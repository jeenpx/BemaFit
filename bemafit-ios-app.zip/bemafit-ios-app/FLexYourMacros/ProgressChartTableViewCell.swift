//
//  ProgressChartTableViewCell.swift
//  FlexYourMacros
//
//  Created by DBG on 17/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ProgressChartTableViewCell: UITableViewCell {
    
    
    let chartView: ScrollableGraphView = ScrollableGraphView()
    let barPlotView: GroupedBarChartView = GroupedBarChartView()
    var progressType: ProgressType = ProgressType.Weight
    var exerciseType: ExerciseCategory = ExerciseCategory.CardioVascular
    var macroDailyRequirement = [DailyRequirement]()
    let themeBlueColor = UIColor(red: 30.0/255.0, green: 144.0/255.0, blue: 255.0/255.0, alpha: 1.0)

    
//    weak var chartView: ScatterPlotView!
//    weak var barPlotView: GroupedBarChartView!
//    
    let labelNoData: UILabel = UILabel.init()
//    let labelNoDataGroupedChart: UILabel! = UILabel.init()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

//    override func layoutSubviews() {
//        super.layoutSubviews()
//        
//        labelNoDataScatterPlot.transform = CGAffineTransform(scaleX: 1.0, y: -1.0)
//        labelNoDataGroupedChart.transform = CGAffineTransform(scaleX: 1.0, y: -1.0)
//    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func setupViewWithData(progressReportDatas:[[ProgressReport]], xAxisLabels:[String]) {
        
        if self.chartView.superview == nil && progressType != ProgressType.Macros {
            self.contentView.addSubview(self.chartView)
            self.barPlotView.isHidden = true
            self.chartView.isHidden = false
        }
        else if self.barPlotView.superview == nil && progressType == ProgressType.Macros {
            self.contentView.addSubview(self.barPlotView)
            self.barPlotView.isHidden = false
            self.chartView.isHidden = true
        }
        
        self.labelNoData.text = "No records found"
        self.labelNoData.textColor = .gray
        self.labelNoData.textAlignment = .center
        self.labelNoData.font = UIFont.systemFont(ofSize: 14)
        self.contentView.addSubview(self.labelNoData)
        self.labelNoData.isHidden = true
        
        self.chartView.lineWidth = 1.0
        self.chartView.lineColor = themeBlueColor
        self.chartView.lineStyle = .straight
        self.chartView.lineJoin =  kCALineJoinRound
        self.chartView.lineCap = kCALineCapRound
        self.chartView.shouldFill = true
        self.chartView.fillType = .gradient
        self.chartView.fillGradientStartColor = themeBlueColor
        self.chartView.fillGradientEndColor = .white
        self.chartView.fillGradientType = .radial
        self.chartView.dataPointSpacing = CGFloat(80.0)
        self.chartView.direction = .leftToRight
        self.chartView.shouldAutomaticallyDetectRange = true
        self.chartView.dataPointType = .circle
        self.chartView.dataPointSize = CGFloat(5.0)
        self.chartView.dataPointFillColor = themeBlueColor
        self.chartView.shouldAdaptRange = true
        self.chartView.shouldAnimateOnAdapt = true
        self.chartView.animationDuration = 1.0
        self.chartView.adaptAnimationType = .easeOut
        self.chartView.shouldAnimateOnStartup = true
        self.chartView.shouldShowReferenceLines = true
        self.chartView.referenceLineColor = .lightGray
        self.chartView.referenceLineThickness = CGFloat(1.0)
        self.chartView.referenceLinePosition = .left
        self.chartView.referenceLineType = .cover
        self.chartView.numberOfIntermediateReferenceLines = 2
        self.chartView.shouldAddLabelsToIntermediateReferenceLines = true
        self.chartView.shouldAddUnitsToIntermediateReferenceLineLabels = false
        self.chartView.referenceLineLabelFont = UIFont.systemFont(ofSize: 8)
        self.chartView.referenceLineLabelColor = .lightGray
        self.chartView.shouldShowReferenceLineUnits = false
        self.chartView.referenceLineNumberOfDecimalPlaces = 1
        self.chartView.shouldShowLabels = true
        self.chartView.dataPointLabelTopMargin = CGFloat(3.0)
        self.chartView.dataPointLabelBottomMargin = CGFloat(3.0)
        self.chartView.dataPointLabelFont = UIFont.systemFont(ofSize: 8)
        self.chartView.dataPointLabelColor = .lightGray
        
        let data:[Double] = [0.0,0.0,0.0,0.0]
        let labels = ["", "", "",""]
        self.chartView.set(data: data, withLabels: labels)
        
        if progressType == ProgressType.Weight {
            
            self.barPlotView.isHidden = true
            self.chartView.isHidden = false
            
            var averageArray = [Double]()
            averageArray = progressReportDatas.map({ progressReports in
                
                let itemArray: [Double] = progressReports.map { return $0.weight.doubleValue }
                let itemTotal: Double   = itemArray.reduce(0) { return $0 + $1 }
                return itemArray.count != 0 ? Double(itemTotal) / Double(itemArray.count) : 0.0
            })

            if averageArray.count == 0 || xAxisLabels.count == 0 /*|| averageArray.count != xAxisLabels.count*/ {
                self.labelNoData.isHidden = false
                self.chartView.isHidden = true
                self.barPlotView.isHidden = true
                return
            }
            
//            self.removeLastZero(dataArray: averageArray, labelArray: xAxisLabels)
            self.chartView.set(data: averageArray, withLabels: xAxisLabels)
        }
        else if progressType == ProgressType.Bodyfat {
            
            self.barPlotView.isHidden = true
            self.chartView.isHidden = false
            
            var averageArray = [Double]()
            averageArray = progressReportDatas.map({ progressReports in
                
                let itemArray: [Double] = progressReports.map { return $0.bodyfat.doubleValue }
                let itemTotal: Double   = itemArray.reduce(0) { return $0 + $1 }
                return itemArray.count != 0 ? Double(itemTotal) / Double(itemArray.count) : 0.0
            })
            
            if averageArray.count == 0 || xAxisLabels.count == 0 /*|| averageArray.count != xAxisLabels.count*/ {
                self.labelNoData.isHidden = false
                self.chartView.isHidden = true
                self.barPlotView.isHidden = true
                return
            }
            
            self.chartView.set(data: averageArray, withLabels: xAxisLabels)
        }
        else if progressType == ProgressType.Exercise && exerciseType == ExerciseCategory.Strength {
            
            self.barPlotView.isHidden = true
            self.chartView.isHidden = false
            
            var averageArray = [Double]()
            averageArray = progressReportDatas.map({ progressReports in
                
                let itemArray: [Double] = progressReports.map { return $0.calorie.doubleValue }
                let itemTotal: Double   = itemArray.reduce(0) { return $0 + $1 }
                return itemArray.count != 0 ? Double(itemTotal) / Double(itemArray.count) : 0.0
            })
            
            if averageArray.count == 0 || xAxisLabels.count == 0 /*|| averageArray.count != xAxisLabels.count*/ {
                self.labelNoData.isHidden = false
                self.chartView.isHidden = true
                self.barPlotView.isHidden = true
                return
            }
            
            self.chartView.set(data: averageArray, withLabels: xAxisLabels)
        }
        else if progressType == ProgressType.Exercise && exerciseType == ExerciseCategory.CardioVascular {
            
            self.barPlotView.isHidden = true
            self.chartView.isHidden = false
            
            var averageArray = [Double]()
            averageArray = progressReportDatas.map({ progressReports in
                
                let itemArray: [Double] = progressReports.map { return $0.amount.doubleValue }
                let itemTotal: Double   = itemArray.reduce(0) { return $0 + $1 }
                return itemArray.count != 0 ? Double(itemTotal) / Double(itemArray.count) : 0.0
            })
            
            if averageArray.count == 0 || xAxisLabels.count == 0 /*|| averageArray.count != xAxisLabels.count*/ {
                self.labelNoData.isHidden = false
                self.chartView.isHidden = true
                self.barPlotView.isHidden = true
                return
            }
            
            self.chartView.set(data: averageArray, withLabels: xAxisLabels)
        }
        else if progressType == ProgressType.Macros {
            
            self.barPlotView.isHidden = false
            self.chartView.isHidden = true
            
            var macroPercentageArray = [[Double]]()

            let macroRequired = self.macroDailyRequirement.first
            
            macroPercentageArray = progressReportDatas.map({ progressReports in
                
                let calorieDayArray: [Double] = progressReports.map { return $0.calorie.doubleValue }
                let calorieDayTotal: Double   = calorieDayArray.reduce(0) { return $0 + $1 }
                
                //protein calculation
                let proteinDayArray: [Double] = progressReports.map { return $0.protein.doubleValue }
                let proteinDayTotal: Double   = proteinDayArray.reduce(0) { return $0 + $1 }
                
                //fat calculation
                let fatDayArray: [Double] = progressReports.map { return $0.fat.doubleValue }
                let fatDayTotal: Double   = fatDayArray.reduce(0) { return $0 + $1 }
                
                //carb calculation
                let carbDayArray: [Double] = progressReports.map { return $0.carb.doubleValue }
                let carbDayTotal: Double   = carbDayArray.reduce(0) { return $0 + $1 }
                
                //fibre calculation
                let fibreDayArray: [Double] = progressReports.map { return $0.fibre.doubleValue }
                let fibreDayTotal: Double   = fibreDayArray.reduce(0) { return $0 + $1 }
                
                return [self.getThePercentageValue(calorieDayTotal, total: macroRequired!.calories_total), self.getThePercentageValue(proteinDayTotal, total: macroRequired!.protein_total), self.getThePercentageValue(fatDayTotal, total: macroRequired!.fat_total), self.getThePercentageValue(carbDayTotal, total: macroRequired!.carbs_total), self.getThePercentageValue(fibreDayTotal,total: macroRequired!.fiber_total)]
            })
            
            self.barPlotView.xAxisLabels =  macroPercentageArray.count == 0 ? [] : xAxisLabels
            self.barPlotView.chartViewData = macroPercentageArray
            labelNoData.isHidden = macroPercentageArray.count == 0 ? false : true
            self.chartView.isHidden = true
            self.barPlotView.isHidden = macroPercentageArray.count == 0 ? true : false
        }
    }
    
    func getThePercentageValue(_ value: Double, total: String) -> Double {
        
        if total.doubleValue <= 0.0 {
            return 0.0
        }
        if value > total.doubleValue {
            return 100.0
        }
        return (value / total.doubleValue) * 100.0
    }

    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.chartView.frame = CGRect(x: 5, y: 5, width: self.contentView.bounds.width - 10, height: self.contentView.bounds.height - 10)
        self.barPlotView.frame = CGRect(x: 5, y: 5, width: self.contentView.bounds.width - 10, height: self.contentView.bounds.height - 10)
        self.labelNoData.frame = CGRect(x: 5, y: 5, width: self.contentView.bounds.width - 10, height: self.contentView.bounds.height - 10)
    }

//    let arrayData: [Double] = [0.0, 2.0, 15.0, 12.9, 25.0, 6.5, 10.0, 3.8, 4.5, 11.0]
//    
//    var xAxisData:[String] = []
//    
//    var chartData:[[ProgressReport]] = [] {
//        
//        didSet {
//            
//            var averageArray = [Double]()
//            
//            if progressType == ProgressType.Weight {
//                
//                self.chartView.isHidden = false
//                self.barPlotView.isHidden = true
//                averageArray = chartData.map({ progressReports in
//                    
//                    let itemArray: [Double] = progressReports.map { return $0.weight.doubleValue }
//                    let itemTotal: Double   = itemArray.reduce(0) { return $0 + $1 }
//                    return itemArray.count != 0 ? Double(itemTotal) / Double(itemArray.count) : 0.0
//                })
//
//                chartView.xAxisLabels = xAxisData
//                chartView.chartViewData = averageArray
//                labelNoDataScatterPlot.isHidden = averageArray.count == 0 ? false : true
//                
//            } else if progressType == ProgressType.Bodyfat {
//                
//                self.chartView.isHidden = false
//                self.barPlotView.isHidden = true
//                averageArray = chartData.map({ progressReports in
//                    
//                    let itemArray: [Double] = progressReports.map { return $0.bodyfat.doubleValue }
//                    let itemTotal: Double   = itemArray.reduce(0) { return $0 + $1 }
//                    return itemArray.count != 0 ? Double(itemTotal) / Double(itemArray.count) : 0.0
//                })
//                
//                chartView.xAxisLabels = xAxisData
//                chartView.chartViewData = averageArray
//                labelNoDataScatterPlot.isHidden = averageArray.count == 0 ? false : true
//
//                
//            }else if  progressType == ProgressType.Exercise && exerciseType == ExerciseCategory.Strength {
//
//                self.chartView.isHidden = false
//                self.barPlotView.isHidden = true
//                averageArray = chartData.map({ progressReports in
//                    
//                    let itemArray: [Double] = progressReports.map { return $0.calorie.doubleValue }
//                    let itemTotal: Double   = itemArray.reduce(0) { return $0 + $1 }
//                    return itemArray.count != 0 ? Double(itemTotal) / Double(itemArray.count) : 0.0
//                })
//
//                chartView.xAxisLabels = xAxisData
//                chartView.chartViewData = averageArray
//                labelNoDataScatterPlot.isHidden = averageArray .reduce(0) { return $0 + $1 } > 0 ? true : false
//
//            } else if  progressType == ProgressType.Exercise && exerciseType == ExerciseCategory.CardioVascular {
//                
//                self.chartView.isHidden = false
//                self.barPlotView.isHidden = true
//                averageArray = chartData.map({ progressReports in
//                    
//                    let itemArray: [Double] = progressReports.map { return $0.amount.doubleValue }
//                    let itemTotal: Double   = itemArray.reduce(0) { return $0 + $1 }
//                    return itemArray.count != 0 ? Double(itemTotal) / Double(itemArray.count) : 0.0
//                })
//
//                chartView.xAxisLabels = xAxisData
//                chartView.chartViewData = averageArray
//                labelNoDataScatterPlot.isHidden = averageArray .reduce(0) { return $0 + $1 } > 0 ? true : false
//                
//            } else if progressType == ProgressType.Macros {
//               
//                self.chartView.isHidden = true
//                self.barPlotView.isHidden = false
//                
//                var macroPercentageArray = [[Double]]()
//                
//                let macroRequired = self.macroDailyRequirement.first
//
//                macroPercentageArray = chartData.map({ progressReports in
//                    
//                    let calorieDayArray: [Double] = progressReports.map { return $0.calorie.doubleValue }
//                    let calorieDayTotal: Double   = calorieDayArray.reduce(0) { return $0 + $1 }
//                    
//                    //protein calculation
//                    let proteinDayArray: [Double] = progressReports.map { return $0.protein.doubleValue }
//                    let proteinDayTotal: Double   = proteinDayArray.reduce(0) { return $0 + $1 }
//                    
//                    //fat calculation
//                    let fatDayArray: [Double] = progressReports.map { return $0.fat.doubleValue }
//                    let fatDayTotal: Double   = fatDayArray.reduce(0) { return $0 + $1 }
//                    
//                    //carb calculation
//                    let carbDayArray: [Double] = progressReports.map { return $0.carb.doubleValue }
//                    let carbDayTotal: Double   = carbDayArray.reduce(0) { return $0 + $1 }
//                    
//                    //fibre calculation
//                    let fibreDayArray: [Double] = progressReports.map { return $0.fibre.doubleValue }
//                    let fibreDayTotal: Double   = fibreDayArray.reduce(0) { return $0 + $1 }
//                    
//                    return [self.getThePercentageValue(calorieDayTotal, total: macroRequired!.calories_total), self.getThePercentageValue(proteinDayTotal, total: macroRequired!.protein_total), self.getThePercentageValue(fatDayTotal, total: macroRequired!.fat_total), self.getThePercentageValue(carbDayTotal, total: macroRequired!.carbs_total), self.getThePercentageValue(fibreDayTotal,total: macroRequired!.fiber_total)]
//                })
//                
//                //print("macro sorted array-----\(macroPercentageArray)")
//                self.barPlotView.xAxisLabels =  macroPercentageArray.count == 0 ? [] : xAxisData
//                self.barPlotView.chartViewData = macroPercentageArray
//                labelNoDataGroupedChart.isHidden = macroPercentageArray.count == 0 ? false : true
//            }
//        }
//    }
//    
//    var macroDailyRequirement = [DailyRequirement]()
//    
//    func getThePercentageValue(_ value: Double, total: String) -> Double {
//        
//        if total.doubleValue <= 0.0 {
//            return 0.0
//        }
//        if value > total.doubleValue {
//            return 100.0
//        }
//        return (value / total.doubleValue) * 100.0
//    }
//
//    var progressType: ProgressType = ProgressType.Weight
//    var exerciseType: ExerciseCategory = ExerciseCategory.CardioVascular
}
