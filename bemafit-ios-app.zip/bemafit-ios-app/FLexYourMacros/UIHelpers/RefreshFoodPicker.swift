//
//  RefreshFoodPicker.swift
//  FlexYourMacros
//
//  Created by Chandrachudh on 19/01/17.
//  Copyright © 2017 Digital Brand Group. All rights reserved.
//

import UIKit

protocol RefreshoodPickerDelegate:class {
    func didSelectFoodAtIndex(index:Int)
}

class RefreshFoodPicker: UIControl, UIPickerViewDelegate, UIPickerViewDataSource {
    //New picker view to select food from menu
    var baseView:UIView = UIView.init()
    let btnCancel:UIButton = UIButton.init()
    let btnDone:UIButton = UIButton.init()
    let pickerView:UIPickerView = UIPickerView.init()
    
    weak var delegate:RefreshoodPickerDelegate?
    
    var foods = [String]()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.createViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createViews() {
        
        self.backgroundColor = UIColor.init(red: 0, green: 0, blue: 0, alpha: 0.3)
        self.addTarget(self, action: #selector(dismissPicker), for: .touchUpInside)
        
        self.baseView.backgroundColor = .white
        self.addSubview(self.baseView)
        
        self.btnCancel.setTitle("Cancel", for: .normal)
        self.btnCancel.setTitleColor(UIColor.rgb(fromHex: 0x157EF8), for: .normal)
        self.btnCancel.addTarget(self, action: #selector(dismissPicker), for: .touchUpInside)
        self.btnCancel.contentHorizontalAlignment = UIControlContentHorizontalAlignment.left
        if #available(iOS 8.2, *) {
            self.btnCancel.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: UIFontWeightSemibold)
        } else {
            // Fallback on earlier versions
        }
        self.baseView.addSubview(self.btnCancel)
        
        //rgba(41, 128, 185,1.0)
        
        self.btnDone.setTitle("Done", for: .normal)
        self.btnDone.setTitleColor(UIColor.rgb(fromHex: 0x157EF8), for: .normal)
        self.btnDone.addTarget(self, action: #selector(doneButtonTapped), for: .touchUpInside)
        self.btnDone.contentHorizontalAlignment = UIControlContentHorizontalAlignment.right
        if #available(iOS 8.2, *) {
            self.btnDone.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: UIFontWeightSemibold)
        } else {
            // Fallback on earlier versions
        }
        self.baseView.addSubview(self.btnDone)
        
        
        self.baseView.addSubview(self.pickerView)
        self.pickerView.backgroundColor = UIColor.white
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.foods.count
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        var label: UILabel
        
        if let view = view as? UILabel {
            label = view
        } else {
            label = UILabel()
        }
        
        label.textColor = .black
        label.textAlignment = .center
        label.numberOfLines = 0
        label.font = UIFont(name: "SanFranciscoText-Light", size: 12)
        
        // where data is an Array of String
        label.text = self.foods[row]
        
        return label
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.foods[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return self.bounds.width
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 40.0
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let screenWidth:CGFloat = self.bounds.width
        let screenHeight:CGFloat = self.bounds.height
        
        self.baseView.frame = CGRect(x: 0, y: screenHeight - 250, width: screenWidth, height: 250)
        self.btnCancel.frame = CGRect(x: 10, y: 0, width: 100, height: 30)
        self.btnDone.frame = CGRect(x: screenWidth-110, y: 0, width: 100, height: 30)
        
        self.pickerView.frame = CGRect(x: 0, y: self.btnCancel.frame.maxY, width: self.bounds.width, height: self.baseView.bounds.height - self.btnCancel.frame.maxY)
    }
    
    func showWithAnimation(foodToShow:[String]) {
        self.foods = foodToShow
        
        let screenWidth:CGFloat = self.bounds.width
        let screenHeight:CGFloat = self.bounds.height
        
        self.baseView.frame = CGRect(x: 0, y: screenHeight, width: screenWidth, height: 250)
        
        UIView.animate(withDuration: 0.25, delay: 0.0, options: .curveLinear, animations: {
            self.baseView.frame = CGRect(x: 0, y: screenHeight - 250, width: screenWidth, height: 250)
        }) { (finished) in
            
            self.pickerView.reloadAllComponents()
        }
    }
    
    func dismissPicker() {
        
        let screenWidth:CGFloat = self.bounds.width
        let screenHeight:CGFloat = self.bounds.height
        
        UIView.animate(withDuration: 0.25, delay: 0.0, options: .curveLinear, animations: {
            self.baseView.frame = CGRect(x: 0, y: screenHeight, width: screenWidth, height: 250)
        }) { (finished) in
            self.removeFromSuperview()
        }
        
    }
    
    func doneButtonTapped() {
        print("\(self.pickerView.selectedRow(inComponent: 0))")
        self.delegate?.didSelectFoodAtIndex(index: self.pickerView.selectedRow(inComponent: 0))
        self.dismissPicker()
    }

}
