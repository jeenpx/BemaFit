//
//  DailyMealPlanShareModel.swift
//  FlexYourMacros
//
//  Created by Aromal Sasidharan on 12/24/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import Foundation



class DailyMealPlanShare: NSObject {


    
    var meta: MetaModel?
    
    
    
    
    class func responseMapping() -> RKObjectMapping{
        
        
        let rkObjectMapping = RKObjectMapping(for: self)
        
        rkObjectMapping?.addPropertyMapping(DailyMealPlanShare.metaModelKeyMapping)
        
        return rkObjectMapping!;
        
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }


    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: DailyMealPlanShare.responseMapping(), method: .POST, pathPattern: Constants.ServiceConstants.kDailyMealPlanShareUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    
    class func shareDialyMealPlan(_ dailyMealPlanId : String!, friendsID : [String], withBlock onResponse:@escaping (_ error:NSError?)->()) -> (){
        
       SVProgressHUD.show()
        
        
        
        
        RestKitManager.setToken(true)
        
        // create a post request
        let request = RestKitManager.shared().request(with: nil, method: .POST, path: Constants.ServiceConstants.kDailyMealPlanShareUrl, parameters: nil)
        
        // set params as body
        var params = [String: Any]()
        
        
        

        /*test data for aro@gmail.com
        params["guid"] = "66701f9f3210af6f63703603feb938d9"
        params["user_id"] = ["b243c52ba419c50df5e8d6b811f60e40","d5e10882a178fa5b18c99f11a038dde2"]
        */
        
        params["guid"] = dailyMealPlanId as Any?
        params["user_id"] = friendsID as Any? 
        
        
        
        request?.httpBody = try? JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
        
        // create an operation with the request
        let operation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
        
            let dailyMealPlanShareResponse = mappingResult?.firstObject as! DailyMealPlanShare
            
            SVProgressHUD.dismiss()
            
            let responseCode = dailyMealPlanShareResponse.meta?.responseCode
            
            if responseCode != 200{
                onResponse(NSError(domain: "", code: -57, userInfo: [NSLocalizedDescriptionKey:"Please try again later"]))
                return
            }
            onResponse(nil)
            
            //print("result received \(dailyMealPlanShareResponse.meta?.responseCode)")

        }) { (operation, error) in
            SVProgressHUD.dismiss()
            //print("Error received \(error)")
            onResponse(error as NSError?)
        }
        
//        let operation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation : RKObjectRequestOperation!, mappingResult : RKMappingResult!) -> Void in
//            let dailyMealPlanShareResponse = mappingResult.firstObject as! DailyMealPlanShare
//
//            SVProgressHUD.dismiss()
//            
//            let responseCode = dailyMealPlanShareResponse.meta?.responseCode
//            
//            if responseCode != 200{
//                onResponse(error: NSError(domain: "", code: -57, userInfo: [NSLocalizedDescriptionKey:"Please try again later"]))
//                return
//            }
//            onResponse(error: nil)
//            
//            //print("result received \(dailyMealPlanShareResponse.meta?.responseCode)")
//
//            }) { (operation : RKObjectRequestOperation!, error : NSError!) -> Void in
//                
//            SVProgressHUD.dismiss()
//                //print("Error received \(error)")
//                onResponse(error: error)
//
//        }
        
        
        // enque request operation
        RestKitManager.shared().enqueue(operation)
    }
}
