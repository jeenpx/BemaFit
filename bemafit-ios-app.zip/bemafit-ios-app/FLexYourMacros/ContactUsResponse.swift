//
//  ContactUsResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 02/07/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ContactUsResponse: NSObject {
   
    var metaModel: MetaModel?

    class var contactUsResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        // give referece to meta model
        responseMapping?.addPropertyMapping(ContactUsResponse.metaModelKeyMapping)        
        
        return responseMapping!
    }
    
    class var userResponseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: contactUsResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.contactUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    class func sendMessageToFYM(_ message:String,completionHandler: @escaping (_ response:ContactUsResponse) -> ()) {
         SVProgressHUD.show()
        RestKitManager.setToken(true)
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["message":message]
        }
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path: Constants.ServiceConstants.contactUrl, parameters: parameterDictionary, constructingBodyWith: { (formData) in
            
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let response = mappingResult?.firstObject as! ContactUsResponse
            
            completionHandler(response)
             SVProgressHUD.dismiss()
            
            }) { (operation, error) in
                
                //print("failed to load contact us with error \(error)")
                SVProgressHUD.dismiss()
        }
        
        RestKitManager.shared().enqueue(operation)
    }
    

    
}
