//
//  FAQViewController.swift
//  FlexYourMacros
//
//  Created by Vineeth Edwin on 13/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FAQViewController: UIViewController {

    @IBOutlet weak var webViewFAQ: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // create a request
        let request = URLRequest(url: URL(string: "http://apple.com")!)
        
        // loading the url on webView
        webViewFAQ.loadRequest(request)
    }
    
    @IBAction func buttonActionBack(_ sender: UIBarButtonItem) {
        
        // checks if the settings needed to be updated
        self.navigationController?.popViewController(animated: true)
    }
}
