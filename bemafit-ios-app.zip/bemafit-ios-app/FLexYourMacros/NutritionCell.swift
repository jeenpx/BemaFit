//
//  NutritionCell.swift
//  FlexYourMacros
//
//  Created by dbgattila on 6/1/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class NutritionCell: UITableViewCell {

    @IBOutlet weak var labelNutritionName: UILabel!
    @IBOutlet weak var labelNutritionDescription: UILabel!
    
    // set ui values
    var nutrition: NutritionPlanModel? {
        didSet {
            labelNutritionName.text = nutrition?.nutritionName
            labelNutritionDescription.text = nutrition?.nutritionDescription
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
