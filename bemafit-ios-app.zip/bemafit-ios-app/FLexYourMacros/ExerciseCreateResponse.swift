//
//  ExerciseCreateResponse.swift
//  FlexYourMacros
//
//  Created by mini on 29/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _ExerciseCreateResponse = ExerciseCreateResponse()

class ExerciseCreateResponse: NSObject {
    
    var metaModel: MetaModel?
    var createdExercise: ExerciseTypeModel?
    
    class var sharedExerciseCreateResponse: ExerciseCreateResponse {
        return _ExerciseCreateResponse
    }
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(ExerciseCreateResponse.metaModelKeyMapping)
        
        //give reference to exercise model mapping
        responseMapping?.addPropertyMapping(ExerciseCreateResponse.exerciseTypeModelKeyMapping)
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var exerciseTypeModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathExerciseTypeResult, toKeyPath: "createdExercise", with: ExerciseTypeModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: responseMapping, method: .POST, pathPattern: Constants.ServiceConstants.ExerciseUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    
    class func createExercise(_ exercise: [String: String], completionHandler: @escaping (_ createdExerciseId: String, _ successful: Bool, _ message: String) -> ()) {
        
        RestKitManager.setToken(true)
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path: Constants.ServiceConstants.ExerciseUrl, parameters: exercise, constructingBodyWith: { (formData) in
            
        })
        
        SVProgressHUD.show()

        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            SVProgressHUD.dismiss()

            let logResponse = mappingResult?.firstObject as! ExerciseCreateResponse
            // check for success
            if logResponse.metaModel?.responseCode != 200 {
                
                completionHandler("", false, logResponse.metaModel!.message)
                return;
            }
            
            let returnedExercise = logResponse.createdExercise!
            
            completionHandler(returnedExercise.exerciseId, true, logResponse.metaModel!.message)
            }) { (operation, error) in
                
                SVProgressHUD.dismiss()

                completionHandler("", false, &&"failed_to_log_exercise_alert_message")

                //print("failed to create exercise with error \(error)")
        }
        
        RestKitManager.shared().enqueue(operation)
        
        
    }
    
}
