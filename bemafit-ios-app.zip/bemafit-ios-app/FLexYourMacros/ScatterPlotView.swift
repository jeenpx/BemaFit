//
//  ScatterPlotView.swift
//  ChartViews
//
//  Created by DBG-39 on 21/04/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

import Foundation
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}


class ScatterPlotView: CPTGraphHostingView, CPTPlotAreaDelegate, CPTPlotSpaceDelegate, CPTPlotDataSource, CPTScatterPlotDelegate {
    
    var check: Bool = false
    
    var chartViewXIndex = [Int]()
    var  xAxisLabels    = [String]()
    let themeBlueColor = UIColor(red: 30.0/255.0, green: 144.0/255.0, blue: 255.0/255.0, alpha: 1.0)
    
    
    var chartViewData: [Double]? {
        didSet {
            
            chartViewXIndex = [Int]()
            
            for i in 0..<(chartViewData?.count)! {
                chartViewXIndex.append(i)
            }
            configureGraph()
        }
        
        // reload graph
    }
    
    var xMaximum: Int? {
        
        return chartViewXIndex.isEmpty ? 1 : chartViewXIndex.reduce(Int.min, { max($0, $1) })
    }
    
    var yMaximum: Double? {
        
        return (chartViewData?.isEmpty != nil) ? chartViewData?.reduce(DBL_MIN, {max($0!, $1)}) : 1.0
    }
    
    var xDivision: Double? {
        
        return chartViewXIndex.isEmpty ? 1.0 : Double(xMaximum! / chartViewXIndex.count-1)
    }
    
    var yDivision: Double? {
        
        return (chartViewData?.isEmpty != nil) ? yMaximum! / 10 : 1.0
        
    }
    
    
    func configureGraph() {
        
        hostedGraph = CPTXYGraph(frame: self.bounds)
        // Plot area delegate
        hostedGraph.plotAreaFrame.plotArea.delegate = self;
        hostedGraph.plotAreaFrame.scroll(CGPoint(x: 0, y: 0))
        hostedGraph.plotAreaFrame.paddingLeft =  25.0+CGFloat((yMaximum!.stringValue).characters.count )
        hostedGraph.plotAreaFrame.masksToBorder = false
        allowPinchScaling = false

        
        // Setup scatter plot space
        let plotSpace = hostedGraph.defaultPlotSpace as! CPTXYPlotSpace
        plotSpace.allowsUserInteraction = true;
        plotSpace.allowsMomentum        = false;
        plotSpace.delegate              = self;
        
        // Grid line styles
        let majorGridLineStyle = CPTMutableLineStyle()
        majorGridLineStyle.lineWidth = 0.75;
        majorGridLineStyle.lineColor = CPTColor.lightGray()
        
        let minorGridLineStyle = CPTMutableLineStyle()
        minorGridLineStyle.lineWidth = 0.25
        minorGridLineStyle.lineColor = CPTColor.white().withAlphaComponent(0.1)
        
        // Axes
        // Label x axis with a fixed interval policy
        let axisSet = hostedGraph.axisSet as! CPTXYAxisSet
        let x          = axisSet.xAxis as CPTXYAxis
        x.majorIntervalLengthNumber         = NSNumber.init(value: 2.0 * xDivision!)
        x.orthogonalCoordinateDecimalNumber = 0.0
        x.preferredNumberOfMajorTicks = 8
        x.labelingPolicy = CPTAxisLabelingPolicy.none
        
        //  make the custom labels
        var labelLocation     = 0
        var customLabels   = NSMutableSet(capacity: xAxisLabels.count)
        
        for  tickLocation in chartViewXIndex  {
            let newLabel = CPTAxisLabel(text: xAxisLabels[labelLocation], textStyle: x.labelTextStyle) as CPTAxisLabel
            newLabel.tickLocationNumber = tickLocation as NSNumber!
            newLabel.offset = x.labelOffset
            customLabels .add(newLabel)
            labelLocation += 1
        }
        
        x.axisLabels = customLabels as Set<NSObject>;
        x.minorTicksPerInterval       = 0
        x.labelOffset                 = -5.0
        x.titleOffset   = 30.0
        x.titleLocationNumber = 1.2
        if chartViewData?.count == 0 {
            x.isHidden = true
        
        }
        else {
            
            x.isHidden = false
        }
        x.axisConstraints = CPTConstraints.constraint(withRelativeOffset: 0.0)//(0.0)
        
        
        // Label y with an automatic label policy.
        let y = axisSet.yAxis as CPTXYAxis
        y.isHidden = true
        y.orthogonalCoordinateDecimalNumber = 0.0
        y.majorIntervalLengthNumber = NSNumber.init(value:2*yDivision!)
        y.minorTicksPerInterval       = 0
        y.preferredNumberOfMajorTicks = 8
        y.majorGridLineStyle          = majorGridLineStyle
        y.minorGridLineStyle          = minorGridLineStyle
        y.labelOffset                 = -5
        y.titleOffset   = 30.0
        y.titleLocationNumber = 1.0
        y.axisConstraints = CPTConstraints.constraint(withLowerOffset: 0.0)
        
        // Create a plot that uses the data source method
        let dataSourceLinePlot = CPTScatterPlot(frame: CGRect.zero)
        dataSourceLinePlot?.identifier = "Data Source Plot" as (NSCoding & NSCopying & NSObjectProtocol)!
        
        let lineStyle = dataSourceLinePlot?.dataLineStyle.mutableCopy() as! CPTMutableLineStyle
        lineStyle.lineWidth              = 1.5
        lineStyle.lineJoin               = CGLineJoin.round
        lineStyle.lineGradient           = CPTGradient(beginning: CPTColor(componentRed: 65.0/255.0, green: 105.0/255.0, blue: 225.0/255.0, alpha: 1.0), ending: CPTColor.white())
        dataSourceLinePlot?.dataLineStyle = lineStyle
        dataSourceLinePlot?.dataSource    = self
        hostedGraph.add(dataSourceLinePlot)
        
        // Put an area gradient under the plot above
        let areaColor       = CPTColor(componentRed: 30.0/255.0, green: 144.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        let areaGradient = CPTGradient(beginning: areaColor, ending: CPTColor.white())
        areaGradient?.angle = -90.0
        let areaGradientFill = CPTFill(gradient: areaGradient) as CPTFill
        dataSourceLinePlot?.areaFill      = areaGradientFill
        dataSourceLinePlot?.areaBaseValueNumber = 0.0
        
        // Auto scale the plot space to fit the plot data
        // Extend the ranges by 30% for neatness
        plotSpace.scale(toFitPlots: [dataSourceLinePlot!])
        let xRange = plotSpace.xRange.mutableCopy() as! CPTMutablePlotRange
        let yRange = plotSpace.yRange.mutableCopy() as! CPTMutablePlotRange
        xRange.expand(byFactorNumber: 1.0)
        yRange.expand(byFactorNumber: 4.0)
        plotSpace.xRange = xRange
        plotSpace.yRange = yRange
        
        // Restrict y range to a global range
        let globalYRange = CPTPlotRange(locationNumber: 0.0, lengthNumber: NSNumber.init(value: yMaximum! +  yDivision!) )
        plotSpace.globalYRange = globalYRange
        
        // Add plot symbols
        let symbolGradient = CPTGradient(beginning: areaColor, ending: areaColor) as CPTGradient
        symbolGradient.gradientType = CPTGradientType.radial
        symbolGradient.startAnchor  = CGPoint(x: 0.25, y: 0.75)
        let plotSymbol = CPTPlotSymbol.ellipse() as CPTPlotSymbol
        plotSymbol.fill               = CPTFill(gradient: symbolGradient)
        plotSymbol.lineStyle          = nil
        plotSymbol.size               = CGSize(width: 9.0, height: 9.0)
        dataSourceLinePlot?.plotSymbol = plotSymbol
        
        // Set plot delegate, to know when symbols have been touched
        // We will display an annotation when a symbol is touched
        dataSourceLinePlot?.delegate                        = self;
        dataSourceLinePlot?.plotSymbolMarginForHitDetection = 5.0;
        
        hostedGraph.reloadData()
        
    }
    
    // plot datasource methods
    func numberOfRecords(for plot: CPTPlot!) -> UInt {
        return UInt(chartViewData!.count)
    }
    
    func number(for plot: CPTPlot!, field fieldEnum: UInt, record idx: UInt) -> Any! {
        var indexValue: NSNumber = 0
        
        switch fieldEnum {
        case 0:
            indexValue = NSNumber.init(value: chartViewXIndex[Int(idx)])
        case 1:
            indexValue = NSNumber.init(value: chartViewData![Int(idx)])
        default:
            break
        }
        return indexValue
    }
    
    func plotSpace(_ space: CPTPlotSpace!, willChangePlotRangeTo newRange: CPTPlotRange!, for coordinate: CPTCoordinate) -> CPTPlotRange! {
        
        var returnRange = CPTPlotRange()
        
        // Impose a limit on how far user can scroll in x
        let maxRange = CPTPlotRange(locationNumber: -1.0, lengthNumber:NSNumber.init(value: 2*xMaximum!)) as CPTPlotRange
        let changedRange = newRange.mutableCopy() as! CPTMutablePlotRange
        changedRange.shiftEndToFit(in: maxRange)
        changedRange.shiftLocationToFit(in: maxRange)
        returnRange = changedRange;
        return returnRange
    }
}
