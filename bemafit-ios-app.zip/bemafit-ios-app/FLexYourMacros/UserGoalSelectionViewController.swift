//
//  UserGoalSelectionViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 05/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

enum Goal: String {
    case Maintain   = "maintain"
    case FatLoss    = "fatloss"
    case Bulking    = "bulking"
    case Custom     = "custom"
    
    static var types = [Maintain, FatLoss, Bulking, Custom]
    
    var description: String {
        switch self {
        case .Maintain: return "1"
        case .FatLoss:  return "2"
        case .Bulking: return "3"
        case .Custom: return "4"
        default: return ""
        }
    }
}

struct StoryBoard {
    
    struct CellIdentifiers {
        static let IntensityHeaderCell =  "kHeaderCellIntensity"
        static let CustomHeaderCell    =  "kHeaderCellCustom"
        static let GoalCell      =  "kGoalCell"
        static let GoalTypeCell  =  "kGoalTypeCell"
        static let IntensityCell = "kIntensityCell"
        static let CustomCell       = "kCustomCell"
    }
    
    struct SegueIdentifiers {
        static let CompleteSignUp = "kCompleteSignUp"
        static let Nutrition = "kNutrition"
    }
}
class UserGoalSelectionViewController: UITableViewController, UITextFieldDelegate, GoalTypeCellDelegate {
    
    var isCustomCalorieSelected = false
    var shouldShowFatLossIntensityLevel = false
    var shouldShowBulkingIntensityLevel = false
    var currentIndexPath: IndexPath! = nil
    var goals = [GoalModel]()
    var goalOptions = [GoalOptionModel]()
    var themeColor = UIColor.defaultThemeBlueColor()
    let FymUserModel = FymUser.sharedFymUser
    var currentTextField = UITextField()
    
    fileprivate var selectedGoal = Goal.Maintain {
        didSet {
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        goals = AppConfiguration.sharedAppConfiguration.goals
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        if FymUserModel.userGoalOptionId == "" {
            FymUserModel.userSelectedGoal = goals[0]
            goalOptions = goals[0].goalOptions! as [GoalOptionModel]
            FymUserModel.userGoalOptionId = goalOptions[0].goalOptionId!
        }
        
        setuserBulkingIntensityValue()
        
        setuserFatlossIntensityValue()
    }
    
    func setuserBulkingIntensityValue() {
        
        if FymUserModel.userBulkingIntensityValue == "" {
            
            let bulkingGoalArray: [GoalModel]  = goals.filter { return $0.goalId == "3"}
           
            if bulkingGoalArray.isEmpty {
                
                return
            }
            let bulkingGoalOptions: [GoalOptionModel] = bulkingGoalArray[0].goalOptions!
            
            if bulkingGoalOptions.isEmpty {
                
                return
            }
            FymUserModel.userBulkingIntensityValue = bulkingGoalOptions[0].goalPercentage!
        }
        
    }
    
    func setuserFatlossIntensityValue() {
        
        if FymUserModel.userFatlossIntensityValue == "" {
            
            let fatLossGoalArray: [GoalModel]  = goals.filter { return $0.goalId == "2"}
            
            if fatLossGoalArray.isEmpty {
                
                return
            }
            
            let fatLossGoalOptions: [GoalOptionModel] = fatLossGoalArray[0].goalOptions!
            
            if fatLossGoalOptions.isEmpty {
                
                return
            }
            
            FymUserModel.userFatlossIntensityValue = fatLossGoalOptions[0].goalPercentage!
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        currentTextField.text = String(stringInterpolationSegment: FymUserModel.userCustomCalorie)
        reloadTheTableViewWithTheSelection(Goal.Maintain.description)
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        currentTextField.resignFirstResponder()
        
        if (identifier == StoryBoard.SegueIdentifiers.Nutrition) {
            
            if FymUserModel.userGoalOptionId == "8" {
                
                FymUserModel.userCustomCalorie = String(describing: currentTextField.text).doubleValue
                currentTextField .resignFirstResponder()
                self.tableView .reloadData()
                currentTextField.text = ""
                
                if FymUserModel.userCustomCalorie <= 0.0 {
                    
                    showAlert(&&"notice", message: &&"custom_calorie_alert_message")
                    
                    return false
                }
            }
        }
        
        return true
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    func showAlert(_ title: String, message: String) {
        
            if #available(iOS 8.0, *) {
                let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
                
                self.present(alert, animated: true, completion: nil)
            } else {
                // Fallback on earlier versions
                UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"ok").show()
            }
           
       
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // Return the number of sections.
        return 3
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 0
        } else if section == 1 {
            return shouldShowFatLossIntensityLevel || shouldShowBulkingIntensityLevel ? 40 : 0
        }
        return isCustomCalorieSelected ? 40 : 0
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if section == 0 {
            return nil
        } else if section == 1 {
            let headerView: UIView = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.IntensityHeaderCell)!
            return shouldShowFatLossIntensityLevel || shouldShowBulkingIntensityLevel ? headerView : nil
        }
        let headerView: UIView = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.CustomHeaderCell)!
        return isCustomCalorieSelected ? headerView : nil
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        if section == 0 {
            return goals.count + 1
        } else if section == 1 {
            
            return shouldShowFatLossIntensityLevel || shouldShowBulkingIntensityLevel ? goalOptions.count + extraCount : 0
        }
        return isCustomCalorieSelected ? 1 : 0
    }
    
    var extraCount: Int {
        var extraCount = 1
      
         if UIDevice.current.userInterfaceIdiom == UIUserInterfaceIdiom.phone  && max(UIScreen.main.bounds.size.height, UIScreen.main.bounds.size.width) == 736 {
        extraCount = 1
        }
        
        return extraCount
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell?
        
        if indexPath.section == 0 {
            
            if indexPath.row == 0 {
                
                // load the goal cell for section 0, row 0
                let goalCell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.GoalCell, for: indexPath) 
                
                 goalCell.setSeparatorInsetZero()
                
                cell = goalCell
            }
            else {
                
                // load the goal type cell for section 0, rows above 0
                let goalCell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.GoalTypeCell, for: indexPath) as! GoalTypeTableViewCell
                
                goalCell.goalTypeCellDelegate = self
                // load the goal type text to the button
//                goalCell.itemIndex = indexPath.row - 1
                
                // get the current goal
                let currentGoal = goals[indexPath.row - 1] as GoalModel
                
                currentGoal.goalCalorie = getGoalValue(currentGoal.goalId!)
                // set the goal title
                goalCell.goal = currentGoal
                
                // assign tag to the button
                goalCell.buttonGoalType.tag = currentGoal.goalId!.intValue

                goalCell.buttonGoalType.layer.borderWidth = 1.0
                
                // set the selected goal type to user model

                // set the goal type button title color based on selection
                goalCell.buttonGoalType.setTitleColor(currentGoal.goalId == FymUserModel.userSelectedGoal?.goalId ? UIColor.white : UIColor.darkGray, for: UIControlState())
                
                // set the goal type button background color based on selection
                goalCell.buttonGoalType.backgroundColor = currentGoal.goalId == FymUserModel.userSelectedGoal?.goalId ? themeColor : UIColor.clear
                
                goalCell.buttonGoalType.layer.borderColor = currentGoal.goalId == FymUserModel.userSelectedGoal?.goalId ? themeColor.cgColor : UIColor.darkGray.cgColor
                
                // get the label below the button
//                let goalValueLabel =  goalButton.superview!.subviews.filter() {$0.isKindOfClass(UILabel)} as! [UILabel]
                
                // change the label text color
                goalCell.labelGoalValue.textColor = currentGoal.goalId == FymUserModel.userSelectedGoal?.goalId ? UIColor.white : UIColor.darkGray
                
                cell = goalCell
            }
            
        } else if indexPath.section == 1 {
            
            // load the intensity type cell for the section 1
            let intensityCell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.IntensityCell, for: indexPath) as! IntensityLevelTableViewCell
            
            if indexPath.row < goalOptions.count + extraCount - 1 {

                intensityCell.labelIntensityLevel.isHidden = false

            if shouldShowFatLossIntensityLevel || shouldShowBulkingIntensityLevel{
                
                // load with fatloss intensity levels
                intensityCell.titleString = goalOptions[indexPath.row].goalOptionName!
                
                if (shouldShowFatLossIntensityLevel) {
                    
                    if (goalOptions[indexPath.row].goalPercentage! == FymUserModel.userFatlossIntensityValue) {
                        // set the first row selected
                        intensityCell.accessoryType = UITableViewCellAccessoryType.checkmark
                    } else {
                        intensityCell.accessoryType = UITableViewCellAccessoryType.none
                    }
                } else {
                    
                    if (goalOptions[indexPath.row].goalPercentage! == FymUserModel.userBulkingIntensityValue) {
                        // set the first row selected
                        intensityCell.accessoryType = UITableViewCellAccessoryType.checkmark
                    } else {
                        intensityCell.accessoryType = UITableViewCellAccessoryType.none
                    }
                }
            }
            
            if intensityCell.accessoryType == UITableViewCellAccessoryType.checkmark {
                intensityCell.insertSubview(intensityCell.viewSeparator, aboveSubview: intensityCell.subviews.last! as UIView)
            }
            } else {
                intensityCell.labelIntensityLevel.isHidden = true
            }
            cell = intensityCell
            
        } else {
            
            // load the intensity type cell for the section 2
            let customCell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.CustomCell, for: indexPath) as! CustomGoalTableViewCell
            
            customCell.textFieldCustomGoal.delegate = self
            currentTextField = customCell.textFieldCustomGoal
            if FymUserModel.userCustomCalorie != 0.0 {
                currentTextField.text = String(stringInterpolationSegment: FymUserModel.userCustomCalorie)
            }
            cell = customCell
        }
        
        cell?.selectionStyle = UITableViewCellSelectionStyle.none
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: indexPath)
        
        if !cell!.isKind(of: IntensityLevelTableViewCell.self) {
            return
        }
        
        if indexPath.row >= goalOptions.count + extraCount - 1 {
            return
        }

        getTheIntensityLevel(indexPath.row)
        
        currentIndexPath = indexPath
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 1 || indexPath.section == 2 {
            
            return 60.0
        }
        return 70.0
    }
    
    func getTheIntensityLevel(_ selectedIndex: Int) {
        
        // set the selected intensity level to user model
        let selectedIntensityLevel = goalOptions[selectedIndex].goalPercentage
        let selectedIntensityId = goalOptions[selectedIndex].goalOptionId
        
        if shouldShowFatLossIntensityLevel {
            
            FymUserModel.userFatlossIntensityValue = selectedIntensityLevel!
            FymUserModel.userGoalOptionId = selectedIntensityId!
        } else {
            
            FymUserModel.userBulkingIntensityValue = selectedIntensityLevel!
            FymUserModel.userGoalOptionId = selectedIntensityId!
        }
        self.tableView .reloadData()
    }
    
    func getGoalValue(_ goalId : String) -> Double {
        
        var goalCalorie: Double = 0.0
        
        switch goalId {
            
        case "1" :
           goalCalorie = FymUserModel.userMaintainCalorie
        case "2" :
             goalCalorie = FymUserModel.userFatlossCalorie
        case "3" :
            goalCalorie = FymUserModel.userBulkingCalorie
        case "4" :
            goalCalorie = FymUserModel.userCustomCalorie
        default :
            goalCalorie = FymUserModel.userCustomCalorie
        }
        
        return goalCalorie
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        currentTextField = textField
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        var result = true
        let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        if string.characters.count > 0 {
            let disallowedCharacterSet = CharacterSet(charactersIn: "0123456789.").inverted
            let replacementStringIsLegal = string.rangeOfCharacter(from: disallowedCharacterSet) == nil
            let resultingStringLengthIsLegal = prospectiveText.characters.count <= 10
            let scanner = Scanner(string: prospectiveText)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
            result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
        }
        return result
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        //print("textField.text---\(textField.text)")
        if let text = textField.text {
        FymUserModel.userCustomCalorie = text.doubleValue
        textField .resignFirstResponder()
        self.tableView .reloadData()
        }
        return true
    }
    
   func goalTypeCell(_ goalTypeCell: GoalTypeTableViewCell, didSelectGoal goal: GoalModel) {
        
        setTheGoalButtonStyle(goal)
        
        goalOptions = goal.goalOptions!
        
        if goal.goalId! == Goal.Maintain.description || goal.goalId! == Goal.Custom.description {
            //check with ***API***
            FymUserModel.userGoalOptionId = goalOptions[0].goalOptionId! == "" ? "" : goalOptions[0].goalOptionId!
        }
        reloadTheTableViewWithTheSelection(goal.goalId!)

    }
    
    func setTheGoalButtonStyle(_ goalmodel: GoalModel) {
        
        let arrayAllButtons = tableView.relativeSubviews(UIButton)! as [UIButton]
        
        for goalButton in arrayAllButtons {
            
            // set the selected goal type to user model
            if goalButton.tag == goalmodel.goalId!.intValue {
                FymUserModel.userSelectedGoal = goalmodel//goalButton.titleForState(UIControlState.Normal)!
            }
            // set the goal type button title color based on selection
            goalButton.setTitleColor(goalButton.tag == goalmodel.goalId!.intValue ? UIColor.white : UIColor.darkGray, for: UIControlState())
            
            // set the goal type button background color based on selection
            goalButton.backgroundColor = goalButton.tag == goalmodel.goalId!.intValue ? themeColor : UIColor.clear
            
            goalButton.layer.borderColor = goalButton.tag == goalmodel.goalId!.intValue ? themeColor.cgColor : UIColor.darkGray.cgColor
            
            // get the label below the button
            let goalValueLabel =  goalButton.superview!.subviews.filter() {$0.isKind(of: UILabel.self)} as! [UILabel]
            
            // change the label text color
            goalValueLabel[0].textColor = goalButton.tag == goalmodel.goalId!.intValue ? UIColor.white : UIColor.darkGray
        }
    }
    
    func reloadTheTableViewWithTheSelection(_ goalName: String) {
        
        switch goalName {
            
        case Goal.Maintain.description :
            shouldShowFatLossIntensityLevel = false
            shouldShowBulkingIntensityLevel = false
            isCustomCalorieSelected = false
            currentIndexPath = nil
            tableView.reloadData()
            
        case Goal.FatLoss.description :
            // set the flag to show the intensity level section
            shouldShowFatLossIntensityLevel = true
            shouldShowBulkingIntensityLevel = false
            isCustomCalorieSelected = false
            
//            if FymUserModel.userFatlossIntensityValue == "" {
                FymUserModel.userFatlossIntensityValue = goalOptions[0].goalPercentage!
                FymUserModel.userGoalOptionId = goalOptions[0].goalOptionId!
//            }
            tableView.reloadData()
            
        case Goal.Bulking.description :
            shouldShowFatLossIntensityLevel = false
            shouldShowBulkingIntensityLevel = true
            isCustomCalorieSelected = false
            
//            if FymUserModel.userBulkingIntensityValue == "" {
                FymUserModel.userBulkingIntensityValue = goalOptions[0].goalPercentage!
                FymUserModel.userGoalOptionId = goalOptions[0].goalOptionId!
//            }
            tableView.reloadData()
            
        case Goal.Custom.description :
            shouldShowFatLossIntensityLevel = false
            shouldShowBulkingIntensityLevel = false
            isCustomCalorieSelected = true
            currentIndexPath = nil
            tableView.reloadData()
            
        default :
            break
        }
    }
    
    @IBAction func buttonActionBack(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: false)

    }
    
    @IBAction func unwindToGoalSelectionViewController(_ segue: UIStoryboardSegue) {
        self.navigationController?.isNavigationBarHidden = false

    }
    
}
