//
//  ProgressLogWeightAndFatResponse.swift
//  FlexYourMacros
//
//  Created by mini on 18/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _ProgressLogWeightAndFatResponse = ProgressLogWeightAndFatResponse()

class Stats: NSObject {
    var protein:String?
    var fat:String?
    var carbs:String?
    var fiber:String?
    var calories:String?
    
    class var objectMapping: RKObjectMapping {
        let metaMapping = RKObjectMapping(for: self)
        metaMapping?.addAttributeMappings(from: mappingDictionary)
        return metaMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["protein":"protein", "fat":"fat", "carbs":"carbs", "fiber":"fiber", "diet_goal_calories":"calories"])
    }
}

class ProgressLogWeightAndFatResponse: NSObject {
    
    var meta: MetaModel?
    var stats: Stats?

    class var sharedProgressLogWeightAndFatResponse: ProgressLogWeightAndFatResponse {
        return _ProgressLogWeightAndFatResponse
    }
    
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
//        responseMapping?.addPropertyMapping(ProgressLogWeightAndFatResponse.metaModelKeyMapping)
        responseMapping?.addPropertyMappings(from: [ProgressLogWeightAndFatResponse.metaModelKeyMapping, ProgressLogWeightAndFatResponse.statsmapping])
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.postWeightAndFatUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    fileprivate class var statsmapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: "calculated_values", toKeyPath: "stats", with: Stats.objectMapping)
    }
    
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
 
    //, _ updatedStats:[String:Any]
    class func postWeightandBodyFat(_ date: String, weight: String, bodyFat: String, completionHandler: @escaping (_ successful: Bool, _ updatedStats:Stats) -> ()) {
        
        SVProgressHUD.show()
        RestKitManager.setToken(true)
        
        print("log date = \(date)")//http://api.flexyourmacros.com/weightlog':

        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path: Constants.ServiceConstants.postWeightAndFatUrl, parameters: ["log_date" : date, "log_weight": weight, "log_bodyfat": bodyFat], constructingBodyWith: { (formData) in
            
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            SVProgressHUD.dismiss()
            let logWeightAndFatResponse = mappingResult?.firstObject as! ProgressLogWeightAndFatResponse
            // check for success
            if logWeightAndFatResponse.meta?.responseCode != 200 {
                return;
            }
            completionHandler(true, logWeightAndFatResponse.stats!)
            }) { (operation, error) in
                print("failed to load signup with error \(error)")
        }
        
        RestKitManager.shared().enqueue(operation)
    }
}
