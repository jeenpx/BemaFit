//
//  UpdateUserResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 08/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UpdateUserResponse: NSObject {
   
    var metaModel: MetaModel?
    var user_id: String?
    var update: UpdateModel?
  
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        // give referece to meta model
        responseMapping?.addPropertyMapping(UpdateUserResponse.metaModelKeyMapping)
        responseMapping?.addPropertyMapping(UpdateUserResponse.userSettingModelMapping)
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    
    fileprivate class var userSettingModelMapping :RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUpdateInfo, toKeyPath: "update", with: UpdateModel.objectMapping)
    }
    
    
    class var userResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: RKRequestMethod.POST, pathPattern: Constants.ServiceConstants.userUpdateInfoUrl ,keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    
    class func updateUserInfo(_ params: [String:String],completionHandler: @escaping (_ updateResponse:UpdateUserResponse) -> ()) {
          SVProgressHUD.show()
        RestKitManager.setToken(true)
        //print("headers are  \(RKObjectManager.sharedManager().defaultHeaders)");
        let updateUserResponse = UpdateUserResponse()
        updateUserResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
             
      /*  var parameterDictionary: [String:String] = ["first_name":first_name,"last_name":last_name,"email":email,"website":website,"gender":gender,"dob":dob,"height":height,"type":ptype]
        */
        
        var parameterDictionary = params
//       let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: updateUserResponse, method: RKRequestMethod.POST, path: nil, parameters: parameterDictionary, constructingBodyWith: {
//        ((formData: AFMultipartFormData?) -> Void)! in
//        
//      
//        })
        
        let request : NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with:updateUserResponse, method:RKRequestMethod.POST, path:nil, parameters:parameterDictionary) { (formData) in
            
        }
 
//        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) -> Void in
        
        let operation:RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with:(request as URLRequest),success: {
            (operation, mappingResult) in
            
            let response = mappingResult?.firstObject as! UpdateUserResponse
            //print("respone code :\(response.metaModel?.responseCode)")
            //print("respone status :\(response.metaModel?.responseStatus)")
          
           // check for success
            if response.metaModel?.responseCode == 200 {
                completionHandler(response)               
            } else if response.metaModel?.responseCode == 422{
                completionHandler(response)
               
            } else if response.metaModel?.responseCode == 404 {
                completionHandler(response)
               
                
            } else if response.metaModel?.responseCode == 423 {
                completionHandler(response)
            }
            else  {
                return
            }
            SVProgressHUD.dismiss()
            
        }) { (operation, error) in
            
            SVProgressHUD.dismiss()
        }
        
        RestKitManager.shared().enqueue(operation)
        
    }

    

}
