//
//  DailyMealPlanFoodDeleteResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 12/11/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class DailyMealPlanFoodDeleteResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var dailyMealPlanId: String?
    var foodId: String?
    
    // daily meal plan food delete response mapping
    class var dailyMealPlanFoodDeleteResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(DailyMealPlanFoodDeleteResponse.metaModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: dailyMealPlanFoodDeleteResponseMapping, method: .DELETE, pathPattern: Constants.ServiceConstants.kDailyMealPlanFoodDeleteUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func deleteDailyMealPlanFood(_ dailyMealPlanId: String, foodId: String, completionHandler: @escaping (_ responseStatus: String) -> ()) {
        // delete the message thread
        
        // set access token
        RestKitManager.setToken(true)
        
        let dailyMealPlanFoodDeleteResponse = DailyMealPlanFoodDeleteResponse()
        dailyMealPlanFoodDeleteResponse.dailyMealPlanId = dailyMealPlanId
        dailyMealPlanFoodDeleteResponse.foodId = foodId
        
        RestKitManager.shared().delete(dailyMealPlanFoodDeleteResponse, path: nil, parameters: nil, success: { (operation, mappingResult) in
            
            //print("Success")
            let deleteResponseObject = mappingResult?.firstObject as! DailyMealPlanFoodDeleteResponse
            
            if let responseMeta = deleteResponseObject.meta {
                
                // completion handler
                completionHandler(responseMeta.responseStatus!)
            }
            
            }) { (operation, error) in
                //print("error \(error)");
        }
        
    }
}
