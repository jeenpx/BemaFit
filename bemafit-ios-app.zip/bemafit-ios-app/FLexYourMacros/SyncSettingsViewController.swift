//
//  SyncSettingsViewController.swift
//  FlexYourMacros
//
//  Created by Vineeth Edwin on 10/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

// custom section header cell
class HeaderViewCell: UITableViewCell {
 
    @IBOutlet weak var labelHeaderTitle: UILabel!
    
}


//  sync settingsviewcontroller
class SyncSettingsViewController: UITableViewController , AutoSyncTableViewCellDelegate , UIAlertViewDelegate {
    
    // cell identifiers
    let kAutoSynIdentifier = "kAutoSynCell"
    let kHeaderViewCell = "kHeaderViewCell"
    
    @IBOutlet var tableViewSynSettings: UITableView!
    var feedArray: [SettingsModel] = []
    var socialArray: [SettingsModel] = []
    
    var parameters: Array<Dictionary<String, String>> = []
    
    var alert1: UIAlertView?
    
    var alert2: UIAlertView?

    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlertConfirmation(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        GetUserSettingResponse.userSettingsRequest({ (userSettingsResponse) -> () in
            if let set = userSettingsResponse.settings as [SettingsModel]? {
                for obj:SettingsModel in set {
                    if obj.type! == "Social"{
                        self.socialArray.append(obj)
                        
                    } else if obj.type! == "Feed"{
                        self.feedArray.append(obj)
                        
                    }
                }
                
                self.tableViewSynSettings.reloadData()
                
            }
            
        })
        
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        //print("section = \(section)")
        //print("feedArray = \(feedArray)")
        //print("socialArray = \(socialArray)")
        if section == 0 {
            return self.feedArray.count
        }else {
            return self.socialArray.count
        }
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: kAutoSynIdentifier) as! AutoSyncTableViewCell
        cell.delegate = self
        // XXX configure cell here
        if indexPath.section == 0 {
            
            cell.settings = feedArray[indexPath.row]
            
        } else {
            
            cell.settings = socialArray[indexPath.row]
            
        }
        
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 45.0
    }
    
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: kHeaderViewCell) as! HeaderViewCell
        if section == 0 {
            cell.labelHeaderTitle.text = &&"Post_on_Newsfeed"
        }else {
            cell.labelHeaderTitle.text = "POSTS"
            
        }
        
        return cell
    }
    
    
    func settingsSelected(_ settingsId: String, status: String) {
        var e = ["setting_id":settingsId,"status":status]
        
        var flag=0
        for i in 0..<parameters.count
        {
            if(parameters[i]["setting_id"]==e["setting_id"]) {
                parameters[i]["status"] = e["status"]
                flag=1
                
            } else if (parameters[i]["setting_id"] != e["setting_id"]){
                
                //print("not available")
                
            }
            
        }
        
        if flag==0 {
            parameters.append(e)
        }
        
    }
    @IBAction func buttonActionBackClicked(_ sender: UIBarButtonItem) {
        
        if parameters.count == 0 {
            self.navigationController?.popViewController(animated: true)
            return
        }
        showAlert(&&"notice", message: &&"save_the_changes_in_the_settings_message")
       
    }
    
    func showAlertConfirmation(_ title: String, message: String) {
        // configure alert
        // show alert controller if possible else show alert view
        if #available(iOS 8.0, *) {
                let alert = UIAlertController(title: title, message: message , preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
                self.present(alert, animated: true, completion: nil)
                

            } else {
                // Fallback on earlier versions
                alert2 = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok")
                alert2?.show()
            }
        
      
    }
    
    func showAlert(_ title: String, message: String) {
        // configure alert
        // show alert controller if possible else show alert view
        // configure alert
            if #available(iOS 8.0, *) {
                let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .default,  handler: { action in
                    
                    UpdateUserSettingsResponse.updateUserSettings(self.parameters,completionHandler: { (updateUserSettingsResponse) -> () in
                        self.navigationController?.popViewController(animated: true)
                    })
                    
                }))
                
                alert.addAction(UIAlertAction(title: &&"cancel", style: .cancel,  handler: { action in
                    
                    self.navigationController?.popViewController(animated: true)
                    
                }))
                // show alert
                present(alert, animated: true, completion: nil)

            } else {
                // Fallback on earlier versions
                alert1 = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"cancel", otherButtonTitles: &&"ok")
                alert1?.show()
            }
            
        
    }
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        
        if alertView == alert1 {
            if buttonIndex == 0 {
                // cancel button
                self.navigationController?.popViewController(animated: true)
                
            } else {
                
                UpdateUserSettingsResponse.updateUserSettings(self.parameters,completionHandler: { (updateUserSettingsResponse) -> () in
                    self.navigationController?.popViewController(animated: true)
                })
            }
        } else if alertView == alert2 {
            
        }
    }
    
    
  }
