//
//  AdsResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 24/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class AdsResponse: NSObject {
    
    var metaModel: MetaModel?
    var adsModel: [Advertisement]?
    
    class var getAdsResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        // give referece to meta model
        responseMapping?.addPropertyMapping(AdsResponse.metaModelKeyMapping)
        
        // give reference to user credential mapping
        responseMapping?.addPropertyMapping(AdsResponse.userDetailModelKeyMapping)
        
        return responseMapping!
    }
    
    class var userResponseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: getAdsResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.adsUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var userDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathAds, toKeyPath: "adsModel", with: Advertisement.objectMapping)
    }
    
    
    
    class func getAvailableAds(_ params: Dictionary<String, Any> , completionHandler: @escaping (_ getAds:AdsResponse) -> ()) {
        
        var params: Dictionary<String, Any>  = params
      //alaska  30.40578	-87.58638
        
      //  params["latitude"] = location?.coordinate.latitude
       // params["longitude"] = location?.coordinate.longitude
        
        
        //retrieve coordinates
        let location = GeolocationServiceUpdater.getLastKnowLocation() as CLLocation
        
        //setting the coordinates to params for the api 
        // NOTE : requested to send latitutude and longitude params as 1 if the gps locations is 0 or not available
        
        params["latitude"] = location.coordinate.latitude == 0 ? 1 : location.coordinate.latitude
        params["longitude"] = location.coordinate.longitude == 0 ? 1 : location.coordinate.longitude
        
        
        RestKitManager.setToken(true)
        
        //api call for the ads
        RestKitManager.shared().getObject(nil, path:Constants.ServiceConstants.adsUrl, parameters: params, success: { (operation, mappingResult) in
            let getAdsResponse = mappingResult?.firstObject as! AdsResponse
            //print("respone code :\(getAdsResponse.metaModel?.responseCode)")
            //print("respone status :\(getAdsResponse.metaModel?.responseStatus)")
            completionHandler(getAdsResponse)
            
            
            }) { (operation, error) in
                
                //print("failed to load masterdata with error \(error)")
        }
        
        
    }

    
   
}
