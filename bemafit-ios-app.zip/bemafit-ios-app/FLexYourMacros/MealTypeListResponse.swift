//
//  MealTypeListResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 02/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class MealTypeListResponse: NSObject {
    
    var meta = MetaModel()
    var mealTypes = [MealType]()
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
        responseMapping?.addPropertyMapping(metaModelMapping)
        
        // foods mapping
        let mealTypeModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMealType, toKeyPath: "mealTypes", with: MealType.objectMapping)
        responseMapping?.addPropertyMapping(mealTypeModelMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let mealTypeListResponseDescriptor = RKResponseDescriptor(mapping: MealTypeListResponse.responseMapping, method: .any, pathPattern: Constants.ServiceConstants.kMealTypeListUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return mealTypeListResponseDescriptor!
    }
    
    class func fetchMealTypeList(_ completionHandler: @escaping (_ mealTypes: [MealType]) -> ()) {
        
        RestKitManager.setToken(true)
        let param = ["locale" : "\((Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)!)"]
        RestKitManager.shared().getObjectsAtPath(Constants.ServiceConstants.kMealTypeListUrl, parameters: param, success: { (operation, mappingResult) in
            
            // map to correct datamodel
            let response = mappingResult?.firstObject as! MealTypeListResponse
            
            // fire completion handler
            completionHandler(response.mealTypes)
            
            }) { (operation, error) -> Void in
                // error
                //print("XXX failed to load meal type list with error \(error)")
        }
    }
}
