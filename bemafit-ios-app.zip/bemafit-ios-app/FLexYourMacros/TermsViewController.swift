//
//  TermsViewController.swift
//  FlexYourMacros
//
//  Created by DBG on 13/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class TermsViewController: UIViewController, UIWebViewDelegate , UIAlertViewDelegate {
    
    
    @IBOutlet weak var webViewTermsAndPolicies: UIWebView!

    var alert1: UIAlertView?
    var urlString:String = "http://bemafit.com/terms.html"//"http://jcdesignstest.com/bemafit/terms.html"
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //      self.title = "Hello"
        
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        let request = URLRequest(url: URL(string: urlString)!)
        
        // loading the url on webView
        webViewTermsAndPolicies.loadRequest(request)
    }
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        
        SVProgressHUD.show()
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        
        SVProgressHUD.dismiss()
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        
        SVProgressHUD.dismiss()
    }
    
    @IBAction func buttonActionBack(_ sender: UIBarButtonItem) {
        
        // checks if the settings needed to be updated
        _ = self.navigationController?.popViewController(animated: true)
        
    }
    
    class func openAdsInEmbedBrowser(_ fromViewcontroller:UINavigationController?, withUrl urlString:String) -> () {
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let adViewController = storyBoard.instantiateViewController(withIdentifier: "embededBrowser") as! TermsViewController
        adViewController.title = &&"advertisment"
        adViewController.urlString = urlString
        fromViewcontroller!.pushViewController(adViewController, animated: true)
        
    }
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        
        if alertView == alert1 {
           
        }
    }
    
    func showAlert(_ title: String, message: String) {
        // show alert controller if possible else show alert view
            if #available(iOS 8.0, *) {
                let alert = UIAlertController(title:title, message: message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .default) { action -> Void in
                    
                    })
                
                // show alert
                present(alert, animated: true, completion: nil)
            } else {
                // Fallback on earlier versions
                alert1 =  UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok")
                alert1?.show()

            }
        
    }
    
    
}
