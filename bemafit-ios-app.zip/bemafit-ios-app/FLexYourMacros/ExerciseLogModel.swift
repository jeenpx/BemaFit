//
//  ExerciseLogModel.swift
//  FlexYourMacros
//
//  Created by mini on 29/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class UserExercise: JsonSerializer  {
    
    var user_id = ""
    var exercise_details : Array<LogExercise>
    
    init(userID: String, exerciseDetails: Array<LogExercise>) {
        self.user_id = userID
        self.exercise_details = exerciseDetails
    }
}

class LogExercise: JsonSerializer {
    
    var exercise_id = ""
    var exercise_name = ""
    var exercise_time = ""
    var exercise_calorie_burned = ""
    var exercise_unit = "g"
    var exercise_distance = ""
    var exercise_sets = ""
    var exercise_sets_reps = ""
    var exercise_weight_per_set = ""
    var source_id = -1
    
    init(strengthExercise: StrengthExercise) {
        exercise_id = strengthExercise.exerciseId
        exercise_name = strengthExercise.name
        exercise_time = strengthExercise.exerciseAmount.stringValue
        exercise_calorie_burned = strengthExercise.caloriesBurned.stringValue
        exercise_sets = strengthExercise.sets.stringValue
        exercise_sets_reps = strengthExercise.reps.stringValue
        exercise_weight_per_set = strengthExercise.weight.stringValue
        source_id = strengthExercise.source_id
    }
    
    init(cardioVascularExercise: CardioVascularExercise) {
        exercise_id = cardioVascularExercise.exerciseId
        exercise_name = cardioVascularExercise.name
        exercise_time = cardioVascularExercise.exerciseAmount.stringValue
        exercise_calorie_burned = cardioVascularExercise.caloriesBurned.stringValue
        exercise_distance = cardioVascularExercise.distance.stringValue
        source_id = cardioVascularExercise.source_id
    }
}

class ExerciseLogModel: JsonSerializer {
    
    var log_type = "Log"
    var exercise_type = ""
    var exercise_date = ""
    var source_id = -1
    var users : Array<UserExercise>
    
    init(logType: String, exerciseType: String, exerciseDate: String, source_id:Int) {
        
        self.log_type = logType
        self.exercise_type = exerciseType
        self.exercise_date = exerciseDate
        self.source_id = source_id
        self.users =  Array<UserExercise>()
        
    }
    
    //log the exercise
    class func logExercise(_ exerciseLogModel: ExerciseLogModel, completionHandler: @escaping (_ successful: Bool, _ messsage: String) -> ()) {
        
        ExerciseLogResponse.logExercise(exerciseLogModel, completionHandler: { (successful, message) -> () in
            completionHandler(successful, message)
        })
    }
    
    //log the exercise
    class func sendExercise(_ exerciseLogModel: ExerciseLogModel, completionHandler: @escaping (_ successful: Bool, _ messsage: String) -> ()) {
        
        ExerciseLogResponse.logExercise(exerciseLogModel, completionHandler: { (successful, message) -> () in
            completionHandler(successful, message)
        })
    }

}
