//
//  DailyMealPlanCreateResponse.swift
//  FlexYourMacros
//
//  Created by Minimol BI on 09/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import UIKit

class DailyMealPlanCreateResponse: NSObject {
    
    var meta: MetaModel?
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
        responseMapping?.addPropertyMapping(metaModelMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let dailyMealPlanCreateResponseDescriptor = RKResponseDescriptor(mapping: DailyMealPlanCreateResponse.responseMapping, method: .POST, pathPattern: Constants.ServiceConstants.kDailyMealPlan, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return dailyMealPlanCreateResponseDescriptor!
    }
    
    class func logDailyMealPlan(_ params: [String: Any], completionHandler: @escaping (_ error: NSError?) -> ()) {
        
        SVProgressHUD.show()
        
        RestKitManager.setToken(true)
        
        // create a post request
        let request = RestKitManager.shared().request(with: nil, method: .POST, path: Constants.ServiceConstants.kDailyMealPlan, parameters: nil)
        
        // set params as body
        request?.httpBody = try? JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
        
        // create an operation with the request
        let operation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let dailyMealPlanCreateResponse = mappingResult?.firstObject as! DailyMealPlanCreateResponse
            
            // check for success
            if dailyMealPlanCreateResponse.meta?.responseCode != 200 {
                
                SVProgressHUD.dismiss()
                
                // configure alert message
                let message = "alert_log_daily_meal_plan_message"
                

                completionHandler(NSError(domain: "FYM.DailyMealPlan", code: 99, userInfo: ["title": "error", "message": message]))
            }
            else {
                SVProgressHUD.dismiss()
                completionHandler(nil)
            }
            }) { (operation, error) in
                //print("XXX failed to log food with error \(error)")
                SVProgressHUD.dismiss()
                completionHandler(NSError(domain: "FYM.DailyMealPlan", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"]))
        }
        
        // enque request operation
        RestKitManager.shared().enqueue(operation)
    }
}
