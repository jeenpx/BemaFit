//
//  DeletFoodLogResponse.swift
//  FlexYourMacros
//
//  Created by mini on 10/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class DeletFoodLogResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var foodlog_id: String?
    
    // message delete response mapping
    class var deletFoodLogResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(DeletFoodLogResponse.metaModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: deletFoodLogResponseMapping, method: .DELETE, pathPattern: Constants.ServiceConstants.kUrlFood, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func deleteFood(_ foodId: String, completionHandler: @escaping (_ deletedStatus: Bool) -> ()) {
        // delete the food
        
        // set access token
        RestKitManager.setToken(true)
        
        let deletFoodLogResponse = DeletFoodLogResponse()
        deletFoodLogResponse.foodlog_id = foodId
        
        RestKitManager.shared().delete(deletFoodLogResponse, path: nil, parameters: nil, success: { (operation, mappingResult) in
            
            //print("Success")
            let deleteResponseObject = mappingResult?.firstObject as! DeletFoodLogResponse
            if deleteResponseObject.meta != nil {
                // completion handler
                completionHandler(true)
            }
            }) { (operation, error) in
                //print("error \(error)");
                completionHandler(false)
        }
        
    }
}
