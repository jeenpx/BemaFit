//
//  DataTableViewCell.swift
//  FlexYourMacros
//
//  Created by DBG on 17/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class DataTableViewCell: UITableViewCell {

    var progressType: ProgressType = ProgressType.Weight
    var exerciseType: String = ExerciseCategory.CardioVascular.rawValue {
        didSet {
            
            if exerciseType == ExerciseCategory.CardioVascular.rawValue {
                
                self.labelValue.text = exerciseTime(progressReport!.amount.doubleValue)//amount.roundedString() + " " + &&"minutes"

            } else if exerciseType == ExerciseCategory.Strength.rawValue{
                
                var calorie:Double = progressReport!.calorie.doubleValue
                
                self.labelValue.text = calorie.roundedString() + " " + &&"_calories"
            }
        }
    }
    
    func exerciseTime(_ totalSeconds: Double) -> String {
        
        let seconds = totalSeconds.truncatingRemainder(dividingBy: 60);
        let totalMinutes = totalSeconds / 60;
        let minutes = totalMinutes.truncatingRemainder(dividingBy: 60);
        let hours = totalMinutes / 60;
        let dateString = NSString(format: "%02dh %02dm %02ds", Int(hours), Int(minutes), Int(seconds)) //formatter.stringFromDate(date)
        return dateString as String
    }
    
    @IBOutlet weak var labelDate: UILabel!
    @IBOutlet weak var labelValue: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    var progressReport: ProgressReport? {
        
        didSet {
            
            let logDate = progressReport?.log_date.dateValue("yyyy-MM-dd")
            let logDateString = logDate?.stringValue("MMMM dd, yyyy")
            
            self.labelDate.text = logDateString
            
            if progressType == ProgressType.Weight {
            self.labelValue.text = progressReport!.weight + " " + &&"lbs"
                
            }else if progressType == ProgressType.Bodyfat {
            self.labelValue.text = progressReport!.bodyfat + " %"

            }else if progressType == ProgressType.Exercise {
                exerciseType = progressReport!.exercise_type
            }
        }
    }
    
    
    
    
}
