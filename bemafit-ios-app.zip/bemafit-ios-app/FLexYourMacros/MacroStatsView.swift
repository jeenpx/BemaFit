//
//  MacroStatsView.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 23/02/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol MacroStatsViewDelegate {
    func infoButtonClicked(_ macroStatsView: MacroStatsView)
}

class MacroStatsView: UIView {
    
    // macro stats view delegate
    var macroStatsViewDelegate: MacroStatsViewDelegate?
    
    var macroDetails: MacroModel = MacroModel() {
        didSet {
            labelCalories.text = "\(macroLeftOvers().caloriesLeft) of \(macroDetails.caloriesTotal.singleDecimalValue)"
            labelProtein.text = "\(macroLeftOvers().proteinsLeft)g of \(macroDetails.proteinTotal.singleDecimalValue)g"
            labelFats.text = "\(macroLeftOvers().fatsLeft)g of \(macroDetails.fatTotal.singleDecimalValue)g"
            labelCarbs.text = "\(macroLeftOvers().carbsLeft)g of \(macroDetails.carbsTotal.singleDecimalValue)g"
            labelFiber.text = "\(macroLeftOvers().fiberLeft)g of \(macroDetails.fiberTotal.singleDecimalValue)g"
        }
    }

    func macroLeftOvers() -> (caloriesLeft: String, proteinsLeft: String, fatsLeft: String, carbsLeft: String, fiberLeft: String) {
    
        let caloriesLeft = macroDetails.caloriesTotal.doubleValue - macroDetails.calorieAchived.doubleValue
        
        let proteinLeft = macroDetails.proteinTotal.doubleValue - macroDetails.proteinAchived.doubleValue
        
        let fatLeft = macroDetails.fatTotal.doubleValue - macroDetails.fatAchived.doubleValue
        
        let carbLeft = macroDetails.carbsTotal.doubleValue - macroDetails.carbAchived.doubleValue
        
        let fiberLeft = macroDetails.fiberTotal.doubleValue - macroDetails.fiberAchived.doubleValue
        
        return (caloriesLeft.stringValue.singleDecimalValue, proteinLeft.stringValue.singleDecimalValue, fatLeft.stringValue.singleDecimalValue, carbLeft.stringValue.singleDecimalValue, fiberLeft.stringValue.singleDecimalValue)
    }
    
    // macro labels
    @IBOutlet fileprivate weak var labelCalories: UILabel!
    @IBOutlet fileprivate weak var labelProtein: UILabel!
    @IBOutlet fileprivate weak var labelCarbs: UILabel!
    @IBOutlet fileprivate weak var labelFats: UILabel!
    @IBOutlet fileprivate weak var labelFiber: UILabel!
    
    @IBAction fileprivate func infoButtonClicked(_ sender: UIButton) {
        macroStatsViewDelegate?.infoButtonClicked(self)
    }
}
