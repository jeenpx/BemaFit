//
//  MessageFriendsCell.swift
//  FlexYourMacros
//
//  Created by dbgattila on 3/31/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol UserProfileDelegate {
    func userProfile(_ userId: String)
}

class MessageFriendsCell: UITableViewCell {
    
    @IBOutlet weak var imageViewProfilePic: UIImageView!
    @IBOutlet weak var labelUserName: UILabel!
    @IBOutlet weak var labelName: UILabel!
    
    var userProfileDelegate: UserProfileDelegate?
    
    // set value for ui elements
    var friend: FriendModel? {
        didSet {
            labelName.text = friend!.firstName! + " " + friend!.lastName!
            labelUserName.text = friend!.userName
            imageViewProfilePic.setImageWith(URL(string: friend!.profilePhoto!), placeholderImage: UIImage(named: "PlaceHolderProfilePic"))
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        // to configure the view
        configureView()
    }
    
    func configureView() {
        labelUserName.isUserInteractionEnabled = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(MessageFriendsCell.didTaplabelUserNameWithGesture(_:)))
        tapGesture.delegate = self
        
        // add tap gesture to the username label
        labelUserName.addGestureRecognizer(tapGesture)
        
    }
    
    func didTaplabelUserNameWithGesture(_ tapGesture: UITapGestureRecognizer) {
        //print("didTaplabelUserNameWithGesture entered...")
        userProfileDelegate?.userProfile(friend!.user_id!)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    
}
