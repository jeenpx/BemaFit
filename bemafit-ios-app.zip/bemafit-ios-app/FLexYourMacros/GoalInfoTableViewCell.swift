//
//  GoalInfoTableViewCell.swift
//  FlexYourMacros
//
//  Created by DBG on 17/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class GoalInfoTableViewCell: UITableViewCell {

    @IBOutlet weak var labelStart: UILabel!
    @IBOutlet weak var labelCurrent: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    var exerciseType: ExerciseCategory = ExerciseCategory.CardioVascular
    // set the progress type
    var progressType: ProgressType = ProgressType.Weight {
        didSet {
            
            ProgressFirstLog.fetchProgressFirstLogDetails(progressType.description, completionHandler: { (firstLogDetails) -> () in
                
                let progressArray = firstLogDetails as! [ProgressFirstLog];

                if progressArray.count == 0 {
                    return
                }
                
                let sortedArray = progressArray.sorted {$0.log_date > $1.log_date}

                let startLog = sortedArray.first
                
                if self.progressType == ProgressType.Weight || self.exerciseType == ExerciseCategory.Strength {
                    self.labelStart.text = startLog!.weight+" lbs"

                } else if self.progressType == ProgressType.Bodyfat {
                    self.labelStart.text = startLog!.body_fat+"%"

                } else if self.progressType == ProgressType.Exercise && self.exerciseType == ExerciseCategory.CardioVascular {
                    
//                    let logMinutes = startLog!.amount.doubleValue / 60.0
                    self.labelStart.text = self.exerciseTime(startLog!.amount.doubleValue)//"\(logMinutes.roundPlaces())" + " " + &&"minutes"
                }
            })
            
            ProgressLastLog.fetchProgressLastLogDetails(progressType.description, completionHandler: { (lastLogDetails) -> () in
                
                let progressArray = lastLogDetails as! [ProgressLastLog];
                
                if progressArray.isEmpty {
                    return
                }
                
                let sortedArray = progressArray.sorted {$0.log_date > $1.log_date}

                let currentLog = sortedArray.first
                
                if self.progressType == ProgressType.Weight || self.exerciseType == ExerciseCategory.Strength {
                    self.labelCurrent.text = currentLog!.weight+" lbs"
                    
                } else if self.progressType == ProgressType.Bodyfat {
                    self.labelCurrent.text = currentLog!.body_fat+"%"
                    
                } else if self.progressType == ProgressType.Exercise && self.exerciseType == ExerciseCategory.CardioVascular {

//                    let logMinutes = exerciseTime(currentLog!.amount.doubleValue)//currentLog!.amount.doubleValue / 60.0

                    self.labelCurrent.text = self.exerciseTime(currentLog!.amount.doubleValue)//"\(logMinutes.roundPlaces())" + " " + &&"minutes"

                }
            })
        }
    }
    
    func exerciseTime(_ totalSeconds: Double) -> String {
        
        let seconds = totalSeconds.truncatingRemainder(dividingBy: 60);
        let totalMinutes = totalSeconds / 60;
        let minutes = totalMinutes.truncatingRemainder(dividingBy: 60);
        let hours = totalMinutes / 60;
        let dateString = NSString(format: "%02dh %02dm %02ds", Int(hours), Int(minutes), Int(seconds)) //formatter.stringFromDate(date)
        return dateString as String
    }
}
