//
//  GetFollowingFollowerUserResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 02/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

// Get the response of the following /follower users
class GetFollowingFollowerUserResponse: NSObject {
   
    var user_list: [UserDetailModel]?
    var metaModel: MetaModel?
    var totalUsers: String?
    var userId: String?
    
    class var getUserResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        // give referece to meta model
        responseMapping?.addPropertyMapping(GetFollowingFollowerUserResponse.metaModelKeyMapping)
        
        // give reference to user credential mapping
        responseMapping?.addPropertyMapping(GetFollowingFollowerUserResponse.userDetailModelKeyMapping)
        
        responseMapping?.addAttributeMappings(from: mappingDictionary)
        
        return responseMapping!
    }
    
    class var userResponseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: getUserResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.followingfollowerUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var userDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathFollowingFollower, toKeyPath: "user_list", with: UserDetailModel.objectMapping)
    }
    
    class var mappingDictionary: [String : String] {
        return(["total_users":"totalUsers"])
    }
    

    
    
    class func getUsersList(_ userId: String, offset: Int,type: String ,andLimit limit: Int, keywords: String, completionHandler: @escaping (_ followerfollowingresponse:GetFollowingFollowerUserResponse) -> ()) {
        SVProgressHUD.show()

        RestKitManager.setToken(true)
        let userResponse = GetFollowingFollowerUserResponse()
      //  userResponse.userId = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
         userResponse.userId = userId
        
        // input parameters
        let params: Dictionary<String, Any>  = ["type":type as Any,"offset": offset as Any, "limit": limit as Any ]
        
        
        // get the objects from the path login
//        RestKitManager.shared().getObject(userResponse, path:nil, parameters: params, success: { (operation, mappingResult) in
//            let userListResponse = mappingResult.firstObject as! GetFollowingFollowerUserResponse
//            
//            //print("respone code :\(userListResponse.metaModel?.responseCode)")
//            //print("respone status :\(userListResponse.metaModel?.responseStatus)")
//            //print("respone  :\(userListResponse.user_list?.count)")
//            SVProgressHUD.dismiss()
//
//            completionHandler(followerfollowingresponse: userListResponse)
//            
//            
//            }) { (operation, error) in
//                SVProgressHUD.dismiss()
//
//                //print("failed to load follow with error \(error)")
//        })
        
        RestKitManager.shared().getObject(userResponse, path:nil, parameters:params, success:{ (operation, mappingResult) in
            let userListResponse = mappingResult?.firstObject as! GetFollowingFollowerUserResponse
            SVProgressHUD.dismiss()
            completionHandler(userListResponse)
        }) { (operation, error) in
            SVProgressHUD.dismiss()
        }
        
        
    }
    
    
    
}
