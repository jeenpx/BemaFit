//
//  FacebookUserLogIn.swift
//  FlexYourMacros
//
//  Created by mini on 24/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//
import Foundation

private let _FacebookUserLogInResponse = FacebookUserLogInResponse()

class FacebookUserLogInResponse: NSObject {
    
    var accessTokenModel: AccessTokenModel?
    var userDietModel: UserDietModel?
    var userDetailModel: UserDetailModel?
    var metaModel: MetaModel?
    
    class var sharedFacebookUserLogInResponse: FacebookUserLogInResponse {
        return _FacebookUserLogInResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(FacebookUserLogInResponse.metaModelKeyMapping)
        
        // give reference to accesstoken mapping
        responseMapping?.addPropertyMapping(FacebookUserLogInResponse.accessTokenModelKeyMapping)
        
        // give reference to diet mapping
        responseMapping?.addPropertyMapping(FacebookUserLogInResponse.userDietModelKeyMapping)
        
        // give reference to user credential mapping
        responseMapping?.addPropertyMapping(FacebookUserLogInResponse.userDetailModelKeyMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.logInFacebookUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var accessTokenModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathAccessToken, toKeyPath: "accessTokenModel", with: AccessTokenModel.objectMapping)
    }
    
    fileprivate class var userDietModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDiet, toKeyPath: "userDietModel", with: UserDietModel.objectMapping)
    }
    
    fileprivate class var userDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDetail, toKeyPath: "userDetailModel", with: UserDetailModel.objectMapping)
    }
    
    
    
    class func logInFacebookUser(_ viewController: UIViewController, facebookAccessToken: String, completionHandler: @escaping (_ accessCredential: AccessTokenModel, _ userDiet: UserDietModel, _ userDetails: UserDetailModel) -> (), failedWithError: @escaping (_ error: String) -> ()) {
        
        // add loading indicator
        SVProgressHUD.show()

        RestKitManager.setupBasicAuth()
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["facebook_access_token":facebookAccessToken, "grant_type":"password"]
        }
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path: Constants.ServiceConstants.logInFacebookUrl, parameters: parameterDictionary, constructingBodyWith: { (formData) in
            
        })
        
        let userDefaults = UserDefaults.standard
        
        let deviceAccessToken = userDefaults.object(forKey: "token") as? String ?? ""
        
        RKObjectManager.shared().httpClient.setDefaultHeader("Device-Token", value: deviceAccessToken)
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            // remove loading indicator
//            MBProgressHUD.hideHUDForView(viewController.view, animated: true)
            SVProgressHUD.dismiss()

            let userLogInResponse = mappingResult?.firstObject as! FacebookUserLogInResponse
            
            // check for success
            if userLogInResponse.metaModel?.responseCode != 200 {
                
                var errorMessage = userLogInResponse.metaModel?.message ?? ""
                let errorMessages = userLogInResponse.metaModel?.errormessages
                if errorMessages!.isEmpty {
                    
                } else {
                    
                    errorMessage = errorMessages?.first?.fieldMessage ?? ""
                }
                failedWithError(errorMessage)
                return
            }
            // set up the completion handler with response
            completionHandler(userLogInResponse.accessTokenModel!, userLogInResponse.userDietModel!, userLogInResponse.userDetailModel!)
            //print("accessTokenModel in \(userLogInResponse.accessTokenModel?.accessToken)"
            }) { (operation, error) in
                // remove loading indicator
//                MBProgressHUD.hideHUDForView(viewController.view, animated: true)
                SVProgressHUD.dismiss()
                failedWithError((error?.localizedDescription)!)
                //print("failed to load user verification with error \(error)")
        }
        RestKitManager.shared().enqueue(operation)
    }
    
    
}
