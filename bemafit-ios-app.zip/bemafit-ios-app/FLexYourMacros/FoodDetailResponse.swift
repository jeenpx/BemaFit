//
//  FoodDetailResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 09/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FoodDetailResponse: NSObject {
    
    var metaModel = MetaModel()
    var food = FoodListModel()
    var barcode = ""
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
        responseMapping?.addPropertyMapping(metaModelMapping)
        
        // foods mapping
        let foodModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathFood, toKeyPath: "food", with: FoodListModel.objectMapping)
        responseMapping?.addPropertyMapping(foodModelMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let foodDetailResponseDescriptor = RKResponseDescriptor(mapping: FoodDetailResponse.responseMapping, method: .any, pathPattern: Constants.ServiceConstants.kFoodDetailUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return foodDetailResponseDescriptor!
    }
    
    class func fetchBarcodeFood(_ barcode: String, completionHandler: @escaping (_ food: Food?, _ error: String?) -> ()) {
        
        RestKitManager.setToken(true)
        
        let foodDetailResponse = FoodDetailResponse()
        foodDetailResponse.barcode = barcode
        
        RestKitManager.shared().getObject(foodDetailResponse, path: nil, parameters: nil, success: { (operation, mappingResult) in
            
            // map to correct datamodel
            let response = mappingResult?.firstObject as! FoodDetailResponse
            
            if response.metaModel.responseCode != 200 {
                
                completionHandler(nil, &&"no_barcode")
                return
            }
            
            // fire completion handler
            completionHandler(Food(foodListModel: response.food), nil)
            
            }) { (operation, error) -> Void in
                // error
               // completionHandler(food: nil, error: error)
        }
    }
}
