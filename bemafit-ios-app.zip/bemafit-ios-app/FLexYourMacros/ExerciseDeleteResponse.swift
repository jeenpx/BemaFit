//
//  ExerciseDeleteResponse.swift
//  FlexYourMacros
//
//  Created by mini on 26/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class ExerciseDeleteResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var exerciselog_id: String?
    
    // message delete response mapping
    class var exerciseDeleteResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(ExerciseDeleteResponse.metaModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: exerciseDeleteResponseMapping, method: .DELETE, pathPattern: Constants.ServiceConstants.kUrlExercise, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func deleteExercise(_ exerciseId: String, completionHandler: @escaping (_ deletedStatus: Bool) -> ()) {
        // delete the exercise
        
        // set access token
        RestKitManager.setToken(true)
        
        let exerciseDeleteResponse = ExerciseDeleteResponse()
        exerciseDeleteResponse.exerciselog_id = exerciseId
        
        RestKitManager.shared().delete(exerciseDeleteResponse, path: nil, parameters: nil, success: { (operation, mappingResult) in
            
            //print("Success")
            let deleteResponseObject = mappingResult?.firstObject as! ExerciseDeleteResponse
            
            if let responseMeta = deleteResponseObject.meta {
                
                // completion handler
                completionHandler(true)
            }
            
        }) { (operation, error) in
            //print("error \(error)");
            completionHandler(false)
        }
        
//        RestKitManager.shared().delete(exerciseDeleteResponse, path: nil, parameters: nil, success: { (operation, mappingResult) in
//            
//            //print("Success")
//            let deleteResponseObject = mappingResult.firstObject as! ExerciseDeleteResponse
//            
//            if let responseMeta = deleteResponseObject.meta {
//                
//                // completion handler
//                completionHandler(deletedStatus: true)
//            }
//            
//            }) { (operation, error) in
//                //print("error \(error)");
//                
//                completionHandler(deletedStatus: false)
//        })
        
    }
}
