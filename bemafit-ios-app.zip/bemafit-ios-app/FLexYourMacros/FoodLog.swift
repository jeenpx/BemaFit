//
//  FoodLog.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 27/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import CoreData
@objc(FoodLog)
class FoodLog: NSManagedObject {


}
