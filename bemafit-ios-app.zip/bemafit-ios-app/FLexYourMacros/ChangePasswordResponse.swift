//
//  ChangePasswordResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 24/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

private let _ChangePasswordResponse = ChangePasswordResponse()

class ChangePasswordResponse: NSObject {
   
    var changePasswordModel: ChangePasswordModel?
    var metaModel: MetaModel?
    var user_id: String?
    
    
    class var sharedUserSignUpResponse: ChangePasswordResponse {
        return _ChangePasswordResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(ChangePasswordResponse.metaModelKeyMapping)
        
        // give reference to changePassword mapping
        responseMapping?.addPropertyMapping(ChangePasswordResponse.changePasswordModelMapping)
        
        return responseMapping!
    }
    
    
    class var userResponseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.changePasswordUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    
    fileprivate class var changePasswordModelMapping :RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathChangePassword, toKeyPath: "changePasswordModel", with: ChangePasswordModel.objectMapping)
    }
    
    
    class func userChangePassword(_ oldPassword:String,newPassword:String,completionHandler: @escaping (_ userChangePasswordResponse:ChangePasswordResponse) -> ()) {
        SVProgressHUD.show()

        RestKitManager.setToken(true)
 
        let changePasswordResponse = ChangePasswordResponse()
        changePasswordResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["old_password":oldPassword, "new_password":newPassword]
        }
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: changePasswordResponse, method: .POST, path: nil, parameters: parameterDictionary, constructingBodyWith: { (formData) in

        })
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let userChangepasswordResonse = mappingResult?.firstObject as! ChangePasswordResponse
            //print("respone code :\(userChangepasswordResonse.metaModel?.responseCode)")
            //print("respone status :\(userChangepasswordResonse.metaModel?.responseStatus)")
            
            // check for success
            if userChangepasswordResonse.metaModel?.responseCode == 200 {
               // success password changed
                completionHandler(userChangepasswordResonse)
                
            } else if userChangepasswordResonse.metaModel?.responseCode == 422{
                // Invalid old password
                completionHandler(userChangepasswordResonse)
                
            } else if userChangepasswordResonse.metaModel?.responseCode == 404 {
                
                 completionHandler(userChangepasswordResonse)
                
                
            } else {
                return
            }
            SVProgressHUD.dismiss()

            }) { (operation, error) in
            SVProgressHUD.dismiss()
            //print("failed to load change password with error \(error)")
        }

        RestKitManager.shared().enqueue(operation)
    }

    
    
    
}





