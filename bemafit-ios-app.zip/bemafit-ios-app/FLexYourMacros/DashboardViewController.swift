//
//  DashboardViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 18/02/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


let kEnableDashboardNotification = "kEnableDashboardNotification"

class DashboardViewController: SLKTextViewController, MacroStatsViewDelegate, DashboardViewLogHeaderViewDelegate, NewsFeedCellDelegate , UITableViewDragLoadDelegate ,AdvertisementCellDelegate, EnlargeImageNewsFeedDelegate {
    
    var offsetValue:Int!
    var friendRequestCount:Int!
    let badgeView = MKNumberBadgeView()
    
    // XXX fetch the hasttags here
    let hashTags = [String]()
    let users = [String]()
    
    // selected hashtag
    var hashTag = ""
    
    // list of news feeds
    var newsFeeds = [NewsFeed]() {
        didSet {
            tableView.reloadData()
        }
    }
    
    var advertisement = Advertisement() {
        didSet {
            tableView.reloadData()
        }
    }
    
    var macroDetails = MacroModel()
    
    // search results which is optional
    fileprivate var searchResults: [String]?
    
    // refresh control
    let refreshControl = UIRefreshControl()
    
    var isGesturePopEnabled = true
    
    var pageMeta = PageMetaModel()
    
    @IBOutlet fileprivate var macroStatsView: MacroStatsView!
    
    @IBOutlet weak var barButtonProgress: UIBarButtonItem!
    @IBOutlet weak var barButtonFriends: UIBarButtonItem!
    @IBOutlet weak var barButtonMessages: UIBarButtonItem!
    @IBOutlet weak var barButtonDirectory: UIBarButtonItem!
    
    @IBOutlet weak var barButtonDailyLog: UIBarButtonItem!
    
    @IBOutlet weak var barButtonMealPlan: UIBarButtonItem!
    
    var messageBadge: Int = 0 {
        didSet {
            barButtonMessages.shouldAnimateBadge = true
            barButtonMessages.shouldHideBadgeAtZero = true
            barButtonMessages.badgeOriginX = 25.0
            barButtonMessages.badgeOriginY = 0
            barButtonMessages.badgeValue = String(messageBadge)
            
        }
    }
    
    // reload confirmation status
    // will be false during image post navigation
    var shouldReload = true
    
    // handle push notification
    var shouldNavigateMessageDetails = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // localize tool bar images
        barButtonProgress.image = UIImage(named: &&"tab_progress")
        barButtonFriends.image = UIImage(named: &&"tab_friends")
        barButtonMessages.image = UIImage(named: &&"tab_messages")
        barButtonMealPlan.image = UIImage(named:&&"tab_mealPlan")
        barButtonDailyLog.image = UIImage(named: &&"tab_dailyLog")
        
        // configure the chat view
        configureView()
        getUserDetails()
        
        // observe for dashboard enable notifications
        NotificationCenter.default.addObserver(self, selector: #selector(DashboardViewController.handleEnableDashboardNotification(_:)), name: NSNotification.Name(rawValue: kEnableDashboardNotification), object: nil)
    }
    
    func getUserDetails() {
        if let userId = AppConfiguration.sharedAppConfiguration.userDetails!.userId {
            
            if userId.isEmpty == false {
                UserProfileresponse.getUserProfileDetails(userId) { (userDiet, user) in

                    AppConfiguration.sharedAppConfiguration.userDetails = user
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //Get all friend requests
        offsetValue = 0
        friendRequestCount = 0
        self.badgeView.removeFromSuperview()
        getFriendsList(offsetValue, limit: 10, searchKeyword: "")
        
        // enable dashboard
        enableDashboard()
        
        // we need a light status bar
        UIApplication.shared.statusBarStyle = .lightContent
        
        // configure toolbar
        configureToolBar()
        
        // configure macro stats view
        configureMacroStatsView()
        
        // fetch news feeds and reload table
        if shouldReload {
            
            // reset page meta data
            pageMeta = PageMetaModel()
            
            NewsFeed.fetchPublicNewsFeeds(pageMeta: pageMeta) { (newsFeeds, pageMeta) -> () in
                self.newsFeeds = newsFeeds
                self.pageMeta = pageMeta
                self.tableView.reloadData()
            }
        }
        else { shouldReload = true }
        
        // fetch advertisement
        Advertisement.latestAdvertisement("Newsfeed") { (advertisement) -> () in
            self.advertisement = advertisement
        }
        
        // get unread messages count
        MessageResponse.getMessages(0, andLimit: 1, andProgressHUD: false) { (messages, unreadCount) -> () in
            
            DispatchQueue.main.async {
                
                if let count = unreadCount {
                    
                    // save unread count
                    self.messageBadge = count.intValue
                    self.barButtonMessages.badgePadding = 5
                    
                }
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        dismissKeyboard(true)
        
        // hide toolbar
        hideToolBar()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // activate sliding gestures
        activateSlidingGesture()
        
        //        self.messageBadge = 20
        
    }
    
    //Get all friends
    func getFriendsList(_ offset:Int,limit:Int,searchKeyword:String){
        
        //  internet check
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
//            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        GetFriendsResponse.getFriendsList(offset, andLimit: limit, keywords:searchKeyword, shouldShowHUD: false
            , completionHandler: { (getFriendsResponse:GetFriendsResponse) -> () in
            let response = getFriendsResponse
            
            
                //if friend request is still not accepted by user then add to badge count.
            if let set  = response.friends as [FriendModel]? {
                for obj in set {
                    if obj.type == "FriendRequest" {
                        self.friendRequestCount = self.friendRequestCount+1
                    }
                    self.offsetValue = self.offsetValue+1
                }
            }
            
            if offset != self.offsetValue {
                self.getFriendsList(self.offsetValue, limit: 10, searchKeyword: "")
            }
            else {//if friend request count is greater than 0 then show the badge.
                if (self.friendRequestCount > 0) {
                    self.badgeView.value = self.friendRequestCount
                    
                    let screenFrame: CGRect = UIScreen.main.bounds;
                    
                    let barview:UIView = self.barButtonFriends.value(forKey: "view") as! UIView
                    
                    if (self.badgeView.superview == nil) {
                        barview.addSubview(self.badgeView)
                    }
                    
                    var width:CGFloat!
                    if((barview) != nil){
                        width=barview.frame.size.width;
                    }
                    else{
                        width=0.0 ;
                    }
                    
                    self.badgeView.frame = CGRect(x: width-20, y: -5, width: 25, height: 25)
                }
            }
            
        })
    }
    
    func handleEnableDashboardNotification(_ sender: Notification) {
        enableDashboard()
    }
    
    func enableDashboard() {
        tableView.isUserInteractionEnabled = true
        textInputbar.isUserInteractionEnabled = true
        dashboardNavigationController?.toolbar.isUserInteractionEnabled = true
    }
    
    fileprivate func configureToolBar() {
        
        // show toolbar
        showToolbar()
    }
    
    fileprivate func configureMacroStatsView() {
        
        // setup macro stats view delegate
        macroStatsView.macroStatsViewDelegate = self
        
        MacroModel.refreshUserMacros(Date(), completionHnadler: { (achievedMacroGoal) -> () in
            self.macroStatsView.macroDetails = achievedMacroGoal
            self.macroDetails = achievedMacroGoal
        })
        
        // update the macrostats view transform
        macroStatsView.transform = tableView.transform
        
        // set macro stats view as the table header
        tableView.tableHeaderView = macroStatsView
    }
    
    func configureView() {
        
        // set basic properties for the view
        // XXX double check this
        bounces = true
        shakeToClearEnabled = true
        isKeyboardPanningEnabled = true
        shouldScrollToBottomAfterKeyboardShows = false
        isInverted = false
        
        // setup tableview
        tableView.backgroundColor = UIColor.defaultGrayColor()
        tableView.separatorStyle = UITableViewCellSeparatorStyle.none
        tableView.register(UINib(nibName: Storyboard.Nibs.NewsFeedCell, bundle: nil), forCellReuseIdentifier: Storyboard.CellIdentifiers.NewsFeedCellIdentifier)
        tableView.register(AdvertisementCell.self, forCellReuseIdentifier: Storyboard.CellIdentifiers.AdvertisementCellIdentifier)
        
        // set estimated row height
        // XXX setting the lowest height now, recheck
        //        tableView.rowHeight = UITableViewAutomaticDimension
        
        // setup refresh control
        refreshControl.addTarget(self, action: #selector(DashboardViewController.pullToRefresh(_:)), for: UIControlEvents.valueChanged)
        refreshControl.tintColor = UIColor.gray
        
        // add refresh control to the tableview
        tableView.addSubview(refreshControl)
        
        // set delegate for pull to refresh and load more
        tableView.setDragDelegate(self, refreshDatePermanentKey: "nil")
        
        // hide pull to refresh
        tableView.showRefreshView = false
        
        // show load more
        tableView.showLoadMoreView = true
        
        // tableview footer release text
        tableView.footerReleaseText = &&"release_to_load_more_status"
        
        // tableview footer pull up text
        tableView.footerPullUpText = &&"pull_down_to_load_more_status"
        
        //tableview footer loading text
        tableView.footerLoadingText = &&"loading_status"
        
        // setup textview
        textView.placeholder = &&"post_placeholder_text"
        textView.pastableMediaTypes = SLKPastableMediaType()
        textView.refreshFirstResponder()
        textView.refreshInputViews()
        
        // setup buttons
        leftButton.setImage(UIImage(named: "CameraIcon"), for: UIControlState())
        rightButton.setTitle(&&"post_button_title", for: UIControlState())
        
        // setup textinputbar
        textInputbar.editorTitle.textColor = UIColor.darkGray
        
        textInputbar.editorLeftButton.tintColor = UIColor(red: 0, green: 122.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        textInputbar.editorRightButton.tintColor = UIColor(red: 0, green: 122.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        
        textInputbar.autoHideRightButton = false
        textInputbar.counterStyle = .split
        textInputbar.counterPosition = SLKCounterPosition.top
        textInputbar.maxCharCount = 160
        
        textView.text = "A really looooong textA really looooong textA really looooong textA really looooong textA really looooong textA really looooong textA really looooong text"
        
        textInputbar.setNeedsLayout()
        textInputbar.layoutIfNeeded()
        
        textView.text = ""
        
        textInputbar.setNeedsLayout()
        textInputbar.layoutIfNeeded()
        
        typingIndicatorView.canResignByTouch = true
        
        autoCompletionView.register(NewsFeedCell.self, forCellReuseIdentifier: Storyboard.CellIdentifiers.AutoCompletionCellIdentifier)
        registerPrefixes(forAutoCompletion: ["#", "@"])
    }
    
    override func canPressRightButton() -> Bool {
        return super.canPressRightButton()
    }
    
    override func canShowAutoCompletion() -> Bool {
        
        // clear the search results array
        let autoCompletionList = foundPrefix == "#" ? hashTags : users
        searchResults = autoCompletionList
        
        // filter hashtags
        let predicate = NSPredicate(format: "SELF BEGINSWITH[C] %@", foundWord)
        if foundWord.characters.count > 0 {
            searchResults = autoCompletionList.filter {
                predicate.evaluate(with: $0)
            }
        }
        
        // sort the search results
        if let _ = searchResults {
            (searchResults!).sort(by: <)
        }
        
        return searchResults?.count > 0
    }
    
    override func didPressLeftButton(_ sender: Any) {
        super.didPressLeftButton(sender)
        
        // hide keyboard to show actionsheet on top
        view.endEditing(true)
        
        // no need to reload data after picking image
        shouldReload = false
        
        // fetch image from image picker
        ImagePickerManager.sharedManager.presentImagePicker(self) { (image, source) -> () in
            self.textView.insertImage(image)
            DispatchQueue.main.async {
                self.textView.becomeFirstResponder()
                self.textView.selectedRange = NSMakeRange(self.textView.text.characters.count, 0)
            }
        }
    }
    
    override func didPressRightButton(_ sender: Any) {
        
        // validate any pending auto-correction or auto-spelling
        textView.refreshFirstResponder()
        
        // create a new newsfeed
        textView.getInsertedImage { image in
            NewsFeed.create(self.textView.text, image: image) { (newsFeed, error) -> () in
                if error != nil {
                    // XXX handler error
                    return
                }
                
                // reload tableview with the new newsfeed
                DispatchQueue.main.async {
                    
                    // update tableview
                    if let newsFeed = newsFeed {
                        self.tableView.beginUpdates()
                        self.newsFeeds = [newsFeed] + self.newsFeeds
                        self.tableView.insertRows(at: [IndexPath(row: 0, section: 0)], with: .bottom)
                        self.tableView.endUpdates()
                        self.dismissKeyboard(true)
                    }
                }
            }
            
            // cleanup the textview (weird huh?)
            DispatchQueue.main.async {
                self.textView.attributedText = nil
                self.textView.text = "   "
                self.textView.font = UIFont.systemFont(ofSize: 16)
                self.textView.slk_clearText(true)
            }
        }
        
        tableView.slk_scrollToTop(animated: true)
        
        // call the super method in the end with some
        // additional cleanup to handle image insertions
        // super method will do the cleanup
        super.didPressRightButton(sender)
    }
    
    override func didPasteMediaContent(_ userInfo: [AnyHashable: Any]!) {
        super.didPasteMediaContent(userInfo)
        
        // XXX do something related to image upload here
    }
    
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        if (tableView == self.tableView) {
            
            return CGFloat((newsFeeds[indexPath.row] as NewsFeed).contentHeight)
        }
        else {
            return 0.0
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if (tableView == self.tableView) {
            return CGFloat((newsFeeds[indexPath.row] as NewsFeed).contentHeight)
        }
        else {
            return 0.0
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == autoCompletionView {
            return searchResults?.count ?? 0
        }
        else {
            return newsFeeds.count //+ 1
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell
        
        if tableView == self.tableView {
            cell = self.tableView(tableView, newsFeedCellForRowAtIndexPath: indexPath)
        } else {
            cell = self.tableView(tableView, autoCompletionCellForRowAtIndexPath: indexPath)
        }
        
        // update the cell transform
        cell.transform = tableView.transform
        
        return cell
    }
    
    func tableView(_ tableView:UITableView, adverstimentCellForRowAtIndexPath indexPath: IndexPath) -> AdvertisementCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.AdvertisementCellIdentifier) as! AdvertisementCell
        // configure cell
        cell.advertisement = advertisement
        cell.advertisementCellDelegate = self;
        return cell
    }
    
    func tableView(_ tableView: UITableView, newsFeedCellForRowAtIndexPath indexPath: IndexPath) -> NewsFeedCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.NewsFeedCellIdentifier) as! NewsFeedCell
        
        // configure cell
        cell.newsFeed = newsFeeds[indexPath.row]
        cell.newsFeedCellDelegate = self
        cell.enlargeImageNewsFeedDelegate = self
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, autoCompletionCellForRowAtIndexPath indexPath: IndexPath) -> NewsFeedCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.AutoCompletionCellIdentifier) as! NewsFeedCell
        
        // XXX configure cell here
        cell.textLabel?.text = searchResults![indexPath.row]
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        // auto completion view header
        if tableView == autoCompletionView {
            let headerView = UIView()
            headerView.backgroundColor = autoCompletionView.separatorColor
            return headerView
        } else if tableView == self.tableView {
            // view log button header
            return DashboardViewLogHeaderView(delegate: self, advertisement: advertisement)
        } else {
            return nil
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if tableView == autoCompletionView {
            return  0.5
        } else {
            return advertisement.shouldDisplayAdvertisement ? 100 : 30
        }
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        (cell as? NewsFeedCell)?.newsFeed = newsFeeds[indexPath.row]
        
        //        cell.layoutIfNeeded()
    }
    
    override func heightForAutoCompletionView() -> CGFloat {
        let cellHeight = CGFloat(44.0)
        let cellCount = CGFloat(searchResults?.count ?? 0)
        return cellHeight * cellCount
    }
    
    func pullToRefresh(_ sender: UIRefreshControl) {
        
        // reset page meta data
        pageMeta = PageMetaModel()
        
        // fetch news feeds and reload table
        NewsFeed.fetchPublicNewsFeeds(false, pageMeta: pageMeta) { (newsFeeds, pageMeta) -> () in
            self.newsFeeds = newsFeeds
            self.pageMeta = pageMeta
            self.refreshControl.endRefreshing()
            self.tableView.reloadData()
        }
    }
    
    // load more funcationality
    func dragTableDidTriggerLoadMore(_ tableView: UITableView!) {
        
        if !pageMeta.isValid {
            Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(DashboardViewController.finishLoadMore), userInfo: nil, repeats: false)
            return
        }
        
        // fetch news feeds and reload table
        NewsFeed.fetchPublicNewsFeeds(offset: newsFeeds.count, pageMeta: pageMeta) { (newsFeeds, pageMeta) -> () in
            self.pageMeta = pageMeta
            self.newsFeeds += newsFeeds
            self.tableView.finishLoadMore()
        }
    }
    
    func dragTableLoadMoreCanceled(_ tableView: UITableView!) {
        // called when the load more is cancelled
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(DashboardViewController.finishLoadMore), object: nil)
    }
    
    func finishLoadMore() {
        tableView.finishLoadMore()
        tableView.reloadData()
    }
    
    func clickedOnAdHeader(_ urlString:String) {
        TermsViewController.openAdsInEmbedBrowser(self.navigationController, withUrl: urlString)
    }
    
    func buttonActionSideMenu(_: UIButton) {
        performSegue(withIdentifier: Storyboard.Segues.UnwindSideMenu, sender: self)
    }
    
    func infoButtonClicked(_ macroStatsView: MacroStatsView) {
        performSegue(withIdentifier: Storyboard.Segues.MacroChartSegue, sender: self)
    }
    
    func buttonActionViewLog(_ sender: DashboardViewLogHeaderView) {
        performSegue(withIdentifier: Storyboard.Segues.ViewLogSegue, sender: self)
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didSelectHashTag hashTag: String) {
        self.hashTag = hashTag
        performSegue(withIdentifier: Storyboard.Segues.HashTagSegue, sender: self)
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didSelectUser userId: String) {
        performSegue(withIdentifier: Storyboard.Segues.ProfileSegue, sender: userId)
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didSelectBusinessDirectory businessDirectoryId: String) {
        DirectoryDetailViewController.loadDirectoryDetail(businessDirectoryId, fromViewcontroller: self)
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didLikeNewsFeed like: Bool) {
        // do something after liking
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didInspireNewsFeed inspire: Bool) {
        // do something after inspiring
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didDeleteNewsFeed delete: Bool) {
        
        if delete {
            let cellIndexPath = tableView.indexPath(for: newsFeedCell)
            let feedId = newsFeeds[cellIndexPath!.row].id
            
            let reachability = appDelegate!.internetReachable
            if !reachability {
                // no internet
                
                // alert
                AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                return
            }
            
            UIAlertView.show(withTitle: &&"delete_confirmation_title", message: &&"delete_confirmation_message", cancelButtonTitle: &&"ok_button_title", otherButtonTitles: [&&"cancel_button_title"], tap: { (alertview : UIAlertView, buttonIndex : Int) in
                
                
                if buttonIndex == alertview.cancelButtonIndex{
                    
                    NewsFeedDeleteResponse.deleteNewsFeed(feedId, completionHandler: { (responseStatus) -> () in
                        if responseStatus == "OK" {
                            let feed = self.newsFeeds.filter({$0.id == feedId})
                            
                            // remove the feed
                            self.newsFeeds.remove(feed[0])
                            
                            // reload tableview
                            self.tableView.reloadData()
                        }
                    })
                    
                }
            })
            
            
            // delete the feed
        }
    }
    
    func buttonActionComments(_ newsFeed: NewsFeed) {
        performSegue(withIdentifier: Storyboard.Segues.NewsFeedCommentsSegue, sender: newsFeed)
    }
    
    func displayNewAd() -> () {
        Advertisement.latestAdvertisement("Newsfeed") { (advertisement) -> () in
            self.advertisement = advertisement
        }
    }
    
    func showAd(_ urlString: String) {
        TermsViewController.openAdsInEmbedBrowser(self.navigationController, withUrl: urlString)
    }
    
    func buttonShare(_ shareContent: FacebookShareModel) {
        NewsFeedShare.sharedManager.showActionSheet(true, fromViewController: self) { () -> (FacebookShareModel) in
            return shareContent;
        }
    }
    
    func clickedOnAd(_ urlString: String) {
        TermsViewController.openAdsInEmbedBrowser(self.navigationController, withUrl: urlString)
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let userInteractionEnabled = slidingViewController?.currentTopViewPosition == ECSlidingViewControllerTopViewPosition.centered
        
        tableView.isUserInteractionEnabled = userInteractionEnabled
        textInputbar.isUserInteractionEnabled = userInteractionEnabled
        dashboardNavigationController?.toolbar.isUserInteractionEnabled = userInteractionEnabled
    }
    
    override func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        return isGesturePopEnabled
    }
    
    struct Storyboard {
        struct CellIdentifiers {
            static let NewsFeedCellIdentifier = "kNewsFeedCell"
            static let AutoCompletionCellIdentifier = "kAutoCompletionCell"
            static let AdvertisementCellIdentifier = "kAdvertisementCell"
        }
        struct Segues {
            static let ProfileSegue = "kMyProfileSlideSegue"
            static let MacroChartSegue = "kMacroChartSegue"
            static let NewsFeedCommentsSegue = "kNewsFeedCommentsSegue"
            static let HashTagSegue = "kHashTagSegue"
            static let ViewLogSegue = "kViewLogSegue"
            static let UnwindSideMenu = "kUnwindToSideMenu"
            static let MessagesSegue = "kDashboardMessagesSegue"
        }
        struct Nibs {
            static let NewsFeedCell = "NewsFeedCell"
        }
        struct Sections {
            static let AdvertisementSection = 0
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == Storyboard.Segues.HashTagSegue {
            let hashTagViewController = segue.destination as! HashTagViewController
            hashTagViewController.hashTag = hashTag
        }
        else  if segue.identifier == Storyboard.Segues.MacroChartSegue {
            let macroChartViewController = segue.destination as! MacroChartViewController
            macroChartViewController.macroDetails = macroDetails
        }
        else if segue.identifier == Storyboard.Segues.ProfileSegue {
            let profileViewController = segue.destination as! ProfileViewController
            profileViewController.userId = sender as? String ?? ""
        }
        else if segue.identifier == Storyboard.Segues.NewsFeedCommentsSegue {
            let newsFeedCommentsViewController = segue.destination as! NewsFeedCommentsViewController
            newsFeedCommentsViewController.newsFeed = sender as! NewsFeed
        }
        else if segue.identifier == Storyboard.Segues.ViewLogSegue {
            
            // check if sender is from exercise log screens
            let isFoodLogMode = !(sender is ExerciseStrengthLogViewController || sender is ExerciseCardioLogViewController || sender is SendDetailsViewController)
            
            let viewLogViewController = segue.destination as? ViewLogViewController
            viewLogViewController?.isFoodLogMode = isFoodLogMode
        }
        else if segue.identifier == Storyboard.Segues.MessagesSegue {
            let messagesViewController = segue.destination as! MessagesViewController
            
            if shouldNavigateMessageDetails {
                shouldNavigateMessageDetails = false
                messagesViewController.navigateMessageDetailsFriendId = sender as? String ?? ""
                messagesViewController.navigateMessageDetails = true
            }
        }
    }
    
    func enlargeImageView(_ selectedCell: NewsFeedCell, imageViewNewsFeed: UIImageView) {
        
        self.shouldReload = false
        let imageInfo = JTSImageInfo()
        imageInfo.placeholderImage = imageViewNewsFeed.image;
        imageInfo.imageURL = URL(string: selectedCell.newsFeed.feedImage.replacingOccurrences(of: "feed200", with: "feed600"))
        imageInfo.referenceRect = imageViewNewsFeed.frame
        imageInfo.referenceView = imageViewNewsFeed.superview
        let imageViewController = JTSImageViewController(imageInfo: imageInfo, mode: .image, backgroundStyle: .scaled)
        
        // present the view controller.
        imageViewController?.show(from: self, transition: .fromOriginalPosition)
    }
    
    @IBAction func unwindToDashboardViewController(_ segue: UIStoryboardSegue) {
        // close the side menu if its open
    }
    
    @IBAction func barButtonActionMealPlan(_ sender: Any) {
        let manageStoryboard = UIStoryboard(name: "DailyMealPlan", bundle: Bundle.main)
        
        // instantiate the initial view controller
        let initialViewController = manageStoryboard.instantiateViewController(withIdentifier: "kDailyMealPlanList") as! DailyMealPlanViewController
        
        dashboard?.navigationController?.pushViewController(initialViewController, animated: true)
        
    }
    
    @IBAction func barButtonActionDailyLog(_ sender: Any) {
        
        let manageStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        
        // instantiate the view controller
        let viewLogViewController = manageStoryboard.instantiateViewController(withIdentifier: "kViewLog") as! ViewLogViewController
        viewLogViewController.isFoodLogMode = true
        dashboard?.navigationController?.pushViewController(viewLogViewController, animated: true)
    }
    
}
