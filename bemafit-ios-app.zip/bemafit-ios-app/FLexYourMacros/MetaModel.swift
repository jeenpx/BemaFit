//
//  MetaModel.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 10/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class MetaModel: NSObject {
    
    var responseStatus: String?
    var responseCode: NSNumber = 0 {
        
        didSet {
            
          //  if responsecode is 430 the user is not valid user, got deleted from admin side
            if responseCode == 430 {
            
            let userDefaults = UserDefaults.standard
            if let sessionStatus: Any = userDefaults.object(forKey: "session") as Any? {
            
            if sessionStatus as! String == "Active"  && responseCode == 403 {
            
            RestKitManager.shared().operationQueue.cancelAllOperations()

            userDefaults.set("DeActivate", forKey: "session")
            userDefaults.synchronize()
                
            let deviceToken = userDefaults.object(forKey: "token") as? String ?? ""
                
            LogoutResponse.logoutUser(deviceToken, completionHandler: { (metaModel) -> () in
                if let meta = metaModel {
                    if meta.responseCode != 200 {
                        AlertManager.showAlert(&&"notice", message: &&"failed_logout")
                        return
                    }
                    let appDelegate = UIApplication.shared.delegate as? AppDelegate
                    appDelegate?.loadLogin()
                }
            })
            }
            }

            }
        }
    }
    
    var message: String = ""
    var errormessages: [MetaError] = [MetaError]()
    
    class var objectMapping: RKObjectMapping {
        let metaMapping = RKObjectMapping(for: self)
        metaMapping?.addAttributeMappings(from: mappingDictionary)
        // give reference to accesstoken mapping
        metaMapping?.addPropertyMapping(MetaModel.errorMessageMapping)
        return metaMapping!
    }
    
    fileprivate class var errorMessageMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathErrorMessage, toKeyPath: "errormessages", with: MetaError.objectMapping)
    }
    
    class var mappingDictionary: [String : String] {
        return(["status":"responseStatus", "code":"responseCode", "message" : "message"])
    }
}

class MetaError: NSObject {
    
    var field: String = ""
    var fieldMessage: String = ""
    
    class var objectMapping: RKObjectMapping {
        let metaMapping = RKObjectMapping(for: self)
        metaMapping?.addAttributeMappings(from: mappingDictionary)
        return metaMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["field":"field", "message":"fieldMessage"])
    }
}

class PageMetaModel: NSObject {
    var hashId = ""
    var rangeId = ""
    var subRangeId = ""
    
    var isValid: Bool {
        return !hashId.isEmpty
    }
    
    class var objectMapping: RKObjectMapping {
        
        let mapping = ["hid": "hashId", "rid1": "rangeId", "rid2": "subRangeId"]
        
        let pageMetaMapping = RKObjectMapping(for: self)
        pageMetaMapping?.addAttributeMappings(from: mapping)
        return pageMetaMapping!
    }
}
