//
//  Progress.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 29/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import CoreData
@objc(Progress)
class Progress: NSManagedObject {

    @NSManaged var type: String
    @NSManaged var report: NSSet
    @NSManaged var required_per_day: DailyRequirement
    @NSManaged var progress_first_log: ProgressFirstLog
    @NSManaged var progress_last_log: ProgressLastLog
    @NSManaged var macro_per_reporting_period: MacroPerReportingPeriod

    class var entityMapping : RKEntityMapping {
        
        let progressMapping: RKEntityMapping = RKEntityMapping(forEntityForName: Constants.Tables.progressTable, in: RestKitManager.shared().managedObjectStore)
        //set up the identification attribute
//        progressMapping.identificationAttributes = ["type"]

        progressMapping .addAttributeMappings(from: progressMappingDictionary)
        progressMapping.addPropertyMapping(RKRelationshipMapping(fromKeyPath: "report", toKeyPath: "report", with: ProgressReport.entityMapping))
        progressMapping.addPropertyMapping(RKRelationshipMapping(fromKeyPath: "required_per_day", toKeyPath: "required_per_day", with: DailyRequirement.entityMapping))
        progressMapping.addPropertyMapping(RKRelationshipMapping(fromKeyPath: "first_entry", toKeyPath: "progress_first_log", with: ProgressFirstLog.entityMapping))
        progressMapping.addPropertyMapping(RKRelationshipMapping(fromKeyPath: "last_entry", toKeyPath: "progress_last_log", with: ProgressLastLog.entityMapping))
        progressMapping.addPropertyMapping(RKRelationshipMapping(fromKeyPath: "required_per_reporting_period", toKeyPath: "macro_per_reporting_period", with: MacroPerReportingPeriod.entityMapping))
        return progressMapping
    }
    
    fileprivate class var progressMappingDictionary: [String : String] {
        
        return(["type":"type"])
    }
    
    class func fetchProgressDataFromUrl(_ progressType: String, date: String, dateType: String, numberOfPages: String, completionHandler:@escaping (_ done: Bool)->(), completedWithError:@escaping (_ error: NSError)->()) {
        
        ProgressResponse.fetchUserProgressData(progressType, date: date, dateType: dateType, numberOfPages: numberOfPages, completionHandler: { (done) -> () in
            completionHandler(done)
        }) { (error) -> () in
            completedWithError(error)
        }
        
    }
    
    class func fetchProgressData(_ progressType: String, progressStartDate: String,progressEndDate: String, completionHandler:(_ fetchedArray: [Any])->()) {
        
        var error: NSError?
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>()
        let entity = NSEntityDescription.entity(forEntityName: Constants.Tables.progressReportTable, in: RKObjectManager.shared().managedObjectStore.persistentStoreManagedObjectContext)
        fetchRequest.returnsObjectsAsFaults = false
        fetchRequest.entity = entity
        
        // set the predicate
//        let progressPredicate = NSPredicate(format: "log_date >= %@ && log_date < %@ && (SUBQUERY(progressType, $x, $x.type = %@).@count == progressType.@count)",progressStartDate,progressEndDate,progressType)

        let progressReportQuery1 =  NSPredicate(format: "(log_date <= %@)",progressEndDate)
        let progressReportQuery2 =  NSPredicate(format: "(log_date >= %@)",progressStartDate)
        let progressReportQuery3 =  NSPredicate(format: "SUBQUERY(progressType, $x, $x.type = %@).@count == progressType.@count",progressType)
        
        let compoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: [progressReportQuery1, progressReportQuery2, progressReportQuery3])
        fetchRequest.predicate = compoundPredicate
        
        var count = 1
        count = try! RKObjectManager.shared().managedObjectStore.persistentStoreManagedObjectContext.count(for: fetchRequest)
        fetchRequest.fetchLimit = count
        
        var fetchedObjects: [Any]?
        do {
            fetchedObjects = try RKObjectManager.shared().managedObjectStore.persistentStoreManagedObjectContext .fetch(fetchRequest)
        } catch let error1 as NSError {
            error = error1
            fetchedObjects = nil
        }
        completionHandler(fetchedObjects!)
    }

    class func deleteProgressData(_ progressType: String, progressStartDate: String,progressEndDate: String, completionHandler:(_ deletedSuccessfully: Bool)->()) {
        
        //delete macro details
        
        if progressType == "Macro" {
            
            let dailyRequirementQuery = NSPredicate(format: "SUBQUERY(progressDailyType, $x, $x.type = %@).@count == progressDailyType.@count",progressType)
            fetchObjects(Constants.Tables.dailyRequirement, query: dailyRequirementQuery)
            
            let macroDetailQuery = NSPredicate(format: "progress_type_reporting_period.type = %@",progressType)
            fetchObjects(Constants.Tables.MacroPerReportingPeriod, query: macroDetailQuery)

        } else {
           
            //delete first log data
            
            let firstLogQuery = NSPredicate(format: "SUBQUERY(progressFirstLogType, $x, $x.type = %@).@count == progressFirstLogType.@count",progressType)
            fetchObjects(Constants.Tables.ProgressFirstLog, query: firstLogQuery)
            
            //delete last log data
            
            let lastLogQuery = NSPredicate(format: "SUBQUERY(progressLastLogType, $x, $x.type = %@).@count == progressLastLogType.@count",progressType)
            fetchObjects(Constants.Tables.ProgressLastLog, query: lastLogQuery)
        }
        
        // delete report data for the month
        let progressReportQuery1 =  NSPredicate(format: "(log_date <= %@)",progressEndDate)
        let progressReportQuery2 =  NSPredicate(format: "(log_date >= %@)",progressStartDate)
        let progressReportQuery3 =  NSPredicate(format: "SUBQUERY(progressType, $x, $x.type = %@).@count == progressType.@count",progressType)
        let compoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: [progressReportQuery1,progressReportQuery2,progressReportQuery3])
        
        var error: NSError?
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>()
        let entity = NSEntityDescription.entity(forEntityName: Constants.Tables.progressReportTable, in: RKObjectManager.shared().managedObjectStore.persistentStoreManagedObjectContext)
        fetchRequest.returnsObjectsAsFaults = false
        fetchRequest.entity = entity
        
        // set the predicate
        let progressReportPredicate = compoundPredicate
        fetchRequest.predicate = progressReportPredicate
        
        var count = 1
        count = try! RKObjectManager.shared().managedObjectStore.persistentStoreManagedObjectContext.count(for: fetchRequest)
        fetchRequest.fetchLimit = count
        
        let fetchedReportObjects = (try! RKObjectManager.shared().managedObjectStore.persistentStoreManagedObjectContext .fetch(fetchRequest)) as![NSManagedObject]
        
        deleteObjects(fetchedReportObjects)

        completionHandler(true)

    }
    
    class func fetchObjects(_ tablename: String, query: NSPredicate) {
        
        var error: NSError?
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>()
        let entity = NSEntityDescription.entity(forEntityName: tablename, in: RKObjectManager.shared().managedObjectStore.persistentStoreManagedObjectContext)
        fetchRequest.returnsObjectsAsFaults = false
        fetchRequest.entity = entity
        
        // set the predicate
        let progressReportPredicate = query
        fetchRequest.predicate = progressReportPredicate
        
        var count = 1
        count = try! RKObjectManager.shared().managedObjectStore.persistentStoreManagedObjectContext.count(for: fetchRequest)
        fetchRequest.fetchLimit = count
        
        let fetchedReportObjects = (try! RKObjectManager.shared().managedObjectStore.persistentStoreManagedObjectContext .fetch(fetchRequest)) as![NSManagedObject]
        
        deleteObjects(fetchedReportObjects)
        
    }
    
    class func deleteObjects(_ fetchedObjects: [NSManagedObject]) {
        
        var error: NSError?

        for rowObject in fetchedObjects {
            RestKitManager.shared().managedObjectStore.persistentStoreManagedObjectContext.delete(rowObject)
            //print("deleted successfuly")
            do {
                try RestKitManager.shared().managedObjectStore.persistentStoreManagedObjectContext.save()
            } catch var error1 as NSError {
                error = error1
                //print("failed to delete object")
            }
        }
        
        
    }
    
}

