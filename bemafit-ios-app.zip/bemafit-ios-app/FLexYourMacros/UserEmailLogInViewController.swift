//
//  UserEmailLogInViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 11/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UserEmailLogInViewController: UITableViewController, UIAlertViewDelegate {
    
    @IBOutlet weak var textFieldEmail: UITextField!
    @IBOutlet weak var textFieldPassword: UITextField!
    
    var currentTextField = UITextField()
    
    override func viewWillAppear(_ animated: Bool) {
        // hides navigation bar
        navigationController?.isNavigationBarHidden = false
        let titleDictionary: NSDictionary = [NSForegroundColorAttributeName: UIColor.white]
        self.navigationController?.navigationBar.titleTextAttributes = titleDictionary as? [String : Any]
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if AppConfiguration.sharedAppConfiguration.isFacebookUser {
            textFieldEmail.text = UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserEmail
        } else {
            
            textFieldEmail.text = AppConfiguration.sharedAppConfiguration.userDetails?.userEmail
        }
        
        // hides navigation bar
        navigationController?.isNavigationBarHidden = false
        let titleDictionary: NSDictionary = [NSForegroundColorAttributeName: UIColor.white]
        self.navigationController?.navigationBar.titleTextAttributes = titleDictionary as? [String : Any]
        
        // Remove separator Inset of Table view
        
        if #available(iOS 8.0, *) {
            tableView.layoutMargins = UIEdgeInsets.zero
        } else {
            // Fallback on earlier versions
            tableView.separatorInset = UIEdgeInsets.zero
        };
        
    }
    
    @IBAction func unwindToUserEmailLoginViewController(_ segue: UIStoryboardSegue) {
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        currentTextField = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField!) -> Bool {
        // resign keyboard
        textField.resignFirstResponder()
        return false
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    @IBAction func buttonActionUserLogIn(_ sender: UIButton) {
        
        currentTextField.resignFirstResponder()
        // check whether email or password is empty
        if textFieldEmail.isEmpty {
            
            showAlert(&&"notice", message: &&"email_validity")//"Please enter a email")
            return
        } else if textFieldPassword.isEmpty {
            
            showAlert(&&"notice", message: &&"password_validity")//"Please enter a password")
            return
        }
        else if !textFieldEmail.isValidEmailAddress{
            showAlert("notice", message: &&"email_validity")//"Please enter a valid email")
            return
        }
        
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        UserLogInResponse.logInUser(self, username: textFieldEmail.text!, password: textFieldPassword.text!, completionHandler: { (accessCredential, userDiet, userDetails) -> () in
            
            AppConfiguration.sharedAppConfiguration.userDetails = userDetails
            
            AppConfiguration.sharedAppConfiguration.userDiet = userDiet
            
            AppConfiguration.sharedAppConfiguration.userCredential = accessCredential
            
            //print("accesstoken:\(AppConfiguration.sharedAppConfiguration.userCredential?.accessToken)")
            //print("userid:\(AppConfiguration.sharedAppConfiguration.userDetails?.userId)")
            
            self.appDelegate?.checkUserVerification({ (verifiedStatus) -> () in
                
                if !verifiedStatus {
                    
                    let userDefaults = UserDefaults.standard
                    
                    AppConfiguration.sharedAppConfiguration.userEmail = userDefaults.object(forKey: "user_email") as! String
                    
                    let alert =  UIAlertView(title: &&"notice", message: &&"To continue using the app, please verify the registered email", delegate: self, cancelButtonTitle: &&"ok", otherButtonTitles: &&"resend_email")
                    alert.tag = 2
                    alert.show()
                    
                } else {
                    Flurry.logEvent("Login", withParameters: ["useremail" : self.textFieldEmail.text, "userID" : AppConfiguration.sharedAppConfiguration.userDetails?.userId])
                    self.appDelegate?.loadDashboard()
                }
            })
            
            }) { (error) -> () in
                
                self.showAlert(&&"notice", message: error)
        }
        
    }
    
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        
        if alertView.tag == 2 {
            
            if buttonIndex == 1 {
                
                
                // resend email api called
                ResendEmailResponse.resendEmail(AppConfiguration.sharedAppConfiguration.userEmail, completionHandler: { (resendEmailResponse) -> () in
                    
                    if resendEmailResponse == nil {
                        UIAlertView(title: &&"notice", message: &&"failed_resend_email", delegate: nil, cancelButtonTitle: &&"ok").show()
                        
                        return }
                    if resendEmailResponse!.status == "OK" {
                        
                        UIAlertView(title: &&"email_sent", message: &&"check_the_email_1" + "\(AppConfiguration.sharedAppConfiguration.userEmail). " + &&"check_the_email_2", delegate: nil, cancelButtonTitle: &&"ok").show()
                        
                    }
                })
                
                self.appDelegate?.loadLogin()
                
            } else {
                self.appDelegate?.loadLogin()
            }
        }
    }
    
    func showAlert(_ title: String, message: String) {
        
        if #available(iOS 8.0, *) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
        } else {
            // Fallback on earlier versions
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: "ok").show()
        }
    }
    
    override func  tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        cell.setSeparatorInsetZero()
        
    }
    
}
