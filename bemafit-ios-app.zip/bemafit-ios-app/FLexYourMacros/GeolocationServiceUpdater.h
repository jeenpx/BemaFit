//
//  GeolocationServiceUpdater.h
//  GeolocationServiceSample
//
//  Created by dbgmacmini2 dbg on 13/03/14.
//  Copyright (c) 2014 codebase. All rights reserved.
//


#define NOTIFICATION_UPDATE_LOCATION @"NOTIFICATION_UPDATE_LOCATION"
#define NOTIFICATION_STATE_CHANGED @"NOTIFICATION_STATE_CHANGED"
#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

typedef enum{
    NOT_ENABLED_LOCATION_SERVICE,
    NOT_ENABLED_IN_PHONE_SETTINGS,
    NOT_ENABLED_IN_APP_SETTINGS,
    ALL_SETTINGS_ENABLED,
    }GeolocationServiceUpdaterDisbledType;


typedef NS_ENUM(NSUInteger, GeoLocationDiabledType) {
    DISABLED_LOCATION_SERVICE,
    DISABLED_IN_PHONE_SETTINGS,
    DISABLED_IN_APP_SETTINGS,
    SETTINGS_ENABLED,
};

typedef  void (^UpdatedLocation)(CLLocation*,CLLocationDistance);
typedef  void (^UpdatedLocationName)(CLLocation* location,NSString *locationName, CLPlacemark* placemark,NSError* error);
@class CLLocationManager;

@interface GeolocationServiceUpdater : NSObject <CLLocationManagerDelegate>
@property(strong,nonatomic) CLLocationManager* clLocationManager;
@property(strong,nonatomic) CLLocation* oldLocationPoint;
@property(nonatomic) float desiredMeterDistance;
@property(strong,nonatomic) CLGeocoder *geocoder;
@property(strong,nonatomic) UpdatedLocation locationUpdate;
@property(strong,nonatomic) UpdatedLocationName locationNameUpdate;
+(BOOL)isGeoLocationEnabled;
+(BOOL)isLocationServicesEnabled;

+(void)getUpdatedLocation:(UpdatedLocation)locationUpdater;
+(GeolocationServiceUpdater*)getSharedGeoLocationUpdater;
+(void)stopScanningForLocationChange;
+(void)startScaningForLocationChange;
+(void)isGeoLocationEnabled:(void(^)(BOOL result,GeolocationServiceUpdaterDisbledType type))block;
+(CLLocation*)getLastKnowLocation;
+(void)setDesiredMeterDistance:(float)meters;
+(void)registerForUpdatesWith:(id)object andSelector:(SEL)selector;
+(void)fireNotificationStateChanged;
+(void)registerForStateChangeWith:(id)object andSelector:(SEL)selector;
+(void)getLastKnownLocationName:(UpdatedLocationName)updatedLocationNameBlock;
+(void)isGeoLocationSettingsEnabled:(void(^)(BOOL result,GeoLocationDiabledType type))block;
@end
