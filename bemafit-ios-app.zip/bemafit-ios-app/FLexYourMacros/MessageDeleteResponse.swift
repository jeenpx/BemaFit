//
//  MessageDeleteResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/11/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class MessageDeleteResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var user_id: String?
    var friend_id: String?
    
    // message delete response mapping
    class var messageDeleteResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(MessageDeleteResponse.metaModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: messageDeleteResponseMapping, method: .DELETE, pathPattern: Constants.ServiceConstants.kUrlThreadMessages, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func deleteThreadMessages(_ friendId: String, completionHandler: @escaping (_ responseStatus: String) -> ()) {
        // delete the message thread
        
        // set access token
        RestKitManager.setToken(true)
        
        let messageDeleteResponse = MessageDeleteResponse()
        messageDeleteResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId
        messageDeleteResponse.friend_id = friendId
        
        RestKitManager.shared().delete(messageDeleteResponse, path: nil, parameters: nil, success: { (operation, mappingResult) in
            
            //print("Success")
            let deleteResponseObject = mappingResult?.firstObject as! MessageDeleteResponse
            
            if let responseMeta = deleteResponseObject.meta {
                
                // completion handler
                completionHandler(responseMeta.responseStatus!)
            }
            
            }) { (operation, error) in
                //print("error \(error)");
        }
        
    }
}
