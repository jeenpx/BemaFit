//
//  UserFacebook.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 13/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _UserVerificationResponse = UserVerificationResponse()

class UserVerificationResponse: NSObject {
    
    var userVerificationModel: UserVerificationModel?
    var metaModel: MetaModel?

    class var sharedUserVerificationResponse: UserVerificationResponse {
        return _UserVerificationResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(UserVerificationResponse.metaModelKeyMapping)
        
        // give reference to accesstoken mapping
        responseMapping?.addPropertyMapping(UserVerificationResponse.userVerificationModelKeyMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.verifyUserUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var userVerificationModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathVerifyUser, toKeyPath: "userVerificationModel", with: UserVerificationModel.objectMapping)
    }
    
    class func verifyUser(_ userEmail: String, showHUD: Bool = true, userFacebookId: String, userName: String = "", completionHandler: @escaping (_ userVerificationModel: UserVerificationModel) -> (), failure: @escaping (_ failedWithError: String) -> ()) {
        
        if showHUD {
            SVProgressHUD.show()
        }

        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["email":userEmail as String, "facebook_id":userFacebookId as String, "username": userName]
        }
        
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path: Constants.ServiceConstants.verifyUserUrl, parameters: parameterDictionary, constructingBodyWith: { (formData) in
           
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            if showHUD {

            SVProgressHUD.dismiss()
            }

            // get the user response
            let userVerificationResponse = mappingResult?.firstObject as! UserVerificationResponse
            
            // check for success
            if userVerificationResponse.metaModel?.responseCode != 200 {
                
                var errorMessage = userVerificationResponse.metaModel?.message ?? ""
                let errorMessages = userVerificationResponse.metaModel?.errormessages
                if errorMessages!.isEmpty {
                    
                } else {
                    
                    errorMessage = errorMessages?.first?.fieldMessage ?? ""
                }
                failure(errorMessage)
                return;
            }
            
            // set up the completion handler with response
            completionHandler(userVerificationResponse.userVerificationModel!)
            
            }) { (operation, error) in
                
                if showHUD {

                    SVProgressHUD.dismiss() }

                failure((error?.localizedDescription)!)
                //print("failed to load user verification with error \(error)")
        }

        RestKitManager.shared().enqueue(operation)
    
    }
    
}
