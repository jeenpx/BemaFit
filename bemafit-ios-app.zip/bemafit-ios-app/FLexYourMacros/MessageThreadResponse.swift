//
//  MessageThreadResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/4/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class MessageThreadResponse: NSObject{
    
    // model instance variables
    var meta: MetaModel?
    var messages: [MessageItemModel]?
    var totalMessages: String?
    
   // route instance variables
    var user_id: String?
    var friend_id: String?
    
    override init() {
        super.init();
    }
    
    // message response mapping
    class var messageResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        responseMapping?.addAttributeMappings(from: mappingDictionary)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(MessageThreadResponse.metaModelKeyMapping)
        
        // give reference to message item model
        responseMapping?.addPropertyMapping(MessageThreadResponse.messageThreadModelKeyMapping)
        
        return responseMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["total_messages":"totalMessages"])
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    fileprivate class var messageThreadModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMessages, toKeyPath: "messages", with: MessageItemModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: messageResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kUrlThreadMessages, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    
    class func getThreadMessages(_ offset: Int, andLimit limit: Int, andFriendId friendId: String, andShowProgressHUD showLoader: Bool, completionHandler: @escaping (_ totalMessages: Int, _ messages: [MessageItemModel]?) -> ()) {
        // get thread messages
        
        if showLoader {
        SVProgressHUD.show()
        }
        
        // set access token
        RestKitManager.setToken(true)
        
        // input parameters
        let params: Dictionary = ["offset": offset, "limit": limit]
        
        // instance of message model class
        let messageThreadResponse = MessageThreadResponse()
        
        // set user id
        messageThreadResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId
        
        // set friend id
        messageThreadResponse.friend_id = friendId
        
        // api call with instance of message model class
        RestKitManager.shared().getObject(messageThreadResponse, path: nil, parameters: params, success: { (operation, mappingResult) in
            
            //print("Success")
            let messageObject = mappingResult?.firstObject as! MessageThreadResponse
            
            // check for success
            if messageObject.meta?.responseCode != 200 {
                //print("failure data\(messageObject.meta?.responseCode)")
                return;
            }
            //print("totalmessages:\(messageObject.totalMessages?.intValue)")
            
            SVProgressHUD.dismiss()
            
            // completion handler for messages
            completionHandler(messageObject.totalMessages!.intValue, messageObject.messages as [MessageItemModel]?)
            
            }) { (operation, error) in
                SVProgressHUD.dismiss()
                //print("erorrrrrrr \(error)");
                
        }
        
    }
}
