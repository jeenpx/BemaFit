//
//  ExerciseUpdateResponse.swift
//  FlexYourMacros
//
//  Created by mini on 26/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class ExerciseUpdateResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var exerciselog_id: String?
    
    // message delete response mapping
    class var exerciseUpdateResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(ExerciseUpdateResponse.metaModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: exerciseUpdateResponseMapping, method: .PATCH, pathPattern: Constants.ServiceConstants.kUrlExercise, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func updateExercise(_ date: Date,exerciseId: String, completionHandler: @escaping (_ updatedStatus: Bool) -> ()) {
        // delete the exercise
        
        // set access token
        RestKitManager.setToken(true)
        
        let exerciseUpdateResponse = ExerciseUpdateResponse()
        exerciseUpdateResponse.exerciselog_id = exerciseId
        
        let request: NSMutableURLRequest = RestKitManager.shared().request(with: exerciseUpdateResponse, method: .PATCH, path: nil, parameters: nil)
        
        var err: NSError?
        let parameterDictionary = ["exercise_date" : date.stringValue("yyyy-MM-dd")]
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameterDictionary, options: JSONSerialization.WritingOptions(rawValue: 0))
        } catch let error as NSError {
            err = error
            request.httpBody = nil
        }
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult)in
            
            let exerciseUpdateResponse = mappingResult?.firstObject as! ExerciseUpdateResponse
            
            //print("respone status :\(exerciseUpdateResponse.meta?.responseStatus)")
            
            // check for success
            if exerciseUpdateResponse.meta?.responseCode != 200 {
                return;
            }
            // set up the completion handler with response
            completionHandler(true)
            
        }) { (operation, error) in
            completionHandler(false)
            //print("failed to log exercise with error \(error)")
        }
        
//        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) -> Void in
//            
//            let exerciseUpdateResponse = mappingResult.firstObject as! ExerciseUpdateResponse
//            
//            //print("respone status :\(exerciseUpdateResponse.meta?.responseStatus)")
//            
//            // check for success
//            if exerciseUpdateResponse.meta?.responseCode != 200 {
//                return;
//            }
//            
//            // set up the completion handler with response
//            completionHandler(updatedStatus: true)
//            
//            }) { (operation, error) in
//                
//                completionHandler(updatedStatus: false)
//                
//                //print("failed to log exercise with error \(error)")
//        })
        
        RestKitManager.shared().enqueue(operation)
      
        
    }
}
