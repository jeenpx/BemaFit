//
//  NewsFeedCommentsDeleteResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 12/2/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class NewsFeedCommentsDeleteResponse: NSObject {

    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var userId: String?
    var feedId: String?
    var commentId: String?
    
    // message delete response mapping
    class var commentsDeleteResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(NewsFeedCommentsDeleteResponse.metaModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: commentsDeleteResponseMapping, method: .DELETE, pathPattern: Constants.ServiceConstants.kNewsFeedCommentDeleteUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func deleteNewsFeedComment(_ newsFeedId: String, newsFeedCommentId: String, completionHandler: @escaping (_ responseStatus: String) -> ()) {
        // delete the news feed comment
        
        // set access token
        RestKitManager.setToken(true)
        
        let newsFeedCommentsDeleteResponse = NewsFeedCommentsDeleteResponse()
        newsFeedCommentsDeleteResponse.userId = AppConfiguration.sharedAppConfiguration.userDetails?.userId
        newsFeedCommentsDeleteResponse.feedId = newsFeedId
        newsFeedCommentsDeleteResponse.commentId = newsFeedCommentId
        
        RestKitManager.shared().delete(newsFeedCommentsDeleteResponse, path: nil, parameters: nil, success: { (operation, mappingResult) in
            
            //print("Success")
            let deleteResponseObject = mappingResult?.firstObject as! NewsFeedCommentsDeleteResponse
            
            if let responseMeta = deleteResponseObject.meta {
                
                // completion handler
                completionHandler(responseMeta.responseStatus!)
            }
            
            }) { (operation, error) in
                //print("error \(error)");
                
        }
        
    }

}
