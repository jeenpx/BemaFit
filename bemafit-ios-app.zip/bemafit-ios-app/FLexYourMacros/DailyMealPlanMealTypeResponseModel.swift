//
//  DailyMealPlanMealTypeResponseModel.swift
//  FlexYourMacros
//
//  Created by mini on 15/01/16.
//  Copyright © 2016 Digital Brand Group. All rights reserved.
//

import UIKit

class DailyMealType: NSObject {
    
    var id = ""
    var name = ""
    var isDefault = false
    var dailyMealTypeName = ""
    var mealType = MealType(name: "")
    
    init(dailyMealTypeName: String = "") {
        if dailyMealTypeName.characters.count > 0 {
            
            let tempMealTypeName = dailyMealTypeName
            let tempValue  = tempMealTypeName.substring(to: tempMealTypeName.characters.index(before: tempMealTypeName.endIndex))
            let lastCharacter = tempMealTypeName.substring(from: tempMealTypeName.characters.index(before: tempMealTypeName.endIndex))
              self.dailyMealTypeName = dailyMealTypeName //old Code changed Anand
//            self.dailyMealTypeName = &&tempValue + lastCharacter//hidden by Chandrachudh F22 Labs
        }
        else
        {
            self.dailyMealTypeName = dailyMealTypeName
        }
        
        
    }
    
    var foods = [Food]() {
        didSet {
            // set meal types
            foods.map { $0.dailyMealType = self }
        }
    }
    
    override var description: String { get { return "\n meal name \(self.name) meal id \(self.id)" } }
    override init() { }
    
    func addFood(_ food: Food) {
        food.dailyMealType = self
        foods.append(food)
    }
//
    func deleteFood(_ food: Food, shouldUpdateServer: Bool = true) {
        
        // remove locally if it asks for it
        if !shouldUpdateServer {
            foods.remove(food)
            return
        }
        
        // delete foodlog from server
        food.deleteFood { (deletedStatus) -> () in
            self.foods.remove(food)
        }
    }
    
    func toDictionary() -> [String: String] {
        return ["meal_type": name,"locale":(Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)! as! String]
    }
    
    class var objectMapping: RKObjectMapping {
        
        let mappingDictionary = ["id": "id", "name": "name", "is_default": "isDefault", "dmp_meal_type": "dailyMealTypeName"]
        
        let mapping = RKObjectMapping(for: self)
        mapping?.addAttributeMappings(from: mappingDictionary)
        return mapping!
    }
    
    class func showAlert(_ error: NSError?) {
        
        // no need to handle errors if we dont have any :)
        if error == nil { return }
        
        // get the tile and message for the alert
        if let userInfo = error?.userInfo {
            let title = userInfo["title"] as! String
            let message = userInfo["message"] as! String
            
            // show alert
            UIAlertView(title: &&title, message: &&message, delegate: nil, cancelButtonTitle: &&"cancel").show()
        }
    }
    
    class func fetchDailyMealTypeList(_ coreMealNo: String = "0", snackMealNo: String = "0", showHUD: Bool = false, completionHandler: @escaping (_ dailyMealTypes: [DailyMealType]) -> ()) {
        
        if showHUD {
            SVProgressHUD.show()
        }
        DailyMealPlanMealTypeResponseModel.fetchDailyMealTypeList(coreMealNo, snackMealNo: snackMealNo) { (dailyMealTypes) -> () in
            
            if showHUD {
                
                SVProgressHUD.dismiss()
                
            }
            completionHandler(dailyMealTypes)
        }
    }
}

func ==(lhs: DailyMealType, rhs: DailyMealType) -> Bool {
    return (lhs.id == rhs.id)
}

class DailyMealPlanMealTypeResponseModel: NSObject {
    
    var meta = MetaModel()
    var dailyMealTypes = [DailyMealType]()
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
        responseMapping?.addPropertyMapping(metaModelMapping)
        
        // foods mapping
        let mealTypeModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathdailyMealPlanTypeResult, toKeyPath: "dailyMealTypes", with: DailyMealType.objectMapping)
        responseMapping?.addPropertyMapping(mealTypeModelMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let dailyMealPlanMealTypeResponseModelDescriptor = RKResponseDescriptor(mapping: DailyMealPlanMealTypeResponseModel.responseMapping, method: .any, pathPattern: Constants.ServiceConstants.kDailyMealPlanTypes, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return dailyMealPlanMealTypeResponseModelDescriptor!
    }
    
    class func fetchDailyMealTypeList(_ coreMealNo: String = "0", snackMealNo: String = "0", completionHandler: @escaping (_ dailyMealTypes: [DailyMealType]) -> ()) {
        
        RestKitManager.setToken(true)
        let param = ["coremeal" : coreMealNo, "snacks" : snackMealNo,"locale" : "\((Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)!)"]
        
        RestKitManager.shared().getObjectsAtPath(Constants.ServiceConstants.kDailyMealPlanTypes, parameters: param, success: { (operation, mappingResult) in
            
            // map to correct datamodel
            let response = mappingResult?.firstObject as! DailyMealPlanMealTypeResponseModel
            
            // fire completion handler
            completionHandler(response.dailyMealTypes)
            
            }) { (operation, error) -> Void in
                // error
                //print("XXX failed to load meal type list with error \(error)")
        }
    }
}

