//
//  FormulaCell.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/17/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FormulaCell: UITableViewCell {
    
    @IBOutlet weak var labelFormula: UILabel!
    @IBOutlet weak var imageViewtickGreen: UIImageView!
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    }

}
