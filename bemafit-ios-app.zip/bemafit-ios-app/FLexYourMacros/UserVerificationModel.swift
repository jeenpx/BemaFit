//
//  UserFacebookModel.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 13/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class UserVerificationModel: NSObject {
    
    var emailVerified: Any?
    var userValid: Any?
    var verificationDaysRemaining: NSNumber?
    var userExists: Any?
    var userNameExists: Any?
    var facebookIdExists: Any?
    var emailExists: Any?
    
    var isVerified: Bool {
        return userValid as? Bool ?? false
    }
    
    class var objectMapping: RKObjectMapping {
        let dietMapping = RKObjectMapping(for: self)
        dietMapping?.addAttributeMappings(from: mappingDictionary)
        return dietMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["user_exists": "userExists", "email_verified":"emailVerified", "user_valid":"userValid", "verification_days_remaining":"verificationDaysRemaining", "username_exists":"userNameExists", "facebook_exists": "facebookIdExists", "email_exists": "emailExists"])
    }
  
}
