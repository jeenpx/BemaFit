//
//  AppConfiguration.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 10/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _AppConfiguration = AppConfiguration()

class AppConfiguration: NSObject {
    
    var activityLevels: [ActivityLevelModel]  {
        
        let locale =  (Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)! as! String

        return (locale == "es" ? activityLevels_spanish : activityLevels_english)!
    }
    var nutritionPlans: [NutritionPlanModel] {
        
        let locale =  (Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)! as! String

        return (locale == "es" ? nutritionPlans_spanish : nutritionPlans_english)!
    }
    var goals: [GoalModel] {
        
        let locale =  (Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)! as! String

        return (locale == "es" ? goals_spanish : goals_english)!
    }
    var businessCategories: [BusinessCategoryModel]? {
        
        let locale =  (Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)! as! String
       
        return (locale == "es" ? businessCategories_spanish : businessCategories_english)!
    }
    var mealCategories: [FoodCategory]? {
        
        let locale =  (Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)! as! String

        return (locale == "es" ? mealCategories_spanish : mealCategories_english)!
    }
    
    //spanish app configuration
    var activityLevels_spanish: [ActivityLevelModel]?
    var nutritionPlans_spanish: [NutritionPlanModel]?
    var goals_spanish: [GoalModel]?
    var businessCategories_spanish: [BusinessCategoryModel]?
    var mealCategories_spanish: [FoodCategory]?
    
    //english app configuration
    var activityLevels_english: [ActivityLevelModel]?
    var nutritionPlans_english: [NutritionPlanModel]?
    var goals_english: [GoalModel]?
    var businessCategories_english: [BusinessCategoryModel]?
    var mealCategories_english: [FoodCategory]?
    
    var refreshingToken: Bool = false

    var isLog: Bool = false
    
    var masterDataModelEnglish: MasterDataModel? {
       
        didSet {
          
            activityLevels_english = self.masterDataModelEnglish?.activityLevels
            nutritionPlans_english = self.masterDataModelEnglish?.nutritionPlans
            goals_english = self.masterDataModelEnglish?.goals
            businessCategories_english = self.masterDataModelEnglish?.businessCategory
            mealCategories_english = self.masterDataModelEnglish?.mealCategory
        }
    }
    
    var masterDataModelSpanish: MasterDataModel? {
      
        didSet {
            
            activityLevels_spanish = self.masterDataModelSpanish?.activityLevels
            nutritionPlans_spanish = self.masterDataModelSpanish?.nutritionPlans
            goals_spanish = self.masterDataModelSpanish?.goals
            businessCategories_spanish = self.masterDataModelSpanish?.businessCategory
            mealCategories_spanish = self.masterDataModelSpanish?.mealCategory
        }
    }
    
    var userDetails: UserDetailModel? {
        didSet {
            //save user id in user credentials
            let userDefaults = UserDefaults.standard
            userDefaults.set(userDetails!.userId!, forKey: "user_id")
            userDefaults.set(userDetails!.userEmail!, forKey: "user_email")
            userDefaults.set(userDetails?.userDateofJoining, forKey: "user_date_added")
            userDefaults.synchronize()
        }
    }
    var userDiet: UserDietModel?
    var userVerification: UserVerificationModel?
    var userCredential: AccessTokenModel?
    var isFacebookUser: Bool = false
    var accessToken: String = ""
    var pushNotificationInfo: [AnyHashable: Any]?
    var userEmail = ""
    var userFoundInvalid = false
    
    class var sharedAppConfiguration: AppConfiguration {
        return _AppConfiguration
    }
    
    class func refreshAccessTokenDetails(_ completionHandler: @escaping (_ accessCredential: AccessTokenModel?) -> ()) {
       
        let userDefaults = UserDefaults.standard
        // get the saved user id
        _ = userDefaults.object(forKey: "user_id") as! String
        let refreshToken = userDefaults.object(forKey: "refreshtoken") as! String
        AccessTokenRefreshResponse.refreshToken(refreshToken) { (accessCredential) -> () in
            completionHandler(accessCredential!)
        }
    }
    
    class func refreshUserDetails(_ showProgressHUD: Bool = false, completionHandler: @escaping (_ refreshedUserDetails: Bool) -> ()) {
                
        let userDefaults = UserDefaults.standard
        // get the saved user id
        let userId = userDefaults.object(forKey: "user_id") as! String
        
        UserProfileresponse.getUserProfileDetails(userId,showHUD: showProgressHUD,  completionHandler: { (userDiet, userDetails) -> () in
            
            
            AppConfiguration.sharedAppConfiguration.userDetails = userDetails
            
            AppConfiguration.sharedAppConfiguration.userDiet = userDiet

            completionHandler(true)
        })
    }
    
    class func loadAllMAsterData(_ completionHandler: @escaping (_ loadedmasterData: Bool) -> ()) {
        
        MasterDataResponse.fetchMasterData { (masterDataModelEnglish, masterDataModelSpanish) in
            AppConfiguration.sharedAppConfiguration.masterDataModelEnglish = masterDataModelEnglish
            AppConfiguration.sharedAppConfiguration.masterDataModelSpanish = masterDataModelSpanish
            
            completionHandler(true)
        }
//        MasterDataResponse.fetchMasterData { (masterDataModelEnglish, masterDataModelSpanish) -> () in
//            
//            AppConfiguration.sharedAppConfiguration.masterDataModelEnglish = masterDataModelEnglish
//            AppConfiguration.sharedAppConfiguration.masterDataModelSpanish = masterDataModelSpanish
//            
//            completionHandler(true)
//        }
    }
    
    
    
}
