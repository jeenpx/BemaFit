//
//  ProfileViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 18/02/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

enum ProfileViewMode: String {
    case MyProfile = "profile"
    case Follow = "follow"
    case Unfollow = "unfollow"
    case SendFriendRequest = "sendfriendrequest"
    case RequestPending = "requestpending"
    case RequestReceived = "requestreceived"
}

class ProfileViewController: UITableViewController, UITableViewDragLoadDelegate, NewsFeedCellDelegate,EnlargeImageNewsFeedDelegate {
    
    @IBOutlet weak var viewProfileDetails: UIView!
    @IBOutlet var navigationTitleItem: UINavigationItem!
    @IBOutlet weak var buttonProfile: UIButton!
    @IBOutlet var tableViewProfileFeeds: UITableView!
    @IBOutlet weak var labelWebsite: UILabel!
    @IBOutlet weak var imageViewUserProfile: UIImageView!
    @IBOutlet weak var labelFollowersCount: UILabel!
    @IBOutlet weak var labelFollowingCount: UILabel!
    @IBOutlet weak var labelDescrip: UILabel!
    var refreshPage:Bool = true
    var pageMeta = PageMetaModel()
    
    var profileViewMode: ProfileViewMode = .MyProfile {
        didSet {
            switch profileViewMode {
            case .MyProfile:
                buttonProfile.setTitle(&&"edit_profile", for: UIControlState())
                buttonProfile.backgroundColor = UIColor(red: 114.0/255.0, green: 114.0/255.0, blue: 114.0/255.0, alpha: 1.0)
            case .Follow:
                buttonProfile.setTitle(&&"unfollow", for: UIControlState())
                buttonProfile.backgroundColor = UIColor(red: 233.0/255.0, green: 12.0/255.0, blue: 1.0/255.0, alpha: 1.0)
            case .Unfollow:
                buttonProfile.setTitle(&&"follow", for: UIControlState())
                buttonProfile.backgroundColor = UIColor(red: 57.0/255.0, green: 181.0/255.0, blue: 74.0/255.0, alpha: 1.0)
            case .SendFriendRequest:
                buttonProfile.setTitle(&&"send_friend_request", for: UIControlState())
                buttonProfile.backgroundColor = UIColor(red: 57.0/255.0, green: 181.0/255.0, blue: 74.0/255.0, alpha: 1.0)
            case .RequestPending:
                buttonProfile.setTitle(&&"pending", for: UIControlState())
                buttonProfile.backgroundColor = UIColor(red: 207.0/255.0, green: 207.0/255.0, blue: 207.0/255.0, alpha: 1.0)
            case .RequestReceived:
                buttonProfile.setTitle(&&"accept", for: UIControlState())
                buttonProfile.backgroundColor = UIColor(red: 40.0/255.0, green: 141.0/255.0, blue: 255.0/255.0, alpha: 1.0)
            }
        }
    }
    
    // user id : sameuser /different user
    var userId = ""
    
    var user = UserDetailModel() {
        didSet {
            
            viewProfileDetails.isHidden = false
            navigationTitleItem.title = user.userUserName
            // configure based on user
            labelFollowersCount.text = user.followers
            labelFollowingCount.text = user.following
            labelWebsite.text = user.userWebsite
            labelDescrip.text = user.userDescription as? String ?? ""
            let profilePhotoString = user.userProfilePhoto as? String ?? ""
            imageViewUserProfile.setImageWith(URL(string:profilePhotoString ), placeholderImage: UIImage(named:"PlaceHolderProfilePic")!)
            
            // current user
            if user.userId == AppConfiguration.sharedAppConfiguration.userDetails?.userId {
                profileViewMode = .MyProfile
            }
            else {
                
                // public users
                if user.userType == "Public" {
                    profileViewMode = user.followStatus == "Yes" ? .Follow : .Unfollow
                }
                    
                    // private users
                else {
                    
                    switch (user.friendStatus!) {
                        
                    case "nonFriend" :
                        profileViewMode = .SendFriendRequest
                        
                    case "friendRequestSent" :
                        profileViewMode = ProfileViewMode.RequestPending
                        
                    case "friends" :
                        profileViewMode = ProfileViewMode.Follow
                        
                    case "friendRequestReceived" :
                        profileViewMode = ProfileViewMode.RequestReceived
                        
                    default :
                        break
                    }
                }
            }
            
            setAutoLayResizeHeader()
        }
    }
    
    func setAutoLayResizeHeader() {
        
        labelDescrip.translatesAutoresizingMaskIntoConstraints = false
        
        var newFrame = viewProfileDetails.frame
        
        viewProfileDetails?.setNeedsUpdateConstraints()
        viewProfileDetails?.updateConstraintsIfNeeded()
        viewProfileDetails?.bounds = CGRect(x: 0.0, y: 0.0, width: tableViewProfileFeeds.bounds.width, height: viewProfileDetails!.bounds.height)
        
        viewProfileDetails?.setNeedsLayout()
        viewProfileDetails?.layoutIfNeeded()
        
        labelDescrip.preferredMaxLayoutWidth = labelDescrip.bounds.width
        labelDescrip.setNeedsUpdateConstraints()
        
        // Get the actual height required for the cell's contentView
        let height = viewProfileDetails.systemLayoutSizeFitting(UILayoutFittingCompressedSize).height
        
        newFrame.size.height =  height + 1 //labelDescrip.frame.size.height + newSize.height
        viewProfileDetails.frame = newFrame
        
        self.tableViewProfileFeeds.tableHeaderView = viewProfileDetails
    }
    // list of news feeds
    var newsFeeds = [NewsFeed]() {
        didSet {
            tableView.reloadData()
        }
    }
    
    struct Storyboard {
        struct Nibs {
            static let NewsFeedCell = "NewsFeedCell"
        }
        struct CellIdentifiers {
            static let NewsFeedCellIdentifier = "kNewsFeedCell"
            static let kPrivarteCell = "kPrivateCell"
        }
    }
    
    
    override func  viewWillAppear(_ animated: Bool) {
        
        // reset page meta data
        if self.refreshPage{
            pageMeta = PageMetaModel()
            
            // clear array
            newsFeeds.removeAll()
            
            // fetch news feeds and reload table
            NewsFeed.fetchNewsFeeds(userId ,pageMeta: pageMeta){ (newsFeeds, pageMeta) -> () in
                self.newsFeeds = newsFeeds
                self.pageMeta = pageMeta
            }
        }
        self.refreshPage = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set the empty text
        buttonProfile.setTitle(" ", for: UIControlState())
        self.tableViewProfileFeeds.tableHeaderView = nil
        
        // hides the header view before loading the user details
        viewProfileDetails.isHidden = true
        
        // configure table
        setupTable()
        
        // for updating the details
        setUpdateListener()
        
        NotificationCenter.default.addObserver(self,
                                                         selector: #selector(ProfileViewController.updateProfileDetails(_:)),
                                                         name: NSNotification.Name(rawValue: Constants.updateUserProfile),
                                                         object: nil)
        
        configureView()
        
        
        
    }
    
    override func viewDidLayoutSubviews() {
        
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        if self.tableViewProfileFeeds.tableHeaderView == nil {
            
            labelDescrip.translatesAutoresizingMaskIntoConstraints = false
            
            var newFrame = viewProfileDetails.frame
            
            viewProfileDetails?.setNeedsUpdateConstraints()
            viewProfileDetails?.updateConstraintsIfNeeded()
            viewProfileDetails?.bounds = CGRect(x: 0.0, y: 0.0, width: tableViewProfileFeeds.bounds.width, height: viewProfileDetails!.bounds.height)
            
            viewProfileDetails?.setNeedsLayout()
            viewProfileDetails?.layoutIfNeeded()
            
            labelDescrip.preferredMaxLayoutWidth = labelDescrip.bounds.width
            labelDescrip.setNeedsUpdateConstraints()
            
            // Get the actual height required for the cell's contentView
            let height = viewProfileDetails.systemLayoutSizeFitting(UILayoutFittingCompressedSize).height
            
            newFrame.size.height =  height + 1//labelDescrip.frame.size.height + newSize.height
            viewProfileDetails.frame = newFrame
            self.tableViewProfileFeeds.tableHeaderView = viewProfileDetails
            
        }
    }
    
    func setUpdateListener() {
        
    }
    
    func updateProfileDetails(_ notification: Notification) {
        configureView()
        
        // reset page meta data
        pageMeta = PageMetaModel()
        
        // fetch news feeds and reload table
        NewsFeed.fetchNewsFeeds(userId ,pageMeta:pageMeta){ (newsFeeds ,pageMeta) -> () in
            self.newsFeeds = newsFeeds
            self.pageMeta =  pageMeta
        }
        
    }
    
    
    func setupTable() {
        
        tableView.register(UINib(nibName: Storyboard.Nibs.NewsFeedCell, bundle: nil), forCellReuseIdentifier: Storyboard.CellIdentifiers.NewsFeedCellIdentifier)
        //   tableView.estimatedRowHeight = 230.0
        
        // set delegate for pull to refresh and load more
        tableViewProfileFeeds.setDragDelegate(self, refreshDatePermanentKey: "kFriend")
        
        // hide pull to refresh
        tableViewProfileFeeds.showRefreshView = false
        
        // show load more
        tableViewProfileFeeds.showLoadMoreView = true
        
        // tableview footer release text
        tableViewProfileFeeds.footerReleaseText = &&"release_to_load_more_status"
        
        // tableview footer pull up text
        tableViewProfileFeeds.footerPullUpText = &&"pull_down_to_load_more_status"
        
        //tableview footer loading text
        tableViewProfileFeeds.footerLoadingText = &&"loading_status"
    }
    
    func configureView() {
        // get the user info based XXXX pass the friendId below
        UserProfileresponse.getUserProfileDetails(userId) { (userDiet, user) in
            self.user = user
        }
        
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        // restricting the newsfeeds for private users : only public user and same user can see the newsfeeds
        if user.userType == "Public" || ProfileViewMode.MyProfile == profileViewMode || (user.userType == "Private" && user.friendStatus == "friends"){
            return newsFeeds.count
        } else {
            return 0
        }
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header: UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView //recast your view as a UITableViewHeaderFooterView
        header.contentView.backgroundColor = UIColor.grayColorDirectory()//make the background color light blue
        header.alpha = 1 //make the header transparent
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat((newsFeeds[indexPath.row ] as NewsFeed).contentHeight)
        
    }
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10.0
    }
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 230.0
    }
    
    
    //    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
    //        return 230.0
    //    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        (cell as? NewsFeedCell)?.newsFeed = newsFeeds[indexPath.row]
        
        cell.layoutIfNeeded()
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.NewsFeedCellIdentifier) as! NewsFeedCell
        
        // configure cell
        cell.newsFeed = newsFeeds[indexPath.row]
        cell.shareButton.isHidden = true
        cell.newsFeedCellDelegate = self
        cell.enlargeImageNewsFeedDelegate = self
        return cell
    }
    func enlargeImageView(_ selectedCell: NewsFeedCell, imageViewNewsFeed: UIImageView) {
        
        let imageInfo = JTSImageInfo()
        imageInfo.image = imageViewNewsFeed.image
        
        // imageInfo.imageURL = NSURL(string: food.image)
        imageInfo.referenceRect = imageViewNewsFeed.frame
        imageInfo.referenceView = imageViewNewsFeed.superview
        let imageViewController = JTSImageViewController(imageInfo: imageInfo, mode: .image, backgroundStyle: .scaled)
        
        // present the view controller.
        self.refreshPage = false
        imageViewController?.show(from: self, transition: .fromOriginalPosition)
        
    }
    
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        if user.userType == "Public" || ProfileViewMode.MyProfile == profileViewMode || (user.userType == "Private" && user.friendStatus == "friends") {
            return 0.0
        }
        return 200.0
    }
    
    
    override func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        
        if (user.userType == "Public" || ProfileViewMode.MyProfile == profileViewMode || (user.userType == "Private" && user.friendStatus == "friends")) {
            return UIView(frame: CGRect.zero)
        }
        
        let cell: UITableViewCell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.kPrivarteCell)!
        
        return cell
    }
    // load more funcationality
    func dragTableDidTriggerLoadMore(_ tableView: UITableView!) {
        
        if !pageMeta.isValid {
            Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(ProfileViewController.finishLoadMore), userInfo: nil, repeats: false)
            return
        }
        
        NewsFeed.fetchNewsFeeds(userId, offset: newsFeeds.count, pageMeta:pageMeta) { (newsFeeds, pageMeta) -> () in
            self.newsFeeds += newsFeeds
            self.pageMeta = pageMeta
            self.finishLoadMore()
        }
        
    }
    
    func dragTableLoadMoreCanceled(_ tableView: UITableView!) {
        // called when the load more is cancelled
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(ProfileViewController.finishLoadMore), object: nil)
    }
    
    func finishLoadMore() {
        // to stop the load more and populate the tableview with new items
        //   getFriendsList(friendModelArray.count, limit: 5, searchKeyword: "",)
        tableViewProfileFeeds.finishLoadMore()
        tableViewProfileFeeds.reloadData()
        
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didSelectHashTag hashTag: String) {
        performSegue(withIdentifier: "kHashTagSegue", sender: hashTag)
        
        
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didSelectUser userId: String) {
        
        if self.userId != userId {
            let profileViewController = storyboard?.instantiateViewController(withIdentifier: "kProgressVC") as! ProfileViewController
            profileViewController.userId = userId
            navigationController?.pushViewController(profileViewController, animated: true)
        }
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didSelectBusinessDirectory businessDirectoryId: String) {
        DirectoryDetailViewController.loadDirectoryDetail(businessDirectoryId, fromViewcontroller: self)
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didLikeNewsFeed like: Bool) {
        // newsFeedCell.newsFeed.like(like)
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didInspireNewsFeed inspire: Bool) {
        //  newsFeedCell.newsFeed.inspire(inspire)
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didDeleteNewsFeed delete: Bool) {
        if delete {
            let cellIndexPath = tableView.indexPath(for: newsFeedCell)
            let feedId = newsFeeds[cellIndexPath!.row].id
            
            let reachability = appDelegate!.internetReachable
            if !reachability {
                // no internet
                
                // alert
                AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                return
            }
            
            // delete the feed
            
            
            UIAlertView.show(withTitle: &&"delete_confirmation_title", message: &&"delete_confirmation_message", cancelButtonTitle: &&"ok_button_title", otherButtonTitles: [&&"cancel_button_title"], tap: { (alertview : UIAlertView, buttonIndex : Int) in
                
                
                if buttonIndex == alertview.cancelButtonIndex{
                    
                    NewsFeedDeleteResponse.deleteNewsFeed(feedId, completionHandler: { (responseStatus) -> () in
                        if responseStatus == "OK" {
                            let feed = self.newsFeeds.filter({$0.id == feedId})
                            
                            // remove the feed
                            self.newsFeeds.remove(feed[0])
                            
                            // reload tableview
                            self.tableView.reloadData()
                        }
                    })
                }
            })
            
            
        }
    }
    
    func buttonActionComments(_ newsFeed: NewsFeed) {
        performSegue(withIdentifier: "kProfileCommentsSegue", sender: newsFeed)
        
    }
    
    override func  prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "kHashTagSegue" {
            let hashTagViewController = segue.destination as! HashTagViewController
            hashTagViewController.hashTag = sender as! String
        }
        if segue.identifier == "kProfileSettings" {
            let settingsViewController = segue.destination as! SettingsViewController
            settingsViewController.isProfileEditable = true
        }
        else if segue.identifier == "kSegueFollowing" {
            if let followingViewController = segue.destination as? FollowingViewController{
                followingViewController.userId = user.userId!
                followingViewController.title = &&"followg"
                followingViewController.isFollow = false
            }
        }
        else if segue.identifier == "kProfileCommentsSegue" {
            let newsFeedCommentsViewController = segue.destination as? NewsFeedCommentsViewController
            newsFeedCommentsViewController!.newsFeed = (sender as? NewsFeed)!
        }
        else if segue.identifier == "kSegueFollower" {
            if let followingViewController = segue.destination as? FollowingViewController{
                followingViewController.userId = user.userId!
                followingViewController.title = &&"followers"
                followingViewController.isFollow = true
            }
        }
    }
    
    
    
    
    @IBAction func buttonActionProfile(_ sender: UIButton) {
        
        switch(profileViewMode) {
        case ProfileViewMode.MyProfile :
            //print("Myprofile")
            self.performSegue(withIdentifier: "kProfileSettings", sender: nil)
            
        case ProfileViewMode.Follow :
            UnfollowUserResponse.unfollowUser(userId, completionHandler: { (response) -> () in
                let unFollowUserResponse = response
                //print("respone code :\(unFollowUserResponse.metaModel?.responseCode)")
                //print("respone status :\(unFollowUserResponse.metaModel?.responseStatus)")
                if unFollowUserResponse.metaModel?.responseCode == 200 {
                    self.profileViewMode = .Unfollow
                    self.configureView()
                }
            })
            
        case ProfileViewMode.Unfollow :
            FollowUserResponse.followUser(userId, completionHandler: { (response) -> () in
                let followUserResponse = response
                //print("respone code :\(followUserResponse.metaModel?.responseCode)")
                //print("respone status :\(followUserResponse.metaModel?.responseStatus)")
                if followUserResponse.metaModel?.responseCode == 200 {
                    self.profileViewMode = .Follow
                    self.configureView()
                }
                
            })
            
        case ProfileViewMode.RequestPending :
            print("Pending")
            break
            
        case ProfileViewMode.SendFriendRequest :
            InviteFriendResponse.sendInvitationFriend(user.userId!, completionHandler: { (response) -> () in
                let inviteFriendResponse = response
                // success code = 200 , Invitation send
                if inviteFriendResponse.metaModel?.responseCode == 200 {
                    self.profileViewMode = .RequestPending
                }
            })
            
        case ProfileViewMode.RequestReceived :
            //print("Request recieved")
            // accept the friend request
            FriendsRequestResponse.sendFriendRequest(user.userId!,status: "Accepted", completionHandler: { (response) -> () in
                let response = response
                //check for success
                if response.metaModel?.responseCode == 200 {
                    // response successful
                    // set the provision for unfollow
                    //self.profileViewMode = .Unfollow
                    self.configureView()
                    
                } else {
                    //print("Unfavourable --response code  \(response.metaModel?.responseCode)")
                }
            })
            
        }
    }
    func buttonShare(_ shareContent: FacebookShareModel) {
        
    }
    
}
