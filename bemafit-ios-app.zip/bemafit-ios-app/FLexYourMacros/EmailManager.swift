//
//  EmailManager1.swift
//  FlexYourMacros
//
//  Created by DBG on 29/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import MessageUI


typealias onMailFinished = (_ controller: MFMailComposeViewController, _ result: MFMailComposeResult, _ error: NSError?) -> ()

class EmailManager :NSObject, MFMailComposeViewControllerDelegate {
    
    var finishBlock: onMailFinished?
    
    class var sharedInstance: EmailManager {
        struct Static {
            static let instance = EmailManager()
        }
        return Static.instance
    }
    //sending email
    fileprivate func sendMail(_ attachmentName : String,fileName : String, mailSubject : String = "Daily-Meal-Plan", mailContent : String = "Hey ,Checkout my daily meal plan.", vController:UIViewController, withCompletionblock  finishBlock:@escaping onMailFinished) {
        
        self.finishBlock = finishBlock
        
        let nsDocumentDirectory = FileManager.SearchPathDirectory.documentDirectory
        let nsUserDomainMask = FileManager.SearchPathDomainMask.userDomainMask
        let arrayPaths:NSArray = NSSearchPathForDirectoriesInDomains(nsDocumentDirectory,nsUserDomainMask, true) as NSArray
        let path:NSString = arrayPaths.object(at: 0) as! NSString
        let pdfFileName = path.appendingPathComponent(fileName as String)
        let fileData = try? Data(contentsOf: URL(fileURLWithPath: pdfFileName))
        let picker = MFMailComposeViewController()
        
        if (MFMailComposeViewController.canSendMail() == true) {
            picker.mailComposeDelegate = self
            picker.setSubject(mailSubject)
            picker.setMessageBody(mailContent, isHTML: false)
            picker.addAttachmentData(fileData!, mimeType:"application/pdf",fileName:attachmentName)
            vController.present(picker, animated: true, completion: nil)
        }
        else {
            AlertManager.showAlert("Unable to send a mail", message: "Please configure mail in your device")
        }
    }
    
    
    
    
    class func send1Mail(_ attachmentName : String,fileName : String, mailSubject : String = "Daily-Meal-Plan", mailContent : String = "Hey ,Checkout my daily meal plan.", vController:UIViewController, withCompletionblock  finishBlock:@escaping onMailFinished){
        EmailManager.sharedInstance.sendMail(attachmentName, fileName: fileName, mailSubject: mailSubject, mailContent: mailContent, vController: vController, withCompletionblock: finishBlock)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        self.finishBlock?(controller, result, error as NSError?)
        controller.dismiss(animated: true, completion: nil)
        
    }
    
    
}
