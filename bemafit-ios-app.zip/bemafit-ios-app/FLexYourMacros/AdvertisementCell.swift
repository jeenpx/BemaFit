//
//  AdvertisementCell.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 10/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol AdvertisementCellDelegate {
   
    func clickedOnAd(_ urlString:String)
    
}

class AdvertisementCell: UITableViewCell {
    
    var advertisementCellDelegate:AdvertisementCellDelegate?
    
    var advertisement: Advertisement! {
        didSet {
            configureView()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func configureView() {
        var activityIndicator = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.white)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 25, height: 25)
        activityIndicator.startAnimating()
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.color = UIColor.clear
        addSubview(activityIndicator)
  
        backgroundColor = UIColor.clear
        
        // constrain for the activity indicator
        let constX:NSLayoutConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.centerX, relatedBy: NSLayoutRelation.equal, toItem: self, attribute: NSLayoutAttribute.centerX, multiplier: 1.0, constant: 0.0);
        self.addConstraint(constX);
        
        let constY:NSLayoutConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.centerY, relatedBy: NSLayoutRelation.equal, toItem: self, attribute: NSLayoutAttribute.centerY, multiplier: 1.0, constant: 0.0);
        self.addConstraint(constY);
        
        // check if ad image is empty
        if advertisement.shouldDisplayAdvertisement {
            activityIndicator.color = UIColor.white
        }else {
            activityIndicator.color = UIColor.clear
        }
        
        // add advertisement image
        if let imageURL = advertisement.imageURL {
            
            let imageView = UIImageView(frame: frame)
            imageView.setImageWith(imageURL as URL!, placeholderImage: nil)
            imageView.contentMode = UIViewContentMode.scaleToFill

            //imageView.image = UIImage(named: "DashboardCellTop")
            
            addSubview(imageView)
            
            // set constraints for the imageview
            imageView.translatesAutoresizingMaskIntoConstraints = false
            self.addConstraints([NSLayoutConstraint(item: imageView, attribute: .left, relatedBy: .equal,
                toItem: self, attribute: .left, multiplier: 1.0, constant: 5.0),
                NSLayoutConstraint(item: imageView, attribute: .right, relatedBy: .equal,
                    toItem: self, attribute: .right, multiplier: 1.0, constant: -5.0), NSLayoutConstraint(item: imageView, attribute: .bottom, relatedBy: .equal,
                        toItem: self, attribute: .bottom, multiplier: 1.0, constant: -5.0), NSLayoutConstraint(item: imageView, attribute: .top, relatedBy: .equal,
                            toItem: self, attribute: .top, multiplier: 1.0, constant: 10.0)])
            
            imageView.layer.masksToBounds = true
            imageView.layer.cornerRadius = 10
            
            // add tap gesture
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(AdvertisementCell.imageViewTapped(_:)))
            imageView.isUserInteractionEnabled = true
            imageView.addGestureRecognizer(tapGesture)
        }

    }
    
    func imageViewTapped(_ tapGestureRecognizer: UITapGestureRecognizer) {
        // append http and open the url
        
        self.advertisementCellDelegate?.clickedOnAd(advertisement.content!)
    }
}
