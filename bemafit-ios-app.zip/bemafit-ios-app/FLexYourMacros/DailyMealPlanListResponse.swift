//
//  DailyMealPlanListItems.swift
//  FlexYourMacros
//
//  Created by DBG on 09/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import Foundation

//DMP list model
class DailyMealPlanListModel: NSObject {
    
    var guId: String = ""
    var name: String = ""
    var addedDate: String = ""
    var updatedDate: String = ""
    var username: String = ""
    var profilePhoto: String = ""
    // use the added username always : suppose if a user share a meal
    var addedUsername: String = ""
    var addedUserId: String = ""
  
    class var objectMapping: RKObjectMapping {
        let dmpListMapping = RKObjectMapping(for: self)
        dmpListMapping?.addAttributeMappings(from: mappingDictionary)
        return dmpListMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["guid":"guId", "name":"name", "added_date":"addedDate", "updated_date":"updatedDate", "username": "username", "user_profile_photo":"profilePhoto","added_username":"addedUsername","added_userid":"addedUserId"])
    }
}

private let _DailyMealPlanListResponse = DailyMealPlanListResponse()

class DailyMealPlanListResponse: NSObject {
    
    var metaModel = MetaModel()
    var dailyMealPlanListResults = [DailyMealPlanListModel]()
    
    class var sharedDailyMealPlanListResponse: DailyMealPlanListResponse {
        return _DailyMealPlanListResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(DailyMealPlanListResponse.metaModelKeyMapping)
        
        // give reference to FoodListMapping
        responseMapping?.addPropertyMapping(DailyMealPlanListResponse.dailyMealPlanListModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var dailyMealPlanListModelKeyMapping : RKRelationshipMapping {
        
        // food log model is used since both auto suggested food and logged food are of same model
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathDailyMealPlanListResult, toKeyPath: "dailyMealPlanListResults", with: DailyMealPlanListModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kDailyMealPlanList, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func fetchDailyMealPlanList( _ offset:Int ,limit:Int ,showHUD: Bool = false,completionHandler:@escaping (_ dailyMealPlanList: [DailyMealPlanListModel], _ error: NSError?)->()) {
        
        RestKitManager.setToken(true)
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["offset": "\(offset)", "limit": "\(limit)"]
        }
        
        if showHUD {
            SVProgressHUD.show()
        }
        // get the objects from the path login
        RestKitManager.shared().getObjectsAtPath(Constants.ServiceConstants.kDailyMealPlanList, parameters: parameterDictionary, success: { (operation, mappingResult) in
            
            // map to correct datamodel
            let response = mappingResult?.firstObject as! DailyMealPlanListResponse
            
            if showHUD {
                SVProgressHUD.dismiss()
            }
            
            //print("respone code :\(response.dailyMealPlanListResults.count)")
            
            if response.metaModel.responseCode != 200 {
                let error = NSError(domain: "FYM.DailyMealPlan", code: 1001, userInfo: ["title": "error", "message": "alert_auto_suggest_list_message"])
                
                // fire completion handler
                completionHandler([], error)
                
            }
            else {
                // fire completion handler
                completionHandler(response.dailyMealPlanListResults, nil)
            }
            
            }) { (operation, error) -> Void in
                // error
                let networkError = NSError(domain: "FYM.AutoSuggestFood", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
                
                // fire completion handler
                completionHandler([], networkError)
        }
    }
    
    
}
