//
//  ExerciseTypeResponse.swift
//  FlexYourMacros
//
//  Created by mini on 25/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class ExerciseDetails: NSObject {
    
    var exerciseAmount: String = ""
    var exerciseCalorieBurned: String = ""
    var exerciseSets: String = ""
    var exerciseReps: String = ""
    var exerciseWeight: String = ""
    var exerciseDistance: String = ""
    
    class var objectMapping: RKObjectMapping {
        let exerciseMapping = RKObjectMapping(for: self)
        exerciseMapping?.addAttributeMappings(from: mappingDictionary)
        return exerciseMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["Exercise Amount":"exerciseAmount", "Calories Burned":"exerciseCalorieBurned", "Number of Sets":"exerciseSets", "Reps/Set":"exerciseReps", "Reps/ Weight per Set":"exerciseWeight", "Distance": "exerciseDistance"])
    }

}
//exercise model
class ExerciseTypeModel: NSObject {
    
    var exerciseId: String = ""
    var exerciseGuId: String = ""
    var exerciseName: String = ""
    var exerciseValue: String = ""
    var exerciseType: String = ""
    var caloriesPerMinute: String = ""
    var caloriesPerHour: String = ""

    var exerciseDetails: ExerciseDetails = ExerciseDetails()
    
    class var objectMapping: RKObjectMapping {
        let exerciseMapping = RKObjectMapping(for: self)
        exerciseMapping?.addAttributeMappings(from: mappingDictionary)
        exerciseMapping?.addPropertyMapping(ExerciseTypeModel.exerciseDetailModelKeyMapping)
        return exerciseMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["id":"exerciseId", "guid":"exerciseGuId", "name":"exerciseName", "met_value":"exerciseValue", "exercise_type":"exerciseType", "cal_burned_min":"caloriesPerMinute", "cal_burned_hour":"caloriesPerHour"])
    }
    
    fileprivate class var exerciseDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathExerciseDetail, toKeyPath: "exerciseDetails", with: ExerciseDetails.objectMapping)
    }
    
}

private let _ExerciseTypeResponse = ExerciseTypeResponse()

class ExerciseTypeResponse: NSObject {
    
    var metaModel: MetaModel?
    var exerciseTypeResults: [ExerciseTypeModel]?
    
    class var sharedExerciseTypeResponse: ExerciseTypeResponse {
        return _ExerciseTypeResponse
    }
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(ExerciseTypeResponse.metaModelKeyMapping)
        
        // give reference to ProgressTypeMapping
        responseMapping?.addPropertyMapping(ExerciseTypeResponse.exerciseTypeModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var exerciseTypeModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathExerciseTypeResult, toKeyPath: "exerciseTypeResults", with: ExerciseTypeModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: responseMapping, method: .GET, pathPattern: Constants.ServiceConstants.ExerciseUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func fetchExerciseTypes(_ offset: String,name: String,type: String, completionHandler:@escaping (_ exercises: [Exercise])->()) {
        

        RestKitManager.setToken(true)
        // get the objects from the path login
        RestKitManager.shared().getObjectsAtPath(Constants.ServiceConstants.ExerciseUrl, parameters: ["offset" : offset,"limit" : "30", "locale" : "\((Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)!)", "name" : name, "type": type], success: { (operation, mappingResult) in
            
            // get the user response
            let progressResponse = mappingResult?.firstObject as! ExerciseTypeResponse
            
            //check for success
            if progressResponse.metaModel?.responseCode != 200 {
                return;
            }
            
            var exerciseList = [Exercise]()
            exerciseList = progressResponse.exerciseTypeResults!.map { (anExercise: ExerciseTypeModel) in
                
                var exercise = Exercise(name: "")
                if anExercise.exerciseType == ExerciseTypeId.Strength.rawValue {
                    
                    let strengthExercise: StrengthExercise = StrengthExercise(name: anExercise.exerciseName)
                    strengthExercise.sets = anExercise.exerciseDetails.exerciseSets.doubleValue
                    strengthExercise.reps = anExercise.exerciseDetails.exerciseReps.doubleValue
                    strengthExercise.weight = anExercise.exerciseDetails.exerciseWeight.doubleValue
                    strengthExercise.caloriesBurned = anExercise.exerciseDetails.exerciseCalorieBurned.doubleValue
                    strengthExercise.exerciseAmount = anExercise.exerciseDetails.exerciseAmount.doubleValue
                    strengthExercise.exerciseId = anExercise.exerciseId
                    strengthExercise.exerciseMetValue = anExercise.exerciseValue
                    strengthExercise.exerciseTypeId = ExerciseTypeId.Strength
                    strengthExercise.caloriesPerMinute = anExercise.caloriesPerMinute
                    strengthExercise.caloriesPerHour = anExercise.caloriesPerHour

                    exercise = strengthExercise as Exercise
                    
                }
                else if anExercise.exerciseType == ExerciseTypeId.CardioVascular.rawValue {
                    
                    let cardioExercise: CardioVascularExercise = CardioVascularExercise(name: anExercise.exerciseName)
                    cardioExercise.distance = anExercise.exerciseDetails.exerciseDistance.doubleValue
                    cardioExercise.caloriesBurned = anExercise.exerciseDetails.exerciseCalorieBurned.doubleValue
                    cardioExercise.exerciseAmount = anExercise.exerciseDetails.exerciseAmount.doubleValue
                    cardioExercise.exerciseId = anExercise.exerciseId
                    cardioExercise.exerciseMetValue = anExercise.exerciseValue
                    cardioExercise.exerciseTypeId = ExerciseTypeId.CardioVascular
                    cardioExercise.caloriesPerMinute = anExercise.caloriesPerMinute
                    cardioExercise.caloriesPerHour = anExercise.caloriesPerHour
                    exercise = cardioExercise as Exercise

                }
                else {
                    // invalid exercise
                    //print("XXX invalid exercise type \(anExercise.exerciseType)")
                    exercise = Exercise(name: "")
                }
               
                return exercise
            }
            
            completionHandler(exerciseList)

            
            }) { (operation, error) in
                
                //print("failed to load masterdata with error \(error)")
        }
    }
    
}
