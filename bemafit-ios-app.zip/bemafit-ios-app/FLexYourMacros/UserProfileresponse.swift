//
//  GetUserProfileresponse.swift
//  FlexYourMacros
//
//  Created by mini on 05/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _UserProfileresponse = UserProfileresponse()

class UserProfileresponse: NSObject {
    
    var userDietModel: UserDietModel?
    var userDetailModel: UserDetailModel?
    var metaModel: MetaModel?
    var userid: String?
    
    class var sharedUserProfileresponse: UserProfileresponse {
        return _UserProfileresponse
    }
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(UserProfileresponse.metaModelKeyMapping)
        
        // give reference to diet mapping
        responseMapping?.addPropertyMapping(UserProfileresponse.userDietModelKeyMapping)
        
        // give reference to user credential mapping
        responseMapping?.addPropertyMapping(UserProfileresponse.userDetailModelKeyMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: responseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kUrlGetUserDetailResponse, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
   
    fileprivate class var userDietModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDiet, toKeyPath: "userDietModel", with: UserDietModel.objectMapping)
    }
    
    fileprivate class var userDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDetail, toKeyPath: "userDetailModel", with: UserDetailModel.objectMapping)
    }
    
    
    
    class func getUserProfileDetails(_ userId: String,showHUD: Bool = false,  completionHandler: @escaping (_ userDiet: UserDietModel, _ userDetails: UserDetailModel) -> ()) {
            
        RestKitManager.setToken(true)
        
        let userProfileResponse = UserProfileresponse()
        userProfileResponse.userid = userId
        if showHUD {
            SVProgressHUD.show() }
        
        // api call with instance of message model class
        RestKitManager.shared().getObject(userProfileResponse, path: nil, parameters: nil, success: { (operation, mappingResult) in
            
            if showHUD {

            SVProgressHUD.dismiss()
            }
            
            // get the user response
            let userProfileresponse = mappingResult?.firstObject as! UserProfileresponse
            
            // check for success
            if userProfileresponse.metaModel?.responseCode != 200 {
                return;
            }
            
            // set up the completion handler with response
            completionHandler(userProfileresponse.userDietModel!, userProfileresponse.userDetailModel!)
            
            }) { (operation, error) in
                
                if showHUD {

                SVProgressHUD.dismiss()
                }
                //print("failed to load login with error \(error)")
        }
    }
    
    
}
