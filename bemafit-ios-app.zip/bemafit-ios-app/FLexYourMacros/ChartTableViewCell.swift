//
//  ChartTableViewCell.swift
//  ChartViews
//
//  Created by DBG-39 on 23/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

import UIKit

class ChartTableViewCell: UITableViewCell {

    weak var barChartView: BarChartView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    func loadGraph(_ macroDetails: MacroModel) {
        
        let carbPercentage = macroDetails.carbsTotal.doubleValue > 0.0 ? macroDetails.carbAchived.doubleValue/macroDetails.carbsTotal.doubleValue : 0.0
        let proteinPercentage =  macroDetails.proteinTotal.doubleValue > 0.0 ?macroDetails.proteinAchived.doubleValue/macroDetails.proteinTotal.doubleValue : 0.0
        let fatPercentage = macroDetails.fatTotal.doubleValue > 0.0 ? macroDetails.fatAchived.doubleValue/macroDetails.fatTotal.doubleValue : 0.0
        barChartView.chartViewData = [carbPercentage*100, fatPercentage*100, proteinPercentage*100]
    }
   
}
