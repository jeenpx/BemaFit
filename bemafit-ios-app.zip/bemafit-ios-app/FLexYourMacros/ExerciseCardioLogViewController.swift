//
//  ExerciseCardioLogViewController.swift
//  FlexYourMacros
//
//  Created by mini on 26/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ExerciseCardioLogViewController: UITableViewController, UIAlertViewDelegate, UITextFieldDelegate {

    @IBOutlet weak var textFieldExerciseName: UITextField!
    @IBOutlet weak var textFieldHours: UITextField!
    @IBOutlet weak var textFieldMinutes: UITextField!
    @IBOutlet weak var textFieldSeconds: UITextField!
    @IBOutlet weak var textFieldCalorieBurned: UITextField!
    @IBOutlet weak var textFieldMiles: UITextField!

    var logDate: Date = Date()
    var shouldShare: Bool = false
    
    var isFromDashboard = true

    var selectedExerciseType: String = ""
    var userWeight: String = "0"
    var userHeight: String = "0"


    var exercise: CardioVascularExercise = CardioVascularExercise(name: "") {
        didSet {
            
        }
    }
    
    struct Storyboard {
        
        struct Segues {
            static let ShareExerciseDetails  = "kSendExercsieDetailsSegue"
            static let DashBoard       = "kUnwindDashBoardStrength"
            static let ViewLog         = "kViewLogCardio"
        }
    }
    
    var currentTextField: UITextField?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if exercise.name == "" {
//            textFieldCalorieBurned.placeholder = "0"
            textFieldCalorieBurned.isUserInteractionEnabled = true
            textFieldExerciseName.isUserInteractionEnabled = true
        } else {
            
            if exercise.exerciseMetValue != "" {
//            textFieldCalorieBurned.placeholder = "Enter exercise amount details"
                textFieldCalorieBurned.isUserInteractionEnabled = false
            } else {
//                textFieldCalorieBurned.placeholder = "0"
                textFieldCalorieBurned.isUserInteractionEnabled = true
            }
            textFieldExerciseName.isUserInteractionEnabled = false
            textFieldExerciseName.text = exercise.name
            userWeight = AppConfiguration.sharedAppConfiguration.userDetails!.userWeight!
            userHeight = AppConfiguration.sharedAppConfiguration.userDetails!.userHeight!

        }

    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        currentTextField = textField
        
        if textField == textFieldExerciseName {
            
            textField.textAlignment = NSTextAlignment.center
        }
        
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        var result = true
        
        let characterSet = (textField == textFieldHours || textField == textFieldMinutes || textField == textFieldSeconds) ? "0123456789" : "0123456789."
        let noOfCharacters = textField == textFieldCalorieBurned ? 7 : 5
        let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        if string.characters.count > 0 {
            let disallowedCharacterSet = CharacterSet(charactersIn:characterSet ).inverted
            let replacementStringIsLegal = string.rangeOfCharacter(from: disallowedCharacterSet) == nil
            let resultingStringLengthIsLegal = prospectiveText.characters.count <= noOfCharacters
            
            // check if the number is valid
            let isLowNumber = textField == textFieldCalorieBurned ? prospectiveText.doubleValue < 100000 : true
            
            let scanner = Scanner(string: prospectiveText)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
            result = resultingStringLengthIsLegal && replacementStringIsLegal && resultingTextIsNumeric && isLowNumber
        }
        if !result && textField != textFieldExerciseName {
            return result
        } else {
            result = true
        }
        switch textField {
        case textFieldExerciseName: exercise.name = textFieldExerciseName.text!
        case textFieldHours, textFieldMinutes, textFieldSeconds:

            self.exercise.exerciseAmount = self.totalSeconds.doubleValue
                if !textFieldCalorieBurned.isUserInteractionEnabled {
                    
                    textFieldCalorieBurned.text = calorieBurned.stringValue
                }

        case textFieldCalorieBurned: exercise.caloriesBurned = textFieldCalorieBurned.text!.doubleValue
        case textFieldMiles: exercise.distance = textFieldMiles.text!.doubleValue
        default: break
        }
        
        return result

    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if textField == textFieldHours || textField == textFieldMinutes || textField == textFieldSeconds {
            
            if !textFieldCalorieBurned.isUserInteractionEnabled {
                
                textFieldCalorieBurned.text = calorieBurned.stringValue
            }
        }
        
        if textField == textFieldExerciseName {
            
            textField.textAlignment = NSTextAlignment.right
        }

    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if textField == textFieldHours || textField == textFieldMinutes || textField == textFieldSeconds {
            
            if !textFieldCalorieBurned.isUserInteractionEnabled {
                
                textFieldCalorieBurned.text = calorieBurned.stringValue
            }
        }
        
        if textField == textFieldExerciseName {
            
            textField.textAlignment = NSTextAlignment.right
        }
        
        textField.resignFirstResponder()
        return true
    }
    
    var calorieBurned: Double {
        
        //print("calorie burned ----\((userBmr/24.0)*exercise.exerciseMetValue.doubleValue*(totalSeconds.doubleValue/3600.0))")
        return (userBmr/24.0)*exercise.exerciseMetValue.doubleValue*(totalSeconds.doubleValue/3600.0)
    }
    
    var userBmr:Double {
        
        var userBMR = 0.0
        
        let userGender: String = AppConfiguration.sharedAppConfiguration.userDetails!.userGender!
        
        switch userGender {
        case "M":
            userBMR =  13.75 * userWeightinKg + 5 * userHeight.doubleValue - 6.76 * userAge + 66
        case "F":
            userBMR =  9.56 * userWeightinKg + 1.85 * userHeight.doubleValue - 4.68 * userAge + 655
        default:
            break
        }
        
        return userBMR
    }
    
    var userWeightinKg: Double {
        
        return (userWeight.doubleValue * 0.453592)
    }
    
    var userAge: Double {
        
        let userDob = AppConfiguration.sharedAppConfiguration.userDetails?.userDob?.dateValue("yyyy-MM-dd", dateStyle: nil)
        // get the age of the person based on todate
        let ageComponents = (Calendar.current as NSCalendar).components(.NSYearCalendarUnit, from: userDob!, to: Date(), options: [])
        return Double(ageComponents.year!)
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    @IBAction func buttonActionSave(_ sender: UIBarButtonItem) {
        
        textFieldExerciseName.textAlignment = NSTextAlignment.right
        currentTextField?.resignFirstResponder()

        // check exercise name or calories burned is empty
        if textFieldExerciseName.isEmpty  {
            // show alert controller if possible else show alert view
            
                if #available(iOS 8.0, *) {
                    let alert = UIAlertController(title: &&"notice", message: &&"enter_the_details_alert_message", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
                    
                    self.present(alert, animated: true, completion: nil)
                    return
                } else {
                    // Fallback on earlier versions
                    
                    UIAlertView(title: &&"notice", message: &&"enter_the_details_alert_message", delegate: nil, cancelButtonTitle: &&"ok").show()
                    return
                }
            
        }
        
        
        //set calorie burned to 0 if not entered
        if textFieldCalorieBurned.isEmpty || textFieldCalorieBurned.text!.doubleValue < 0.0 {
            
            textFieldCalorieBurned.text = "0.0"
        }
        
        //set miles to 0 if not entered
        if textFieldMiles.isEmpty || textFieldMiles.text!.doubleValue < 0.0 {
            
            textFieldMiles.text = "0.0"
        }
        
        //collect all entries
        collectTheTextFieldsEntries()
        
        // show alert controller if possible else show alert view
             if #available(iOS 8.0, *) {
                let alert = UIAlertController(title: &&"confirmation_title", message: &&"log_confirmation_alert_message", preferredStyle: .alert)
                AppConfiguration.sharedAppConfiguration.isLog = true
                alert.addAction(UIAlertAction(title: &&"log_and_share_alert_button_title", style: .cancel) { action -> Void in
                AppConfiguration.sharedAppConfiguration.isLog = true
                    //print("log_and_share_alert_button_title")
                    self.shouldShare = true
                    
                    
                    
                    if self.exercise.exerciseId == "" {
                        // if exercise id is found "" ? create exercise
                        self.createExerciseType()
                        
                        return
                    }
                    
                    self.performSegue(withIdentifier: Storyboard.Segues.ShareExerciseDetails, sender: self.exercise)
                    
                    //                self.logExercise()
                    
                    })
                alert.addAction(UIAlertAction(title: &&"log_only_alert_button_title", style: .default) { action -> Void in
                    AppConfiguration.sharedAppConfiguration.isLog = true
                    self.shouldShare = false
                    //                //println("log_only_alert_button_title")
                    if self.exercise.exerciseId == "" {
                        // if exercise id is found "" ? create exercise
                        self.createExerciseType()
                        
                        return
                    }
                    self.logExercise()
                    
                    })
                
                
                self.present(alert, animated: true, completion: nil)
                return

            } else {
                // Fallback on earlier versions
                
                UIAlertView(title: &&"confirmation_title", message: &&"log_confirmation_alert_message", delegate: self, cancelButtonTitle: &&"log_only_alert_button_title", otherButtonTitles: &&"log_and_share_alert_button_title").show()
                return
            }
          
    }
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        
        // enable log to self only on this screen. - Shanth
        AppConfiguration.sharedAppConfiguration.isLog = true;

        if alertView.title == &&"confirmation_title"  {
            
            if buttonIndex == 0 {
                
                shouldShare = false
            } else if buttonIndex == 1 {
                
                shouldShare = true
            }
            
            if exercise.exerciseId == "" {
                // if exercise id is found "" ? create exercise
                createExerciseType()
                
                return
            }
            
            if !self.shouldShare {
                self.logExercise()
                
            } else {
                self.performSegue(withIdentifier: Storyboard.Segues.ShareExerciseDetails, sender: self.exercise)
            }
        }
    }
    
    func createExerciseType() {

        // create exercise and get the exercise iD
        Exercise.createExercise(StrengthExercise(name: ""), cardioExercise: exercise) { (createdExerciseId, successful, message) -> () in
            
            if !successful {
               
                self.showAlert(&&"notice", message: message)

                return
            }
            // assign the exercise id to the exercise
            self.exercise.exerciseId = createdExerciseId
            //log the exercise for the particular user
            if !self.shouldShare {
                self.logExercise()
  
            } else {
                self.performSegue(withIdentifier: Storyboard.Segues.ShareExerciseDetails, sender: self.exercise)
            }
            
        }
    }
    
    
    func collectTheTextFieldsEntries() {
        
        let allTextFields: [UITextField] = tableView.relativeSubviews(UITextField)!
        
        for textField in allTextFields {
            
            switch textField {
            case textFieldExerciseName: exercise.name = textFieldExerciseName.text!
            case textFieldCalorieBurned:
                if !textFieldCalorieBurned.isUserInteractionEnabled {
                    textFieldCalorieBurned.text = calorieBurned.stringValue
                }
                exercise.caloriesBurned = textFieldCalorieBurned.text!.doubleValue
            case textFieldMiles: exercise.distance = textFieldMiles.text!.doubleValue
            default: break
            }
            
        }
        exercise.exerciseAmount = totalSeconds.doubleValue
        
    }
    
    var totalSeconds: String {
        let _totalSeconds = textFieldHours.text!.intValue*60*60 + textFieldMinutes.text!.intValue*60 + textFieldSeconds.text!.intValue
        return String(_totalSeconds)
    }

    func checkAllFields() -> Bool {
        // check all fields are non empty
        
        var valid = true
        let textFields = tableView.relativeSubviews(UITextField)!
        
        for textField in textFields {
            
            if textField.isEmpty {
                valid = false
            }
        }
        
        return valid
    }
    
    func logExercise() {
        
        var logExercises = [LogExercise]()
        logExercises.append(LogExercise(cardioVascularExercise: exercise))
        
        var userExercises = [UserExercise]()
        userExercises.append(UserExercise(userID: AppConfiguration.sharedAppConfiguration.userDetails!.userId!, exerciseDetails: logExercises))
        
        let exerciseModel = ExerciseLogModel(logType: "Log", exerciseType: ExerciseTypeId.CardioVascular.rawValue, exerciseDate: logDate.stringValue("yyyy-MM-dd"), source_id:-1)
        exerciseModel.users = userExercises
        
        //print("exerciselog-----\(exerciseModel.toJsonString())")
        
        ExerciseLogModel.logExercise(exerciseModel, completionHandler: { (successful, messsage) -> () in
            if successful {
                
                // load view log
                self.loadViewLog()
                
            } else {
                
                self.showAlert(&&"notice", message: messsage)
                
                //print("failed logged")
                
            }
        })
    }
    
    func showAlert(_ title: String, message: String) {
        
           if #available(iOS 8.0, *) {
                let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
                
                self.present(alert, animated: true, completion: nil)
                return
            } else {
                // Fallback on earlier versions
                UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"ok").show()
                return

            }
        
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        //share exercise details to friend
        if segue.identifier == Storyboard.Segues.ShareExerciseDetails {
            let sendDetailsViewController = segue.destination as! SendDetailsViewController
            sendDetailsViewController.sendDetailsViewMode = .exerciseDetail
            sendDetailsViewController.exercise = sender as? Exercise
            sendDetailsViewController.isFromDashboard = isFromDashboard
            sendDetailsViewController.logDate = logDate
        }
    }
    
    @IBAction func backButtonAction(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }

}
