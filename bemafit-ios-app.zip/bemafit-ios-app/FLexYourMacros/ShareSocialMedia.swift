//
//  ShareSocialMedia.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/10/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import UIKit
import Social
import Accounts

protocol ShareSocialMediaDelegate {
    func shareSocialMedia(_ sharedStatus: String)
}

class ShareSocialMedia: NSObject, UIActionSheetDelegate {
    
    var shareSocialMediaDelegate: ShareSocialMediaDelegate?
    
    // singleton manager
    class var sharedManager: ShareSocialMedia {
        struct Singleton {
            static let instance = ShareSocialMedia()
        }
        return Singleton.instance
    }
    
    var currentViewController: UIViewController?
    
    
    // image to share
    fileprivate var shareImage: UIImage?
    
    // message to share
    fileprivate var shareMessage: String?
    
    // view for  document interaction controller in instagram
    fileprivate var shareView: UIView?
    
    // picture url
    fileprivate var sharedImageUrl: String?
    
    // website url
    fileprivate var shareWebsiteUrl: String?
    
    // name
    fileprivate var shareName: String?
    
    // action sheet to share on social media
    fileprivate let actionSheet = UIActionSheet(title: nil, delegate: nil, cancelButtonTitle: &&"cancel", destructiveButtonTitle: nil, otherButtonTitles: "Newsfeed", "Instagram",
        "Facebook", "Twitter")
    
    func shareOnSocialMedia(_ viewController: UIViewController, image: UIImage?, name: String, message: String, view: UIView, imageUrl: String, websiteUrl: String) {
        
        
        if image != nil {
            shareImage = image
        }
        else {
            // XXX- default image
            shareImage = UIImage(named: "LocationButton")
        }
        
        // save the message to share
        shareMessage = message
        
        // save the view for  document interaction controller in instagram
        shareView = view
        
        // save the parent view controller
        currentViewController = viewController
        
        // save image url
        sharedImageUrl = imageUrl
        
        // save website url
        shareWebsiteUrl = websiteUrl
        
        // save name
        shareName = name
        
        // present the action sheet
        actionSheet.delegate = self
        actionSheet.show(in: viewController.view)
    }
    
    
    func actionSheet(_ actionSheet: UIActionSheet, clickedButtonAt buttonIndex: Int) {
        
        // get the selected social media
        switch actionSheet.buttonTitle(at: buttonIndex)! {
            
        case "Newsfeed":
            
            // XXX - need to implement
            //print("Newsfeed")
            NewsFeed.create(shareMessage!, image: shareImage!) { (newsFeed, error) -> () in
                // handle errors
                if error == nil  {
                    self.shareSocialMediaDelegate?.shareSocialMedia(&&"successfully_shared_on_news_feed")
                }
            }
            
        case "Instagram":
            
            // share to instagram
            InstagramManager.sharedManager.postImageToInstagramWithCaption(shareImage!, instagramCaption: shareMessage!, view: shareView!)
            
        case "Facebook":
            
            let shareModel = FacebookShareModel()
            shareModel.description = shareMessage
            shareModel.name = shareName
            shareModel.pictureLink = sharedImageUrl
            shareModel.link = shareWebsiteUrl
            
            FacebookManager.showShareDialog(withShareModel: currentViewController!, andModel: shareModel, andCallback: { (status, results, error) -> Void in
                if error != nil {
                    //print(error)
                }
                else {
                    //print("success")
                    
                }
            })
            
        case "Twitter":
            //  share to twitter
            
            //  twitter without UI
            //  limit the characters to 140
            /* var shareMessage1 = shareMessage!.truncate(120, trailing: "...")
            TwitterManager.sharedManager.shareMessage(["status": shareMessage1], andImage: shareImage!, withSuccessBlock: { (data, urlResponse) -> () in
            
            // success
            // MARK: twitter
            self.showAlert(&&"notice", andMessage: &&"posted", andButtonTitle: "ok")
            
            }, andFailureBlock: { (error) -> () in
            // failure
            
            if error.localizedDescription == "Twitter Account not setup" {
            self.showAlert(&&"notice", andMessage: &&"setup_twitter_account", andButtonTitle: "ok")
            }
            else {
            self.showAlert(&&"notice",andMessage: &&"posted_failed" , andButtonTitle: "ok")
            }
            })
            */
            
            //  twitter with UI
            TwitterManager.sharedManager.shareTweetsUsingUI(currentViewController!, messages: shareMessage!, andImage: shareImage!, withSuccessBlock: { (data) -> () in
                //print("shared item ")
                }, andFailureBlock: { (error) -> () in
                    if error.localizedDescription == "Twitter Account not setup" {
                        self.showAlert(&&"notice", andMessage: &&"setup_twitter_account", andButtonTitle: "ok")
                    }
                    else {
                        self.showAlert(&&"notice",andMessage: &&"posted_failed" , andButtonTitle: "ok")
                    }
            })
            
            
        default: return
        }
    }
    
    func showAlert(_ title: String, andMessage message: String, andButtonTitle buttonTitle: String) {
        // show the alert
        
        if #available(iOS 8.0, *) {
            let alert: UIAlertController = UIAlertController(title: title,
                message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: buttonTitle, style: .default, handler: nil))
            self.currentViewController?.present(alert, animated: true, completion: nil)
        } else {
            // Fallback on earlier versions
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: buttonTitle).show()
        }
    }
    
}
