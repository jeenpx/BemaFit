//
//  BarChartView.swift
//  ChartViews
//
//  Created by DBG-39 on 23/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

import UIKit
import CoreGraphics
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}



class GroupedBarChartView: CPTGraphHostingView, CPTBarPlotDelegate, CPTPlotSpaceDelegate, CPTPlotDataSource, CPTBarPlotDataSource {
    
    fileprivate var chartViewXIndex = [Int]()
    var  xAxisLabels: [String] = [] {
        didSet {
            
            chartViewXIndex = [Int]()
            
            for i in 0 ..< xAxisLabels.count {
                
                chartViewXIndex.append(i)
            }
        }
    }
    
    var yMaximum: Double? {
        
        var maximumArray = [Double]()
        maximumArray = chartViewData!.map({ array in
            
            return  array.reduce(DBL_MIN, {max($0, $1)})
            
        })
        
        return maximumArray.count == 0 ? 0.0 :maximumArray.reduce(DBL_MIN, {max($0, $1)})
    }
    
    var xMaximum: Int? {
        
        return chartViewXIndex.isEmpty ? 1 : chartViewXIndex.reduce(Int.min, { max($0, $1) })
    }
    
    var xDivision: Double? {
        
        return chartViewXIndex.isEmpty ? 1.0 : Double(xMaximum! / chartViewXIndex.count-1)
    }
    
    var yDivision: Double? {
        
        //print("yMaximum ----\(yMaximum)")
        return chartViewData?.isEmpty != nil ? (yMaximum! / 10) : 1.0
        
    }
    
    var chartViewData: [[Double]]? {
        didSet {
            
            renderInGraphHostingView()
        }
    }
    
    
    func renderInGraphHostingView() {
        
        hostedGraph = CPTXYGraph(frame: self.bounds)
        // Plot area delegate
        hostedGraph.plotAreaFrame.plotArea.delegate = self;
        hostedGraph.plotAreaFrame.scroll(CGPoint(x: 0, y: 0))
        hostedGraph.plotAreaFrame.paddingLeft =  10.0+CGFloat((yMaximum!.stringValue.characters.count))
        hostedGraph.plotAreaFrame.paddingTop = 0.0
        hostedGraph.plotAreaFrame.masksToBorder = false
        allowPinchScaling = false

        
        let plotSpace = hostedGraph.defaultPlotSpace as! CPTXYPlotSpace;
        plotSpace.allowsUserInteraction = true;
        plotSpace.allowsMomentum        = false;
        plotSpace.delegate              = self;
        
        let majorGridLineStyle: CPTMutableLineStyle = CPTMutableLineStyle()
        majorGridLineStyle.lineWidth = 0.75
        majorGridLineStyle.lineColor = CPTColor.lightGray()
        
        let minorGridLineStyle = CPTMutableLineStyle()
        minorGridLineStyle.lineWidth = 1.0
        minorGridLineStyle.lineColor = CPTColor.lightGray()
        
        // Label x axis with a fixed interval policy
        let axisSet = hostedGraph.axisSet as! CPTXYAxisSet
        let x          = axisSet.xAxis as CPTXYAxis
        x.labelingPolicy = CPTAxisLabelingPolicy.none
        
        //make the custom labels
        var x_labelLocation     = 0
        var x_customLabels   = NSMutableSet(capacity: xAxisLabels.count)
        
        for  tickLocation in chartViewXIndex  {
            let newLabel = CPTAxisLabel(text: xAxisLabels[x_labelLocation], textStyle: x.labelTextStyle) as CPTAxisLabel
            x_labelLocation += 1
            newLabel.tickLocationNumber = tickLocation as NSNumber!
            newLabel.offset = x.labelOffset
            x_customLabels .add(newLabel)
        }
        
        x.axisLabels = x_customLabels as Set<NSObject>;
        x.majorIntervalLengthNumber         = NSNumber.init(value: 2.0*xDivision!)
        x.minorTicksPerInterval       = 0
        x.labelOffset                 = -5.0
        x.titleOffset   = 30.0
        x.titleLocationNumber = 1.2
        x.majorGridLineStyle = majorGridLineStyle
        x.axisConstraints = CPTConstraints.constraint(withLowerOffset: 0.0)
        x.axisConstraints = CPTConstraints.constraint(withRelativeOffset: 0.0)
        if chartViewData?.count == 0 {
            x.isHidden = true
        }
        else {
            x.isHidden = false
        }
        
        // Label y with an automatic label policy.
        let y = axisSet.yAxis as CPTXYAxis
        y.isHidden = true
        y.labelingPolicy = CPTAxisLabelingPolicy.none
        y.orthogonalCoordinateDecimalNumber = 0.0
        y.majorIntervalLengthNumber = NSNumber.init(value: 2*yDivision!)
        y.minorTicksPerInterval       = 0
        y.preferredNumberOfMajorTicks = 8
        y.majorGridLineStyle          = majorGridLineStyle
        y.minorGridLineStyle          = minorGridLineStyle
        y.labelOffset                 = -5
        y.titleOffset   = 30.0
        y.titleLocationNumber = 1.0
        y.axisConstraints = CPTConstraints.constraint(withLowerOffset: 0.0)
        
        
        //make the custom y labels
        var y_labelLocation     = 0
        
        if chartViewData?.count > 0 {
           
            var y_customLabels   = NSMutableSet(capacity: xAxisLabels.count)
            
            for  i in 0...5  {
                
                let currentValue = Double(i)*(yMaximum!/5.0)
                let labelText = currentValue.description+"%"
                var newLabel = CPTAxisLabel()
                if currentValue == 0.0 {
                     newLabel = CPTAxisLabel(text: "", textStyle: x.labelTextStyle) as CPTAxisLabel

                } else {
                
                    newLabel = CPTAxisLabel(text: currentValue < 1.0 ?  String(format: "%.2f", currentValue).singleDecimalValue+" %" : String(format: "%.2f", currentValue).singleDecimalValue+" %", textStyle: x.labelTextStyle) as CPTAxisLabel
                }
                newLabel.tickLocationNumber = currentValue as NSNumber!
                newLabel.offset = y.labelOffset
                y_customLabels .add(newLabel)
            }
            y.axisLabels = y_customLabels as Set<NSObject>;

        }
        
        var barLineStyle: CPTMutableLineStyle = CPTMutableLineStyle()
        barLineStyle.lineWidth = 0.5
        barLineStyle.lineColor = CPTColor.clear()
        
        var sampleContentArray = [Double]()
        if chartViewData?.count != 0 {
            sampleContentArray = chartViewData!.first!
        }
        // add bar plot
        for i in 0 ..< sampleContentArray.count {
            
            let barPlot = CPTBarPlot(frame: CGRect(x: 0, y: 0, width: 15, height: 15))
            barPlot?.lineStyle         = barLineStyle
            barPlot?.barWidthNumber    = 15.0
            barPlot?.barWidthsAreInViewCoordinates = true
            barPlot?.barCornerRadius   = 0.0
            barPlot?.title = String(i)
            
            barPlot?.barsAreHorizontal = false
            barPlot?.dataSource        = self
            barPlot?.barBasesVary = false
            barPlot?.showLabels = true
            barPlot?.labelOffset = -10
            barPlot?.barOffSetNumber = NSNumber.init(value: i*15)
            
            hostedGraph.add(barPlot)
            
            let xbarRange: CPTMutablePlotRange = barPlot?.plotRangeEnclosingBars() as! CPTMutablePlotRange
            xbarRange.expand(byFactorNumber: 0.3)
            
            let ybarRange: CPTMutablePlotRange = barPlot!.plotRangeEnclosingBars() as! CPTMutablePlotRange
            ybarRange.expand(byFactorNumber: 4.0)
            let xlengthNumber = 0.35*Double(xMaximum!)
            
            let barPlotSpace: CPTXYPlotSpace = hostedGraph.defaultPlotSpace as! CPTXYPlotSpace
            barPlotSpace.xRange = CPTPlotRange(locationNumber: 0, lengthNumber: xlengthNumber as NSNumber!)
            //xbarRange
            barPlotSpace.yRange = ybarRange
        }
        
        
        let xRange = plotSpace.xRange.mutableCopy() as! CPTMutablePlotRange
        let yRange = plotSpace.yRange.mutableCopy() as! CPTMutablePlotRange
        //print("expandable factor -----\((Double(xMaximum!)/10.0)*4.0)")
        xRange.expand(byFactorNumber: 1.8)
        yRange.expand(byFactorNumber: 6.0)
        plotSpace.xRange = xRange
        plotSpace.yRange = yRange
        
        // Restrict y range to a global range
        let globalYRange = CPTPlotRange(locationNumber: 0.0, lengthNumber: yMaximum as NSNumber!)
        let globalXRange = CPTPlotRange(locationNumber: -0.2, lengthNumber: NSNumber.init(value: xMaximum!-Int(2*xDivision!)))
        plotSpace.globalYRange = globalYRange
        plotSpace.globalXRange = globalXRange

        
    }
    
    func numberOfRecords(for plot: CPTPlot!) -> UInt {
        return UInt(chartViewData!.count)
    }
    
    func number(for plot: CPTPlot!, field fieldEnum: UInt, record idx: UInt) -> Any! {
        
        var indexValue: NSNumber = 0
        let plotTitle = plot.title
        
        switch fieldEnum {
        case 0:
            indexValue = NSNumber.init(value: chartViewXIndex[Int(idx)])
            break
        case 1:
            let plotArray = chartViewData![Int(idx)]
            indexValue = NSNumber.init(value: plotArray[plotTitle!.intValue])
            break
        default:
            break
        }
        return indexValue
    }
    
    func barFill(for barPlot: CPTBarPlot!, record idx: UInt) -> CPTFill! {
        
        var color: CPTColor?
        
        switch barPlot.title {
            
        case "0":
            color = CPTColor(componentRed: 39.0/255.0, green: 141.0/255.0, blue: 253.0/255.0, alpha: 1.0)
            
        case "1":
            color = CPTColor(componentRed: 101.0/255.0, green: 173.0/255.0, blue: 255.0/255.0, alpha: 1.0)
            
        case "2":
            color = CPTColor(componentRed: 167.0/255.0, green: 206.0/255.0, blue: 255.0/255.0, alpha: 1.0)
            
        case "3":
            color = CPTColor(componentRed: 204.0/255.0, green: 227.0/255.0, blue: 254.0/255.0, alpha: 1.0)
        case "4":
            color = CPTColor(componentRed: 114.0/255.0, green: 112.0/255.0, blue: 114.0/255.0, alpha: 1.0)
        case "5":
            color = CPTColor(componentRed: 39.0/255.0, green: 141.0/255.0, blue: 253.0/255.0, alpha: 1.0)
            
        default:
            color = CPTColor.yellow()
        }
        
        let fillGradient: CPTGradient = CPTGradient(beginning: color, ending: color)
        return CPTFill(gradient: fillGradient)
    }
    
    //        func dataLabelForPlot(plot: CPTPlot!, recordIndex idx: UInt) -> CPTLayer! {
    //
    //            let plotTitle = plot.title
    //            let plotArray = chartViewData![Int(idx)]
    //
    //            var labelTextStyle: CPTMutableTextStyle = CPTMutableTextStyle()
    //            labelTextStyle.color = CPTColor.whiteColor()
    //            labelTextStyle.fontSize = 14.0
    //            var labelTextValue: NSNumber = plotArray[plotTitle.intValue]
    //            var label: CPTTextLayer = CPTTextLayer(text: labelTextValue.stringValue + "%", style: labelTextStyle)
    //            return label
    //        }
    //
    //    func plotSpace(space: CPTPlotSpace!, willChangePlotRangeTo newRange: CPTPlotRange!, forCoordinate coordinate: CPTCoordinate) -> CPTPlotRange! {
    //
    //        var returnRange = CPTPlotRange()
    //
    //        // Impose a limit on how far user can scroll in x
    //        let maxRange = CPTPlotRange(locationNumber: -1.0, lengthNumber: xMaximum!*2) as CPTPlotRange
    //        let changedRange = newRange.mutableCopy() as CPTMutablePlotRange
    //        changedRange.shiftEndToFitInRange(maxRange)
    //        changedRange.shiftLocationToFitInRange(maxRange)
    //        returnRange = changedRange;
    //        return returnRange
    //    }
    //    
}
