//
//  CreateMealViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/22/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

// base tableview cell for CreateMealCell and CreateServeMealCell
class BaseCreateMealCell: UITableViewCell {
    var isValid: Bool {
        return true
    }
}

// cell mode of CreateMealCell
enum CreateMealCellMode: String {
    case BrandName = "meal_brand_name"
    case Name = "meal_name"
    case Empty = ""
    case Servings = "meal_number_servngs"
    case Category = "meal_category"
    static var createMealModes = [BrandName, Name, Empty, Servings, Category]
}

// delegate for CreateMealCell
protocol CreateMealCellDelegate {
    func createMealCell(_ cell: CreateMealCell, textFieldForCategoryCell textField: UITextField)
    func createMealCell(_ cell: CreateMealCell, textFieldDidEndEditing textField: UITextField)
    func createMealCell(_ cell: CreateMealCell, textFieldDidBeginEditing textField: UITextField)
}

class CreateMealCell: BaseCreateMealCell, UITextFieldDelegate {
    
    @IBOutlet weak var buttonAddCategory: UIButton!
    @IBOutlet weak var buttonConstraint: NSLayoutConstraint!
    @IBOutlet weak var textField: UITextField!
    
    // delegate instance
    var createMealCellDelegate: CreateMealCellDelegate?
    
    // cell mode instance
    var createMealCellMode = CreateMealCellMode.Name {
        didSet {
            configureView()
        }
    }
    
    // returns true for textfield with value and for category
    override var isValid: Bool {
        return (createMealCellMode == CreateMealCellMode.Category) || !textField.isEmpty
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func configureView() {
        
        // set placeholder
        textField.placeholder = &&createMealCellMode.rawValue
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        // display uipicker for category field
        if createMealCellMode == CreateMealCellMode.Category {
            createMealCellDelegate?.createMealCell(self, textFieldForCategoryCell: textField)
        }
        else {
            // delegate function used to store selected texfield resign keyboard in view controller
            
            createMealCellDelegate?.createMealCell(self, textFieldDidBeginEditing: textField)
        }
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        createMealCellDelegate?.createMealCell(self, textFieldDidEndEditing: textField)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var result = true
        
        if createMealCellMode == CreateMealCellMode.BrandName || createMealCellMode == CreateMealCellMode.Name {
            let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
            if string.characters.count > 0 {
                let resultingStringLengthIsLegal = prospectiveText.characters.count <= 60
                result =  resultingStringLengthIsLegal
            }
        }

        
        else if createMealCellMode == CreateMealCellMode.Servings {
            // managing the textfield input: limit the characters to only of numeric type
            let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
            if string.characters.count > 0 {
                let disallowedCharacterSet = CharacterSet(charactersIn: "0123456789.").inverted
                let replacementStringIsLegal = string.rangeOfCharacter(from: disallowedCharacterSet) == nil
                let resultingStringLengthIsLegal = prospectiveText.characters.count <= 10
                let scanner = Scanner(string: prospectiveText)
                let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
                result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
            }
        }
        else if createMealCellMode == CreateMealCellMode.Category {
            return false
        }
        return result
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        
        //set background color for cells
        backgroundColor = isEditing ? UIColor.clear : UIColor.white
    }
}

// delegate for CreateServeMealCell
protocol CreateServeMealCellDelegate {
    func createServeMealCell(_ cell: CreateServeMealCell, textFieldDidEndEditing textField: UITextField, isServing serving: Bool)
    func createServeMealCell(_ cell: CreateServeMealCell, textFieldDidBeginEditing textField: UITextField)
}

class CreateServeMealCell: BaseCreateMealCell, UITextFieldDelegate {
    
    @IBOutlet weak var textFieldServingSize: UITextField!
    @IBOutlet weak var textFieldUnit: UITextField!
    
    // delegate instance for CreateServeMealCell
    var createServeMealCellDelegate: CreateServeMealCellDelegate?
    
    override var isValid: Bool {
        return relativeSubviews(UITextField)?.reduce(true) { $0 && $1.isNonEmpty } ?? true
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        createServeMealCellDelegate?.createServeMealCell(self, textFieldDidEndEditing: textField, isServing: textField == textFieldServingSize)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var result = true
        if textField == textFieldServingSize {
            // managing the textfield input: limit the characters to only of numeric type
            let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
            if string.characters.count > 0 {
                let disallowedCharacterSet = CharacterSet(charactersIn: "0123456789.").inverted
                let replacementStringIsLegal = string.rangeOfCharacter(from: disallowedCharacterSet) == nil
                let resultingStringLengthIsLegal = prospectiveText.characters.count <= 10
                let scanner = Scanner(string: prospectiveText)
                let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
                result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
            }
        }
        return result
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        createServeMealCellDelegate?.createServeMealCell(self, textFieldDidBeginEditing: textField)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

class CreateMealViewController: UITableViewController, CreateMealCellDelegate, CreateServeMealCellDelegate, UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate {
    
    // food instance
    var food = Food()
    
    var mealType: MealType?
    
    var isDailyMealPlan = false
    
    var dailyMealType = DailyMealType(dailyMealTypeName: "")
    
    // save category textfield
    var texFieldCategory: UITextField!
    
    // save the selected textfield other than category
    var textFieldCreateMeal = UITextField()
    
    // save the selected textfield in serve meal cell
    var textFieldServeMeal = UITextField()

    var allFoodCategories: Set<FoodCategory> {
        var tempFoodCategories = Set<FoodCategory>()
        if let foodCategories = AppConfiguration.sharedAppConfiguration.mealCategories {
            tempFoodCategories = Set(foodCategories)
        }
        return tempFoodCategories
    }
    
    
    @IBOutlet var tableViewCreateMeal: UITableView!
    @IBOutlet var pickerViewCategory: UIPickerView!
    @IBOutlet var toolbarCategory: UIToolbar!
    
    
    var pickerData: [FoodCategory] {
        return (allFoodCategories.subtracting(food.foodCategories)).allObjects
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // hide empty tableview cells
        tableViewCreateMeal.tableFooterView = UIView()
        
        // set tableview editing true
        tableViewCreateMeal.setEditing(true, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5 + food.foodCategories.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var tableViewCell: UITableViewCell!
        
        switch indexPath.row {
            
        case 0,1,3,4:
            let mealCell: CreateMealCell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifier.CreateMeallCellIdentifier) as! CreateMealCell
            mealCell.createMealCellMode = CreateMealCellMode.createMealModes[indexPath.row]
            mealCell.createMealCellDelegate = self
            tableViewCell = mealCell
            
        case 2:
            let createServeMealCell: CreateServeMealCell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifier.CreateServeMeallCellIdentifier) as! CreateServeMealCell
            createServeMealCell.createServeMealCellDelegate = self
            tableViewCell = createServeMealCell
            
        default:
            let mealCell: CreateMealCell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifier.CreateMeallCellIdentifier) as! CreateMealCell
            mealCell.textField.text = food.foodCategories.allObjects[indexPath.row - 5].name
            
            // set text color
            mealCell.textField.textColor = UIColor(red: 114.0/255.0, green: 114.0/255.0, blue: 114.0/255.0, alpha: 1.0)
            
            // set font type and size
            mealCell.textField.font = UIFont(name: "Helvetica-Bold", size: 16)
            
            // disable userinteraction for category textfields
            mealCell.textField.isUserInteractionEnabled = false
            
            tableViewCell = mealCell
            break
        }
        return tableViewCell
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        
        // category cells
        if indexPath.row > 4 {
            return true
        }
        return false
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        //print("reached")
        
        if (editingStyle == UITableViewCellEditingStyle.delete) {
            // delete the row from the data source
            
            tableViewCreateMeal.beginUpdates()
            
            // remove the category from food
            food.foodCategories.remove(food.foodCategories.allObjects[indexPath.row - 5])
            
            // delete the row from tableview
            tableViewCreateMeal.deleteRows(at: [indexPath], with: UITableViewRowAnimation.fade)
            
            tableViewCreateMeal.endUpdates()
            
            // reload picker
            pickerViewCategory.reloadAllComponents()
        }
    }
    
    func createMealCell(_ cell: CreateMealCell, textFieldForCategoryCell textField: UITextField) {
        // configure textfield of pickerview
        
        if pickerData.count <= 0 {
            
            textField.inputView = pickerViewCategory
            textField.inputAccessoryView = toolbarCategory
            pickerViewCategory.isUserInteractionEnabled = false
            return
        }
        textField.inputView = pickerViewCategory
        textField.inputAccessoryView = toolbarCategory
        pickerViewCategory.isUserInteractionEnabled = true

        // save the category textfield
        texFieldCategory = textField
    }
    
    func createMealCell(_ cell: CreateMealCell, textFieldDidEndEditing textField: UITextField) {
        
        // set food property values
        switch cell.createMealCellMode {
            
        case .BrandName:
            food.brandName = textField.text!
        case .Name:
            food.name = textField.text!
        case .Servings:
            food.numberOfServings = (textField.text! as NSString).doubleValue
        default:
            break
        }
    }
    
    func createMealCell(_ cell: CreateMealCell, textFieldDidBeginEditing textField: UITextField) {
        
        // set keyboard numeric type
        if cell.createMealCellMode == .Servings {
            textField.keyboardType = .numbersAndPunctuation
        }
        
        // save the textfield other than category
        textFieldCreateMeal = textField
    }
    
    func createServeMealCell(_ cell: CreateServeMealCell, textFieldDidEndEditing textField: UITextField, isServing serving: Bool) {
        
        // check whether serving size or unit textfield
        if serving {
            food.servingSize = (textField.text! as NSString).doubleValue
        }
        else {
            food.unit = textField.text!
        }
    }
    
    func createServeMealCell(_ cell: CreateServeMealCell, textFieldDidBeginEditing textField: UITextField) {
        
        // set keyboard numeric type
        if textField == cell.textFieldServingSize {
            textField.keyboardType = .numbersAndPunctuation
        }
        
        // save textfield
        textFieldServeMeal = textField
    }
    
    // picker view delegates and datasource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row].name
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        //print("selected == \(pickerData[row].name)")
        
    }
    
    // storyboard identifiers
    struct StoryBoard {
        struct CellIdentifier {
            static let CreateMeallCellIdentifier = "kCreateMealCell"
            static let CreateServeMeallCellIdentifier = "kCreateServeMealCell"
        }
        struct Segue {
            static let NutritionFactsSegue = "kNutritionFacts"
        }
    }
    
    @IBAction func buttonActionPickerDone(_ sender: Any) {
        
        if pickerData.isEmpty {
            
            // hide picker
            texFieldCategory.resignFirstResponder()
            return
        }
        // add the selected category
        food.foodCategories.insert(pickerData[pickerViewCategory.selectedRow(inComponent: 0)])
        
        // reload picker
        pickerViewCategory.reloadAllComponents()
        
        // reload the tableview
        tableViewCreateMeal.reloadData()
        
        // hide picker
        texFieldCategory.resignFirstResponder()
        
    }
    
    @IBAction func buttonActionNext(_ sender: Any) {
        
        // resign keyboard to store food value in create meal cell
        textFieldCreateMeal.resignFirstResponder()
        
        // resign keyboard to store food value in serve meal cell
        textFieldServeMeal.resignFirstResponder()

        //print("foodname:\(food.name)")
        //print("fooddes:\(food.description)")
        //print("foodnumbr:\(food.numberOfServings)")
        //print("foodunit:\(food.unit)")
        
//        if food.brandName.isEmpty {
//            showAlert(&&"error", message: &&"brand_name_empty")
//            return
//        }
        if food.name.isEmpty {
            showAlert(&&"error", message: &&"food_name_empty")
            return
        }
//        else if food.description.isEmpty {
//            showAlert(&&"error", message: &&"description_empty")
//            return
//        }
        else if food.servingSize < 1 {
            showAlert(&&"error", message: &&"serving_size_validation")
            return
        }
        else if food.unit.isEmpty {
            showAlert(&&"error", message: &&"unit_empty")
            return
        }
        else if food.numberOfServings < 1 {
            showAlert(&&"error", message: &&"no_of_servings_validation")
            return
        }
            // check category added
            else if food.foodCategories.count == 0 {
                
                // show alert for empty category
                showAlert(&&"error", message: &&"category_empty")
                
                // exit
                return
            }
            performSegue(withIdentifier: StoryBoard.Segue.NutritionFactsSegue, sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == StoryBoard.Segue.NutritionFactsSegue {
            let convertUnitsViewController = segue.destination as! ConvertUnitsViewController
            
            convertUnitsViewController.mealType = mealType
            
            // save the food
            convertUnitsViewController.food = food
        }
    }
    
    
    func showAlert(_ title: String, message: String) {
       
            if #available(iOS 8.0, *) {
                let alertView = UIAlertController(title: title,
                    message: message, preferredStyle: .alert)
                alertView.addAction(UIAlertAction(title: &&"create_meal_alert_ok", style: .cancel, handler: nil))
                present(alertView, animated: true, completion: nil)
            } else {
                // Fallback on earlier versions
                 UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"create_meal_alert_ok").show()
            }
            
    }
    
    @IBAction func buttonActionBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}
