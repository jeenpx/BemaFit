
//
//  LogFoodResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 28/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class LogFoodResponse: NSObject {
 
    var meta: MetaModel?
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
        responseMapping?.addPropertyMapping(metaModelMapping)

        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let logFoodResponseDescriptor = RKResponseDescriptor(mapping: LogFoodResponse.responseMapping, method: .POST, pathPattern: Constants.ServiceConstants.kFoodLogUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return logFoodResponseDescriptor!
    }
    
    class func logFood(_ params: [String: Any], completionHandler: @escaping (_ error: NSError?) -> ()) {
        
        SVProgressHUD.show()
        
        RestKitManager.setToken(true)
        
        // create a post request
        let request = RestKitManager.shared().request(with: nil, method: .POST, path: Constants.ServiceConstants.kFoodLogUrl, parameters: nil)
        
        // set params as body
        request?.httpBody = try? JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())

        // create an operation with the request
        let operation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let logFoodResponse = mappingResult?.firstObject as! LogFoodResponse
            
            // check for success
            if logFoodResponse.meta?.responseCode != 200 {

                SVProgressHUD.dismiss()
                
                // configure alert message
                var message = "alert_log_food_post_message"
                
                // determine the log type
                let logType = LogType(rawValue: params["log_type"] as! String)
                if let logType = logType {
                    switch logType {
                    case LogType.Copy: message = "alert_copy_food_failure_message"
                    case LogType.Split: message = "alert_split_food_failure_message"
                    case LogType.Send: message = "alert_share_food_failure_message"
                    default: message = "alert_log_food_post_message"
                    }
                }
                
                completionHandler(NSError(domain: "FYM.FoodLog", code: 99, userInfo: ["title": "error", "message": message]))
            }
            else {
                SVProgressHUD.dismiss()
                completionHandler(nil)
            }
            }) { (operation, error) in
                //print("XXX failed to log food with error \(error)")
                SVProgressHUD.dismiss()
                completionHandler(NSError(domain: "FYM.FoodLog", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"]))
        }
        
        // enque request operation
        RestKitManager.shared().enqueue(operation)
    }
}
