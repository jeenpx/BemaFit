//
//  UITableView+Subviews.swift
//  FlexYourMacros
//
//  Created by Thahir on 12/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import UIKit

extension UITableView {
    
    var relativeSubviews: [UIView] {
        return (subviews[0].subviews.filter { $0.isKind(of: UITableViewCell.self) } as! [UITableViewCell]).reduce([]) { $0 + $1.relativeSubviews }
    }
    
    func relativeSubviews <T: UIView> (_ type: T.Type) -> [T]? {
        return relativeSubviews.filter { $0.isKind(of: T.self) } as? [T]
    }
    
    func showEmptyTableViewMessage(_ message: String = &&"empty_tableview_message") {
        let labelEmptyMessage = UILabel(frame: CGRect(x: 0, y: 0, width: bounds.size.width, height: bounds.size.height))
        labelEmptyMessage.text = message
        labelEmptyMessage.textColor = UIColor(red: 114.0/255.0, green: 114.0/255.0, blue: 114.0/255.0, alpha: 1.0)
        labelEmptyMessage.numberOfLines = 0
        labelEmptyMessage.textAlignment = .center
        labelEmptyMessage.font = UIFont.helvetica(16)
        labelEmptyMessage.sizeToFit()
        backgroundView = labelEmptyMessage
        separatorStyle = .none
    }
}
