//
//  DirectoryHours.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/26/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class DirectoryHours: NSObject {
    
    // model instance variable
    var day: String?
    var open: String?
    var close: String?
    
    func getNormalTimeFromRailway(_ openTime: Bool) -> String {
        // convert railway time to normal time
        
        let time = openTime ? open : close
        if let normalTime = time {
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = DateFormatter.Style.medium
            dateFormatter.dateFormat = "HH:mm:ss"
            let date = dateFormatter.date(from: normalTime)
            
            let formatter = DateFormatter()
            formatter.dateFormat = "hh:mm a"
            return formatter.string(from: date!).replacingOccurrences(of: "AM", with: "am").replacingOccurrences(of: "PM", with: "pm")
        }
        return "00:00"
    }
    
    class var objectMapping: RKObjectMapping {
        // object mapping
        
        let directoryCategoryMapping = RKObjectMapping(for: self)
        directoryCategoryMapping?.addAttributeMappings(from: mappingDictionary)
        return directoryCategoryMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["day":"day", "open":"open", "close":"close"])
    }
    
    func acceptsDay(_ day: String) -> Bool {
        // return current date
        
        return self.day == day
    }
    
}
