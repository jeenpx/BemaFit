//
//  ResendEmailResponse.swift
//  FlexYourMacros
//
//  Created by mini on 05/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//
import Foundation

private let _ResendEmailResponse = ResendEmailResponse()

class ResendEmailModel: NSObject {
    
    var status: String = ""
    
    class var objectMapping: RKObjectMapping {
        let tokenMapping = RKObjectMapping(for: self)
        tokenMapping?.addAttributeMappings(from: ResendEmailModel.mappingDictionary)
        return tokenMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["status":"status"])
    }
    
}

class ResendEmailResponse: NSObject {
    
    var resendEmailModel: ResendEmailModel?
    var metaModel: MetaModel?
    
    class var sharedResendEmailResponse: ResendEmailResponse {
        return _ResendEmailResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        // give reference to resend email model mapping
        responseMapping?.addPropertyMapping(ResendEmailResponse.metaModelKeyMapping)

        responseMapping?.addPropertyMapping(ResendEmailResponse.resendEmailModellKeyMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.resenEmailUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var resendEmailModellKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathResendEmail, toKeyPath: "resendEmailModel", with: ResendEmailModel.objectMapping)
    }
    
    class func resendEmail(_ user_email: String, completionHandler: @escaping (_ resendEmailResponse: ResendEmailModel?) -> ()) {
        
        RestKitManager.setupBasicAuth()

        var parameterDictionary: [String:String] {
            
            // create the parameter dictionary
            return ["email":user_email]
        }
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path: Constants.ServiceConstants.resenEmailUrl, parameters: parameterDictionary, constructingBodyWith: { (formData) in
            
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let response = mappingResult?.firstObject as! ResendEmailResponse
            
            if response.metaModel?.responseCode != 200 {
                
                completionHandler(nil)

                return;
            }

            completionHandler(response.resendEmailModel!)
            
            
            }) { (operation, error) in
                
                //print("failed to load contact us with error \(error)")
                
                completionHandler(nil)
        }
        
        RestKitManager.shared().enqueue(operation)
        
    }
    
    
}
