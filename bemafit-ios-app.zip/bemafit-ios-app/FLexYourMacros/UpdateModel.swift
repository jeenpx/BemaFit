//
//  UpdateModel.swift
//  FlexYourMacros
//
//  Created by DBG on 08/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UpdateModel: NSObject {
    
    var status:String?
    
    class var objectMapping: RKObjectMapping {
        let updateModelMapping = RKObjectMapping(for: self)
        updateModelMapping?.addAttributeMappings(from: mappingDictionary)
        return updateModelMapping!
    }
    
    
    class var mappingDictionary: [String : String]    {
        return(["status":"status"])
    }
    
}
