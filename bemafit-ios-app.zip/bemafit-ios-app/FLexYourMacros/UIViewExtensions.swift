//
//  UIViewExtensions.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 10/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

let kMainScreenWidth = Double(UIScreen.main.bounds.width)

extension UIView {
    
    func disableAutoresizingMask() {
        translatesAutoresizingMaskIntoConstraints = false
    }
    
    func centerHorizontallyInSuperview() {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let constraints = NSLayoutConstraint(item: self, attribute: NSLayoutAttribute.centerX, relatedBy: NSLayoutRelation.equal, toItem: superview, attribute: NSLayoutAttribute.centerX, multiplier: 1, constant: 0)
        superview!.addConstraint(constraints)
    }
    
    func centerVerticallyInSuperview() {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let constraints = NSLayoutConstraint(item: self, attribute: NSLayoutAttribute.centerY, relatedBy: NSLayoutRelation.equal, toItem: superview, attribute: NSLayoutAttribute.centerY, multiplier: 1, constant: 0)
        superview!.addConstraint(constraints)
    }
    
    func fillSuperView(_ margin: Int = 0) {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let views = ["view": self]
        let metrics = ["margin": margin]
        superview!.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-margin-[view]-margin-|", options: NSLayoutFormatOptions.alignAllCenterX, metrics: metrics, views: views))
        superview!.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-margin-[view]-margin-|", options: NSLayoutFormatOptions.alignAllCenterY, metrics: metrics, views: views))
    }
    
    func setLeftMargin(_ margin: Int = 15) {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let views = ["view": self]
        let metrics = ["margin": margin]
        
        superview!.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-margin-[view]", options: NSLayoutFormatOptions(), metrics: metrics, views: views))
    }
    
    func setRightMargin(_ margin: Int = 15) {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let views = ["view": self]
        let metrics = ["margin": margin]
        
        superview!.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[view]-margin-|", options: NSLayoutFormatOptions(), metrics: metrics, views: views))
    }
    
    func setTopMargin(_ margin: Int = 15) {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let views = ["view": self]
        let metrics = ["margin": margin]
        
        superview!.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-margin-[view]", options: NSLayoutFormatOptions(), metrics: metrics, views: views))
    }
    
    func setBottomMargin(_ margin: Int = 15) {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let views = ["view": self]
        let metrics = ["margin": margin]
        
        superview!.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[view]-margin-|", options: NSLayoutFormatOptions(), metrics: metrics, views: views))
    }    
}
