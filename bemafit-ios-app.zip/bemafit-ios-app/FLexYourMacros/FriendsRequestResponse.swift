//
//  FriendsRequestResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 07/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FriendsRequestResponse: NSObject {
    var metaModel: MetaModel?
    var friendRequest:FriendRequestModel?
    var friend_id: String?

    class var friendsRequestResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(FriendsRequestResponse.metaModelKeyMapping)
        
        // give reference to message item model
        responseMapping?.addPropertyMapping(FriendsRequestResponse.friendRequestModelMapping)
        
        return responseMapping!
    }

    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }    
    
    fileprivate class var friendRequestModelMapping :RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathSendFriendRequest, toKeyPath: "friendRequest", with: FriendRequestModel.objectMapping)
    }
    
    
    class var userResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: friendsRequestResponseMapping, method: .PUT, pathPattern: Constants.ServiceConstants.sendFriendRequestUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
  
    class func sendFriendRequest(_ friendId:String,status:String,completionHandler: @escaping (_ friendRequestresponse:FriendsRequestResponse) -> () ) {
        
        RestKitManager.setToken(true)
        
        let friendRequestresponse = FriendsRequestResponse()
        
        friendRequestresponse.friend_id = friendId
        
        let params = ["response_status": status] as Dictionary<String, String>
        
         var err: NSError?
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: friendRequestresponse, method: .PUT, path: nil, parameters: nil, constructingBodyWith: { (formData) in
            
        })
//        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: friendRequestresponse, method: .PUT, path: nil, parameters: nil, constructingBodyWith: { (formData) in
//            
//        })
        
        
        do {
            request.httpBody =  try JSONSerialization.data(withJSONObject: params, options: [])
        } catch let error as NSError {
            err = error
            request.httpBody = nil
        }
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let response = mappingResult?.firstObject as! FriendsRequestResponse
            //print("respone code :\(response.metaModel?.responseCode)")
            //print("respone status :\(response.metaModel?.responseStatus)")
            
            // check for success
            /*   if response.metaModel?.responseCode != 200 {
             return
             }
             
             */
            completionHandler(response)
            //print("Success ")
        }) {  (operation, error) in
            //print("failed to load change password with error \(error)")
        }
    
//        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) -> Void in
//            
//            let response = mappingResult.firstObject as! FriendsRequestResponse
//            //print("respone code :\(response.metaModel?.responseCode)")
//            //print("respone status :\(response.metaModel?.responseStatus)")
//            
//            // check for success
//         /*   if response.metaModel?.responseCode != 200 {
//              return
//           }
//            
//           */ 
//            completionHandler(friendRequestresponse: response)
//               //print("Success ")
//
//            
//            }) { (operation, error) in
//                
//                //print("failed to load change password with error \(error)")
//        })
        
        RestKitManager.shared().enqueue(operation)
    
    
    }
    
  }
