//
//  UserSignUpCompletionViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 05/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UserSignUpCompletionViewController: UITableViewController, UITextFieldDelegate, SignUpCompleteTableViewCellDelegate {
    
    struct StoryBoard {
        
        struct CellIdentifiers {
            static let UpdateCell =  "kUpdateCell"
            static let HeaderCell    =  "kHeaderCell"
            static let CalorieCell      =  "kCalorieCell"
            static let FiberCell  =  "kFibreCell"
            static let MacroCell = "kMacroCell"
            static let CustomCell       = "kCustomCell"
        }
        
        struct SegueIdentifiers {
            static let CompleteSignUp = "kSignUpComplete"
        }
        
        struct ViewControllerIdentifiers {
            static let LogInVC = "kEmailVC"
        }
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    @IBOutlet var tabelView: UITableView!
    var didEdit: Bool = false
    let FYMUserModel = FymUser.sharedFymUser
    var currentTextField = UITextField()
    var customCarbPercentage: Double = 0.0
    var customFatPercentage: Double = 0.0
    var customProteinPercentage: Double = 0.0
    var isUpdateButtonPresent = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.rightBarButtonItem?.setTitleTextAttributes([NSFontAttributeName: UIFont(name: "Helvetica", size: 13.0)!], for: UIControlState())
        
        customCarbPercentage = FYMUserModel.userCustomCarbsPercentage
        customFatPercentage = FYMUserModel.userCustomFatPercentage
        customProteinPercentage = FYMUserModel.userCustomProteinPercentage
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 5
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        if section == 4 {
            return 1
        } else if section == 2 {
            return 3
        }
        return 1
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 4 {
            return 0
        }
        return 40.0
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        //        // section four of the table contains the update button
        if section == 4 {
            return UIView(frame: CGRect.zero)
        }
        let headerView = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.HeaderCell) as! SignUpCompleteTableViewCell
        headerView.labelHeaderTitle.text = setSectionHeaderTitles(section)
        return headerView
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.section == 4 {
            return 120.0
        }
        return 60.0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = SignUpCompleteTableViewCell()
        if indexPath.section == 0 {
            // section zero holds the calorie prototype cell
            cell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.CalorieCell, for: indexPath) as! SignUpCompleteTableViewCell
            cell.configureCell()
        } else if indexPath.section == 1 {
            // section one holds the fibre prototype cell
            cell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.FiberCell, for: indexPath) as! SignUpCompleteTableViewCell
            cell.textFieldFiber.delegate = self
            cell.textFieldFiber.tag = 120
            cell.textFieldFiber.isUserInteractionEnabled = FYMUserModel.userNutritionType == "5" ? true : false
            cell.configureCell()
            return cell
        } else if indexPath.section == 2 {
            // section two holds the macro prototype cell
            cell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.MacroCell, for: indexPath) as! SignUpCompleteTableViewCell
            cell.textFieldMacroValue.delegate = self
            cell.textFieldMacroValue.tag = indexPath.row
            //  based on the selected nutrition type user interaction for the macro breakdown cells are managed
            cell.textFieldMacroValue.isUserInteractionEnabled = FYMUserModel.userNutritionType == "5" ? true : false
            cell.tag = indexPath.row
            cell.configureCell()
            return cell
        } else if indexPath.section == 3 {
            // custom cell for entering meal number
            cell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.CustomCell, for: indexPath) as! SignUpCompleteTableViewCell
            cell.textFieldMealNumber.delegate = self
            cell.textFieldMealNumber.tag = 110;
            cell.configureCell()
        } else if indexPath.section == 4 {
            // custom cell for entering meal number
            cell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.UpdateCell) as! SignUpCompleteTableViewCell
            // if in editing mode update button is visible
            //            if didEdit {
            cell.buttonUpdate.isHidden = FYMUserModel.userNutritionType != "5"
            isUpdateButtonPresent = true
            //            } else {
            //                cell.buttonUpdate.hidden = true
            //                isUpdateButtonPresent = false
            //            }
            
            cell.signUpCompleteTableViewCellDelegate = self
        }
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if tableView.cellForRow(at: indexPath)?.reuseIdentifier == StoryBoard.CellIdentifiers.MacroCell  {
            
            let cell = tableView.cellForRow(at: indexPath) as! SignUpCompleteTableViewCell
            
            cell.textFieldMacroValue.becomeFirstResponder()
        }
        
    }
    
    func setSectionHeaderTitles(_ sectionIndex: Int) -> String {
        
        // manage the header titles for the sections in the table view
        var headerTitle: String
        
        switch sectionIndex {
        case 0:
            headerTitle = &&"calculate_calories"
        case 1:
            headerTitle = &&"fiber_goal"
        case 2:
            headerTitle = &&"calculate_macros"
        case 3:
            headerTitle = &&"no_of_meals"
        default :
            headerTitle = ""
        }
        
        return headerTitle
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        //print("string ---\(string)")
        // managing the textfield input: limit the characters to only of numeric type
        
        if string == " " {
            return false
        }
        
        if string.isEmpty {
            return true
        }
        
        var isValid = true
        let text = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        
        // check for unwanted characters
        let replacementStringIsLegal = string.rangeOfCharacter(from: CharacterSet(charactersIn: "0123456789.").inverted) == nil
        
        
        if textField.tag == 120 {
            // textfield fiber
            
            // check for string count
            let resultingStringLengthIsLegal = text.characters.count <= 7
            
            
            // check if the number is valid
            let scanner = Scanner(string: text)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
            
            let isLowNumber = text.doubleValue < 100000
            
            isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber
        }
        else if textField.tag == 110 {
            // number of meals
            
            var result = true
            let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
            if string.characters.count > 0 {
                let disallowedCharacterSet = CharacterSet(charactersIn: "0123456789").inverted
                let replacementStringIsLegal = string.rangeOfCharacter(from: disallowedCharacterSet) == nil
                let resultingStringLengthIsLegal = prospectiveText.characters.count <= 10
                let scanner = Scanner(string: prospectiveText)
                let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
                result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
            }
            return result
        }
        else {
            
            // check for string count
            let resultingStringLengthIsLegal = text.characters.count <= 5
            
            
            // check if the number is valid
            let scanner = Scanner(string: text)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
            
            let isLowNumber = text.doubleValue <= 100
            
            isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber
            
        }
        
        return isValid
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        //        if textField.tag != 110 {
        //            textField.text = ""
        //        }
        currentTextField = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        // on return of text field editing update the user model with macro values
        if textField.tag == 0 {
            customFatPercentage  = textField.text!.doubleValue
            if checkTheMacroTotal() {
            }
        } else if textField.tag == 1 {
            customCarbPercentage  = textField.text!.doubleValue
            if checkTheMacroTotal() {
            }
        } else if textField.tag == 2 {
            customProteinPercentage  = textField.text!.doubleValue
            if checkTheMacroTotal() {
            }
        } else if textField.tag == 110 {
            FYMUserModel.userNumberOfMeals  = textField.text!.intValue
            currentTextField.resignFirstResponder()
        } else if textField.tag == 120 {
            //fiber value entered
            FYMUserModel.userCustomFiberValue = textField.text!
            currentTextField.resignFirstResponder()
        }
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        // on ending of text field editing update the user model with macro values
        //print("//print tag----\(textField.tag)")
        if textField.tag == 0 {
            customFatPercentage  = textField.text!.doubleValue
            if checkTheMacroTotal() {
            }
        } else if textField.tag == 1 {
            customCarbPercentage  = textField.text!.doubleValue
            if checkTheMacroTotal() {
            }
        } else if textField.tag == 2 {
            customProteinPercentage  = textField.text!.doubleValue
            if checkTheMacroTotal() {
            }
        } else if textField.tag == 110 {
            FYMUserModel.userNumberOfMeals  = textField.text!.intValue
        } else if textField.tag == 120 {
            //fiber value entered
            FYMUserModel.userCustomFiberValue = textField.text!
            currentTextField.resignFirstResponder()
            
        }
        
    }
    
    func checkTheMacroTotal() -> Bool {
        
        currentTextField.resignFirstResponder()
        
        // check macro total : show alert when it is not equal to 100%
        var checkMacro = true
        var totalMacroPercentage = customFatPercentage + customCarbPercentage + customProteinPercentage
        let roundedTotalMacroPercentage = totalMacroPercentage.roundPlaces(3)
        if  roundedTotalMacroPercentage > 99.994 && roundedTotalMacroPercentage <= 100.0 {
            didEdit = true
            
            //            self.tableView .reloadSections(NSIndexSet(indexesInRange: NSMakeRange(4, 1)), withRowAnimation: UITableViewRowAnimation.Left)
            
            
        } else {
            checkMacro = false
            didEdit = false
            
            //            self.tableView .reloadSections(NSIndexSet(indexesInRange: NSMakeRange(4, 1)), withRowAnimation: UITableViewRowAnimation.Left)
        }
        return checkMacro
    }
    
    @IBAction func unwindToUserSignUpCompletionViewController(_ segue: UIStoryboardSegue) {
        // close the side menu if its open
    }
    
    @IBAction func buttonActionSignUpCompletion(_ sender: UIBarButtonItem) {
        
        
        currentTextField.resignFirstResponder()
        
        if FYMUserModel.userNutritionType == "5" {
            
            
            if(!self.validateCustomEntry())
            {
                return
            }
            
            
        }
        
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        UserSignUpResponse.signUpUser(self, completionHandler: { (userDetails, userDiet) -> () in
            
            if userDetails.userFacebookId != "" {
                
                // the current user is a facebook user
                FacebookUserLogInResponse.logInFacebookUser(self, facebookAccessToken: UserFacebookCredentialModel.sharedUserFacebookCredentialModel.userFbAccessToken!, completionHandler: { (accessCredential, userDiet, userDetails) -> () in
                    
                    AppConfiguration.sharedAppConfiguration.userDetails = userDetails
                    
                    AppConfiguration.sharedAppConfiguration.userDiet = userDiet
                    
                    AppConfiguration.sharedAppConfiguration.userCredential = accessCredential
                    
                    //print("accesstoken:\(AppConfiguration.sharedAppConfiguration.userCredential?.accessToken)")
                    //print("userid:\(AppConfiguration.sharedAppConfiguration.userDetails?.userId)")
                    
                    // load dashboard
                    Flurry.logEvent("Sign up with Facebook", withParameters: ["userID" : AppConfiguration.sharedAppConfiguration.userDetails?.userId])
                    self.appDelegate?.loadDashboard()
                    
                    }, failedWithError: { (error) -> () in
                        self.showAlert(&&"notice", message: error)
                        
                })
                
                return
                
            }
            
            if !reachability {
                
                self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                return
            }
            
            UserLogInResponse.logInUser(self, username: self.FYMUserModel.userEmail, password: self.FYMUserModel.userPassword, completionHandler: { (accessCredential, userDiet, userDetails) -> () in
                
                FymUser.resetSharedInstance()
                
                //save user sign up time
                let userDefaults = UserDefaults.standard
                userDefaults.set(Date(), forKey: "created_date")
                userDefaults.synchronize()
                
                AppConfiguration.sharedAppConfiguration.userDetails = userDetails
                
                AppConfiguration.sharedAppConfiguration.userDiet = userDiet
                
                AppConfiguration.sharedAppConfiguration.userCredential = accessCredential
                
                //print("accesstoken:\(AppConfiguration.sharedAppConfiguration.userCredential?.accessToken)")
                
                //                self.showAlert(&&"notice", message: &&"user_registration_completed_alert_message")
                
                // load dashboard
                
                Flurry.logEvent("Signup with Email", withParameters: ["useremail" : self.FYMUserModel.userEmail, "userID" : AppConfiguration.sharedAppConfiguration.userDetails?.userId])
                self.appDelegate?.loadDashboard()
                
                
                }, failedWithError: { (error) -> () in
                    self.showAlert(&&"notice", message: error)
            })
            
            }) { (failed) -> () in
                self.showAlert(&&"notice", message: failed)
                
        }
        
    }
    
    func showAlert(_ title: String, message: String) {
        
        if #available(iOS 8.0, *) {
            
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return
            
        } else {
            // Fallback on earlier versions
            
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"ok").show()
            return
        }
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        cell.setSeparatorInsetZero()
    }
    
    func buttonActionUpdate(_ signUpCompleteTableViewCell: SignUpCompleteTableViewCell) {
        
        currentTextField.resignFirstResponder()
        
        didEdit = false
        FYMUserModel.userCustomFatPercentage = customFatPercentage
        FYMUserModel.userCustomCarbsPercentage = customCarbPercentage
        FYMUserModel.userCustomProteinPercentage = customProteinPercentage
        
        self.tableView.reloadData()
        self.validateCustomEntry()
        
    }
    
    func validateCustomEntry() -> Bool{
        if FYMUserModel.userNutritionType == "5" {
            
            let totalMacroPercentage = customFatPercentage + customCarbPercentage + customProteinPercentage
            
            if FYMUserModel.userCustomFiberValue.doubleValue <= 0.0 {
                
                if #available(iOS 8.0, *) {
                    let alert = UIAlertController(title: &&"notice", message: &&"custom_fiber_greater_zero", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    
                } else {
                    // Fallback on earlier versions
                    
                    UIAlertView(title: &&"notice", message: &&"custom_fiber_greater_zero", delegate: nil, cancelButtonTitle: &&"ok").show()
                }
                
                return false
            }
            
            if Int(totalMacroPercentage) != 100 {
                
                // show alert controller if possible else show alert view
                if #available(iOS 8.0, *) {
                    
                    let alert = UIAlertController(title: &&"notice", message: &&"macro_percentage_add_upto_100", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    
                } else {
                    // Fallback on earlier versions
                    
                    UIAlertView(title: &&"notice", message: &&"macro_percentage_add_upto_100", delegate: nil, cancelButtonTitle: &&"ok").show()
                }
                return false
            }
            
            FYMUserModel.userCustomFatPercentage = customFatPercentage
            FYMUserModel.userCustomCarbsPercentage = customCarbPercentage
            FYMUserModel.userCustomProteinPercentage = customProteinPercentage
            return true
        }
        else
        {
            return true
        }
    }
    
    @IBAction func buttonActionBack(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        if (identifier == StoryBoard.SegueIdentifiers.CompleteSignUp) {
            
            let signInViewController = self.storyboard?.instantiateViewController(withIdentifier: StoryBoard.ViewControllerIdentifiers.LogInVC) as! UserEmailLogInViewController
        }
        return true
    }
}
