//
//  Exercise.swift
//  FlexYourMacros
//
//  Created by mini on 25/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

// MARK:

enum ExerciseType: String {
    case Strength = "strength"
    case CardioVascular = "cardiovascular"
    case None = ""
}

enum ExerciseTypeId: String {
    case CardioVascular = "1"
    case Strength = "2"
    case None = ""
}

class Exercise: HeightCalculating {
    var name = ""
    var date = Date()
    var caloriesBurned = 0.0
    var exerciseId = ""
    var exerciseLogId = ""
    var exerciseMetValue = ""
    // in seconds
    var exerciseAmount = 0.0
    var exerciseMethod = ""
    var caloriesPerMinute = ""
    var caloriesPerHour = ""
    var exerciseModel:ExerciseModel?
    var source_id = -1


    var expectedHeight: CGFloat {
        return 191.0
    }
    
    var exerciseTypeId: ExerciseTypeId = .None

    fileprivate(set) var exerciseType: ExerciseType = .None
    
    init(name: String) {
        self.name = name
    }
    
    func copy() -> Exercise {
        
        var copiedExercise: Exercise
        
        // create the correct exercise object
        if exerciseType == ExerciseType.Strength {
            copiedExercise = StrengthExercise(name: name)
            
        }
        else if exerciseType == ExerciseType.CardioVascular {
            copiedExercise = CardioVascularExercise(name: name)
        }
        else {
            copiedExercise = Exercise(name: name)
        }
        
        // copy the exercise values
        copiedExercise.exerciseId = exerciseId
        copiedExercise.date = date
        copiedExercise.caloriesBurned = caloriesBurned
        copiedExercise.exerciseType = exerciseType
        copiedExercise.exerciseTypeId = exerciseTypeId
        copiedExercise.exerciseMetValue = exerciseMetValue
        copiedExercise.caloriesPerMinute = caloriesPerMinute
        copiedExercise.caloriesPerHour = caloriesPerHour


        return copiedExercise
    }
    
    func toMultiValDictionaryForShareExerciseLogs() -> [String: Any] {
        
        var caloriesBurned:String = (self.exerciseModel?.exerciseDetails.exerciseCalorieBurned)!
        
        if caloriesBurned.components(separatedBy: ".").count == 1 {
            caloriesBurned = "\(caloriesBurned).0"
        }
        
        return ["exercise_name" : (self.exerciseModel?.exerciseName)! as Any,
                "exercise_time" : (self.exerciseModel?.exerciseDetails.exerciseAmount)! as Any,
                "exercise_sets_reps" : (self.exerciseModel?.exerciseDetails.exerciseReps)! as Any,
                "exercise_id" : (self.exerciseModel?.exerciseId)! as Any,
                "exercise_sets" : (self.exerciseModel?.exerciseDetails.exerciseSets)! as Any,
                "exercise_weight_per_set" : (self.exerciseModel?.exerciseDetails.exerciseWeight)! as Any,
                "exercise_distance" : (self.exerciseModel?.exerciseDetails.exerciseDistance)! as Any,
                "exercise_calorie_burned" : caloriesBurned,
                "exercise_type" : (self.exerciseModel?.exerciseTypeId)!,
                "source_id" : (self.exerciseModel?.source_id)!
        ]

    }
    
    class func fetchExercisesLogs(_ offSet: String, showHUD: Bool = false, date: Date, completionHandler:@escaping (_ exerciseList: [Exercise])->()) {
        if showHUD {
            SVProgressHUD.show()
        }

        ExerciseResponse.fetchExerciseList(offSet, date: date) { (exerciseList, error) -> () in
            if showHUD {
                SVProgressHUD.dismiss()
            }
            if error == nil {
                completionHandler(exerciseList) }
        }
    }
    
    class func fetchExercises(_ offset: String,name: String, type: String, completionHandler:@escaping (_ exercises: [Exercise])->()) {
        
        ExerciseTypeResponse.fetchExerciseTypes(offset, name: name, type:type, completionHandler: { (exercises) -> () in
            completionHandler(exercises)
        })
       
    }
    
    class func fetchCardioExercises(_ offset: String, name: String, type: String, completionHandler:@escaping (_ cardioExercises: [CardioVascularExercise])->()) {
            Exercise.fetchExercises (offset,name:name, type:type, completionHandler: { (exercises) -> () in
//                let cardioExercises = exercises.filter { $0.exerciseType == .CardioVascular }
                completionHandler(exercises as! [CardioVascularExercise])
            })
    }
    
    class func fetchStrengthExercises(_ offset: String, name: String, type: String, completionHandler:@escaping (_ strengthExercises: [StrengthExercise])->()) {
        Exercise.fetchExercises (offset, name:name, type:type, completionHandler: { (exercises) -> () in
//            let strengthExercises = exercises.filter { $0.exerciseType == .Strength }
            completionHandler(exercises as! [StrengthExercise])
        })
    }
    
    class func createExercise(_ strengthExercise: StrengthExercise,cardioExercise: CardioVascularExercise, completionHandler:@escaping (_ createdExerciseId: String, _ successful: Bool, _ message: String)->()) {
        
        // create an exercise
        var paramDictionary = [String: String]()

        if strengthExercise.name != "" {
            
            paramDictionary["name"] = strengthExercise.name
            paramDictionary["amount"] = strengthExercise.exerciseAmount.stringValue
            paramDictionary["calorie_burned"] = strengthExercise.caloriesBurned.stringValue
            paramDictionary["type"] = "2"//ExerciseCategory.Strength.rawValue
            paramDictionary["number_of_sets"] = strengthExercise.sets.stringValue
            paramDictionary["rep_sets"] = strengthExercise.reps.stringValue
            paramDictionary["rep_set_weight"] = strengthExercise.weight.stringValue
            
        } else if cardioExercise.name != "" {
            
            paramDictionary["name"] = cardioExercise.name
            paramDictionary["amount"] = cardioExercise.exerciseAmount.stringValue
            paramDictionary["calorie_burned"] = cardioExercise.caloriesBurned.stringValue
            paramDictionary["type"] = "1"//ExerciseCategory.CardioVascular.rawValue
            paramDictionary["distance"] = cardioExercise.distance.stringValue
        }
        
        paramDictionary["locale"] = "\((Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)!)"

        ExerciseCreateResponse.createExercise(paramDictionary, completionHandler: { (createdExerciseId, successful, message) -> () in
            completionHandler(createdExerciseId, successful, message)

        })
        
    }
    
    //delete an exercise
    class func deleteExercise(_ exerciseId: String, completionHandler:@escaping (_ deletedStatus: Bool)->()) {
        ExerciseDeleteResponse.deleteExercise(exerciseId, completionHandler: { (deletedStatus) -> () in
            completionHandler(deletedStatus)
        })
    }
    
    class func updateExercise(_ exercise: Exercise, completionHandler:@escaping (_ updatedStatus: Bool)->()) {
        //update exercise date
        ExerciseUpdateResponse.updateExercise(exercise.date, exerciseId: exercise.exerciseLogId) { (updatedStatus) -> () in
        completionHandler(updatedStatus)
        }
    }
}

class StrengthExercise: Exercise {
    var sets = 0.0
    var reps = 0.0
    var weight = 0.0
    
    override var expectedHeight: CGFloat {
        return 191.0
    }
    
    override init(name: String) {
        super.init(name: name)
        exerciseType = .Strength
    }
    
    override func copy() -> StrengthExercise {
        let copiedExercise = super.copy() as! StrengthExercise
        copiedExercise.sets = sets
        copiedExercise.reps = reps
        copiedExercise.weight = weight
        return copiedExercise
    }
}

class CardioVascularExercise: Exercise {
    
    // XXX think of units here
    var distance = 0.0
    
    override var expectedHeight: CGFloat {
        return 130.0
    }
    
    override init(name: String) {
        super.init(name: name)
        exerciseType = .CardioVascular
    }
    
    override func copy() -> CardioVascularExercise {
        let copiedExercise = super.copy() as! CardioVascularExercise
        copiedExercise.distance = distance
        return copiedExercise
    }
}
