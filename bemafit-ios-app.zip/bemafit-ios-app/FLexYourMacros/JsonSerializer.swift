//
//  JsonSerializer.swift
//  FlexYourMacros
//
//  Created by mini on 29/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation


open class JsonSerializer : NSObject{
    // http://stackoverflow.com/questions/27989094/how-to-unwrap-an-optional-value-from-any-type
    func unwrap(_ any:Any) -> Any? {
        let mi = Mirror(reflecting: any)
        if mi.displayStyle != .optional {
            return any
        }
        
        // Optional.None
        if mi.children.count == 0 {
            return nil
        }
        
        let (_,some) = mi.children.first!
        return some
    }
    
    open func toDictionary() -> NSDictionary {
        let propertiesDictionary = NSMutableDictionary()
        let mirror = Mirror(reflecting: self)
        for object in mirror.children {
            let (propName, childMirror) = object
            if let propValue:Any = unwrap(childMirror) as? Any {
                if let serializeablePropValue = propValue as? JsonSerializer {
                    propertiesDictionary.setValue(serializeablePropValue.toDictionary(), forKey: propName!)
                } else if let arrayPropValue = propValue as? Array<JsonSerializer> {
                    var subArray = Array<NSDictionary>()
                    for item in arrayPropValue {
                        subArray.append(item.toDictionary())
                    }
                    propertiesDictionary.setValue(subArray, forKey: propName!)
                } else if propValue is Int || propValue is Double || propValue is Float {
                    propertiesDictionary.setValue(propValue, forKey: propName!)
                } else if let dataPropValue = propValue as? Data {
                    propertiesDictionary.setValue(dataPropValue.base64EncodedString(options: []), forKey: propName!)
                } else if let boolPropValue = propValue as? Bool {
                    propertiesDictionary.setValue(boolPropValue, forKey: propName!)
                } else {
                    propertiesDictionary.setValue(propValue, forKey: propName!)
                }
            }
        }
        
        return propertiesDictionary
    }
    
    open func toJson() -> Data {
        let dictionary = self.toDictionary()
        
        var err: NSError?
        do {
            let json = try JSONSerialization.data(withJSONObject: dictionary, options:JSONSerialization.WritingOptions(rawValue: 0))
            return json
        } catch var error1 as NSError {
            err = error1
            let error = err?.description ?? "nil"
            NSLog("ERROR: Unable to serialize json, error: %@", error)
            NotificationCenter.default.post(name: Notification.Name(rawValue: "CrashlyticsLogNotification"), object: self, userInfo: ["string": "unable to serialize json, error: \(error)"])
            abort()
        }
    }
    
    open func toJsonString() -> NSString! {
        return NSString(data: self.toJson(), encoding: String.Encoding.utf8.rawValue)
    }
    
}
