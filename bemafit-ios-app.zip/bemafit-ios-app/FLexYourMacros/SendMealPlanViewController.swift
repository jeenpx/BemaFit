//
//  SendMealPlanViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 11/18/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class SendMealPlanCell: UITableViewCell {
    
 @IBOutlet weak var imageViewTick: UIImageView!
 @IBOutlet weak var imageViewProfilePic: UIImageView!
 @IBOutlet weak var labelUsername: UILabel!
 @IBOutlet weak var labelName: UILabel!
    
    
}

class SendMealPlanViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    struct StoryBoard {
        struct CellIdentifiers {
            static let sendMealPlanCellIdentifier = "kSendMealPlanCell"
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let sendMealPlanCell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.sendMealPlanCellIdentifier)
        return sendMealPlanCell!
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 85.0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func buttonActionDismissViewController(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popViewController(animated: true)
    }
}
