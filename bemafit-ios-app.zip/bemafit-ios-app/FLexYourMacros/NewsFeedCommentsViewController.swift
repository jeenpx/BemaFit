//
//  NewsFeedCommentsViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 27/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class NewsFeedCommentsViewController: SLKTextViewController, NewsFeedCommentCellDelegate, EnlargeImageCommentDelegate, SWTableViewCellDelegate {
    
    // XXX fetch the hasttags here
    let hashTags = [String]()
    let users = [String]()
    
    // selected hashtag
    var hashTag = ""
    
    // newsFeed for which the comments are listed
    var newsFeed = NewsFeed()
    
    // list of news feeds
    fileprivate var newsFeedComments = [NewsFeedComment]()
    
    // search results which is optional
    fileprivate var searchResults: [String]?
    
    // refresh control
    let refreshControl = UIRefreshControl()
    
    var shouldReload = true
    
    var pageMeta = PageMetaModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // configure the chat view
        configureView()
        
        //print(NSUserDefaults.standardUserDefaults().objectForKey("accesstoken"))
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        title = &&"comments"
        
        // fetch news feed comments
        if shouldReload {
            
            // reset page meta data
            pageMeta = PageMetaModel()
            
            self.newsFeed.fetchComments(pageMeta: pageMeta) { (newsFeedComments, pageMeta) in
                self.pageMeta = pageMeta
                self.newsFeedComments = Array(newsFeedComments.reversed())
                self.tableView.reloadData()
                
                DispatchQueue.main.async {
                    // scroll to bottom
                    self.scrollToBottom()
                }
            }
        }
    }
    
    func configureView() {
        
        // set basic properties for the view
        // XXX double check this
        bounces = true
        shakeToClearEnabled = true
        isKeyboardPanningEnabled = true
        shouldScrollToBottomAfterKeyboardShows = false
        isInverted = false
        
        // setup tableview
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.register(UINib(nibName: "NewsFeedCommentCell", bundle: nil), forCellReuseIdentifier: Storyboard.CellIdentifiers.NewsFeedCommentCellIdentifier)
        
        // set estimated row height
        // XXX setting the lowest height now, recheck
        tableView.estimatedRowHeight = 230.0
        tableView.rowHeight = UITableViewAutomaticDimension
        
        // setup refresh control
        refreshControl.addTarget(self, action: #selector(NewsFeedCommentsViewController.pullToRefresh(_:)), for: UIControlEvents.valueChanged)
        refreshControl.tintColor = UIColor.gray
        
        // add refresh control to the tableview
        tableView.addSubview(refreshControl)
        
        // setup textview
        textView.placeholder = NSLocalizedString("post_placeholder_text", comment: "")
        textView.pastableMediaTypes = SLKPastableMediaType()
        
        // setup buttons
        leftButton.setImage(UIImage(named: "CameraIcon"), for: UIControlState())
        rightButton.setTitle(&&"post_button_title", for: UIControlState())
        
        // setup textinputbar
        textInputbar.editorTitle.textColor = UIColor.darkGray
        
        textInputbar.editorLeftButton.tintColor = UIColor(red: 0, green: 122.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        textInputbar.editorRightButton.tintColor = UIColor(red: 0, green: 122.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        // textInputbar.editortLeftButton.tintColor = UIColor(red: 0, green: 122.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        // textInputbar.editortRightButton.tintColor = UIColor(red: 0, green: 122.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        
        textInputbar.autoHideRightButton = false
        textInputbar.counterStyle = SLKCounterStyle.none
        
        typingIndicatorView.canResignByTouch = true
        
        autoCompletionView.register(NewsFeedCell.self, forCellReuseIdentifier:Storyboard.CellIdentifiers.AutoCompletionCellIdentifier)
        registerPrefixes(forAutoCompletion: ["#", "@"])
    }
    
    override func canPressRightButton() -> Bool {
        return super.canPressRightButton()
    }
    
    override func canShowAutoCompletion() -> Bool {
        
        // clear the search results array
        let autoCompletionList = foundPrefix == "#" ? hashTags : users
        searchResults = autoCompletionList as [String]
        
        // filter hashtags
        let predicate = NSPredicate(format: "SELF BEGINSWITH[C] %@", foundWord)
        if foundWord.characters.count > 0 {
            searchResults = autoCompletionList.filter {
                predicate.evaluate(with: $0)
            }
        }
        
        // sort the search results
        if let _ = searchResults {
            (searchResults!).sort(by: <)
        }
        
        return searchResults?.count > 0
    }
    
    override func didPressLeftButton(_ sender: Any!) {
        super.didPressLeftButton(sender)
        
        // hide keyboard to show actionsheet on top
        view.endEditing(true)
        
        // no need to reload data after picking image
        shouldReload = false
        
        // fetch image from image picker
        ImagePickerManager.sharedManager.presentImagePicker(self) { (image, source) in
            self.textView.insertImage(image)
            DispatchQueue.main.async {
                self.textView.becomeFirstResponder()
                self.textView.selectedRange = NSMakeRange(self.textView.text.characters.count, 0)
            }
        }
    }
    
    override func didPressRightButton(_ sender: Any!) {
        
        // validate any pending auto-correction or auto-spelling
        textView.refreshFirstResponder()
        
        // create a new newsfeed comment
        textView.getInsertedImage { image in
            // comment
            self.newsFeed.comment(self.textView.text, image: image) { (newsFeedComment, error) -> () in
                if error != nil {
                    // XXX handle error
                }
                
                // update in main thread
                DispatchQueue.main.async {
                    
                    // update tableview
                    if let newsFeedComment = newsFeedComment {
                        self.tableView.beginUpdates()
                        self.newsFeedComments += [newsFeedComment]
                        self.tableView.insertRows(at: [IndexPath(row: self.newsFeedComments.count - 1, section: 0)], with: .bottom)
                        self.tableView.endUpdates()
                        
                        // scroll table view to botton
                        self.scrollToBottom(true)
                    }
                }
            }
            
            // cleanup the textview (weird huh?)
            DispatchQueue.main.async {
                self.textView.attributedText = nil
                self.textView.text = "   "
                self.textView.font = UIFont.systemFont(ofSize: 16)
                self.textView.slk_clearText(true)
                self.dismissKeyboard(true)
            }
        }
        
        // call the super method in the end with some
        // additional cleanup to handle image insertions
        // super method will do the cleanup
        super.didPressRightButton(sender)
    }
    
    override func didPasteMediaContent(_ userInfo: [AnyHashable: Any]!) {
        super.didPasteMediaContent(userInfo)
        
        // XXX do something related to image upload here
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableView == autoCompletionView ? searchResults?.count ?? 0 : newsFeedComments.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return newsFeedComments[indexPath.row].expectedHeight
        return UITableViewAutomaticDimension
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell
        
        if tableView == self.tableView {
            cell = self.tableView(tableView, newsFeedCommentCellForRowAtIndexPath: indexPath)
        } else {
            cell = self.tableView(tableView, autoCompletionCellForRowAtIndexPath: indexPath)
        }
        
        // update the cell transform
        cell.transform = tableView.transform
        cell.layoutIfNeeded()
        return cell
    }
    
    func tableView(_ tableView: UITableView, newsFeedCommentCellForRowAtIndexPath indexPath: IndexPath) -> NewsFeedCommentCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.NewsFeedCommentCellIdentifier) as! NewsFeedCommentCell
        
        cell.newsFeedComment = newsFeedComments[indexPath.row]
        cell.newsFeed = newsFeed
        cell.newsFeedCommentCellDelegate = self
        cell.enlargeImageCommentDelegate = self
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, autoCompletionCellForRowAtIndexPath indexPath: IndexPath) -> NewsFeedCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.AutoCompletionCellIdentifier) as! NewsFeedCell
        
        // XXX configure cell here
        cell.textLabel?.text = searchResults![indexPath.row]
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return tableView == autoCompletionView ? 0.5 : 0
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        cell.setSeparatorInsetZero()
        
        (cell as? NewsFeedCommentCell)?.newsFeedComment = newsFeedComments[indexPath.row]
        cell.layoutSubviews()
        cell.layoutIfNeeded()
    }
    
    override func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        tableView.reloadData()
    }
    
    override func didChange(_ status: SLKKeyboardStatus) {
        // scroll to bottom
        scrollToBottom(true)
    }
    
    override func heightForAutoCompletionView() -> CGFloat {
        let cellHeight = CGFloat(44.0)
        let cellCount = CGFloat(searchResults?.count ?? 0)
        
        return cellHeight * cellCount
    }
    
    func pullToRefresh(_ sender: UIRefreshControl) {
        
        if !pageMeta.isValid {
            self.refreshControl.endRefreshing()
            return
        }
        
        // fetch news feed comments and reload table
        newsFeed.fetchComments(false, pageMeta: pageMeta) { (newsFeedComments, pageMeta) in
            self.pageMeta = pageMeta
            self.newsFeedComments = Array(newsFeedComments.reversed()) + self.newsFeedComments
            self.refreshControl.endRefreshing()
            self.tableView.reloadData()
        }
    }
    
    func scrollToBottom(_ animated: Bool = false) {
        // scroll table view to bottom
        if tableView.numberOfRows(inSection: 0) > 0 {
            tableView.scrollToRow(at: IndexPath(row: tableView.numberOfRows(inSection: 0) - 1, section: 0), at: UITableViewScrollPosition.bottom, animated: animated)
        }
    }
    
    func newsFeedCommentCell(_ newsFeedCommentCell: NewsFeedCommentCell, didSelectUser userId: String) {
        performSegue(withIdentifier: Storyboard.Segues.ProfileSegue, sender: userId)
    }
    
    func newsFeedCommentCell(_ newsFeedCommentCell: NewsFeedCommentCell, didSelectHashTag hashTag: String) {
        self.hashTag = hashTag
        performSegue(withIdentifier: Storyboard.Segues.HashTagSegue, sender: self)
    }
    
    struct Storyboard {
        struct Segues {
            static let ProfileSegue = "kProfileSegue"
            static let HashTagSegue = "kCommentHashTagSegue"
        }
        struct CellIdentifiers {
            static let NewsFeedCommentCellIdentifier = "kNewsFeedCommentCell"
            static let AutoCompletionCellIdentifier = "kAutoCompletionCell"
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == Storyboard.Segues.ProfileSegue {
            let profileViewController = segue.destination as! ProfileViewController
            profileViewController.userId = sender as? String ?? ""
        } else if segue.identifier == Storyboard.Segues.HashTagSegue {
            let hashTagViewController = segue.destination as! HashTagViewController
            hashTagViewController.hashTag = hashTag
        }
    }
    
    @IBAction func unwindToDashboardViewController(_ segue: UIStoryboardSegue) {
        // close the side menu if its open
    }
    
    func enlargeImageView(_ selectedCell: NewsFeedCommentCell, imageViewComment: UIImageView) {
        // enlarge the imageview
        
        let imageInfo = JTSImageInfo()
        imageInfo.image = imageViewComment.image
        
        // imageInfo.imageURL = NSURL(string: food.image)
        imageInfo.referenceRect = imageViewComment.frame
        imageInfo.referenceView = imageViewComment.superview
        let imageViewController = JTSImageViewController(imageInfo: imageInfo, mode: .image, backgroundStyle: .scaled)
        
        // present the view controller.
        imageViewController?.show(from: self, transition: .fromOriginalPosition)
        
    }
    
    func swipeableTableViewCell(_ cell: SWTableViewCell!, didTriggerRightUtilityButtonWith index: Int) {
        // called when the right utility buttons are clicked
        
        let cellIndexPath = tableView.indexPath(for: cell)
        let commentId = newsFeedComments[cellIndexPath!.row].id
        let feedId = newsFeed.id
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        // delete the newsfeed comment
        UIAlertView.show(withTitle: &&"delete_confirmation_title", message: &&"comment_delete_confirmation_message", cancelButtonTitle: &&"ok_button_title", otherButtonTitles: [&&"cancel_button_title"], tap: { (alertview : UIAlertView, buttonIndex : Int) in
            
            
            if buttonIndex == alertview.cancelButtonIndex{
                
                NewsFeedCommentsDeleteResponse.deleteNewsFeedComment(feedId, newsFeedCommentId: commentId) { (responseStatus) -> () in
                    if responseStatus == "OK" {
                        
                        
                        if self.newsFeedComments.count-1 >= cellIndexPath!.row{
                            self.newsFeedComments.remove(at: cellIndexPath!.row)
                            
                            self.tableView.deleteRows(at: [cellIndexPath!], with: .none)
                        }
                    }
                }
                
            }
        })
        
        
        
    }
    
    func swipeableTableViewCellShouldHideUtilityButtons(onSwipe cell: SWTableViewCell!) -> Bool {
        // prevent multiple cells from showing utilty buttons simultaneously
        
        return true
    }
    
}

