//
//  AccessTokenRefreshResponse.swift
//  FlexYourMacros
//
//  Created by mini on 05/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//
import Foundation

private let _AccessTokenRefreshResponse = AccessTokenRefreshResponse()

class AccessTokenRefreshResponse: NSObject {
    
    var accessTokenModel: AccessTokenModel?
    var metaModel: MetaModel?
    
    class var sharedAccessTokenRefreshResponse: AccessTokenRefreshResponse {
        return _AccessTokenRefreshResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        // give reference to accesstoken mapping
        responseMapping?.addPropertyMapping(AccessTokenRefreshResponse.metaModelKeyMapping)

        responseMapping?.addPropertyMapping(AccessTokenRefreshResponse.accessTokenModelKeyMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.refreshTokenUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var accessTokenModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathAccessToken, toKeyPath: "accessTokenModel", with: AccessTokenModel.objectMapping)
    }
    
    class func refreshToken(_ refreshToken: String, completionHandler: @escaping (_ accessCredential: AccessTokenModel?) -> ()) {
        
        RestKitManager.setupBasicAuth()

        var parameterDictionary: [String:String] {
            
            // create the parameter dictionary
            return ["refresh_token":refreshToken]
        }
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path: Constants.ServiceConstants.refreshTokenUrl, parameters: parameterDictionary, constructingBodyWith: { (formData) in
            
        })
//        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path: Constants.ServiceConstants.refreshTokenUrl, parameters: parameterDictionary, constructingBodyWith: { (formData) in
//            
//        })
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            let response = mappingResult?.firstObject as! AccessTokenRefreshResponse
            
            if response.metaModel?.responseCode != 200 {
                completionHandler(nil)
                return;
            }
            
            completionHandler(response.accessTokenModel!)
            
        }) {(operation, error) in
            //print("failed to load contact us with error \(error)")
            completionHandler(nil)
        }
        
//        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) -> Void in
//            
//            let response = mappingResult.firstObject as! AccessTokenRefreshResponse
//            
//            if response.metaModel?.responseCode != 200 {
//                
//                completionHandler(accessCredential: nil)
//
//                return;
//            }
//
//            completionHandler(accessCredential: response.accessTokenModel!)
//
//            
//            }) { (operation, error) in
//                
//                //print("failed to load contact us with error \(error)")
//
//                completionHandler(accessCredential: nil)
//        })
        
        RestKitManager.shared().enqueue(operation)
        
    }
    
    
}
