//
//  Utilities.swift
//  FlexYourMacros
//
//  Created by Chandrachudh on 17/01/17.
//  Copyright © 2017 Digital Brand Group. All rights reserved.
//

import UIKit

class Utilities: NSObject {
    
    class func removeOptionalString(text:String) -> String {
        return ((text).replacingOccurrences(of: "Optional(", with: "")).replacingOccurrences(of: ")", with: "")
    }

}
