//
//  AdsModel.swift
//  FlexYourMacros
//
//  Created by DBG on 24/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class Advertisement: NSObject {

    var id = ""
    var content: String?
    var imageUrlString: String?
    var type: String?
    var name: String?
    
    var imageURL: URL? {
        return URL(string: imageUrlString ?? "")
    }
    
    var shouldShowAdvertisement: Bool {
        return imageURL != nil
    }
    
    var shouldDisplayAdvertisement: Bool {
        
        if let adsUrlString = imageUrlString {
            if adsUrlString.isEmpty {
                return false
            }else {
                return true
            }
        }
        return false
    }
    
    
    class var objectMapping: RKObjectMapping {
        let adsMapping = RKObjectMapping(for: self)
        adsMapping?.addAttributeMappings(from: mappingDictionary)
        return adsMapping!
    }
    
    class var mappingDictionary: [String: String] {
        return ["id": "id","content":"content","image_url":"imageUrlString","type":"type","name":"name"]
    }

    class func latestAdvertisement(_ location: String, completionHandler: @escaping (Advertisement) -> ()) {
        let params: Dictionary<String, Any>  = ["location":location as Any, "type": "App" as Any]
        AdsResponse.getAvailableAds(params) { (getAds) -> () in
            let getAdsResponse = getAds
            
            if getAdsResponse.metaModel?.responseCode == 200 {
                if let arrayAds: [Advertisement] = getAdsResponse.adsModel as [Advertisement]? {
                    // chk the count
                    
                    if arrayAds.count > 0 {
                        
                        let ad = arrayAds[0] as Advertisement
                        completionHandler(ad)
                       /* if let adsUrlString = ad.imageUrlString {
                            
                            // image url is empty
                            if adsUrlString.isEmpty {
                                //println("empty")
                            }else{
                                completionHandler(ad)
                                
                            }
                            
                        }
                        */
                    }
                }
            }
        }
    }
    
}
