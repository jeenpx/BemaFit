//
//  UserPersonelDetailsViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 05/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UserPersonelDetailsViewController: UITableViewController, UITextFieldDelegate, UIGestureRecognizerDelegate, UIAlertViewDelegate {
    
    @IBOutlet weak var barButtonNextIcon: UIBarButtonItem!
    @IBOutlet weak var barButtonPreviousIcon: UIBarButtonItem!
    @IBOutlet weak var textFieldFirstName: UITextField!
    @IBOutlet weak var textFieldLastName: UITextField!
    @IBOutlet weak var textFieldUserName: UITextField!
    @IBOutlet weak var textFieldEmail: UITextField!
    @IBOutlet weak var textFieldWebsite: UITextField!
    @IBOutlet weak var buttonImage: UIButton!
    @IBOutlet weak var textFieldPassword: UITextField!
    @IBOutlet weak var textFieldConfirmPassword: UITextField!
    var currentTextField = UITextField()
    internal var canDismissView = true
    var alert = UIAlertView()
    
    @IBOutlet weak var labelTermandConditions: UILabel!
    let FymUserModel = FymUser.sharedFymUser
    
    struct StoryBoard {
        
        struct SegueIdentifiers {
            static let PersonnelShow = "kShowPersonnel"
        }
    }
    
    func capitalizeTextFields() -> ()
    {
        self.textFieldFirstName.autocapitalizationType = UITextAutocapitalizationType.words;
        self.textFieldLastName.autocapitalizationType = UITextAutocapitalizationType.words;
//        self.textFieldUserName.autocapitalizationType = UITextAutocapitalizationType.Words;
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = false
        self.capitalizeTextFields()
        let titleDictionary: NSDictionary = [NSForegroundColorAttributeName: UIColor.white]
        self.navigationController?.navigationBar.titleTextAttributes = titleDictionary as? [String : Any]
        
        // set border of button Image
        buttonImage.layer.borderWidth = 1.0
        buttonImage.layer.borderColor = UIColor.darkGray.cgColor
        
        if (AppConfiguration.sharedAppConfiguration.isFacebookUser) {
            
            loadWithFacebookCredentials()
            
        } else {
            
            // load with already entered credentials
            loadWithExistingCredentials()
        }
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(UserPersonelDetailsViewController.didTaplabelTermandConditionsWithGesture(_:)))
        tapGesture.delegate = self
        labelTermandConditions.addGestureRecognizer(tapGesture)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(true)
        canDismissView = true
        barButtonPreviousIcon.isEnabled = true
        barButtonNextIcon.isEnabled = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        alert.dismiss(withClickedButtonIndex: 0, animated: false)
        // view is inactive, abort all checks
    }
    
   override func viewDidDisappear(_ animated: Bool) {
    
        alert.dismiss(withClickedButtonIndex: 0, animated: false)

    }
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        cell.setSeparatorInsetZero()
    }
    
    fileprivate func loadWithFacebookCredentials() {
        
        textFieldFirstName.text = UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserFirstName
        textFieldLastName.text = UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserLastName
        textFieldUserName.text = UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserName
        textFieldEmail.text = UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserEmail
        
        let profilePicURL = "http://graph.facebook.com/" + UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserId! + "/picture?type=large"
        
        buttonImage.setImage(UIImage(data: try! Data(contentsOf: URL(string: profilePicURL)!)), for: UIControlState())
        
        self.FymUserModel.userImage = buttonImage.image(for: UIControlState())!
    }
    
    fileprivate func loadWithExistingCredentials() {
        
        textFieldFirstName.text = FymUserModel.userFirstName
        textFieldLastName.text = FymUserModel.userLastName
        textFieldUserName.text = FymUserModel.userUserName
        textFieldEmail.text = FymUserModel.userEmail
        textFieldWebsite.text = FymUserModel.userWebsite
        textFieldPassword.text = FymUserModel.userPassword
        textFieldConfirmPassword.text = FymUserModel.userPassword
        
        // check for the existing image
        if FymUserModel.userImage != nil {
            self.buttonImage .setImage(FymUserModel.userImage, for: UIControlState()) }
    }
    
    fileprivate func storeDataLocally() {
        
       
        // store data locally
        FymUserModel.userFirstName = textFieldFirstName.text!
        FymUserModel.userLastName  = textFieldLastName.text!
        FymUserModel.userUserName  = textFieldUserName.text!
        FymUserModel.userEmail     = textFieldEmail.text!
        FymUserModel.userWebsite   = textFieldWebsite.text != "" ? textFieldWebsite.text! : ""
        FymUserModel.userPassword  = textFieldPassword.text!
    }
    
    func didTaplabelTermandConditionsWithGesture(_ tapGesture: UITapGestureRecognizer) {
        
        self.performSegue(withIdentifier: "kTermsPage", sender: nil)
    }
    
    @IBAction func buttonActionSetImage(_ sender: UIButton) {
        
        currentTextField.resignFirstResponder()
        
        storeDataLocally()
        // bring image picker view
        
        ImagePickerManager.sharedManager.presentImagePicker(self, completionHandler: { (image, source) -> () in
            sender.setImage(image,for: UIControlState())
            self.FymUserModel.userImage = image
            
        })
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        currentTextField = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // resign keyboard
        textField.resignFirstResponder()
        return false
    }
    
    func didPresent(_ alertView: UIAlertView) {
        canDismissView = false
    }
    
    func alertViewCancel(_ alertView: UIAlertView) {
        canDismissView = true
    }
    
    func alertView(_ alertView: UIAlertView, didDismissWithButtonIndex buttonIndex: Int) {
        canDismissView = true
        barButtonPreviousIcon.isEnabled = true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        // managing the textfield input: limit the characters to only of numeric type
        var result = true
        if textField == textFieldPassword || textField == textFieldConfirmPassword {
            let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
            if string.characters.count > 0 {
                let resultingStringLengthIsLegal = prospectiveText.characters.count <= 10
                result =  resultingStringLengthIsLegal
            }
        } else if textField == textFieldUserName {
            
           if string == " "{
                result = false
            }
        }
        return result
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        storeDataLocally()
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if (identifier == StoryBoard.SegueIdentifiers.PersonnelShow) {
            
            barButtonPreviousIcon.isEnabled = false
        }
        barButtonNextIcon.isEnabled = false
        return true
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    @IBAction func buttonActionNext(_ sender: UIBarButtonItem) {
        
        currentTextField.resignFirstResponder()
        
        // check all fields are entered
        var validityCheck = checkAllFields()
        
        if !validityCheck {
            
           
            return
        }
        
        if validityCheck {
            // check the email entered is valid in style
            validityCheck = textFieldEmail.text!.isValidEmail()
            
            if !validityCheck {
                
                self.showAlert(&&"notice", message: &&"enter_valid_email_alert_message")
                return
            }

        }
        
        if textFieldWebsite.text != "" {
        
            //check for validity of website
            let checkWebSiteValidity = textFieldWebsite.text!.websiteString()
        
            validityCheck = checkWebSiteValidity.valid
            
            self.textFieldWebsite.text = checkWebSiteValidity.urlString
            if !validityCheck {
            
               self.showAlert(&&"notice", message: &&"enter_valid_website_alert_message")
                
                return
            } else {
                
                textFieldWebsite.text = checkWebSiteValidity.urlString
            }
        }
        
        if validityCheck {
            
            // check password is of 6 characters
            validityCheck = checkPasswordValidity()
            
            if !validityCheck {
                
                self.showAlert(&&"notice", message: &&"password_minimum_character_count_alert_message")
                return
            }
            
            if validityCheck {
                // check both password and confirm password fields are same
                validityCheck = confirmPassword()
            }
            
            if !validityCheck {
                
                self.showAlert(&&"notice", message: &&"password_mismatch_alert_message")
                return
            }
        }
        
        if validityCheck {

            checkForUserExisting()
        }
    }
    
    func checkForUserExisting() {
        
        
        UserVerificationResponse.verifyUser(textFieldEmail.text!, userFacebookId: "", userName: textFieldUserName.text!, completionHandler: { (userVerificationModel) -> () in
            
            AppConfiguration.sharedAppConfiguration.userVerification = userVerificationModel
            
            //print("user validity---\((AppConfiguration.sharedAppConfiguration.userVerification?.userExists as! Bool))")
            
            // check for the user is avlid for sign up
            if (AppConfiguration.sharedAppConfiguration.userVerification?.emailExists  as! Bool) == false && (AppConfiguration.sharedAppConfiguration.userVerification?.userNameExists  as! Bool) == false {
                
                // navigate to personal details view
                self.performSegue(withIdentifier: StoryBoard.SegueIdentifiers.PersonnelShow, sender: nil)
                
            } else {
                
                if (AppConfiguration.sharedAppConfiguration.userVerification?.emailExists  as! Bool) == true {
                    
                    self.showAlert(&&"notice", message: &&"user_already_exist_alert_message")

                } else if (AppConfiguration.sharedAppConfiguration.userVerification?.userNameExists  as! Bool) == true {
                    
                    self.showAlert(&&"notice", message: &&"user_name_already_exist_alert_message")

                }
            }
            
            }, failure: { (failedWithError) -> () in
                
                self.showAlert(&&"notice", message: failedWithError)
                
        })
    }
    
    func showAlert(_ title: String, message: String) {
        
        // show alert controller if possible else show alert view
//        if NSClassFromString(Class.UIAlertController) != nil {
//            
//            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//            
//            alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
//            
//            self.presentViewController(alert, animated: true, completion: nil)
//            return
//        }
//        else {
        
            alert = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"ok")
            alert.show()
            return
//        }
    }
    
    func confirmPassword() -> Bool {
        // return true if password and confirmpassword are same
        return textFieldPassword.text == textFieldConfirmPassword.text ? true : false
    }
    
    func checkPasswordValidity() -> Bool {
        // return password contains 6 characters

        return  textFieldPassword.text!.utf16.count  >= 6 ? true : false
    }
    
    @IBAction func buttonActionBack(_ sender: UIBarButtonItem) {
       
        barButtonNextIcon.isEnabled = false
//        sleep(1)
        alert.dismiss(withClickedButtonIndex: 0, animated: false)
        self.navigationController?.popViewController(animated: false)
    }
    
    func checkAllFields() -> Bool {
        // check all fields are non empty
       
        barButtonPreviousIcon.isEnabled = false

       if self.textFieldFirstName.isEmpty {
            
            showAlert(&&"first_name")
            return false;
        }
        if self.textFieldLastName.isEmpty {
            showAlert(&&"last_name")
            return false;
        }
        if self.textFieldUserName.isEmpty {
            showAlert(&&"username")
            return false;
        }
        if self.textFieldEmail.isEmpty {
            showAlert(&&"email")
            return false;
        }
//        if self.textFieldWebsite.isEmpty {
//            showAlert(&&"website")
//            return false;
//        }
        if self.textFieldPassword.isEmpty {
            showAlert(&&"password")
            return false;
        }
        if self.textFieldConfirmPassword.isEmpty {
            showAlert(&&"cpassword")
            return false;
        }
        
        
        /*
        
        "first_name"
        "last_name"
        "username"
        "email"
        "website"
        "password"
        "cpassword"
        "please_enter"*/
        barButtonPreviousIcon.isEnabled = true

        return true;
        
    }
    
   
    
    @IBAction func unwindToUserPersonelDetailsViewController(_ segue: UIStoryboardSegue) {
        
        self.navigationController?.isNavigationBarHidden = false

    }
    
    func showAlert(_ fieldName:String){
    
        alert = UIAlertView(title: &&"notice", message: &&"please_enter"+" "+fieldName, delegate: self, cancelButtonTitle: &&"Ok")
        alert.show()
    }
    
}
