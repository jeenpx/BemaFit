//
//  DirectoryDetailViewController.swift
//  FlexYourMacros
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


public enum DirectoryCellMode: String {
    case Monday = "Mon"
    case Tuesday = "Tue"
    case Wednesday = "Wed"
    case Thursday = "Thu"
    case Friday = "Fri"
    case Saturday = "Sat"
    case Sunday = "Sun"
    static var modes = [Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday]
}

class DescriptionCell: UITableViewCell {
    
    @IBOutlet weak var labelDescription: UILabel!
    @IBOutlet weak var viewVerified: UIView!
    
    @IBOutlet weak var viewVerifiedHeight: NSLayoutConstraint!
    var  directory = DirectoryModel() {
        didSet {
            
            if directory.directoryDescription == "" {
                labelDescription.isHidden = true
                showEmptyTableViewCellMessage(&&"no_description")
            }
            else {
                // set value for company's description
                labelDescription.text = directory.directoryDescription
            }
            
            if directory.premiumListing == "0" {
                viewVerifiedHeight.constant = 0
                
                // hide verified view if premium listing is 0
                viewVerified.isHidden = true
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}


class DirectoryDetailViewController: UIViewController, UIAlertViewDelegate, ShareSocialMediaDelegate, UITableViewDataSource, UITableViewDelegate {
    
    var businessDirectory = DirectoryModel()
    
    var businessDirectoryId = ""
    
    // tells whether to load the model from businessDirectoryId
    var shouldLoadFromId: Bool = false
    
    @IBOutlet weak var imageViewCompany: UIImageView!
    @IBOutlet weak var tableViewDirectoryDetails: UITableView!
    
    @IBOutlet weak var constraintViewNoRecordsHeight: NSLayoutConstraint!
    
    @IBOutlet weak var viewHeader: UIView!
    @IBOutlet weak var viewNoRecords: UIView!
    @IBOutlet weak var buttonItemShare: UIBarButtonItem!
    
    var offscreenCells = [String: DescriptionCell]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // load placeholder model
        configureView()
        
        if shouldLoadFromId {
            DirectoryModel.getBusinessDirectory(businessDirectoryId) { (businessDirectory) in
                
                self.businessDirectory = businessDirectory
                
                DispatchQueue.main.async {
                    self.configureView()
                }
            }
        }
        else {
            configureView()
        }
    }
    
    func configureView() {
        
        //print("kMainScreenWidth:\(kMainScreenWidth)")
        
        // set navigation bar title
        navigationItem.title = businessDirectory.name
        
        buttonItemShare.image = UIImage(named: &&"directory_button_share")
        
        // set value for company's image
        if let imagePath = businessDirectory.images?[0].file {
            imageViewCompany.setImageWith(URL(string: imagePath), placeholderImage: UIImage(named: "PlaceHolderDirectory"))
            
        }
        
        tableViewDirectoryDetails.rowHeight = UITableViewAutomaticDimension
        tableViewDirectoryDetails.estimatedRowHeight = 32.0
        tableViewDirectoryDetails.tableFooterView = UIView(frame: CGRect.zero)
        
        tableViewDirectoryDetails.reloadData()
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.row {
            
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "kDescriptionCell") as! DescriptionCell
            cell.directory = businessDirectory
            cell.setNeedsUpdateConstraints()
            cell.updateConstraintsIfNeeded()
            return cell
            
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "kCompanyDetailsCell") as! CompanyDetailsTableCell
            cell.directory = businessDirectory
            return cell
            
        case 2, 3, 4, 5, 6, 7, 8:
            let cell = tableView.dequeueReusableCell(withIdentifier: "kCompanyTimingsCell") as! CompanyTimingsCell
            cell.directoryCellMode = DirectoryCellMode.modes[indexPath.row - 2]
            cell.directory = businessDirectory
            return cell
        default:
            break
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return businessDirectory.workingHours?.count > 0 ? 9 : 3
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.row == 0 {
            
            var cell = offscreenCells["kDescriptionCell"]
            if cell == nil {
                cell = tableView.dequeueReusableCell(withIdentifier: "kDescriptionCell") as? DescriptionCell
                offscreenCells["kDescriptionCell"] = cell
            }
            
            cell?.directory = businessDirectory
            
            cell?.setNeedsUpdateConstraints()
            cell?.updateConstraintsIfNeeded()
            cell?.bounds = CGRect(x: 0.0, y: 0.0, width: tableViewDirectoryDetails.bounds.width, height: cell!.bounds.height)
            
            cell?.setNeedsLayout()
            cell?.layoutIfNeeded()
            
            cell?.labelDescription.preferredMaxLayoutWidth = cell!.labelDescription.bounds.width
            cell?.labelDescription.setNeedsUpdateConstraints()
            
            // Get the actual height required for the cell's contentView
            var height = cell?.contentView.systemLayoutSizeFitting(UILayoutFittingCompressedSize).height
            
            // Add an extra point to the height to account for the cell separator, which is added between the bottom
            // of the cell's contentView and the bottom of the table view cell.
            height = height! + 1
            
            return height!
            
        }
        else if indexPath.row == 1 {
            return 62
        }
        else {
            
            if businessDirectory.workingHours?.count == 0 {
                // no working hours
                
                let height = tableViewDirectoryDetails.frame.height - tableViewDirectoryDetails.contentSize.height
                
                if height <= 0 {
                    return 32
                }
                else {
                    return height
                }
            }
            else {
                // working hours available
                
                return 32
            }
        }
    }
    
    @IBAction func buttonActionCheckIn(_ sender: Any) {
        //check in button is pressed
        
        var checkInName = " "
        if let name = businessDirectory.name {
            checkInName = " " + name
        }
        if #available(iOS 8.0, *) {
            
            let alertView = UIAlertController(title: NSLocalizedString("directory_detail_alert_title", comment: ""),
                
                message: NSLocalizedString("directory_detail_alert_message", comment: "") + checkInName + "?", preferredStyle: .alert)
            alertView.addAction(UIAlertAction(title: NSLocalizedString("directory_detail__cancel", comment: ""), style: .cancel, handler: nil))
            alertView.addAction(UIAlertAction(title: NSLocalizedString("directory_detail_check_in", comment: ""), style: .default){ action -> Void in
                self.checkIn()
                })
            present(alertView, animated: true, completion: nil)
            
        } else {
            // Fallback on earlier versions
            
            UIAlertView(title: NSLocalizedString("directory_detail_alert_title", comment: ""), message: NSLocalizedString("directory_detail_alert_message", comment: "") + checkInName, delegate: self, cancelButtonTitle: NSLocalizedString("directory_detail__cancel", comment: ""), otherButtonTitles: NSLocalizedString("directory_detail_check_in", comment: "")).show()
        }
    }
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        if buttonIndex == 1 {
            checkIn()
        }
    }
    
    func checkIn() {
        // check in api call
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        if let id = businessDirectory.id {
            DirectoryCheckInResponse.directoryCheckIn(id) { (status) -> () in
                //print(status)
                self.showAlert(&&"notice", message: status)
            }
        }
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    func showAlert(_ title: String, message: String) {
        
        if #available(iOS 8.0, *) {
            
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
            return
        } else {
            // Fallback on earlier versions
            
            
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"ok").show()
            return
        }
    }
    
    @IBAction func shareButtonClicked(_ sender: Any) {
        // share button clicked
        
        //print("shareButtonClicked:")
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        let businessName = businessDirectory.name ?? ""
        let businessDescription = businessDirectory.directoryDescription ?? ""
        let businessImageUrl = businessDirectory.images?[0].file
        let businessWebsiteUrl = businessDirectory.website
        
        ShareSocialMedia.sharedManager.shareSocialMediaDelegate = self
        ShareSocialMedia.sharedManager.shareOnSocialMedia(self, image: imageViewCompany.image, name: businessName, message: businessDescription, view: self.view, imageUrl: businessImageUrl!, websiteUrl: businessWebsiteUrl!)
    }
    
    func shareSocialMedia(_ sharedStatus: String) {
        
        showAlert(&&"notice", message: sharedStatus)
    }
    
    class func loadDirectoryDetail(_ id: String, fromViewcontroller: UIViewController) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let directoryDetailViewController = storyBoard.instantiateViewController(withIdentifier: "kDirectoryDetailView") as! DirectoryDetailViewController
        directoryDetailViewController.businessDirectoryId = id
        directoryDetailViewController.shouldLoadFromId = true
        fromViewcontroller.navigationController?.pushViewController(directoryDetailViewController, animated: true)
    }
}



