//
//  LogProgressViewController.swift
//  FlexYourMacros
//
//  Created by mini on 18/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//
import UIKit
import Foundation
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l <= r
  default:
    return !(rhs < lhs)
  }
}


class LogProgressViewController: UITableViewController, UITextFieldDelegate{

    @IBOutlet weak var btnCalender: UIButton!
    
    @IBOutlet weak var textFieldWeight: UITextField!
    @IBOutlet weak var textFieldBodyFat: UITextField!
    var currentTextfield: UITextField!
    var logDate = Date()
    
    @IBOutlet weak var labelLastLoggedDate: UILabel!
    
    var blurView: UIControl!
    var calenderBGView: UIView!
    let datePickerHeight: CGFloat = 250.0
    var datePicker: UIDatePicker!
    var headerView: UIView!
    var arrayData = [[ProgressReport]]()
    var selectedReport: ProgressReport!
    
    
    struct Storyboard {
        
        struct Segues {
            static let Progress  = "kUnwindProgress"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textFieldWeight.becomeFirstResponder()
        //load the last log date
        loadProgressLastLogDetails()
        
        let titleDictionary: NSDictionary = [NSForegroundColorAttributeName: UIColor.white]
        self.navigationController?.navigationBar.titleTextAttributes = titleDictionary as? [String : Any]
        
        self.btnCalender.setTitle(Utilities.removeOptionalString(text: requestDate), for: UIControlState())
    }
    
    @IBAction func showCalender(_ sender: Any) {
        
        self.textFieldWeight.resignFirstResponder()
        self.textFieldBodyFat.resignFirstResponder()
        
        if blurView == nil {
            blurView = UIControl.init(frame: UIScreen.main.bounds)
            blurView.backgroundColor = UIColor.black.withAlphaComponent(0.0)
            blurView.addTarget(self, action: #selector(LogProgressViewController.dismissCalender(_:)), for: UIControlEvents.touchUpInside)
        }
        self.view.window?.addSubview(blurView)
        
        if calenderBGView == nil {
            calenderBGView = UIView.init(frame: CGRect(x: 0, y: self.blurView.frame.height - self.datePickerHeight, width: blurView.frame.width, height: self.datePickerHeight))
            calenderBGView.backgroundColor = UIColor.white
            blurView.addSubview(calenderBGView)
        }
        
        if datePicker == nil {
            datePicker = UIDatePicker.init(frame: CGRect(x: 0, y: self.datePickerHeight/5, width: self.blurView.frame.width, height: self.datePickerHeight-(self.datePickerHeight/5)))
            
            let userDefaults = UserDefaults.standard
            
            if let dateOfJoiningEpoch:Double = userDefaults.object(forKey: "user_date_added") as! Double {
                if dateOfJoiningEpoch <= 0 {
                    let gregorian: Calendar = Calendar(identifier: Calendar.Identifier.gregorian)
                    let currentDate: Date = Date()
                    var components: DateComponents = DateComponents()
                    components.day = -7
                    let minDate: Date = (gregorian as NSCalendar).date(byAdding: components, to: currentDate, options: NSCalendar.Options(rawValue: 0))!
                    
                    datePicker.minimumDate = minDate
                }
                else {
                    let dateOfJoining = NSDate(timeIntervalSince1970: dateOfJoiningEpoch as! TimeInterval) as Date
                    datePicker.minimumDate = dateOfJoining
                }
            }
            else {
                let gregorian: Calendar = Calendar(identifier: Calendar.Identifier.gregorian)
                let currentDate: Date = Date()
                var components: DateComponents = DateComponents()
                components.day = -7
                let minDate: Date = (gregorian as NSCalendar).date(byAdding: components, to: currentDate, options: NSCalendar.Options(rawValue: 0))!
                datePicker.minimumDate = minDate
            }
            
            datePicker.maximumDate = Date()
            datePicker.datePickerMode = UIDatePickerMode.date
            calenderBGView.addSubview(datePicker)
        }
        
        if headerView == nil {
            headerView = UIView.init(frame: CGRect(x: 0, y: 0, width: self.blurView.frame.width, height: (self.datePickerHeight/5)))
            headerView.backgroundColor = UIColor.clear
            calenderBGView.addSubview(headerView)
            
            let btnCancel: UIButton = UIButton.init(frame: CGRect(x: 10, y: 0, width: (headerView.frame.width/2) - 10, height: headerView.frame.height))
            btnCancel.backgroundColor = UIColor.clear
            btnCancel.setTitle("Cancel", for: UIControlState())
            btnCancel.setTitleColor(UIColor.hx_color(withHexRGBAString: "#0076ffff"), for: UIControlState())
            btnCancel.addTarget(self, action: #selector(LogProgressViewController.cancelCalender), for: UIControlEvents.touchUpInside)
            btnCancel.contentHorizontalAlignment = UIControlContentHorizontalAlignment.left
            headerView.addSubview(btnCancel)
            
            let btnDone: UIButton = UIButton.init(frame: CGRect(x: headerView.frame.width/2, y: 0, width: (headerView.frame.width/2) - 10, height: headerView.frame.height))
            btnDone.backgroundColor = UIColor.clear
            btnDone.setTitle("Done", for: UIControlState())
            btnDone.setTitleColor(UIColor.hx_color(withHexRGBAString: "#0076ffff"), for: UIControlState())
            btnDone.addTarget(self, action: #selector(LogProgressViewController.selectDate), for: UIControlEvents.touchUpInside)
            btnDone.contentHorizontalAlignment = UIControlContentHorizontalAlignment.right
            headerView.addSubview(btnDone)
            
        }
        
        
        self.animateAndShowDatePicker()
    }
    
    func dismissCalender(_ control : UIControl) {
        self.cancelCalender()
    }
    
    func animateAndShowDatePicker() {
        calenderBGView.frame = CGRect(x: 0, y: blurView.frame.height, width: blurView.frame.width, height: self.datePickerHeight)
        self.blurView.backgroundColor = UIColor.black.withAlphaComponent(0.0)
        UIView.animate(withDuration: 0.35, animations: {
            self.calenderBGView.frame = CGRect(x: 0, y: self.blurView.frame.height-self.datePickerHeight, width: self.blurView.frame.width, height: self.datePickerHeight)
            self.blurView.backgroundColor = UIColor.black.withAlphaComponent(0.4)
            }, completion: nil)
    }
    
    func cancelCalender() {
        print("cancel button tapped")
        self.calenderBGView.frame = CGRect(x: 0, y: self.blurView.frame.height-self.datePickerHeight, width: self.blurView.frame.width, height: self.datePickerHeight)
        self.blurView.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        UIView.animate(withDuration: 0.35, animations: {
            self.calenderBGView.frame = CGRect(x: 0, y: self.blurView.frame.height, width: self.blurView.frame.width, height: self.datePickerHeight)
            self.blurView.backgroundColor = UIColor.black.withAlphaComponent(0.0)
            }, completion: { (complete: Bool) in
                self.blurView.removeFromSuperview()
        })
    }
    
    func selectDate() {
        print("select date button tapped")
        self.cancelCalender()
        
        let selectedDate : Date = self.datePicker.date
        let dateFormatter: DateFormatter = DateFormatter.init()
        dateFormatter.dateFormat = "MM/dd/yy"
        let selectedDateString = Utilities.removeOptionalString(text: dateFormatter.string(from: selectedDate))
        
        self.selectedReport = nil
        
        for reportsArray in self.arrayData {
            if reportsArray.count>0 {
                
                for report in reportsArray {
                    if report.log_date == selectedDateString {
                        self.selectedReport = report
                        self.textFieldWeight.text = report.weight
                        self.textFieldBodyFat.text = report.bodyfat
                        self.btnCalender.setTitle(Utilities.removeOptionalString(text: report.log_date), for: UIControlState())
                    }
                }
            }
        }
        
        if self.selectedReport == nil {
            self.textFieldWeight.text = ""
            self.textFieldBodyFat.text = ""
            self.btnCalender.setTitle(selectedDateString, for: UIControlState())
        }
    }
    
    
    var progressType: ProgressType = ProgressType.Weight
    
    func loadProgressLastLogDetails() {
        
        ProgressLastLog.fetchProgressLastLogDetails(progressType.description, completionHandler: { (lastLogDetails) -> () in
            
            if lastLogDetails.isEmpty {
                return
            }
            let lastLogArray: [ProgressLastLog] = lastLogDetails.map({
                return $0 as! ProgressLastLog
            })
            
            if lastLogArray.isEmpty {
                
                return
            }
            let currentLog = lastLogArray.first
            
            if currentLog?.log_date == "" {
                self.labelLastLoggedDate.text = ""
                return
            }
            
            
            
            let dateString = currentLog!.log_date.dateValue("yyyy-MM-dd", dateStyle: nil)!.stringValue("MM/dd/yy", dateStyle: nil, showToday: false)
            self.labelLastLoggedDate.text = &&"last_logged" + " " + "\(dateString)"
            self.textFieldBodyFat.text = currentLog?.body_fat
            self.textFieldWeight.text = currentLog?.weight
        })
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    //log weight and fat
    @IBAction func logAction(_ sender: UIBarButtonItem) {
       
        currentTextfield?.resignFirstResponder()
        
        if textFieldWeight.text!.isEmpty || textFieldWeight.text?.doubleValue <=  0.0{
            
            if #available(iOS 8.0, *) {
                
                let alert = UIAlertController(title: &&"notice", message: &&"enter_weight_request", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
                self.present(alert, animated: true, completion: nil)
            } else {
                // Fallback on earlier versions
                
                UIAlertView(title: &&"notice", message: &&"enter_weight_request", delegate: nil, cancelButtonTitle: "ok").show()
            }
        }else if textFieldBodyFat.text!.isEmpty || textFieldBodyFat.text?.doubleValue <=  0.0 {
            
            if #available(iOS 8.0, *) {
                
                let alert = UIAlertController(title: &&"notice", message: &&"enter_bodyfat_request", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
                
                self.present(alert, animated: true, completion: nil)
            } else {
                // Fallback on earlier versions
                
                UIAlertView(title: &&"notice", message: &&"enter_bodyfat_request", delegate: nil, cancelButtonTitle: "ok").show()
            }
            return;
        }  else {
            
            let reachability = appDelegate!.internetReachable
            
            if !reachability {
                
                UIAlertView(title: &&"alert_network_title", message: &&"alert_network_message", delegate: nil, cancelButtonTitle: "ok").show()
                return
            }
            
            
            let dateFormatter: DateFormatter = DateFormatter.init()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            var logDate = dateFormatter.string(from: Date())

            if let datePickerComponent = self.datePicker {
                let selectedDate:Date = datePickerComponent.date as Date
                logDate = dateFormatter.string(from: selectedDate as Date)
            }
            
            if self.selectedReport != nil {
                logDate = self.selectedReport.log_date
            }
            
            ProgressLogWeightAndFatResponse.postWeightandBodyFat(logDate, weight: textFieldWeight.text!, bodyFat: textFieldBodyFat.text!, completionHandler: { (successful, updatedStats) -> () in
              
                let stats = updatedStats as Stats
                
                print("protein = \(String(describing: stats.protein))")
                
                let protein = (stats.protein ?? "N/A")
                let carbs = (stats.carbs ?? "N/A")
                let fat = (stats.fat ?? "N/A")
                let fiber = (stats.fiber ?? "N/A")
                let calories = (stats.calories ?? "N/A")
                
                var message = "Would you like to update your macros?"
                message = message + "\nCalories: " + calories
                message = message + "\nProtein: " + protein
                message = message + "\nCarbs: " + carbs
                message = message + "\nFat: " + fat
                message = message + "\nFiber: " + fiber
                
                if logDate == dateFormatter.string(from: Date()) {
                    let alert = UIAlertController.init(title: "Update your Macros", message: message, preferredStyle: .alert)
                    
                    let attrStr = NSMutableAttributedString.init(string: message)
                    
                    let paragraphStyle = NSMutableParagraphStyle()
                    paragraphStyle.lineSpacing = 10.0
                    paragraphStyle.alignment = .center
                    
                    let paragraphStyle2 = NSMutableParagraphStyle()
                    paragraphStyle2.lineSpacing = 5.0
                    paragraphStyle2.alignment = .center
                    
                    let fullRange = NSRange.init(location: 0, length: (message.characters.count))
                    
                    let mainMessageRange = (message as NSString).range(of: "Would you like to update your macros?")
                    let caloriesRange = (message as NSString).range(of: "Calories")
                    let proteinsRange = (message as NSString).range(of: "Protein")
                    let carbsRange = (message as NSString).range(of: "Carbs")
                    let fatRange = (message as NSString).range(of: "Fat")
                    let fiberRange = (message as NSString).range(of: "Fiber")
                    
                    attrStr.addAttribute(NSParagraphStyleAttributeName, value: paragraphStyle2, range: fullRange)
                    attrStr.addAttribute(NSParagraphStyleAttributeName, value: paragraphStyle, range: mainMessageRange)
                    attrStr.addAttribute(NSForegroundColorAttributeName, value: UIColor.black, range: fullRange)
                    attrStr.addAttribute(NSFontAttributeName, value: UIFont.systemFont(ofSize: 12), range: fullRange)
                    attrStr.addAttribute(NSFontAttributeName, value: UIFont.boldSystemFont(ofSize: 12), range: caloriesRange)
                    attrStr.addAttribute(NSFontAttributeName, value: UIFont.boldSystemFont(ofSize: 12), range: proteinsRange)
                    attrStr.addAttribute(NSFontAttributeName, value: UIFont.boldSystemFont(ofSize: 12), range: carbsRange)
                    attrStr.addAttribute(NSFontAttributeName, value: UIFont.boldSystemFont(ofSize: 12), range: fatRange)
                    attrStr.addAttribute(NSFontAttributeName, value: UIFont.boldSystemFont(ofSize: 12), range: fiberRange)
                    
                    alert.setValue(attrStr, forKey: "attributedMessage")
                    
                    let cancelAction = UIAlertAction.init(title: "Cancel", style: .cancel, handler: { (action) in
                        self.performSegue(withIdentifier: Storyboard.Segues.Progress, sender: nil)
                    })
                    alert.addAction(cancelAction)
                    
                    let updateAction = UIAlertAction.init(title: "Update", style: .default, handler: { (action) in
                        
                        
                        let parameterDictionary: [String:String] = ["weight":self.textFieldWeight.text!]
                        
                        // update the user information
                        UpdateUserResponse.updateUserInfo(parameterDictionary, completionHandler: { (updateResponse) -> () in
                            //refresh user details
                            AppConfiguration.refreshUserDetails { (refreshedUserDetails) -> () in
                                self.performSegue(withIdentifier: Storyboard.Segues.Progress, sender: nil)
                            }
                        })
                    })
                    alert.addAction(updateAction)
                    
                    self.present(alert, animated: true, completion: nil)
                }
                else {
                    self.performSegue(withIdentifier: Storyboard.Segues.Progress, sender: nil)
                }
            })
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        
        if segue.identifier == Storyboard.Segues.Progress {
            
            let progressViewController = segue.destination as! ProgressViewController
            progressViewController.progressType = progressType
        }
    }
    
    var requestDate: String {
        
//        //webcall prepare the request date in for yyyy-mm-dd from the current date
//        let components = (Calendar.current as NSCalendar).components([.day, .month, .year], from: Date())
////        return "\(components.year)"+"-"+"\(components.month)"+"-"+"\(components.day)"
//        return "\(components.month)-\(components.day)-\(components.year)"
        
        let currentTime = NSDate()
        let dateFormatter: DateFormatter = DateFormatter.init()
        dateFormatter.dateFormat = "MM/dd/yy"
        return dateFormatter.string(from: currentTime as Date)
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        currentTextfield = textField
    }
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField .resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var result = true
        let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        if string.characters.count > 0 {
            let disallowedCharacterSet = CharacterSet(charactersIn: "0123456789.").inverted
            let replacementStringIsLegal = string.rangeOfCharacter(from: disallowedCharacterSet) == nil
            let resultingStringLengthIsLegal = prospectiveText.characters.count <= 6
            let scanner = Scanner(string: prospectiveText)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
            result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
        }
        return result
    }

    @IBAction func backAction(_ sender: UIButton) {
        //dismiss view controller
        self.navigationController?.popViewController(animated: true)    }
}
