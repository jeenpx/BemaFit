//
//  ChangeShareStatusFoodLogResponse.swift
//  FlexYourMacros
//
//  Created by mini on 10/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class ChangeShareStatusFoodLogResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var foodlog_id: String?
    
    // message delete response mapping
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(ChangeShareStatusFoodLogResponse.metaModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: responseMapping, method: .PATCH, pathPattern: Constants.ServiceConstants.kUrlFood, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func changeStatus(_ foodId: String, status: String, completionHandler: @escaping (_ changedStatus: Bool) -> ()) {
        // delete the food
        
        // set access token
        RestKitManager.setToken(true)
        
        let changeShareStatusFoodLogResponse = ChangeShareStatusFoodLogResponse()
        changeShareStatusFoodLogResponse.foodlog_id = foodId
        
        
        var err: NSError?
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: changeShareStatusFoodLogResponse, method: .PATCH, path: nil, parameters: nil, constructingBodyWith: { (formData) in
            
        })
        
        do {
            request.httpBody =  try JSONSerialization.data(withJSONObject: ["approve": status], options: [])
        } catch var error as NSError {
            err = error
            request.httpBody = nil
        }
        
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) -> Void in
            
            //print("Success")
            let responseObject = mappingResult?.firstObject as! ChangeShareStatusFoodLogResponse
            
            if let responseMeta = responseObject.meta {
                
                // completion handler
                completionHandler(true)
            }
            
            }) { (operation, error) in
                //print("error \(error)");
                
                completionHandler(false)
                
                //print("failed to update status with error \(error)")
        }
        
        RestKitManager.shared().enqueue(operation)
        
    }
}
