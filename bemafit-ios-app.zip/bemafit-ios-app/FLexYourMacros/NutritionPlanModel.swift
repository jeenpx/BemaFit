//
//  NutritionLevelModel.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 08/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class NutritionPlanModel: NSObject {
    
    var nutritionId: String?
    var nutritionName: String?
    var nutritionDescription: String?
    
    class var objectMapping: RKObjectMapping {
        
        let dietMapping = RKObjectMapping(for: self)
        dietMapping?.addAttributeMappings(from: mappingDictionary)
        return dietMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["id":"nutritionId", "name":"nutritionName", "description":"nutritionDescription"])
    }
}
