//
//  ListLogFoodResponse.swift
//  FlexYourMacros
//
//  Created by mini on 08/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _ListLogFoodResponse = ListLogFoodResponse()

//foodlog model
class FoodLogModel: NSObject {
    
    var foodLogId: String = ""
    var foodId: String = ""
    var foodDate: String = ""
    var foodName: String = ""
    var foodUnit = ""
    var noOfServing: String = ""
    var mealType: String = ""
    var servingSize: String = ""
    var brandName: String = ""
    var approve: String = ""
    var method: String = ""
    var source_id = -1
    
    
    var nutritionalFacts = NutritionalFactsModel()
    
    class var objectMapping: RKObjectMapping {
        let foodLogMapping = RKObjectMapping(for: self)
        foodLogMapping?.addAttributeMappings(from: mappingDictionary)
        foodLogMapping?.addPropertyMapping(FoodLogModel.nutritionalFactKeyMapping)
        
        return foodLogMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["id":"foodLogId", "food_id":"foodId", "log_date":"foodDate", "food_name":"foodName", "food_unit": "foodUnit", "number_of_serving":"noOfServing", "approve": "approve", "type":"mealType", "serving_size": "servingSize", "brand_name" : "brandName", "method": "method","source_id":"source_id"])
    }
    
    fileprivate class var nutritionalFactKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathNutrition, toKeyPath: "nutritionalFacts", with: NutritionalFactsModel.objectMapping)
    }
}

class ListLogFoodResponse: NSObject {
    
    var metaModel = MetaModel()
    var foodLogResults = [FoodLogModel]()
    
    class var sharedListLogFoodResponse: ListLogFoodResponse {
        return _ListLogFoodResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(ListLogFoodResponse.metaModelKeyMapping)
        
        // give reference to FoodListMapping
        responseMapping?.addPropertyMapping(ListLogFoodResponse.foodLogListModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var foodLogListModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathFoodLogResult, toKeyPath: "foodLogResults", with: FoodLogModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kFoodLogUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func fetchFoodLogList(_ offset: String, date: Date, completionHandler:@escaping (_ foodLogList: [Food], _ error: NSError?)->()) {
        
        RestKitManager.setToken(true)
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["date": date.stringValue("yyyy-MM-dd"), "offset": offset, "limit": "50","locale" : "\((Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)!)"]
        }
        
        // get the objects from the path login
        
        RestKitManager.shared().getObjectsAtPath(Constants.ServiceConstants.kFoodLogUrl, parameters: parameterDictionary, success: { (operation, mappingResult) in
            // map to correct datamodel
            let response = mappingResult?.firstObject as! ListLogFoodResponse
            
            let foodLogs = (response.foodLogResults as [FoodLogModel]).map { Food(foodLogModel: $0) }
            
            if response.metaModel.responseCode != 200 {
                let error = NSError(domain: "FYM.FoodLog", code: 1001, userInfo: ["title": "error", "message": "alert_log_list_message"])
                // fire completion handler
                completionHandler([], error)
            }
            else {
                // fire completion handler
                completionHandler(foodLogs, nil)
            }
        }) { (operation, error) in
            // error
            let networkError = NSError(domain: "FYM.FoodList", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
            
            // fire completion handler
            completionHandler([], networkError)
        }
        
//        RestKitManager.shared().getObjectsAtPath(Constants.ServiceConstants.kFoodLogUrl, parameters: parameterDictionary, success: { (operation, mappingResult) in
//            
//            // map to correct datamodel
//            let response = mappingResult.firstObject as! ListLogFoodResponse
//            
//            let foodLogs = (response.foodLogResults as [FoodLogModel]).map { Food(foodLogModel: $0) }
//            
//            if response.metaModel.responseCode != 200 {
//                let error = NSError(domain: "FYM.FoodLog", code: 1001, userInfo: ["title": "error", "message": "alert_log_list_message"])
//                
//                // fire completion handler
//                completionHandler(foodLogList: [], error: error)
//                
//            }
//            else {
//                // fire completion handler
//                completionHandler(foodLogList: foodLogs, error: nil)
//            }
//
//            }) { (operation, error) -> Void in
//                // error
//                let networkError = NSError(domain: "FYM.FoodList", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
//                
//                // fire completion handler
//                completionHandler(foodLogList: [], error: networkError)
//        }
    }
}
