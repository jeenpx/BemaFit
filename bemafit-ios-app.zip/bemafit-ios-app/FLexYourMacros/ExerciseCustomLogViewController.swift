//
//  ExerciseCustomLogViewController.swift
//  FlexYourMacros
//
//  Created by mini on 26/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ExerciseCustomLogViewController: UITableViewController, UITextFieldDelegate {

    @IBOutlet weak var textFieldExerciseName: UITextField!
    
    @IBOutlet weak var textFieldHours: UITextField!
    
    @IBOutlet weak var textFieldMinutes: UITextField!
    
    @IBOutlet weak var textFieldSeconds: UITextField!
    
    @IBOutlet weak var textFieldCaloriesBurned: UITextField!
    
    @IBOutlet weak var textFieldDistance: UITextField!
    
    @IBOutlet weak var textFieldSets: UITextField!
    
    @IBOutlet weak var textFieldWeight: UITextField!
    
    var selectedExerciseType: String = ""
    
    var exercise = Exercise(name: "")
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if selectedExerciseType == ExerciseCategory.CardioVascular.rawValue {
            exercise = CardioVascularExercise(name: "")
        } else if selectedExerciseType == ExerciseCategory.CardioVascular.rawValue {
            exercise = StrengthExercise(name: "")
        }
         
    }
    @IBAction func backButtonAction(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    @IBAction func buttonActionLog(_ sender: UIBarButtonItem) {
        
        // check exercise name or calories burned is empty
        if textFieldExerciseName.isEmpty || textFieldCaloriesBurned.isEmpty {
            
                if #available(iOS 8.0, *) {
                    let alert = UIAlertController(title: &&"notice", message: &&"enter_the_details_alert_message", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
                    
                    self.present(alert, animated: true, completion: nil)
                    return

                } else {
                    // Fallback on earlier versions
                    
                    UIAlertView(title: &&"notice", message: &&"enter_the_details_alert_message", delegate: nil, cancelButtonTitle: &&"ok").show()
                    return
                }
                
                           
        }
        
    }
//    
//    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
//        
//        switch textField {
//        case textFieldExerciseName: exercise.name = textField.text
//        case textFieldHours, textFieldMinutes, textFieldSeconds: exercise.exerciseAmount = totalSeconds.doubleValue
//        case textFieldCaloriesBurned: exercise.caloriesBurned = textFieldCaloriesBurned.text.doubleValue
////        case textFieldDistance: exercise.
//        }
    
//        return true
//    }
//    var parameterDictionary: Dictionary<String, Any> {
//       
//        var _parameterDictionary: Dictionary<String, Any> = [
//            "log_type" : "Log",
//            "exercise_type" : selectedExerciseType,
//            "exercise_date" : "",
//            "users" : [userExerciseDictionary]
//        ]
//        
//       return _parameterDictionary
//    }
//    
//    var userExerciseDictionary: Dictionary<String, Any> {
//        
//        var _userExerciseDictionary: Dictionary<String, Any> = [
//        "user_id": AppConfiguration.sharedAppConfiguration.userDetails?.userId!,
//        "exercise_details": [exerciseDetail]
//        ]
//        return _userExerciseDictionary
//    }
//    
//    var exerciseDetail: Dictionary<String, String> {
//        var _exerciseDetail: Dictionary<String, String> = [
//            "exercise_id" : "",
//            "exercise_name" : textFieldExerciseName.text,
//            "exercise_time" : totalSeconds,
//            "exercise_calorie_burned" : textFieldCaloriesBurned.text,
//            "exercise_unit": "g",
//            "exercise_distance" : textFieldDistance.text,
//            "exercise_sets" : textFieldSets.text,
//            "exercise_sets_reps" : "",
//            "exercise_weight_per_set" : textFieldWeight.text
//        ]
//        return _exerciseDetail
//    }
//    
    var totalSeconds: String {
        let _totalSeconds = textFieldHours.text!.intValue*60*60 + textFieldMinutes.text!.intValue*60 + textFieldSeconds.text!.intValue
        return String(_totalSeconds)
    }
    
//    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
//        
//        if textField != textFieldCaloriesBurned || textField != textFieldDistance || textField != textFieldHours || textField != textFieldMinutes || textField != textFieldSeconds || textField != textFieldSets || textField != textFieldWeight {
//            
//            return true
//        }
//        
//        var result = true
//        let prospectiveText = (textField.text as NSString).stringByReplacingCharactersInRange(range, withString: string)
//        if count(string) > 0 {
//            let disallowedCharacterSet = NSCharacterSet(charactersInString: "0123456789.-").invertedSet
//            let replacementStringIsLegal = string.rangeOfCharacterFromSet(disallowedCharacterSet) == nil
//            let resultingStringLengthIsLegal = count(prospectiveText) <= 6
//            let scanner = NSScanner(string: prospectiveText)
//            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
//            result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
//        }
//        return result
//    }
    
   
}
