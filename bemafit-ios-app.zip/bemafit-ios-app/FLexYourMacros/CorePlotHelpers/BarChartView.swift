//
//  BarChartView.swift
//  ChartViews
//
//  Created by DBG-39 on 23/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

import UIKit
import CoreGraphics


class BarChartView: CPTGraphHostingView, CPTBarPlotDelegate, CPTPlotSpaceDelegate, CPTPlotDataSource, CPTBarPlotDataSource {

    var chartViewData: [Double]? {
        didSet {
            
            // create graph hosting view if not exists
            if hostedGraph == nil {
                configureGraph()
            }
            
//            configureGraph()

            // reload graph
            reloadGraph()
        }
    }
    
    fileprivate let chartViewXIndex: [Double] = [-5, 0, +5]
    
    fileprivate var minimumYRangeNumber: NSNumber? {
        return NSNumber.init(value: chartViewData!.reduce(chartViewData![0]) { min($0, $1) } + 15)
    }
    
    fileprivate var maximumYRangeNumber: NSNumber {
        return 115.0//chartViewData!.reduce(chartViewData![0]) { max($0, $1) } + 15
    }

    fileprivate func configureGraph() {
        
        // initialise hosted graph
        hostedGraph = CPTXYGraph(frame: bounds)
        
        allowPinchScaling = false
        
        // create grid line style
        let majorGridLineStyle: CPTMutableLineStyle = CPTMutableLineStyle()

        majorGridLineStyle.lineWidth = 1.0
        majorGridLineStyle.lineColor = CPTColor.white()
        
        // configure axis
        let axisSet: CPTXYAxisSet = hostedGraph.axisSet as! CPTXYAxisSet
        let y = axisSet.yAxis
        y?.axisConstraints             = CPTConstraints.constraint(withLowerOffset: 0.0)
        y?.preferredNumberOfMajorTicks = 5
        y?.majorGridLineStyle          = majorGridLineStyle
        y?.labelOffset                 = 16.0 * 0.375
        y?.labelRotation               = CGFloat(M_PI_2)
        y?.labelingPolicy              = CPTAxisLabelingPolicy.automatic
        y?.title       = "Y Axis"
        y?.titleOffset = 16.0 * 1.25

        // create bar style
        let barLineStyle: CPTMutableLineStyle = CPTMutableLineStyle()
        barLineStyle.lineWidth = 1.0
        barLineStyle.lineColor = CPTColor.clear()
        
        // configure bar plot source
        let barPlot = CPTBarPlot(frame: CGRect.zero)
        barPlot?.lineStyle         = barLineStyle
        barPlot?.barWidthNumber    = 55.0
        barPlot?.barWidthsAreInViewCoordinates = true
        barPlot?.barCornerRadius   = 0.0
        barPlot?.barsAreHorizontal = false
        barPlot?.dataSource        = self
        barPlot?.barBasesVary = false
        barPlot?.showLabels = true
        barPlot?.labelOffset = 0
        hostedGraph.add(barPlot)
        
    }


    fileprivate func reloadGraph() {
        
        // configure plot space
        let barRange: CPTMutablePlotRange = (hostedGraph.allPlots()[0] as AnyObject).plotRangeEnclosingBars().mutableCopy()as! CPTMutablePlotRange

        barRange.expand(byFactorNumber: 2.0)
        let barPlotSpace: CPTXYPlotSpace = hostedGraph.defaultPlotSpace as! CPTXYPlotSpace
        barPlotSpace.xRange = barRange
        barPlotSpace.yRange = CPTPlotRange(locationNumber: 0, lengthNumber: maximumYRangeNumber)
        
        // reload graph
        hostedGraph.reloadData()
    }
    
    func numberOfRecords(for plot: CPTPlot!) -> UInt {
        return UInt(chartViewData!.count)
    }
    
    func number(for plot: CPTPlot!, field fieldEnum: UInt, record idx: UInt) -> Any! {
        
        var indexValue: NSNumber = 0
        
        switch fieldEnum {
        case 0:
            // set the xaxis locations
            indexValue = NSNumber(value: chartViewXIndex[Int(idx)] as Double)
        case 1:
            // set the yaxis locations
            let labelTextValue: NSNumber = NSNumber.init(value: chartViewData![Int(idx)])

            indexValue = NSNumber.init(value: labelTextValue.doubleValue > 100.0 ? 110.0 : chartViewData![Int(idx)])
        default:
            break
        }
        return indexValue
    }
    
    func barFill(for barPlot: CPTBarPlot!, record idx: UInt) -> CPTFill! {
        var color: CPTColor?
        
        switch idx {

        case 0:
            
             color = CPTColor(componentRed: 141.0/255.0, green: 199.0/255.0, blue: 63.0/255.0, alpha: 1.0)
        case 1:
            color =  CPTColor(componentRed:40.0/255.0, green: 141.0/255.0, blue: 1.0, alpha: 1.0)
            
        case 2:
            color = CPTColor(componentRed: 247.0/255.0, green: 148.0/255.0, blue: 29.0/255.0, alpha: 1.0)
            
        case 3:
            color = CPTColor(componentRed: 141.0/255.0, green: 199.0/255.0, blue: 63.0/255.0, alpha: 1.0) 
            
        default:
            break
        }
        
        let fillGradient: CPTGradient = CPTGradient(beginning: color, ending: color)
        return CPTFill(gradient: fillGradient)
    }

    
    func dataLabel(for plot: CPTPlot!, record idx: UInt) -> CPTLayer! {
        
        // create label textstyle for bar
        let labelTextStyle = CPTMutableTextStyle()
        labelTextStyle.color = CPTColor.white()
        labelTextStyle.fontSize = 14.0
        
        // get the text value
        let labelTextValue: NSNumber = NSNumber.init(value: chartViewData![Int(idx)])
        
        // set the label
        let label = CPTTextLayer(text: labelTextValue.doubleValue > 100.0 ? "Over 100%" : labelTextValue.stringValue.singleDecimalValue + "%", style: labelTextStyle)
        let textStyle = CPTTextStyle(attributes: [NSFontAttributeName : UIFont.helveticaBold(11), NSForegroundColorAttributeName: UIColor.white])
        label?.textStyle = textStyle
        return label
    }
    
}
