//
//  CPTAxis+SwiftCompat.h
//  ChartViews
//
//  Created by DBG-39 on 20/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CPTAxis.h"

@interface CPTAxis (SwiftCompat)

@property (strong, nonatomic) NSNumber *majorIntervalLengthNumber;
@property (strong, nonatomic) NSNumber *titleLocationNumber;

@end
