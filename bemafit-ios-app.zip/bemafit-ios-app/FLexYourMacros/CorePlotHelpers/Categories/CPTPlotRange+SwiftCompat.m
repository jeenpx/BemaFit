//
//  CPTPlotRange+SwiftCompat.m
//  ChartViews
//
//  Created by DBG-39 on 23/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

#import "CPTPlotRange+SwiftCompat.h"

@implementation CPTPlotRange (SwiftCompat)

+ (instancetype)plotRangeWithLocationNumber:(NSNumber *)location lengthNumber:(NSNumber *)length {

   return [self plotRangeWithLocation:location.decimalValue length:length.decimalValue] ;
}
@end
