//
//  CPTXYAxis+SwiftCompat.m
//  ChartViews
//
//  Created by DBG-39 on 20/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

#import "CPTXYAxis+SwiftCompat.h"

@implementation CPTXYAxis (SwiftCompat)

- (NSNumber *)orthogonalCoordinateDecimalNumber {
    return @([NSDecimalNumber decimalNumberWithDecimal:self.orthogonalCoordinateDecimal].doubleValue);
}

- (void)setOrthogonalCoordinateDecimalNumber:(NSNumber *)orthogonalCoordinateDecimalNumber {
    
    self.orthogonalCoordinateDecimal = orthogonalCoordinateDecimalNumber.decimalValue;

}

@end
