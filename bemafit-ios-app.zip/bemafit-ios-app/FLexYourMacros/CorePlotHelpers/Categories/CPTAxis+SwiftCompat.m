//
//  CPTAxis+SwiftCompat.m
//  ChartViews
//
//  Created by DBG-39 on 20/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

#import "CPTAxis+SwiftCompat.h"

@implementation CPTAxis (SwiftCompat)

- (NSNumber *)majorIntervalLengthNumber {
    return @([NSDecimalNumber decimalNumberWithDecimal:self.majorIntervalLength].doubleValue);
}

- (void)setMajorIntervalLengthNumber:(NSNumber *)majorIntervalLengthNumber {
    self.majorIntervalLength = majorIntervalLengthNumber.decimalValue;
}

- (NSNumber *)titleLocationNumber {
    return @([NSDecimalNumber decimalNumberWithDecimal:self.titleLocation].doubleValue);
}

- (void)setTitleLocationNumber:(NSNumber *)titleLocationNumber {
    self.titleLocation = titleLocationNumber.decimalValue;
}

@end
