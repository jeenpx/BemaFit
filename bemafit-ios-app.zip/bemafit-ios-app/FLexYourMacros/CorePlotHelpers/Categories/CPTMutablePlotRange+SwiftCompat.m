//
//  CPTMutablePlotRange+SwiftCompat.m
//  ChartViews
//
//  Created by DBG-39 on 23/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

#import "CPTMutablePlotRange+SwiftCompat.h"

@implementation CPTMutablePlotRange (SwiftCompat)

- (void)expandRangeByFactorNumber:(NSNumber *)factor {
    
    [self expandRangeByFactor:factor.decimalValue];
}

@end
