//
//  CPTAxisLabel+SwiftCompat.m
//  FlexYourMacros
//
//  Created by DBG-39 on 07/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

#import "CPTAxisLabel+SwiftCompat.h"

@implementation CPTAxisLabel (SwiftCompat)

- (NSNumber *)tickLocationNumber {
    return @([NSDecimalNumber decimalNumberWithDecimal:self.tickLocation].doubleValue);
}

- (void)setTickLocationNumber:(NSNumber *)tickLocationNumber {
    self.tickLocation = tickLocationNumber.decimalValue;
}

@end
