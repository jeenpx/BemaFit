//
//  CPTBarPlot+SwiftCompat.h
//  ChartViews
//
//  Created by DBG-39 on 23/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "CPTBarPlot.h"

@interface CPTBarPlot (SwiftCompat)

@property (strong, nonatomic) NSNumber *barWidthNumber;
@property (strong, nonatomic) NSNumber *barOffSetNumber;

@end
