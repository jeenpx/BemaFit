//
//  CPTAxisLabel+SwiftCompat.h
//  FlexYourMacros
//
//  Created by DBG-39 on 07/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//
#import <UIKit/UIKit.h>

#import "CPTAxisLabel.h"

@interface CPTAxisLabel (SwiftCompat)

@property (strong, nonatomic) NSNumber *tickLocationNumber;

@end
