//
//  UITextField+Validation.swift
//  FlexYourMacros
//
//  Created by DBG on 12/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import UIKit

extension UITextField {
    
    var isValidPassword: Bool {
        return text!.characters.count > 5
    }
    
    var isEmpty: Bool {
        return text!.trimmedString().characters.count <= 0
    }
    
    var isNonEmpty: Bool {
        return !isEmpty
    }
    
    var isValidEmailAddress: Bool {
        let regex = try? NSRegularExpression(pattern: "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}$", options: .caseInsensitive)
        return regex?.firstMatch(in: text!, options: [], range: NSMakeRange(0, text!.characters.count)) != nil
    }
    
}
