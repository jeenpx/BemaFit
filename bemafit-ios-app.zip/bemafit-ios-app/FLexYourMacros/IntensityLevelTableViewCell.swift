//
//  IntensityLevelTableViewCell.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 18/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class IntensityLevelTableViewCell: UITableViewCell {

    @IBOutlet weak var labelIntensityLevel: UILabel!
    
    @IBOutlet weak var viewSeparator: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    var itemIndexForFatLossIntensity : Int = 0 {
        
        didSet {
           labelIntensityLevel.text = getFatLossIntesityText(itemIndexForFatLossIntensity)
        }
    }
    
    var titleString: String = "" {
        didSet {
            
            var intensityString = titleString.components(separatedBy: " ")
            labelIntensityLevel.text = intensityString[1] + " " + intensityString[0]
        }
    }
    
    func getFatLossIntesityText(_ index : Int) -> String {
        
        var intensityLevel : String
        
        switch index {
            
        case 0 :
            intensityLevel = "Cautious 15%"
        case 1 :
            intensityLevel = "Moderate 20%"
        case 2 :
            intensityLevel = "Extreme  25%"
        default :
            intensityLevel = ""
        }
        return intensityLevel
    }
    
    var itemIndexForBulkingIntensity : Int = 0 {
        
        didSet {
            labelIntensityLevel.text = getBulkingIntesityText(itemIndexForBulkingIntensity)
        }
    }
    
    func getBulkingIntesityText(_ index : Int) -> String {
        
        var intensityLevel : String
        
        switch index {
            
        case 0 :
            intensityLevel = "Cautious 5%"
        case 1 :
            intensityLevel = "Moderate 10%"
        case 2 :
            intensityLevel = "Extreme  15%"
        default :
            intensityLevel = ""
        }
        return intensityLevel
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if self.accessoryType == UITableViewCellAccessoryType.checkmark {
            self.insertSubview(viewSeparator, aboveSubview: subviews.last! as UIView)
        }
    }
}
