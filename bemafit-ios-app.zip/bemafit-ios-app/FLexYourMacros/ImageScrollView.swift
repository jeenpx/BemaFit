//
//  ImageScrollView.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 05/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ImageScrollView: UIScrollView, UIScrollViewDelegate {
    
    var arrayImages: [String] = [] {
        didSet {
            
            configureScrollView()
        }
    }
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
    }
    
    func configureScrollView() {
        
        isPagingEnabled = true
        showsHorizontalScrollIndicator = false
        showsVerticalScrollIndicator = false

        // update frame
        frame  = CGRect(x: 0, y: 0, width: superview?.bounds.width ?? 375.0, height: 350.0)
        
        // set background color
        backgroundColor = UIColor.white
        
        let arrayImageViews = arrayImages.map {
            UIImageView(image: UIImage(named: $0))
        }
        
        arrayImageViews.reduce(nil) { (image1: UIImageView?, image2) -> UIImageView in
            image2.contentMode = UIViewContentMode.center
            self.addSubview(image2)
            image2.translatesAutoresizingMaskIntoConstraints = false
            
            if let image1 = image1 {
                self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[image1(imageWidth)]-0-[image2(imageWidth)]", options: [], metrics: ["imageWidth": self.bounds.width], views: ["image1": image1, "image2": image2]))
            } else {
                self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[image2(imageWidth)]", options: [], metrics: ["imageWidth": self.bounds.width], views: ["image2": image2]))
            }
            
            self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[image2(imageHeight)]-0-|", options: [], metrics: ["imageHeight": self.frame.height], views: ["image2": image2]))
            
            return image2
        }
        
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[image]-0-|", options: [], metrics: nil, views: ["image": arrayImageViews[arrayImageViews.count-1]]))
        
    }
}

