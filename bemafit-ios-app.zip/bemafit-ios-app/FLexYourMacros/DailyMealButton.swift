//
//  DailyMealButton.swift
//  FlexYourMacros
//
//  Created by Minimol BI on 19/11/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class DailyMealButton: UIButton {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!

        self.layer.cornerRadius = 4.0
        self.layer.borderColor = UIColor.grayColorDirectory().cgColor
        self.layer.borderWidth = 1.0
        self.layer.masksToBounds = true
    }

}
