//
//  NewsFeedCommentsCell.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 13/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol NewsFeedCommentCellDelegate {
    func newsFeedCommentCell(_ newsFeedCommentCell: NewsFeedCommentCell, didSelectUser userId: String)
    func newsFeedCommentCell(_ newsFeedCommentCell: NewsFeedCommentCell, didSelectHashTag hashTag: String)

}

protocol EnlargeImageCommentDelegate {
    func enlargeImageView(_ selectedCell: NewsFeedCommentCell, imageViewComment: UIImageView)
}

class NewsFeedCommentCell: SWTableViewCell, HashTagTextViewDelegate {

    var enlargeImageCommentDelegate: EnlargeImageCommentDelegate?

    // UI elements
    @IBOutlet fileprivate weak var imageViewProfilePic: UIImageView!
    @IBOutlet fileprivate weak var textViewComment: HashTagTextView!
    @IBOutlet fileprivate weak var imageViewComment: UIImageView!
    @IBOutlet fileprivate weak var labelTimeStamp: UILabel!
    @IBOutlet weak var lcTextViewHeight: NSLayoutConstraint!
    @IBOutlet weak var lcImageWidth: NSLayoutConstraint!
    @IBOutlet weak var lcImageHeight: NSLayoutConstraint!
    
    // constraints
    @IBOutlet fileprivate weak var constraintImageViewHeight: NSLayoutConstraint!
    @IBOutlet fileprivate weak var constraintPadding: NSLayoutConstraint!
    
    var constraintTextViewHeight: [NSLayoutConstraint]?
    
    // NewsFeedCommentCellDelegate
    var newsFeedCommentCellDelegate: NewsFeedCommentCellDelegate?
    
    var isNetworkReachable: Bool {
        let reachability = (UIApplication.shared.delegate as! AppDelegate).internetReachable
        
        if !reachability {
            
            // no internet
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
        }
        
        return reachability
    }
    
    var newsFeed = NewsFeed() {
        didSet {
            
            // check whether the currrent user posted the feed
            if newsFeed.userId == AppConfiguration.sharedAppConfiguration.userDetails?.userId {
                
                // Add right utility buttons to all the comments
                rightUtilityButtons = configureRightUtilityButtons() as! [Any]
            }
            else {
                // feeds posted by friends
                
                if newsFeedComment.userId == AppConfiguration.sharedAppConfiguration.userDetails?.userId {
                    
                    // Add right utility buttons to the comments from user
                    rightUtilityButtons = configureRightUtilityButtons() as! [Any]
                }
            }
        }
    }
    
    // news feed data
    var newsFeedComment = NewsFeedComment() {
        didSet {
            
            // we dont need cell selection
            selectionStyle = .none
            
            // round edges for profile pic
            imageViewProfilePic.layer.cornerRadius = imageViewProfilePic.bounds.width / 2
            imageViewProfilePic.clipsToBounds = true
            
            textViewComment.text = newsFeedComment.comment
            textViewComment.configureForHashTagDetection(true)
            textViewComment.prependSender(newsFeedComment.userName, senderId: newsFeedComment.userId)
            textViewComment.hashTagTextViewDelegate = self
            
            if let profileImageURL = URL(string: newsFeedComment.userImage) {
                imageViewProfilePic.setImageWith(profileImageURL, placeholderImage: UIImage(named: "PlaceHolderProfilePic"))
            }
            
           
            
            labelTimeStamp.text = (newsFeedComment.date as NSDate).timeAgo()
            
//            textViewComment.sizeToFit()
//            textViewComment.layoutIfNeeded()
            
            hasImage = false
            lcImageWidth.constant = 0
            lcImageHeight.constant = 0
            
            if !newsFeedComment.image.isEmpty {
//                imageViewComment.setImageWith(URL(string: newsFeedComment.image))
                
                let urlString = newsFeedComment.image
//                imageViewComment.contentMode = .scaleAspectFit
                imageViewComment.backgroundColor = .clear
                if SDWebImageManager.shared().cachedImageExists(for: NSURL.init(string: urlString) as URL!) {
                    self.imageViewComment.sd_setImage(with: NSURL.init(string: urlString) as URL!)
                    setupImageFrames()
                }
                else {
                    
                    self.imageViewComment.sd_setImage(with: NSURL.init(string: urlString) as URL!, placeholderImage:nil, options: [.avoidAutoSetImage,.highPriority,.retryFailed,.delayPlaceholder], completed: { (image, error, cacheType, url) in
                        if error == nil {
                            DispatchQueue.main.async {
                                self.imageViewComment.image = image
                                self.setupImageFrames()
                            }
                        }
                    })
                }
                hasImage = true
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(NewsFeedCommentCell.didTapImageViewCommentWithGesture(_:)))
                tapGesture.delegate = self
                
                // add tap gesture to the food imageview
                imageViewComment.addGestureRecognizer(tapGesture)
                imageViewComment.isUserInteractionEnabled = true
                
//                lcImageWidth.constant = 150
//                lcImageHeight.constant = 150
            }
            self.layoutIfNeeded()
            
            imageViewProfilePic.gestureRecognizers = [UITapGestureRecognizer(target: self, action: #selector(NewsFeedCommentCell.imageViewProfilePicTapped(_:)))]
        }
    }
    
    func setupImageFrames() {
        
        let maxSize:CGFloat = 250
        let minSize:CGFloat = 150
        var currentWidth = (imageViewComment.image?.size.width ?? 1)
        var currentHeight = (imageViewComment.image?.size.height ?? 1)
        var newWidth = currentWidth
        var newHeight = currentHeight
        
        if currentWidth > maxSize {
            newWidth =  maxSize
            
            newHeight = newWidth*currentHeight/currentWidth
        }
        else if currentHeight > maxSize {
            newHeight = maxSize
            
            newWidth = newHeight*currentWidth/currentHeight
        }
        
        currentWidth = newWidth
        currentHeight = newHeight
        
        if newWidth < minSize {
            newWidth = minSize
            
            newHeight = newWidth*currentHeight/currentWidth
        }
        else if currentHeight > maxSize {
            newHeight = minSize
            
            newWidth = newHeight*currentWidth/currentHeight
        }
        
        lcImageHeight.constant = newHeight
        lcImageWidth.constant = newWidth
        self.layoutIfNeeded()
        
    }
    
    func didTapImageViewCommentWithGesture(_ tapGesture: UITapGestureRecognizer) {
        enlargeImageCommentDelegate?.enlargeImageView(self, imageViewComment: imageViewComment)
    }
    // default comment doesn't include image
    var hasImage: Bool = false {
        didSet {
            
            // update constraints based on image content
//            constraintImageViewHeight.constant = hasImage ? 200 : 0
//            constraintPadding.constant = hasImage ? 8 : 0
            
            updateConstraintsIfNeeded()
        }
    }
    
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//        
//        configureCell()
//    }
//    
//    func configureCell() {
//        
//        // Add right utility buttons
//        rightUtilityButtons = configureRightUtilityButtons() as [Any]
//    }
    
    func configureRightUtilityButtons() -> NSArray {
        // configure right utility button for swipe delete
        
        let rightUtilityButtons = NSMutableArray()
        rightUtilityButtons.addUtilityButtonWithBackgroundColor(UIColor(red: 224.0/255.0, green: 224.0/255.0, blue: 224.0/255.0, alpha: 1.0),
            andTitleColor: UIColor.red, andTitle: NSLocalizedString("message_swipe_delete_title", comment: ""))
        return rightUtilityButtons
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        
        imageViewComment.image = nil
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func hashTagTextView(_ hashTagTextView: HashTagTextView, didSelectUser user: String) {
        newsFeedCommentCellDelegate?.newsFeedCommentCell(self, didSelectUser: user)
    }
    
    func imageViewProfilePicTapped(_ sender: UITapGestureRecognizer) {
        newsFeedCommentCellDelegate?.newsFeedCommentCell(self, didSelectUser: newsFeedComment.userId)
    }
    
    func hashTagTextView(_ hashTagTextView: HashTagTextView, didSelectHashTag hashTag: String) {
        // hashtag
        // abort if no network
        if !isNetworkReachable { return }
        
        newsFeedCommentCellDelegate?.newsFeedCommentCell(self, didSelectHashTag: hashTag)
    }
    
    func hashTagTextView(_ hashTagTextView: HashTagTextView, didSelectBusinessDirectory businessDirectory: String) {
        // business directory
    }
}
