//
//  MacroTableViewCell.swift
//  ChartViews
//
//  Created by DBG-39 on 25/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

import UIKit

class MacroTableViewCell: UITableViewCell {

    var macroColor: UIColor = UIColor.clear {
        didSet {
            viewBullet.backgroundColor = macroColor
        }
    }

    func configure(_ macroName: String, macroTotal: String, macroAchieved: String) {
        
        labelMacroName.text = macroName
        
        let macroTotalValue = macroTotal.doubleValue
        
        let macroAchievedValue = macroAchieved.doubleValue
        
        let macroPercentage = (macroAchievedValue/macroTotalValue)*100
        
        labelMacroGoal.text = "\(macroTotal.singleDecimalValue) g"
        
        labelMacroTotal.text = "\(macroPercentage.stringValue.singleDecimalValue)%"

    }

    @IBOutlet fileprivate weak var viewBullet: UIView!
    @IBOutlet fileprivate weak var labelMacroName: UILabel!
    @IBOutlet fileprivate weak var labelMacroTotal: UILabel!
    @IBOutlet fileprivate weak var labelMacroGoal: UILabel!
    @IBOutlet fileprivate weak var constraintTextMargin: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // adjust text margin
        constraintTextMargin.constant = macroColor == UIColor.clear ? -10 : 8
    }
}
