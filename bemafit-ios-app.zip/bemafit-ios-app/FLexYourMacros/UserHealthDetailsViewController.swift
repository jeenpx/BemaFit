//
//  UserHealthDetailsViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 05/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

enum Gender: String {
    case Male   = "male"
    case Female = "female"
    
    static var genderTypes = [Male, Female]
    
    var description: String {
        switch self {
        case .Male : return "M"
        case .Female : return "F"
        }
    }
}

class UserHealthDetailsViewController: UITableViewController, UITextFieldDelegate, UIAlertViewDelegate {
    
    @IBOutlet weak var segmentGender: UISegmentedControl!
    @IBOutlet weak var textFieldDOB: UITextField!
    @IBOutlet weak var textFieldHeight: UITextField!
    //height in unit -- height in inches
    @IBOutlet weak var textFieldHeightUnits: UITextField!
    @IBOutlet weak var textFieldWeight: UITextField!
    @IBOutlet weak var textFieldBodyFat: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var toolBar: UIToolbar!
    var currentTextField = UITextField()
    internal var canDismissView = true
    var alert = UIAlertView()

    let FymUserModel = FymUser.sharedFymUser
    
    internal var canAbort = false
    
    struct StoryBoard {
        
        struct SegueIdentifiers {
            static let FormulaSelect = "kFormulaSelect"
        }
    }

    fileprivate var gender = Gender.Male {
        didSet {
            
            //print("gender description ------\(gender.description)")
           FymUserModel.userGender = gender.description
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldDOB.inputView = datePicker
        textFieldDOB.inputAccessoryView = toolBar
        
        setDatePickerMaximumDate()
        
        // initialize userGender with male
        if FymUserModel.userGender == "" {
            gender = Gender.Male
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        // view is active, should not abort
        canAbort = false
        canDismissView = true
        loadWithExistingCredentials()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // view is inactive, abort all checks
        canAbort = true
        alert.dismiss(withClickedButtonIndex: 0, animated: false)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        alert.dismiss(withClickedButtonIndex: 0, animated: false)
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        currentTextField = textField
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if (string == ".") {
            return false
        }
        
        let aSet = CharacterSet(charactersIn:"0123456789").inverted
        let compSepByCharInSet = string.components(separatedBy: aSet)
        let numberFiltered = compSepByCharInSet.joined(separator: "")
        
        if (numberFiltered.characters.count == 0 && string.characters.count != 0) {
            return false
        }
        
        // managing the textfield input: limit the characters to only of numeric type
        var result = true
        
        let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        if string.characters.count > 0 {
            let disallowedCharacterSet = CharacterSet(charactersIn: allowString).inverted
            let replacementStringIsLegal = string.rangeOfCharacter(from: disallowedCharacterSet) == nil
            let resultingStringLengthIsLegal = prospectiveText.characters.count <= 6
            let scanner = Scanner(string: prospectiveText)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
            result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
        }
        
        switch textField {
        case textFieldHeight, textFieldHeightUnits, textFieldBodyFat:
            return textField.text!.characters.count + string.characters.count - range.length <= 2
        case textFieldWeight:
            return textField.text!.characters.count + string.characters.count - range.length <= 3
        default:
            break
        }
        return result
    }
    
    var allowString: String {
        
        if currentTextField == textFieldHeight || currentTextField == textFieldHeightUnits {
            
            return "0123456789"
        }
        
        return "0123456789."
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // resign keyboard
        textField.resignFirstResponder()
        return true
    }
    
    func didPresent(_ alertView: UIAlertView) {
        canDismissView = false
    }
    
    func alertViewCancel(_ alertView: UIAlertView) {
        canDismissView = true
    }
    
    func alertView(_ alertView: UIAlertView, didDismissWithButtonIndex buttonIndex: Int) {
        canDismissView = true
    }
    
    fileprivate func loadWithExistingCredentials() {
        
        // load with entered credentials
        textFieldDOB.text = getTheDateInDisplayFormat(FymUserModel.userDobString)
        textFieldWeight.text = FymUserModel.userWeight
        textFieldBodyFat.text = FymUserModel.userFatLoss
        
        // seperate height to feet and inches
        var heightComponentArray = FymUserModel.userHeight.components(separatedBy: ".")
        if heightComponentArray.count > 1 {
        textFieldHeight.text = heightComponentArray[0]
            textFieldHeightUnits.text = heightComponentArray[1] }
        
        // select the gender
        segmentGender.selectedSegmentIndex = FymUserModel.userGender == "M" ? 0 : 1
        
    }
   
    fileprivate func setDatePickerMaximumDate() {
    
        let calendar = Calendar.current
        var components = DateComponents()
        components.year = -10
        
        // min date
        let maximumDate = (calendar as NSCalendar).date(byAdding: components, to: Date(), options: [])
        datePicker.maximumDate = maximumDate
        
        // min date
        components.year = -150
        let minimumDate = (calendar as NSCalendar).date(byAdding: components, to: Date(), options: [])
        datePicker.minimumDate = minimumDate

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        
        if (segue.identifier == StoryBoard.SegueIdentifiers.FormulaSelect) {
            FymUserModel.userWeight = textFieldWeight.text!
            
            let userHeightInFeet = textFieldHeight.text == "" ? "0" : textFieldHeight.text
            let userHeightInInch = textFieldHeightUnits.text == "" ? "0" : textFieldHeightUnits.text
            FymUserModel.userHeight = userHeightInFeet! + "." + userHeightInInch!
            
            //print("userheight in cm ----\(FymUserModel.userHeightinCm)")
//            if !textFieldBodyFat.text.isEmpty {
                FymUserModel.userFatLoss = textFieldBodyFat.text!
//        }
        }
        
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if (identifier == StoryBoard.SegueIdentifiers.FormulaSelect) {
            return checkAllFields()
        }
        
        alert.dismiss(withClickedButtonIndex: 0, animated: false)
        return true
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    func checkAllFields() -> Bool {
        
        currentTextField.resignFirstResponder()
        
        // abort if needed
//        if canAbort { return false}
        
        // check all fields are filled
        if textFieldDOB.text!.isEmpty {
            self.showAlert(&&"notice", message: &&"enter_date_of_birth")
            return false

            
        }else if ( textFieldHeight.text!.isEmpty && textFieldHeightUnits.text!.isEmpty || textFieldHeight.text!.doubleValue <= 0.0 ){
            
            self.showAlert(&&"notice", message: &&"enter_height")
            return false

            
        } else if  textFieldWeight.text!.isEmpty || textFieldWeight.text!.doubleValue <= 0.0 {
            
            self.showAlert(&&"notice", message: &&"enter_weight")
            return false

        } else if !textFieldBodyFat.text!.isEmpty {
            
            let fatValue = textFieldBodyFat.text!.doubleValue
            
            if fatValue <= 0.0 {
                self.showAlert(&&"notice", message: &&"enter_fat_less_alert_message")
                return false

            } else if fatValue > 100.0 {
                self.showAlert(&&"notice", message: &&"enter_fat_greater_alert_message")
                return false
            }
        }
        return true
    }

    
    func showAlert(_ title: String, message: String) {
        
        // show alert controller if possible else show alert view
//        if NSClassFromString(Class.UIAlertController) != nil {
//            
//            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//            
//            alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
//            
//            self.presentViewController(alert, animated: true, completion: nil)
//            return
//        }
//        else {
        
            alert = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"ok")
            alert.show()
            return
//        }
    }
    
    @IBAction func segmentActionSelectGender(_ sender: UISegmentedControl, forEvent event: UIEvent) {
        // get the selected index and the title for the section asssign to userGender
        
        gender = Gender.genderTypes[sender.selectedSegmentIndex]
     }
    
    @IBAction func buttonActionPickerDone(_ sender: UIBarButtonItem) {
        textFieldDOB.resignFirstResponder()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        // get the pickerdate and assign it to the DOB field
        let strDate = dateFormatter.string(from: datePicker.date)
        FymUserModel.userDob = datePicker.date
        FymUserModel.userDobString = strDate
        textFieldDOB.text = getTheDateInDisplayFormat(strDate)
    }
    
    fileprivate func getTheDateInDisplayFormat(_ dateString: String) -> (String){
        
        if dateString == "" {
            return ""
        }
        // get the date in return format eg Apr 01, 2013
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let formattedDate = dateFormatter.date(from: dateString)
        let returnDateFormatter = DateFormatter()
        returnDateFormatter.dateStyle =  .medium
        let formattedDateString = returnDateFormatter.string(from: formattedDate!)
        return formattedDateString
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    @IBAction func unwindToUserHealthDetailsViewController(_ segue: UIStoryboardSegue) {
        self.navigationController?.isNavigationBarHidden = false
    }
    
    @IBAction func buttonActionBack(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: false)

    }

}
