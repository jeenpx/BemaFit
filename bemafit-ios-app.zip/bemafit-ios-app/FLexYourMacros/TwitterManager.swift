//
//  TwitterManager.swift
//  SWTShareTwitter
//
//  Created by DBG on 23/03/15.
//  Copyright (c) 2015 dbg. All rights reserved.
//

import Foundation
import Social
import Accounts

class TwitterManager {
    
    class var ErrorCodeAccountNotSetUp: Int {
        return 404
    }
    
    let requestUrl = "https://upload.twitter.com/1/statuses/update_with_media.json"
    
    typealias FailureBlock = (_ error: NSError) -> ()
    typealias SuccessBlock = (_ data: Data, _ urlResponse: HTTPURLResponse) -> ()
    typealias SuccessBlock1 = (_ data: String) -> ()
    
    // singleton manager
    class var sharedManager: TwitterManager {
        struct Singleton {
            static let instance = TwitterManager()
        }
        return Singleton.instance
    }
    
    func shareTweetsUsingUI(_ viewController: UIViewController,messages: String, andImage image: UIImage, withSuccessBlock successBlock: @escaping SuccessBlock1, andFailureBlock failureBlock: FailureBlock) {
        
        let viewController = viewController
        if SLComposeViewController.isAvailable(forServiceType: SLServiceTypeTwitter) {
            let tweetSheet:SLComposeViewController = SLComposeViewController(forServiceType: SLServiceTypeTwitter)
            tweetSheet.setInitialText(messages)
            tweetSheet.add(image)
            
            tweetSheet.completionHandler = {
                result -> Void in
                let getResult = result as SLComposeViewControllerResult;
                switch(getResult.rawValue) {
                case SLComposeViewControllerResult.cancelled.rawValue:
                    print("Cancelled")
                case SLComposeViewControllerResult.done.rawValue:
                    print("It's Work!")
                default:
                    print("Error!")
                }
                successBlock("Success")
                viewController.dismiss(animated: true, completion: nil)
            }
            
            
            viewController.present(tweetSheet, animated: true, completion: nil)
            
        } else {
            failureBlock(NSError(domain: "",
                code: TwitterManager.ErrorCodeAccountNotSetUp,
                userInfo: [NSLocalizedDescriptionKey: "Twitter Account not setup"]));
        }
        
        
        
    }
    func shareMessage(_ messages: NSDictionary, andImage image: UIImage, withSuccessBlock successBlock: @escaping SuccessBlock, andFailureBlock failureBlock: @escaping FailureBlock) {
        // called to share text and image in twitter
        SVProgressHUD.show()
        // get the twitter account type
        let account = ACAccountStore()
        let accountType = account.accountType(withAccountTypeIdentifier: ACAccountTypeIdentifierTwitter)
        
        // fetch twitter accounts
        account.requestAccessToAccounts(with: accountType, options: nil) { (status, error) in
            
            // get accounts
            let arrayAccounts = status ? account.accounts(with: accountType) : []
            
            // twitter account not set up
            if (arrayAccounts?.count)! <= 0 {
                SVProgressHUD.dismiss()
                failureBlock(NSError(domain: "",
                    code: TwitterManager.ErrorCodeAccountNotSetUp,
                    userInfo: [NSLocalizedDescriptionKey: "Twitter Account not setup"]));
                return
            }
            
            // get the twitter account
            let twitterAccount = arrayAccounts?.last as! ACAccount
            
            // post to twitter
            let requestURL = URL(string: self.requestUrl)!
            let postRequest = SLRequest(forServiceType:SLServiceTypeTwitter, requestMethod: SLRequestMethod.POST, url: requestURL, parameters: messages as! [AnyHashable: Any])
            let imageData = UIImagePNGRepresentation(image)
            postRequest?.account = twitterAccount
            postRequest?.addMultipartData(imageData, withName: "media", type: "image/jpg", filename: "TwitterImage")
            postRequest?.perform() { (responseData, urlResponse, error) in
                
                // on failure to upload the image
                if error != nil {
                    SVProgressHUD.dismiss()
                    failureBlock(error as! NSError)
                    return
                }
                SVProgressHUD.dismiss()
                // on successfully uploaded
                successBlock(responseData!, urlResponse!)
            }
        }
    }
}
