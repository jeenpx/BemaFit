//
//  NSDate+Extensions.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/6/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let kMinute = 60
private let kDay = kMinute * 24

extension Date {
    
    func stringFromFormat(_ format: String, withValue value: Int) -> String {
        // get the string value from format
        
        // XXX - how to avoid getLocaleFormatUnderscoresWithValue
        let localeFormat = String(format: format, getLocaleFormatUnderscoresWithValue(Double(value)))
        return String(format: NSLocalizedString(localeFormat, comment: ""), value)
    }
    
    func getLocaleFormatUnderscoresWithValue(_ value: Double) -> String {
        // get the locale format
        
        // country code
        let localeCode = Locale.preferredLanguages.first! 
        
        if localeCode == "ru" {
            let XY = Int(floor(value)) % 100
            let Y = Int(floor(value)) % 10
            
            if Y == 0 || Y > 4 || (XY > 10 && XY < 15) {
                return ""
            }
            
            if Y > 1 && Y < 5 && (XY < 10 || XY > 20) {
                return "_"
            }
            
            if Y == 1 && XY != 11 {
                return "__"
            }
        }
    
        return ""
    }
        
    // dateFormat has precedence over dateStyle
    // date style defaults to LongStyle
    func stringValue(_ dateFormat: String? = nil, dateStyle: DateFormatter.Style? = nil, showToday: Bool = false) -> String {
        
        // return today text if its today
        if showToday {
            if self.isToday() {
                return &&"today"
            }
        }
        
        // get a date formatter
        let dateFormatter = DateFormatter()
        
        // set appropriate date styles/formats
        if let dateFormat = dateFormat {
            dateFormatter.dateFormat = dateFormat
        }
        else if let dateStyle = dateStyle {
            dateFormatter.dateStyle = dateStyle
        }
        else {
            dateFormatter.dateStyle = DateFormatter.Style.long
        }
        
        dateFormatter.locale = Locale.current
        
        // return the string after formatting
        return dateFormatter.string(from: self)
    }
    
    func isToday() -> Bool {
        
        // get a calendar
        let calendar = Calendar(identifier: Calendar.Identifier.gregorian)
        
        // get today calendar components (emit time or normalize to midnight)
        let requiredTodayCalendarComponents: NSCalendar.Unit = [NSCalendar.Unit.NSYearCalendarUnit, NSCalendar.Unit.NSMonthCalendarUnit, NSCalendar.Unit.NSDayCalendarUnit]
        let todayCalendarComponents = (calendar as NSCalendar?)?.components(requiredTodayCalendarComponents, from: Date())
        let currentCalendarComponents = (calendar as NSCalendar?)?.components(requiredTodayCalendarComponents, from: self)
        
        return todayCalendarComponents == currentCalendarComponents
    }
    
    func nextDay() -> Date {
        
        // get a calendar
        let calendar = Calendar(identifier: Calendar.Identifier.gregorian)
        
        // get the date components for next day
        var dateComponents = DateComponents()
        dateComponents.day = 1
        
        // return next day
        return (calendar as NSCalendar).date(byAdding: dateComponents, to: self, options: [])!
    }
    
    func previousDay() -> Date {
        
        // get a calendar
        let calendar = Calendar(identifier: Calendar.Identifier.gregorian)
        
        // get the date components for next day
        var dateComponents = DateComponents()
        dateComponents.day = -1
        
        // return next day
        return (calendar as NSCalendar).date(byAdding: dateComponents, to: self, options: [])!
    }
    
    func numberOfDaysInMonth() -> Int {
        // get the number of days in a month
        let calendar = Calendar.current
        let days = (calendar as NSCalendar).range(of: .NSDayCalendarUnit, in: .NSMonthCalendarUnit, for: self)
        return days.length

    }
    
    func numberOfDaysInFirstWeek() -> Int {
        let calendar = Calendar.current
        // calculate day of the first date
        let component = (calendar as NSCalendar).components(NSCalendar.Unit.NSWeekdayCalendarUnit, from: firstDateOftheMonth())
        let weekDay = component.weekday
        return 7 - weekDay!
    }
    
    func firstDateOftheMonth() -> Date {
        // calculate the first date of the month
        let calendar = Calendar.current
        var firstDateComponents = (calendar as NSCalendar).components([.NSYearCalendarUnit, .NSMonthCalendarUnit, .NSDayCalendarUnit], from: self)
        firstDateComponents.day = 1
        firstDateComponents.hour = 0
        firstDateComponents.minute = 0
        firstDateComponents.second = 0
        return calendar.date(from: firstDateComponents)!
    }
    
    func dateComponents() -> DateComponents {
       // get the date componenets for the date
        let calendar = Calendar.current
        let components = (calendar as NSCalendar).components([.month, .day, .year, .weekOfMonth, .weekday], from: self)
        return components
    }
    
    func numberOfWeeks() -> Int {
        
        // calculate the number of weeks
        let calendar = Calendar.current
        let weekRange = (calendar as NSCalendar).range(of: NSCalendar.Unit.NSWeekCalendarUnit, in: NSCalendar.Unit.NSMonthCalendarUnit, for: self)
        let weeksCount=weekRange.length
        return weeksCount
    }
    
    func startOfMonth() -> Date? {
        
        let calendar = Calendar.current
        let currentDateComponents = (calendar as NSCalendar).components([.year, .month], from: self)
        let startOfMonth = calendar.date(from: currentDateComponents)
        
        return startOfMonth
    }
    
    func dateByAddingMonths(_ monthsToAdd: Int) -> Date? {
        
        let calendar = Calendar.current
        var months = DateComponents()
        months.month = monthsToAdd
        
        return (calendar as NSCalendar).date(byAdding: months, to: self, options: [])
    }
    
    func endOfMonth() -> Date? {
        
        let calendar = Calendar.current
        if let plusOneMonthDate = dateByAddingMonths(1) {
            let plusOneMonthDateComponents = (calendar as NSCalendar).components([.year, .month], from: plusOneMonthDate)
            
            let endOfMonth = calendar.date(from: plusOneMonthDateComponents)?.addingTimeInterval(-1)
            
            return endOfMonth
        }
        
        return nil
    }
    
    func weekArrayForMonthOfDate() -> [[String : Date]] {
        
        // get the week array for the month: every week start & end date
        var weekArray =  [[String:Date]]()
        var lastDate: Date?
        for i in 0 ..< numberOfWeeks() {
            
            var dayComponent = DateComponents()
            let calendar = Calendar.current
            var itemDictionary = [String:Date]()
            
            // for the first index of the number of weeks find out how many days are there and make the start&end date based on that
            if i == 0 {
                dayComponent.day = numberOfDaysInFirstWeek()
                let endDate = (calendar as NSCalendar).date(byAdding: dayComponent, to: firstDateOftheMonth(), options: NSCalendar.Options())
                var startDate = firstDateOftheMonth()
                if numberOfDaysInFirstWeek() != 7 {
                   
                    dayComponent.day = -1*(6-numberOfDaysInFirstWeek())
                    startDate = (calendar as NSCalendar).date(byAdding: dayComponent, to: firstDateOftheMonth(), options: NSCalendar.Options())!
                }
                itemDictionary = ["startDate" : startDate, "endDate" : endDate!]
                weekArray.append(itemDictionary)
                lastDate = endDate
                
            } else {
                
                //for all other indices except the last index
                if i < numberOfWeeks() - 1  {
                    dayComponent.day = 1;
                    let startDate = (calendar as NSCalendar).date(byAdding: dayComponent, to: lastDate!, options: NSCalendar.Options())
                    dayComponent.day = 6;
                    let endDate = (calendar as NSCalendar).date(byAdding: dayComponent, to: startDate!, options: NSCalendar.Options())
                    itemDictionary = ["startDate" : startDate!, "endDate" : endDate!]
                    weekArray.append(itemDictionary)
                    lastDate = endDate
                    
                } else {
                    
                    //for the last index of the number of weeks
                    dayComponent.day = 1;
                    let startDate = (calendar as NSCalendar).date(byAdding: dayComponent, to: lastDate!, options: NSCalendar.Options())
                    dayComponent.day = (numberOfDaysInMonth() - numberOfDaysInFirstWeek()) % 7 == 0 ? 6 : (numberOfDaysInMonth() - numberOfDaysInFirstWeek()) % 7 + (6-((numberOfDaysInMonth() - numberOfDaysInFirstWeek()) % 7))
//                    dayComponent.month = (numberOfDaysInMonth() - numberOfDaysInFirstWeek()) % 7 == 0 ? 0 :1

                    let endDate = (calendar as NSCalendar).date(byAdding: dayComponent, to: startDate!, options: NSCalendar.Options())
                    itemDictionary = ["startDate" : startDate!, "endDate" : endDate!]
                    weekArray.append(itemDictionary)
                    lastDate = endDate
                }
            }
        }
        
        return weekArray
    }
    
    // returns true if date is within the start and end date or equal to the start or end date
    func isInRange(_ startDate: Date, endDate: Date) -> Bool {
        return (self.compare(startDate) == .orderedDescending && self.compare(endDate) == .orderedAscending) || self.compare(startDate) == .orderedSame || self.compare(endDate) == .orderedSame
    }
}

