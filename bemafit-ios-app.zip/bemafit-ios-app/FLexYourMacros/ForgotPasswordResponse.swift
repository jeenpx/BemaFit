 //
//  ForgotPasswordResponse.swift
//  FlexYourMacros
//
//  Created by Aromal Sasidharan on 6/15/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation


var metaModel: MetaModel?
var userId: String?
class ForgotPasswordResponse: NSObject {
    var metaModel: MetaModel?
    
    class var responseMapping: RKObjectMapping {
    
    let responseMapping = RKObjectMapping(for: self)
    
    // give referece to meta model
    responseMapping?.addPropertyMapping(ForgotPasswordResponse.metaModelKeyMapping)
    
    return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    class var responseDescriptor: RKResponseDescriptor {
        let mealTypeCreateResponseDescriptor = RKResponseDescriptor(mapping: ForgotPasswordResponse.responseMapping, method: .POST, pathPattern: Constants.ServiceConstants.kForgotPasswordUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return mealTypeCreateResponseDescriptor!
    }
    class func requestForPassword(_ email:String,completionHandler:@escaping (_ response:String) -> ()) {
        
        
        var parameterDictionary: [String:String] {
            
            // save useremail and password for a session
            
            
            // create the parameter dictionary
            return ["email":email]
        }
        
        // get the objects from the path login
        
        
        
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path: Constants.ServiceConstants.kForgotPasswordUrl, parameters: parameterDictionary, constructingBodyWith: { (formData) in
            
        })
        var err: NSError?

        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation,mappedResult) in
            
            let forgotPasswordResponse = mappedResult?.firstObject as! ForgotPasswordResponse
            
            //print("Response of forget password \(forgotPasswordResponse.metaModel?.responseStatus)")
            
            if forgotPasswordResponse.metaModel?.responseCode != 200 {
                //completionHandler(response: "Failure\(forgotPasswordResponse.metaModel?.responseCode)")
                
                if forgotPasswordResponse.metaModel?.responseCode == 404 {
                    completionHandler(&&"email_not_exist")
                }
                else if forgotPasswordResponse.metaModel?.responseCode == 422 {
                    completionHandler(&&"enter_valid_email_alert_message")
                }
                else {
                    
                }
               return
            }
            completionHandler("Success")
            
            }) { (operation, error) in
                
             completionHandler("Failure")
                //print("Response Failed");
                
        }
        RestKitManager.shared().enqueue(operation)
        
        
    }
}
