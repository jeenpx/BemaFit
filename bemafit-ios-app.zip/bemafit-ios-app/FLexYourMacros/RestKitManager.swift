//
//  RestKitManager.swift
//  FlexYourMacros
//

import Foundation

class RestKitManager: RKObjectManager, UIAlertViewDelegate {
    
    class func configureProgressHUD() {
        SVProgressHUD.setDefaultMaskType(SVProgressHUDMaskType.clear)
        SVProgressHUD.setBackgroundColor(UIColor.clear)
        SVProgressHUD.setForegroundColor(UIColor.defaultThemeBlueColor())
        SVProgressHUD.setRingThickness(6.0)
    }
    
    class func configureResponseDescriptors() {
        
        // add the response descriptor
        let objectManager = RestKitManager.shared() as RestKitManager;
        
        objectManager.addResponseDescriptor(UserLogInResponse.responseDescriptor)
        
        // add    response descriptor
        objectManager.addResponseDescriptor(MasterDataResponse.responseDescriptor)
        objectManager.addResponseDescriptor(MasterDataResponse.foodCategoryResponseDescriptor)
        
        // add response descriptor for user facebook response
        objectManager.addResponseDescriptor(UserVerificationResponse.responseDescriptor)
        
        //add signup response descriptor
        objectManager.addResponseDescriptor(UserSignUpResponse.responseDescriptor)
        
        //add progress response descriptor
        
        objectManager.addResponseDescriptor(ProgressResponse.responseDescriptor)
        
        // add response descriptor for post weight and bodyfat
        objectManager.addResponseDescriptor(ProgressLogWeightAndFatResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(ExerciseResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(ExerciseTypeResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(ExerciseLogResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(ExerciseCreateResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(ExerciseDeleteResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(ExerciseUpdateResponse.responseDescriptor)
        
        // message response descriptor
        objectManager.addResponseDescriptor(MessageResponse.responseDescriptor)
        
        // message thread response descriptor
        objectManager.addResponseDescriptor(MessageThreadResponse.responseDescriptor)
        
        // post message response descriptor
        objectManager.addResponseDescriptor(MessageSendResponse.responseDescriptor)
        
        // delete message response descriptor
        objectManager.addResponseDescriptor(MessageDeleteResponse.responseDescriptor)
        
        //add users response descriptor
        objectManager.addResponseDescriptor(GetUsersResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(ChangePasswordResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(GetUserSettingResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(GetFriendsResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(FriendsRequestResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(UnfriendResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(UpdateUserSettingsResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(FriendsRequestResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(UpdateUserResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(ProfilePicResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(InviteFriendResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(DirectoryGetResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(DirectoryCheckInResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(GetFollowingFollowerUserResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(InviteFriendResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(UserProfileresponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(InviteFriendResponse.userResponseDescriptor)
        
        objectManager.addResponseDescriptor(InviteFriendResponse.userResponseDescriptorForEmailInvite)
        
        objectManager.addResponseDescriptor(ExerciseCategoryResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(ListLogFoodResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(UserMacroDetailResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(DeletFoodLogResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(ChangeShareStatusFoodLogResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(ManageGoalsUpdateUserResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(ForgotPasswordResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(FacebookConnectResponse.facebookConnectDescriptor)
        
        objectManager.addResponseDescriptor(ContactUsResponse.userResponseDescriptor)
        
        // hash tag get response
        objectManager.addResponseDescriptor(HashTagGetResponse.responseDescriptor)
        
        //access token response descriptor
        objectManager.addResponseDescriptor(AccessTokenRefreshResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(ResendEmailResponse.responseDescriptor)
        
        // news feed comments delete
        objectManager.addResponseDescriptor(NewsFeedCommentsDeleteResponse.responseDescriptor)
        
        // news feed delete
        objectManager.addResponseDescriptor(NewsFeedDeleteResponse.responseDescriptor)
        
        // logout
        objectManager.addResponseDescriptor(LogoutResponse.responseDescriptor)
        
        // daily meal plan delete
        objectManager.addResponseDescriptor(DailyMealPlanDeleteResponse.responseDescriptor)
        
        // daily meal plan type listing
        objectManager.addResponseDescriptor(DailyMealPlanMealTypeResponseModel.responseDescriptor)
        
        // route class for Invite friends via email
        let inviteFriendsRoute: RKRoute = RKRoute(with: InviteFriendResponse.self, pathPattern: Constants.ServiceConstants.inviteFriendsUrl, method: RKRequestMethod.POST)
        objectManager.router.routeSet.add(inviteFriendsRoute)
        
        // route class for get messages
        let getMessageRoute: RKRoute = RKRoute(with: MessageResponse.self, pathPattern: Constants.ServiceConstants.kUrlGetMessages, method: RKRequestMethod.GET)
        objectManager.router.routeSet.add(getMessageRoute)
        
        // rote class to list thread messages
        let getThreadMessageRoute: RKRoute = RKRoute(with: MessageThreadResponse.self, pathPattern: Constants.ServiceConstants.kUrlThreadMessages, method: RKRequestMethod.GET)
        objectManager.router.routeSet.add(getThreadMessageRoute)
        
        // route class to post message
        let postMessageRoute: RKRoute = RKRoute(with: MessageSendResponse.self, pathPattern: Constants.ServiceConstants.kUrlPostMessage, method: RKRequestMethod.POST)
        objectManager.router.routeSet.add(postMessageRoute)
        
        // route class to delete message thread
        let deleteMessageThreadRoute: RKRoute = RKRoute(with: MessageDeleteResponse.self, pathPattern: Constants.ServiceConstants.kUrlThreadMessages, method: RKRequestMethod.DELETE)
        objectManager.router.routeSet.add(deleteMessageThreadRoute)
        
        let getFriendsListRoute: RKRoute = RKRoute(with: GetFriendsResponse.self, pathPattern: Constants.ServiceConstants.getFriendsUrl, method: RKRequestMethod.GET)
        objectManager.router.routeSet.add(getFriendsListRoute)
        
        let changePasswordRoute: RKRoute = RKRoute(with: ChangePasswordResponse.self, pathPattern: Constants.ServiceConstants.changePasswordUrl, method: RKRequestMethod.POST)
        objectManager.router.routeSet.add(changePasswordRoute)
        
        let userSettingsRoute: RKRoute = RKRoute(with: GetUserSettingResponse.self, pathPattern: Constants.ServiceConstants.userSettingsUrl, method: RKRequestMethod.GET)
        objectManager.router.routeSet.add(userSettingsRoute)
        
        //user profile response
        let userGetUserProfileRoute: RKRoute = RKRoute(with: UserProfileresponse.self, pathPattern: Constants.ServiceConstants.kUrlGetUserDetailResponse, method: RKRequestMethod.GET)
        objectManager.router.routeSet.add(userGetUserProfileRoute)
        
        let UnfriendRequestRoute: RKRoute = RKRoute(with: UnfriendResponse.self, pathPattern: Constants.ServiceConstants.UnFriendUrl, method: RKRequestMethod.DELETE)
        objectManager.router.routeSet.add(UnfriendRequestRoute)
        
        
        let updateUserSettingsRoute: RKRoute = RKRoute(with: UpdateUserSettingsResponse.self, pathPattern: Constants.ServiceConstants.userSettingsUrl, method: RKRequestMethod.POST)
        objectManager.router.routeSet.add(updateUserSettingsRoute)
        
        let friendRequestRoute: RKRoute = RKRoute(with: FriendsRequestResponse.self, pathPattern: Constants.ServiceConstants.sendFriendRequestUrl, method: RKRequestMethod.PUT)
        objectManager.router.routeSet.add(friendRequestRoute)
        
        
        let UpdateUserRoute: RKRoute = RKRoute(with: UpdateUserResponse.self, pathPattern: Constants.ServiceConstants.userUpdateInfoUrl, method: RKRequestMethod.POST)
        objectManager.router.routeSet.add(UpdateUserRoute)
        
        let ChangeProfilePicRoute: RKRoute = RKRoute(with: ProfilePicResponse.self, pathPattern: Constants.ServiceConstants.ChangeProfilePicUrl, method: RKRequestMethod.POST)
        objectManager.router.routeSet.add(ChangeProfilePicRoute)
        
        // route class to delete exercise
        let deleteExerciseRoute: RKRoute = RKRoute(with: ExerciseDeleteResponse.self, pathPattern: Constants.ServiceConstants.kUrlExercise, method: RKRequestMethod.DELETE)
        objectManager.router.routeSet.add(deleteExerciseRoute)
        
        // route class to delete food
        let deleteFoodLogRoute: RKRoute = RKRoute(with: DeletFoodLogResponse.self, pathPattern: Constants.ServiceConstants.kUrlFood, method: RKRequestMethod.DELETE)
        objectManager.router.routeSet.add(deleteFoodLogRoute)
        
        // route class to chnage status of shared food
        let changeSharedFoodLogRoute: RKRoute = RKRoute(with: ChangeShareStatusFoodLogResponse.self, pathPattern: Constants.ServiceConstants.kUrlFood, method: RKRequestMethod.PATCH)
        objectManager.router.routeSet.add(changeSharedFoodLogRoute)
        
        // route class to update exercise
        let updateExerciseRoute: RKRoute = RKRoute(with: ExerciseUpdateResponse.self, pathPattern: Constants.ServiceConstants.kUrlExercise, method: RKRequestMethod.PATCH)
        objectManager.router.routeSet.add(updateExerciseRoute)
        
        // food list
        objectManager.addResponseDescriptor(FoodListResponse.responseDescriptor)
        
        // get food details from barcode
        let foodDetailRoute = RKRoute(with: FoodDetailResponse.self, pathPattern: Constants.ServiceConstants.kFoodDetailUrl, method: RKRequestMethod.GET)
        objectManager.router.routeSet.add(foodDetailRoute)
        objectManager.addResponseDescriptor(FoodDetailResponse.responseDescriptor)
        
        // log food
        objectManager.addResponseDescriptor(LogFoodResponse.responseDescriptor)
        
        // news feed
        let newsFeedRoute = RKRoute(with: NewsFeedResponse.self, pathPattern: Constants.ServiceConstants.kNewsFeedUrl, method: RKRequestMethod.GET)
        objectManager.router.routeSet.add(newsFeedRoute)
        objectManager.addResponseDescriptor(NewsFeedResponse.responseDescriptor)
        
        // news feed for a particular user
        let newsFeedsParticularUserRoute = RKRoute(with: FeedsParticularUserResponse.self, pathPattern: Constants.ServiceConstants.kNewsFeedParticularUserUrl, method: RKRequestMethod.GET)
        objectManager.router.routeSet.add(newsFeedsParticularUserRoute)
        objectManager.addResponseDescriptor(FeedsParticularUserResponse.responseDescriptorFeedsParticularUser)
        
        // news feed comments
        let newsFeedCommentsRoute = RKRoute(with: NewsFeedCommentsResponse.self, pathPattern: Constants.ServiceConstants.kNewsFeedCommentsUrl, method: RKRequestMethod.GET)
        objectManager.router.routeSet.add(newsFeedCommentsRoute)
        objectManager.addResponseDescriptor(NewsFeedCommentsResponse.responseDescriptor)
        
        // create news feed
        let createNewsFeedRoute = RKRoute(with: CreateNewsFeedResponse.self, pathPattern: Constants.ServiceConstants.kNewsFeedUrl, method: RKRequestMethod.POST)
        objectManager.router.routeSet.add(createNewsFeedRoute)
        objectManager.addResponseDescriptor(CreateNewsFeedResponse.responseDescriptor)
        
        // meal types
        objectManager.addResponseDescriptor(MealTypeListResponse.responseDescriptor)
        objectManager.addResponseDescriptor(MealTypeCreateResponse.responseDescriptor)
        
        let followingFollowerUsersRoute: RKRoute = RKRoute(with: GetFollowingFollowerUserResponse.self, pathPattern: Constants.ServiceConstants.followingfollowerUrl, method: RKRequestMethod.GET)
        objectManager.router.routeSet.add(followingFollowerUsersRoute)
        
        
        // motivate-like/inspire
        objectManager.addResponseDescriptor(MotivateResponse.responseDescriptor)
        
        let motivateUsersRoute: RKRoute = RKRoute(with: MotivateResponse.self, pathPattern: Constants.ServiceConstants.motivateUrl, method: RKRequestMethod.POST)
        objectManager.router.routeSet.add(motivateUsersRoute)
        
        let manageGoalsUpdateRoute: RKRoute = RKRoute(with: ManageGoalsUpdateUserResponse.self, pathPattern: Constants.ServiceConstants.kManageGoalsUpdateUrl, method: RKRequestMethod.PUT)
        objectManager.router.routeSet.add(manageGoalsUpdateRoute)
        
        // follow user
        objectManager.addResponseDescriptor(FollowUserResponse.userResponseDescriptor)
        let followRoute: RKRoute = RKRoute(with: FollowUserResponse.self, pathPattern: Constants.ServiceConstants.kFollowUrl, method: RKRequestMethod.POST)
        objectManager.router.routeSet.add(followRoute)
        
        //unfollow user
        objectManager.addResponseDescriptor(UnfollowUserResponse.userResponseDescriptor)
        let unFollowRoute: RKRoute = RKRoute(with: UnfollowUserResponse.self, pathPattern: Constants.ServiceConstants.kFollowUrl, method: RKRequestMethod.DELETE)
        objectManager.router.routeSet.add(unFollowRoute)
        
        let hashTagGetResponse: RKRoute = RKRoute(with: HashTagGetResponse.self, pathPattern: Constants.ServiceConstants.kHashTagUrl, method: RKRequestMethod.GET)
        objectManager.router.routeSet.add(hashTagGetResponse)
        
        // route class to delete news feed comment
        let newsFeedCommentsDeleteResponse: RKRoute = RKRoute(with: NewsFeedCommentsDeleteResponse.self, pathPattern: Constants.ServiceConstants.kNewsFeedCommentDeleteUrl, method: RKRequestMethod.DELETE)
        objectManager.router.routeSet.add(newsFeedCommentsDeleteResponse)
        
        // route class to delete news feed
        let newsFeedDeleteResponse: RKRoute = RKRoute(with: NewsFeedDeleteResponse.self, pathPattern: Constants.ServiceConstants.kNewsFeedDeleteUrl, method: RKRequestMethod.DELETE)
        objectManager.router.routeSet.add(newsFeedDeleteResponse)
        objectManager.addResponseDescriptor(NewsFeedDeleteResponse.responseDescriptor)
        
        // route class to delete daily meal plan
        let dailyMealPlanDeleteResponse: RKRoute = RKRoute(with: DailyMealPlanDeleteResponse.self, pathPattern: Constants.ServiceConstants.kDailyMealPlanDeleteUrl, method: RKRequestMethod.DELETE)
        objectManager.router.routeSet.add(dailyMealPlanDeleteResponse)
        
        // create meal
        objectManager.addResponseDescriptor(CreateMealPostResponse.responseDescriptor)
        
        objectManager.addResponseDescriptor(FacebookUserLogInResponse.responseDescriptor)
        // ads
        objectManager.addResponseDescriptor(AdsResponse.userResponseDescriptor)
        //daily meal plan auto suggest
        objectManager.addResponseDescriptor(DailyMealPlanAutoSuggestResponse.responseDescriptor)
        //daily meal plan refresh
        objectManager.addResponseDescriptor(DailyMealPlanItemRefreshResponse.responseDescriptor)
        //add daily meal plan create
        objectManager.addResponseDescriptor(DailyMealPlanCreateResponse.responseDescriptor)
        
        //daily meal plan list
        objectManager.addResponseDescriptor(DailyMealPlanListResponse.responseDescriptor)
        
        //daily meal plan detail response
        let dailyMealPlanItemDetailResponse: RKRoute = RKRoute(with: DailyMealPlanItemDetailResponse.self, pathPattern: Constants.ServiceConstants.kDailyMealPlanDetailUrl, method: RKRequestMethod.GET)
        objectManager.router.routeSet.add(dailyMealPlanItemDetailResponse)
        objectManager.addResponseDescriptor(DailyMealPlanItemDetailResponse.responseDescriptor)
        
        //daily meal plan fooditem delete
        let dailyMealPlanFoodItemDeleteResponse: RKRoute = RKRoute(with: DailyMealPlanFoodItemDeleteResponse.self, pathPattern: Constants.ServiceConstants.kDailyMealPlanFoodItemDeleteUrl, method: RKRequestMethod.DELETE)
        objectManager.router.routeSet.add(dailyMealPlanFoodItemDeleteResponse)
        objectManager.addResponseDescriptor(DailyMealPlanFoodItemDeleteResponse.responseDescriptor)
        

        
        
        //daily meal plan share with friends
        objectManager.addResponseDescriptor(DailyMealPlanShare.responseDescriptor)

        // daily meal plan update 
        let dailyMealPlanUpdateResponse: RKRoute = RKRoute(with: DailyMealPlanUpdateResponse.self, pathPattern: Constants.ServiceConstants.kDailyMealPlanUpdate, method: RKRequestMethod.PUT)
        objectManager.router.routeSet.add(dailyMealPlanUpdateResponse)
        objectManager.addResponseDescriptor(DailyMealPlanUpdateResponse.responseDescriptor)

        
    }
   
    class func setupRestkit() {
        
        let modelPath = Bundle.main.path(forResource: "FymModel", ofType: "momd")
        let url = URL(fileURLWithPath: modelPath!)
        
        let managedObjectModel = NSManagedObjectModel(contentsOf: url)
        
        let managedObjectStore = RKManagedObjectStore(managedObjectModel: managedObjectModel)
        
        var error: NSError?
        
        let options = [NSMigratePersistentStoresAutomaticallyOption : true, NSInferMappingModelAutomaticallyOption : true]
        
        let success = RKEnsureDirectoryExistsAtPath(RKApplicationDataDirectory(), &error)
        
        if !success {
            //print("Failed to create Application Data Directory at path \(RKApplicationDataDirectory())")
        }
        
//        let path = NSURL(fileURLWithPath:RKApplicationDataDirectory()).URLByAppendingPathComponent("FymModel.sqlite")
        
     
        let path = (RKApplicationDataDirectory() as NSString).appendingPathComponent("FymModel.sqlite")
        
        //print("Path-------------------------------:: \(path)")
        
        do {
            try managedObjectStore?.addSQLitePersistentStore(atPath: path, fromSeedDatabaseAtPath: nil, withConfiguration: nil, options: options)

        }
        catch {
            
        }
            
        
        //        if persistentStore == nil {
        //            //print("Failed adding persistent store at path \(path)")
        //        }
        
        managedObjectStore?.createManagedObjectContexts()
        
        // manage cache to prevent creation of duplicates
        
        // create an OAuthClient
        let baseURL = URL(string: Constants.ServiceConstants.BaseUrlString)
        
        let oauthClient = AFOAuth2Client(baseURL: baseURL)
        oauthClient?.setDefaultHeader("Content-Type", value:"application/json")
        oauthClient?.setDefaultHeader("Accept", value:"application/json")
        oauthClient?.setAuthorizationHeaderWithUsername(Constants.ServiceConstants.oAuthUserName, password: Constants.ServiceConstants.oAuthPassword)
        
        //create an Object manager with aouthclient as HTTP client
        let objectManager = RestKitManager(httpClient: oauthClient)
        objectManager?.managedObjectStore = managedObjectStore
        
        RestKitManager.setShared(objectManager)
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.managedObjectContext = RKManagedObjectStore.default().persistentStoreManagedObjectContext
        
        RestKitManager.initLogging()
        #if !(TARGET_OS_EMBEDDED)  // This will work for Mac or Simulator but excludes physical iOS devices
            #if DEBUG
                // @(1) is NSSQLiteStoreType
                createCoreDataDebugProjectWithType(1, storeURL: persistentStore!.URL!.absoluteString!, modelFilePath: modelUrl.absoluteString!)
            #endif
        #endif
    }
    
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    class func setToken(_ flag: Bool) {
        
        var accessToken = ""
        let userDefaults = UserDefaults.standard
        
        if userDefaults.object(forKey: "session") != nil {
            
            accessToken = userDefaults.object(forKey: "accesstoken") as! String
            
            //get the accesstoken set date from the userdefaults
            let accessTokenSetDate = userDefaults.value(forKey: "accesstoken_setdate") as! Date
            
            let tokenExpirationTime = userDefaults.object(forKey: "expiresin") as! String
            
            //check the time interval since the accesstoken is set in seconds
            let seconds = Date().timeIntervalSince(accessTokenSetDate)
            
            let accesstoken : String? = (flag) ? accessToken: ""
            RestKitManager.shared().httpClient.setDefaultHeader("Authorization", value:"Bearer "+accesstoken!)
            
            //check whether the accesstoken exceeded the expiration time
            if seconds >= tokenExpirationTime.doubleValue - 1000  && AppConfiguration.sharedAppConfiguration.refreshingToken == false {
                
                AppConfiguration.sharedAppConfiguration.refreshingToken = true
                
                AppConfiguration.refreshAccessTokenDetails { (accessCredential) -> () in
                    
                    AppConfiguration.sharedAppConfiguration.refreshingToken = false
                    if accessCredential == nil {
                        UIAlertView(title: "Log out!", message: "Triggered logout", delegate: self, cancelButtonTitle: &&"OK").show()
                        return
                    }
                    
                    accessToken = accessCredential!.accessToken!
                    let accesstoken : String? = (flag) ? accessToken: ""
                    RestKitManager.shared().httpClient.setDefaultHeader("Authorization", value:"Bearer "+accesstoken!)
                    
                }
                return
            }
            
            //print("date ---\(accessTokenSetDate)")
            
        }
        //        var accesstoken : String? = (flag) ? accessToken: ""
        //        RestKitManager.sharedManager().HTTPClient.setDefaultHeader("Authorization", value:"Bearer "+accesstoken!)
        
    }
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        
        if alertView.title == "Log out!" {
            if buttonIndex == 0 {
                //found the token expired and user is redirected to the login page
                AppConfiguration.refreshAccessTokenDetails { (accessCredential) -> () in
                    
                }
                //                appDelegate?.loadLogin()
            }
        }
    }
    
    class func setupBasicAuth() {
        
        // create an OAuthClient
        let baseURL = URL(string: Constants.ServiceConstants.BaseUrlString)
        
        let oauthClient = AFOAuth2Client(baseURL: baseURL)
        oauthClient?.setDefaultHeader("Content-Type", value:"application/json")
        oauthClient?.setDefaultHeader("Accept", value:"application/json")
        oauthClient?.setAuthorizationHeaderWithUsername(Constants.ServiceConstants.oAuthUserName, password: Constants.ServiceConstants.oAuthPassword)
        
        RestKitManager.shared().httpClient = oauthClient
        
        //print("Headers are \(RestKitManager.sharedManager().HTTPClient.defaultHeaders)")
    }
    
}


#if !(TARGET_OS_EMBEDDED)
    func createCoreDataDebugProjectWithType(_ storeFormat: NSNumber, storeURL: String, modelFilePath: String) {
        
        let project: NSDictionary = [
            "storeFilePath": storeURL,
            "storeFormat" : storeFormat,
            "modelFilePath": modelFilePath,
            "v" : "1"
        ]
        
        let projectFile = "/tmp/\(Bundle.main.infoDictionary![kCFBundleNameKey as String]!).cdp"
        project.write(toFile: projectFile, atomically: true)
    }
    
#endif
