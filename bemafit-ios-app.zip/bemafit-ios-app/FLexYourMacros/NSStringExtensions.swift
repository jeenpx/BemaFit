//
//  NSString.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 27/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

// MARK: Localization
prefix operator &&

prefix func && (string: String) -> String {
    return NSLocalizedString(string, comment: "")
}

// MARK: Filtering
extension String {
    
    func filterWordsWithPrefix(_ prefix: String, shouldStripPrefix: Bool) -> [String] {
        
        // the regular expression to filter out words
        let regularExpression = try! NSRegularExpression(pattern: "\(prefix)(\\w+)", options: .caseInsensitive)
        
        // filter out results using the regular expression
        let arrayMatches = regularExpression.matches(in: self, options: .withTransparentBounds, range: NSMakeRange(0, self.characters.count))
        
        // return words from results
        return arrayMatches.map() {
            (self as NSString).substring(with: $0.rangeAt(shouldStripPrefix ? 1 : 0))
        }
    }
    
    func filterHashTags() -> [String] {
        return filterWordsWithPrefix("#", shouldStripPrefix: false)
    }
    
    func contains(_ find: String) -> Bool {
        return self.range(of: find, options: NSString.CompareOptions.caseInsensitive) != nil
    }
    
    func trimmedString() -> String {
        
        // trim white spaces and new lines
        var trimmedText = trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        
        // remove new lines throughout the text
        trimmedText = trimmedText.replacingOccurrences(of: "\n", with: "")
        
        return trimmedText
    }
    
    var isEmpty: Bool {
        return self.trimmedString().characters.count <= 0
    }
    
}

//MARK: Email
extension String{
    func isValidEmail() -> Bool {
        // //println("validate calendar: \(testStr)")
        let emailRegEx = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: self)
    }
    
}

// MARK: Date
extension String {
    
    // dateFormat has precedence over dateStyle
    // date style defaults to LongStyle
    func dateValue(_ dateFormat: String? = nil, dateStyle: DateFormatter.Style? = nil) -> Date? {
        
        // get a date formatter
        let dateFormatter = DateFormatter()
        
        // set appropriate date styles/formats
        if let dateFormat = dateFormat {
            dateFormatter.dateFormat = dateFormat
        }
        else if let dateStyle = dateStyle {
            dateFormatter.dateStyle = dateStyle
        }
        else {
            dateFormatter.dateStyle = DateFormatter.Style.long
        }
        
        // return the date after formatting
        return dateFormatter.date(from: self)
    }
    
    func utcDateValue(_ dateFormat: String? = nil, dateStyle: DateFormatter.Style? = nil) -> Date? {
        
        // get a date formatter
        let dateFormatter = DateFormatter()
        
        // set appropriate date styles/formats
        if let dateFormat = dateFormat {
            dateFormatter.dateFormat = dateFormat
        }
        else if let dateStyle = dateStyle {
            dateFormatter.dateStyle = dateStyle
        }
        else {
            dateFormatter.dateStyle = DateFormatter.Style.long
        }
        
        // set gmt 0
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        
        // return the date after formatting
        return dateFormatter.date(from: self)
    }
    
    func  websiteString() ->  (valid: Bool, urlString: String){
        
        var isValid = false //urlTestWithPrefix.evaluateWithObject(self)
        var urlString = self
        
        
        if self.lowercased().range(of: "https://") == nil {
            
            urlString = (self.lowercased().range(of: "http://") == nil) ? "http://"+self : self
        }
        
        
        let urlRegEx = "^^(http|https)://((?!-)[A-Za-z0-9-]{1,63}(?<!-)\\.)+[A-Za-z]{2,6}$"
        let urlTest = NSPredicate(format: "SELF MATCHES %@",urlRegEx)
        isValid = urlTest.evaluate(with: urlString)
        
        return (isValid, urlString)
    }
    
}

extension String {
    
    var FloatValue: Double {
        
        return round(self.doubleValue * 100) / 100
        //        return (self as NSString).floatValue
        //        return round ((self as NSString).floatValue * 100.0) / 100.0
    }
    
    var intValue: Int {
        return (self as NSString).integerValue
    }
    
    var doubleValue: Double {
        return (self as NSString).doubleValue
    }
    
    var singleDecimalValue: String {
        return NSString(format: "%.1f", (self as NSString).floatValue) as String
    }
    
}

// dynamic height
extension String {
    
    func expectedHeight(_ width: Double, font: UIFont) -> Double {
        return Double((self as NSString).boundingRect(with: CGSize(width: CGFloat(width), height: 9999.0), options: .usesLineFragmentOrigin, attributes: [NSFontAttributeName: font], context: nil).height)
    }
    
    func expectedNumberOfLines(_ width: Double, font: UIFont) -> Int {
        
        //print("lien \(font.lineHeight)")
        return Int(expectedHeight(width, font: font) / Double(font.lineHeight))
    }
    
}

// truncate string
extension String {
    /// Truncates the string to length number of characters and
    /// appends optional trailing string if longer
    func truncate(_ length: Int, trailing: String? = nil) -> String {
        if self.characters.count > length {
            return self.substring(to: self.characters.index(self.startIndex, offsetBy: length)) + (trailing ?? "")
        } else {
            return self
        }
    }
}

// Unique ID Generation
extension String{
    
    static func generateUniqueID (_ len : Int) -> NSString {
        
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        
        let randomString : NSMutableString = NSMutableString(capacity: len)
        
        for _ in 0..<len {
            let length = UInt32 (letters.length)
            let rand = arc4random_uniform(length)
            randomString.appendFormat("%C", letters.character(at: Int(rand)))
        }
        
        return randomString
    }
    
    
}

