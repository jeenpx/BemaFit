//
//  FriendRequestModel.swift
//  FlexYourMacros
//
//  Created by DBG on 07/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FriendRequestModel: NSObject {
    var status: String?
    
    class var objectMapping: RKObjectMapping {
        let friendRequestMapping = RKObjectMapping(for: FriendRequestModel.self)
        friendRequestMapping?.addAttributeMappings(from: mappingDictionary)
        return friendRequestMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["status":"status"])
    }
    
}
