//
//  DirectoryViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 3/23/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class DirectoryTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imageViewCompany: UIImageView!
    @IBOutlet weak var labelMilesAway: UILabel!
    @IBOutlet weak var labelCompanyName: UILabel!
    
    @IBOutlet weak var viewVerified: UIView!
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        configureCell()
    }
    
    var directory: DirectoryModel? {
        didSet {
            labelCompanyName.text = directory!.name
            if let distance = directory!.distance {
                labelMilesAway.text = distance == "" ? "" : distance + &&"miles_away"
            }
            if let images = directory!.images as [DirectoryImages]? {
                for image: DirectoryImages in images {
                    //                    imageViewCompany.setImageWithURL(NSURL(string:  image.file!))
                    if let imageURL = image.file {
                        imageViewCompany.setImageWith(URL(string: imageURL), placeholderImage: UIImage(named: "PlaceHolderDirectory"))
                    }
                }
            }
            if let verified = directory?.premiumListing {
                
                // hide verified view if premium listing is 0
                viewVerified.isHidden = verified == "0"
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func configureCell() {
        //        setSeparatorInsetZero()
    }
    
}

class DirectoryViewController: UIViewController, UISearchBarDelegate, UITableViewDragLoadDelegate, UITableViewDataSource, UITableViewDelegate,AKPickerViewDataSource, AKPickerViewDelegate {
    
    @IBOutlet weak var searchBarLocation: SearchBarLocation!
    @IBOutlet weak var tableViewDirectory: UITableView!
    @IBOutlet fileprivate weak var pickerViewHorizontalListItem: AKPickerView!
    
    var directoryList: [DirectoryModel]?
    var pickerBusinessCategory = [BusinessCategoryModel]()
    
    @IBOutlet weak var viewVerified: UIView!
    
    // offset value for friends list
    var offset = 0
    
    // limit value for friends list
    var limit = 10
    
    var stringLocation = ""
    
    var pickerType = ""
    
    // temporary variable to store offset
    var tempOffset = 0
    
    var latitude: Double = 0
    
    var longitude: Double = 0
    
    // hold gps location
    var gpsLocation = ""
    
    // temporary array to store friends
    var arrayTempdirectoryList: [DirectoryModel]?
    
    struct StoryBoard {
        struct Segue {
            static let SegueDirectoryDetails = "kSegueDirectoryDetails"
        }
    }
    
    struct DirectoryConstants {
        
        // empty records
        static let emptyMessage = &&"empty_tableview_message"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // hide empty tableview cells
        tableViewDirectory.tableFooterView = UIView()
        
        // bsiness types
        if let businessCategory =  AppConfiguration.sharedAppConfiguration.businessCategories {
            pickerBusinessCategory = businessCategory
            pickerType = pickerBusinessCategory[0].name!
        }
        
        // set delegate for search bar
        searchBarLocation.searchBarLocationDelegate = self
        
        configureView()
        
        // configure the table view directory
        configureTableViewDirectory()
        
        GeolocationServiceUpdater.isGeoLocationSettingsEnabled { (result : Bool, type :  GeoLocationDiabledType) -> Void in
            
            switch(type){
            case GeoLocationDiabledType.DISABLED_IN_PHONE_SETTINGS,GeoLocationDiabledType.DISABLED_LOCATION_SERVICE:
                
                self.showAlert(&&"notice", message: &&"enable_location_service_message")
                // show empty record message
                self.tableViewDirectory.showEmptyTableViewMessage(DirectoryConstants.emptyMessage)
                
            default:
                let location = GeolocationServiceUpdater.getLastKnowLocation() as CLLocation
                self.latitude = location.coordinate.latitude
                self.longitude = location.coordinate.longitude
                
                let reachability = self.appDelegate!.internetReachable
                if !reachability {
                    // no internet
                    
                    // alert
                    AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                    // show empty record message
                    self.tableViewDirectory.showEmptyTableViewMessage(DirectoryConstants.emptyMessage)
                    return
                }
                
                self.listDirectory(self.offset, andLimit: self.limit, andLocation: self.stringLocation, andType: self.pickerType, andLatitude: self.latitude, andLongitude: self.longitude, andProgressHUD: true, doLoadMore: false)
                break
            }
        }
    }
    
    func configureTableViewDirectory() {
        
        // set delegate for pull to refresh and load more
        tableViewDirectory.setDragDelegate(self, refreshDatePermanentKey: "kDirectory")
        
        // hide pull to refresh
        tableViewDirectory.showRefreshView = false
        
        // show load more
        tableViewDirectory.showLoadMoreView = true
        
        // tableview footer release text
        tableViewDirectory.footerReleaseText = NSLocalizedString("release_to_load_more_status", comment: "")
        
        // tableview footer pull up text
        tableViewDirectory.footerPullUpText = NSLocalizedString("pull_down_to_load_more_status", comment: "")
        
        //tableview footer loading text
        tableViewDirectory.footerLoadingText = NSLocalizedString("loading_status", comment: "")
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let count = self.directoryList?.count {
            if count == 0 {
                // show empty record message
                
                tableViewDirectory.showEmptyTableViewMessage(DirectoryConstants.emptyMessage)
            }
            else {
                tableViewDirectory.backgroundView = UIView()
                tableViewDirectory.separatorStyle = .singleLine
            }
            
            return count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let directoryTableViewCell = tableView.dequeueReusableCell(withIdentifier: "kDirectoryCell", for: indexPath) as! DirectoryTableViewCell
        if let directoryModel: DirectoryModel  = self.directoryList?[indexPath.row] {
            
            // save the directory
            directoryTableViewCell.directory = directoryModel
        }
        return directoryTableViewCell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func dragTableDidTriggerLoadMore(_ tableView: UITableView!) {
        // called when the load more is selected
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            
            // finish the load more
            Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(DirectoryViewController.finishLoadMore), userInfo: nil, repeats: false)
            return
        }

        // don't call api
        if latitude == 0 && longitude == 0 && stringLocation == "" {
            offset = 0
            // directory array set to empty
            directoryList?.removeAll()
            Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(DirectoryViewController.finishLoadMore), userInfo: nil, repeats: false)
            return
        }
        
        if let count = self.directoryList?.count {
            // save directory count to offset
            
            offset = count
        }
        else {
            // set offset to zero
            
            offset = 0
        }
        
        listDirectory(offset, andLimit: limit, andLocation: stringLocation, andType: pickerType, andLatitude: self.latitude, andLongitude: self.longitude, andProgressHUD: false, doLoadMore: true)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let directoryListItem = directoryList?[indexPath.row]
        performSegue(withIdentifier: StoryBoard.Segue.SegueDirectoryDetails, sender: directoryListItem)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == StoryBoard.Segue.SegueDirectoryDetails {
            let directoryDetailViewController = segue.destination as! DirectoryDetailViewController
            if let directoryDetail = sender as? DirectoryModel {
                //print("directoryDetail:\(directoryDetail.directoryDescription)")
                directoryDetailViewController.businessDirectory = directoryDetail
            }
        }
    }
    
    func dragTableLoadMoreCanceled(_ tableView: UITableView!) {
        // called when the load more is cancelled
        
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(DirectoryViewController.finishLoadMore), object: nil)
    }
    
    func finishLoadMore() {
        // to stop the load more and populate the tableview with new items
        
        tableViewDirectory.finishLoadMore()
        tableViewDirectory.reloadData()
    }
    
    func searchBarBookmarkButtonClicked(_ searchBar: UISearchBar) {
        
        
        GeolocationServiceUpdater.isGeoLocationSettingsEnabled { (result: Bool, type : GeoLocationDiabledType) -> Void in
            
            
            switch(type)
            {
            case GeoLocationDiabledType.DISABLED_IN_PHONE_SETTINGS,GeoLocationDiabledType.DISABLED_LOCATION_SERVICE:
                self.showAlert(&&"notice", message: &&"enable_location_service_message")            default:
                    GeolocationServiceUpdater.startScaningForLocationChange()
                    SVProgressHUD.show()
                    GeolocationServiceUpdater.getLastKnownLocationName({ (location, locationName, placemark, error) in
                        
                        if error==nil {
                            
                            searchBar.text = locationName
                            self.gpsLocation = locationName!
                            self.latitude = (location?.coordinate.latitude)!
                            self.longitude = (location?.coordinate.longitude)!
                        }
                        else{
                            self.showAlert(&&"notice", message: &&"failed_to_load_location_details")
                        }
                        SVProgressHUD.dismiss()
                    })
//                    GeolocationServiceUpdater.getLastKnownLocationName({ (location : CLLocation!, locationName : String!, placemark: CLPlacemark!, error : NSError!) -> Void in
//                        
//                        if error==nil {
//                            
//                            searchBar.text = locationName
//                            self.gpsLocation = locationName
//                            self.latitude = location.coordinate.latitude
//                            self.longitude = location.coordinate.longitude
//                        }
//                        else{
//                            self.showAlert(&&"notice", message: &&"failed_to_load_location_details")
//                        }
//                        SVProgressHUD.dismiss()
//                    })
                break
            }
        }
    }
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        // called when search button of search bar is clicked
        
        searchBar.setShowsCancelButton(false, animated: true)
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            searchBar.resignFirstResponder()
            return
        }
        
        // if gps location then lat and long used instead of search text
        stringLocation = searchBar.text! == gpsLocation ? "" : searchBar.text!
        
        // store offset to tempoary offset variable
        tempOffset = offset
        
        // store directory to tempoary directory array
        arrayTempdirectoryList = directoryList
        
        // set offset 0
        offset = 0
        
        // directory array set to empty
        directoryList?.removeAll()
        
        listDirectory(offset, andLimit: limit, andLocation: stringLocation, andType: pickerType, andLatitude: self.latitude, andLongitude: self.longitude, andProgressHUD: true, doLoadMore: false)
        
        searchBar.resignFirstResponder()
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if(searchText.isEmpty) {
            
            // show previous data
            // searchBarTextEmpty()
            
            // set location empty
            stringLocation = ""
        }
    }
    
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
        searchBar.setShowsCancelButton(true, animated: true)
        return true
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        //searchBar.text.removeAll(keepCapacity: true)
        searchBar.text?.removeAll()
        searchBar.setShowsCancelButton(false, animated: true)
        searchBar.resignFirstResponder()
        
        // show previous data
        // searchBarTextEmpty()
        
        // set location empty
        stringLocation = ""
        
        // directory array set to empty
        directoryList?.removeAll()
        
        //set oofset zero
        offset = 0
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            tableViewDirectory.reloadData()
            return
        }

        
        listDirectory(offset, andLimit: limit, andLocation: stringLocation, andType: pickerType, andLatitude: self.latitude, andLongitude: self.longitude, andProgressHUD: false, doLoadMore: false)
    }
    
//    func searchBarTextEmpty() {
//        
//        // set location empty
//        stringLocation = ""
//        
//        if (arrayTempdirectoryList != nil) {
//            
//            // store temporary offset value back to offset variable
//            offset = tempOffset
//            
//            // store temporary array directory value back to directory array
//            directoryList = arrayTempdirectoryList
//            
//            // to reload tableview data
//            tableViewDirectory.reloadData()
//        }
//    }
    
    
    
    @IBAction func unwindToDirectoryViewController(_ segue: UIStoryboardSegue) {
        
    }
    
    
    func configureView() {
        
        // horizontal picker for data
        pickerViewHorizontalListItem.delegate = self
        pickerViewHorizontalListItem.dataSource = self
        pickerViewHorizontalListItem.font = UIFont.helveticaBold()
        pickerViewHorizontalListItem.highlightedFont = UIFont.helveticaBold()
        pickerViewHorizontalListItem.interitemSpacing = 30
        pickerViewHorizontalListItem.viewDepth = 1000.0
        pickerViewHorizontalListItem.pickerViewStyle = .flat
        pickerViewHorizontalListItem.maskDisabled = true
        pickerViewHorizontalListItem.reloadData()
        
    }
    
    func numberOfItemsInPickerView(_ pickerView: AKPickerView) -> Int {
        return pickerBusinessCategory.count
    }
    
    func pickerView(_ pickerView: AKPickerView, titleForItem item: Int) -> String {
        //return titles[item]
        return pickerBusinessCategory[item].name!
    }
    
    func pickerView(_ pickerView: AKPickerView, didSelectItem item: Int) {
        
        // directory array set to empty
        directoryList?.removeAll()
        
        //set oofset zero
        offset = 0
        
        // set location empty
        // stringLocation = ""
        
        pickerType = pickerBusinessCategory[item].name!
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            tableViewDirectory.reloadData()
            return
        }
        
        listDirectory(offset, andLimit: limit, andLocation: stringLocation, andType: pickerType, andLatitude: self.latitude, andLongitude: self.longitude, andProgressHUD: true, doLoadMore: false)
    }
    
    func pickerView(_ pickerView: AKPickerView, configureLabel label: UILabel, forItem item: Int) {
        label.textColor = UIColor.pickerGrayColor()
        label.highlightedTextColor = UIColor.defaultThemeBlueColor()
    }
    
    func listDirectory(_ offset: Int, andLimit limit: Int, andLocation location: String, andType type: String, andLatitude latitude: Double, andLongitude longitude: Double, andProgressHUD showProgressHUD: Bool, doLoadMore loadMore: Bool) {
        
        var lat: Double = 0
        var long: Double = 0
        let geoLocation = GeolocationServiceUpdater.getLastKnowLocation() as CLLocation
        
        // if gps enabled store the current lat and long else store 0 value
        lat = geoLocation.coordinate.latitude
        long = geoLocation.coordinate.longitude
        
        DirectoryGetResponse.getDirectory(offset, andLimit: limit, andLocation: location, andType: type, andLatitude: lat, andLongitude: long, andProgressHUD: showProgressHUD) { (directoryGetResponse,status) -> () in
            
            if status == "failure" {
                // directory array set to empty
                self.directoryList?.removeAll()
                
                //set oofset zero
                self.offset = 0
                
                // show empty record message
                self.tableViewDirectory.showEmptyTableViewMessage(DirectoryConstants.emptyMessage)
                
                // reload the tableview
                self.tableViewDirectory.reloadData()
                
                return
            }
            
            
            if self.directoryList?.isEmpty == false {
                // append new values to existing array
                
                if let directories: [DirectoryModel] = directoryGetResponse.business {
                    for directory in directories {
                        self.directoryList?.append(directory)
                    }
                }
            }
            else {
                // empty array
                
                self.directoryList = directoryGetResponse.business
            }
            
            if loadMore {
                
                // finish the load more
                self.finishLoadMore()
            }
            
            // reload the tableview
            self.tableViewDirectory.reloadData()
        }
    }
    
    func showAlert(_ title: String, message: String) {
        // show alert controller if possible else show alert view
        UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"OK").show()
        
    }
    
}

