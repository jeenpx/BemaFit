//
//  DailyMealPlanSelectNutritionViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 11/19/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class SelectNutritionPlanCell: UITableViewCell {
    
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelDescription: UILabel!
    
    var nutritionPlan: NutritionPlanModel? {
        didSet {
            labelTitle.text = nutritionPlan?.nutritionName
            labelDescription.text = nutritionPlan?.nutritionDescription
        }
    }
    
    var isNutritionSelected = false {
        didSet {
            accessoryType = isNutritionSelected ? .checkmark : .none
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}

class DailyMealPlanSelectNutritionViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    struct StoryBoard {
        struct CellIdentifiers {
            static let SelectNutritionPlanCellIdentifier = "kSelectNutritionPlanCell"
        }
    }
    
    var nutritionPlans: [NutritionPlanModel]? {
        didSet {
            selectedNutritionPlan = nutritionPlans?.filter { $0.nutritionId == FymUser.sharedFymUser.userNutritionType }.first
        }
    }
    
    var selectedNutritionPlan: NutritionPlanModel? {
        didSet {
            FymUser.sharedFymUser.userNutritionType  = selectedNutritionPlan!.nutritionId!
            DailyMealPlan.sharedDailyMealPlan.nutrionalPlanId = selectedNutritionPlan!.nutritionId!.intValue
            //print(FymUser.sharedFymUser.userNutritionType)
        }
    }
    
    var offscreenCells = [String: SelectNutritionPlanCell]()
    
    @IBOutlet weak var tableViewSelectNutrition: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // save user Nutrition Type
        if FymUser.sharedFymUser.userNutritionType == "" {
            if let nutritionId = AppConfiguration.sharedAppConfiguration.userDiet?.dietNutritionalPlan {
                FymUser.sharedFymUser.userNutritionType = nutritionId
            }
        }
        
        // save nutrition plans
        nutritionPlans = AppConfiguration.sharedAppConfiguration.nutritionPlans
        configureTableView()
        
    }
    
    func configureTableView() {
        
        // hide empty tableview cells
        tableViewSelectNutrition.tableFooterView = UIView(frame: CGRect.zero)
        tableViewSelectNutrition.rowHeight = UITableViewAutomaticDimension
        tableViewSelectNutrition.estimatedRowHeight = 60
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let selectNutritionPlanCell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.SelectNutritionPlanCellIdentifier) as! SelectNutritionPlanCell
        
        selectNutritionPlanCell.nutritionPlan = nutritionPlans?[indexPath.row]
        selectNutritionPlanCell.isNutritionSelected = nutritionPlans?[indexPath.row] == selectedNutritionPlan
        
        selectNutritionPlanCell.setNeedsUpdateConstraints()
        selectNutritionPlanCell.updateConstraintsIfNeeded()

        return selectNutritionPlanCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedNutritionPlan = nutritionPlans?[indexPath.row]
        NotificationCenter.default.post(name: Notification.Name(rawValue: "RefreshNutritionPlan"), object: nil, userInfo: nil)

        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if FymUser.sharedFymUser.areAllNutritionPlansActive == true {
            return AppConfiguration.sharedAppConfiguration.nutritionPlans.count
        }
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var cell = offscreenCells[StoryBoard.CellIdentifiers.SelectNutritionPlanCellIdentifier]
        if cell == nil {
            cell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.SelectNutritionPlanCellIdentifier) as? SelectNutritionPlanCell
            offscreenCells[StoryBoard.CellIdentifiers.SelectNutritionPlanCellIdentifier] = cell
        }
        
        cell?.nutritionPlan = nutritionPlans?[indexPath.row]
        
        cell?.setNeedsUpdateConstraints()
        cell?.updateConstraintsIfNeeded()
        cell?.bounds = CGRect(x: 0.0, y: 0.0, width: tableViewSelectNutrition.bounds.width, height: cell!.bounds.height)
        
        cell?.setNeedsLayout()
        cell?.layoutIfNeeded()
        
        cell?.labelDescription.preferredMaxLayoutWidth = cell!.labelDescription.bounds.width
        cell?.labelDescription.setNeedsUpdateConstraints()
        
        // Get the actual height required for the cell's contentView
        var height = cell?.contentView.systemLayoutSizeFitting(UILayoutFittingCompressedSize).height
        
        // Add an extra point to the height to account for the cell separator, which is added between the bottom
        // of the cell's contentView and the bottom of the table view cell.
        height = height! + 1
        return height!
    }
}
