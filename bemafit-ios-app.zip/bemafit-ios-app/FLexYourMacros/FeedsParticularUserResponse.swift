//
//  FeedsParticularUserResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 09/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//
import UIKit

class FeedsParticularUserResponse: NSObject {
    
    var user_id = ""
    var metaModel = MetaModel()
    var newsFeeds = [NewsFeed]()
    var pageMetaModel = PageMetaModel()
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
        responseMapping?.addPropertyMapping(metaModelMapping)
        
        // newsfeeds mapping
        let newsFeedModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathNewsFeeds, toKeyPath: "newsFeeds", with: NewsFeed.objectMapping)
        responseMapping?.addPropertyMapping(newsFeedModelMapping)
        
        // page meta model mapping
        let pageMetaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathPageMeta, toKeyPath: "pageMetaModel", with: PageMetaModel.objectMapping)
        responseMapping?.addPropertyMapping(pageMetaModelMapping)
        
        return responseMapping!
    }
    
    
    // feeds for a particular user : Get feeds of a particular user.
    class var responseDescriptorFeedsParticularUser: RKResponseDescriptor {
        let newFeedsesponseDescriptor = RKResponseDescriptor(mapping: FeedsParticularUserResponse.responseMapping, method: .any, pathPattern: Constants.ServiceConstants.kNewsFeedParticularUserUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return newFeedsesponseDescriptor!
    }
    
    
    // Get feeds of a particular user.
    class func fetchNewsFeedsForParticularUser(_ userId:String, params: [String: String], completionHandler: @escaping (_ newsFeeds: [NewsFeed], _ pageMeta: PageMetaModel, _ error: NSError?) -> ()) {
        
        RestKitManager.setToken(true)
        
        let newsFeedResponse = FeedsParticularUserResponse()
        newsFeedResponse.user_id = userId
        
        RestKitManager.shared().getObject(newsFeedResponse, path: nil, parameters: params, success: { (operation, mappingResult) in
            
            // map to correct datamodel
            let response = mappingResult?.firstObject as! FeedsParticularUserResponse
            
            if response.metaModel.responseCode != 200 {
                let error = NSError(domain: "FYM.NewsFeed", code: 1001, userInfo: ["title": "error", "message": "alert_feed_list_message"])
                
                // fire completion handler
                completionHandler([], newsFeedResponse.pageMetaModel, error)
                
            }
            else {
                // fire completion handler
                completionHandler(response.newsFeeds, newsFeedResponse.pageMetaModel, nil)
            }
            
            }) { (operation, error) -> Void in
                // error
                let networkError = NSError(domain: "FYM.NewsFeed", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
                
                // fire completion handler
                completionHandler([], newsFeedResponse.pageMetaModel, networkError)
        }
    }
    
    
}
