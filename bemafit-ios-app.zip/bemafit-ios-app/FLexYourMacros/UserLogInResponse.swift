//
//  AccessTokenModel.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 09/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _UserLogInResponse = UserLogInResponse()

class UserLogInResponse: NSObject {
    
    var accessTokenModel: AccessTokenModel?
    var userDietModel: UserDietModel?
    var userDetailModel: UserDetailModel?
    var metaModel: MetaModel?
    
    class var sharedUserLogInResponse: UserLogInResponse {
        return _UserLogInResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(UserLogInResponse.metaModelKeyMapping)
        
        // give reference to accesstoken mapping
        responseMapping?.addPropertyMapping(UserLogInResponse.accessTokenModelKeyMapping)
        
        // give reference to diet mapping
        responseMapping?.addPropertyMapping(UserLogInResponse.userDietModelKeyMapping)
        
        // give reference to user credential mapping
        responseMapping?.addPropertyMapping(UserLogInResponse.userDetailModelKeyMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.logInUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var accessTokenModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathAccessToken, toKeyPath: "accessTokenModel", with: AccessTokenModel.objectMapping)
    }
    
    fileprivate class var userDietModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDiet, toKeyPath: "userDietModel", with: UserDietModel.objectMapping)
    }
    
    fileprivate class var userDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDetail, toKeyPath: "userDetailModel", with: UserDetailModel.objectMapping)
    }
    
    
    
    class func logInUser(_ viewController: UIViewController, username: String, password: String, completionHandler: @escaping (_ accessCredential: AccessTokenModel, _ userDiet: UserDietModel, _ userDetails: UserDetailModel) -> (), failedWithError: @escaping (_ error: String) -> ()) {
    
        // add loading indicator
        SVProgressHUD.show()

        RestKitManager.setupBasicAuth()
        
        var parameterDictionary: [String:String] {
            // save useremail and password for a session
            let userDefaults = UserDefaults.standard
            userDefaults.set(username, forKey: "username")
            userDefaults.set(password, forKey: "password")

            userDefaults.synchronize()
             
            // create the parameter dictionary
            return ["username":username, "password":password, "grant_type":"password"]
        }

        let userDefaults = UserDefaults.standard

        let deviceAccessToken = userDefaults.object(forKey: "token") as? String ?? ""
   
        RKObjectManager.shared().httpClient.setDefaultHeader("Device-Token", value: deviceAccessToken)
        // get the objects from the path login
        RKObjectManager.shared().post(nil, path: Constants.ServiceConstants.logInUrl, parameters: parameterDictionary, success: { (operation, mappingResult) in
            
            SVProgressHUD.dismiss()
            
            // get the user response
            let userLogInResonse = mappingResult?.firstObject as! UserLogInResponse
            
            // check for success
            if userLogInResonse.metaModel?.responseCode != 200 {
                
                var errorMessage = userLogInResonse.metaModel?.message ?? ""
                let errorMessages = userLogInResonse.metaModel?.errormessages
                if errorMessages!.isEmpty {
                    
                } else {
                    
                    errorMessage = errorMessages?.first?.fieldMessage ?? ""
                }
                failedWithError(errorMessage)
                return
            }
            
            // set up the completion handler with response
            completionHandler(userLogInResonse.accessTokenModel!, userLogInResonse.userDietModel!, userLogInResonse.userDetailModel!)
            
        //print("accessTokenModel in \(userLogInResonse.accessTokenModel?.accessToken)")
            
        }) { (operation, error) in
            
            // remove loading indicator
            SVProgressHUD.dismiss()
            var message = error?.localizedDescription
            if let errorDetail = (error as! NSError).localizedRecoverySuggestion
            {
                message = errorDetail;
                
                if let data: Data = errorDetail.data(using: String.Encoding.utf8) {
                
                var error: NSError?
                
                // convert NSData to 'Any'
                let json: Any?
                do {
                    json = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions(rawValue: 0))
                } catch var error1 as NSError {
                    error = error1
                    json = nil
                } catch {
                    fatalError()
                }
                if let errorMessage = (json! as? [String: Any])?["detail"] as? String  {
//                    //println("to json \(errorMessage)")
                    
                    message = errorMessage
                }
                }
                
                
            }
            
            failedWithError(message!)
            
        }
    }
    
    
}
