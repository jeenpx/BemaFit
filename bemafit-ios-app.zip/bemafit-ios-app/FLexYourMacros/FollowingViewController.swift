//
//  FollowingViewController.swift
//  FlexYourMacros
//
//  Created by DBG on 01/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol FollowingCellDelegate {
    func followFriend(_ followingcell: FollowingCell, user: UserDetailModel,status:Mode)
    func navigateToProfile( _ user: UserDetailModel)
    
}

// private, follow ,unfollow
enum Mode: String {
    case Private = "private"
    case Follow = "follow"
    case Unfollow = "unfollow"
    case SameUser = "sameUser"
    }

// header cell
class FollowingCell: UITableViewCell {
    
    @IBOutlet weak var imageViewUserIcon: UIImageView!
    @IBOutlet weak var labelUsername: UILabel!
    @IBOutlet weak var labelFullName: UILabel!
    @IBOutlet weak var buttonUnfollow: UIButton!
    @IBOutlet weak var buttonFollow: UIButton!
    @IBOutlet weak var buttonPrivate: UIButton!
    
    var statusMode: Mode = .Private{
        didSet{
            
            switch statusMode {
            case .Private:
                buttonPrivate.isHidden = false
            case .Follow:
                buttonFollow.isHidden = false
            case .Unfollow:
                buttonUnfollow.isHidden = false
            case .SameUser:
                buttonUnfollow.isHidden = true
                buttonFollow.isHidden = true
                buttonPrivate.isHidden = true
            }
            
        }
    }
    
    enum userType: String {
        case Follower = "follower"
        case Following = "following"
    }
    
    var followingCellDelegate : FollowingCellDelegate?
  
    var userDetails: UserDetailModel! {
        didSet{
            labelUsername.text = userDetails.userUserName
            labelFullName.text = "\(userDetails.userFirstName!) \(userDetails.userLastName!)"
            let imageURL = URL(string: userDetails.userProfilePhoto! as String)
            imageViewUserIcon.setImageWith(imageURL, placeholderImage:  UIImage(named:"FacebookIcon")!)
            buttonUnfollow.isHidden = true
            buttonFollow.isHidden = true
            buttonPrivate.isHidden = true
            
            
            // current user
            if userDetails.userId == AppConfiguration.sharedAppConfiguration.userDetails?.userId {
                statusMode = .SameUser
            }else if userDetails.followStatus == "Yes" {
                statusMode = .Unfollow
            } else {
                
                if userDetails.userType == "Private" {
                    statusMode = .Private
                } else {
                    statusMode = .Follow
                }
            }
            
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        configureView()
    }
    
    func configureView() {
        
        labelUsername.isUserInteractionEnabled = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(FollowingCell.didTaplabelUserNameWithGesture(_:)))
        tapGesture.delegate = self
        labelUsername.addGestureRecognizer(tapGesture)
        
        imageViewUserIcon.isUserInteractionEnabled = true
        let userImageTapGesture = UITapGestureRecognizer(target: self, action: #selector(FollowingCell.didTaplabelUserNameWithGesture(_:)))
        userImageTapGesture.delegate = self
        imageViewUserIcon.addGestureRecognizer(userImageTapGesture)
        
    }

func didTaplabelUserNameWithGesture(_ tapGesture: UITapGestureRecognizer) {
    //print("didTaplabelUserNameWithGesture entered...")
    followingCellDelegate?.navigateToProfile(userDetails)
}

    @IBAction func buttonActionUnfollow(_ sender: UIButton) {
        //print("unfollow")
        followingCellDelegate?.followFriend(self, user: userDetails,status: statusMode)
    }
    @IBAction func buttonActionFollow(_ sender: UIButton) {
          //print("follow")
        followingCellDelegate?.followFriend(self, user: userDetails,status: statusMode)
    }
    @IBAction func buttonActionPrivate(_ sender: UIButton) {
        followingCellDelegate?.followFriend(self, user: userDetails,status: statusMode)
    }
    
}

class FollowingViewController: UITableViewController , UITableViewDragLoadDelegate , FollowingCellDelegate{
    
    var isFollow = false
    var arrayUser = [UserDetailModel]()
    var userId = " "
    var selectedUserId = ""
    
    // show empty tableview message
    var tableViewShowEmptyMessage = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView()
        if isFollow {
            getUsersList(0, limit: 20,type:"followers", doLoadMore: false)
        } else {
            getUsersList(0, limit: 20,type:"following", doLoadMore: false)
        }
       
    }
    
    
    func configureTableView() {
        
        // hide empty tableview cells
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        
        // set delegate for pull to refresh and load more
        tableView.setDragDelegate(self, refreshDatePermanentKey: "kMessageFriends")
        
        // hide pull to refresh
        tableView.showRefreshView = false
        
        // show load more
        tableView.showLoadMoreView = true
        
        // tableview footer release text
        tableView.footerReleaseText = NSLocalizedString("release_to_load_more_status", comment: "")
        
        // tableview footer pull up text
        tableView.footerPullUpText = NSLocalizedString("pull_down_to_load_more_status", comment: "")
        
        //tableview footer loading text
        tableView.footerLoadingText = NSLocalizedString("loading_status", comment: "")
        
    }
    
    
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.

        if arrayUser.count == 0 && tableViewShowEmptyMessage {
            // show empty record message
            
            tableView.showEmptyTableViewMessage()
        }
        else {
            tableView.backgroundView = UIView()
            tableView.separatorStyle = .singleLine
        }
        return arrayUser.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.FollowCell, for: indexPath) as! FollowingCell
      //  cell.type = isFollow
        cell.userDetails = arrayUser[indexPath.row]
        cell.followingCellDelegate = self
        return cell
    }
    
    struct Storyboard {
        struct CellIdentifiers {
            static let FollowCell = "kFollowCell"
        }
    }
    
    func getUsersList(_ offset:Int,limit:Int,type:String,doLoadMore:Bool) {
        // API CALL FOR FOLLOWERS/FOLLOWING
        GetFollowingFollowerUserResponse.getUsersList(userId, offset: offset, type: type ,andLimit: 15, keywords: "", completionHandler: { (response:GetFollowingFollowerUserResponse) -> () in
            let res = response
            //print("respone code :\(res.metaModel?.responseCode)")
            //print("respone status :\(res.metaModel?.responseStatus)")
            
            // set true
            self.tableViewShowEmptyMessage = true
            
            if res.metaModel?.responseCode == 200 {
                if doLoadMore {
                self.arrayUser += res.user_list!
                self.finishLoadMore()
                }else{
                self.arrayUser = res.user_list!
                }
                self.tableView.reloadData()
            }
        })
    }
    // load more funcationality
    func dragTableDidTriggerLoadMore(_ tableView: UITableView!) {
        // called when the load more is selected
        
        if isFollow {
            getUsersList(arrayUser.count,limit: 20,type:"followers", doLoadMore: true)
        } else {
             getUsersList(arrayUser.count,limit: 20,type:"following", doLoadMore: true)
        }
    }
    func dragTableLoadMoreCanceled(_ tableView: UITableView!) {
        // called when the load more is cancelled
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(FollowingViewController.finishLoadMore), object: nil)
    }
    
    func finishLoadMore() {
        // to stop the load more and populate the tableview with new items
        tableView.finishLoadMore()
        tableView.reloadData()
    }
    
    func removeArrayElement(_ s :[UserDetailModel],removeItem:UserDetailModel )-> ([UserDetailModel]) {
        var s = s
        
        var index:Int = -1
        
        for i in 0..<s.count {
            if s[i].userId == removeItem.userId {
                index = i
                //print("found index ")
            }
            
        }
        if(index != -1){
            s.remove(at: index)
        }
        
        return s
    }
    
    func followFriend(_ followingcell: FollowingCell, user: UserDetailModel,status mode:Mode) {
        // posting the notification
        
        switch(mode) {
        case Mode.Private :
            //print("private\(user.userId)")
            //performSegueWithIdentifier("kFollowingProfileSegue", sender: user.userId)
            selectedUserId = user.userId!
        case Mode.Follow:
            FollowUserResponse.followUser(user.userId!, completionHandler: { (response) -> () in
                let followUserResponse = response
                //print("respone code :\(followUserResponse.metaModel?.responseCode)")
                //print("respone status :\(followUserResponse.metaModel?.responseStatus)")
                if followUserResponse.metaModel?.responseCode == 200 {
                  //  followingcell.buttonFollow.hidden = true
                  //  followingcell.buttonUnfollow.hidden = false                    
                    if self.isFollow {
                        self.getUsersList(0, limit: 20,type:"followers", doLoadMore: false)
                    } else {
                        self.getUsersList(0, limit: 20,type:"following", doLoadMore: false)
                    }
                    
                    let notification = Notification(name: Notification.Name(rawValue: Constants.updateUserProfile),
                        object: nil)
                    NotificationCenter.default.post(notification)
                    
                }
                
            })
        
        case Mode.Unfollow:
            UnfollowUserResponse.unfollowUser(user.userId!, completionHandler: { (response) -> () in
                let unFollowUserResponse = response
                //print("respone code :\(unFollowUserResponse.metaModel?.responseCode)")
                //print("respone status :\(unFollowUserResponse.metaModel?.responseStatus)")
                if unFollowUserResponse.metaModel?.responseCode == 200 {
                  /*  if self.userId == AppConfiguration.sharedAppConfiguration.userDetails?.userId {
                        self.arrayUser = self.removeArrayElement(self.arrayUser, removeItem: user)
                        self.tableView.reloadData()
                    }else{
                        followingcell.buttonFollow.hidden = false
                        followingcell.buttonUnfollow.hidden = true
                    }*/
                    
                    // refresh the list again
                    if self.isFollow {
                        self.getUsersList(0, limit: 20,type:"followers", doLoadMore: false)
                    } else {
                        self.getUsersList(0, limit: 20,type:"following", doLoadMore: false)
                    }
                    
                    let notification = Notification(name: Notification.Name(rawValue: Constants.updateUserProfile),
                        object: nil)
                    NotificationCenter.default.post(notification)
                    
                }
            })
            
        case Mode.SameUser :
              print("same user")
        }
        
       }
    
    // navigation to user profile
    func navigateToProfile(_ user: UserDetailModel) {
        selectedUserId = user.userId!
        performSegue(withIdentifier: "kFollowingProfileSegue", sender: user.userId)

    }
    
    override func  prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "kFollowingProfileSegue" {
            let profileViewController = segue.destination as! ProfileViewController
            profileViewController.userId = selectedUserId//sender as? String ?? ""
        }
    }

}
