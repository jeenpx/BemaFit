//
//  MealTypeCreateResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 03/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class MealTypeCreateResponse: NSObject {
    
    var meta = MetaModel()
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
        responseMapping?.addPropertyMapping(metaModelMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let mealTypeCreateResponseDescriptor = RKResponseDescriptor(mapping: MealTypeCreateResponse.responseMapping, method: .POST, pathPattern: Constants.ServiceConstants.kMealTypeListUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return mealTypeCreateResponseDescriptor!
    }
    
    class func createMealType(_ params: [String: Any], completionHandler: @escaping (_ error: NSError?) -> ()) {
        
        RestKitManager.setToken(true)
        
        // create a post request
        let request = RestKitManager.shared().request(with: nil, method: .POST, path: Constants.ServiceConstants.kMealTypeListUrl, parameters: nil)
        
        // set params as body
        request?.httpBody = try? JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
        
        // create an operation with the request
        let operation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let mealTypeCreateResponse = mappingResult?.firstObject as! MealTypeCreateResponse
            
            // check for success
            if mealTypeCreateResponse.meta.responseCode == 200 {
                completionHandler(nil)
                return
            }
            
            // configure error messages
            var message = ""
            if mealTypeCreateResponse.meta.responseCode == 500 {
                if mealTypeCreateResponse.meta.message == "Meal Type already exist" {
                    message = "create_meal_type_validation_message"
                }
                else {
                    message = "create_meal_type_limit_error_message"
                }
            }
            else {
                message = "create_meal_type_error_message"
            }
            
            completionHandler(NSError(domain: "FYM.MealType", code: 1002, userInfo: ["title": "error", "message": message]))
            
            }) { (operation, error) in
                //print("XXX failed to create mealtype with error \(error)")
                completionHandler(NSError(domain: "FYM.MealType", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"]))
        }
        
        // enque request operation
        RestKitManager.shared().enqueue(operation)
    }
    
}
