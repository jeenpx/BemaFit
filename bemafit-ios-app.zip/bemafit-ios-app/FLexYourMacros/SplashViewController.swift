//
//  SplashViewController.swift
//  FlexYourMacros
//
//  Created by mini on 24/07/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class SplashViewController: UIViewController, UIAlertViewDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        checkUserVerification()

        // Do any additional setup after loading the view.
    }
    
    func checkUserVerification() {
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
//            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        appDelegate?.checkUserVerification({ (verifiedStatus) -> () in
            if !verifiedStatus {
                
                let userDefaults = UserDefaults.standard
                
                AppConfiguration.sharedAppConfiguration.userEmail = userDefaults.object(forKey: "user_email") as! String
                
                let alert =  UIAlertView(title: &&"notice", message: &&"To continue using the app, please verify the registered email", delegate: self, cancelButtonTitle: &&"ok", otherButtonTitles: &&"resend_email")
                alert.tag = 2
                alert.show()
                
            } else {
                
                AppConfiguration.refreshUserDetails(false) { (refreshedUserDetails) -> () in
                    
                    if refreshedUserDetails {
                        
                        let reachability = self.appDelegate!.internetReachable
                        if !reachability {
                            // no internet
                            
                            // alert
                            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                            return
                        }
                        
                        self.loadAllMAsterData({ (loadedmasterData) -> () in
                            
                            self.appDelegate?.loadDashboard()
                            
                        })
                        
                    }
                }
            }
        })
       
    }

    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        
        if alertView.tag == 2 {
            
            if buttonIndex == 1 {
                
                
                // resend email api called
                ResendEmailResponse.resendEmail(AppConfiguration.sharedAppConfiguration.userEmail, completionHandler: { (resendEmailResponse) -> () in
                    
                    if resendEmailResponse == nil {
                        UIAlertView(title: &&"notice", message: &&"failed_resend_email", delegate: nil, cancelButtonTitle: &&"ok").show()
                        
                        return }
                    if resendEmailResponse!.status == "OK" {
                        
                        UIAlertView(title: &&"email_sent", message: &&"check_the_email_1" + "\(AppConfiguration.sharedAppConfiguration.userEmail). " + &&"check_the_email_2", delegate: nil, cancelButtonTitle: &&"ok").show()
                        
                    }
                })
                
                self.appDelegate?.loadLogin()
                
            } else {
                self.appDelegate?.loadLogin()
            }
        }
    }
    func loadAllMAsterData(_ completionHandler: @escaping (_ loadedmasterData: Bool) -> ()) {
        
        // load master data
        MasterDataResponse.fetchMasterData { (masterDataModelEnglish, masterDataModelSpanish) -> () in
            
            AppConfiguration.sharedAppConfiguration.masterDataModelEnglish = masterDataModelEnglish
            AppConfiguration.sharedAppConfiguration.masterDataModelSpanish = masterDataModelSpanish
            completionHandler(true)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
