//
//  DirectoryImages.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/26/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class DirectoryImages: NSObject {
    
    // model instance variables
    var file: String?
    var directoryDescription: String?
    
    class var objectMapping: RKObjectMapping {
        // object mapping
        
        let directoryCategoryMapping = RKObjectMapping(for: self)
        directoryCategoryMapping?.addAttributeMappings(from: mappingDictionary)
        return directoryCategoryMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["file":"file", "description":"directoryDescription"])
    }

}
