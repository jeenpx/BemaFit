//
//  UserMacroDetailResponse.swift
//  FlexYourMacros
//
//  Created by mini on 09/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _UserMacroDetailResponse = UserMacroDetailResponse()

class MacroModel: NSObject {
    
    var proteinTotal: String = ""
    var fatTotal: String = ""
    var carbsTotal:String = ""
    var fiberTotal: String = ""
    var caloriesTotal:String = ""
    var sugarTotal: String = ""
    var calorieAchived: String = ""
    var proteinAchived: String = ""
    var fiberAchived: String = ""
    var fatAchived: String = ""
    var carbAchived: String = ""
    var sugarAchived: String = ""
    
    
    func macrosLeft() -> (caloriesLeft: String, proteinsLeft: String, fatsLeft: String, carbsLeft: String, fiberLeft: String) {
        
        var caloriesLeft = caloriesTotal.doubleValue - calorieAchived.doubleValue
        var proteinLeft = proteinTotal.doubleValue - proteinAchived.doubleValue
        var fatLeft = fatTotal.doubleValue - fatAchived.doubleValue
        var carbLeft = carbsTotal.doubleValue - carbAchived.doubleValue
        var fiberLeft = fiberTotal.doubleValue - fiberAchived.doubleValue
        
        return (caloriesLeft.roundedString(), proteinLeft.roundedString(), fatLeft.roundedString(), carbLeft.roundedString(), fiberLeft.roundedString())
    }
    
    class var objectMapping: RKObjectMapping {
        let exerciseMapping = RKObjectMapping(for: self)
        exerciseMapping?.addAttributeMappings(from: mappingDictionary)
        return exerciseMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["protein_total": "proteinTotal", "fat_total": "fatTotal", "carbs_total": "carbsTotal", "fiber_total": "fiberTotal", "calories_total": "caloriesTotal",  "calorie_achived":"calorieAchived", "protein_achived":"proteinAchived", "fibre_achived":"fiberAchived", "fat_achived":"fatAchived", "carb_achived":"carbAchived"])
    }
    
    class func refreshUserMacros(_ date: Date = Date(), completionHnadler: @escaping (_ achievedMacroGoal: MacroModel) -> ()) {
        //refresh macros for a date
        UserMacroDetailResponse.fetchUserMacro(date, completionHandler: { (achievedMacroGoal) -> () in
            completionHnadler(achievedMacroGoal)
        })
    }
}

class UserMacroDetailResponse: NSObject {
    
    var metaModel: MetaModel?
    var macroModel: [MacroModel]?
    
    class var sharedUserMacroDetailResponse: UserMacroDetailResponse {
        return _UserMacroDetailResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(UserMacroDetailResponse.metaModelKeyMapping)
        
        // give reference to achievegoalMapping
        responseMapping?.addPropertyMapping(UserMacroDetailResponse.achieveGoalModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var achieveGoalModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathAchivedMacro, toKeyPath: "macroModel", with: MacroModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kMacroLogUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func fetchUserMacro(_ date: Date, completionHandler:@escaping (_ achievedMacroGoal: MacroModel)->()) {
        
        RestKitManager.setToken(true)
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["date": date.stringValue("yyyy-MM-dd"), "limit": "1"]
        }
        
        // get the objects from the path login
        RestKitManager.shared().getObjectsAtPath(Constants.ServiceConstants.kMacroLogUrl, parameters: parameterDictionary, success: { (operation, mappingResult) in
            
            // get the user response
            let logResponse = mappingResult?.firstObject as! UserMacroDetailResponse
            
            //check for success
            if logResponse.metaModel?.responseCode != 200 {
                return;
            }
            
            var macroArray: [MacroModel] = logResponse.macroModel!
            
            completionHandler(macroArray[0])
            
        }) { (operation, error) -> Void in
            
            //print("failed to load masterdata with error \(error)")
        }
        
//        RestKitManager.shared().getObjectsAtPath(Constants.ServiceConstants.kMacroLogUrl, parameters: parameterDictionary, success: { (operation, mappingResult) in
//            
//            // get the user response
//            let logResponse = mappingResult.firstObject as! UserMacroDetailResponse
//            
//            //check for success
//            if logResponse.metaModel?.responseCode != 200 {
//                return;
//            }
//    
//            var macroArray: [MacroModel] = logResponse.macroModel!
//            
//            completionHandler(achievedMacroGoal: macroArray[0])
//            
//            }) { (operation, error) in
//                
//                //print("failed to load masterdata with error \(error)")
//        })
    }
    
}

