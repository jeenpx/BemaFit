//
//  UpdateUserSettingsResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 05/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UpdateUserSettingsResponse: NSObject {
    var metaModel: MetaModel?
    var updateSettings: UpdateUserSettingsModel?
    var user_id: String?
    
    class var UpdateUserSettingsResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        // give referece to meta model
        responseMapping?.addPropertyMapping(UpdateUserSettingsResponse.metaModelKeyMapping)
        // give reference to changePassword mapping
        responseMapping?.addPropertyMapping(UpdateUserSettingsResponse.updateUserSettingModelMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var updateUserSettingModelMapping :RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUpdateSettings, toKeyPath: "updateSettings", with: UpdateUserSettingsModel.objectMapping)
    }
    
    class var userResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: UpdateUserSettingsResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.userSettingsUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    
    class func updateUserSettings(_ parameters: Array<Dictionary<String, String>>,completionHandler: @escaping (_ updateUserSettingsResponse:UpdateUserSettingsResponse) -> ()){
     
        RestKitManager.setToken(true)
        let updateResponse = UpdateUserSettingsResponse()
        updateResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
    
      //  var e = ["setting_id":id,"status":status]
        
       // var parameters: Array<Dictionary<String, String>> = [["setting_id":"3","status":"No"],["setting_id":"1","status":"No"]]
       // parameters.append(e)
        
   
        let jsonData = try? JSONSerialization.data(withJSONObject: parameters,options:JSONSerialization.WritingOptions());
        let jsonString = NSString(data: jsonData!, encoding:String.Encoding.utf8.rawValue);
        
        //print("Converted json string \(jsonString)");
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: updateResponse, method: .POST, path: nil, parameters: ["settings" :
            
            jsonString as! String], constructingBodyWith: { (formData) in
                
        })
        
//        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: updateResponse, method: .POST, path: nil, parameters: ["settings" :
//            
//            jsonString as! String], constructingBodyWith: { (formData) in
//            
//        })
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let updateUserSettingsResponse = mappingResult?.firstObject as! UpdateUserSettingsResponse
            //print("respone code :\(updateUserSettingsResponse.metaModel?.responseCode)")
            //print("respone status :\(updateUserSettingsResponse.metaModel?.responseStatus)")
            
            // check for success
            if updateUserSettingsResponse.metaModel?.responseCode != 200 {
                return;
            }
            
            // set up the completion handler with response
            completionHandler(updateUserSettingsResponse)
            
            //print("Status is \(updateUserSettingsResponse.updateSettings?.status)")
            
        }) { (operation, error) in
            
            //print("failed to load change password with error \(error)")
        }
        
//       let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) -> Void in
//            
//            let updateUserSettingsResponse = mappingResult.firstObject as! UpdateUserSettingsResponse
//            //print("respone code :\(updateUserSettingsResponse.metaModel?.responseCode)")
//            //print("respone status :\(updateUserSettingsResponse.metaModel?.responseStatus)")
//            
//            // check for success
//            if updateUserSettingsResponse.metaModel?.responseCode != 200 {
//                return;
//            }
//            
//            // set up the completion handler with response
//            completionHandler(updateUserSettingsResponse: updateUserSettingsResponse)
//            
//            //print("Status is \(updateUserSettingsResponse.updateSettings?.status)")
//            
//            }) { (operation, error) in
//                
//                //print("failed to load change password with error \(error)")
//        })
        
        RestKitManager.shared().enqueue(operation)
    
    }
    


}
