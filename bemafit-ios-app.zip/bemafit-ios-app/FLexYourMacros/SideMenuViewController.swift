//
//  SideMenuViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 18/02/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class SideMenuViewController: UITableViewController, UIAlertViewDelegate {
    
    @IBOutlet weak var footerView: UIView!
    @IBOutlet weak var indicatorViewProfileIcon: UIActivityIndicatorView!
    @IBOutlet weak var imageViewUserImage: UIImageView!
    @IBOutlet weak var imageViewAds: UIImageView!
    @IBOutlet weak var labelUserName: UILabel!
    @IBOutlet weak var buttonAds: UIButton!
    @IBOutlet weak var indicatorAds: UIActivityIndicatorView!
    
    var adsUrlContent: String = ""
    
    // store device token
    var deviceToken = ""
    
    // mapping cellidentifier -> segue
    let segueMapper = [
        "kMyProfileCell": "kMyProfileSlideSegue",
        "kSettingsCell": "kSettingsSlideSegue"
    ]
    
    var enableDashboard = false {
        didSet {
            dashboard?.tableView.isUserInteractionEnabled = enableDashboard
            dashboard?.textInputbar.isUserInteractionEnabled = enableDashboard
            dashboardNavigationController?.toolbar.isUserInteractionEnabled = enableDashboard
        }
    }
    
    func closeSideMenu() {
        // close the side menu if its open
        if let slidingViewController = slidingViewController {
            if slidingViewController.currentTopViewPosition == .anchoredRight {
                slidingViewController.resetTopView(animated: true) {
                    self.enableDashboard = true
                }
            }
        }
    }
    
    override func viewDidLoad() {
        
        let height = UIScreen.main.bounds.height ?? 667.0//CGRectGetWidth(superview!.bounds)
        
        footerView.frame = CGRect(x: footerView.frame.origin.x, y: footerView.frame.origin.y, width: footerView.frame.size.width, height: height - 285.0)
        
        indicatorAds.isHidden = true

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // set the alpha value to zero
        self.imageViewAds.alpha = 0
        indicatorViewProfileIcon.isHidden = false
        indicatorAds.isHidden = true
        
        // disable dashboard
        enableDashboard = false
        
        labelUserName.text = AppConfiguration.sharedAppConfiguration.userDetails?.userUserName!
        if let profilePhoto = AppConfiguration.sharedAppConfiguration.userDetails?.userProfilePhoto {
            loadImage(profilePhoto as? String ?? "")
        }
        else {
            //print("NO PROFILE PIC")
        }
        
        // load advertisement
        Advertisement.latestAdvertisement("Sidebar") { (advertisement) -> () in
            
            if advertisement.shouldDisplayAdvertisement {
                
                //   self.imageViewAds.setImageWithURL(advertisement.imageURL)
                let request = URLRequest(url: advertisement.imageURL!)
                
                // settings the image 
                self.imageViewAds.setImageWith(request, placeholderImage: nil, success: { (request, response, image) in
                    
                    // set the image
                    self.imageViewAds.image = image
                    
                    // animation
                    self.animateAdvertisement()
                    
                    // hide the activity indicator
                    self.indicatorAds.isHidden = true
                    
                    }) { (request, response, error) in
                        
                        // hide the activity indicator
                        self.indicatorAds.isHidden = true
                        
                }
                
                // self.animateAdvertisement()
                
                self.buttonAds.setTitle(advertisement.content, for: UIControlState())
                
                self.adsUrlContent = advertisement.content!
                self.buttonAds.addTarget(self, action: "buttonAdClicked:",for: UIControlEvents.touchUpInside)
            } else {
                self.indicatorAds.isHidden = true
            }
        }
        
        slidingViewController?.anchorRightPeekAmount = 60
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // enable dashboard
        enableDashboard = true
        
        dashboard?.displayNewAd()
        
        // post notification about enabling dashboard
        NotificationCenter.default.post(name: Notification.Name(rawValue: kEnableDashboardNotification), object: nil)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        // enable dashboard
        enableDashboard = true
        
        // post notification about enabling dashboard
        NotificationCenter.default.post(name: Notification.Name(rawValue: kEnableDashboardNotification), object: nil)
    }
    
    func animateAdvertisement () {
        // slow animation fade in fade out to avoid flashing
        UIView.animate(withDuration: 0.5, delay: 0.0, options: UIViewAnimationOptions.transitionCrossDissolve, animations:{
            self.imageViewAds.alpha = 0.25
            }, completion: {(value: Bool) in
                UIView.animate(withDuration: 1.0, animations: {
                    self.imageViewAds.alpha = 1.0
                })
        })
        
    }
    
    func loadImage(_ urlString:String) {
        let imgURL: URL = URL(string: urlString)!
        let request: URLRequest = URLRequest(url: imgURL)
        
        // settings the image
        self.imageViewUserImage.setImageWith(request, placeholderImage: nil, success: { (request, response, image) in
            
            // set the image
           self.imageViewUserImage.image = image
           self.indicatorViewProfileIcon.isHidden = true
            
            }) { (request, response, error) in
                
                // hide the activity indicator
               self.indicatorViewProfileIcon.isHidden = true
        }
        
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // remove highlight
        tableView.deselectRow(at: indexPath, animated: true)
        
        // get the selected cell
        let cell = tableView.cellForRow(at: indexPath)
        
        // sign out
        if cell?.reuseIdentifier == "kSignOutCell" {
           
            let userDefaults = UserDefaults.standard
            deviceToken = userDefaults.object(forKey: "token") as? String ?? ""
            
            // logout api
            logout(deviceToken)
            
            return
        } else if cell?.reuseIdentifier == "kManageMacroCell" {
            
            // instantiate the main storyboard
            let manageStoryboard = UIStoryboard(name: "ManageGoalsStoryboard", bundle: Bundle.main)
            
            // instantiate the initial view controller
            let initialViewController = manageStoryboard.instantiateViewController(withIdentifier: "kManageGoalsList") as! ManageGoalsListViewController
            
            dashboard?.navigationController?.pushViewController(initialViewController, animated: true)
            closeSideMenu()
            return;
        }
        
        // perform segues from dashboard using the segue mapper
        dashboard?.performSegue(withIdentifier: segueMapper[cell!.reuseIdentifier!]!, sender: AppConfiguration.sharedAppConfiguration.userDetails!.userId!)
        
        // close the side menu
        closeSideMenu()
    }
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        
        if alertView.title == &&"sign_out" {
            
            if buttonIndex == 1 {
                
                appDelegate?.loadLogin()
            }
        }
    }
    
    func buttonAdClicked(_ sender:UIButton) {
        
        self.dashboard?.showAd(adsUrlContent);
        self.closeSideMenu()
    }
    
    @IBAction func unwindToMenuViewController(_ segue: UIStoryboardSegue) {
        // close the side menu if its open
        closeSideMenu()
    }
    
    func logout(_ deviceToken: String) {
        
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        LogoutResponse.logoutUser(deviceToken, completionHandler: { (metaModel) -> () in
            if let meta = metaModel {
                if meta.responseCode != 200 {
                    AlertManager.showAlert(&&"notice", message: &&"failed_logout")
                    return
                }
               self.appDelegate?.loadLogin()
            }
        })
    }
}
