//
//  MessagesViewController.swift
//  FlexYourMacros
//
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class MessagesViewController: UIViewController, SWTableViewCellDelegate, UITableViewDelegate, UITableViewDataSource, UITableViewDragLoadDelegate, UserProfileDelegate {
    
    @IBOutlet var tableViewMessage: UITableView!
    
    // array holds messages
    var inboxMessages: [MessageItemModel]?
    
    // limit value for messages
    var limitValue: Int = 10
    
    // Offset value for messages
    var offsetValue: Int = 0
    
    // user selected message
    var index = 0
    
    // variable for pull to refresh
    var refreshControl: UIRefreshControl!
    
    // navigate from message list to thread in case of push notification
    var navigateMessageDetails = false
    
    // friend id in case of push notification
    var navigateMessageDetailsFriendId = ""
    
    struct MessageIdentifiers {
        
        // cell identifier
        static let cellIdentifierMessages = "kMessageListCell"
        
        // segue identifier
        static let segueIdentifierMessages = "kSegueMessageDetails"
        
        static let segueMessageListProfileSegue = "kMessageListProfileSegue"
        
        // empty records
        static let emptyMessage = &&"empty_tableview_message"
        
        static let selectUser = "kSelectUser"
        
        static let messageDetailsId = "MessageDetailsViewController"
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //sortDate()
        
        // configure message tableview
        configureTableViewMessage()
        
        let reachability = self.appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        // list messages api call
        listMessages(offsetValue, andLimit: limitValue, andProgressHUD: true, doLoadMore: false)
    }
    
    func configureTableViewMessage() {
        
        // hide empty tableview cells
        tableViewMessage.tableFooterView = UIView(frame: CGRect.zero)
        
        // set delegate for pull to refresh and load more
        tableViewMessage.setDragDelegate(self, refreshDatePermanentKey: "kMessage")
        
        // hide pull to refresh
        tableViewMessage.showRefreshView = false
        
        // show load more
        tableViewMessage.showLoadMoreView = true
        
        // tableview footer release text
        tableViewMessage.footerReleaseText = NSLocalizedString("release_to_load_more_status", comment: "")
        
        // tableview footer pull up text
        tableViewMessage.footerPullUpText = NSLocalizedString("pull_down_to_load_more_status", comment: "")
        
        //tableview footer loading text
        tableViewMessage.footerLoadingText = NSLocalizedString("loading_status", comment: "")
        
        // configure pull to refresh
        configureRefreshControl()
    }
    
    func configureRefreshControl() {
        refreshControl = UIRefreshControl()
        
        // add the target
        refreshControl.addTarget(self, action: #selector(MessagesViewController.pullToRefresh(_:)), for: UIControlEvents.valueChanged)
        refreshControl.tintColor = UIColor.gray
        
        // add refresh control to the tableview
        tableViewMessage.addSubview(refreshControl)
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let count = self.inboxMessages?.count {
            
            if count == 0 {
                // show empty record message
                
                tableViewMessage.showEmptyTableViewMessage(MessageIdentifiers.emptyMessage)
            }
            else {
                tableViewMessage.backgroundView = UIView()
                tableViewMessage.separatorStyle = .singleLine
            }
            
            return count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let messageListCell = tableView.dequeueReusableCell(withIdentifier: MessageIdentifiers.cellIdentifierMessages, for: indexPath) as! MessageListCell
        if let messageItemModel: MessageItemModel  = self.inboxMessages?[indexPath.row] {
            
            // save the message
            messageListCell.messageItemModel = messageItemModel
        }
        messageListCell.delegate = self
        messageListCell.userProfileDelegate = self
        return messageListCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let selectedMessageListCell = tableView.cellForRow(at: indexPath) as! MessageListCell
        
        // index of selected message
        index = indexPath.row
        
        NotificationCenter.default.addObserver(self, selector: #selector(MessagesViewController.refreshMessageThread(_:)), name:NSNotification.Name(rawValue: "RefreshMessageIdentifier"), object: nil)
        
        performSegue(withIdentifier: MessageIdentifiers.segueIdentifierMessages, sender: selectedMessageListCell.messageItemModel)
    }
    
    func swipeableTableViewCell(_ cell: SWTableViewCell!, didTriggerRightUtilityButtonWith index: Int) {
        // called when the right utility buttons are clicked
        
        let messageDeleteCell = cell as! MessageListCell
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        // delete message thread
        MessageDeleteResponse.deleteThreadMessages(MessageItemModel.getMessageFriend(messageDeleteCell.messageItemModel!).friendId, completionHandler: { (responseStatus) -> () in
            
            if responseStatus == "OK" {
                
                //print("messageviewcontroller: delete successful")
                let cellIndexPath = self.tableViewMessage.indexPath(for: cell)
                self.inboxMessages?.remove(at: cellIndexPath!.row)
                
                // delete row from tableview
                self.tableViewMessage.deleteRows(at: [cellIndexPath!], with: UITableViewRowAnimation.automatic)
                
            }
        })
    }
    
    func swipeableTableViewCellShouldHideUtilityButtons(onSwipe cell: SWTableViewCell!) -> Bool {
        // prevent multiple cells from showing utilty buttons simultaneously
        
        return true
    }
    
    func refreshMessageThread(_ notification: Notification){
        //Take Action on Notification
        
        if notification.userInfo != nil {
            
            //            let replacedObject = notification.userInfo?["replaceObject"] as? MessageItemModel ?? nil // newpost
            
            let newObject = notification.userInfo?["newMessage"] as! MessageItemModel
            let methodName = notification.userInfo?["method"] as! String
            
            if let messages = self.inboxMessages {
                
                
                let removeMessage = messages.filter{MessageItemModel.getMessageFriend($0).friendId == MessageItemModel.getMessageFriend(newObject).friendId}
                
                if removeMessage.isEmpty {
                    
                    // for an user not existing in thread
                    let tempArray = self.inboxMessages ?? [MessageItemModel]()
                    
                    // remove all messages
                    self.inboxMessages?.removeAll()
                    
                    // insert updated message at first location
                    self.inboxMessages?.insert(newObject, at: 0)
                    
                    for message in tempArray {
                        
                        // append all messages
                        self.inboxMessages?.append(message)
                    }
                    
                    self.tableViewMessage.reloadSections(IndexSet(integersIn: NSMakeRange(0, 1).toRange()!), with: UITableViewRowAnimation.none)
                    
                } else {
                    
                    
                    if let messageIndex = messages.index(of: removeMessage.first!) {
                        
                        if methodName == "Read" {
                            //just read
                            self.inboxMessages?[messageIndex] = newObject
                            self.tableViewMessage.reloadRows(at: [IndexPath(row: messageIndex, section: 0)], with: UITableViewRowAnimation.none)
                        } else if methodName == "Post" {
                            
                            //posted new
                            self.inboxMessages?.remove(at: messageIndex)
                            // for an user not existing in thread
                            let tempArray = self.inboxMessages!
                            // remove all messages
                            self.inboxMessages?.removeAll()
                            // insert updated message at first location
                            self.inboxMessages?.insert(newObject, at: 0)
                            
                            for message in tempArray {
                                
                                // append all messages
                                self.inboxMessages?.append(message)
                            }
                            
                            self.tableViewMessage.reloadSections(IndexSet(integersIn: NSMakeRange(0, 1).toRange()!), with: UITableViewRowAnimation.none)
                            
                        }
                        
                    }
                }
                
            }
            
            
        }
        
    }
    
    func dragTableDidTriggerLoadMore(_ tableView: UITableView!) {
        // called when the load more is selected
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            
            // finish the load more
            Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(MessagesViewController.finishLoadMore), userInfo: nil, repeats: false)
            return
        }
        
        if let count = self.inboxMessages?.count {
            // save messages count to offset
            
            offsetValue = count
        }
        else {
            // set offset to zero
            
            offsetValue = 0
        }
        
        // list messages
        listMessages(offsetValue, andLimit: limitValue, andProgressHUD: false, doLoadMore: true)
    }
    
    func dragTableLoadMoreCanceled(_ tableView: UITableView!) {
        // called when the load more is cancelled
        
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(MessagesViewController.finishLoadMore), object: nil)
    }
    
    func finishLoadMore() {
        // to stop the load more and populate the tableview with new items
        
        tableViewMessage.finishLoadMore()
        //tableViewMessage.reloadData()
    }
    
    func listMessages(_ offset: Int, andLimit limit: Int, andProgressHUD showLoader: Bool,doLoadMore loadMore: Bool) {
        // list message based on offset, limit and load more status
        
        MessageResponse.getMessages(offset, andLimit: limit, andProgressHUD: showLoader) { (messages, unreadCount) in
            
            if self.inboxMessages?.isEmpty == false {
                // append new values to the existing array
                
                if let newMessages = messages as [MessageItemModel]? {
                    
                    // avoid message duplication
                    if let arrayMessages = self.inboxMessages {
                        for message in newMessages {
                            
                            let messageObject = arrayMessages.filter { MessageItemModel.getMessageFriend($0).friendId == MessageItemModel.getMessageFriend(message).friendId }
                            
                            if messageObject.isEmpty {
                                self.inboxMessages?.append(message)
                            }
                        }
                    }
                }
                
            } else {
                // empty array
                
                self.inboxMessages = messages
            }
            
            if loadMore {
                
                // finish the load more
                self.tableViewMessage.finishLoadMore()
            }
            
            if self.refreshControl != nil {
                
                // stop pull to refresh
                self.refreshControl?.endRefreshing()
            }
            
            //print( self.inboxMessages?.count)
            
            // reload the tableview
            self.tableViewMessage.reloadData()
            
            // handle push notification
            if self.navigateMessageDetails {
                
                // set false
                self.navigateMessageDetails = false
                //print( self.inboxMessages?.count)
                if let messages = self.inboxMessages {
                    var messageForDetails = messages.filter { MessageItemModel.getMessageFriend($0).friendId == self.navigateMessageDetailsFriendId }
                    
                    // navigate to message details
                    let messageDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: MessageIdentifiers.messageDetailsId) as! MessageDetailsViewController
                    
                    messageDetailsViewController.selectedMessageThread = messageForDetails[0]
                    NotificationCenter.default.addObserver(self, selector: #selector(MessagesViewController.refreshMessageThread(_:)), name:NSNotification.Name(rawValue: "RefreshMessageIdentifier"), object: nil)                    
                    self.navigationController?.pushViewController(messageDetailsViewController, animated: true)
                }
            }
        }
    }
    
    @IBAction func unwindToMessagesViewController(_ segue: UIStoryboardSegue) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == MessageIdentifiers.segueIdentifierMessages {
            // navigate to message details screen
            
            let messageDetailsViewController = segue.destination as! MessageDetailsViewController
            if let selectedMessage = sender as? MessageItemModel {
                messageDetailsViewController.selectedMessageThread = selectedMessage
            }
        } else if segue.identifier ==  MessageIdentifiers.selectUser {
            
            NotificationCenter.default.addObserver(self, selector: #selector(MessagesViewController.refreshMessageThread(_:)), name:NSNotification.Name(rawValue: "RefreshMessageIdentifier"), object: nil)
        }
        else if segue.identifier == MessageIdentifiers.segueMessageListProfileSegue {
            let profileViewController = segue.destination as! ProfileViewController
            profileViewController.userId = sender as? String ?? ""
        }
        
    }
    
    func userProfile(_ userId: String) {
        //print(userId)
        performSegue(withIdentifier: MessageIdentifiers.segueMessageListProfileSegue, sender: userId)
    }
    
    func pullToRefresh(_ sender: Any) {
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            refreshControl.endRefreshing()
            return
        }
        
        // set offset 0
        offsetValue = 0
        
        // clear array
        inboxMessages?.removeAll()
        
        // list messages
        listMessages(offsetValue, andLimit: limitValue, andProgressHUD: false, doLoadMore: false)
    }
    
    
}
