

//
//  NewsFeedCommentsResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 16/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class NewsFeedCommentsResponse: NSObject {
    
    var userId = ""
    var feedId = ""
    
    var metaModel = MetaModel()
    var pageMetaModel = PageMetaModel()
    var newsFeedComments = [NewsFeedComment]()
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
        responseMapping?.addPropertyMapping(metaModelMapping)
        
        // newsfeedcomments mapping
        let newsFeedCommentsModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathNewsFeedComments, toKeyPath: "newsFeedComments", with: NewsFeedComment.objectMapping)
        responseMapping?.addPropertyMapping(newsFeedCommentsModelMapping)
        
        // page meta model mapping
        let pageMetaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathPageMeta, toKeyPath: "pageMetaModel", with: PageMetaModel.objectMapping)
        responseMapping?.addPropertyMapping(pageMetaModelMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let newFeedCommentsResponseDescriptor = RKResponseDescriptor(mapping: NewsFeedCommentsResponse.responseMapping, method: .any, pathPattern: Constants.ServiceConstants.kNewsFeedCommentsUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return newFeedCommentsResponseDescriptor!
    }
    
    class func fetchNewsFeedComments(_ feedId: String, params: [String: String], completionHandler: @escaping (_ newsFeedComments: [NewsFeedComment], _ pageMeta: PageMetaModel, _ error: NSError?) -> ()) {
        
        RestKitManager.setToken(true)
        
        let newsFeedCommentsResponse = NewsFeedCommentsResponse()
        newsFeedCommentsResponse.userId = AppConfiguration.sharedAppConfiguration.userDetails?.userId ?? ""
        newsFeedCommentsResponse.feedId = feedId
        
        RestKitManager.shared().getObject(newsFeedCommentsResponse, path: nil, parameters: params, success: { (operation, mappingResult) in
            
            // map to correct datamodel
            let response = mappingResult?.firstObject as! NewsFeedCommentsResponse
            
            if response.metaModel.responseCode != 200 {
                let error = NSError(domain: "FYM.NewsFeed", code: 1001, userInfo: ["title": "error", "message": "alert_feed_comments_list_message"])
                
                // fire completion handler
                completionHandler([], PageMetaModel(), error)
                
            }
            else {
                // fire completion handler
                completionHandler(response.newsFeedComments, response.pageMetaModel, nil)
            }
            
            }) { (operation, error) -> Void in
                // error
                let networkError = NSError(domain: "FYM.NewsFeed", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
                
                // fire completion handler
                completionHandler([], PageMetaModel(), networkError)
        }
    }
    
}
