//
//  NumberOfMealsCell.swift
//  FlexYourMacros
//
//  Created by dbgattila on 6/3/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol NumberOfMealsCellDelegate {
    func numberOfMeals(_ cell: NumberOfMealsCell)
}

class NumberOfMealsCell: UITableViewCell, UITextFieldDelegate {
    
    @IBOutlet weak var textFieldNumberOfMeals: UITextField!
    var numberOfMealsCellDelegate: NumberOfMealsCellDelegate?
    
    var numberOfMeals: String? {
        didSet {
            textFieldNumberOfMeals.text = numberOfMeals
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if FymUser.sharedFymUser.userNumberOfMeals != textField.text!.intValue {
            
            // show alert due to change in number of meals value
           ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
        }
        
        FymUser.sharedFymUser.userNumberOfMeals = textField.text!.intValue
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        numberOfMealsCellDelegate?.numberOfMeals(self)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // hide keyboard on return
        textField.resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        // managing the textfield input: limit the characters to only of numeric type
        var result = true
        let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        if string.characters.count > 0 {
            let disallowedCharacterSet = CharacterSet(charactersIn: "0123456789").inverted
            let replacementStringIsLegal = string.rangeOfCharacter(from: disallowedCharacterSet) == nil
            let resultingStringLengthIsLegal = prospectiveText.characters.count <= 10
            let scanner = Scanner(string: prospectiveText)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
            result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
        }
        return result
    }

}
