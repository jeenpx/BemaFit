//
//  LogoutResponse.swift
//  FlexYourMacros
//
//  Created by Attila Roy on 04/08/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class LogoutResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    
    // message response mapping
    class var logoutMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(LogoutResponse.metaModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: logoutMapping, method: .POST, pathPattern: Constants.ServiceConstants.kLogoutUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func logoutUser(_ deviceToken: String, completionHandler: @escaping (_ metaModel: MetaModel?) -> ()) {
        
        // set access token
        RestKitManager.setToken(true)
        
        // input parameter
        let param: Dictionary = ["Device-Token": deviceToken]
        
        SVProgressHUD.show()
        // check in api
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path: Constants.ServiceConstants.kLogoutUrl, parameters: param, constructingBodyWith: { (formData) in
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            SVProgressHUD.dismiss()
            let logoutResponse = mappingResult?.firstObject as! LogoutResponse
            if let metaResponse = logoutResponse.meta {
                completionHandler(metaResponse)
                
            }
            }) { (operation, error) in
                
                SVProgressHUD.dismiss()
                completionHandler(MetaModel())
        }
        
        RestKitManager.shared().enqueue(operation)
    }
    
}
