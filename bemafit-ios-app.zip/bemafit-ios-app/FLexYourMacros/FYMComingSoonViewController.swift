//
//  FYMComingSoonViewController.swift
//  FlexYourMacros
//
//  Created by Aman Ahluwalia on 02/09/16.
//  Copyright © 2016 Digital Brand Group. All rights reserved.
//

import UIKit

class FYMComingSoonViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func removeComingSoonScreen(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
