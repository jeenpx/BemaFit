//
//  DailyMealPlan.swift
//  FlexYourMacros
//
//  Created by Minimol BI on 09/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private var _DailyMealPlan = DailyMealPlan()

class DailyMealPlan: NSObject {
    
    var dailyMealPlanName : String = ""
    var dailyMealPlanId : String = ""
    var coremeal: Double = 0.0
    var snack: Double = 0.0
    var nutrionalPlanId: Int = 1
    var nutritionMacroModel: MacroModel?
    var addedFoods = [Food]()
    var canEditProfile = false
    
    class var sharedDailyMealPlan: DailyMealPlan {
        
        return _DailyMealPlan
    }
    
    class func resetSharedInstance() {
        
        _DailyMealPlan = DailyMealPlan()
    }
    
    //daily meal plan  DailyMealPlan.sharedDailyMealPlan.nutrionalPlanId
    class func fetchFoodDailyMeal(_ coremealNo: String, snackNo: String, calories: String, carbs: String, proteins: String, fats: String, showHUD: Bool = false, nutritionPlan: String, completionHandler: @escaping (_ loggedFoods: [Food]) -> ()) {
        
        if showHUD {
            SVProgressHUD.show()
        }
        
        DailyMealPlanAutoSuggestResponse.fetchSuggestedFoodList(coremealNo, snackNo: snackNo, calories: calories, carbs: carbs, proteins: proteins, fats: fats, nutritionPlan: nutritionPlan) { (foodLogList, error) -> () in
            
            if showHUD {
                
                SVProgressHUD.dismiss()
                
            }
            Food.showAlert(error)
            
            
            if error == nil {
                completionHandler(foodLogList)
            }
        }
    }
    
    class func fetchRefreshedItemInMealPlan(_ mealType: String, mealId: String, parentId: String, rowId: String, type: String, dmpMealType: String, showHUD: Bool = false , nutritionPlan: String , completionHandler: @escaping (_ loggedFoods: [Food]) -> ()) {
        
        if showHUD {
            SVProgressHUD.show()
        }
        
        
        DailyMealPlanItemRefreshResponse.fetchRefreshFoodItem(mealType, mealId: mealId, parentId: parentId, rowId: rowId, type: type, dmpMealType: dmpMealType , nutritionPlan:  nutritionPlan) { (foodLogList, error) -> () in
            
            if showHUD {
                
                SVProgressHUD.dismiss()
                
            }
            Food.showAlert(error)
            
            
            if error == nil {
                completionHandler(foodLogList)
            }
            
        }
    }
    
    
    func createNewMealPlan(_ completionHandler: @escaping (_ error: NSError?) -> ()) {
        
        var params = [String: Any]()
        
        params["name"] = dailyMealPlanName as Any?
        params["coremeal"] = coremeal as Any?
        params["snacks"] = snack as Any?
        params["nutrition_plan"] = Int(FymUser.sharedFymUser.userNutritionType) as Any?
        params["calorie"] = nutritionMacroModel?.caloriesTotal as Any?
        params["carb"] = nutritionMacroModel?.carbsTotal as Any?
        params["fat"] = nutritionMacroModel?.fatTotal as Any?
        params["protien"] = nutritionMacroModel?.proteinTotal as Any?
        params["fiber"] = nutritionMacroModel?.fiberTotal as Any?
        params["detail"] = addedFoods.map {
            ["id": $0.id, "guid": $0.guid, "name": $0.name,"name_es": $0.name_es, "genre": $0.genre, "type": $0.mealType.name,
                "brand": $0.brandName, "serving_size": "\($0.servingSize)","serving_size_original":"\($0.servingSizeOriginal)", "calorie": "\($0.calories)", "fat": "\($0.fat)", "saturated": "\($0.saturated)", "polyunsaturated": "\($0.polyunsaturated)", "monounsaturated": "\($0.monosaturated)", "trans": "\($0.trans)", "cholesterol": "\($0.cholesterol)", "sodium": "\($0.sodium)", "potassium": "\($0.potassium)", "carbs": "\($0.carbohydrates)", "fiber": "\($0.fiber)", "sugar": "\($0.sugar)", "protien": "\($0.protein)", "vitamin_a": "\($0.vitaminA)", "vitamin_c": "\($0.vitaminC)", "calcium": "\($0.calcium)", "iron": "\($0.iron)", "created_date": $0.createdDate, "status_id": $0.statusId, "unit": $0.unit, "meal_type":  $0.mealType.name, "when_delete": $0.dependentIds, "fym_dmp_type": $0.dailyMealType.dailyMealTypeName,"row_id":$0.foodRowId,"parent":$0.foodParentId,"focus":$0.foodFocus,"serving_size_fixed":$0.servingSizeFixed]
        }
        params["nutritional_plan"] = nutrionalPlanId as Any
        
        DailyMealPlanCreateResponse.logDailyMealPlan(params) { (error) -> () in
            
            completionHandler(error)
        }
        
    }
    
    func updateMealPlan(_ mealId:String, completionHandler: @escaping (_ error: NSError?) -> ()) {
        
        var params = [String: Any]()
        
        params["name"] = dailyMealPlanName as Any?
        params["coremeal"] = coremeal as Any?
        params["snacks"] = snack as Any?
        params["nutrition_plan"] = Int(FymUser.sharedFymUser.userNutritionType) as Any?
        params["calorie"] = nutritionMacroModel?.caloriesTotal as Any?
        params["carb"] = nutritionMacroModel?.carbsTotal as Any?
        params["fat"] = nutritionMacroModel?.fatTotal as Any?
        params["protien"] = nutritionMacroModel?.proteinTotal as Any?
        params["fiber"] = nutritionMacroModel?.fiberTotal as Any?
        params["detail"] = addedFoods.map {
            ["id": $0.id, "guid": $0.guid, "name": $0.name,"name_es": $0.name_es, "genre": $0.genre, "type": $0.mealType.name,
                "brand": $0.brandName, "serving_size": "\($0.servingSize)","serving_size_original":"\($0.servingSizeOriginal)", "calorie": "\($0.calories)", "fat": "\($0.fat)", "saturated": "\($0.saturated)", "polyunsaturated": "\($0.polyunsaturated)", "monounsaturated": "\($0.monosaturated)", "trans": "\($0.trans)", "cholesterol": "\($0.cholesterol)", "sodium": "\($0.sodium)", "potassium": "\($0.potassium)", "carbs": "\($0.carbohydrates)", "fiber": "\($0.fiber)", "sugar": "\($0.sugar)", "protien": "\($0.protein)", "vitamin_a": "\($0.vitaminA)", "vitamin_c": "\($0.vitaminC)", "calcium": "\($0.calcium)", "iron": "\($0.iron)", "created_date": $0.createdDate, "status_id": $0.statusId, "unit": $0.unit, "meal_type":  $0.mealType.name, "when_delete": $0.dependentIds, "fym_dmp_type": $0.dailyMealType.dailyMealTypeName, "row_id":$0.foodRowId,"parent":$0.foodParentId,"focus":$0.foodFocus,"serving_size_fixed":$0.servingSizeFixed]
        }
        params["nutritional_plan"] = nutrionalPlanId as Any?
        
        DailyMealPlanUpdateResponse.updateDailyMealPlan(mealId, params: params) { (error) -> () in
            completionHandler(error)
        }
        
    }
}
