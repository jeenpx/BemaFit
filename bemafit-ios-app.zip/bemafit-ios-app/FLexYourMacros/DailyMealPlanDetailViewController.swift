
//
//  DailyMealPlanDetailViewController.swift
//  FlexYourMacros
//
//  Created by Minimol BI on 17/11/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}


protocol SummaryCellDelegate {
    
    func selectSnacks(_ currentSnacks: Int)
    func selectMeals(_ currentMeals: Int)
    func selectRefresh()
    func selectReCalculate()
    func showUserProfile(_ userId: String)
    
}

class SummaryCell: UITableViewCell {
    
    @IBOutlet weak var imageViewProfileImage: UIImageView!
    @IBOutlet weak var labelProfileName: UILabel!
    @IBOutlet weak var labelUpdatedStatus: UILabel!
    @IBOutlet weak var labelSnacks: UILabel!
    @IBOutlet weak var labelMeals: UILabel!
    @IBOutlet weak var labelNotice: UILabel!
    @IBOutlet weak var buttonMeals: DailyMealButton!
    @IBOutlet weak var buttonSnacks: DailyMealButton!
    @IBOutlet weak var buttonRefresh: DailyMealButton!
    @IBOutlet weak var buttonRecalculateMeal: DailyMealButton!
    @IBOutlet weak var layoutConstraintF1Height: NSLayoutConstraint!
    
    
    @IBOutlet weak var layoutHeightRecalculateMeal: NSLayoutConstraint!
    
    @IBOutlet weak var viewRecalculate: UIView!
    
    @IBOutlet weak var viewRefresh: UIView!
    
    @IBOutlet weak var layoutHeightButtonRecalculate: NSLayoutConstraint!
    
    var showRecalculate = false
    var noOfMeals = 0.0
    var noOfSnacks = 0.0
    var isEditableMode = true
    
    var summaryCellDelegate: SummaryCellDelegate?
    
    
    var updatedMealTime = " "{
        didSet{
            let newDate = updatedMealTime.utcDateValue("yyyy-MM-dd HH:mm:ss")
            if let x = (newDate as NSDate?)?.timeAgo() {
                labelUpdatedStatus.text = &&"alert_title_update"+" "+x
            }else {
                labelUpdatedStatus.text = " "
            }
            
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if reuseIdentifier == "kSummaryHeader" {
            labelProfileName.text = AppConfiguration.sharedAppConfiguration.userDetails?.userUserName
            let imageURL = URL(string: (AppConfiguration.sharedAppConfiguration.userDetails?.userProfilePhoto as? String) ?? "")
            imageViewProfileImage.setImageWith(imageURL, placeholderImage:  UIImage(named:"FacebookIcon")!)
            
            labelProfileName.isUserInteractionEnabled = true
            imageViewProfileImage.isUserInteractionEnabled = true
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(SummaryCell.didTaplabelUserNameWithGesture(_:)))
            tapGesture.delegate = self
            
            let userImageTapGesture = UITapGestureRecognizer(target: self, action: #selector(SummaryCell.didTaplabelUserNameWithGesture(_:)))
            userImageTapGesture.delegate = self
            
            // add tap gesture to the username label and image
            labelProfileName.addGestureRecognizer(userImageTapGesture)
            
            imageViewProfileImage.addGestureRecognizer(tapGesture)
            
            
        }
        
        if reuseIdentifier == "kSummaryFooter" {
            layoutHeightRecalculateMeal.constant = showRecalculate == true ? 102 : 0
            labelNotice.isHidden = !showRecalculate
            
            let noOfMealString = NSMutableAttributedString(string: "\(Int(noOfMeals))", attributes: [NSFontAttributeName: UIFont.helveticaBold(15), NSForegroundColorAttributeName: isEditableMode ? UIColor.darkTextGrayColor() : UIColor.lightTextGrayColor()])
            noOfMealString.append(NSMutableAttributedString(string: &&" Meals", attributes: [NSFontAttributeName: UIFont.helvetica(15), NSForegroundColorAttributeName: UIColor.lightTextGrayColor()]))
            labelMeals.attributedText = noOfMealString
            
            let noOfSnackString = NSMutableAttributedString(string: "\(Int(noOfSnacks))", attributes: [NSFontAttributeName: UIFont.helveticaBold(15), NSForegroundColorAttributeName: isEditableMode ? UIColor.darkTextGrayColor() : UIColor.lightTextGrayColor()])
            noOfSnackString.append(NSMutableAttributedString(string: &&" Snacks", attributes: [NSFontAttributeName: UIFont.helvetica(15), NSForegroundColorAttributeName: UIColor.lightTextGrayColor()]))
            labelSnacks.attributedText = noOfSnackString
            
            //set the button refresh state color and image
            buttonRefresh.layer.borderColor = isEditableMode == true ?  UIColor.blueColorForDMP().cgColor : UIColor.grayColorDirectory().cgColor
            buttonRefresh.setTitleColor(isEditableMode == true ?  UIColor.blueColorForDMP() : UIColor.lightTextGrayColor(), for: UIControlState())
            buttonRefresh.setImage(isEditableMode == true ? UIImage(named: "RefreshBlueIcon") : UIImage(named: "RefreshGreyIcon"), for: UIControlState())
            buttonRefresh.isEnabled = isEditableMode
            buttonSnacks.isEnabled = isEditableMode
            buttonMeals.isEnabled = isEditableMode
        }
    }
    
    func configureView() {
        
    }
    
    func didTaplabelUserNameWithGesture(_ tapGesture: UITapGestureRecognizer) {
        //print("didTaplabelUserNameWithGesture entered...\(AppConfiguration.sharedAppConfiguration.userDetails?.userId)")
        self.summaryCellDelegate?.showUserProfile((AppConfiguration.sharedAppConfiguration.userDetails?.userId)!)
    }
    
    
    @IBAction func buttonActionMeals(_ sender: DailyMealButton) {
        
        self.summaryCellDelegate?.selectMeals(1)
    }
    
    @IBAction func buttonActionSnacks(_ sender: DailyMealButton) {
        
        self.summaryCellDelegate?.selectSnacks(1)
    }
    
    @IBAction func buttonActionRefresh(_ sender: DailyMealButton) {
        
        if noOfMeals == 0.0 {
            
            UIAlertView(title: &&"notice", message: &&"no_of_meals_zero", delegate: nil, cancelButtonTitle: &&"ok").show()
            return
        }
        
        
        
        self.summaryCellDelegate?.selectRefresh()
        
    }
    
    @IBAction func buttonActionRecalculate(_ sender: DailyMealButton) {
        
        self.summaryCellDelegate?.selectReCalculate()
        
    }
}

class DietItemNutritionCell: UITableViewCell {
    
    @IBOutlet weak var labelNutritionalPlan: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        NotificationCenter.default.addObserver(self, selector: #selector(DietItemNutritionCell.reloadNutritionPlan), name:NSNotification.Name(rawValue: "RefreshNutritionPlan"), object: nil)
    }
    
    func configureView() {
        
    }
    
    var nutritionPlan: NutritionPlanModel? {
        didSet {
            labelNutritionalPlan.text = nutritionPlan?.nutritionName
        }
    }
    
    func reloadNutritionPlan() {
        
        if FymUser.sharedFymUser.userNutritionType == "" {
            if let nutritionId = AppConfiguration.sharedAppConfiguration.userDiet?.dietNutritionalPlan {
                FymUser.sharedFymUser.userNutritionType = nutritionId
            }
        }
        
        nutritionPlan =  AppConfiguration.sharedAppConfiguration.nutritionPlans.filter { $0.nutritionId! == FymUser.sharedFymUser.userNutritionType }.first!
        DailyMealPlan.sharedDailyMealPlan.nutrionalPlanId = nutritionPlan!.nutritionId!.intValue
        AppConfiguration.sharedAppConfiguration.userDiet?.dietNutritionalPlan = String(DailyMealPlan.sharedDailyMealPlan.nutrionalPlanId)
        
    }
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        reloadNutritionPlan()
    }
}

class DietItemCalorieCell: UITableViewCell, UITextFieldDelegate {
    
    
    @IBOutlet weak var labelCalorieTarget: UILabel!
    
    @IBOutlet weak var textFieldCalorieValue: UITextField!
    var dietMacroItem = [String : String]() {
        
        didSet {
            
            labelCalorieTarget.text = dietMacroItem.keys.first
            textFieldCalorieValue.text  = dietMacroItem[dietMacroItem.keys.first!]
            
        }
    }
    
    @IBAction func editedValue(_ sender: UITextField) {
        
        
        
        
        if sender.text == "" {
            
            return;
        }
        
        
        DailyMealPlan.sharedDailyMealPlan.nutritionMacroModel?.caloriesTotal = sender.text ?? "0.0"
    }
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func configureView() {
        
    }
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        self.textFieldCalorieValue.delegate = self
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        var result = true
        let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        if string.characters.count > 0 {
            let disallowedCharacterSet = CharacterSet(charactersIn: "0123456789").inverted
            let replacementStringIsLegal = string.rangeOfCharacter(from: disallowedCharacterSet) == nil
            let resultingStringLengthIsLegal = prospectiveText.characters.count <= 10
            let scanner = Scanner(string: prospectiveText)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
            result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
        }
        return result
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
    
}

enum DietMacroCellMode {
    case protein
    case carbs
    case fat
}
var selectionMode : String = ""
class DietItemMacroCell: UITableViewCell, UITextFieldDelegate {
    
    @IBOutlet weak var labelMacro: UILabel!
    @IBOutlet weak var textFieldMacroValue: UITextField!
    var dietMacroCellMode = DietMacroCellMode.protein
    var isNutritionCell : Bool = false
    var dietMacroItem = [String : String]() {
        
        didSet {
            
            labelMacro.text = dietMacroItem.keys.first
            textFieldMacroValue.text  = dietMacroItem[dietMacroItem.keys.first!]
            
            let cellTitle = dietMacroItem.keys.first!
            switch cellTitle {
            case &&"proteins":
                dietMacroCellMode = DietMacroCellMode.protein
            case &&"carbohydrates":
                dietMacroCellMode = DietMacroCellMode.carbs
            case &&"fats":
                dietMacroCellMode = DietMacroCellMode.fat
            default: break
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func configureView() {
        
    }
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        textFieldMacroValue.delegate = self
        
        let cellTitle = dietMacroItem.keys.first!
        //        if cellTitle == &&"proteins" {
        //            textFieldMacroValue.becomeFirstResponder()
        //        }
        if DailyMealPlan.sharedDailyMealPlan.canEditProfile
        {
            if selectionMode != "Nutrition Summary" {
                if cellTitle == &&"proteins" {
                    textFieldMacroValue.becomeFirstResponder()
                }
            }
            //            else
            //            {
            //                textFieldMacroValue.resignFirstResponder()
            //            }
        }
        
    }
    
    @IBAction func editedMacroValue(_ sender: UITextField) {
        
        if sender.text == "" {
            
            return;
        }
        switch dietMacroCellMode {
        case .protein:
            DailyMealPlan.sharedDailyMealPlan.nutritionMacroModel?.proteinTotal = sender.text ?? "0.0"
        case .carbs:
            DailyMealPlan.sharedDailyMealPlan.nutritionMacroModel?.carbsTotal = sender.text ?? "0.0"
        case .fat:
            DailyMealPlan.sharedDailyMealPlan.nutritionMacroModel?.fatTotal = sender.text ?? "0.0"
        }
        
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        var result = true
        let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        if string.characters.count > 0 {
            let disallowedCharacterSet = CharacterSet(charactersIn: "0123456789").inverted
            let replacementStringIsLegal = string.rangeOfCharacter(from: disallowedCharacterSet) == nil
            let resultingStringLengthIsLegal = prospectiveText.characters.count <= 10
            let scanner = Scanner(string: prospectiveText)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
            result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
        }
        return result
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
}

protocol DietCellDelegate {
    
    func editDiet(_ dietCell: DietCell)
    
}

enum DietCellMode {
    case summary
    case nutrition
}
class DietCell: UITableViewCell {
    
    @IBOutlet weak var buttonEdit: UIButton!
    @IBOutlet weak var labelDietProfile: UILabel!
    @IBOutlet weak var imageViewDirection: UIImageView!
    @IBOutlet weak var dietTableView: UITableView!
    @IBOutlet weak var layoutConstraintTableHeight: NSLayoutConstraint!
    var nutritionPlan: NutritionPlanModel?
    var isEditableMode = true
    
    var dietCellDelegate: DietCellDelegate?
    var shouldOpen = true
    
    var profileMacroArray = [[String:String]]()
    var mealPlanMacroArray = [[String:String]]()
    //    var firstResponderField : UITextField!
    var mealPlanNutritionSummary = DailyNutritionSummary() {
        
        didSet {
            mealPlanMacroArray = [[&&"calories": mealPlanNutritionSummary.calories.stringValue], [&&"proteins": mealPlanNutritionSummary.protien.stringValue], [&&"carbohydrates": mealPlanNutritionSummary.carbohydrates.stringValue], [&&"fats": mealPlanNutritionSummary.fat.stringValue], [&&"sugar": mealPlanNutritionSummary.sugar.stringValue]]
            dietTableView.reloadData()
            
        }
    }
    
    var dietCellMode = DietCellMode.summary
    var macroDetails = MacroModel() {
        didSet {
            profileMacroArray = [[&&"calories": macroDetails.caloriesTotal], [&&"proteins": macroDetails.proteinTotal], [&&"carbohydrates": macroDetails.carbsTotal], [&&"fats": macroDetails.fatTotal]]
        }
    }
    
    struct Storyboard {
        struct CellIdentifiers {
            static let DietNutritionalPlanCellIdentifier = "kDietNutritionalPlan"
            static let DietCalorieCellIdentifier = "kDietCalorie"
            static let DietMacroCellIdentifier = "kDietMacro"
            static let DietSugarCellIdentifier = "kDietSugar"
        }
        struct Segues {
            
        }
        struct Nibs {
        }
        struct Sections {
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func configureView() {
        
    }
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        dietTableView.reloadData()
        
        layoutConstraintTableHeight.constant = shouldOpen == true ? dietTableView.contentSize.height : 0
        imageViewDirection.image = shouldOpen == true ? UIImage(named: "DownArrowBlue") : UIImage(named: "RightArrowBlueIcon")
        labelDietProfile.text = dietCellMode == DietCellMode.summary ? &&"current_diet_profile" : &&"nutrition_summary"
        buttonEdit.isHidden = (dietCellMode == DietCellMode.nutrition || !isEditableMode)
        buttonEdit.alpha = DailyMealPlan.sharedDailyMealPlan.canEditProfile ? 0.5 : 1.0
    }
    
    @IBAction func buttonActionEdit(_ sender: UIButton) {
        
        if !shouldOpen {
            return
        }
        //        firstResponderField.becomeFirstResponder()
        DailyMealPlan.sharedDailyMealPlan.canEditProfile  = !DailyMealPlan.sharedDailyMealPlan.canEditProfile
        sender.alpha = DailyMealPlan.sharedDailyMealPlan.canEditProfile ? 0.5 : 1.0
        dietTableView.reloadData()
        self.dietCellDelegate?.editDiet(self)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAtIndexPath indexPath: IndexPath) -> CGFloat {
        
        var cellHeight: CGFloat = 0.0
        
        if dietCellMode == DietCellMode.summary {
            
            if indexPath.row == 0 {
                
                let currentCell = self.tableView(tableView, dietNutritionalPlanCellForRowAtIndexPath: indexPath)
                cellHeight =  currentCell.frame.size.height
                
            } else if indexPath.row == 1 {
                
                let currentCell = self.tableView(tableView, dietCalorieCellForRowAtIndexPath: indexPath )
                
                cellHeight =  currentCell.frame.size.height
                
            } else {
                
                let currentCell = self.tableView(tableView, dietMacroCellForRowAtIndexPath: indexPath)
                cellHeight =  currentCell.frame.size.height
                
            }
        } else if dietCellMode == DietCellMode.nutrition {
            
            if indexPath.row == 0 {
                
                let currentCell = self.tableView(tableView, dietCalorieCellForRowAtIndexPath: indexPath)
                
                cellHeight =  currentCell.frame.size.height
                
            } else {
                
                let currentCell = self.tableView(tableView, dietMacroCellForRowAtIndexPath: indexPath)
                cellHeight =  currentCell.frame.size.height
            }
        }
        return cellHeight
    }
    
    func numberOfSectionsInTableView(_ tableView: UITableView) -> Int {
        return shouldOpen == true ? 1 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return shouldOpen == true ? dietCellMode == DietCellMode.summary ? profileMacroArray.count + 1 : mealPlanMacroArray.count : 0
    }
    
    func tableView(_ tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: IndexPath) {
        
        cell.setSeparatorInsetZero()
    }
    
    func tableView(_ tableView: UITableView, canEditRowAtIndexPath indexPath: IndexPath) -> Bool {
        return false
    }
    
    func tableView(_ tableView: UITableView, cellForRowAtIndexPath indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell
        
        switch dietCellMode {
        case .summary:
            if indexPath.row == 0 {
                cell = self.tableView(tableView, dietNutritionalPlanCellForRowAtIndexPath: indexPath)
            } else if indexPath.row == 1 {
                cell = self.tableView(tableView, dietCalorieCellForRowAtIndexPath: indexPath)
            } else {
                cell = self.tableView(tableView, dietMacroCellForRowAtIndexPath: indexPath)
            }
            
        case .nutrition:
            
            if indexPath.row == 0 {
                cell = self.tableView(tableView, dietCalorieCellForRowAtIndexPath: indexPath)
            } else {
                cell = self.tableView(tableView, dietMacroCellForRowAtIndexPath: indexPath)
                
            }
        }
        cell.transform = tableView.transform
        
        return cell
    }
    
    func tableView(_ tableView:UITableView, dietNutritionalPlanCellForRowAtIndexPath indexPath: IndexPath) -> DietItemNutritionCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.DietNutritionalPlanCellIdentifier) as! DietItemNutritionCell
        // configure cell
        //        cell.nutritionPlan = nutritionPlan
        return cell
    }
    
    func tableView(_ tableView:UITableView, dietCalorieCellForRowAtIndexPath indexPath: IndexPath) -> DietItemCalorieCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.DietCalorieCellIdentifier) as! DietItemCalorieCell
        if dietCellMode == DietCellMode.summary {
            cell.dietMacroItem = profileMacroArray[indexPath.row - 1]
            cell.textFieldCalorieValue.isUserInteractionEnabled = DailyMealPlan.sharedDailyMealPlan.canEditProfile
            
        } else {
            
            cell.dietMacroItem = mealPlanMacroArray[indexPath.row]
            
        }
        //cell.isNutritionCell = false
        // configure cell
        return cell
    }
    
    func tableView(_ tableView:UITableView, dietMacroCellForRowAtIndexPath indexPath: IndexPath) -> DietItemMacroCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.DietMacroCellIdentifier) as! DietItemMacroCell
        if dietCellMode == DietCellMode.summary {
            
            cell.dietMacroItem = profileMacroArray[indexPath.row - 1]
            cell.textFieldMacroValue.isUserInteractionEnabled = DailyMealPlan.sharedDailyMealPlan.canEditProfile
            cell.isNutritionCell = true
            
        } else {
            
            cell.dietMacroItem = mealPlanMacroArray[indexPath.row]
            cell.isNutritionCell = false
        }
        
        // configure cell
        return cell
    }
    
    
}

protocol DailyMealTypeCellDelegate {
    
    func dailyMealTypeHeader(_ logHeaderView: DailyMealTypeCell, infoButtonClickedForMealType mealType: MealType)
}

class DailyMealTypeCell: UITableViewCell {
    
    @IBOutlet weak var labelMealType: UILabel!
    var dailyMealTypeCellDelegate: DailyMealTypeCellDelegate?
    var dailyMealType: DailyMealType = DailyMealType(dailyMealTypeName: "") {
        didSet {
            //using the original code by Anand in "dailyMealType.dailyMealTypeName"s definition
            let tempMealTypeName = dailyMealType.dailyMealTypeName
            let tempValue  = tempMealTypeName.substring(to: tempMealTypeName.characters.index(before: tempMealTypeName.endIndex))
            let lastCharacter = tempMealTypeName.substring(from: tempMealTypeName.characters.index(before: tempMealTypeName.endIndex))
            
//            self.dailyMealTypeName = dailyMealTypeName //old Code changed Anand
            let mealType = &&tempValue + lastCharacter//hiden by Chandrachudh F22 Labs
            
            labelMealType.text = dailyMealType.id != "3" ? mealType + " (\(dailyMealType.name))" : dailyMealType.dailyMealTypeName
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func configureView() {
        
    }
    
    @IBAction func buttonActionMealTypeInfo(_ sender: UIButton) {
        self.dailyMealTypeCellDelegate?.dailyMealTypeHeader(self, infoButtonClickedForMealType: dailyMealType.mealType)
    }
    
}


protocol DailyMealTypeFooterCellDelegate {
    func addItemToMealType(_ dailyMealType: DailyMealType)
}
class DailyMealTypeFooterCell: UITableViewCell {
    
    @IBOutlet weak var buttonAddItem: UIButton!
    var dailyMealTypeFooterCellDelegate: DailyMealTypeFooterCellDelegate?
    var dailyMealType: DailyMealType = DailyMealType(dailyMealTypeName: "")
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func configureView() {
        
    }
    
    @IBAction func buttonActionAddItem(_ sender: UIButton) {
        self.dailyMealTypeFooterCellDelegate?.addItemToMealType(dailyMealType)
        
    }
}

protocol DailyMealTypeItemCellDelegate {
    
    func dailyMealTypeItemRefreshItem(_ mealTypeItemCell: DailyMealTypeItemCell, refreshFood food: Food)
    func dailyMealTypeItemDeleteItem(_ mealTypeItemCell: DailyMealTypeItemCell, deleteFood food: Food)
}

class DailyMealTypeItemCell: MGSwipeTableCell, MGSwipeTableCellDelegate {
    
    
    
    typealias FoodSeletectedCallBack = (_ addFood : Bool,  _ food : Food, _ indexPath : IndexPath?) ->()
    @IBOutlet weak var labelMealItemName: UILabel!
    @IBOutlet weak var labelMealItemDetail: UILabel!
    @IBOutlet weak var imageViewDrag: UIImageView!
    @IBOutlet weak var buttonSelect: UIButton!
    @IBOutlet weak var lcBtnLogWidth: NSLayoutConstraint!
    
    
    var buttonDelete:MGSwipeButton?
    var buttonRefresh:MGSwipeButton?
    var indexPath : IndexPath?
    var onFoodSelectBlock:FoodSeletectedCallBack?
    var editModeEnabled:Bool = false{
        
        didSet {
            
            self.buttonSelect.isHidden = editModeEnabled
        }
    }
    
    func configureView() {
        if editModeEnabled == true {
            lcBtnLogWidth.constant = 0
        }
        else {
            lcBtnLogWidth.constant = 40
        }
        self.layoutIfNeeded()
    }
    
    var dailyMealTypeItemCellDelegate: DailyMealTypeItemCellDelegate?
    @IBAction func buttonActionSelect(_ sender: UIButton) {
        toggleSelection()
        self.onFoodSelectBlock?(buttonSelect.isSelected, self.food, self.indexPath)
    }
    
    func toggleSelection() {
        buttonSelect.isSelected = !buttonSelect.isSelected
        
        
    }
    var food = Food() {
        didSet {
            
            let locale:String? = ((Locale.current as NSLocale).object(forKey: NSLocale.Key.languageCode)) as? String
            
            labelMealItemName.text = (locale ?? "" == "es" && (String(food.name_es).trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).characters.count) > 0 ) ? food.name_es : food.name
            
            if food.foodRowId == "-1"{
                buttonRefresh?.backgroundColor = UIColor.lightGrayColorButtonRefersh()
                
            }
            else{
                buttonRefresh?.backgroundColor = UIColor.darkTextGrayColor()
                
            }
            
            var foodNcal = food.calories * food.servingSize
            
            labelMealItemDetail.text = "\(food.servingSize.roundPlaces(2)) " + &&"servings" + ". "+"\(foodNcal.roundPlaces(2)) " + &&"calories"
            labelMealItemName.textColor = (food.servingSize < 0.25) ? UIColor.red : labelMealItemDetail.textColor
            
            self.contentView.layer.borderColor = food.isRefreshed ? UIColor.defaultThemeDarkBlueColor().cgColor : UIColor.clear.cgColor
            self.contentView.layer.borderWidth = food.isRefreshed ? 1.0 : 0.0
            
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        // configure the cell
        configureCell()
    }
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
    }
    
    func configureCell() {
        
        
        // set swipable cell delegate
        delegate = self
        
        // configure the right utility buttons
        
        self.buttonDelete = MGSwipeButton(title: &&"message_swipe_delete_title", backgroundColor: UIColor.defaultThemeDarkBlueColor()) { (cell) -> Bool in
            
            return true
        }
        self.buttonDelete?.setTitleColor(UIColor.white, for: UIControlState())
        self.buttonDelete?.titleLabel?.font = UIFont.helveticaBold(15)
        
        rightButtons = [buttonDelete!]
        rightSwipeSettings.transition = MGSwipeTransition.border
        
        //configure the left utility button
        let buttonImage = UIImage(named: "RefreshGreyIcon")
        self.buttonRefresh = MGSwipeButton(title: "", icon: buttonImage, backgroundColor: UIColor.darkTextGrayColor(), padding: 30) { (cell) -> Bool in
            return false
        }
        leftButtons = [buttonRefresh!]
        leftSwipeSettings.transition = MGSwipeTransition.static
        leftExpansion.expansionLayout = MGSwipeExpansionLayout.center
        
    }
    
    
    func swipeTableCell(_ cell: MGSwipeTableCell!, canSwipe direction: MGSwipeDirection) -> Bool {
        return self.editModeEnabled
    }
    
    func swipeTableCell(_ cell: MGSwipeTableCell!, tappedButtonAt index: Int, direction: MGSwipeDirection, fromExpansion: Bool) -> Bool {
        
        // hide buttons
        cell.hideSwipe(animated: true)
        
        if direction == MGSwipeDirection.leftToRight {
            dailyMealTypeItemCellDelegate?.dailyMealTypeItemRefreshItem(self, refreshFood: food)
        }
        else if direction == MGSwipeDirection.rightToLeft {
            dailyMealTypeItemCellDelegate?.dailyMealTypeItemDeleteItem(self, deleteFood: food)
        }
        
        return true
    }
    
    @IBAction func buttonActionFoodlog(_ sender: DailyMealButton) {
        
        food.logFood(food.mealType.id, mealDate: Date(), userGuid: AppConfiguration.sharedAppConfiguration.userDetails!.userId!) { (error) -> () in
            //print("logged food")
            
            // load view log
        }
        
    }
}

class DailyNutritionSummary: NSObject {
    
    var calories = 0.0
    var fat = 0.0
    var saturated = 0.0
    var polyUnsaturated = 0.0
    var monoSaturated = 0.0
    var trans = 0.0
    var cholesterol = 0.0
    var sodium = 0.0
    var carbohydrates = 0.0
    var fiber = 0.0
    var protien = 0.0
    var potassium = 0.0
    var sugar = 0.0
}

enum mealPlanDetailPageMode {
    
    case newMealPlan
    case editingMealPlan
    case logMealPlan
}

class DailyMealPlanDetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, DietCellDelegate, SummaryCellDelegate, DailyMealTypeCellDelegate, DailyMealTypeFooterCellDelegate, SWTableViewCellDelegate, UIActionSheetDelegate, MealTypeInfoViewDelegate, UITableViewDragLoadDelegate, DragAndDropTableViewDataSource, DragAndDropTableViewDelegate, DailyMealTypeItemCellDelegate,RefreshoodPickerDelegate {
    
    var dailyMealPlanModelSelected : DailyMealPlanResponseModel?
    var selectedFoodArray: [IndexPath : Food]  = [:]
    var PDFCreator: NDHTMLtoPDF = NDHTMLtoPDF()
    enum ActionSheetMode: String {
        case Share = "daily_meal_plan_share"
        case Meals = "how_many_meals"
        case Snacks = "how_many_snacks"
        
        init(rawValue : String)
        {
            self = ActionSheetMode(rawValue: rawValue)
        }
    }
    var pageMode = mealPlanDetailPageMode.newMealPlan
    var mealPlanId: String = ""
    var isEditableMode = true
    var logFoodArray = [Food]()
    var foodToDelete : Food?
    var foodToAdd : Food?
    var foodtoDeleteLocalId : Int?
    var replacementFoods = [Food]()
    var replaceFoodIndex:Int = 0
    
    @IBOutlet weak var buttonRigfhtNavigation: UIBarButtonItem!
    @IBOutlet var mealTypeInfoView: MealTypeInfoView!
    @IBOutlet weak var buttonShare: UIButton!
    @IBOutlet weak var butonLog: UIButton!
    @IBOutlet weak var buttonDelteEdit: UIButton!
    @IBOutlet weak var buttonDeleteNew: UIButton!
    
    @IBOutlet weak var tableView: DragAndDropTableView!
    var statusArray = [false, false];
    var dietCellMode = [DietCellMode.summary, DietCellMode.nutrition]
    
    // for the purpose of pdf
    var mealInfo:[DailyMealFoodModel] = [DailyMealFoodModel]()
    // offset
    var offsetValue:Int!
    
    var actionSheetMode = ActionSheetMode.Share
    
    var userMealTypes = [DailyMealType]() {
        didSet {
            
            self.sortFoodLogArray(self.foodArray)
        }
    }
    var mealData = [DailyMealType]()
    var isDailyMealPlan = true
    var showRecalculate = false
    var isRefreshed = false
    
    var updatedMealDate = " "
    
    var mealNutritionSummary = DailyNutritionSummary()
    var snackNutritionSummary = DailyNutritionSummary()
    
    var mealPlanSelectedNutrition: NutritionPlanModel {
        
        if pageMode == mealPlanDetailPageMode.newMealPlan {
            
            if let nutritionId = AppConfiguration.sharedAppConfiguration.userDiet?.dietNutritionalPlan {
                FymUser.sharedFymUser.userNutritionType = nutritionId
            }
        } else {
            
            let mealPlanNutritionId = "\(dailyMealPlan.nutrionalPlanId)"
            FymUser.sharedFymUser.userNutritionType = mealPlanNutritionId
        }
        
        return AppConfiguration.sharedAppConfiguration.nutritionPlans.filter { $0.nutritionId! == FymUser.sharedFymUser.userNutritionType }.first!
        
    }
    
    var mealTotalNutritionSummary: DailyNutritionSummary {
        
        let tempTotalSummary = DailyNutritionSummary()
        tempTotalSummary.calories = mealNutritionSummary.calories + snackNutritionSummary.calories
        tempTotalSummary.fat = mealNutritionSummary.fat + snackNutritionSummary.fat
        tempTotalSummary.saturated = mealNutritionSummary.saturated + snackNutritionSummary.saturated
        tempTotalSummary.polyUnsaturated = mealNutritionSummary.polyUnsaturated + snackNutritionSummary.polyUnsaturated
        tempTotalSummary.monoSaturated = mealNutritionSummary.monoSaturated + snackNutritionSummary.monoSaturated
        tempTotalSummary.trans = mealNutritionSummary.trans + snackNutritionSummary.trans
        tempTotalSummary.cholesterol = mealNutritionSummary.cholesterol + snackNutritionSummary.cholesterol
        tempTotalSummary.sodium = mealNutritionSummary.sodium + snackNutritionSummary.sodium
        tempTotalSummary.carbohydrates = mealNutritionSummary.carbohydrates + snackNutritionSummary.carbohydrates
        tempTotalSummary.fiber = mealNutritionSummary.fiber + snackNutritionSummary.fiber
        tempTotalSummary.protien = mealNutritionSummary.protien + snackNutritionSummary.protien
        tempTotalSummary.potassium = mealNutritionSummary.potassium + snackNutritionSummary.potassium
        tempTotalSummary.sugar = mealNutritionSummary.sugar + snackNutritionSummary.sugar
        
        return tempTotalSummary
    }
    
    var foodArray = [Food]() {
        didSet {
            
            mealNutritionSummary.calories = getMealMacros().totalMealCalorie
            mealNutritionSummary.protien = getMealMacros().totalMealProtein
            mealNutritionSummary.carbohydrates = getMealMacros().totalMealCarbs
            mealNutritionSummary.fat = getMealMacros().totalMealFat
            mealNutritionSummary.fiber = getMealMacros().totalMealFiber
            mealNutritionSummary.sugar = getMealMacros().totalMealSugar
            
            snackNutritionSummary.calories = getSnackMacros().totalSnackCalorie
            snackNutritionSummary.protien = getSnackMacros().totalSnackProtein
            snackNutritionSummary.carbohydrates = getSnackMacros().totalSnackCarbs
            snackNutritionSummary.fat = getSnackMacros().totalSnackFat
            snackNutritionSummary.fiber = getSnackMacros().totalSnackFiber
            snackNutritionSummary.sugar = getSnackMacros().totalSnackSugar
            
            dailyMealPlan.addedFoods = foodArray
            self.sortFoodLogArray(self.foodArray)
        }
    }
    
    var draggedFood: Food?
    
    var targetCalorie: Double {
        
        return self.dailyMealPlan.nutritionMacroModel?.caloriesTotal.doubleValue ?? 0.0
    }
    var targetProtein: Double {
        
        return self.dailyMealPlan.nutritionMacroModel?.proteinTotal.doubleValue ?? 0.0
    }
    
    var targetCarbs: Double {
        
        return self.dailyMealPlan.nutritionMacroModel?.carbsTotal.doubleValue ?? 0.0
    }
    
    var targetFat: Double {
        
        return self.dailyMealPlan.nutritionMacroModel?.fatTotal.doubleValue ?? 0.0
    }
    
    var targetSugar:Double {
        return self.dailyMealPlan.nutritionMacroModel?.sugarTotal.doubleValue ?? 0.0
    }
    
    
    var noOfMeals: Double = 3.0 {
        didSet {
            dailyMealPlan.coremeal = noOfMeals
            
            self.fetchMealTypes({ (fetchedSuccessfully) -> () in
                
            })
        }
    }
    
    var noOfSnacks: Double = 2.0 {
        didSet {
            dailyMealPlan.snack = noOfSnacks
            
            self.fetchMealTypes({ (fetchedSuccessfully) -> () in
                
            })
            
        }
    }
    
    let dailyMealPlan = DailyMealPlan.sharedDailyMealPlan
    
    var mealMacroSplitOffPercentage: Double {
        
        return self.noOfSnacks ==  0.0 ? 100.0 : 80.0
    }
    var snackMacroSplitOffPercentage: Double {
        
        return self.noOfSnacks ==  0.0 ? 0.0 : 20.0
    }
    
    struct Storyboard {
        struct CellIdentifiers {
            static let SummaryHeaderCellIdentifier = "kSummaryHeader"
            static let DietHeaderCellIdentifier = "kDietHeader"
            static let SummaryFooterCellIdentifier = "kSummaryFooter"
            static let MealTypeHeaderCellIdentifier = "kMealTypeHeader"
            static let MealTypeItemCellIdentifier = "kMealTypeItem"
            static let MealTypeFooterCellIdentifier = "kMealTypeFooter"
        }
        struct Segues {
            static let CreateNewMealSegueIdentifier = "kCreateNewMeal"
            static let NutritionSegueIdentifier = "kSelectNutritionSegue"
        }
        struct Nibs {
        }
        struct Sections {
        }
    }
    
    var macroDetails = MacroModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.estimatedRowHeight = UITableViewAutomaticDimension
        
        // hide empty tableview cells
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        
        //        tableView.setDragDelegate(self, refreshDatePermanentKey: "kPlan")
        
        configureFooterButtons()
        MacroModel.refreshUserMacros(Date(), completionHnadler: { (achievedMacroGoal) -> () in
            self.dailyMealPlan.nutritionMacroModel = achievedMacroGoal
            
            
            if self.pageMode == mealPlanDetailPageMode.newMealPlan {
                //fetch user meal types
                
                self.dailyMealPlan.coremeal = self.noOfMeals
                self.dailyMealPlan.snack = self.noOfSnacks
                self.fetchMealTypes({ (fetchedSuccessfully) -> () in
                    //                self.foodArray.removeAll()
                })
                
            } else if self.pageMode == mealPlanDetailPageMode.editingMealPlan || self.pageMode == mealPlanDetailPageMode.logMealPlan {
                
                self.fetchDetailsOfMealPlan()
            }
            
            
            
        })
        
        
    }
    
    func configureFooterButtons() {
        
        butonLog.setTitle(pageMode == mealPlanDetailPageMode.editingMealPlan ? &&"Log" : &&"Edit", for: UIControlState())
        butonLog.isHidden = pageMode == mealPlanDetailPageMode.newMealPlan
        buttonDelteEdit.isHidden = pageMode == mealPlanDetailPageMode.newMealPlan
        buttonShare.isHidden = pageMode == mealPlanDetailPageMode.newMealPlan
        
        buttonDeleteNew.isHidden = pageMode != mealPlanDetailPageMode.newMealPlan
        
        isEditableMode = pageMode != mealPlanDetailPageMode.logMealPlan
        
        buttonRigfhtNavigation.title = pageMode == mealPlanDetailPageMode.logMealPlan ? &&"Log" : &&"Save"
        
        self.dailyMealPlan.canEditProfile = isEditableMode
        
        self.tableView.reloadData()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.tableView.translatesAutoresizingMaskIntoConstraints = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func fetchMealTypes(_ completionHandler:@escaping (_ fetchedSuccessfully: Bool) -> ()) {
        
        
        DailyMealType.fetchDailyMealTypeList("\(noOfMeals)", snackMealNo: "\(noOfSnacks)", showHUD: true) { (dailyMealTypes) -> () in
            
            self.userMealTypes = dailyMealTypes
            
            completionHandler(true)
        }
        
    }
    
    
    
    func fetchDailyMealFood(_ shouldReloadData: Bool = true) {
        
        
        if userMealTypes.isEmpty {
            
            fetchMealTypes({ (fetchedSuccessfully) -> () in
                if fetchedSuccessfully {
                    
                    DailyMealPlan.fetchFoodDailyMeal("\(self.noOfMeals)", snackNo: "\(self.noOfSnacks)", calories: "\(self.targetCalorie)", carbs: "\(self.targetCarbs)", proteins: "\(self.targetProtein)", fats: "\(self.targetFat)", showHUD: true, nutritionPlan: String(DailyMealPlan.sharedDailyMealPlan.nutrionalPlanId),completionHandler: { (loggedFoods) -> () in
                        
                        self.foodArray = loggedFoods
                        self.showCautionAlertIfFoodsAreRemoved()
                    })
                    
                }
            })
        } else {
            
            DailyMealPlan.fetchFoodDailyMeal("\(self.noOfMeals)", snackNo: "\(self.noOfSnacks)", calories: "\(self.targetCalorie)", carbs: "\(self.targetCarbs)", proteins: "\(self.targetProtein)", fats: "\(self.targetFat)", showHUD: true, nutritionPlan: String(DailyMealPlan.sharedDailyMealPlan.nutrionalPlanId), completionHandler: { (loggedFoods) -> () in
                
                self.foodArray = loggedFoods
                self.showCautionAlertIfFoodsAreRemoved()
            })
        }
        
    }
    func showCautionAlertIfFoodsAreRemoved() -> (){
        
        
        
        
        
        
        if let emptyMealTypes = self.returnEmptyMealTypes(){
            // TODO: add spanish version for the alert
            self.view.makeToast(&&"algorithm_not_able_to_genrate1" + " " + emptyMealTypes + " " + &&"algorithm_not_able_to_genrate2" , duration: 7.0, position: CSToastPositionCenter);
        }
        
        
        
        
    }
    
    func returnEmptyMealTypes() -> String! {
        
        
        let sortedMealTypes = (self.userMealTypes.map{ return $0.dailyMealTypeName })
        let mealTypesSuggested = Set(self.foodArray.map{ return $0.dailyMealType.dailyMealTypeName })
        let mealTypesRequested = Set(sortedMealTypes)
        let mealNotListed = mealTypesRequested.subtracting(mealTypesSuggested).sorted(by: DailyMealPlanUtils.compareMealType)
        //print(mealNotListed)
        
        return mealNotListed.count == 0 || mealNotListed.count == mealTypesRequested.count ? nil : mealNotListed.joined(separator: ", ")//mealNotListed[0...mealNotListed.count-2].joinWithSeparator(", ") + "and " + mealNotListed[mealNotListed.count-1] + " "
        
        
        
    }
    
    func compareMealType(_ a : String, b : String) -> Bool{
        
        
        let string1Alpha:String = (a.components(separatedBy: CharacterSet.decimalDigits) as NSArray).componentsJoined(by: "")
        let string2Alpha:String = (b.components(separatedBy: CharacterSet.decimalDigits) as NSArray).componentsJoined(by: "")
        
        if string1Alpha != string2Alpha{ // compare two different meal names eg: coremeal1 n snack 2
            return a < b
        }
        
        let string1Numeric:String = (a.components(separatedBy: CharacterSet.letters) as NSArray).componentsJoined(by: "")
        let string2Numeric:String = (b.components(separatedBy: CharacterSet.letters) as NSArray).componentsJoined(by: "")
        
        // compare the numeric of same type of coremeals eg : snack10 and snack2
        return Int(string1Numeric) < Int(string2Numeric)
        
    }
    func combineArrayWithCommaAnd(_ a : String, b : String) -> String{
        return ""
    }
    
    func fetchDetailsOfMealPlan() {
        
        if userMealTypes.isEmpty {
            
            fetchMealTypes({ (fetchedSuccessfully) -> () in
                if fetchedSuccessfully {
                    
                    DailyMealPlanItemDetailResponse.fetchMealPlanDetail(self.mealPlanId, showHUD: true) { (dailyMealPlanResponseModel : DailyMealPlanResponseModel?, error) -> () in
                        
                        if dailyMealPlanResponseModel != nil {
                            self.dailyMealPlanModelSelected = dailyMealPlanResponseModel
                            let tempArray = dailyMealPlanResponseModel!.mealPlanFoods as [DailyMealFoodModel]
                            let foodLogs = (dailyMealPlanResponseModel!.mealPlanFoods as [DailyMealFoodModel]).map { Food(dailyMealFoodModel: $0) }
                            self.mealInfo = dailyMealPlanResponseModel!.mealPlanFoods as [DailyMealFoodModel]
                            
                            self.noOfMeals = dailyMealPlanResponseModel!.mealCoreNo.doubleValue
                            self.noOfSnacks = dailyMealPlanResponseModel!.mealSnackNo.doubleValue
                            self.dailyMealPlan.dailyMealPlanName = dailyMealPlanResponseModel!.mealPlanName
                            self.dailyMealPlan.dailyMealPlanId = dailyMealPlanResponseModel!.mealPlanGuid
                            self.updatedMealDate = dailyMealPlanResponseModel!.mealUpdatedDate
                            self.dailyMealPlan.nutrionalPlanId = Int(dailyMealPlanResponseModel!.mealNutritionId) ?? 0
                            self.dailyMealPlan.nutritionMacroModel?.caloriesTotal = dailyMealPlanResponseModel!.mealCalorie
                            self.dailyMealPlan.nutritionMacroModel?.carbsTotal = dailyMealPlanResponseModel!.mealCarb
                            self.dailyMealPlan.nutritionMacroModel?.fatTotal = dailyMealPlanResponseModel!.mealFat
                            self.dailyMealPlan.nutritionMacroModel?.proteinTotal = dailyMealPlanResponseModel!.mealProtein
                            self.dailyMealPlan.nutritionMacroModel?.fiberTotal = dailyMealPlanResponseModel!.mealFibre
                            self.dailyMealPlan.nutritionMacroModel?.sugarTotal = dailyMealPlanResponseModel!.mealSugar
                            
                            self.foodArray = foodLogs
                            
                            
                            self.fetchMealTypes({ (fetchedSuccessfully) -> () in
                                
                            })
                            
                        }
                    }
                    
                }
            })
        } else {
            
            DailyMealPlanItemDetailResponse.fetchMealPlanDetail(self.mealPlanId, showHUD: true) { (dailyMealPlanResponseModel, error) -> () in
                
                if dailyMealPlanResponseModel != nil {
                    self.dailyMealPlanModelSelected = dailyMealPlanResponseModel
                    let foodLogs = (dailyMealPlanResponseModel!.mealPlanFoods as [DailyMealFoodModel]).map { Food(dailyMealFoodModel: $0) }
                    self.mealInfo = dailyMealPlanResponseModel!.mealPlanFoods as [DailyMealFoodModel]
                    self.foodArray = foodLogs
                    self.noOfMeals = dailyMealPlanResponseModel!.mealCoreNo.doubleValue
                    self.noOfSnacks = dailyMealPlanResponseModel!.mealSnackNo.doubleValue
                    self.dailyMealPlan.dailyMealPlanName = dailyMealPlanResponseModel!.mealPlanName
                    self.dailyMealPlan.dailyMealPlanId = dailyMealPlanResponseModel!.mealPlanGuid
                    self.updatedMealDate = dailyMealPlanResponseModel!.mealUpdatedDate
                    self.dailyMealPlan.nutrionalPlanId = Int(dailyMealPlanResponseModel!.mealNutritionId) ?? 0
                    
                    self.fetchMealTypes({ (fetchedSuccessfully) -> () in
                        
                    })
                }
            }
            
        }
        
    }
    
    func sortFoodLogArray(_ array: [Food]) {
        
        //sort the food log array to meal types
        mealData = userMealTypes.map() { dailyMealType in
            
            let meal = DailyMealType(dailyMealTypeName: dailyMealType.dailyMealTypeName)
            meal.id = dailyMealType.id
            meal.isDefault = dailyMealType.isDefault
            meal.name = dailyMealType.name
            
            
            //            let tempFoods = array.filter() {
            //                
            //                $0.dailyMealType.dailyMealTypeName == dailyMealType.dailyMealTypeName //&& $0.approve != "Deny"
            //            }
            
            meal.foods = array.filter() {
                
                $0.dailyMealType.dailyMealTypeName == dailyMealType.dailyMealTypeName //&& $0.approve != "Deny"
            }//tempFoods.sort { $0.name.compare($1.name) == .OrderedAscending }
            
            //create the meal type from daily meal type
            let mealType = MealType(name: dailyMealType.name)
            mealType.id = Int(dailyMealType.id) ?? 0
            mealType.isDefault = dailyMealType.isDefault
            mealType.foods = meal.foods
            meal.mealType = mealType
            
            return meal
        }
        
        self.tableView.reloadData()
        //print("meal data is \(mealData)")
    }
    
    func foodForIndexPath(_ indexPath: IndexPath) -> Food? {
        
        // return the food from the mealtype
        
        let foods = mealData[indexPath.section - 1].foods
        if foods.count == 0{
            
            return nil
        }
        return foods[indexPath.row] ?? nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        var cellHeight: CGFloat = 0.0
        
        if indexPath.section == 0 {
            
            let currentCell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.DietHeaderCellIdentifier) as! DietCell
            currentCell.macroDetails = self.dailyMealPlan.nutritionMacroModel ?? MacroModel()
            currentCell.shouldOpen = statusArray[indexPath.row]
            currentCell.dietCellMode = dietCellMode[indexPath.row]
            currentCell.nutritionPlan = mealPlanSelectedNutrition
            currentCell.mealPlanNutritionSummary = mealTotalNutritionSummary
            
            currentCell.setNeedsUpdateConstraints()
            currentCell.updateConstraintsIfNeeded()
            //print("height---\(CGRectGetHeight(currentCell.frame))")
            currentCell.bounds = CGRect(x: 0.0, y: 0.0, width: tableView.bounds.width, height: currentCell.bounds.height)
            
            currentCell.setNeedsLayout()
            currentCell.layoutIfNeeded()
            
            currentCell.dietTableView.setNeedsUpdateConstraints()
            
            // Get the actual height required for the cell's contentView
            cellHeight = currentCell.contentView.systemLayoutSizeFitting(UILayoutFittingCompressedSize).height
            //currentCell.contentView.systemLayoutSizeFittingSize(UILayoutFittingCompressedSize).height
            
        } else {
            
            let currentCell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.MealTypeItemCellIdentifier) as! DailyMealTypeItemCell
            
            currentCell.food = foodForIndexPath(indexPath)!
            currentCell.setNeedsUpdateConstraints()
            currentCell.updateConstraintsIfNeeded()
            //print("height---\(CGRectGetHeight(currentCell.frame))")
            currentCell.bounds = CGRect(x: 0.0, y: 0.0, width: tableView.bounds.width, height: currentCell.bounds.height)
            
            currentCell.setNeedsLayout()
            currentCell.layoutIfNeeded()
            
            currentCell.labelMealItemName.preferredMaxLayoutWidth = currentCell.labelMealItemName.bounds.width
            currentCell.labelMealItemDetail.preferredMaxLayoutWidth = currentCell.labelMealItemDetail.bounds.width
            
            currentCell.labelMealItemName.setNeedsUpdateConstraints()
            currentCell.labelMealItemDetail.setNeedsUpdateConstraints()
            currentCell.contentView.setNeedsUpdateConstraints()
            
            // Get the actual height required for the cell's contentView
            cellHeight = currentCell.contentView.systemLayoutSizeFitting(UILayoutFittingCompressedSize).height
        }
        return cellHeight
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1 + mealData.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return section == 0 ? 2 : (mealData[section-1].foods).count
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        cell.setSeparatorInsetZero()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell
        
        if indexPath.section == 0 {
            cell = self.tableView(tableView, dietCellForRowAtIndexPath: indexPath)
            cell.setNeedsUpdateConstraints()
            cell.updateConstraintsIfNeeded()
        } else {
            cell = self.tableView(tableView, mealPlanCellForRowAtIndexPath: indexPath)
            cell.setNeedsUpdateConstraints()
            cell.updateConstraintsIfNeeded()
        }
        // update the cell transform
        cell.transform = tableView.transform
        
        return cell
    }
    
    func tableView(_ tableView:UITableView, dietCellForRowAtIndexPath indexPath: IndexPath) -> DietCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.DietHeaderCellIdentifier) as! DietCell
        cell.dietCellDelegate = self
        cell.macroDetails = self.dailyMealPlan.nutritionMacroModel ?? MacroModel() //macroDetails
        //set usermacro details
        cell.shouldOpen = statusArray[indexPath.row]
        cell.dietCellMode = dietCellMode[indexPath.row]
        cell.nutritionPlan = mealPlanSelectedNutrition
        cell.mealPlanNutritionSummary = mealTotalNutritionSummary
        cell.isEditableMode = isEditableMode
        // configure cell
        return cell
    }
    
    func editDiet(_ dietCell: DietCell) {
        
    }
    
    func tableView(_ tableView:UITableView, mealPlanCellForRowAtIndexPath indexPath: IndexPath) -> DailyMealTypeItemCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.MealTypeItemCellIdentifier) as! DailyMealTypeItemCell
        // configure cell
        cell.dailyMealTypeItemCellDelegate = self
        cell.food = foodForIndexPath(indexPath)!
        cell.selectionStyle = UITableViewCellSelectionStyle.none;
        cell.editModeEnabled = (pageMode != .logMealPlan)
        let selected = (self.selectedFoodArray[indexPath] != nil)
        cell.buttonSelect.isSelected = selected
        cell.indexPath = indexPath
        cell.configureView()
        
        
        //print("food \(cell.food.name) contained \(selected) selected food array size \(self.selectedFoodArray.count)")
        cell.onFoodSelectBlock = { (addFood : Bool, food:Food, indexPathForCell : IndexPath?) -> Void in
            if addFood{
                self.selectedFoodArray[indexPathForCell!] = food
            }
            else{
                if self.selectedFoodArray[indexPathForCell!] != nil{
                    self.selectedFoodArray.removeValue(forKey: indexPathForCell!)
                }
            }
        }
        return cell
    }
    
    
    
    //configure headers
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        //summary cell header
        if section == 0 {
            let headerViewSummary = self.tableView(tableView, summaryCellHeaderForSection: section)
            
            return headerViewSummary
        } else {
            
            let headerViewMealPlan = self.tableView(tableView, mealPlanHeaderForSection: section)
            return headerViewMealPlan
        }
    }
    
    func tableView(_ tableView:UITableView, summaryCellHeaderForSection section: Int) -> SummaryCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.SummaryHeaderCellIdentifier) as! SummaryCell
        // configure cell
        cell.updatedMealTime = updatedMealDate
        cell.summaryCellDelegate = self
        return cell
    }
    
    func tableView(_ tableView:UITableView, mealPlanHeaderForSection section: Int) -> DailyMealTypeCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.MealTypeHeaderCellIdentifier) as! DailyMealTypeCell
        // configure cell
        cell.dailyMealTypeCellDelegate = self
        cell.dailyMealType = mealData[section-1]
        return cell
    }
    
    func dailyMealTypeHeader(_ logHeaderView: DailyMealTypeCell, infoButtonClickedForMealType mealType: MealType) {
        
        // show meal type info view
        // adjust view size
        mealTypeInfoView.frame = CGRect(x: 0, y: 0, width: view.bounds.width - 40, height: 150)
        
        //set the delegate
        mealTypeInfoView.mealTypeInfoViewDelegate = self
        
        //layer corner radius
        mealTypeInfoView.layer.cornerRadius = 50.0
        
        // set mealtype
        mealTypeInfoView.dailyMealPlanMealType = mealType
        
        // present popup
        KLCPopup(contentView: mealTypeInfoView).show(with: KLCPopupLayoutMake(.center, .center))
    }
    
    func mealTypeInfo(_ closePopUp: Bool) {
        KLCPopup.dismissAllPopups()
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        var headerHeight: CGFloat = 0.0
        
        if section == 0 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.SummaryHeaderCellIdentifier) as! SummaryCell
            headerHeight = cell.frame.size.height
            
        } else {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.MealTypeHeaderCellIdentifier) as! DailyMealTypeCell
            headerHeight = cell.frame.size.height
        }
        
        return headerHeight
    }
    
    // configure footer
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        
        //summary cell header
        if section == 0 {
            let footerViewSummary = self.tableView(tableView, summaryCellFooterForSection: section)
            return footerViewSummary
        } else {
            
            let footerViewMealPlan = self.tableView(tableView, mealPlanFooterForSection: section)
            footerViewMealPlan.dailyMealTypeFooterCellDelegate = self
            footerViewMealPlan.dailyMealType = mealData[section-1]
            return footerViewMealPlan
        }
    }
    
    func tableView(_ tableView:UITableView, summaryCellFooterForSection section: Int) -> SummaryCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.SummaryFooterCellIdentifier) as! SummaryCell
        // configure cell
        cell.showRecalculate = showRecalculate
        cell.noOfMeals = noOfMeals
        cell.noOfSnacks = noOfSnacks
        cell.isEditableMode = isEditableMode
        
        cell.summaryCellDelegate = self
        cell.setNeedsUpdateConstraints()
        cell.updateConstraintsIfNeeded()
        return cell
    }
    
    func tableView(_ tableView:UITableView, mealPlanFooterForSection section: Int) -> DailyMealTypeFooterCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.MealTypeFooterCellIdentifier) as! DailyMealTypeFooterCell
        //        cell.dailyMealTypeFooterCellDelegate = self
        // configure cell
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        var footerHeight: CGFloat = 0.0
        
        if section == 0 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.SummaryFooterCellIdentifier) as! SummaryCell
            cell.showRecalculate = showRecalculate
            cell.setNeedsUpdateConstraints()
            cell.updateConstraintsIfNeeded()
            //print("height---\(CGRectGetHeight(cell.frame))")
            cell.bounds = CGRect(x: 0.0, y: 0.0, width: tableView.bounds.width, height: cell.bounds.height)
            
            cell.setNeedsLayout()
            cell.layoutIfNeeded()
            
            cell.viewRecalculate.setNeedsUpdateConstraints()
            cell.viewRefresh.setNeedsUpdateConstraints()
            
            // Get the actual height required for the cell's contentView
            footerHeight = cell.contentView.systemLayoutSizeFitting(UILayoutFittingCompressedSize).height
            //            footerHeight = cell.frame.size.height
            
        } else {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.MealTypeFooterCellIdentifier) as! DailyMealTypeFooterCell
            footerHeight = (isEditableMode) ? cell.frame.size.height : 0
        }
        return footerHeight
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.section ==  0 {
            
            let selectedDietCell = tableView.cellForRow(at: indexPath) as! DietCell
            
            statusArray[indexPath.row] = !statusArray[indexPath.row]
            selectedDietCell.shouldOpen = statusArray[indexPath.row]
            selectionMode = selectedDietCell.labelDietProfile.text!
            selectedDietCell.dietCellMode = dietCellMode[indexPath.row]
            tableView.reloadData()
        } else {
            // remove selection
            tableView.deselectRow(at: indexPath, animated: true)
            //print("here")
            
            let aFood:Food? = self.foodForIndexPath(indexPath)
            
            if aFood == nil {
                
                return
            }
            
            if let foodUniqueId = aFood?.uniqueID, foodUniqueId.isEmpty{
                aFood?.foodAddedMethod = "Local"
                aFood?.locaLGeneratedId = String.generateUniqueID(4) as String
            }
            
            let selectedFood  = Food(foodToBeCopied:aFood!)
            selectedFood.resetNutritionToDefualtServings(selectedFood.numberOfServings)
            FoodDetailViewController.openFromViewController(self.navigationController, withFood: selectedFood, fromController: FoodDetailViewController.FromController.dailyMealPlan,openForEdit : self.isEditableMode, foodUpdateCallBack: { (updatedFood : Food, fromController : FoodDetailViewController.FromController) -> (Void) in
                
                if selectedFood.foodAddedMethod == "Local" {
                    
                    if let i = self.foodArray.index(where: {$0.id == selectedFood.id && $0.dailyMealType.dailyMealTypeName == selectedFood.dailyMealType.dailyMealTypeName && $0.addedDate == selectedFood.addedDate
                    }) {
                        
                        //print("index----\(i)")
                        let newFood = self.foodArray[i]
                        newFood.servingSize = updatedFood.numberOfServings
                        newFood.numberOfServings = updatedFood.numberOfServings
                        self.showRecalculate = true
                        self.foodArray[i] = newFood
                        
                    }
                } else {
                    
                    if let i = self.foodArray.index(where: {$0.uniqueID == selectedFood.uniqueID && $0.dailyMealType.dailyMealTypeName == selectedFood.dailyMealType.dailyMealTypeName && $0.foodFocus == selectedFood.foodFocus
                    }) {
                        
                        //print("index----\(i)")
                        let newFood = self.foodArray[i]
                        newFood.servingSize = updatedFood.numberOfServings
                        newFood.numberOfServings = updatedFood.numberOfServings
                        self.showRecalculate = true
                        self.foodArray[i] = newFood
                    }
                }
                
            })
        }
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return indexPath.section != 0 && isEditableMode
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    
    func tableView(_ tableView: UITableView, targetIndexPathForMoveFromRowAt sourceIndexPath: IndexPath, toProposedIndexPath proposedDestinationIndexPath: IndexPath) -> IndexPath {
        
        //        if (sourceIndexPath.section != proposedDestinationIndexPath.section) {
        //            return proposedDestinationIndexPath.section == 0 ? sourceIndexPath : proposedDestinationIndexPath
        //        }
        //        return proposedDestinationIndexPath;
        return proposedDestinationIndexPath.section == 0 ? sourceIndexPath : proposedDestinationIndexPath
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        
        //print("destination section ---\(destinationIndexPath.section)")
        // save the dragged food
        
        draggedFood = (mealData[sourceIndexPath.section - 1] as DailyMealType).foods[sourceIndexPath.row]
        
        if destinationIndexPath.section == 0 {
            
            return
        }
        
        if sourceIndexPath.section != destinationIndexPath.section {
            if let food = draggedFood {
                foodToDelete = food
                if foodToDelete != nil {
                    
                    
                    (mealData[sourceIndexPath.section - 1] as DailyMealType).deleteFood(food, shouldUpdateServer: false)
                    (mealData[destinationIndexPath.section - 1] as DailyMealType).addFood(food)
                    foodToAdd = food
                    
                }
                
            }
        }
    }
    
    
    func tableView(_ tableView: DragAndDropTableView!, willBeginDraggingCellAt indexPath: IndexPath!, placeholderImageView placeHolderImageView: UIImageView!) {
        
        placeHolderImageView.layer.shadowOpacity = 0.3
        placeHolderImageView.layer.shadowRadius = 1
    }
    
    func tableView(_ tableView: DragAndDropTableView!, didEndDraggingCellAt sourceIndexPath: IndexPath!, to toIndexPath: IndexPath!, placeHolderView placeholderImageView: UIImageView!) {
        
        if sourceIndexPath == nil || toIndexPath == nil  { return }
        
        if sourceIndexPath.section != toIndexPath.section {
            
        }
        if foodToDelete != nil {
            self.showRecalculate = true
            if let foodtoDeleteId = foodToDelete!.locaLGeneratedId, foodToDelete!.uniqueID.isEmpty{
                
                
                if let index = self.foodArray.index(where: {$0.locaLGeneratedId == foodtoDeleteId}){
                    
                    self.showRecalculate = true
                    foodtoDeleteLocalId = index
                    self.foodArray.remove(at: index)
                    self.foodArray.append(foodToAdd!)
                    logFoodArray.remove(at: index)
                    logFoodArray.append(foodToAdd!)
                }
                
            }
            
            
        }
        draggedFood = nil
    }
    
    func dailyMealTypeItemRefreshItem(_ mealTypeItemCell: DailyMealTypeItemCell, refreshFood food: Food) {
        
        if food.foodRowId == "-1" {
            UIAlertView(title: &&"notice", message: &&"refersh_not_possible_manually_added_food", delegate: nil, cancelButtonTitle: &&"ok").show()
            return;
        }
        
        let dailyMealTypeItemCell = mealTypeItemCell
        let food = dailyMealTypeItemCell.food
        
        DailyMealPlan.fetchRefreshedItemInMealPlan(food.mealType.name, mealId: food.id, parentId: food.foodParentId, rowId: food.foodRowId, type: food.foodType, dmpMealType: food.dailyMealType.dailyMealTypeName,showHUD: false,nutritionPlan: String(DailyMealPlan.sharedDailyMealPlan.nutrionalPlanId) ) { (loggedFoods) -> () in
            
            //get all related ids
            if let i = self.foodArray.index(where: {$0.id == food.id && $0.dailyMealType.dailyMealTypeName == food.dailyMealType.dailyMealTypeName && $0.foodFocus == food.foodFocus
            }) {
                
                if loggedFoods.count > 0 {
                    
                    self.replacementFoods.removeAll()
                    self.replacementFoods.append(contentsOf: loggedFoods)
                    self.replaceFoodIndex = i
                    self.showPickerWithFood(replacements: loggedFoods)
//                    let newFood = loggedFoods[0]
//                    newFood.isRefreshed = true
//                    self.showRecalculate = true
//                    self.foodArray[i] = newFood
                }
//                self.perform("changeAllFoodStateToOriginal", with: nil, afterDelay: 2.0)
            }
        }        
    }
    
    func showPickerWithFood(replacements:[Food]) {
        
        let screenHeight:CGFloat = UIScreen.main.bounds.height
        let screenWidth:CGFloat = UIScreen.main.bounds.width
        
        let pickerView:RefreshFoodPicker = RefreshFoodPicker.init(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight))
        UIApplication.shared.keyWindow?.addSubview(pickerView)
        pickerView.delegate = self
        
        var foods = [String]()
        
        for food in replacements {
            foods.append(food.name)
        }
        
        pickerView.showWithAnimation(foodToShow:foods)
    }
    
    //MARK:: RefreshoodPickerDelegate Methods
    func didSelectFoodAtIndex(index: Int) {
        let newFood = self.replacementFoods[index]
        newFood.isRefreshed = true
        self.showRecalculate = true
        self.foodArray[self.replaceFoodIndex] = newFood
        self.replaceFoodIndex = 0
        self.perform(#selector(DailyMealPlanDetailViewController.changeAllFoodStateToOriginal), with: nil, afterDelay: 2.0)
    }
    
    
    
    func changeAllFoodStateToOriginal() {
        
        
        let tempFoodArray = self.foodArray
        
        self.foodArray = tempFoodArray.map() { food in
            food.isRefreshed = false
            return food
            
        }
        
    }
    
    func dailyMealTypeItemDeleteItem(_ mealTypeItemCell: DailyMealTypeItemCell, deleteFood food: Food) {
        
        let dailyMealTypeItemCell = mealTypeItemCell
        
        if pageMode == mealPlanDetailPageMode.newMealPlan || isRefreshed {
            
            if let i = foodArray.index(where: {$0.id == food.id && $0.dailyMealType.dailyMealTypeName == food.dailyMealType.dailyMealTypeName && $0.foodFocus == food.foodFocus
            }) {
                
                showRecalculate = true
                foodArray.remove(at: i)
            }
            
        } else {
            
            let foodToDelete = dailyMealTypeItemCell.food
            if let foodtoDeleteLocalId = foodToDelete.locaLGeneratedId, foodToDelete.uniqueID.isEmpty{
                
                
                if let index = self.foodArray.index(where: {$0.locaLGeneratedId == foodtoDeleteLocalId}){
                    
                    self.showRecalculate = true
                    self.foodArray.remove(at: index)
                    
                }
                
            }
            else{
                DailyMealPlanFoodItemDeleteResponse.deleteDailyMealPlan(mealPlanId, foodId: foodToDelete.uniqueID, completionHandler: { (responseStatus) -> () in
                    
                    if let i = self.foodArray.index(where: {$0.id == food.id && $0.dailyMealType.dailyMealTypeName == food.dailyMealType.dailyMealTypeName && $0.foodFocus == food.foodFocus
                    }) {
                        
                        self.showRecalculate = true
                        self.foodArray.remove(at: i)
                    }
                })
            }
            
        }
        
    }
    
    @IBAction func buttonActionShare(_ sender: UIButton) {
        
        if self.foodArray.count == 0 {
            
            UIAlertView(title: &&"notice", message: &&"no_items_to_share", delegate: nil, cancelButtonTitle: &&"ok").show()
            return
        }
        actionSheetMode = ActionSheetMode.Share
        showActionSheet()
    }
    
    @IBAction func buttonActionLogPlan(_ sender: UIButton) {
        
        if pageMode == mealPlanDetailPageMode.logMealPlan {
            
            pageMode = mealPlanDetailPageMode.editingMealPlan
            configureFooterButtons()
            return
        }
        
        if self.foodArray.count == 0 {
            
            UIAlertView(title: &&"notice", message: &&"no_items_to_log", delegate: nil, cancelButtonTitle: &&"ok").show()
            return
        }
        
        logFoodArray = self.foodArray
        
        if noOfMeals > 3.0 || noOfSnacks > 2.0 {
            
            let alertView = UIAlertView(title: &&"notice", message: &&"extra_log_alert", delegate: self, cancelButtonTitle: &&"ok")
            alertView.tag = 55
            alertView.show()
            return
            
        } else {
            
            logMealPlanAction()
        }
        
        
    }
    
    func alertView(_ alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if alertView.tag == 55 {
            
            logMealPlanAction()
        }
    }
    
    func logMealPlanAction() {
        
        Food().logDailyMealPlanFood(mealFoods: logFoodArray, userGuid: AppConfiguration.sharedAppConfiguration.userDetails!.userId!) { (error) -> () in
            
            if error == nil {
                
                //print("logged all items successfully")
                UIAlertView(title: &&"message_success", message: &&"daily_meal_plan_whole_log", delegate: nil, cancelButtonTitle: "Ok").show()
            }
            
        }
    }
    
    @IBAction func buttonActionDeletePlan(_ sender: UIButton) {
        
        if pageMode == mealPlanDetailPageMode.newMealPlan {
            self.refreshControllers()
            return;
        }
        
        //print("delete items successfully>>>>>\(self.dailyMealPlan.dailyMealPlanId)")
        
        //delete the daily meal plan
        DailyMealPlanDeleteResponse.deleteDailyMealPlan(self.dailyMealPlan.dailyMealPlanId) { (responseStatus) -> () in
            self.refreshControllers()
            if responseStatus == "OK" {
                //print("delete items successfully>>>>>\(self.dailyMealPlan.dailyMealPlanId)")
                let notification = Notification(name: Notification.Name(rawValue: Constants.updateDailyMealList), object: nil)
                NotificationCenter.default.post(notification)
            }
        }
        
    }
    
    @IBAction func unwindToDailyMealPlanDetailViewController(_ segue: UIStoryboardSegue) {
    }
    
    func selectSnacks(_ currentSnacks: Int) {
        
        actionSheetMode = ActionSheetMode.Snacks
        showActionSheet()
    }
    
    func selectMeals(_ currentMeals: Int) {
        
        actionSheetMode = ActionSheetMode.Meals
        showActionSheet()
    }
    
    func selectRefresh() {
        showRecalculate = false
        isRefreshed = true
        foodArray.removeAll()
        
        //if pageMode == mealPlanDetailPageMode.newMealPlan {
        //fetch user meal types
        fetchDailyMealFood()
        //}
    }
    
    func showActionSheet() {
        
        var otherButtonTitles = [String]()
        
        switch actionSheetMode {
        case .Share:
            otherButtonTitles = [&&"daily_meal_plan_email", "Bemafit Friends"]
        case .Meals:
            
            for count in 1...10 {
                otherButtonTitles.append("\(11-count)")
            }
        case .Snacks:
            
            for count in 1...11 {
                otherButtonTitles.append("\(11-count)")
            }
            
        }
        
        let actionSheet =  UIActionSheet(title: &&"\(actionSheetMode.rawValue)", delegate: self, cancelButtonTitle: &&"cancel", destructiveButtonTitle: nil)
        
        for buttonTitle in otherButtonTitles {
            actionSheet.addButton(withTitle: buttonTitle)
        }
        
        actionSheet.show(in: self.view)
    }
    
    func actionSheet(_ actionSheet: UIActionSheet, clickedButtonAt buttonIndex: Int) {
        
        switch actionSheetMode {
        case ActionSheetMode.Meals:
            
            //print("meal number ---\(actionSheet.buttonTitleAtIndex(buttonIndex))")
            noOfMeals = buttonIndex == 0 ? noOfMeals > 1 ? noOfMeals : 1 : actionSheet.buttonTitle(at: buttonIndex)?.doubleValue ??  1
            self.tableView.reloadData()
            
        case ActionSheetMode.Share:
            //print("share---\(actionSheet.buttonTitleAtIndex(buttonIndex))")
            if (actionSheet.buttonTitle(at: buttonIndex)=="Email") {
                
                DailyMealPlanUtils.generatePdfAndEmail(Int(noOfSnacks), noOfCoreMeals: Int(self.noOfMeals), foodLog: self.mealInfo, fromViewController: self,pdfName:self.dailyMealPlan.dailyMealPlanName,dailyMealPlanModel: self.dailyMealPlanModelSelected)
                
                
                //print("email share")
            }else if(actionSheet.buttonTitle(at: buttonIndex)=="Bemafit Friends") {
                //print("FYM share")
                
                // if the meal plan is not saved ask user to save the meal plan
                if self.dailyMealPlan.dailyMealPlanId == "" {
                    UIAlertView(title: &&"notice", message: &&"save_meal_to_share", delegate: nil, cancelButtonTitle: &&"ok").show()
                    return;
                }
                
                //share with fym friends
                SendDetailsViewController.shareDailyMealPlan(self.dailyMealPlan.dailyMealPlanId, fromViewController: self)
                
                
            }
        case ActionSheetMode.Snacks:
            
            //print("meal number ---\(actionSheet.buttonTitleAtIndex(buttonIndex))")
            noOfSnacks =  buttonIndex == 0 ? noOfSnacks > 0 ? noOfSnacks : 0 : actionSheet.buttonTitle(at: buttonIndex)?.doubleValue ?? 0
            self.tableView.reloadData()
            
        }
    }
    
    
    
    func selectedInfo() {
        
    }
    
    func addItemToMealType(_ dailyMealType: DailyMealType) {
        
        //set up notification center observer for receiving added foof item
        
        NotificationCenter.default.addObserver(self, selector: #selector(DailyMealPlanDetailViewController.refreshDailyMealPlan(_:)), name:NSNotification.Name(rawValue: "RefreshMealPlanIdentifier"), object: nil)
        
        let manageStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        
        // instantiate the initial view controller
        let addFoodViewController = manageStoryboard.instantiateViewController(withIdentifier: "kAddFoodLog") as! AddFoodLogViewController
        addFoodViewController.isDailyMealPlan = isDailyMealPlan
        addFoodViewController.dailyMealType = dailyMealType
        addFoodViewController.mealType = dailyMealType.mealType
        self.navigationController?.pushViewController(addFoodViewController, animated: true)
    }
    
    enum FoodType {
        case proteinRich
        case carbRich
        case fatRich
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == Storyboard.Segues.CreateNewMealSegueIdentifier {
            
            
            let createNewMealPlanViewController = segue.destination as! CreateNewMealPlanViewController
            createNewMealPlanViewController.pageMode = pageMode
            
        } else if segue.identifier == Storyboard.Segues.NutritionSegueIdentifier {
            
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        if (identifier == Storyboard.Segues.NutritionSegueIdentifier) {
            
            return DailyMealPlan.sharedDailyMealPlan.canEditProfile
        }
        else if (identifier == Storyboard.Segues.CreateNewMealSegueIdentifier) {
            
            if self.foodArray.count == 0 {
                
                UIAlertView(title: &&"notice", message: &&"no_food_in_meal_plan", delegate: nil, cancelButtonTitle: &&"ok").show()
            }
            return self.foodArray.count == 0 ? false : true
        }
        return true
    }
    
    func refreshDailyMealPlan(_ notification: Notification) {
        
        //Take Action on Notification
        
        if notification.userInfo != nil {
            
            //show recalculate when a new food is added
            let newFood = notification.userInfo?["newFood"] as! Food
            newFood.foodAddedMethod = "Local"
            newFood.locaLGeneratedId = String.generateUniqueID(4) as String
            newFood.foodRowId = "-1"
            //add newfood to the meal type and refresh the list
            //            getServingSize(newFood, foodType: getFoodType(newFood))
            //            newFood.servingSize =  getServingSize(newFood, foodType: getFoodType(newFood))
            showRecalculate = true
            
            foodArray.append(newFood)
            
            NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "RefreshMealPlanIdentifier"), object: nil)
            
            
        }
        
    }
    func showUserProfile(_ userId: String) {
        let manageStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        // instantiate the initial view controller
        let profileViewController = manageStoryboard.instantiateViewController(withIdentifier: "kProgressVC") as! ProfileViewController
        profileViewController.userId = userId
        self.navigationController?.pushViewController(profileViewController, animated: true)
    }
    
    func selectReCalculate() {
        // do the recalculation
        showRecalculate = false
        
        calculateRefreshedServingSize()
        //        refreshServingSize()
    }
    
    func calculateRefreshedServingSize() {
        
        if noOfMeals == 0.0 {
            
            //print("no of meals can't be zero")
            return
        }
        
        let newCoreMealData:[DailyMealType] = mealData.map() { mealDataItem in
            
            let refreshedMealDataItem = mealDataItem
            refreshedMealDataItem.foods = mealDataItem.name != "Snacks" ? refreshServingSizeCoreMeal(mealDataItem.foods) : mealDataItem.foods
            //            
            //            getSectionMacros(refreshedMealDataItem)
            
            return refreshedMealDataItem
        }
        
        mealData = newCoreMealData
        
        //get all food from mealData to foodArray
        
        var newFoodArray = [Food]()
        newFoodArray.removeAll()
        for mealDataItem in newCoreMealData {
            
            newFoodArray = newFoodArray + mealDataItem.foods
        }
        
        self.foodArray = newFoodArray
        
        //printLeftOverValues()
        
        let newCoreSnackData:[DailyMealType] = mealData.map() { mealDataItem in
            
            let refreshedMealDataItem = mealDataItem
            
            refreshedMealDataItem.foods = mealDataItem.name != "Snacks" ? mealDataItem.foods : refreshServingSizeOfSnacks(mealDataItem.foods)
            
            getSectionMacros(refreshedMealDataItem)
            return refreshedMealDataItem
        }
        
        mealData = newCoreSnackData
        
        //get all food from mealData to foodArray
        
        newFoodArray.removeAll()
        for mealDataItem in newCoreSnackData {
            
            newFoodArray = newFoodArray + mealDataItem.foods
        }
        
        self.foodArray = newFoodArray
        
        //printLeftOverValues()
        
        let foodTobeRemoved = self.foodArray.filter {
            $0.servingSize < 0.25
        }
        
        if foodTobeRemoved.count > 0 {
            
            UIAlertView(title: &&"notice", message: &&"remove_food_serving_less", delegate: nil, cancelButtonTitle: &&"ok").show()
        }
        
    }
    
    func refreshServingSizeCoreMeal(_ mealDataFoods: [Food]) -> [Food] {
        let mealDataFoods = mealDataFoods
        
        
        var proteinFodds = getTheProteinFoods(mealDataFoods)
        
        //calculate the protein value for the fixed serving foods
        
        let fixedServingSizeProteinFoods = proteinFodds.filter {
            $0.servingSizeFixed == "1"
        }
        
        // get the fixed meal protein
        //        let fixedMealProtein: Double = fixedServingSizeProteinFoods.filter{ $0.mealType.name != "Snacks" }.reduce(0) { return $0 + ($1.protein * $1.servingSize) }
        
        let fixedMealProtein: Double = fixedServingSizeProteinFoods.reduce(0) { return $0 + ($1.protein * $1.servingSize) }
        
        
        // get the left over meal protein
        //print("protein per meal ----\(getProteinSplitOffPercentage().mealProtein)")
        let leftOverMealProtein = getProteinSplitOffPercentage().mealProtein - fixedMealProtein
        
        let dynamicServingSizeProteinFoods = proteinFodds.filter {
            $0.servingSizeFixed == "0" || $0.servingSizeFixed == ""
        }
        //
        
        
        
        //split this protein for the serving size
        let proteinPerFood = leftOverMealProtein/Double(dynamicServingSizeProteinFoods.count)
        
        // get the protein foods whose serving size can be changed and map it to new array with changed serving size
        let newServingSizeProteinFoods: [Food] = dynamicServingSizeProteinFoods.map() { food in
            
            food.servingSize = food.protein == 0 ? food.servingSize : proteinPerFood / food.protein
            food.servingSize = food.servingSize < 0 ? 0 : food.servingSize
            food.numberOfServings = food.servingSize
            return food
        }
        
        //      //print("food with new serving size-protein----\(newServingSizeProteinFoods)")
        //        
        //      replace the old food with food with new serving size
        
        
        
        
        //      calculate the carbs amount so far
        //        
        var carbFoods = getTheCarbFoods(mealDataFoods)
        
        //      calculate the carb value for the fixed serving foods
        //        
        let fixedServingSizeCarbFoods = carbFoods.filter {
            $0.servingSizeFixed == "1"
        }
        
        //      get the fixed meal carb
        //        let fixedMealCarbs: Double = fixedServingSizeCarbFoods.filter{ $0.mealType.name != "Snacks" }.reduce(0) { return $0 + ($1.carbohydrates * $1.servingSize) }
        let fixedMealCarbs: Double = fixedServingSizeCarbFoods.reduce(0) { return $0 + ($1.carbohydrates * $1.servingSize) }
        
        //
        //        // carbs from protein foods
        proteinFodds = getTheProteinFoods(mealDataFoods)
        let carbFromProteinFoods: Double = proteinFodds.reduce(0) { return $0 + ($1.carbohydrates * $1.servingSize) }
        let totalCarbFromFoods = fixedMealCarbs + carbFromProteinFoods
        //
        //        // get the left over meal carbs
        let leftOverMealCarbs = getCarbsSplitOffPercentage().mealCarbs - totalCarbFromFoods
        //
        let dynamicServingSizeCarbFoods = carbFoods.filter {
            $0.servingSizeFixed == "0" || $0.servingSizeFixed == ""
        }
        
        
        
        
        //        //split this carbs for the serving size
        let carbsPerFood = leftOverMealCarbs/Double(dynamicServingSizeCarbFoods.count)
        //
        //
        //        // get the carb foods whose serving size can be changed and map it to new array with changed serving size
        let newServingSizeCarbFoods: [Food] = dynamicServingSizeCarbFoods.map() { food in
            
            food.servingSize = food.carbohydrates == 0 ?  food.servingSize  : carbsPerFood / food.carbohydrates
            food.servingSize = food.servingSize < 0 ? 0 : food.servingSize
            food.numberOfServings = food.servingSize
            return food
        }
        //        //print("food with new serving size-carbs----\(newServingSizeCarbFoods)")
        //        
        //        // replace the old food with food with new serving size
        //
        
        //
        //        //calculate the fats amount so far
        //        
        let fatFoods = getTheFatFoods(foodArray)
        //
        //        //calculate the fat value for the fixed serving foods
        //        
        let fixedServingSizeFatFoods = fatFoods.filter {
            $0.servingSizeFixed == "1"
        }
        //
        //        // get the fixed meal fat
        let fixedMealFat: Double = fixedServingSizeFatFoods.reduce(0) { return $0 + ($1.fat * $1.servingSize) }
        //
        //        // fat from protein and carb foods
        proteinFodds = getTheProteinFoods(mealDataFoods)
        carbFoods = getTheCarbFoods(mealDataFoods)
        //
        let proteinPlusCarbFoods = proteinFodds + carbFoods
        let fatFromProteinPlusCarbFoods: Double = proteinPlusCarbFoods.reduce(0) { return $0 + ($1.fat * $1.servingSize) }
        let totalFatFromFoods = fixedMealFat + fatFromProteinPlusCarbFoods
        
        
        //      get the left over meal fat
        let leftOverMealFat = getFatSplitOffPercentage().mealFat - totalFatFromFoods
        
        let dynamicServingSizeFatFoods = fatFoods.filter {
            $0.servingSizeFixed == "0" || $0.servingSizeFixed == ""
        }
        
        
        //      split this fat for the serving size
        let fatPerFood = leftOverMealFat/Double(dynamicServingSizeFatFoods.count)
        
        //      get the fat foods whose serving size can be changed and map it to new array with changed serving size
        let newServingSizeFatFoods: [Food] = dynamicServingSizeFatFoods.map() { food in
            
            food.servingSize = food.fat == 0 ? food.servingSize : fatPerFood / food.fat
            food.servingSize = food.servingSize < 0 ? 0 : food.servingSize
            food.numberOfServings = food.servingSize
            return food
        }
        //print("food with new serving size-fat----\(newServingSizeFatFoods)")
        //
        //        // replace the old food with food with new serving size
        //        
        
        //
        
        
        return mealDataFoods
    }
    
    func printLeftOverValues() {
        let leftOverCalorie = targetCalorie - calculateMealNutritionSummary().mealTotalCalorie
        let leftOverProtein = targetProtein - calculateMealNutritionSummary().mealTotalProtein
        let leftOverCarb = targetCarbs - calculateMealNutritionSummary().mealTotalCarbs
        let leftOverFat = targetFat - calculateMealNutritionSummary().mealTotalFat
        
    }
    
    func getSectionMacros(_ mealDataItem: DailyMealType) {
        
        let calorie: Double = mealDataItem.foods.reduce(0) { return $0 + ($1.calories * $1.servingSize) }
        let protein: Double = mealDataItem.foods.reduce(0) { return $0 + ($1.protein * $1.servingSize) }
        let carbs: Double = mealDataItem.foods.reduce(0) { return $0 + ($1.carbohydrates * $1.servingSize) }
        let fat: Double = mealDataItem.foods.reduce(0) { return $0 + ($1.fat * $1.servingSize) }
    }
    
    func refreshServingSizeOfSnacks(_ snackFoods:[Food]) -> [Food]{
        let snackFoods = snackFoods
        //
        //        // calculate the calorie from all meal foods
        let calorieFromMealFoods: Double = calculateMealNutritionSummary().mealTotalCalorie
        //
        //        let leftOverCalorie = getCalorieSplitOffPercentage().mealCalorie - calorieFromMealFoods
        //
        let leftOverCalorie = targetCalorie - calorieFromMealFoods
        
        
        let dynamicServingSizeSnackFoods = snackFoods.filter {
            $0.servingSizeFixed == "0" || $0.servingSizeFixed == ""
        }
        
        
        //        //split this fat for the serving size
        let caloriePerSnackSection = leftOverCalorie / noOfSnacks //((leftOverCalorie * snackMacroSplitOffPercentage)/100.0)/noOfSnacks
        
        
        
        let calorieFromFixedSnack:Double = snackFoods.reduce(0){
            return $0 + (($1.servingSizeFixed == "1") ? $1.calories : 0)
        }
        
        let caloriePerSnackItem = (caloriePerSnackSection-calorieFromFixedSnack)/Double(dynamicServingSizeSnackFoods.count)
        //
        //
        //        // get the fat foods whose serving size can be changed and map it to new array with changed serving size
        dynamicServingSizeSnackFoods.map() { food in
            
            food.servingSize = food.calories == 0 ? food.servingSize : caloriePerSnackItem / food.calories
            food.servingSize = food.servingSize < 0 ? 0 : food.servingSize
            food.numberOfServings = food.servingSize
            
        }
        
        return snackFoods
    }
    
    func getTheProteinFoods(_ foods: [Food]) -> [Food] {
        
        let proteinFoods = foods.filter { food in
            
            let foodType = getFoodType(food)
            //print("foodType---\(foodType)")
            return foodType == FoodType.proteinRich
        }
        
        return proteinFoods
    }
    
    func getTheCarbFoods(_ foods: [Food]) -> [Food] {
        
        let carbFoods = foods.filter { food in
            
            let foodType = getFoodType(food)
            //print("foodType---\(foodType)")
            return foodType == FoodType.carbRich
        }
        
        return carbFoods
    }
    
    func getTheFatFoods(_ foods: [Food]) -> [Food] {
        
        let fatFoods = foods.filter { food in
            
            let foodType = getFoodType(food)
            //print("foodType---\(foodType)")
            return foodType == FoodType.fatRich
        }
        
        return fatFoods
    }
    
    // find out the food type of the food depending on the prominent macro nutrients present in the food
    func getFoodType(_ food: Food) -> (FoodType)  {
        
        var foodType = FoodType.proteinRich
        
        let macroDictionary = ["Protein" : food.protein, "Carbs" : food.carbohydrates, "Fat" : food.fat]
        
        let valueMaxElement = macroDictionary.max(by: { (a, b) -> Bool in
            return a.1 < b.1
        })
        
        if let maxValueMacroType: String = valueMaxElement!.0 {
            
            if maxValueMacroType == "Protein" {
                
                foodType = FoodType.proteinRich
                
            } else if maxValueMacroType == "Carbs" {
                
                foodType = FoodType.carbRich
                
            } else if maxValueMacroType == "Fat" {
                
                foodType = FoodType.fatRich
            }
        }
        
        return foodType
    }
    
    //adjust the food serving size based on the size needed to attain the nutrition
    func getServingSize(_ food: Food, foodType: FoodType) -> Double {
        
        var servingSize: Double = 1.0
        
        if (food.protein == 0.0 && food.carbohydrates == 0.0 && food.fat == 0.0) || food.servingSize != 0{
            
            // the food has no protein, fat and carbohydrates -- return the defaqult serving size
            return servingSize
        }
        
        switch foodType {
        case .carbRich:
            servingSize =  (food.mealType.name == "Snacks" ? getCarbsSplitOffPercentage().snackCarbs : getCarbsSplitOffPercentage().mealCarbs) / food.carbohydrates
        case .proteinRich:
            servingSize = (food.mealType.name == "Snacks" ? getProteinSplitOffPercentage().snackProtein : getProteinSplitOffPercentage().mealProtein)  / food.protein
        case .fatRich:
            servingSize = (food.mealType.name == "Snacks" ? getFatSplitOffPercentage().snackFat : getFatSplitOffPercentage().mealFat) / food.fat
        }
        
        return servingSize
    }
    
    func getMealMacros() -> (totalMealCalorie: Double, totalMealProtein: Double, totalMealCarbs: Double, totalMealFat: Double, totalMealFiber: Double, totalMealSugar:Double) {
        
        return (calculateMealNutritionSummary().mealTotalCalorie, calculateMealNutritionSummary().mealTotalProtein,
                calculateMealNutritionSummary().mealTotalCarbs,
                calculateMealNutritionSummary().mealTotalFat, calculateMealNutritionSummary().mealTotalFiber, calculateMealNutritionSummary().mealTotalSugar
        )
    }
    
    func getSnackMacros() -> (totalSnackCalorie: Double, totalSnackProtein: Double, totalSnackCarbs: Double, totalSnackFat: Double, totalSnackFiber: Double, totalSnackSugar:Double) {
        
        return (calculateSnackNutritionSummary().snackTotalCalorie, calculateSnackNutritionSummary().snackTotalProtein,
                calculateSnackNutritionSummary().snackTotalCarbs,
                calculateSnackNutritionSummary().snackTotalFat, calculateSnackNutritionSummary().snackTotalFiber, calculateSnackNutritionSummary().snackTotalSugar
        )
    }
    
    func getCalorieSplitOffPercentage() -> (mealCalorie: Double, snackCalorie: Double) {
        
        return (((targetCalorie * mealMacroSplitOffPercentage)/100.0)/noOfMeals, ((targetCalorie * snackMacroSplitOffPercentage)/100.0)/noOfSnacks)
    }
    
    func getProteinSplitOffPercentage() -> (mealProtein: Double, snackProtein: Double) {
        
        return (((targetProtein * mealMacroSplitOffPercentage)/100.0)/noOfMeals, ((targetProtein * snackMacroSplitOffPercentage)/100.0)/noOfSnacks)
    }
    
    func getCarbsSplitOffPercentage() -> (mealCarbs: Double, snackCarbs: Double) {
        
        return (((targetCarbs * mealMacroSplitOffPercentage)/100.0)/noOfMeals, ((targetCarbs * snackMacroSplitOffPercentage)/100.0)/noOfSnacks)
    }
    
    func getFatSplitOffPercentage() -> (mealFat: Double, snackFat: Double) {
        
        return (((targetFat * mealMacroSplitOffPercentage)/100.0)/noOfMeals, ((targetFat * snackMacroSplitOffPercentage)/100.0)/noOfSnacks)
    }
    
    func calculateMealNutritionSummary() -> (mealTotalCalorie: Double, mealTotalProtein: Double, mealTotalCarbs: Double, mealTotalFat: Double, mealTotalFiber: Double, mealTotalSugar:Double) {
        
        let calorie: Double = foodArray.filter{ $0.mealType.name != "Snacks" }.reduce(0) { return $0 + ($1.calories * (($1.servingSizeFixed == "1") ? 1 : $1.servingSize)) }
        let protein: Double = foodArray.filter{ $0.mealType.name != "Snacks" }.reduce(0) { return $0 + ($1.protein * (($1.servingSizeFixed == "1") ? 1 : $1.servingSize)) }
        let carbs: Double = foodArray.filter{ $0.mealType.name != "Snacks" }.reduce(0) { return $0 + ($1.carbohydrates * (($1.servingSizeFixed == "1") ? 1 : $1.servingSize)) }
        let fat: Double = foodArray.filter{ $0.mealType.name != "Snacks" }.reduce(0) { return $0 + ($1.fat * (($1.servingSizeFixed == "1") ? 1 : $1.servingSize)) }
        let fiber: Double = foodArray.filter{ $0.mealType.name != "Snacks" }.reduce(0) { return $0 + ($1.fiber * (($1.servingSizeFixed == "1") ? 1 : $1.servingSize)) }
        let sugar: Double = foodArray.filter{ $0.mealType.name != "Snacks"}.reduce(0) {return $0 + ($1.sugar! * (($1.servingSizeFixed == "1") ? 1: $1.servingSize))}
        
        return (calorie, protein, carbs, fat, fiber, sugar)
    }
    
    func calculateSnackNutritionSummary() -> (snackTotalCalorie: Double, snackTotalProtein: Double, snackTotalCarbs: Double, snackTotalFat: Double, snackTotalFiber: Double, snackTotalSugar:Double) {
        
        let calorie: Double = foodArray.filter{ $0.mealType.name == "Snacks" }.reduce(0) { return $0 + ($1.calories * (($1.servingSizeFixed == "1") ? 1 : $1.servingSize)) }
        let protein: Double = foodArray.filter{ $0.mealType.name == "Snacks" }.reduce(0) { return $0 + ($1.protein * (($1.servingSizeFixed == "1") ? 1 : $1.servingSize)) }
        let carbs: Double = foodArray.filter{ $0.mealType.name == "Snacks" }.reduce(0) { return $0 + ($1.carbohydrates * (($1.servingSizeFixed == "1") ? 1 : $1.servingSize)) }
        let fat: Double = foodArray.filter{ $0.mealType.name == "Snacks" }.reduce(0) { return $0 + ($1.fat * (($1.servingSizeFixed == "1") ? 1 : $1.servingSize)) }
        let fiber: Double = foodArray.filter{ $0.mealType.name == "Snacks" }.reduce(0) { return $0 + ($1.fiber * (($1.servingSizeFixed == "1") ? 1 : $1.servingSize)) }
        let sugar: Double = foodArray.filter{ $0.mealType.name == "Snacks" }.reduce(0) { return $0 + ($1.sugar! * (($1.servingSizeFixed == "1") ? 1 : $1.servingSize)) }
        
        return (calorie, protein, carbs, fat, fiber, sugar)
    }
    
    func refreshControllers(){
        if let viewControllers = self.navigationController?.viewControllers {
            for viewController in viewControllers {
                // some process
                if viewController.isKind(of: DailyMealPlanViewController.self) {
                    _ = self.navigationController?.popToViewController(viewController, animated: true)
                    
                }
            }
        }
    }
    
    @IBAction func buttonActionRightNavigation(_ sender: UIBarButtonItem) {
        
        if pageMode != mealPlanDetailPageMode.logMealPlan {
            
            self.performSegue(withIdentifier: Storyboard.Segues.CreateNewMealSegueIdentifier, sender: nil)
            
        } else {
            
            if self.selectedFoodArray.count == 0 {
                
                UIAlertView(title: &&"notice", message: &&"no_items_to_log", delegate: nil, cancelButtonTitle: &&"ok").show()
                return
            }
            
            logFoodArray = Array(self.selectedFoodArray.values)
            
            if noOfMeals > 3.0 || noOfSnacks > 2.0 {
                
                let alertView = UIAlertView(title: &&"notice", message: &&"extra_log_alert", delegate: self, cancelButtonTitle: &&"ok")
                alertView.tag = 55
                alertView.show()
                return
                
            } else {
                
                logMealPlanAction()
            }
        }
        
    }
    
}
