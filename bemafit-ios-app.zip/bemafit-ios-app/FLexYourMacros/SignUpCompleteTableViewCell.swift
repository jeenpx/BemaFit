//
//  NutritionCategoryTableViewCell.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 18/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit


// delegate for CreateMealCell
protocol SignUpCompleteTableViewCellDelegate {
    func buttonActionUpdate(_ signUpCompleteTableViewCell: SignUpCompleteTableViewCell)
}
class SignUpCompleteTableViewCell: UITableViewCell, UITextFieldDelegate {

    @IBOutlet weak var labelHeaderTitle: UILabel!
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelDescription: UILabel!
    @IBOutlet weak var textFieldMacroValue: UITextField!
    @IBOutlet weak var labelMacroType: UILabel!
    @IBOutlet weak var labelMacroValue: UILabel!
    @IBOutlet weak var textFieldMealNumber: UITextField!
    @IBOutlet weak var buttonUpdate: UIButton!    
    @IBOutlet weak var textFieldFiber: UITextField!
    let FYMUserModel = FymUser.sharedFymUser

    var signUpCompleteTableViewCellDelegate: SignUpCompleteTableViewCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configureCell() {
        
        //print(&&"carbs")

        if self.reuseIdentifier == "kCalorieCell" {
            
            self.labelTitle.text = &&"calories"
            self.labelDescription.text = FYMUserModel.userCalorieValue
            
        } else if self.reuseIdentifier == "kFibreCell" {
            
            self.labelTitle.text = &&"fiber"
            self.textFieldFiber.text = FYMUserModel.userFiberValue
        } else if self.reuseIdentifier == "kMacroCell" {
            
            if self.tag == 0 {
                self.labelMacroType.text = "%" + " " + &&"fat"
                self.labelMacroValue.text = FYMUserModel.userFat
                if  FYMUserModel.userFatPercentage.doubleValue > 0.0 {
                 self.textFieldMacroValue.text = FYMUserModel.userFatPercentage
                }
            } else if self.tag == 1 {
                self.labelMacroType.text = "%" + " " + &&"carbs"
                self.labelMacroValue.text = FYMUserModel.userCarbs
                if  FYMUserModel.userCarbsPercentage.doubleValue > 0.0 {
                    self.textFieldMacroValue.text = FYMUserModel.userCarbsPercentage
                }
            } else if self.tag == 2 {
                self.labelMacroType.text = "%" + " " + &&"proteins"
                self.labelMacroValue.text = FYMUserModel.userProtein
                if  FYMUserModel.userProteinPercentage.doubleValue > 0.0 {
                    self.textFieldMacroValue.text = FYMUserModel.userProteinPercentage
                }
            }
            
        } else if self.reuseIdentifier == "kCustomCell" {
            self.textFieldMealNumber.text = FYMUserModel.userNumberOfMeals == 0 ? "" : String(FYMUserModel.userNumberOfMeals)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        // managing the textfield input: limit the characters to only of numeric type
        //        if string.isEmpty { return true }
        
//        FymUser.sharedFymUser.userNutritionType = "5"
        if string == " " {
            return false
        }
        var isValid = true
        let text = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        
        // check for unwanted characters
        let replacementStringIsLegal = string.rangeOfCharacter(from: CharacterSet(charactersIn: "0123456789.").inverted) == nil
        
        // check for string count
        let resultingStringLengthIsLegal = text.characters.count <= 7
        
        
        // check if the number is valid
        let scanner = Scanner(string: text)
        let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
        
        let isLowNumber = text.doubleValue < 100000
        
        isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber
        
        return isValid
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func buttonActionUpdate(_ sender: UIButton) {
        
        // disable update button after clicked once
//        buttonUpdate.alpha = 0.5
//        buttonUpdate.userInteractionEnabled = false
        signUpCompleteTableViewCellDelegate?.buttonActionUpdate(self)
    }
}
