//
//  DailyMealPlanUpdateResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 24/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import Foundation
class DailyMealPlanUpdateResponse:NSObject {
    
    var meta: MetaModel?
    var dailyMealPlanId: String?
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
        responseMapping?.addPropertyMapping(metaModelMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let dailyMealPlanUpdateResponseDescriptor = RKResponseDescriptor(mapping: DailyMealPlanUpdateResponse.responseMapping, method: .PUT, pathPattern: Constants.ServiceConstants.kDailyMealPlanUpdate, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return dailyMealPlanUpdateResponseDescriptor!
    }
    
    class func updateDailyMealPlan(_ dailyMealPlanId: String,params: [String: Any], completionHandler: @escaping (_ error: NSError?) -> ()) {
        
        SVProgressHUD.show()
        
        RestKitManager.setToken(true)
        
        let dailyMealPlanUpdateResponse = DailyMealPlanUpdateResponse()
        dailyMealPlanUpdateResponse.dailyMealPlanId = dailyMealPlanId
        
        
        // create a post request
        let request = RestKitManager.shared().request(with: dailyMealPlanUpdateResponse, method: .PUT, path:nil, parameters: nil)
        
        // set params as body
        request?.httpBody = try? JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
        
        // create an operation with the request
        let operation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let dailyMealPlanCreateResponse = mappingResult?.firstObject as! DailyMealPlanUpdateResponse
            
            // check for success
            if dailyMealPlanCreateResponse.meta?.responseCode != 200 {
                
                SVProgressHUD.dismiss()
                
                // configure alert message
                let message = "alert_log_daily_meal_plan_message"
                
                
                completionHandler(NSError(domain: "FYM.DailyMealPlan", code: 99, userInfo: ["title": "error", "message": message]))
            }
            else {
                SVProgressHUD.dismiss()
                completionHandler(nil)
            }
            }) { (operation, error) in
                //print("XXX failed to log food with error \(error)")
                SVProgressHUD.dismiss()
                completionHandler(NSError(domain: "FYM.DailyMealPlan", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"]))
        }
        
        // enque request operation
        RestKitManager.shared().enqueue(operation)
    }
}
