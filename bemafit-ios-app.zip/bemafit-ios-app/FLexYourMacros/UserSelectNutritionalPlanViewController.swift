//
//  UserSelectNutritionalPlanViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 12/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UserSelectNutritionalPlanViewController: UITableViewController {

    struct StoryBoard {
        
        struct CellIdentifiers {
            static let HeaderCell =  "kHeaderCell"
            static let NutritionCell    =  "kNutritionCell"
        }
        
        struct SegueIdentifiers {
        }
    }
    
    var currentIndexPath: IndexPath! = IndexPath(row: 0, section: 0)
    let FYMUserModel = FymUser.sharedFymUser
    var nutritionalPlans = [NutritionPlanModel]()
    var offscreenCells = [String: NutritionCategoryTableViewCell]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        nutritionalPlans = AppConfiguration.sharedAppConfiguration.nutritionPlans
        
        // set the default nutriotional plan when loaded first time
        if (FYMUserModel.userNutritionType == "") {
            FYMUserModel.userNutritionType =  nutritionalPlans[0].nutritionId! }
        
        self.tableView.selectRow(at: currentIndexPath, animated: true, scrollPosition: UITableViewScrollPosition.none)
        
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 60
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        if FymUser.sharedFymUser.areAllNutritionPlansActive == true {
            return nutritionalPlans.count
        }
        
        return 1
    }

    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        var cell = offscreenCells[StoryBoard.CellIdentifiers.NutritionCell]
        if cell == nil {
            cell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.NutritionCell) as? NutritionCategoryTableViewCell
            offscreenCells[StoryBoard.CellIdentifiers.NutritionCell] = cell
        }
        
        let currentNutritionalPlan = nutritionalPlans[indexPath.row] as NutritionPlanModel
        
        cell?.labelNutritionTitle.text = currentNutritionalPlan.nutritionName
        cell?.labelNutritionDescription.text = currentNutritionalPlan.nutritionDescription
        
        cell?.setNeedsUpdateConstraints()
        cell?.updateConstraintsIfNeeded()
        cell?.bounds = CGRect(x: 0.0, y: 0.0, width: tableView.bounds.width, height: cell!.bounds.height)
        
        cell?.setNeedsLayout()
        cell?.layoutIfNeeded()
        
        cell?.labelNutritionDescription.preferredMaxLayoutWidth = cell!.labelNutritionDescription.bounds.width
        cell?.labelNutritionDescription.setNeedsUpdateConstraints()
        
        // Get the actual height required for the cell's contentView
        var height = cell?.contentView.systemLayoutSizeFitting(UILayoutFittingCompressedSize).height
        
        // Add an extra point to the height to account for the cell separator, which is added between the bottom
        // of the cell's contentView and the bottom of the table view cell.
        height = height! + 1
        
        return height!

    }
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.HeaderCell) as! UIView
        return headerView
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.NutritionCell, for: indexPath) as! NutritionCategoryTableViewCell
        
        // populate with current plan detail for the row
        let currentNutritionalPlan = nutritionalPlans[indexPath.row] as NutritionPlanModel

        if currentNutritionalPlan.nutritionId == FYMUserModel.userNutritionType {
            // set the first row selected
            cell.accessoryType = UITableViewCellAccessoryType.checkmark
        } else {
            cell.accessoryType = UITableViewCellAccessoryType.none
        }
        cell.labelNutritionTitle.text = currentNutritionalPlan.nutritionName
        cell.labelNutritionDescription.text = currentNutritionalPlan.nutritionDescription
        cell.setNeedsUpdateConstraints()
        cell.updateConstraintsIfNeeded()
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: indexPath) as! NutritionCategoryTableViewCell
        
        let currentNutritionalPlan = nutritionalPlans[indexPath.row] as NutritionPlanModel

        // set user selected nutrition type
        FYMUserModel.userNutritionType = currentNutritionalPlan.nutritionId!
        self.tableView .reloadData()
    }
  
   override func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView(frame: CGRect.zero)
    }
    @IBAction func buttonActionBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)

    }
    
    @IBAction func unwindToNutritionSelectionViewController(_ segue: UIStoryboardSegue) {
        self.navigationController?.isNavigationBarHidden = false

    }
}
