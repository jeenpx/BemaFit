//
//  NewMessageViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/1/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class NewMessageViewController: UIViewController, UITextViewDelegate, UIAlertViewDelegate {
    
    // hold choosen friend details
    var friend: FriendModel?
    
    @IBOutlet weak var textViewMessage: UITextView!
    @IBOutlet weak var labelPlaceholder: UILabel!
    
    // posted message
    var postedMessage = MessageItemModel()
    
    var placeHolderMessage = &&"message_post_placeholder_text"
    
    struct StoryBoard {
        struct Segues {
            static let CreateMessageToDetails = "kCreateMessageToDetails"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set placeholder
        labelPlaceholder.text = placeHolderMessage
        
        // configure the view
        configureView()
    }
    
    func configureView() {
        
        textViewMessage.becomeFirstResponder()
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        // text entered
        if text != "" {
            labelPlaceholder.isHidden = true
        }
        else {
            // backspace
            
            // user presses backspace on single character
            if textView.text.characters.count == 1 {
                labelPlaceholder.isHidden = false
            }
        }
        
        if text == "\n" {
            
            // pressed return key when no character
            if textView.text.characters.count == 0 {
                labelPlaceholder.isHidden = false
            }
            
            textViewMessage.resignFirstResponder()
            return false
        }
        
        return true
    }
    
    func sendMessage(_ message: String, andFriendId friendId: String) {
        // send the message to the friend
        
        if textViewMessage.tag == 20 || message.trimmedString() == "" {
            
            // show alert
            showAlert(&&"new_message_alert_title", message: &&"new_message_alert_message")
        }
        else {
            MessageSendResponse.postMessage(message, andFriendId: friendId) { (sendMessage,meta) -> () in
                
                // response error
                if meta.responseCode != 200 {
                    self.showAlert(&&"notice", message: &&"failure_send")
                    return
                }
                
                // save posted message
                self.postedMessage = sendMessage
                NotificationCenter.default.post(name: Notification.Name(rawValue: "RefreshMessageIdentifier"), object: nil, userInfo: ["newMessage": self.postedMessage as Any, "method": "Post"])
                
                //self.messageSendSuccessfulAlert(&&"notice", message: &&"message_send_success_alert")
                
                // navigate to message details
                self.performSegue(withIdentifier: StoryBoard.Segues.CreateMessageToDetails, sender: nil)
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == StoryBoard.Segues.CreateMessageToDetails {
            let messageDetailsViewController = segue.destination as! MessageDetailsViewController
            messageDetailsViewController.selectedMessageThread = postedMessage
        }
    }
    
    @IBAction func buttonActionSend(_ sender: Any) {
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        sendMessage(textViewMessage.text.trimmedString(), andFriendId: friend!.user_id!)
    }
    
    func showAlert(_ title: String, message: String) {
        if #available(iOS 8.0, *) {
            let alertView = UIAlertController(title: title,
                message: message, preferredStyle: .alert)
            alertView.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
            present(alertView, animated: true, completion: nil)
        } else {
            // Fallback on earlier versions
            
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"ok").show()
        }
    }
}
