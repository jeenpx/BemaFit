//
//  FoodListResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 27/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit
import SystemConfiguration

class FoodListModel: NSObject {
    
    var id = ""
    var guid = ""
    var name = ""
    var brandName = ""
    var unitId = 0
    var unit = ""
    var servingSize = 0.0
    var image = ""
    var imageLarge = ""
    var nutritionalFacts = NutritionalFactsModel()
    var vendorVerified = ""
    
    class var objectMapping: RKObjectMapping {
        
        let mappingDictionary = ["id": "id", "guid": "guid", "name": "name", "unit_id": "unitId", "unit": "unit", "serving_size": "servingSize", "brand_name": "brandName", "meal_image": "image", "meal_image_large": "imageLarge", "vendor_verified": "vendorVerified"]
        
        let nutritionalFactsRelationshipMapping = RKRelationshipMapping(fromKeyPath: "nutrition_facts", toKeyPath: "nutritionalFacts", with: NutritionalFactsModel.objectMapping)
        
        let mapping = RKObjectMapping(for: self)
        mapping?.addAttributeMappings(from: mappingDictionary)
        mapping?.addPropertyMapping(nutritionalFactsRelationshipMapping)
        return mapping!
    }
}

class NutritionalFactsModel: NSObject {
    
    var calories = 0.0
    var fat = 0.0
    var saturated = 0.0
    var polyUnsaturated = 0.0
    var monoSaturated = 0.0
    var trans = 0.0
    var cholesterol = 0.0
    var sodium = 0.0
    var carbohydrates = 0.0
    var fiber = 0.0
    var protien = 0.0
    var potassium = 0.0
    var sugar = 0.0
    
    class var objectMapping: RKObjectMapping {
        
        let mappingDictionary = ["Calories": "calories", "Fat": "fat", "Saturated": "saturated", "Polyunsaturated": "polyUnsaturated", "Monosaturated": "monoSaturated", "Trans": "trans", "Cholestrol": "cholesterol", "Sodium": "sodium", "Carbohydrates": "carbohydrates", "Dietary Fiber": "fiber", "Protien": "protien", "Pottassium": "potassium", "Sugar":"sugar"]
        
        let mapping = RKObjectMapping(for: self)
        mapping?.addAttributeMappings(from: mappingDictionary)
        return mapping!
    }
}

class FoodListResponse: NSObject {
    
    var metaModel = MetaModel()
    var foods = [FoodListModel]()
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
        responseMapping?.addPropertyMapping(metaModelMapping)
        
        // foods mapping
        let foodListModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathFood, toKeyPath: "foods", with: FoodListModel.objectMapping)
        responseMapping?.addPropertyMapping(foodListModelMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let foodListResponseDescriptor = RKResponseDescriptor(mapping: FoodListResponse.responseMapping, method: .any, pathPattern: Constants.ServiceConstants.kFoodListUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return foodListResponseDescriptor!
    }
    
    class func fetchFoodList(_ params: [String: String], completionHandler: @escaping (_ foods: [Food], _ error: NSError?) -> ()) {
        
        RestKitManager.setToken(true)
        
        RestKitManager.shared().getObjectsAtPath(Constants.ServiceConstants.kFoodListUrl, parameters: params, success: { (operation, mappingResult) in
            
            // map to correct datamodel
            let response = mappingResult?.firstObject as! FoodListResponse
            
            let foods = (response.foods as [FoodListModel]).map { Food(foodListModel: $0) }
            
            if response.metaModel.responseCode != 200 {
                let error = NSError(domain: "FYM.FoodList", code: 1001, userInfo: ["title": "error", "message": "alert_food_list_message"])
                
                // fire completion handler
                completionHandler([], error)
                
            }
            else {
                // fire completion handler
                completionHandler(foods, nil)
            }
            
            }) { (operation, error) -> Void in
                // error
                let networkError = NSError(domain: "FYM.FoodList", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
                
                // fire completion handler
                completionHandler([], networkError)
        }
    }
}
