//
//  UITableViewExtensions.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/22/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

extension UITableViewCell {
    
    var relativeSubviews: [UIView] {
        return contentView.subviews
    }
    
    func relativeSubviews <T: UIView> (_ type: T.Type) -> [T]? {
        return relativeSubviews.filter() { $0.isKind(of: T.self)} as? [T]
    }
}


extension UITableViewCell {
    
    func setCustomSeparatorInset(_ inset: UIEdgeInsets) {
        
        // set seperator inset
        separatorInset = UIEdgeInsets.zero
        if #available(iOS 8.0, *) {
            preservesSuperviewLayoutMargins = false
            layoutMargins = UIEdgeInsets.zero
        } else {
            // Fallback on earlier versions
        }
    }
    
    func setSeparatorInsetZero() {
        setCustomSeparatorInset(UIEdgeInsets.zero)
    }
    
    func showEmptyTableViewCellMessage(_ message: String = &&"empty_tableview_message") {
        let labelEmptyMessage = UILabel(frame: CGRect(x: 0, y: 0, width: bounds.size.width, height: bounds.size.height))
        labelEmptyMessage.text = message
        labelEmptyMessage.textColor = UIColor(red: 114.0/255.0, green: 114.0/255.0, blue: 114.0/255.0, alpha: 1.0)
        labelEmptyMessage.numberOfLines = 0
        labelEmptyMessage.textAlignment = .center
        labelEmptyMessage.font = UIFont.helvetica(15)
        labelEmptyMessage.sizeToFit()
        backgroundView = labelEmptyMessage
    }
}
