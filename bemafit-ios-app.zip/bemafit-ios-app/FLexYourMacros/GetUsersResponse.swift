//
//  GetUsersResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 21/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class GetUsersResponse: NSObject {

    var userDetailModel: [UserDetailModel]?
    var metaModel: MetaModel?
    var totalUsers: String?
    
    class var getUserResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)        
        // give referece to meta model
        responseMapping?.addPropertyMapping(GetUsersResponse.metaModelKeyMapping)
        
        // give reference to user credential mapping
        responseMapping?.addPropertyMapping(GetUsersResponse.userDetailModelKeyMapping)
        
        responseMapping?.addAttributeMappings(from: mappingDictionary)
        
        return responseMapping!
    }
    
    class var userResponseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: getUserResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.signUpUserUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    fileprivate class var userDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathGetFriends, toKeyPath: "userDetailModel", with: UserDetailModel.objectMapping)
    }
    
    class var mappingDictionary: [String : String] {
        return(["total_users":"totalUsers"])
    }
    
    
    class func getFymUsers(_ isProgressbarEnabled:Bool, offset: Int, andLimit limit: Int, keywords: String, completionHandler: @escaping (_ getUserResponse:GetUsersResponse) -> ()) {
        
        if isProgressbarEnabled {
            SVProgressHUD.show()
        }
        RestKitManager.setToken(true)
        // let friendResponse = GetFriendsResponse()
        // friendResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
        
        // input parameters
        let params: Dictionary<String, Any>  = ["offset": offset as Any, "limit": limit as Any ,"keyword": keywords as Any , "exclude": "friendsAndRequestReceived" as Any]
        
        
        // get the objects from the path login
        RestKitManager.shared().getObject(nil, path:Constants.ServiceConstants.signUpUserUrl, parameters: params, success: { (operation, mappingResult) in
            let getUserResponse = mappingResult?.firstObject as! GetUsersResponse
            
            //print("respone code :\(getUserResponse.metaModel?.responseCode)")
            //print("respone status :\(getUserResponse.metaModel?.responseStatus)")
            
            completionHandler(getUserResponse)
            if isProgressbarEnabled {
                SVProgressHUD.dismiss()
            }
            }) { (operation, error) in
                if isProgressbarEnabled {
                    SVProgressHUD.dismiss()
                }
                //print("failed to load masterdata with error \(error)")
        }
    }
}
