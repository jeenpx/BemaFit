//
//  AddressBookContact.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 31/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit
import AddressBook

class AddressBookContact: NSObject {
    
    var contactName = ""
    var contactEmail: String?
    
    // section to help tableview indexing
    var section: Int?
    
    typealias AddressBookContactCallback = (_ contacts: [AddressBookContact]?) -> Void
    
    convenience init(reference: ABAddressBook) {
        self.init()
        contactName = processContactName(reference)
        contactEmail = processContactEmail(reference)
    }
    
    // address book reference
    class func extractAddressBookReference(_ reference: Unmanaged<ABAddressBook>!) -> ABAddressBook? {
        if let reference = reference {
            return Unmanaged<NSObject>.fromOpaque(reference.toOpaque()).takeUnretainedValue()
        }
        return nil
    }
    
    // address book email reference
    fileprivate func extractEmailReference(_ reference: Unmanaged<ABMultiValue>!) -> ABMultiValue? {
        if let reference = reference {
            return Unmanaged<NSObject>.fromOpaque(reference.toOpaque()).takeUnretainedValue()
        }
        return nil
    }
    
    // address book email string
    fileprivate func extractEmailString(_ email: Unmanaged<AnyObject>!) -> String? {
        if let email = email {
            return Unmanaged.fromOpaque(email.toOpaque()).takeUnretainedValue() as CFString as String
        }
        return nil
    }
    
    // extracts a contact name from a contact reference
    fileprivate func processContactName(_ reference: ABAddressBook) -> String {
       
        
        if let firstName = ABRecordCopyCompositeName(reference)?.takeRetainedValue() as String? {
            //print("FIRST NAME: \(firstName)")
            return firstName
        } 
        return ""
   
    }
    
    // extracts a contact email from a contact reference
    fileprivate func processContactEmail(_ reference: ABAddressBook) -> String? {
        
        // fetch email references for the contact
        let emails: ABMultiValue? = extractEmailReference(ABRecordCopyValue(reference, kABPersonEmailProperty))
        
        // return if the user doesn't have any emails
        if ABMultiValueGetCount(emails) <= 0 {
            return nil
        }
        
        // return the first email
        return extractEmailString(ABMultiValueCopyValueAtIndex(emails, 0))
    }
    
    class func processContacts() -> [AddressBookContact] {
        var errorRef: Unmanaged<CFError>?
        let addressBook: ABAddressBook? = extractAddressBookReference(ABAddressBookCreateWithOptions(nil, &errorRef))
        
        let contactList: NSArray = ABAddressBookCopyArrayOfAllPeople(addressBook).takeRetainedValue()
        
        var contacts: [AddressBookContact] = []
        for contact in contactList {
            
            if AddressBookContact(reference: contact as ABAddressBook).contactName != "" {
                contacts.append(AddressBookContact(reference: contact as ABAddressBook))
            }
        }
        
        return contacts
    }
    
    class func fetchAllContacts(_ completionHandler: AddressBookContactCallback?) {
        
        // check authorization status
        if ABAddressBookGetAuthorizationStatus() == .denied || ABAddressBookGetAuthorizationStatus() == .restricted {
            // XXX permission denied
            // handle this
            completionHandler?(nil)
            return
        }
        
        else if ABAddressBookGetAuthorizationStatus() == .authorized {
            
            // fetch all contacts and fire completion handler
            completionHandler?(processContacts())
            return
        }
        
        else {
            
            var errorRef: Unmanaged<CFError>? = nil
            
            let addressBook: ABAddressBook? = extractAddressBookReference(ABAddressBookCreateWithOptions(nil, &errorRef))
            ABAddressBookRequestAccessWithCompletion(addressBook) { (success, error) in
                if error != nil {
                    // XXX handle errors
                    completionHandler?(nil)
                    return
                }
                
                // if user pressed dont allow
                if !success{
                    completionHandler?(nil)
                    return
                }
                
                // fetch names with a valid email
                completionHandler?(self.processContacts())
            }
        }
    }
    
    class func fetchAllContactsWithEmail(_ completionHandler: AddressBookContactCallback?) {
        
        fetchAllContacts { (contacts) in
            
            // handle errors
            if contacts == nil {
                completionHandler?(nil)
                return
            }
            
            // filter out contacts with a valid email
            completionHandler?(contacts?.filter { $0.contactEmail != nil })
        }
    }
}
