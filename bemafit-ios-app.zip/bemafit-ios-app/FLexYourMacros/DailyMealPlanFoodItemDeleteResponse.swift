//
//  DailyMealPlanFoodItemDeleteResponse.swift
//  FlexYourMacros
//
//  Created by Minimol BI on 15/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class DailyMealPlanFoodItemDeleteResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var dailyMealPlanId: String?
    
    // route instance variables
    var dailyMealPlanFoodId: String?
    
    // daily meal plan delete response mapping
    class var dailyMealPlanFoodItemDeleteResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(DailyMealPlanFoodItemDeleteResponse.metaModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: dailyMealPlanFoodItemDeleteResponseMapping, method: .DELETE, pathPattern: Constants.ServiceConstants.kDailyMealPlanFoodItemDeleteUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func deleteDailyMealPlan(_ dailyMealPlanId: String,foodId: String, completionHandler: @escaping (_ responseStatus: String) -> ()) {
        // delete the message thread
        
        // set access token
        RestKitManager.setToken(true)
        
        let dailyMealPlanFoodItemDeleteResponse = DailyMealPlanFoodItemDeleteResponse()
        dailyMealPlanFoodItemDeleteResponse.dailyMealPlanId = dailyMealPlanId
        dailyMealPlanFoodItemDeleteResponse.dailyMealPlanFoodId = foodId

        
        RestKitManager.shared().delete(dailyMealPlanFoodItemDeleteResponse, path: nil, parameters: nil, success: { (operation, mappingResult) in
            
            //print("Success")
            let deleteResponseObject = mappingResult?.firstObject as! DailyMealPlanFoodItemDeleteResponse
            
            if let responseMeta = deleteResponseObject.meta {
                
                // completion handler
                completionHandler(responseMeta.responseStatus!)
            }
            
            }) { (operation, error) in
                //print("error \(error)");
                
        }
        
    }
}
