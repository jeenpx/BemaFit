//
//  DashboardViewLogHeaderView.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 23/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol DashboardViewLogHeaderViewDelegate {
    func buttonActionViewLog(_ sender: DashboardViewLogHeaderView)
    func clickedOnAdHeader(_ urlString:String)
}

class DashboardViewLogHeaderView: UIView {
    
    var dashboardViewLogHeaderViewDelegate: DashboardViewLogHeaderViewDelegate?
    var imageViewAd = UIImageView()
    
    var advertisementDetail = Advertisement()
    var adHeight = 0.0
    
    init() {
        super.init(frame: CGRect(x: 0, y: 0, width: 500, height: 100))
        
        addSubViewsToView()
        //        configureHeaderView()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubViewsToView()
        //        configureHeaderView()
    }
    
    override func layoutIfNeeded() {
        super.layoutIfNeeded()
        
    }
    
    convenience init(delegate: DashboardViewLogHeaderViewDelegate, advertisement: Advertisement) {
        self.init()
        
        // setup delegate
        dashboardViewLogHeaderViewDelegate = delegate
        advertisementDetail = advertisement
        
        if let imageURL = advertisementDetail.imageURL {
            
            imageViewAd.setImageWith(imageURL as URL!, placeholderImage: nil)
            imageViewAd.contentMode = UIViewContentMode.scaleToFill
            imageViewAd.layer.masksToBounds = true
            imageViewAd.layer.cornerRadius = 10
            
            // add tap gesture
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(DashboardViewLogHeaderView.imageViewTapped(_:)))
            imageViewAd.isUserInteractionEnabled = true
            imageViewAd.addGestureRecognizer(tapGesture)
            adHeight = Double(self.frame.height) - 45.0
            configureHeaderView(advertisement)
            
        }
        
        //self.layoutSubviews()
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        addSubViewsToView()
        //        configureHeaderView()
    }
    
    var labelBgView = UIView()
    var label =  UILabel()
    var button =
    UIButton()
    
    func addSubViewsToView() {
        
        // set background
        layer.backgroundColor = UIColor.defaultGrayColor().cgColor
        labelBgView = UIView(frame: CGRect(x: 0, y: 0, width: self.bounds.width, height: 30))
        labelBgView.backgroundColor = UIColor(red: 44.0/255.0, green: 44.0/255.0, blue: 44.0/255.0, alpha: 1.0)
        addSubview(labelBgView)
        
        
        label = UILabel.init(frame: CGRect(x: 10, y: 0, width: labelBgView.frame.width - 20, height: labelBgView.frame.height))
        label.font = UIFont.helveticaBold(13)
        label.textColor = UIColor.defaultThemeBlueColor()
        label.text = &&"view_log"
        labelBgView.addSubview(label)
        
        
        button = UIButton(type: .custom)
        button.frame = CGRect(x: 10, y: 0, width: 150, height: labelBgView.frame.height)
        button.setImage(UIImage(named: "RightArrowIconBlue"), for: UIControlState())
        button.imageEdgeInsets = UIEdgeInsetsMake(2, 0, 0, 0)
        button.addTarget(self, action: #selector(didTapViewlog), for: .touchUpInside)
        button.tintColor = UIColor.defaultThemeBlueColor()
        labelBgView.addSubview(button)
        
        imageViewAd = UIImageView()
        imageViewAd.backgroundColor = UIColor.clear
        addSubview(imageViewAd)
        
    }
    
    func didTapViewlog() {
        dashboardViewLogHeaderViewDelegate?.buttonActionViewLog(self)
    }
    
    
    
    func configureHeaderView(_ advertisement: Advertisement) {
        
        // setup constraints
        label.translatesAutoresizingMaskIntoConstraints = false
        button.translatesAutoresizingMaskIntoConstraints = false
        imageViewAd.translatesAutoresizingMaskIntoConstraints = false
        
        self.layoutIfNeeded()
        
        self.imageViewAd.setNeedsUpdateConstraints()
        self.imageViewAd.updateConstraintsIfNeeded()
        self.layoutIfNeeded()
        
        labelBgView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(15)-[label]-[button]", options: NSLayoutFormatOptions.alignAllCenterY, metrics: nil, views: ["label": label, "button": button]))
        labelBgView.addConstraint(NSLayoutConstraint(item: labelBgView, attribute: .centerY, relatedBy: .equal, toItem: label, attribute: .centerY, multiplier: 1, constant: 0))
        labelBgView.addConstraint(NSLayoutConstraint(item: labelBgView, attribute: .centerY, relatedBy: .equal, toItem: button, attribute: .centerY, multiplier: 1, constant: 0))
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-5-[imageViewAd]-5-|", options: [], metrics: nil, views: ["imageViewAd": imageViewAd]))
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-15-[labelBgView]-[imageViewAd(imageHeight)]-|", options: [], metrics: ["imageHeight": advertisement.shouldDisplayAdvertisement ? self.frame.height-45 : 0], views: ["labelBgView": labelBgView, "imageViewAd": imageViewAd]))
        
        //print("ad height -----\(advertisement.shouldDisplayAdvertisement ? CGRectGetHeight(self.frame)-45 : 0)")
        
        gestureRecognizers = [UITapGestureRecognizer(target: self, action: #selector(DashboardViewLogHeaderView.showViewLog(_:)))]
    }
    
    
    func imageViewTapped(_ tapGestureRecognizer: UITapGestureRecognizer) {
        // append http and open the url
        dashboardViewLogHeaderViewDelegate?.clickedOnAdHeader(advertisementDetail.content!)
    }
    
    func showViewLog(_ sender: UITapGestureRecognizer) {
        dashboardViewLogHeaderViewDelegate?.buttonActionViewLog(self)
    }
}
