//
//  USerFacebookCredentialModel.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 13/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private var _UserFacebookCredentialModel = UserFacebookCredentialModel()

class UserFacebookCredentialModel: NSObject {
    
    var fbUserId: String?
    var fbUserName: String?
    var fbUserEmail: String?
    var fbUserFirstName: String?
    var fbUserLastName: String?
    var fbUserGender: String?
    var userFbAccessToken: String?
    
    class var sharedUserFacebookCredentialModel: UserFacebookCredentialModel {
        return _UserFacebookCredentialModel
    }
    
    class func resetSharedInstance() {
        
        _UserFacebookCredentialModel = UserFacebookCredentialModel()
    }
    
}