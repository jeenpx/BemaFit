//
//  DirectoryCheckInResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/28/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class DirectoryCheckInResponse: NSObject {
    var meta: MetaModel?
    
    // directory checkin response response mapping
    class var objectMapping: RKObjectMapping {
        
        let checkInResponseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        checkInResponseMapping?.addPropertyMapping(DirectoryCheckInResponse.metaModelKeyMapping)
        
        return checkInResponseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: objectMapping, method: .POST, pathPattern: Constants.ServiceConstants.kUrlPostBusiness, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }

    class func directoryCheckIn(_ id: String, completionHandler: @escaping (_ status: String) -> ()) {
        
        SVProgressHUD.show()
        
        // set access token
        RestKitManager.setToken(true)
        
        // input parameter
        let param: Dictionary = ["business": id]
        
        
        // check in api
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path: Constants.ServiceConstants.kUrlPostBusiness, parameters: param, constructingBodyWith: { (formData) in
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) -> Void in
            
            let directoryCheckInResponse = mappingResult?.firstObject as! DirectoryCheckInResponse
            //print("directoryCheckInResponse:\(directoryCheckInResponse.meta?.responseCode)")
            //print("respone status :\(directoryCheckInResponse.meta?.responseStatus)")
            
            
            // check for success
            if directoryCheckInResponse.meta?.responseCode != 200 {
                //print("postMessage: failure")
                completionHandler(&&"failed_to_checkin_alert_message")

                return
            }
            else {
                
                SVProgressHUD.dismiss()
                
                // completion handler to return success
                completionHandler(&&"checked_in_successfully_alert_message")
            }
            
            }) { (operation, error) in
                
                SVProgressHUD.dismiss()
                //print("failed to load postMessage with error \(error)")
                completionHandler(&&"failed_to_checkin_alert_message")

        }
        
        RestKitManager.shared().enqueue(operation)
        
    }
    
}
