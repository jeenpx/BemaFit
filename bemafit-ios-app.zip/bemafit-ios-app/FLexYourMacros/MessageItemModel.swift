//
//  MessageModel.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/24/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class MessageItemModel: NSObject {
    // model instance variables
    
    var messageId: String?
    var senderId: String?
    var senderFirstName: String?
    var senderLastName: String?
    var senderPhoto: String?
    var receiverId: String?
    var receiverFirstName: String?
    var receiverLastName: String?
    var receiverPhoto: String?
    var message: String?
    var createdDate: String?
    var readStatus: String?
    var senderUserName: String?
    var receiverUserName: String?
    
    class var objectMapping: RKObjectMapping {
        // object mapping
        
        let messageMapping = RKObjectMapping(for: self)
        messageMapping?.addAttributeMappings(from: mappingDictionary)
        return messageMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["message_id":"messageId", "sender_id": "senderId", "sender_first_name":"senderFirstName", "sender_last_name":"senderLastName",
            "sender_photo":"senderPhoto", "receiver_id":"receiverId", "receiver_first_name":"receiverFirstName", "receiver_last_name":"receiverLastName",
            "receiver_photo":"receiverPhoto", "message":"message", "created_date":"createdDate", "read_status":"readStatus", "sender_user_name":"senderUserName", "receiver_user_name": "receiverUserName"])
    }
    
    class func getMessageFriend(_ messageItemModel: MessageItemModel) -> (friendId: String, friendName: String, friendPhoto: String, friendUserName: String) {
        // tuple returns friend Id, friend name and friend photo
        
        if messageItemModel.receiverId == AppConfiguration.sharedAppConfiguration.userDetails?.userId {
            return (messageItemModel.senderId!, messageItemModel.senderFirstName! + messageItemModel.senderLastName!,
                messageItemModel.senderPhoto!, messageItemModel.senderUserName!)
        }
        else {
            return (messageItemModel.receiverId!, messageItemModel.receiverFirstName! + messageItemModel.receiverLastName!,
                messageItemModel.receiverPhoto!, messageItemModel.receiverUserName!)
        }
        
    }
    
    //    class func getMessageList(offset: Int, limit: Int, completionHandler: ((messages: [MessageItemModel]?) -> ())?) {
    //        MessageResponse.getMessages(offset, andLimit: limit) { (messages) in
    //
    //            if let completionHandler = completionHandler {
    //                completionHandler(messages: messages)
    //            }
    //        }
    //    }
}
