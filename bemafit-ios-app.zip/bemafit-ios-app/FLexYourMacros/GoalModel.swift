//
//  GoalModel.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 13/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class GoalModel: NSObject {
    
    var goalId: String?
    var goalName: String?
    var goalOptions: [GoalOptionModel]?
    var goalCalorie: Double = 0.0
    
    class var objectMapping: RKObjectMapping {
        
        let activityMapping = RKObjectMapping(for: self)
        activityMapping?.addAttributeMappings(from: mappingDictionary)
        activityMapping?.addPropertyMapping(GoalModel.goalOptionsModelKeyMapping)
        return activityMapping!
    }
    
    fileprivate class var mappingDictionary: [String : String] {
        return(["id":"goalId", "goal":"goalName"])
    }
    
    fileprivate class var goalOptionsModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathGoalOption, toKeyPath: "goalOptions", with: GoalOptionModel.objectMapping)
    }

}

class GoalOptionModel: NSObject {
   
    var goalOptionId: String?
    var goalPercentage: String?
    var goalOptionName: String?
    
    class var objectMapping: RKObjectMapping {
        
        let activityMapping = RKObjectMapping(for: self)
        activityMapping?.addAttributeMappings(from: mappingDictionary)
        return activityMapping!
    }
    
    fileprivate class var mappingDictionary: [String : String] {
        return(["goal_option_id":"goalOptionId", "percentage":"goalPercentage", "goal_option":"goalOptionName"])
    }
}
