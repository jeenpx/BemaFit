//
//  DirectoryModel.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/26/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class DirectoryModel: NSObject {
    
    // model instance variables
    var id: String?
    var name: String?
    var directoryDescription: String?
    var address1: String?
    var address2: String?
    var premiumListing: String?
    var phone: String?
    var website: String?
    var distance: String?
    var category: [DirectoryCategory]?
    var images: [DirectoryImages]?
    var workingHours: [DirectoryHours]?
    var stateCode: String?
    
//    var descriptionHeight {
//        return directoryDescription?.expectedHeight(<#width: Double#>, font: <#UIFont#>)
//    }
    
    class var objectMapping: RKObjectMapping {
        
        // object mapping
        let directoryModelMapping = RKObjectMapping(for: self)
        directoryModelMapping?.addAttributeMappings(from: mappingDictionary)
        
        // give referece to directory model
        directoryModelMapping?.addPropertyMapping(DirectoryModel.categoryKeyMapping)
        
        // give referece to directory image model
        directoryModelMapping?.addPropertyMapping(DirectoryModel.imagesKeyMapping)
        
        // give referece to directory hours model
        directoryModelMapping?.addPropertyMapping(DirectoryModel.hoursKeyMapping)
        
        return directoryModelMapping!
        
    }
    
    
    class var mappingDictionary: [String : String] {
        return(["guid":"id", "name":"name", "description":"directoryDescription", "address1":"address1", "address2":"address2",
            "premium_listing":"premiumListing", "phone":"phone", "website":"website", "distance":"distance", "state_code": "stateCode"])
    }
    
    fileprivate class var categoryKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathBusinessCategory, toKeyPath: "category", with: DirectoryCategory.objectMapping)
    }
    
    fileprivate class var imagesKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathBusinessImages, toKeyPath: "images", with: DirectoryImages.objectMapping)
    }
    
    fileprivate class var hoursKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathBusinessHours, toKeyPath: "workingHours", with: DirectoryHours.objectMapping)
    }
    
    func getWorkingHours(_ day: String) -> DirectoryHours? {
        return workingHours?.filter { $0.acceptsDay(day) }.first
    }
    
    class func showAlert(_ error: NSError?) {
        
        // no need to handle errors if we dont have any :)
        if error == nil { return }
        
        // get the tile and message for the alert
        if let userInfo = error?.userInfo {
            let title = userInfo["title"] as! String
            let message = userInfo["message"] as! String
            
            // show alert
            UIAlertView(title: &&title, message: &&message, delegate: nil, cancelButtonTitle: &&"cancel").show()
        }
    }
    
    class func getBusinessDirectory(_ id: String, completionHandler: @escaping (_ businessDirectory: DirectoryModel) -> ()) {
        
        let params = ["bid": id]
        
        // show hud
        SVProgressHUD.show()
        
        DirectoryGetResponse.getBusinessDirectory(params) { (businessDirectory, error) in
            
            // hide hud
            SVProgressHUD.dismiss()
            
            // handle errors if any
            DirectoryModel.showAlert(error)
            
            completionHandler(businessDirectory ?? DirectoryModel())
        }
    }
}
