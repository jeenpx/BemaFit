//
//  FoodDetailViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 27/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FoodDetailHeader: UITableViewHeaderFooterView {
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // set text
        textLabel!.text = &&"nutrition_facts"
        
        
        // set label text color
        textLabel!.textColor = UIColor.white
        
        // set background color
        contentView.backgroundColor = UIColor(red: 44.0/255.0, green: 44.0/255.0, blue: 44.0/255.0, alpha: 1.0)//UIColor.blackColor()
    }
}

class FoodDetailViewController: UITableViewController, UITextFieldDelegate, UIAlertViewDelegate {
    @IBOutlet weak var cellSplitFood: UITableViewCell!
    
    enum FromController{
        
        
        case dailyMealPlan
        case viewLog
        
        
    }
    @IBOutlet fileprivate weak var textFieldServingSize: UITextField!
    @IBOutlet weak var cellSendFood: UITableViewCell!
    @IBOutlet fileprivate weak var textFieldNumberOfServings: UITextField!
    @IBOutlet fileprivate weak var textFieldCalories: UITextField!
    @IBOutlet fileprivate weak var textFieldFat: UITextField!
    @IBOutlet fileprivate weak var textFieldSaturated: UITextField!
    @IBOutlet fileprivate weak var textFieldPolyunsaturated: UITextField!
    @IBOutlet fileprivate weak var textFieldMonosaturated: UITextField!
    @IBOutlet fileprivate weak var textFieldTrans: UITextField!
    @IBOutlet fileprivate weak var textFieldCholesterol: UITextField!
    @IBOutlet fileprivate weak var textFieldSodium: UITextField!
    @IBOutlet fileprivate weak var textFieldPotassium: UITextField!
    @IBOutlet weak var labelBrandName: UILabel!
    @IBOutlet weak var textFieldRecomendedServingSize: UITextField!
    
    @IBOutlet weak var textFieldCarbohydrate: UITextField!
    @IBOutlet weak var textFieldProtein: UITextField!
    @IBOutlet weak var textFieldFiber: UITextField!
    @IBOutlet weak var barButtonLog: UIBarButtonItem!
    @IBOutlet weak var textFieldSugar: UITextField!
    
    
    typealias FoodUpdateCallBack = (_ food:Food,_ fromController : FromController) -> (Void)
    var food: Food = Food(name: "")
    
    // the mealtype if it has one already selected
    var mealType: MealType?
    
    var logDate =  Date()
    
    var isDailyMealPlan = false
    
    var dailyMealType = DailyMealType(dailyMealTypeName: "")
    
    // tells whether the food can be updated
    var canUpdate = false
    
    // tells whether the values entered are valid and can be processed
    var canProcess = true
    
    // tells whether to abort validity checks
    var canAbort = false
    
    var foodUpdateCallback : FoodUpdateCallBack?
    
    var isMealTypeSelected: Bool {
        return mealType != nil
    }
    var fromController : FromController?
    var isComingFromViewLog = false
    
    var isComingFromMealPlanDetails = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // configure view
        configureView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // cant abort checks when the view is visible
        canAbort = false
        
        // configure navigation button
        
        
        configureNavigationButton()
        reloadData()
        // reload data
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        
        
        
        
        
        super.viewWillDisappear(animated)
        
        
        
        // can abort checks now
        canAbort = true
        
        tableView.endEditing(true)
    }
    
    //    -(void) viewWillDisappear:(BOOL)animated {
    //    if ([self.navigationController.viewControllers indexOfObject:self]==NSNotFound) {
    //    // back button was pressed.  We know this is true because self is no longer
    //    // in the navigation stack.
    //    }
    //    [super viewWillDisappear:animated];
    //    }
    
    func configureNavigationButton() {
        
        
        
        if fromController == FromController.dailyMealPlan{
            barButtonLog.image = nil
            barButtonLog.title = &&"update"
            barButtonLog.isEnabled = self.canUpdate
            textFieldNumberOfServings.isEnabled = self.canUpdate
            self.navigationController?.navigationItem.rightBarButtonItem = nil
            self.cellSendFood.isHidden = true
            self.cellSplitFood.isHidden = true
            self.cellSplitFood.frame.size.height = 0.0
            self.cellSendFood.frame.size.height = 0.0
        }
        if isMealTypeSelected {
            barButtonLog.title = &&"log"
            barButtonLog.image = nil
        }
        else if canUpdate {
            barButtonLog.title = &&"update"
            barButtonLog.image = nil
        }
    }
    
    func configureView() {
        
        // set title
        title = food.name
        
        // register table header
        tableView.register(FoodDetailHeader.self, forHeaderFooterViewReuseIdentifier: Storyboard.FoodDetailHeader)
    }
    
    func reloadData() {
        
        let foodUnit = food.unit
        
//         populate textfields with new values
        textFieldServingSize.text = "\(food.servingSize.roundedString()) \(foodUnit)"
        
        
        var val = Double(food.servingSize) * Double(food.servingSizeOriginal)
        var recommendedServingSize = "\(val.roundedString()) x \(foodUnit)"
        if fromController == FromController.dailyMealPlan {
            textFieldServingSize.text = "\(foodUnit)"
            val = Double(food.servingSizeOriginal)
            recommendedServingSize = "\(val.roundedString()) x \(foodUnit)"
        }
        
        textFieldRecomendedServingSize.text = recommendedServingSize
        textFieldNumberOfServings.text = "\(food.numberOfServings.roundedString())"
        textFieldCalories.text = "\((food.calories).roundedString())"
        textFieldFat.text = "\((food.fat).roundedString())"
        textFieldSaturated.text = "\((food.saturated).roundedString())"
        textFieldPolyunsaturated.text = "\((food.polyunsaturated).roundedString())"
        textFieldMonosaturated.text = "\((food.monosaturated).roundedString())"
        textFieldTrans.text = "\((food.trans).roundedString())"
        textFieldCholesterol.text = "\((food.cholesterol).roundedString())"
        textFieldSodium.text = "\((food.sodium).roundedString())"
        textFieldPotassium.text = "\((food.potassium).roundedString())"
        labelBrandName.text = food.brandName
        textFieldCarbohydrate.text = "\(food.carbohydrates.roundedString())"
        textFieldFiber.text = "\(food.fiber.roundedString())"
        textFieldProtein.text = "\(food.protein.roundedString())"
        if var sugar = food.sugar {
            textFieldSugar.text = "\(sugar.roundedString())"
        }
        else {
            textFieldSugar.text = "NA"
        }
        
        
        /*
         // populate textfields with new values
         textFieldServingSize.text = "\(food.servingSize.roundedString()) \(food.unit)"
         if fromController == FromController.dailyMealPlan{
         
         textFieldServingSize.text = "\(food.unit)"
         }
         
         
         textFieldNumberOfServings.text = "\(food.numberOfServings.roundedString())"
         textFieldCalories.text = "\((food.calories).roundedString())"
         textFieldFat.text = "\((food.fat).roundedString())"
         textFieldSaturated.text = "\((food.saturated).roundedString())"
         textFieldPolyunsaturated.text = "\((food.polyunsaturated).roundedString())"
         textFieldMonosaturated.text = "\((food.monosaturated).roundedString())"
         textFieldTrans.text = "\((food.trans).roundedString())"
         textFieldCholesterol.text = "\((food.cholesterol).roundedString())"
         textFieldSodium.text = "\((food.sodium).roundedString())"
         textFieldPotassium.text = "\((food.potassium).roundedString())"
         labelBrandName.text = food.brandName
         textFieldCarbohydrate.text = "\(food.carbohydrates.roundedString())"
         textFieldFiber.text = "\(food.fiber.roundedString())"
         textFieldProtein.text = "\(food.protein.roundedString())"
         */
        
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == Storyboard.NutritionFactsSectionId ? 32 : 0
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return tableView.dequeueReusableHeaderFooterView(withIdentifier: Storyboard.FoodDetailHeader) as! FoodDetailHeader
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        // get the cell for indexpath using super method for static table view
        let cell = super.tableView(tableView, cellForRowAt: indexPath)
        
        return cell.isHidden == true ? 0 : cell.frame.size.height ?? 0
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // get the selected cell
        let cell = tableView.cellForRow(at: indexPath)
        
        if cell?.reuseIdentifier == Storyboard.CellIdentifiers.SplitFoodCell {
            //print("Split Food")
        }
        else if cell?.reuseIdentifier == Storyboard.CellIdentifiers.SendFoodDetailsCell {
            //print("Food Details")
        }
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        cell.setSeparatorInsetZero()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if string.isEmpty { return true }
        
        var isValid = true
        let text = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        
        // check for unwanted characters
        let replacementStringIsLegal = string.rangeOfCharacter(from: CharacterSet(charactersIn: "0123456789.").inverted) == nil
        
        // check for string count
        let resultingStringLengthIsLegal = text.characters.count <= 5
        
        
        // check if the number is valid
        let scanner = Scanner(string: text)
        let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
        
        let isLowNumber = text.doubleValue < 100
        
        isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber
        
        return isValid
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        // no checks if aborting
        if canAbort { return true }
        
        let shouldEndEditing = textField.text!.doubleValue > 0
        if shouldEndEditing {
            
            // update lock
            canProcess = true
            
            if textField == textFieldNumberOfServings {
                // update number of servings
                food.updateNumberOfServings((textField.text! as NSString).doubleValue)
            } else if textField == textFieldServingSize {
                // update number of servings
                food.servingSize = (textField.text! as NSString).doubleValue
            }
            
            // reload values
            reloadData()
        }
        else {
            
            // update lock
            canProcess = false
            
            // show alert
            UIAlertView(title: &&"error", message: &&"serving_size_validation_alert_message", delegate: nil, cancelButtonTitle: &&"cancel").show()
        }
        
        return shouldEndEditing
    }
    
    struct Storyboard {
        struct Segues {
            static let SplitFood = "kSplitFoodSegue"
            static let SendFoodDetail = "kSendFoodDetailSegue"
            static let MealTypeListSegue = "kMealTypeListSegue"
            static let UnwindViewLogSegue = "kUnwindViewLogSegue"
        }
        
        struct CellIdentifiers {
            static let SplitFoodCell = "kSplitFoodCell"
            static let SendFoodDetailsCell = "kSendFoodDetailsCell"
        }
        static let NutritionFactsSectionId = 1
        static let FoodDetailHeader = "kFoodDetailHeader"
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == Storyboard.Segues.SplitFood {
            let sendDetailsViewController = segue.destination as! SendDetailsViewController
            sendDetailsViewController.sendDetailsViewMode = .splitFood
            sendDetailsViewController.food = food
            sendDetailsViewController.logDate = logDate
            sendDetailsViewController.isFromDashboard = !isComingFromViewLog
        }
        else if segue.identifier == Storyboard.Segues.SendFoodDetail {
            let sendDetailsViewController = segue.destination as! SendDetailsViewController
            sendDetailsViewController.sendDetailsViewMode = .foodDetail
            sendDetailsViewController.food = food
            sendDetailsViewController.logDate = logDate
            sendDetailsViewController.isFromDashboard = !isComingFromViewLog
        }
        else if segue.identifier == Storyboard.Segues.MealTypeListSegue {
            let mealTypeListViewController = segue.destination as! MealTypeListViewController
            
            mealTypeListViewController.logDate = logDate
            mealTypeListViewController.food = sender as! Food
        }
    }
    
    @IBAction func babButtonActionLog(_ sender: UIBarButtonItem) {
        
        tableView.endEditing(true)
        
        if fromController == FromController.dailyMealPlan{
            
            food.updateNumberOfServings((textFieldNumberOfServings.text! as NSString).doubleValue)
            
            self.foodUpdateCallback?(self.food,self.fromController!)
            _ = self.navigationController?.popViewController(animated: true)
            
            return
        }
        
        
        if isDailyMealPlan {
            
            food.dailyMealType = dailyMealType
            food.mealType = mealType!
            food.addedDate = Date()
            NotificationCenter.default.post(name: Notification.Name(rawValue: "RefreshMealPlanIdentifier"), object: nil, userInfo: ["newFood": food, "method": "Read"])
            
            //resign to the daily meal plan viewcontroller
            if let viewControllers = navigationController?.viewControllers {
                for viewController in viewControllers {
                    // some process
                    if viewController.isKind(of: DailyMealPlanDetailViewController.self) {
                        _ = self.navigationController?.popToViewController(viewController, animated: true)
                    }
                } 
            }
            return
        }
        
        if !canProcess { return }
        
        // update if possible
        
        
        if canUpdate {
            
            food.servingSize = (textFieldServingSize.text! as NSString).doubleValue
            food.numberOfServings = (textFieldNumberOfServings.text! as NSString).doubleValue
            
            food.updateFoodLog { (error) -> () in
                // show alert controller if possible else show alert view
                
                if #available(iOS 8.0, *) {
                    let alert = UIAlertController(title: &&"alert_title_update", message: &&"alert_message_update", preferredStyle: .alert)
                    
                    alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
                    
                    self.present(alert, animated: true, completion: nil)
                } else {
                    // Fallback on earlier versions
                    UIAlertView(title: &&"alert_title_update", message: &&"alert_message_update", delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok").show()
                }
                
            }
        }
            // log if the meal type is selected
        else if isMealTypeSelected {
            // log food
            food.logFood(mealType!.id, mealDate: logDate ?? Date(), userGuid: AppConfiguration.sharedAppConfiguration.userDetails!.userId!) { (error) -> () in
                //print("logged food")
                
                // load view log
                self.loadViewLog()
            }
        }
            // show meal type list screen
        else {
            performSegue(withIdentifier: Storyboard.Segues.MealTypeListSegue, sender: food)
        }
    }
    
    
    //ASSUMING THIS FUNCTION WILL GET CALLED ONLY FROM DAILY MEAL PLAN VIEW CONTROLLER
    class func openFromViewController(_ fromViewcontroller:UINavigationController?, withFood food : Food, fromController: FromController,openForEdit : Bool, foodUpdateCallBack : @escaping FoodUpdateCallBack) -> () {
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let foodDetailViewController = storyBoard.instantiateViewController(withIdentifier: "FoodDetailViewControllerID") as! FoodDetailViewController
        
        foodDetailViewController.food = food
        foodDetailViewController.fromController = fromController
        foodDetailViewController.foodUpdateCallback = foodUpdateCallBack
        foodDetailViewController.canUpdate = openForEdit
        foodDetailViewController.isComingFromMealPlanDetails = true
        fromViewcontroller!.pushViewController(foodDetailViewController, animated: true)
        
        
    }
    func barButtonBack() {
        
        
    }
    
}
