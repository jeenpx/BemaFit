//
//  HashTagGetResponse.swift
//  FlexYourMacros
//
//  Created by Attila Roy on 16/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class HashTagGetResponse: NSObject {
    
    // model instance variables
    var metaModel = MetaModel()
    var newsFeeds = [NewsFeed]()
    var pageMetaModel = PageMetaModel()
    
    
    // route instance variables
    var hashtag = ""
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
        responseMapping?.addPropertyMapping(metaModelMapping)
        
        // newsfeeds mapping
        let newsFeedModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathNewsFeeds, toKeyPath: "newsFeeds", with: NewsFeed.objectMapping)
        responseMapping?.addPropertyMapping(newsFeedModelMapping)
        
        // page meta model mapping
        let pageMetaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathPageMeta, toKeyPath: "pageMetaModel", with: PageMetaModel.objectMapping)
        responseMapping?.addPropertyMapping(pageMetaModelMapping)
        
        return responseMapping!
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let hashTagGetResponseDescriptor = RKResponseDescriptor(mapping: HashTagGetResponse.responseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kHashTagUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return hashTagGetResponseDescriptor!
    }

    class func getHashTagFeedPosts(_ offset: Int, andLimit limit: Int, hashTag: String, pageMetaModel pageMeta: PageMetaModel, completionHandler: @escaping (_ newsFeeds: [NewsFeed]?, _ pageMeta: PageMetaModel) -> ()) {
        
        SVProgressHUD.show()
        
        // set access token
        RestKitManager.setToken(true)
        
        // input parameters
        let params: [String: String] = ["offset": String(offset), "limit": String(limit), "hid": pageMeta.hashId, "rid1": pageMeta.rangeId, "rid2": pageMeta.subRangeId]
        
        // instance of hash tag response
        let hashTagGetResponse = HashTagGetResponse()
        
        // save hashtag
        hashTagGetResponse.hashtag = hashTag
        
        // api call with instance of message model class
        RestKitManager.shared().getObject(hashTagGetResponse, path: nil, parameters: params, success: { (operation, mappingResult) in
            
            //print("Success")
            SVProgressHUD.dismiss()
            let hashTagGetResponse = mappingResult?.firstObject as! HashTagGetResponse
            
            // check for success
            if hashTagGetResponse.metaModel.responseCode != 200 {
                SVProgressHUD.dismiss()
                //print("failure data\(hashTagGetResponse.metaModel.responseCode)")
                return
            }
                        
            // completion handler for news feeds
            completionHandler(hashTagGetResponse.newsFeeds as [NewsFeed]?, hashTagGetResponse.pageMetaModel)
            
            }) { (operation, error) in
                SVProgressHUD.dismiss()
                //print("erorrrrrrr \(error)");
        }

    }
   
}
