//
//  BrcodeViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/15/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit
import Foundation

protocol BarcodeScannerDelegate {
    func barcodeScanner(_ barcodeScanner: BarcodeViewController, didScanBarcode barcode: Barcode)
}

class BarcodeViewController: UIViewController {
    
    // barcode view instance
    @IBOutlet weak var barcodeScannerView: BarcodeScannerView!
    
    // barcode scan delegate
    var barcodeScannerDelegate: BarcodeScannerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // scan barcode
        scanBarcode()
      }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        // hide the navigation bar
        self.navigationController?.isNavigationBarHidden = true
    }
    
    func scanBarcode() {
        
        // read the barcode
        barcodeScannerView.readBarcode { (barcodeScannerView, barcode) in
            //print("barcode data:\(barcode?.barcodeData)")
            
            if let barcode = barcode {
                self.barcodeScannerDelegate?.barcodeScanner(self, didScanBarcode: barcode)
            }

            // pop view controller
            self.navigationController?.popViewController(animated: true)
        }
    }
}
