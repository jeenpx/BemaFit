//
//  HashTagTextView.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 30/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol HashTagTextViewDelegate {
    func hashTagTextView(_ hashTagTextView: HashTagTextView, didSelectHashTag hashTag: String)
    func hashTagTextView(_ hashTagTextView: HashTagTextView, didSelectUser user: String)
    func hashTagTextView(_ hashTagTextView: HashTagTextView, didSelectBusinessDirectory businessDirectory: String)
}

class HashTagTextView: UITextView {
    
    // hashtag attribute name
    let kHashTag = "isHashTag"
    
    // user attribute name
    let kUser = "isUser"
    
    // business directory attribute name
    let kBusinessDirectory = "isBusinessDirectory"
    
    // hash tag textview delegate
    var hashTagTextViewDelegate: HashTagTextViewDelegate?
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        // configure text view
        configureTextView()
    }
    
    func configureTextView() {

        // not editable
        isEditable = false
        
        // disable scrolling
        isScrollEnabled = false
        
        // detect all data including urls, phone numbers etc
        dataDetectorTypes = .all
        
        // add tap gesture
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(HashTagTextView.textViewTapped(_:)))
        addGestureRecognizer(tapGestureRecognizer)
    }
    
    func convertToDefaultTextAttributes() {
        
        // create attributed text from the current text
        attributedText = NSMutableAttributedString(string: text, attributes: [NSFontAttributeName: UIFont.helvetica(13),  NSForegroundColorAttributeName: UIColor.darkTextGrayColor()])
    }
    
    func configureForHashTagDetection(_ shouldRestoreFirst: Bool = false) {
        
        // restore if we should
        if shouldRestoreFirst {
            convertToDefaultTextAttributes()
        }
        
        // the regular expression to filter out hashtags
        let regularExpressionHashtags = try! NSRegularExpression(pattern: "#(\\w+)", options: .caseInsensitive)
        
        // filter out hashtag text checking results using the regular expression
        let hashTagResults = regularExpressionHashtags.matches(in: text, options: .withTransparentBounds, range: NSMakeRange(0, text.characters.count)) 
        
        // create attributed text from the current text respecting textview properties
        let attributedText = NSMutableAttributedString(string: text, attributes: [NSFontAttributeName: font ??  UIFont(), NSForegroundColorAttributeName: UIColor.darkTextGrayColor()])
        
        // set attributes for hashtags
        for hashtag in hashTagResults {
            attributedText.setAttributes([NSFontAttributeName: UIFont.helveticaBold(13), NSForegroundColorAttributeName: UIColor.defaultThemeBlueColor(), kHashTag: (text as NSString).substring(with: hashtag.range)], range: hashtag.range)
        }
        
        // the regular expression to filter out users
        let regularExpressionUsers = try! NSRegularExpression(pattern: "(^| )@(\\w+)", options: .caseInsensitive)
        
        // filter out user text checking results using the regular expression
        let userResults = regularExpressionUsers.matches(in: text, options: .withTransparentBounds, range: NSMakeRange(0, text.characters.count)) 
        
        // set attributes for users
        for user in userResults {
            // removing user key to remove user detection
//            attributedText.setAttributes([NSFontAttributeName: UIFont.helveticaBold(size: 13), kUser: (text as NSString).substringWithRange(user.range)], range: user.range)
            attributedText.setAttributes([NSFontAttributeName: UIFont.helveticaBold(13),  NSForegroundColorAttributeName: UIColor.darkGray], range: user.range)
        }
        
        // set attributed text with highlighted hashtags
        self.attributedText = attributedText
    }
    
    func prependSender(_ sender: String, senderId: String? = nil) {
        
        // configure the sender
        let attributedSender = NSMutableAttributedString(string: sender + " ", attributes: [NSFontAttributeName: UIFont.helveticaBold(12), NSForegroundColorAttributeName: UIColor.defaultThemeBlueColor() , kUser: senderId ?? sender])
        
        // prepend sender
        let mutableAttributedText = NSMutableAttributedString(attributedString: self.attributedText)
        attributedSender.append(mutableAttributedText)
        self.attributedText = attributedSender
    }
    
    func appendSender(_ sender: String, senderId: String? = nil) {
        
        // configure the sender
        let attributedSender = NSMutableAttributedString(string: " " + sender, attributes: [NSFontAttributeName: UIFont.helveticaBold(12), NSForegroundColorAttributeName: UIColor.defaultThemeBlueColor() , kUser: senderId ?? sender])
        
        // append sender
        let attributedText = NSMutableAttributedString(attributedString: self.attributedText)
        attributedText.append(attributedSender)
        self.attributedText = attributedText
    }
    
    func appendBusinessDirectory(_ sender: String, senderId: String? = nil) {
        
        // configure the sender
        let attributedSender = NSMutableAttributedString(string: " " + sender, attributes: [NSFontAttributeName: UIFont.helveticaBold(12), NSForegroundColorAttributeName: UIColor.defaultThemeBlueColor() , kBusinessDirectory: senderId ?? sender])
        
        // append sender
        let attributedText = NSMutableAttributedString(attributedString: self.attributedText)
        attributedText.append(attributedSender)
        self.attributedText = attributedText
    }
    
    func setBusinessDirectoryData(_ businessDirectory: String, businessDirectoryId: String) {
        
        // configure business directory name
        let attributedName = NSMutableAttributedString(string: "\n\(businessDirectory)\n", attributes: [NSFontAttributeName: UIFont.helveticaBold(15), NSForegroundColorAttributeName: UIColor.darkTextGrayColor(), kBusinessDirectory: businessDirectoryId])
        
        // configure view business name
        let attributedViewBusiness = NSMutableAttributedString(string: &&"view_business", attributes: [NSFontAttributeName: UIFont.helveticaBold(13), NSForegroundColorAttributeName: UIColor.defaultThemeBlueColor(), kBusinessDirectory: businessDirectoryId])
        
        let attributedText = NSMutableAttributedString(attributedString: attributedName)
        attributedText.append(attributedViewBusiness)
        self.attributedText = attributedText
    }
    
    func textViewTapped(_ tapGestureRecognizer: UITapGestureRecognizer) {
        
        let textView = tapGestureRecognizer.view as! UITextView
        
        // location of the tap in textview
        var location = tapGestureRecognizer.location(in: textView)
        location.x -= textView.textContainerInset.left
        location.y -= textView.textContainerInset.top
        
        // get the character that has been tapped
        let tappedCharacterIndex = textView.layoutManager.characterIndex(for: location, in: textView.textContainer, fractionOfDistanceBetweenInsertionPoints: nil)
        
        // get the hashTag if any
        let hashtag = textView.attributedText.attribute(kHashTag, at: tappedCharacterIndex, effectiveRange: nil) as? String
        
        // if a valid hashtag is found, forward it
        if let hashTag = hashtag {
            hashTagTextViewDelegate?.hashTagTextView(self, didSelectHashTag: hashTag.substring(from: hashTag.characters.index(hashTag.startIndex, offsetBy: 1)))
        }
        
        // get the user if any
        let user = textView.attributedText.attribute(kUser, at: tappedCharacterIndex, effectiveRange: nil) as? String
        
        // if a valid user is found, forward it after removing the "@"
        if let user = user {
            hashTagTextViewDelegate?.hashTagTextView(self, didSelectUser: user)
        }
        
        // get business directory if any
        let businessDirectory = textView.attributedText.attribute(kBusinessDirectory, at: tappedCharacterIndex, effectiveRange: nil) as? String
        
        // if a valid business directory is found, forward it
        if let businessDirectory = businessDirectory {
            hashTagTextViewDelegate?.hashTagTextView(self, didSelectBusinessDirectory: businessDirectory)
        }
    }
}
