//
//  CompanyDetailsTableCell.swift
//  FlexYourMacros
//
//  Created by DBG on 12/07/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class CompanyDetailsTableCell: UITableViewCell {
    
    @IBOutlet weak var labelPhoneNumber: UILabel!
    @IBOutlet weak var labelWebsite: UILabel!
    @IBOutlet weak var labelAddress: UILabel!
    
    // width constraints
    @IBOutlet weak var constraintPhoneNumber: NSLayoutConstraint!
    @IBOutlet weak var constraintWebsite: NSLayoutConstraint!
    
    @IBOutlet weak var constraintAddress: NSLayoutConstraint!
    var  directory = DirectoryModel() {
        didSet {
            // set value for company's phone
            //labelPhoneNumber.text = directory.phone
            
            // set constraints for width
            constraintPhoneNumber.constant = CGFloat((kMainScreenWidth/2) - 20)
            constraintWebsite.constant = CGFloat((kMainScreenWidth/2) - 20)
            constraintAddress.constant = CGFloat((kMainScreenWidth/2) - 20)
            
            // set value for company's phone
            if let number = directory.phone {
                
                labelPhoneNumber.text = number != "" ? number : &&"no_phone_number"
                
                if number == "" {
                    labelPhoneNumber.textColor = UIColor.darkTextGrayColor()
                    labelPhoneNumber.font = UIFont(name: "Helvetica", size: 14)
                }
            }
            
            // set value for company's website
            if let website = directory.website {
                labelWebsite.text = website != "" ? website : &&"no_website"
                if  website == "" {
                    labelWebsite.textColor = UIColor.darkTextGrayColor()
                    labelWebsite.font = UIFont(name: "Helvetica", size: 14)
                }
            }
            
            // set value for company's address
            if let address1 = directory.address1 {
                if let address2 = directory.address2 {
                    if address1 + address2 == "" {
                       labelAddress.text = &&"no_address"
                        labelAddress.font = UIFont(name: "Helvetica", size: 14)
                    }
                    else {
                        if let stateCode = directory.stateCode {
                            labelAddress.text = address2 == "" ? address1 : address1 + "," + " " + address2 + "," + " " + stateCode
                        }
                    }
                }
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
