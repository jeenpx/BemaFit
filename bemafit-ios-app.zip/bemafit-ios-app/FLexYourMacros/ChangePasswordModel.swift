//
//  ChangePassword.swift
//  FlexYourMacros
//
//  Created by DBG on 24/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ChangePasswordModel: NSObject {
    
    var status: String?
    var user_id: String?

    class var objectMapping: RKObjectMapping {
        let dietMapping = RKObjectMapping(for: self)
        dietMapping?.addAttributeMappings(from: mappingDictionary)
        return dietMapping!
    }
    class var mappingDictionary: [String : String] {
        return(["status": "status"])
    }
}
