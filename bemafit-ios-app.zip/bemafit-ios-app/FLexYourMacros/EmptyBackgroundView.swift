//
//  EmptyBackgroundView.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/14/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import UIKit

enum EmptyBackgroundViewMode {
    case food
    case exercise
}

protocol EmptyBackgroundViewDelegate {
    func buttonActionCreateNew(_ emptyBackgroundViewMode: EmptyBackgroundView)
}

class EmptyBackgroundView: UIView {
    
    var emptyBackgroundViewDelegate: EmptyBackgroundViewDelegate?
    
    // mode defaults to Food
    var emptyBackgroundViewMode = EmptyBackgroundViewMode.food {
        didSet {
            configureView()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func configureView() {
        
        // set the background color of the view
        self.backgroundColor = UIColor.defaultGrayColor()
        
        // configure the imageview custom meal
        let imageViewCustomMeal = UIImageView(image: UIImage(named: emptyBackgroundViewMode == .food ? "NoResultMeal":"NoResultExercise"))
        
        // add tap gesture to the imageview custom meal
        imageViewCustomMeal.isUserInteractionEnabled = true
        let tapImageViewCustomMeal = UITapGestureRecognizer(target: self, action: #selector(EmptyBackgroundView.didTapCreateCustomMeal(_:)))
        imageViewCustomMeal.addGestureRecognizer(tapImageViewCustomMeal)
        
        // add the subview imageview custom meal
        self.addSubview(imageViewCustomMeal)
        
        // configure the label custom meal
        let labelCustomMeal = UILabel()
        labelCustomMeal.text = emptyBackgroundViewMode == .food ? &&"create_custom_meal":&&"create_custom_exercise"
        labelCustomMeal.font = UIFont(name: "Helvetica-Bold", size: 12)!
        labelCustomMeal.textColor = UIColor(red: 40.0/255.0, green: 141.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        
        // add tap gesture to the label custom meal
        labelCustomMeal.isUserInteractionEnabled = true
        let taplabelCustomMeal = UITapGestureRecognizer(target: self, action: #selector(EmptyBackgroundView.didTapCreateCustomMeal(_:)))
        labelCustomMeal.addGestureRecognizer(taplabelCustomMeal)
        
        // add the subview label custom meal
        self.addSubview(labelCustomMeal)
        
        // configure the label no results
        let labelNoResults = UILabel()
        labelNoResults.text = &&"no_results_found"
        labelNoResults.font = UIFont(name: "Helvetica-Bold", size: 16)!
        labelNoResults.textColor = UIColor(red: 114.0/255.0, green: 114.0/255.0, blue: 114.0/255.0, alpha: 1.0)
        
        // add the subview label no results
        self.addSubview(labelNoResults)

        // set constraints for the subviews
        setConstraintsViewCustomMeal(imageViewCustomMeal, andLabel: labelCustomMeal, andLabelNoResults: labelNoResults)
        
    }
    
    func setConstraintsViewCustomMeal(_ imageViewCustomMeal: UIImageView, andLabel labelCustomMeal: UILabel, andLabelNoResults labelNoResults: UILabel) {
        
        // set constraints for the imageview
        imageViewCustomMeal.translatesAutoresizingMaskIntoConstraints = false
        self.addConstraints([NSLayoutConstraint(item: imageViewCustomMeal, attribute: NSLayoutAttribute.centerX, relatedBy: .equal,
            toItem: self, attribute: NSLayoutAttribute.centerX, multiplier: 1.0, constant: 0.0),
            NSLayoutConstraint(item: imageViewCustomMeal, attribute: NSLayoutAttribute.centerY, relatedBy: .equal,
                toItem: self, attribute: NSLayoutAttribute.centerY, multiplier: 1.0, constant: 0.0)])
        
        self.addConstraints([NSLayoutConstraint(item: imageViewCustomMeal, attribute: NSLayoutAttribute.height, relatedBy: .equal,
            toItem: nil, attribute: NSLayoutAttribute.notAnAttribute, multiplier: 1.0, constant: 75.0),
            NSLayoutConstraint(item: imageViewCustomMeal, attribute: NSLayoutAttribute.width, relatedBy: .equal,
                toItem: nil, attribute: NSLayoutAttribute.notAnAttribute, multiplier: 1.0, constant: 75.0)])
        
        // set constraints for the label custom meal
        labelCustomMeal.translatesAutoresizingMaskIntoConstraints = false
        self.addConstraints([NSLayoutConstraint(item: labelCustomMeal, attribute: NSLayoutAttribute.top, relatedBy: .equal,
            toItem: imageViewCustomMeal, attribute: NSLayoutAttribute.bottom, multiplier: 1.0, constant: 15.0),
            NSLayoutConstraint(item: labelCustomMeal, attribute: NSLayoutAttribute.centerX, relatedBy: .equal,
                toItem: self, attribute: NSLayoutAttribute.centerX, multiplier: 1.0, constant: 0.0)])
        
        // set constraints for the label no results
        labelNoResults.translatesAutoresizingMaskIntoConstraints = false
        self.addConstraints([NSLayoutConstraint(item: labelNoResults, attribute: NSLayoutAttribute.bottom, relatedBy: .equal,
            toItem: imageViewCustomMeal, attribute: NSLayoutAttribute.top, multiplier: 1.0, constant: -15.0),
            NSLayoutConstraint(item: labelNoResults, attribute: NSLayoutAttribute.centerX, relatedBy: .equal,
                toItem: self, attribute: NSLayoutAttribute.centerX, multiplier: 1.0, constant: 0.0)])

    }
    
    func didTapCreateCustomMeal(_ tapGesture: UITapGestureRecognizer) {
        //print("didTapCreateCustomMeal entered...")
        emptyBackgroundViewDelegate?.buttonActionCreateNew(self)
    }
    
}
