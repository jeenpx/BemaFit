//
//  UpdateFoodLogResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 10/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UpdateFoodLogResponse: NSObject {
   
    var meta: MetaModel?
    var foodLogId = ""
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
        responseMapping?.addPropertyMapping(metaModelMapping)
        
        return responseMapping!
    }
    
    class func updateFoodLog(_ foodLogId: String, params: [String: Any], completionHandler: @escaping (_ error: NSError?) -> ()) {
        
        RestKitManager.setToken(true)
        
        // configure path
        let path = Constants.ServiceConstants.kFoodLogUrl + "/\(foodLogId)"
        
        let updateFoodLogResponseDescriptor = RKResponseDescriptor(mapping: UpdateFoodLogResponse.responseMapping, method: .PATCH, pathPattern: path, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        
        RestKitManager.shared().addResponseDescriptor(updateFoodLogResponseDescriptor)
        
        // create a patch request
        let request = RestKitManager.shared().request(with: nil, method: .PATCH, path: path, parameters: nil)
        
        // set params as body
        request?.httpBody = try? JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
        
        // create an operation with the request
        let operation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let updateFoodLogResponse = mappingResult?.firstObject as! UpdateFoodLogResponse
            
            // check for success
            if updateFoodLogResponse.meta?.responseCode != 200 {
                //print("XXX failed to udpate food log")
                completionHandler(NSError(domain: "FYM.FoodLog", code: 99, userInfo: ["description": "Failed to udpate food log"]))
            }
            else {
                completionHandler(nil)
            }
            }) { (operation, error) in
                //print("XXX failed to log food with error \(error)")
                completionHandler(error as! NSError)
        }
        
        // enque request operation
        RestKitManager.shared().enqueue(operation)
    }
}
