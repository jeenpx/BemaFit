//
//  DoubleExtensions.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 08/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

infix operator ** { associativity left precedence 170 }

func ** (num: Double, power: Double) -> Double{
    return pow(num, power)
}

extension Double {
    
    mutating func roundPlaces(_ decimalPlaces: Int = 1) -> Double {
        let divisor = pow(10.0, Double(decimalPlaces))
        return (self * divisor).rounded() / divisor
    }
    
    mutating func roundedString(_ decimalPlaces: Int = 1) -> String {
        return "\(roundPlaces(decimalPlaces))"
    }
}
