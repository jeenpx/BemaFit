//
//  UserMacroFormulaeViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 05/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

enum MacroFormula: String {
    case Physique = "physique"
    case LeanMass = "lean_mass"
    
    static var types = [Physique, LeanMass]
}

class UserMacroFormulaeViewController: UITableViewController, UIAlertViewDelegate {
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    struct StoryBoard {
        
        struct CellIdentifiers {
            static let HeaderCell       =  "kHeaderCell"
            static let ActivityCell     =  "kActivityCell"
        }
    }
    
    @IBOutlet weak var buttonFitPhysique: UIButton!
    @IBOutlet weak var buttonLeanMass: UIButton!
    @IBOutlet weak var buttonChooseFormula: UIButton!
    @IBOutlet var formulaInfoView: UIView!
    
    var currentIndexPath: IndexPath?
    let FymUserModel = FymUser.sharedFymUser
    var activityLevels = [ActivityLevelModel]()
    
    fileprivate var macroFormula = MacroFormula.Physique {
        didSet {
            
            //print("macro raw value ----\(macroFormula.rawValue)")
            FymUserModel.formulaType = macroFormula.rawValue
        }
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        buttonLeanMass.layer.borderWidth = 1.0
        buttonFitPhysique.layer.borderWidth = 1.0
        
        activityLevels = AppConfiguration.sharedAppConfiguration.activityLevels
        
        // set default user values
        if FymUserModel.formulaType == "" {
            macroFormula = MacroFormula.Physique
        }
        if (FymUserModel.userActivityLevelId == "") {
            FymUserModel.userActivityLevelId = activityLevels[0].activityId!
        }
        
        let selectedButton = FymUserModel.formulaType == MacroFormula.Physique.rawValue ? buttonFitPhysique : buttonLeanMass
        buttonActionFormulaSelection(selectedButton!)
        
        if UIScreen.main.bounds.width <= 320 {
            
            formulaInfoView.frame = CGRect(x: formulaInfoView.frame.origin.x, y: formulaInfoView.frame.origin.y, width: formulaInfoView.frame.size.width, height: 305)
        } else if UIScreen.main.bounds.width == 375 {
            formulaInfoView.frame = CGRect(x: formulaInfoView.frame.origin.x, y: formulaInfoView.frame.origin.y, width: formulaInfoView.frame.size.width, height: 280)
        } else {
            formulaInfoView.frame = CGRect(x: formulaInfoView.frame.origin.x, y: formulaInfoView.frame.origin.y, width: formulaInfoView.frame.size.width, height: 250)
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if (segue.identifier == "kGoalSet") {
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        return checkAllFields()
    }
    
    func checkAllFields() -> Bool {
        return true
    }
    
    @IBAction func buttonActionPopUpClosed(_ sender: Any) {
        // dismiss all popups
        KLCPopup.dismissAllPopups()
    }
    
    @IBAction func buttonActionFormulaDetails(_ sender: UIButton) {
        
        // set frame for the popup content view
        formulaInfoView.frame = CGRect(x: 0, y: 0, width: view.bounds.width - 20, height: formulaInfoView.frame.height)
        // set layout of the popup
        let layout = KLCPopupLayoutMake(.center, .center)
        // set contentview for the popup
        let popup = KLCPopup(contentView: formulaInfoView)
        popup?.show(with: layout)
    }
    
    func textFieldShouldReturn(_ textField: UITextField!) -> Bool {
        // resign keyboard
        textField.resignFirstResponder()
        return false
    }
    
    @IBAction func unwindToUserMacroFormulaeViewController(_ segue: UIStoryboardSegue) {
        self.navigationController?.isNavigationBarHidden = false
        
    }
    
    //MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return activityLevels.count
    }
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40.0
    }
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView: UIView = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.HeaderCell)!
        return headerView
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: ActivityLevelTableViewCell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.ActivityCell, for: indexPath) as! ActivityLevelTableViewCell
        
        let currentActivity = activityLevels[indexPath.row] as ActivityLevelModel
        
        if currentActivity.activityId == FymUserModel.userActivityLevelId {
            // set the first row selected
            cell.accessoryType = UITableViewCellAccessoryType.checkmark
        } else {
            cell.accessoryType = UITableViewCellAccessoryType.none
        }
        
        cell.labelActivityTitle.text = currentActivity.activityName
        cell.labelActivityDescription.text = currentActivity.activityDescription
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // assign the activity level value to the user model
        let currentActivity = activityLevels[indexPath.row] as ActivityLevelModel
        FymUserModel.userActivityLevelId = currentActivity.activityId!
        self.tableView .reloadData()
    }
    
    @IBAction func buttonActionFormulaSelection(_ sender: UIButton) {
        
        switch sender.tag {
        case 20:
            
            macroFormula = MacroFormula.Physique
            buttonLeanMass.backgroundColor = UIColor.clear
            buttonLeanMass.layer.borderColor = UIColor.darkGray.cgColor
            buttonLeanMass.setTitleColor(UIColor.darkGray, for: UIControlState())
            
        case 21:
            
            // check whether user entered the fat loss percentage
            if FymUserModel.userFatLoss == "" {
                // if not entered pops up alert and make user navigate to that page to enter the details
                if #available(iOS 8.0, *) {
                    let alert = UIAlertController(title: &&"notice", message: &&"enter_bodyfat_percent_alert_message", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: &&"cancel", style: .cancel, handler: nil))
                    alert.addAction(UIAlertAction(title: &&"go_back_alert_button_title", style: .default) {
                        _ in
                        // pop the view controller
                        self.navigationController!.popViewController(animated: true)
                        })
                    self.present(alert, animated: true, completion: nil)
                    return
                } else {
                    // Fallback on earlier versions
                    UIAlertView(title: &&"notice", message: &&"enter_bodyfat_percent_alert_message", delegate: self, cancelButtonTitle: &&"cancel", otherButtonTitles: &&"go_back_alert_button_title").show()
                    return
                }
                
                
            }
            
            macroFormula = MacroFormula.LeanMass
            buttonFitPhysique.backgroundColor = UIColor.clear
            buttonFitPhysique.layer.borderColor = UIColor.darkGray.cgColor
            buttonFitPhysique.setTitleColor(UIColor.darkGray, for: UIControlState())
        default :
            break
        }
        sender.backgroundColor = UIColor.defaultThemeBlueColor()
        sender.layer.borderColor = UIColor.defaultThemeBlueColor().cgColor
        sender.setTitleColor(UIColor.white, for: UIControlState())
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    @IBAction func buttonActionBack(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: false)
        
    }
    // alert view delegate methods
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        if buttonIndex == 1 {
            self.navigationController!.popViewController(animated: true)
        }
    }
    
}
