//
//  NewsFeedComment.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 16/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class NewsFeedComment: NSObject, HeightCalculating {
    
    var id = ""
    var comment = ""
    var image = ""
    var stringDate = ""
    var date: Date {
        return stringDate.utcDateValue("yyyy-MM-dd HH:mm:ss") ?? Date()
    }
    var userId = ""
    var userName = ""
    var userImage = ""
    
    var imageWidth = 0.0
    var imageHeight = 0.0
    
    class var objectMapping: RKObjectMapping {
        
        let mappingDictionary = ["feed_comment_id": "id",
            "comment": "comment",
            "feed_image": "image",
            "created_date": "stringDate",
            "user_id": "userId",
            "user_name": "userName",
            "profile_photo": "userImage",
            "feed_image_width": "imageWidth",
            "feed_image_height": "imageHeight"
        ]
        
        let mapping = RKObjectMapping(for: self)
        mapping?.addAttributeMappings(from: mappingDictionary)
        return mapping!
    }
    
    var expectedHeight: CGFloat {
        let textHeight = (userName + " " + comment).expectedHeight(kMainScreenWidth - 81.0, font: UIFont.helvetica(13))
        let imageViewHeight = image.isEmpty ? 2.0 : (imageHeight/Double(UIScreen.main.scale) + 10.0)
        let padding = 8.0 + 8.0 + 8.0 + 14.0 + 19.0
        return CGFloat(textHeight + imageViewHeight + padding)
    }
}
