//
//  ViewLogViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 24/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l <= r
  default:
    return !(rhs < lhs)
  }
}


// MARK:
// MARK: MealTypeInfoView

protocol MealTypeInfoViewDelegate {
    func mealTypeInfo(_ closePopUp: Bool)
}
class MealTypeInfoView: UIView, UIGestureRecognizerDelegate {
    
    var mealTypeInfoViewDelegate: MealTypeInfoViewDelegate?
    
    // title
    @IBOutlet weak var labelMealType: UILabel!
    
    @IBOutlet weak var imageViewClose: UIImageView!
    // macro labels
    @IBOutlet weak var labelProtein: UILabel!
    @IBOutlet weak var labelCarbs: UILabel!
    @IBOutlet weak var labelFiber: UILabel!
    @IBOutlet weak var labelFats: UILabel!
    @IBOutlet weak var labelCalories: UILabel!
    
    var mealType = MealType(name: "") {
        didSet {
            configureView()
        }
    }
    
    var macroStats = MacroModel() {
        didSet {
            configureViewWithMacroStats()
        }
    }
    
    var dailyMealPlanMealType = MealType(name: "") {
        didSet {
            configureDailyMealPlanView()
        }
    }
    
    
    func configureView() {
        
        let allFoods = mealType.foods as [Food]
        
        let foods = allFoods.filter{return $0.approve != "No"}
        
        //protein calculation
        let proteinArray: [Double] = foods.map { return $0.protein }
        var proteinTotal: Double   = proteinArray.reduce(0) { return $0 + $1 }
        
        //fibre calculation
        let fibreArray: [Double] = foods.map { return $0.fiber }
        var fibreTotal: Double   = fibreArray.reduce(0) { return $0 + $1 }
        
        //fat calculation
        let fatArray: [Double] = foods.map { return $0.fat }
        var fatTotal: Double   = fatArray.reduce(0) { return $0 + $1 }
        
        //carbohydrate calculation
        let carbArray: [Double] = foods.map { return $0.carbohydrates }
        var carbTotal: Double   = carbArray.reduce(0) { return $0 + $1 }
        
        //calorie calculation
        let calorieArray: [Double] = foods.map { return $0.calories }
        var calorieTotal: Double   = calorieArray.reduce(0) { return $0 + $1 }
        
        labelMealType.text = mealType.name + " " + &&"breakdown"
        
        labelProtein.text = "\(proteinTotal.roundPlaces())g " + &&"protein"
        labelFats.text = "\(fatTotal.roundPlaces())g " + &&"fats"
        labelCarbs.text = "\(carbTotal.roundPlaces())g " + &&"carbs"
        labelFiber.text = "\(fibreTotal.roundPlaces())g " + &&"fiber"
        labelCalories.text = "\(calorieTotal.roundPlaces()) " + &&"calories"
        
        self.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(MealTypeInfoView.handleTap)))
    }
    
    func configureViewWithMacroStats() {
        
        labelMealType.text = &&"macro_breakdown"
        
        labelProtein.text = "\(macroStats.macrosLeft().proteinsLeft)g " + &&"protein"
        labelFats.text = "\(macroStats.macrosLeft().fatsLeft)g " + &&"fats"
        labelCarbs.text = "\(macroStats.macrosLeft().carbsLeft)g " + &&"carbs"
        labelFiber.text = "\(macroStats.macrosLeft().fiberLeft)g " + &&"fiber"
        labelCalories.text = "\(macroStats.macrosLeft().caloriesLeft) " + &&"calories"
        
        self.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(MealTypeInfoView.handleTap)))
    }
    
    func configureDailyMealPlanView() {
        
        let allFoods = dailyMealPlanMealType.foods as [Food]
        
        let foods = allFoods.filter{return $0.approve != "No"}
        
        //protein calculation
        let proteinArray: [Double] = foods.map { return $0.protein * (($0.servingSizeFixed == "1") ? 1 : $0.servingSize) }
        var proteinTotal: Double   = proteinArray.reduce(0) { return $0 + $1 }
        
        //fibre calculation
        let fibreArray: [Double] = foods.map { return $0.fiber * (($0.servingSizeFixed == "1") ? 1 : $0.servingSize) }
        var fibreTotal: Double   = fibreArray.reduce(0) { return $0 + $1 }
        
        //fat calculation
        let fatArray: [Double] = foods.map { return $0.fat * (($0.servingSizeFixed == "1") ? 1 : $0.servingSize) }
        var fatTotal: Double   = fatArray.reduce(0) { return $0 + $1 }
        
        //carbohydrate calculation
        let carbArray: [Double] = foods.map { return $0.carbohydrates * (($0.servingSizeFixed == "1") ? 1 : $0.servingSize)}
        var carbTotal: Double   = carbArray.reduce(0) { return $0 + $1 }
        
        //calorie calculation
        let calorieArray: [Double] = foods.map { return $0.calories * (($0.servingSizeFixed == "1") ? 1 : $0.servingSize)}
        var calorieTotal: Double   = calorieArray.reduce(0) { return $0 + $1 }
        
        labelMealType.text = mealType.name + " " + &&"breakdown"
        
        labelProtein.text = "\(proteinTotal.roundPlaces())g " + &&"protein"
        labelFats.text = "\(fatTotal.roundPlaces())g " + &&"fats"
        labelCarbs.text = "\(carbTotal.roundPlaces())g " + &&"carbs"
        labelFiber.text = "\(fibreTotal.roundPlaces())g " + &&"fiber"
        labelCalories.text = "\(calorieTotal.roundPlaces()) " + &&"calories"
        
        self.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(MealTypeInfoView.handleTap)))
    }
    
    
    // close the pop
    func handleTap() {
        KLCPopup.dismissAllPopups()
    }
}

// MARK:
// MARK: LogHeaderView

protocol LogHeaderViewDelegate {
    func logHeader(_ logHeaderView: LogHeaderView, infoButtonClickedForMealType mealType: MealType)
}

class LogHeaderView: UITableViewHeaderFooterView {
    
    var logHeaderViewDelegate: LogHeaderViewDelegate?
    
    var mealType: MealType = MealType(name: "") {
        didSet {
            
            // set heading
            textLabel!.text = mealType.name
        }
    }
    
    //    convenience init(frame: CGRect) {
    //        self.init(frame: frame)
    //        
    //        configureView()
    //    }
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        
        configureView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        configureView()
    }
    
    func configureView() {
        
        let buttonInfo = UIButton(type: UIButtonType.infoLight)
        buttonInfo.tintColor = UIColor(red: 0, green: 122/255.0, blue: 252.0/255.0, alpha: 1.0)
        buttonInfo.addTarget(self, action: #selector(LogHeaderView.buttonActionInfo(_:)), for: .touchUpInside)
        contentView.addSubview(buttonInfo)
        
        // right margin for button info
        buttonInfo.setRightMargin()
        
        textLabel!.setLeftMargin()
        
        // centerify button info
        buttonInfo.centerVerticallyInSuperview()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // set label text color
        textLabel!.textColor = UIColor.white
        
        // set label font
        textLabel!.font = UIFont.helveticaBold()
        
        // set background color
        self.contentView.backgroundColor = UIColor(red: 44.0/255.0, green: 44.0/255.0, blue: 44.0/255.0, alpha: 1.0)//UIColor.lightBlackColor()
    }
    
    func buttonActionInfo(_ sender: UIButton) {
        logHeaderViewDelegate?.logHeader(self, infoButtonClickedForMealType: mealType)
    }
}

// MARK:
// MARK: LogFooterView

protocol LogFooterViewDelegate {
    func logFooter(_ logFooterView: LogFooterView, addButtonClickedForMealTypeData mealType: MealType)
}

class LogFooterView: UITableViewHeaderFooterView {
    
    var mealType: MealType = MealType(name: "")
    
    var logFooterViewDelegate: LogFooterViewDelegate?
    //    
    //    convenience init(frame: CGRect) {
    //        self.init(frame: frame)
    //        
    //        configureView()
    //    }
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        
        configureView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        configureView()
    }
    
    func configureView() {
        
        // configure label
        textLabel!.text = &&"+add_food"
        textLabel!.font = UIFont.helveticaBold()
        textLabel!.setLeftMargin()
        // add tap gesture
        textLabel!.isUserInteractionEnabled = true
        textLabel!.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(LogFooterView.tapped(_:))))
    }
    
    func tapped(_ gesture: UITapGestureRecognizer) {
        logFooterViewDelegate?.logFooter(self, addButtonClickedForMealTypeData: mealType)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // set label text color
        textLabel!.textColor = UIColor.defaultThemeBlueColor()
        
        // set background color
        contentView.backgroundColor = UIColor.defaultGrayColor()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        configureView()
    }
}

// MARK:
// MARK: LogExerciseHeaderView

protocol LogExerciseHeaderViewDelegate {
    func logExerciseHeader(_ logExerciseHeaderView: LogExerciseHeaderView, editDateForExercise exercise: Exercise);
}

class LogExerciseHeaderView: UITableViewHeaderFooterView {
    
    var logExerciseHeaderViewDelegate: LogExerciseHeaderViewDelegate?
    
    var exercise: Exercise = Exercise(name: "") {
        didSet {
            
            configureView()
        }
    }
    
    let imageViewExerciseType = UIImageView()
    let textFieldExerciseName = UILabel()
    let textFieldDate = UITextField()
    let datePicker = UIDatePicker()
    let toolbar: UIToolbar = {
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 320, height: 44))
        toolbar.barStyle = .black
        return toolbar
        }()
    
    //    convenience init(frame: CGRect) {
    //        self.init(frame: frame)
    //        
    //        //        configureView()
    //    }
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        
        //        configureView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        //        configureView()
    }
    
    func configureView() {
        
        imageViewExerciseType.image = UIImage(named: "SharedExerciseIcon")
        imageViewExerciseType.contentMode = UIViewContentMode.center
        imageViewExerciseType.clipsToBounds = true
        contentView.addSubview(imageViewExerciseType)
        
        let buttonEdit = UIButton(type: .custom)
        buttonEdit.setBackgroundImage(UIImage(named: "EditButton"), for: UIControlState())
        buttonEdit.addTarget(self, action: #selector(LogExerciseHeaderView.buttonActionEdit(_:)), for: .touchUpInside)
        contentView.addSubview(buttonEdit)
        
        imageViewExerciseType.translatesAutoresizingMaskIntoConstraints = false
        buttonEdit.translatesAutoresizingMaskIntoConstraints = false
        
        // remove existing constraints if any
        imageViewExerciseType.removeConstraints(imageViewExerciseType.constraints)
        
        // right margin for button info
        buttonEdit.setRightMargin()
        
        // centerify button info
        buttonEdit.centerVerticallyInSuperview()
        
        // configure exercise name textfield
        // configure date textfield
        textFieldDate.textColor = UIColor.white
        textFieldDate.font = UIFont.systemFont(ofSize: 14)
        contentView.addSubview(textFieldDate)
        
        // configure date textfield
        textFieldExerciseName.textColor = UIColor.white
        textFieldExerciseName.font = UIFont.systemFont(ofSize: 14)
        contentView.addSubview(textFieldExerciseName)
        
        // date picker
        datePicker.datePickerMode = .date
        
        // toolbar
        let barButtonChangeDate = UIBarButtonItem(title: &&"change_date", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        barButtonChangeDate.tintColor = UIColor.white
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let barButtonDone = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(LogExerciseHeaderView.barButtonActionDone(_:)))
        
        toolbar.items = [barButtonChangeDate, flexibleSpace, barButtonDone]
        
        // centerify label
        textFieldDate.centerVerticallyInSuperview()
        
        //add constraint to imageview
        let imageViewHeightConstraints = NSLayoutConstraint.constraints(withVisualFormat: "V:[imageViewExerciseType(height)]", options: NSLayoutFormatOptions(), metrics: ["height": 20], views: ["imageViewExerciseType": imageViewExerciseType])
        
        imageViewExerciseType.addConstraints(imageViewHeightConstraints)
        
        let imageViewWidthConstraints = NSLayoutConstraint.constraints(withVisualFormat: "H:[imageViewExerciseType(width@250)]", options: NSLayoutFormatOptions(), metrics: ["width": 0], views: ["imageViewExerciseType": imageViewExerciseType])
        
        imageViewExerciseType.addConstraints(imageViewWidthConstraints)
        
        let metrics = ["leftMargin": 15, "imageWidth": exercise.exerciseMethod == "Send" ? 20 : 0, "rightMargin": exercise.exerciseMethod == "Send" ? 8 : 0]
        
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-leftMargin-[imageViewExerciseType(imageWidth@1000)]-rightMargin-[textFieldExerciseName]", options: NSLayoutFormatOptions(), metrics: metrics, views: ["imageViewExerciseType": imageViewExerciseType, "textFieldExerciseName": textFieldExerciseName]))
        
        imageViewExerciseType.centerVerticallyInSuperview()
        
        // set margin for label
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[textFieldDate]-8-[buttonEdit]", options: NSLayoutFormatOptions(), metrics: nil, views: ["textFieldDate": textFieldDate, "buttonEdit": buttonEdit]))
        
        let exerciseDateFont = UIFont.helvetica(12)
        textFieldDate.font = exerciseDateFont
        textFieldDate.text = exercise.date.stringValue("MMMM dd, yyyy")
        
        imageViewExerciseType.sizeToFit()
        imageViewExerciseType.layoutIfNeeded()
        
        // allows 2 lines now
        textFieldDate.sizeToFit()
        textFieldDate.layoutIfNeeded()
        
        //set width constraint to textlabel
        let width = UIScreen.main.bounds.width ?? 375.0//CGRectGetWidth(superview!.bounds)
        let widthConstraints = NSLayoutConstraint.constraints(withVisualFormat: "H:[textFieldExerciseName(width)]", options: NSLayoutFormatOptions(), metrics: ["width": width-(textFieldDate.frame.width+65+imageViewExerciseType.frame.width)], views: ["textFieldExerciseName": textFieldExerciseName])
        textFieldExerciseName.centerVerticallyInSuperview()
        textFieldExerciseName.addConstraints(widthConstraints)
        
        //print("send ----\(exercise.exerciseMethod)")
        
        let exerciseNameFont = UIFont.helveticaBold()
        textFieldExerciseName.font = exerciseNameFont
        
        // set heading
        textFieldExerciseName.text = exercise.name
        datePicker.date = exercise.date as Date
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // set label text color
        textLabel!.textColor = UIColor.white
        
        //textFieldDate.enabled = false
        textFieldDate.inputAccessoryView = toolbar
        textFieldDate.inputView = datePicker
        
        // set background color
        contentView.backgroundColor = UIColor(red: 44.0/255.0, green: 44.0/255.0, blue: 44.0/255.0, alpha: 1.0)//UIColor.lightBlackColor()
        
        
        
        // add tap gesture
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(LogExerciseHeaderView.buttonActionEdit(_:)))
        tapGesture.numberOfTapsRequired = 1
        self.addGestureRecognizer(tapGesture)
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
    }
    
    func buttonActionEdit(_ sender: UIButton) {
        textFieldDate.becomeFirstResponder()
    }
    
    func barButtonActionDone(_ sender: UIBarButtonItem) {
        exercise.date = datePicker.date
        textFieldDate.text = datePicker.date.stringValue("MMMM dd, yyyy")
        textFieldDate.resignFirstResponder()
        logExerciseHeaderViewDelegate?.logExerciseHeader(self, editDateForExercise: exercise)
    }
}

// MARK:
// MARK: LogExerciseFooterView

protocol LogExerciseFooterViewDelegate {
    func buttonActionAddExercise(_ logExerciseFooterView: LogExerciseFooterView)
}

class LogExerciseFooterView: UITableViewHeaderFooterView {
    
    var logExerciseFooterViewDelegate: LogExerciseFooterViewDelegate?
    
    //    convenience init(frame: CGRect) {
    //        self.init(frame: frame)
    //        
    //        configureView()
    //    }
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        
        configureView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        configureView()
    }
    
    func configureView() {
        
        // configure label
        textLabel!.text = &&"+add_exercise"
        textLabel!.font = UIFont.helveticaBold()
        textLabel!.setLeftMargin()
        
        // add tap gesture
        textLabel!.isUserInteractionEnabled = true
        textLabel!.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(LogFooterView.tapped(_:))))
    }
    
    func tapped(_ gesture: UITapGestureRecognizer) {
        logExerciseFooterViewDelegate?.buttonActionAddExercise(self)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // set label text color
        textLabel!.textColor = UIColor.defaultThemeBlueColor()
        
        // set background color
        contentView.backgroundColor = UIColor.defaultGrayColor()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        configureView()
    }
}

// MARK:
// MARK: LogFoodCell

protocol LogFoodCellDelegate {
    func logFoodCell(_ logFoodCell: LogFoodCell, didCopyFood food: Food)
    func logFoodCell(_ logFoodCell: LogFoodCell, didDeleteFood food: Food)
    func logFoodCell(_ logFoodCell: LogFoodCell, didAcceptFood food: Food)
    func logFoodCell(_ logFoodCell: LogFoodCell, didDenyFood food: Food)
}

class LogFoodCell: MGSwipeTableCell, MGSwipeTableCellDelegate {
    
    var food: Food = Food(name: "") {
        didSet {
            configureView()
        }
    }
    
    var logFoodCellDelegate: LogFoodCellDelegate?
    
    @IBOutlet weak var buttonDeny: UIButton!
    @IBOutlet weak var buttonAccept: UIButton!
    @IBOutlet weak var imageViewshareImage: UIImageView!
    @IBOutlet weak var imageViewDrag: UIImageView!
    
    @IBOutlet weak var labelNameWidthConstant: NSLayoutConstraint!
    @IBOutlet weak var foodNameSuperViewWidth: NSLayoutConstraint!
    @IBOutlet weak var labelFoodCalorie: UILabel!
    @IBOutlet weak var labelFoodName: UILabel!
    @IBOutlet weak var acceptButtonWidth: NSLayoutConstraint!
    @IBOutlet weak var shareImageviewWidth: NSLayoutConstraint!
    @IBOutlet weak var buttonSuperViewWidth: NSLayoutConstraint!
    @IBOutlet weak var labelDate: UILabel!
    @IBOutlet weak var viewFirst: UIView!
    
    func configureView() {
        
        // set food
        var foodName = food.name as NSString
        
        foodName =   foodName.replacingOccurrences(of: "\\\"", with: "") as NSString
        
        foodName = foodName.replacingOccurrences(of: "\\\"", with: "") as NSString
        
        labelFoodName?.text = "\(food.numberOfServings.roundedString())x \(foodName)"
        labelFoodCalorie.text = food.calories.roundedString() + " " + &&"calories"
        
        // set share imageview
        if food.approve == "No" {
            labelDate.text = food.logDate.dateValue("yyyy-MM-dd")!.stringValue("MM/dd/yy")
            buttonSuperViewWidth.constant = 150//CGRectGetMaxX(self.contentView.bounds) - 325
            buttonDeny.isHidden = false
            buttonAccept.isHidden = false
            
        } else {
            buttonSuperViewWidth.constant = 20//CGRectGetMaxX(self.contentView.bounds) - 45
            
            buttonDeny.isHidden = true
            buttonAccept.isHidden = true
            labelDate.text = ""
        }
        
        if food.method == LogType.Send.rawValue {
            imageViewshareImage.image = UIImage(named: "SendFoodDetailsIcon")
            shareImageviewWidth.constant = 20
            imageViewshareImage.isHidden = false
            
        } else if food.method == LogType.Split.rawValue {
            imageViewshareImage.image = UIImage(named: "SplitFoodIcon")
            shareImageviewWidth.constant = 20
            imageViewshareImage.isHidden = false
            
        } else {
            shareImageviewWidth.constant = 0
            imageViewshareImage.isHidden = true
        }
        // set swipable cell delegate
        delegate = self
        
        // configure the right utility buttons
        let buttonCopy = MGSwipeButton(title: &&"copy", backgroundColor: UIColor.defaultGrayColor()) { (cell) -> Bool in
            return true
        }
        buttonCopy.setTitleColor(UIColor.defaultThemeBlueColor(), for: UIControlState())
        buttonCopy.titleLabel?.font = UIFont.helveticaBold(15)
        
        let buttonDelete = MGSwipeButton(title: &&"delete", backgroundColor: UIColor.defaultGrayColor()) { (cell) -> Bool in
            return true
        }
        buttonDelete.setTitleColor(UIColor.red, for: UIControlState())
        buttonDelete.titleLabel?.font = UIFont.helveticaBold(15)
        
        rightButtons = [buttonDelete, buttonCopy]
        rightSwipeSettings.transition = MGSwipeTransition.border
        
        contentView.setNeedsUpdateConstraints()
        contentView.updateConstraintsIfNeeded()
        
        contentView.layoutIfNeeded()
        
    }
    
    struct RightUtilityButtons {
        static let Delete = 0
        static let Copy = 1
    }
    
    func swipeTableCell(_ cell: MGSwipeTableCell!, canSwipe direction: MGSwipeDirection) -> Bool {
        return true
    }
    
    func swipeTableCell(_ cell: MGSwipeTableCell!, tappedButtonAt index: Int, direction: MGSwipeDirection, fromExpansion: Bool) -> Bool {
        
        // hide buttons
        cell.hideSwipe(animated: true)
        
        if index == RightUtilityButtons.Copy {
            logFoodCellDelegate?.logFoodCell(self, didCopyFood: food)
        }
        else if index == RightUtilityButtons.Delete {
            logFoodCellDelegate?.logFoodCell(self, didDeleteFood: food)
        }
        
        return true
    }
    
    @IBAction func buttonActionDeny(_ sender: UIButton) {
        
        logFoodCellDelegate?.logFoodCell(self, didDenyFood: food)
    }
    @IBAction func buttonActionAccept(_ sender: UIButton) {
        
        logFoodCellDelegate?.logFoodCell(self, didAcceptFood: food)
    }
}

// MARK:
// MARK: LogExerciseCell

protocol LogExerciseCellDelegate {
    func logExerciseCell(_ logExerciseCell: LogExerciseCell, didDeleteExercise exercise: Exercise)
    func logExerciseCell(_ logExerciseCell: LogExerciseCell, shouldSendExerciseDetails exercise: Exercise)
}

class LogExerciseCell: SWTableViewCell, SWTableViewCellDelegate {
    
    var exercise = Exercise(name: "") {
        didSet {
            configureView()
        }
    }
    
    var logExerciseCellDelegate: LogExerciseCellDelegate?
    
    @IBOutlet weak var labelExerciseAmount: UILabel!
    @IBOutlet weak var labelCaloriesBurned: UILabel!
    @IBOutlet weak var labelNumberOfSets: UILabel!
    @IBOutlet weak var labelRepsPerSet: UILabel!
    @IBOutlet weak var labelWeightPerSet: UILabel!
    @IBOutlet weak var labelDistance: UILabel!
    
    @IBOutlet weak var viewSendExerciseDetails: UIView!
    
    @IBOutlet weak var constraintCardioStatsHeight: NSLayoutConstraint!
    
    @IBOutlet weak var constraintStrengthStatsHeight: NSLayoutConstraint!
    
    @IBOutlet weak var constraintDistanceStatsHeight: NSLayoutConstraint!
    
    func configureView() {
        
        // reset height constraints
        resetConstraints()
        updateLabels()
        
        // send exercise details
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(LogExerciseCell.gestureActionTap(_:)))
        viewSendExerciseDetails.addGestureRecognizer(tapGesture)
        
        // set swipable cell delegate
        delegate = self
        
        // set right utility buttons
        rightUtilityButtons = configureRightUtilityButtons() as! [Any]
    }
    
    func resetConstraints() {
        // reset height constraints
        constraintCardioStatsHeight.constant = 60
        constraintStrengthStatsHeight.constant = 0
        constraintDistanceStatsHeight.constant = 0
    }
    
    func updateLabels() {
        // set appropriate height constraints
        if exercise.exerciseType == .Strength {
            constraintStrengthStatsHeight.constant = 90
            constraintDistanceStatsHeight.constant = 0
            
            //convert the current exercise to strengthexercise
            let currentExercise = exercise as! StrengthExercise
            labelNumberOfSets.text = currentExercise.sets.stringValue
            labelRepsPerSet.text = currentExercise.reps.stringValue
            labelWeightPerSet.text = currentExercise.weight.stringValue
            labelExerciseAmount.text = exerciseTime(currentExercise.exerciseAmount) //(currentExercise.exerciseAmount/60.0).stringValue + " " + &&"minutes"
            labelCaloriesBurned.text = currentExercise.caloriesBurned.stringValue
        }
        else if exercise.exerciseType == .CardioVascular {
            constraintStrengthStatsHeight.constant = 0
            constraintDistanceStatsHeight.constant = 30
            
            //convert the current exercise to cardiovascular exercise
            let currentExercise = exercise as! CardioVascularExercise
            labelExerciseAmount.text = exerciseTime(currentExercise.exerciseAmount)//(currentExercise.exerciseAmount/60.0).stringValue + " " + &&"minutes"
            labelCaloriesBurned.text = currentExercise.caloriesBurned.stringValue
            labelDistance.text = currentExercise.distance.stringValue
        }
        else {
            //print("exercise without a valid type found")
        }
        
    }
    
    func exerciseTime(_ seconds: Double) -> String {
        
        let seconds1 = seconds.truncatingRemainder(dividingBy: 60);
        let totalMinutes = seconds / 60;
        let minutes = totalMinutes.truncatingRemainder(dividingBy: 60);
        let hours = totalMinutes / 60;
        let dateString = NSString(format: "%02d:%02d:%02d", Int(hours), Int(minutes), Int(seconds1)) //formatter.stringFromDate(date)
        return dateString as String
    }
    
    func configureRightUtilityButtons() -> NSArray {
        let rightUtilityButtons = NSMutableArray()
        rightUtilityButtons.addUtilityButtonWithBackgroundColor(UIColor.defaultGrayColor(),
            andTitleColor: UIColor.red, andTitle: &&"delete")
        return rightUtilityButtons
    }
    
    func gestureActionTap(_ sender: UITapGestureRecognizer) {
        logExerciseCellDelegate?.logExerciseCell(self, shouldSendExerciseDetails: exercise)
    }
    
    func swipeableTableViewCell(_ cell: SWTableViewCell!, didTriggerRightUtilityButtonWith index: Int) {
        logExerciseCellDelegate?.logExerciseCell(self, didDeleteExercise: exercise)
    }
    
    func swipeableTableViewCellShouldHideUtilityButtons(onSwipe cell: SWTableViewCell!) -> Bool {
        return true
    }
}

// MARK:
// MARK: ViewLogViewController

class ViewLogViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, LogHeaderViewDelegate, LogFooterViewDelegate, LogExerciseFooterViewDelegate, UIAlertViewDelegate, LogFoodCellDelegate, LogExerciseCellDelegate, UITableViewDragLoadDelegate, MealTypeInfoViewDelegate, LogExerciseHeaderViewDelegate, MacroStatsViewDelegate, DragAndDropTableViewDataSource, DragAndDropTableViewDelegate, UITextFieldDelegate {
    
    @IBOutlet fileprivate weak var buttonFoodLog: UIButton!
    @IBOutlet fileprivate weak var buttonExerciseLog: UIButton!
    @IBOutlet fileprivate weak var labelLogDate: UILabel!
    @IBOutlet fileprivate var tableView: DragAndDropTableView!
    @IBOutlet var macroStatsView: MacroStatsView!
    @IBOutlet var mealTypeInfoView: MealTypeInfoView!
    @IBOutlet weak var tableFooterCreateMealType: UIView!
    @IBOutlet var exerciseFooter: LogExerciseFooterView!
    
    @IBOutlet weak var buttonNext: UIButton!
    var currentSelectedButton = UIButton()
    var isFirstTime = true
    var activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
    @IBOutlet weak var dateSuperView: UIView!
    @IBOutlet var tableSampleFooter: UIView!
    var offscreenCells = [String: LogFoodCell]()
    
    var alertTextFieldcreateMealType = UITextField()
    
    var draggedFood: Food?
    
    var isFoodLogMode: Bool = true {
        didSet {
            
            if tableData.count != 0 {
                tableData.removeAll()
                reloadData()
            }
            
            configureButtons()
            
            // reload data
            
        }
    }
    
    fileprivate  func configureButtons() {
        
        tableView?.tableHeaderView = isFoodLogMode ? macroStatsView : exerciseTableHeaderView
        tableView?.tableFooterView = tableFooter
        
        let selectedFont = UIFont.helveticaBold(16)
        
        let deSelectFont = UIFont.helvetica(16)
        
        let selectedFontColor = UIColor(red: 95.0/255.0, green: 95.0/255.0, blue: 95.0/255.0, alpha: 1.0)
        
        let deSelectFontColor = UIColor(red: 175.0/255.0, green: 175.0/255.0, blue: 175.0/255.0, alpha: 1.0)
        
        let selectedButtonBgColor = UIColor(red: 224.0/255.0, green: 224.0/255.0, blue: 224.0/255.0, alpha: 1.0)
        
        // update buttons
        buttonFoodLog?.backgroundColor = isFoodLogMode ? UIColor.white : selectedButtonBgColor
        buttonExerciseLog?.backgroundColor  = isFoodLogMode ? selectedButtonBgColor : UIColor.white
        buttonFoodLog?.layer.borderWidth = 1.0
        buttonExerciseLog?.layer.borderWidth = 1.0
        
        buttonFoodLog?.layer.borderColor = isFoodLogMode ? UIColor.white.cgColor : deSelectFontColor.cgColor
        buttonExerciseLog?.layer.borderColor = isFoodLogMode ? deSelectFontColor.cgColor : UIColor.white.cgColor
        
        buttonFoodLog?.setTitleColor(isFoodLogMode ? selectedFontColor : deSelectFontColor, for: UIControlState())
        buttonExerciseLog?.setTitleColor(isFoodLogMode ? deSelectFontColor : selectedFontColor, for: UIControlState())
        
        buttonFoodLog?.titleLabel?.font = isFoodLogMode ? selectedFont : deSelectFont
        buttonExerciseLog?.titleLabel?.font = isFoodLogMode ? deSelectFont : selectedFont
        
    }
    
    var logDate = Date() {
        
        didSet {
            
            foodLogs.removeAll()
            mealData.removeAll()
            exerciseData.removeAll()
            tableData.removeAll()
            reloadData()
            //            tableView.reloadData()
            labelLogDate.text = logDate.stringValue("MMMM dd, yyyy", dateStyle: nil, showToday: true)
            // reload data
            
            // load the macro data for the date
            configureMacroStatusView()
        }
    }
    
    var tableFooter: UIView? {
        
        func tableFooterCreateExercise() -> LogExerciseFooterView {
            exerciseFooter = LogExerciseFooterView(reuseIdentifier: "logfooter");//LogExerciseFooterView(frame: CGRectMake(0, 0, UIScreen.mainScreen().bounds.width, 32.0))
            exerciseFooter.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 32.0)
            exerciseFooter.logExerciseFooterViewDelegate = self
            return exerciseFooter
        }
        
        tableView.layoutSubviews()
        tableSampleFooter = isFoodLogMode ? tableFooterCreateMealType : tableFooterCreateExercise()
        //        tableView.layoutIfNeeded()
        tableSampleFooter!.frame = CGRect(x: 0, y: tableView.contentSize.height-32, width: tableSampleFooter!.frame.size.width, height: tableSampleFooter!.frame.size.height)
        return tableSampleFooter// isFoodLogMode ? tableFooterCreateMealType : tableFooterCreateExercise()
    }
    
    var userMealTypes = [MealType]()
    var foodLogs = [Food]()
    var mealData = [MealType]()
    var exerciseData = [Exercise]()
    var tableData = [Any]()
    var macroDetails = MacroModel()
    var showHUD = true
    var resetOffSet:Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set log date
        logDate = Date()
        
        //configure activity indicator view
        activityIndicator.hidesWhenStopped = true
        dateSuperView.addSubview(activityIndicator)
        activityIndicator.isHidden = true
        
        // configure view
        configureView()
        
        configureButtons()
        
        configureTableView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.tableHeaderView = isFoodLogMode ? macroStatsView : exerciseTableHeaderView
        // set table footer
        self.tableView.tableFooterView = tableFooter
        
        //        foodLogs.removeAll()
        //        mealData.removeAll()
        //        exerciseData.removeAll()
        tableData.removeAll()
        reloadData()
        fetchData()
        
        configureMacroStatusView()
    }
    
    var exerciseTableHeaderView: UIView {
        
        var frame = self.tableView.tableHeaderView!.frame;
        frame.size.height = 0.5;
        let headerView = UIView(frame: frame)
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.tableView.translatesAutoresizingMaskIntoConstraints = false
        
        //        let frame = tableFooter!.frame
        //        tableFooter!.frame = CGRectMake(frame.origin.x, tableView.contentSize.height, frame.size.width, frame.size.height)
        self.tableView.tableFooterView = tableFooter
        
        //print(" footer height \(tableFooter?.frame)")
        //print(" footer height \(tableFooter?.frame.size.height)")
        
    }
    
    
    func configureMacroStatusView() {
        
        
        // setup macro stats view delegate
        macroStatsView.macroStatsViewDelegate = self
        
        MacroModel.refreshUserMacros(logDate, completionHnadler: { (achievedMacroGoal) -> () in
            
            self.macroStatsView.macroDetails = achievedMacroGoal
            self.macroDetails = achievedMacroGoal
        })
    }
    
    
    func infoButtonClicked(_ macroStatsView: MacroStatsView) {
        
    }
    
    struct Storyboard {
        struct CellIdentifiers {
            static let LogHeader            = "kLogHeader"
            static let LogExerciseHeader    = "kLogExerciseHeader"
            static let LogFooter            = "kLogFooter"
            static let LogExerciseFooter    = "kLogExerciseFooter"
            static let LogFoodCell          = "kLogFoodCell"
            static let LogExerciseCell      = "kLogExerciseCell"
        }
        
        struct Segues {
            static let AddFood              = "kAddFoodSegue"
            static let CopyMeal             = "kCopyMealSegue"
            static let FoodDetail           = "kFoodDetailSegue"
            static let SendExerciseDetails  = "kSendExercsieDetailsSegue"
            static let ShareFoodLog         = "kShareFoodLogSegue"
            static let ShareExerciseLog     = "kShareExerciseLogSegue"
            static let AddExercise          = "kAddExercise"
            static let MacroChartView       = "kMacroLogSegue"
        }
    }
    
    func configureView() {
        
        tableView.estimatedRowHeight = UITableViewAutomaticDimension
        
        // register header and footer for tableview
        tableView.register(LogHeaderView.self, forHeaderFooterViewReuseIdentifier: Storyboard.CellIdentifiers.LogHeader)
        tableView.register(LogExerciseHeaderView.self, forHeaderFooterViewReuseIdentifier: Storyboard.CellIdentifiers.LogExerciseHeader)
        tableView.register(LogFooterView.self, forHeaderFooterViewReuseIdentifier: Storyboard.CellIdentifiers.LogFooter)
        tableView.register(LogExerciseFooterView.self, forHeaderFooterViewReuseIdentifier: Storyboard.CellIdentifiers.LogExerciseFooter)
        
        // set estimated view height
        tableView.estimatedRowHeight = 44.0
    }
    
    func configureTableView() {
        
        tableView.estimatedRowHeight = UITableViewAutomaticDimension
        
        // set delegate for pull to refresh and load more
        tableView.setDragDelegate(self, refreshDatePermanentKey: "kLogs")
        
        // hide pull to refresh
        tableView.showRefreshView = false
        
        // show load more
        tableView.showLoadMoreView = true
        
        // tableview footer release text
        tableView.footerReleaseText = NSLocalizedString("release_to_load_more_status", comment: "")
        
        // tableview footer pull up text
        tableView.footerPullUpText = NSLocalizedString("pull_down_to_load_more_status", comment: "")
        
        //tableview footer loading text
        tableView.footerLoadingText = NSLocalizedString("loading_status", comment: "")
    }
    
    func reloadData() {
        
        tableView.estimatedRowHeight = UITableViewAutomaticDimension
        
        configureTableData()
        tableView.reloadData()
        
        self.tableView.tableFooterView = nil
        self.tableView.tableFooterView = tableFooter//self.tableView.tableFooterView
        tableView.bringSubview(toFront: tableFooter!)
        self.tableView.reloadInputViews()
        
        //print(" footer height after loading is \(tableFooter!.frame)")
    }
    
    func dragTableDidTriggerLoadMore(_ tableView: UITableView!) {
        // called when the load more is selected
        showHUD = false
        fetchData(false)
    }
    
    func fetchData(_ shouldReloadData: Bool = true) {
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        // fetch data
        if isFoodLogMode {
            fetchFood(shouldReloadData)
        }
        else {
            fetchExercise(shouldReloadData)
        }
    }
    
    var offSet: String {
        
        if isFoodLogMode {
            return self.foodLogs.isEmpty || resetOffSet ? "0" : String(self.foodLogs.count)
        }
        return self.exerciseData.isEmpty || resetOffSet ? "0" : String(self.exerciseData.count)
    }
    
    func fetchMealTypes(_ completionHandler:@escaping (_ fetchedSuccessfully: Bool) -> ()) {
        
        //get all mealtypes for the user
        MealType.fetchMealTypeList { (mealTypes) -> () in
            self.userMealTypes = mealTypes
            completionHandler(true)
        }
    }
    
    func fetchFood(_ shouldReloadData: Bool = true) {
        
        if !isFirstTime {
            activityIndicator.frame = currentSelectedButton.frame
            currentSelectedButton.isHidden = true
            activityIndicator.isHidden = false
            activityIndicator.startAnimating()
        }
        
        resetOffSet = shouldReloadData
        
        if userMealTypes.isEmpty {
            
            fetchMealTypes({ (fetchedSuccessfully) -> () in
                if fetchedSuccessfully {
                    Food.fetchFoodLogs(self.offSet, date: self.logDate,  showHUD: self.showHUD,completionHandler: { (loggedFoods) -> () in
                        
                        if shouldReloadData {
                            self.foodLogs.removeAll()
                        }
                        if self.foodLogs.isEmpty {
                            
                            self.foodLogs = loggedFoods
                        } else {
                            self.foodLogs += loggedFoods
                        }
                        self.sortFoodLogArray(self.foodLogs)
                        
                    })
                }
            })
        } else {
            
            Food.fetchFoodLogs(self.offSet, date: self.logDate,showHUD: self.showHUD, completionHandler: { (loggedFoods) -> () in
                
                if shouldReloadData {
                    self.foodLogs.removeAll()
                }
                if self.foodLogs.isEmpty {
                    
                    self.foodLogs = loggedFoods
                } else {
                    self.foodLogs += loggedFoods
                }
                self.sortFoodLogArray(self.foodLogs)
                
            })
        }
        
    }
    
    func sortFoodLogArray(_ array: [Food]) {
        
        //sort the food log array to meal types
        mealData = userMealTypes.map() { mealType in
            let meal = MealType(name: mealType.name)
            meal.id = mealType.id
            meal.foods = array.filter() {
                
                $0.mealType.name == mealType.name && $0.approve != "Deny"
            }
            
            return meal
        }
        //print("meal data is \(mealData)")
        //unhide the button
        self.currentSelectedButton.isHidden = false
        //stop the activity indicator from animating
        self.activityIndicator.stopAnimating()
        
        self.tableView.finishLoadMore()
        //configureTableData()
        self.reloadData()
    }
    
    func fetchExercise(_ shouldReloadData: Bool = true) {
        
        if !isFirstTime {
            activityIndicator.frame = currentSelectedButton.frame
            currentSelectedButton.isHidden = true
            activityIndicator.isHidden = false
            activityIndicator.startAnimating()
        }
        
        resetOffSet = shouldReloadData
        
        
        Exercise.fetchExercisesLogs(offSet, showHUD: showHUD, date: logDate) { (exerciseList) -> () in
            
            if shouldReloadData {
                self.exerciseData.removeAll()
            }
            if self.exerciseData.count == 0 {
                
                self.exerciseData = exerciseList
            } else  {
                self.exerciseData  += exerciseList
            }
            
            //unhide the button
            self.currentSelectedButton.isHidden = false
            //stop the activity indicator from animating
            self.activityIndicator.stopAnimating()
            self.tableView.finishLoadMore()
            //self.configureTableData()
            
            self.reloadData()
        }
    }
    
    func configureTableData() {
        tableData = isFoodLogMode ? mealData : exerciseData
        //self.tableView.tableFooterView = tableFooter
        
        
    }
    
    func createMealType(_ name: String) {
        // create a new meal type object
        let newMealType = MealType(name: name)
        
        // post meal type to server
        newMealType.createMealType { (error) in
            if error == nil {
                self.userMealTypes = []
                self.fetchFood()
                self.tableView.reloadData()
            }
        }
    }
    
    // MARK:
    // MARK: UITableViewDelegate
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return tableData.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isFoodLogMode ? (tableData[section] as! MealType).foods.count : 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return isFoodLogMode ? foodCellHeight(indexPath) : (tableData[indexPath.section] as! HeightCalculating).expectedHeight
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return isFoodLogMode ? logTableView(tableView, logFoodCellForRowAtIndexPath: indexPath) : logTableView(tableView, logExerciseCellForRowAtIndexPath: indexPath)
    }
    
    func foodCellHeight(_ indexPath: IndexPath) -> CGFloat {
        
        let  cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.LogFoodCell) as? LogFoodCell
        
        let food = foodForIndexPath(indexPath)
        cell?.food = food
        
        cell?.contentView.setNeedsUpdateConstraints()
        cell?.contentView.updateConstraintsIfNeeded()
        
        cell?.contentView.bounds = CGRect(x: 0.0, y: 0.0, width: tableView.bounds.width, height: cell!.bounds.height)
        
        cell?.contentView.setNeedsLayout()
        cell?.contentView.layoutIfNeeded()
        cell?.labelFoodName.setNeedsLayout()
        cell?.labelFoodName.layoutIfNeeded()
        
        cell?.labelFoodName.setNeedsUpdateConstraints()
        
        cell?.labelFoodName.preferredMaxLayoutWidth = cell!.labelFoodName.bounds.width
        cell?.labelFoodName.layoutIfNeeded()
        
        //print("width----\(CGRectGetWidth(cell!.labelFoodName.bounds))")
        
        
        // Get the actual height required for the cell's contentView
        let height = cell?.contentView.systemLayoutSizeFitting(UILayoutFittingCompressedSize).height
        //        cell?.contentView.setTranslatesAutoresizingMaskIntoConstraints(true)
        // Add an extra point to the height to account for the cell separator, which is added between the bottom
        // of the cell's contentView and the bottom of the table view cell.
        
        //print("height for the cell----\(height))")
        
        return height! //+ height!/2
    }
    
    func logTableView(_ tableView: UITableView, logFoodCellForRowAtIndexPath indexPath: IndexPath) -> LogFoodCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.LogFoodCell) as! LogFoodCell
        
        cell.food = foodForIndexPath(indexPath)
        cell.logFoodCellDelegate = self
        cell.setNeedsUpdateConstraints()
        cell.updateConstraintsIfNeeded()
        
        return cell
    }
    
    func foodForIndexPath(_ indexPath: IndexPath) -> Food {
        
        // return an empty Food if its not food log mode
        if !isFoodLogMode { return Food() }
        
        // return the food from the mealtype
        return (tableData[indexPath.section] as! MealType).foods[indexPath.row]
    }
    
    func logTableView(_ tableView: UITableView, logExerciseCellForRowAtIndexPath indexPath: IndexPath) -> LogExerciseCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.LogExerciseCell) as! LogExerciseCell
        cell.exercise = tableData[indexPath.section] as! Exercise
        cell.logExerciseCellDelegate = self
        cell.selectionStyle = UITableViewCellSelectionStyle.none;
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 32.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return isFoodLogMode ? 32.0 : 1.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return isFoodLogMode ? logTableView(tableView, logFoodViewForHeaderInSection: section) : logTableView(tableView, logExerciseViewForHeaderInSection: section)
    }
    
    func logTableView(_ tableView: UITableView, logFoodViewForHeaderInSection section: Int) -> LogHeaderView? {
        let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: Storyboard.CellIdentifiers.LogHeader) as! LogHeaderView
        header.logHeaderViewDelegate = self
        header.mealType = tableData[section] as! MealType
        return header
    }
    
    func logTableView(_ tableView: UITableView, logExerciseViewForHeaderInSection section: Int) -> LogExerciseHeaderView? {
        let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: Storyboard.CellIdentifiers.LogExerciseHeader) as! LogExerciseHeaderView
        header.logExerciseHeaderViewDelegate = self
        header.exercise = tableData[section] as! Exercise
        return header
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return isFoodLogMode ? logTableView(tableView, logFoodViewForFooterInSection: section) : exerciseTableSectionFooter
    }
    
    var exerciseTableSectionFooter: UIView {
        
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 1))
        headerView.backgroundColor = UIColor.white
        return headerView
    }
    
    func logTableView(_ tableView: UITableView, logFoodViewForFooterInSection section: Int) -> LogFooterView? {
        let footer = tableView.dequeueReusableHeaderFooterView(withIdentifier: Storyboard.CellIdentifiers.LogFooter) as! LogFooterView
        footer.logFooterViewDelegate = self
        footer.mealType = tableData[section] as! MealType
        
        return footer
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // remove selection
        tableView.deselectRow(at: indexPath, animated: true)
        
        if isFoodLogMode {
            let cell = tableView.cellForRow(at: indexPath) as! LogFoodCell
            performSegue(withIdentifier: Storyboard.Segues.FoodDetail, sender: cell.food)
        }
        else {
            
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.setSeparatorInsetZero()
        
        if isFoodLogMode {
            (cell as? LogFoodCell)?.food = foodForIndexPath(indexPath)
            cell.layoutIfNeeded()
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        if view.isKind(of: LogExerciseHeaderView.self) {
            let exerciseHeader = view as! LogExerciseHeaderView
            exerciseHeader.setNeedsLayout()
            exerciseHeader.exercise = tableData[section] as! Exercise
        }
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return isFoodLogMode
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        
        // save the dragged food
        if draggedFood == nil  {
            if let mealType = tableData[sourceIndexPath.section] as? MealType {
                if mealType.foods.count > sourceIndexPath.row {
                    draggedFood = mealType.foods[sourceIndexPath.row]
                }
                else { return }
            }
            else { return }
        }
        
        if sourceIndexPath.section != destinationIndexPath.section {
            if let food = draggedFood {
                (tableData[destinationIndexPath.section] as? MealType)?.addFood(food)
                (tableData[sourceIndexPath.section] as? MealType)?.deleteFood(food, shouldUpdateServer: false)
            }
        }
    }
    
    func tableView(_ tableView: DragAndDropTableView!, willBeginDraggingCellAt indexPath: IndexPath!, placeholderImageView placeHolderImageView: UIImageView!) {
        
        placeHolderImageView.layer.shadowOpacity = 0.3
        placeHolderImageView.layer.shadowRadius = 1
    }
    
    func tableView(_ tableView: DragAndDropTableView!, didEndDraggingCellAt sourceIndexPath: IndexPath!, to toIndexPath: IndexPath!, placeHolderView placeholderImageView: UIImageView!) {
        
        // wtf! do nothing
        if sourceIndexPath == nil || toIndexPath == nil { return }
        
        if sourceIndexPath.section != toIndexPath.section {
            let mealType = tableData[toIndexPath.section] as? MealType
            if let food = draggedFood {
                food.updateFoodLog(mealType!.id) { (error) -> () in
                    
                }
            }
        }
        
        // clear the dragged food
        draggedFood = nil
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
    }
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        //        self.tableView.tableFooterView = nil
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        positionFooterView()
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        
    }
    
    func positionFooterView() {
        
        self.tableView.tableFooterView = nil
        self.tableView.tableFooterView = tableFooter
        tableView.bringSubview(toFront: tableFooter!)
        
        //print(" footer height after loading is \(tableFooter!.frame)")
    }
    
    func canCreateNewSection(_ section: Int) -> Bool {
        return false
    }
    
    // MARK:
    // MARK: UIAlertViewDelegate
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        if alertView.buttonTitle(at: buttonIndex) == &&"create" {
            
            
            if alertView.textField(at: 0)!.text!.characters.count <= 0 {
                self.showAlert()
                return
            }
            createMealType(alertView.textField(at: 0)!.text!)
        }
    }
    
    // MARK:
    // MARK: LogHeaderViewDelegate
    
    func logHeader(_ logHeaderView: LogHeaderView, infoButtonClickedForMealType mealType: MealType) {
        
        // show meal type info view
        // adjust view size
        mealTypeInfoView.frame = CGRect(x: 0, y: 0, width: view.bounds.width - 40, height: 150)
        
        //set the delegate
        mealTypeInfoView.mealTypeInfoViewDelegate = self
        
        //layer corner radius
        mealTypeInfoView.layer.cornerRadius = 50.0
        
        // set mealtype
        mealTypeInfoView.mealType = mealType
        
        // present popup
        KLCPopup(contentView: mealTypeInfoView).show(with: KLCPopupLayoutMake(.center, .center))
    }
    
    func mealTypeInfo(_ closePopUp: Bool) {
        
        //dismiss the pop up
        KLCPopup.dismissAllPopups()
    }
    // MARK:
    // MARK: LogFooterViewDelegate
    
    func logFooter(_ logFooterView: LogFooterView, addButtonClickedForMealTypeData mealType: MealType) {
        // add food
        performSegue(withIdentifier: Storyboard.Segues.AddFood, sender: mealType)
    }
    
    // MARK:
    // MARK: LogFoodCellDelegate
    
    func logFoodCell(_ logFoodCell: LogFoodCell, didCopyFood food: Food) {
        // show copy meal screen
        performSegue(withIdentifier: Storyboard.Segues.CopyMeal, sender: food)
    }
    
    func logFoodCell(_ logFoodCell: LogFoodCell, didDeleteFood food: Food) {
        // delete food
        food.mealType.deleteFood(food)
        self.foodLogs.remove(food)
        self.sortFoodLogArray(self.foodLogs)
        
        //refresh macros after deletion of food
        configureMacroStatusView()
    }
    
    func logFoodCell(_ logFoodCell: LogFoodCell, didAcceptFood food: Food) {
        
        food.approve = "Yes"
        food.changeShareStatus { (changedStatus) -> () in
            if !changedStatus { return }
            //print("shared status changed to Yes")
            self.sortFoodLogArray(self.foodLogs)
        }
        
        //refresh macros after deletion of food
        configureMacroStatusView()
    }
    
    func logFoodCell(_ logFoodCell: LogFoodCell, didDenyFood food: Food) {
        
        food.approve = "Deny"
        food.changeShareStatus { (changedStatus) -> () in
            if !changedStatus { return }
            //print("shared status changed to Deny")
            self.sortFoodLogArray(self.foodLogs)
            
        }
    }
    
    // MARK:
    // MARK: LogExerciseCellDelegate
    
    func logExerciseCell(_ logExerciseCell: LogExerciseCell, didDeleteExercise exercise: Exercise) {
        // delete exercise
        Exercise.deleteExercise(exercise.exerciseLogId, completionHandler: { (deletedStatus) -> () in
            if deletedStatus == true {
                //print("deleted successfully")
                self.exerciseData = self.exerciseData.filter(){ anExercise in
                    anExercise.exerciseLogId != exercise.exerciseLogId
                }
                self.reloadData()
                
            } else {
                //print("failed to delete")
                
            }
        })
    }
    
    func logExerciseCell(_ logExerciseCell: LogExerciseCell, shouldSendExerciseDetails exercise: Exercise) {
        performSegue(withIdentifier: Storyboard.Segues.SendExerciseDetails, sender: exercise)
    }
    
    // MARK:
    // MARK: LogExerciseHeaderViewDelegate
    
    func logExerciseHeader(_ logExerciseHeaderView: LogExerciseHeaderView, editDateForExercise exercise: Exercise) {
        
        Exercise.updateExercise(exercise, completionHandler: { (updatedStatus) -> () in
            
            if updatedStatus {
                
                //print("updated successfully")
                
                if !self.checkForSameDay(exercise.date) {
                    
                    self.exerciseData = self.exerciseData.filter(){ anExercise in
                        anExercise.exerciseLogId != exercise.exerciseLogId
                    }
                }
                self.reloadData()
                
            } else {
                //print("failed to update")
                
            }
        })
    }
    
    func checkForSameDay(_ date: Date) -> Bool {
        
        var isSame = false
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let date1String = dateFormatter.string(from: logDate)
        let date2String = dateFormatter.string(from: date)
        if date1String == date2String {
            //print("Equal date")
            isSame = true
        }
        
        return isSame
    }
    
    // MARK:
    // MARK: LogExerciseFooterViewDelegate
    
    func buttonActionAddExercise(_ logExerciseFooterView: LogExerciseFooterView) {
        //print("add exercise")
        self.performSegue(withIdentifier: Storyboard.Segues.AddExercise, sender: self)
    }
    
    // MARK:
    // MARK: Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == Storyboard.Segues.FoodDetail {
            let foodDetailViewController = segue.destination as! FoodDetailViewController
            foodDetailViewController.food = sender as! Food
            foodDetailViewController.canUpdate = true
            foodDetailViewController.logDate = logDate
            foodDetailViewController.isComingFromViewLog = true
        }
        else if segue.identifier == Storyboard.Segues.SendExerciseDetails {
            let sendDetailsViewController = segue.destination as! SendDetailsViewController
            sendDetailsViewController.sendDetailsViewMode = .exerciseDetail
            sendDetailsViewController.isFromDashboard = false
            sendDetailsViewController.logDate = logDate
            sendDetailsViewController.exercise = sender as? Exercise
        }
        else if segue.identifier == Storyboard.Segues.ShareFoodLog {
            let sendDetailsViewController = segue.destination as! SendDetailsViewController
            sendDetailsViewController.sendDetailsViewMode = .shareFoodLog
            sendDetailsViewController.isFromDashboard = false
            sendDetailsViewController.logDate = logDate
            
            mealData = userMealTypes.map() { mealType in
                let meal = MealType(name: mealType.name)
                meal.id = mealType.id
                meal.foods = self.foodLogs.filter() {
                    
                    $0.mealType.name == mealType.name && $0.approve != "Deny"
                }
                
                return meal
            }
            
            var foodLogsDict: [Dictionary<String, Any>] = []
            
            for mealtype in mealData {
                for food in mealtype.foods {
                    var foodDict = food.toMultiValDictionary()
                    foodDict["food_meal_type"] = NSNumber.init(value: mealtype.id as Int)
                    foodDict["meal_type"] = NSNumber.init(value: mealtype.id as Int)
                    foodLogsDict.append(foodDict)
                }
            }
            
            sendDetailsViewController.foodLogs = foodLogsDict
        }
        else if segue.identifier == Storyboard.Segues.ShareExerciseLog {
            
            let sendDetailsViewController = segue.destination as! SendDetailsViewController
            sendDetailsViewController.sendDetailsViewMode = .shareExerciseLog
            sendDetailsViewController.isFromDashboard = false
            sendDetailsViewController.logDate = logDate
            
            var exerciseDetails: [Dictionary<String, Any>] = []
            
            for data in self.tableData {
                exerciseDetails.append((data as! Exercise).toMultiValDictionaryForShareExerciseLogs())
            }
            sendDetailsViewController.exerciseDetailsLogs = exerciseDetails
        }
        else if segue.identifier == Storyboard.Segues.AddFood {
            let addFoodViewController = segue.destination as! AddFoodLogViewController
            let mealType = sender as? MealType
            addFoodViewController.mealType = mealType
            addFoodViewController.logDate = logDate
        }
        else if segue.identifier == Storyboard.Segues.AddExercise {
            let addExerciseViewController = segue.destination as! ExerciseCategoryViewController
            addExerciseViewController.logDate = logDate
            addExerciseViewController.isFromDashboard = false
        }
        else if segue.identifier == Storyboard.Segues.MacroChartView {
            
            let macroChartViewController = segue.destination as! MacroChartViewController
            macroChartViewController.macroDetails = macroDetails
            
        }
        else if segue.identifier == Storyboard.Segues.CopyMeal {
            
            let copyMealViewController = segue.destination as! CopyMealViewController
            copyMealViewController.totalMeals = userMealTypes

            copyMealViewController.copiedFood = sender as! Food
            
        }
    }
    
    // MARK: Button Actions
    
    @IBAction func buttonActionLogType(_ sender: UIButton) {
        
        // set view mode
        if sender.tag == 0 {
            isFoodLogMode = false
        }
        else {
            isFoodLogMode = true
        }
//        isFoodLogMode = Bool(sender.tag)
        
        showHUD = true
        fetchData()
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    @IBAction func buttonActionCreateNewMealType(_ sender: UIButton) {
        
        // show alert controller if possible else show alert view
        
        if #available(iOS 8.0, *) {
            let alert = UIAlertController(title: &&"create_new_meal_type", message: nil, preferredStyle: .alert)
            
            alert.addTextField { textField in
                textField.placeholder = &&"name_of_meal_type"
                
                // save create meal type textfield
                self.alertTextFieldcreateMealType = textField
                textField.delegate = self
            }
            
            alert.addAction(UIAlertAction(title: &&"create", style: .default) { _ in
                if alert.textFields?.last!.text!.characters.count <= 0 {
                    self.showAlert()
                    return
                }
                
                
                self.createMealType((alert.textFields?.last!.text)!)
                
                })
            
            alert.addAction(UIAlertAction(title: &&"cancel", style: .cancel, handler: nil))
            
            present(alert, animated: true, completion: nil)
        } else {
            // Fallback on earlier versions
            
            let alert = UIAlertView(title: &&"create_new_meal_type", message: "", delegate: self, cancelButtonTitle: &&"cancel", otherButtonTitles: &&"create")
            alert.alertViewStyle = .plainTextInput
            alert.textField(at: 0)?.placeholder = &&"name_of_meal_type"
            
            // save create meal type textfield
            alertTextFieldcreateMealType = alert.textField(at: 0)!
            alert.textField(at: 0)?.delegate = self
            alert.show()
        }
        
    }
    
    func showAlert(){
        let alert = UIAlertView(title: &&"error", message: &&"please_enter_meal_type", delegate: self, cancelButtonTitle: &&"Ok")
        alert.show()
    }
    @IBAction func buttonActionDecrementDate(_ sender: UIButton) {
        
        isFirstTime = false
        currentSelectedButton.isHidden = false
        currentSelectedButton = sender
        logDate = logDate.previousDay()
        showHUD = true
        fetchData()
    }
    
    @IBAction func buttonActionIncrementDate(_ sender: UIButton) {
        
        isFirstTime = false
        currentSelectedButton.isHidden = false
        currentSelectedButton = sender
        logDate = logDate.nextDay()
        showHUD = true
        fetchData()
    }
    
    @IBAction func barButtonActionRefreshMacros(_ sender: UIBarButtonItem) {
        // refresh macros
        configureMacroStatusView()
    }
    
    @IBAction func didTapShareButon(_ sender: Any) {
        print("share  button tapped")
        
        if isFoodLogMode == true {
            print("in food log mode")
            
            if self.foodLogs.count == 0 {
                let alert:UIAlertController = UIAlertController.init(title: &&"error", message: "No Food logs to share", preferredStyle: .alert)
                
                let cancelAction:UIAlertAction = UIAlertAction.init(title: &&"cancel", style: .cancel, handler: nil)
                
                alert.addAction(cancelAction)
                
                self.present(alert, animated: true, completion: nil)
            }
            performSegue(withIdentifier: Storyboard.Segues.ShareFoodLog, sender: nil)
            
        }
        else {
            print("in excercise log mode")
            
            if self.exerciseData.count == 0 {
                let alert:UIAlertController = UIAlertController.init(title: &&"error", message: "No Excercise logs to share", preferredStyle: .alert)
                
                let cancelAction:UIAlertAction = UIAlertAction.init(title: &&"cancel", style: .cancel, handler: nil)
                
                alert.addAction(cancelAction)
                
                self.present(alert, animated: true, completion: nil)
            }
            performSegue(withIdentifier: Storyboard.Segues.ShareExerciseLog, sender: nil)
        }
    }
    
    @IBAction func unwindToViewLogViewController(_ segue: UIStoryboardSegue) {
        
        //configure macro status view
        configureMacroStatusView()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var result = true
        
        // set character limit to meal type name
        if textField == alertTextFieldcreateMealType {
            let prospectiveText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
            if string.characters.count > 0 {
                let resultingStringLengthIsLegal = prospectiveText.characters.count <= 15
                result =  resultingStringLengthIsLegal
            }
        }
        return result
    }
}
