//
//  CreateMealPostResponse.swift
//  FlexYourMacros
//
//  Created by Attila Roy on 23/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class CreateMealPostResponse: NSObject {
    
    // model instance variables
    var meta = MetaModel()
    var food = FoodListModel()
    
    
    // message response mapping
    class var createMealResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(CreateMealPostResponse.metaModelKeyMapping)
        
        // give reference to food list model
        responseMapping?.addPropertyMapping(CreateMealPostResponse.foodListKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    fileprivate class var foodListKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMealFoodList, toKeyPath: "food", with: FoodListModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: createMealResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.kUrlPostCreateMeal, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func createFood(_ params: [String: Any], completionHandler: @escaping (_ food: Food, _ meta: MetaModel) -> ()) {
        
        RestKitManager.setToken(true)
        
        // create a post request
        let request = RestKitManager.shared().request(with: nil, method: .POST, path: Constants.ServiceConstants.kUrlPostCreateMeal, parameters: nil)
        
        // set params as body
        request?.httpBody = try? JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
        
        // create an operation with the request
        let operation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let createMealPostResponse = mappingResult?.firstObject as! CreateMealPostResponse
            
            // check for success
            if createMealPostResponse.meta.responseCode != 200 {
                //print("XXX failed to create a food \(params)")
            }
            
            // fire completion handler
            //completionHandler(food: Food(foodListModel: createMealPostResponse.food))
            completionHandler(Food(foodListModel: createMealPostResponse.food), createMealPostResponse.meta)
            
            }) { (operation, error) in
                //print("XXX failed to log food with error \(error)")
        }
        
        // enque request operation
        RestKitManager.shared().enqueue(operation)
    }
    
}
