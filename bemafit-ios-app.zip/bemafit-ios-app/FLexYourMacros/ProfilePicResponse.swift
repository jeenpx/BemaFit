//
//  ProfilePicResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 15/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ProfilePicResponse: NSObject {
 
    var metaModel: MetaModel?
    var user_id: String?
    var changeProfileModel: ProfilePicModel?
    
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        // give referece to meta model
        responseMapping?.addPropertyMapping(ProfilePicResponse.metaModelKeyMapping)
        responseMapping?.addPropertyMapping(ProfilePicResponse.profilePicModelMapping)
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    
    fileprivate class var profilePicModelMapping :RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathChangeProfilePic, toKeyPath: "changeProfileModel", with: ProfilePicModel.objectMapping )
    }
    
    class var userResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: RKRequestMethod.POST, pathPattern: Constants.ServiceConstants.ChangeProfilePicUrl ,keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }

    
    
    class func changeUserPic(_ completionHandler: @escaping (_ profilePicResponse:ProfilePicResponse) -> ()) {
        
        RestKitManager.setToken(true)
        //print("headers are  \(RKObjectManager.sharedManager().defaultHeaders)");
        let changeProfilePicResponse = ProfilePicResponse()
        changeProfilePicResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
        let parameterDictionary: [String:String] = ["":""]        
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: changeProfilePicResponse, method: RKRequestMethod.POST, path: nil, parameters: parameterDictionary, constructingBodyWith: { (formData) in
           if FymUser.sharedFymUser.userImage != nil {
                   //print("image found is done ")
                formData?.appendPart(withFileData: UIImageJPEGRepresentation(FymUser.sharedFymUser.userImage!, 0.0), name :"photo", fileName :"photo.png", mimeType :"image/png") }
        }

)
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let response = mappingResult?.firstObject as! ProfilePicResponse
            //print("respone code :\(response.metaModel?.responseCode)")
            //print("respone status :\(response.metaModel?.responseStatus)")
            
            // check for success
            if response.metaModel?.responseCode == 200 {
                completionHandler(response)
            }
            
            }) { (operation, error) in
                
                //print("failed to load  with error \(error)")
        }
        RestKitManager.shared().enqueue(operation)
        
    }
    
    
}
