//
//  UserHealthDetailsCalculations.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 19/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

enum ActivityLevel: Double {
    
    // enum for activity level
    case sedentary   = 1.200
    case lightly     = 1.375
    case moderately  = 1.550
    case veryActive  = 1.725
    case extraActive = 1.900
    
    var description: String {
        return NSString(format: "%.2f", self.rawValue) as String
    }
}

private var _FymUser = FymUser()

class FymUser: NSObject {
    
    var userFirstName = ""
    var userLastName = ""
    var userUserName = ""
    var userEmail = ""
    var userWebsite = ""
    var userPassword = ""
    var userImage : UIImage?
    var userFacebookId = ""
    var userGender = ""
    var userWeight = ""
    var userHeight = ""
    var userDob: Date = Date()
    var userDobString = ""
    var userFatLoss = ""
    var userBulkingIntensityValue = ""
    var userFatlossIntensityValue = ""
    var userGoalOptionId = ""
    var activityLevel = 0.0
    var formulaType = ""
    var userActivityLevelId = ""
    var userCustomCalorie: Double = 0.0
    var userNutritionType = ""
//    var userSelectedGoalName:String {
//        
//        return userSelectedGoal?.goalName!
//    }//= "Maintain"
    var userSelectedGoal: GoalModel?
    var userCustomProteinPercentage: Double = 0.0
    var userCustomFatPercentage: Double = 0.0
    var userCustomCarbsPercentage: Double = 0.0
    var userNumberOfMeals = 0
    var userCustomFiberValue = ""
    
    let areAllNutritionPlansActive:Bool = false
    
    var userHeightinCm: String {
        
        var userHeightArray = userHeight.components(separatedBy: ".")
        let feetString: String = userHeightArray[0] ?? "0"
        let inchesString: String = userHeightArray[1] ?? "0"
//        var noOfDecimals = Int(pow(Double(10),Double(count(inchesString))))
        let feets = feetString.doubleValue * 12.0 //* 30.48
        let inchesInFeet = inchesString.doubleValue///Double(noOfDecimals))//* 2.54
        return ((feets+inchesInFeet)*2.54).stringValue
    }
    
    var userWeightinKg: String {
      
        return (userWeight.doubleValue * 0.453592).stringValue
    }
    
    class var sharedFymUser: FymUser {
        
        return _FymUser
    }
    
    class func resetSharedInstance() {
        
        _FymUser = FymUser()
    }
    
    var userMaintainCalorie: Double  {
        
        if formulaType == "physique" {
            
            return calculateFitPhysiqueBMR() * getTheSelectedActivityLevelValue()
        }
        return calculateLeanMassBMR() * getTheSelectedActivityLevelValue()
    }
    
    var userBulkingCalorie: Double {
        
        if formulaType == "physique" {
            
            let tdeeValue =  calculateFitPhysiqueBMR() * getTheSelectedActivityLevelValue()
            
            return tdeeValue + ((userBulkingIntensityValue.doubleValue/100)*tdeeValue)
        }
        let tdeeValue =  calculateLeanMassBMR() * getTheSelectedActivityLevelValue()
        return tdeeValue + ((userBulkingIntensityValue.doubleValue/100)*tdeeValue)
        
    }
    
    var userFatlossCalorie: Double  {
        
        if formulaType == "physique" {
            
            let tdeeValue =  calculateFitPhysiqueBMR() * getTheSelectedActivityLevelValue()
            return tdeeValue - ((userFatlossIntensityValue.doubleValue/100)*tdeeValue)
        }
        let tdeeValue =  calculateLeanMassBMR() * getTheSelectedActivityLevelValue()
        return tdeeValue - ((userFatlossIntensityValue.doubleValue/100)*tdeeValue)
    }
    
    var userCalorieValue: String {
        return String(format: "%.2f", getTheSelectedGoalCalorie())
    }
    
    var userFiberValue: String {
        return userNutritionType == "5" ? userCustomFiberValue : String(format: "%.2f", getTheSelectedGoalCalorie()*(14/1000))
    }
    
    var userProtein: String {
        return String(format: "%.2fg", calculateUserMacros().proteinValue)
    }
    
    var userFat: String {
        return String(format: "%.2fg", calculateUserMacros().fatValue)
    }
    
    var userCarbs: String {
        return String(format: "%.2fg", calculateUserMacros().carbsValue)
    }
    
    var userProteinPercentage: String {
        return String(format: "%.2f", calculateUserMacroPercentages().proteinPercentage)
    }
    
    var userFatPercentage: String {
        return String(format: "%.2f", calculateUserMacroPercentages().fatPercentage)
    }
    
    var userCarbsPercentage: String {
        return String(format: "%.2f", calculateUserMacroPercentages().carbsPercentage)
    }
    
    func calculateUserMacros() -> (proteinValue: Double, fatValue: Double, carbsValue: Double) {
        
        var userProtein: Double = 0.0
        var userFat: Double = 0.0
        var userCarbs: Double = 0.0
        
        let weightInLb =  2.20462 * userWeightinKg.doubleValue
        // calculate macro values : if custom - give the custom value entered; else calculate based on formulae
        userProtein = userNutritionType == "5" ? ((userCustomProteinPercentage/100) * getTheSelectedGoalCalorie())/4 : weightInLb * 1.0
        userFat = userNutritionType == "5" ? ((userCustomFatPercentage/100) * getTheSelectedGoalCalorie())/9 : weightInLb * 0.35
        userCarbs = userNutritionType == "5" ? ((userCustomCarbsPercentage/100) * getTheSelectedGoalCalorie())/4 : (getTheSelectedGoalCalorie()-(userProtein*4 + userFat*9))/4
        
        return (userProtein, userFat, userCarbs)
    }
    
    func calculateUserMacroPercentages() -> (proteinPercentage: Double, fatPercentage: Double, carbsPercentage: Double) {
        
        var userProteinPercentage: Double = 0.0
        var userFatPercentage: Double = 0.0
        var userCarbsPercentage: Double = 0.0
        // calculate macro percentage : if custom - give the custom value entered; else calculate based on formulae
        userProteinPercentage = userNutritionType == "5" ? userCustomProteinPercentage : ((userProtein.doubleValue*4)/getTheSelectedGoalCalorie())*100
        
        userFatPercentage = userNutritionType == "5" ? userCustomFatPercentage : ((userFat.doubleValue*9)/getTheSelectedGoalCalorie())*100
        userCarbsPercentage = userNutritionType == "5" ? userCustomCarbsPercentage : ((userCarbs.doubleValue*4)/getTheSelectedGoalCalorie())*100
        return (userProteinPercentage, userFatPercentage, userCarbsPercentage)
    }
    
    func calculateAge() -> Double {
        
        let time = Date().timeIntervalSince(userDob)
        let allDays = (((time/60)/60)/24)
        let days = allDays.truncatingRemainder(dividingBy: 365);
        let years = (allDays-days)/365;

//        // get the age of the person based on todate
//        let ageComponents = NSCalendar.currentCalendar().components(.YearCalendarUnit, fromDate: userDob, toDate: NSDate(), options: nil)
        return Double(years)// Float(ageComponents.year)
    }
    
    func calculateFitPhysiqueBMR()-> Double {
        
        var userBMR: Double
        
        // calculate age of the user
        let userAge =  calculateAge() as Double
        
        switch userGender {
        case "M":
            // calculate BMR of male
            userBMR = (userWeightinKg.doubleValue * 10.0) + (userHeightinCm.doubleValue * 6.25) - (5.0 * userAge) + 5
        case "F":
            // calculate BMR of female
            userBMR = (userWeightinKg.doubleValue * 10.0) + (userHeightinCm.doubleValue * 6.25) - (5.0 * userAge) - 161
        default:
            userBMR =  0.0
        }
        
        return userBMR
    }
    
    func calculateLeanMassBMR() -> Double{
        
        var userBMR: Double
        
        // calculate lean mass from fatloss and weight
        func calculateLeanMass() -> Double {
            return userWeightinKg.doubleValue - ((userWeightinKg.doubleValue * userFatLoss.doubleValue)/100.0)
            
        }
        
        // calculate BMR for both male and female
        userBMR = 21.6 * calculateLeanMass() + 370
        
        return userBMR
    }
    
    func getTheSelectedGoalCalorie() -> Double {
        
        var selectedCalorie: Double = 0.00

        if let goalId = userSelectedGoal?.goalId {
        // get the calorie value based on the goal type selected
        switch goalId {
        case "1":
            selectedCalorie = userMaintainCalorie
        case "2" :
            selectedCalorie = userFatlossCalorie
        case "3" :
            selectedCalorie = userBulkingCalorie
        case "4" :
            selectedCalorie = userCustomCalorie
        default :
            selectedCalorie = 0.0
        }
        }
        return selectedCalorie
    }
    
    func getTheSelectedActivityLevelValue () -> Double {//(selectedActivity: String) -> String {
        
        let activityValue: String = AppConfiguration.sharedAppConfiguration.activityLevels.filter {
            $0.activityId == self.userActivityLevelId
            }.first?.activityValue ?? ""
        
        return activityValue.doubleValue
    }
    
}
