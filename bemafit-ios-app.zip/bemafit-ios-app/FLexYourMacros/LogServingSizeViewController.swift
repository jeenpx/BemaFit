//
//  LogServingSizeViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 14/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

enum WeightUnits: String {
    case KiloGram = "kilogram"
    case Ounce = "ounce"
    case Pound = "pound"
    case MicroGram = "microgram"
    
    static let allUnits = [WeightUnits.MicroGram, WeightUnits.KiloGram, WeightUnits.Ounce, WeightUnits.Pound]
    
    var conversionValue: Double {
        var value = 0.0
        switch self {
        case .MicroGram: value = (1/1000000)
        case .KiloGram: value = 1000
        case .Ounce: value = 28.3495
        case .Pound: value = 453.592
        }
        return value
    }
}

protocol ServingSizeCellDelegate {
    var canAbort: Bool { get }
    func servingSizeCell(_ servingSizeCell: ServingSizeCell, showValidationAlertForTextField textField: UITextField)
    func servingSizeCell(_ servingSizeCell: ServingSizeCell, didUpdateServingSize food: Food)
}

class ServingSizeCell: UITableViewCell, UITextFieldDelegate {
    
    var food = Food() {
        didSet {
            configureView()
        }
    }
    
    var servingSizeCellDelegate: ServingSizeCellDelegate?
    
    var isReadOnly = false
    
    // the raw serving size from the server without any updates
    var initialServingSize = 0.0 {
        didSet {
            var val:Double = Double(food.servingSize/initialServingSize)
            textFieldServingSize.text = val.roundedString()
            labelUnits.text = "\(initialServingSize.roundedString()) " + food.unit
        }
    }
    
    @IBOutlet weak var labelServingSize: UILabel!
    @IBOutlet weak var textFieldServingSize: UITextField!
    @IBOutlet weak var labelUnits: UILabel!
    
    func configureView() {
        var val:Double = Double(food.servingSize/initialServingSize)
        textFieldServingSize.text = val.roundedString()
        labelUnits.text = "\(initialServingSize.roundedString()) " + food.unit
        
        gestureRecognizers = [UITapGestureRecognizer(target: self, action: #selector(ServingSizeCell.handleTap(_:)))]
    }
    
    func handleTap(_ gesture: UITapGestureRecognizer)  {
        textFieldServingSize.becomeFirstResponder()
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        // dont update if aborting
        if servingSizeCellDelegate?.canAbort ?? false { return }
        
        food.updateServingSize(textField.text!.doubleValue * initialServingSize)
        servingSizeCellDelegate?.servingSizeCell(self, didUpdateServingSize: food)
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        // no checks if aborting
        if servingSizeCellDelegate?.canAbort ?? false { return true}
        
        let shouldEndEditing = textField.text!.doubleValue > 0
        if !shouldEndEditing {
            servingSizeCellDelegate?.servingSizeCell(self, showValidationAlertForTextField: textField)
        }
        return shouldEndEditing
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if string.isEmpty { return true }
        
        var isValid = true
        let text = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        
        // check for unwanted characters
        let replacementStringIsLegal = string.rangeOfCharacter(from: CharacterSet(charactersIn: "0123456789.").inverted) == nil
        
        // check for string count
        let resultingStringLengthIsLegal = text.characters.count <= 8
        
        
        // check if the number is valid
        let scanner = Scanner(string: text)
        let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
        
        let isLowNumber = text.doubleValue < 100000
        
        isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber
        
        if isValid {
            food.updateServingSize(text.doubleValue)
        }
        
        return isValid
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        textFieldServingSize.isUserInteractionEnabled = !isReadOnly
    }
}

enum MacroCellMode: String {
    case Carbohydrates = "carbohydrates"
    case Protein = "protein"
    case Fats = "fats"
    case Fiber = "fiber"
    case Calories = "calories"
    
    static var modes = [Carbohydrates, Protein, Fats, Fiber, Calories]
}

protocol MacroCellDelegate {
    var canAbort: Bool { get }
    func macroCell(_ macroCell: MacroCell, showValidationAlertForTextField textField: UITextField)
    func macroCell(_ macroCell: MacroCell, didUpdateMacro food: Food)
}

class MacroCell: UITableViewCell, UITextFieldDelegate {
    
    var food = Food() {
        didSet {
            configureView()
        }
    }
    
    var macroCellDelegate: MacroCellDelegate?
    
    var isReadOnly = false
    
    @IBOutlet weak var labelMacro: UILabel!
    @IBOutlet weak var textFieldMacroValue: UITextField!
    
    var macroCellMode = MacroCellMode.Carbohydrates {
        didSet {
            configureView()
        }
    }
    
    func configureView() {
        
        // set label
        labelMacro?.text = &&macroCellMode.rawValue +  ((macroCellMode != MacroCellMode.Calories) ? " (g)" : "")
        
        switch macroCellMode {
        case .Carbohydrates: textFieldMacroValue.text = food.carbohydrates.roundedString()
        case .Protein: textFieldMacroValue.text = food.protein.roundedString()
        case .Fats: textFieldMacroValue.text = food.fat.roundedString()
        case .Fiber: textFieldMacroValue.text = food.fiber.roundedString()
        case .Calories: textFieldMacroValue.text = food.calories.roundedString()
        default: break
        }
        
        gestureRecognizers = [UITapGestureRecognizer(target: self, action: #selector(ServingSizeCell.handleTap(_:)))]
    }
    
    func handleTap(_ gesture: UITapGestureRecognizer)  {
        textFieldMacroValue.becomeFirstResponder()
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        // no updations if aborting
        if macroCellDelegate?.canAbort ?? false { return }

        switch macroCellMode {
        case .Carbohydrates: food.updateCarbohydrates(textField.text!.doubleValue)
        case .Protein: food.updateProteins(textField.text!.doubleValue)
        case .Fats: food.updateFats(textField.text!.doubleValue)
        case .Fiber: food.updateFiber(textField.text!.doubleValue)
        case .Calories: food.updateCalories(textField.text!.doubleValue)
        default: break
        }
        
        macroCellDelegate?.macroCell(self, didUpdateMacro: food)
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        // no checks if aborting
        if macroCellDelegate?.canAbort ?? false { return true }

        let shouldEndEditing = textField.text!.doubleValue > 0
        if !shouldEndEditing {
            macroCellDelegate?.macroCell(self, showValidationAlertForTextField: textField)
        }
        return shouldEndEditing
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
    
        if string.isEmpty { return true }

        var isValid = true
        let text = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        
        // check for unwanted characters
        let replacementStringIsLegal = string.rangeOfCharacter(from: CharacterSet(charactersIn: "0123456789.").inverted) == nil
        
        // check for string count
        let resultingStringLengthIsLegal = text.characters.count <= 10
        
        // check if the number is valid
        let scanner = Scanner(string: text)
        let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.isAtEnd
        
        let isLowNumber = text.doubleValue < 100000
        
        isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber
        
        if isValid {
            switch macroCellMode {
            case .Carbohydrates: food.updateCarbohydrates(text.doubleValue)
            case .Protein: food.updateProteins(text.doubleValue)
            case .Fats: food.updateFats(text.doubleValue)
            case .Fiber: food.updateFiber(text.doubleValue)
            case .Calories: food.updateCalories(text.doubleValue)
            default: break
            }            
        }
        
        return isValid
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        textFieldMacroValue.isUserInteractionEnabled = !isReadOnly
    }
}

protocol ServingSizeFoodHeaderDelegate {
    func servingSizeFoodHeader(_ servingSizeFoodHeader: ServingSizeFoodHeader, shouldLogByServingSize: Bool)
}

class ServingSizeFoodHeader: UITableViewHeaderFooterView {
    
    var food = Food() {
        didSet {
            labelFood.text = food.name
        }
    }
    
    var servingSizeFoodHeaderDelegate: ServingSizeFoodHeaderDelegate?
    
    var section = 0 {
        didSet {
            if section == 0 {
                buttonShuffle.isHidden = false
            }
            else {
                buttonShuffle.isHidden = true
            }
//            buttonShuffle.isHidden = Bool(section)
        }
    }
    
    var labelFood = UILabel()
    var buttonShuffle = UIButton()
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        
        configureView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        configureView()
    }
    
    func configureView() {
        
        // set background color
        contentView.backgroundColor = UIColor(red: 44.0/255.0, green: 44.0/255.0, blue: 44.0/255.0, alpha: 1.0)//UIColor.lightBlackColor()
        
        // configure label
        labelFood.textColor = UIColor.white
        labelFood.font = UIFont.helveticaBold(17)
        labelFood.backgroundColor = UIColor.clear
        labelFood.setContentHuggingPriority(100, for: .horizontal)
        labelFood.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(labelFood)
        
        // configure shuffle button
        buttonShuffle.setImage(UIImage(named: "ShuffleButton"), for: UIControlState())
        buttonShuffle.addTarget(self, action: #selector(ServingSizeFoodHeader.buttonActionShuffle(_:)), for: .touchUpInside)
        buttonShuffle.backgroundColor = UIColor.clear
        buttonShuffle.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(buttonShuffle)
        
        // setup constraints
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-15-[labelFood]-40@750-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["labelFood": labelFood]))
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[buttonShuffle(50)]-0-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["buttonShuffle": buttonShuffle]))
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[labelFood]-0-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["labelFood": labelFood]))
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[buttonShuffle]-0-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["buttonShuffle": buttonShuffle]))
    }
    
    func buttonActionShuffle(_ sender: UIButton) {
        servingSizeFoodHeaderDelegate?.servingSizeFoodHeader(self, shouldLogByServingSize: false)
    }
}

protocol ServingSizeMacrosHeaderDelegate {
    func servingSizeMacrosHeader(_ servingSizeMacrosHeader: ServingSizeMacrosHeader, shouldLogByServingSize: Bool)
    func servingSizeMacrosHeader(_ servingSizeMacrosHeader: ServingSizeMacrosHeader, shouldShowInfo food: Food)
}

class ServingSizeMacrosHeader: UITableViewHeaderFooterView {
    
    var food = Food()
    
    var servingSizeMacrosHeaderDelegate: ServingSizeMacrosHeaderDelegate?
    
    var section = 0 {
        didSet {
            if section == 0 {
                buttonShuffle.isHidden = false
            }
            else {
                buttonShuffle.isHidden = true
            }
//            buttonShuffle.isHidden = Bool(section)
        }
    }
    
    var labelMacros = UILabel()
    var buttonShuffle = UIButton()
    var buttonInfo = UIButton(type: UIButtonType.infoLight)
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        
        configureView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        configureView()
    }
    
    func configureView() {
        
        // set background color
        contentView.backgroundColor = UIColor(red: 44.0/255.0, green: 44.0/255.0, blue: 44.0/255.0, alpha: 1.0)//UIColor.lightBlackColor()
        
        // configure label
        labelMacros.textColor = UIColor.white
        labelMacros.font = UIFont.helveticaBold(17)
        labelMacros.backgroundColor = UIColor.clear
        labelMacros.text = &&"macros"
        labelMacros.translatesAutoresizingMaskIntoConstraints = false
        labelMacros.setContentHuggingPriority(100, for: .horizontal)
        contentView.addSubview(labelMacros)
        
        // configure shuffle button
        buttonShuffle.setImage(UIImage(named: "ShuffleButton"), for: UIControlState())
        buttonShuffle.addTarget(self, action: #selector(ServingSizeFoodHeader.buttonActionShuffle(_:)), for: .touchUpInside)
        buttonShuffle.backgroundColor = UIColor.clear
        buttonShuffle.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(buttonShuffle)
        
        // configure info button
        buttonInfo.addTarget(self, action: #selector(ServingSizeMacrosHeader.buttonActionInfo(_:)), for: .touchUpInside)
        buttonInfo.tintColor = UIColor.defaultThemeBlueColor()
        buttonInfo.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(buttonInfo)
        
        // setup constraints
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[buttonInfo(50)]-0-[labelMacros]", options: NSLayoutFormatOptions(), metrics: nil, views: ["labelMacros": labelMacros, "buttonInfo": buttonInfo]))
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[buttonShuffle(50)]-0-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["buttonShuffle": buttonShuffle]))
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[labelMacros]-0-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["labelMacros": labelMacros]))
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[buttonShuffle]-0-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["buttonShuffle": buttonShuffle]))
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[buttonInfo]-0-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["buttonInfo": buttonInfo]))
    }
    
    func buttonActionInfo(_ sender: UIButton) {
        servingSizeMacrosHeaderDelegate?.servingSizeMacrosHeader(self, shouldShowInfo: food)
    }
    
    func buttonActionShuffle(_ sender: UIButton) {
        servingSizeMacrosHeaderDelegate?.servingSizeMacrosHeader(self, shouldLogByServingSize: true)
    }
}

class LogServingSizeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, ServingSizeCellDelegate, MacroCellDelegate, ServingSizeFoodHeaderDelegate, ServingSizeMacrosHeaderDelegate {
    
    var mealType: MealType?
    
    var logDate: Date?
    
    var macroStats = MacroModel()
    
    var isComingFromDashboard: Bool {
        return mealType == nil
    }

    var isDailyMealPlan = false
    
    var dailyMealType = DailyMealType(dailyMealTypeName: "")
    
    var food = Food()
    
    var initialServingSize = 0.0
    
    // will be logging by serving size by default
    var isLoggingByServingSize = true {
        didSet {
            
            // update indices
            
            if isLoggingByServingSize == true {
                indexServingSize = Int(0)
                indexMacro = Int(1)
            }
            else {
                indexServingSize = Int(1)
                indexMacro = Int(0)
            }
            
//            indexServingSize = Int(!isLoggingByServingSize)
//            indexMacro = Int(isLoggingByServingSize)
            
            // reload table
            tableView.reloadData()
        }
    }
    
    // if the values entered are legitimate
    fileprivate var canLog = true
    
    // tells when to ignore checks
    internal var canAbort = false
    
    fileprivate var indexServingSize = 0
    fileprivate var indexMacro = 1
    
    @IBOutlet weak var tableView: TPKeyboardAvoidingTableView!
    @IBOutlet var mealTypeInfoView: MealTypeInfoView!
    
    @IBOutlet weak var barButtonLog: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // cant abort
        canAbort = false
        
        // save the inital serving size to display with the unit
        initialServingSize = food.servingSize
        
        // recalculate calories based on the macro values (the correct calorie value)
        food.updateServingSize(food.servingSize)
        
        MacroModel.refreshUserMacros { (macroStats) in
            DispatchQueue.main.async {
                self.macroStats = macroStats
                self.food.updateCalories(macroStats.macrosLeft().caloriesLeft.doubleValue)
                self.tableView.reloadData()
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // can abort all checks now
        canAbort = true
    }
    
    func configureView() {
        
        // register headers
        tableView.register(ServingSizeFoodHeader.self, forHeaderFooterViewReuseIdentifier: Storyboard.Headers.ServingSizeFoodHeader)
        tableView.register(ServingSizeMacrosHeader.self, forHeaderFooterViewReuseIdentifier: Storyboard.Headers.ServingSizeMacrosHeader)
        
        // ensure empty under table
        tableView.tableFooterView = UIView()
        
        // configure right navigation button
        if !isComingFromDashboard {
            barButtonLog.title = &&"log"
            barButtonLog.image = nil
        }
    }
    
    func showValidationAlert() {
        UIAlertView(title: &&"error", message: &&"serving_size_validation_alert_message", delegate: nil, cancelButtonTitle: &&"cancel").show()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.section == indexServingSize ? 80.0 : 60.0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == indexServingSize ? 1 : 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == indexServingSize {
            let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.ServingSizeCell, for: indexPath) as! ServingSizeCell
            cell.food = food
            cell.initialServingSize = initialServingSize
            cell.servingSizeCellDelegate = self
            
            if indexPath.section == 0 {
                cell.isReadOnly = false
            }
            else {
                cell.isReadOnly = true
            }
            
//            cell.isReadOnly = Bool(indexPath.section)
            return cell
        }
        else if indexPath.section == indexMacro {
            let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.MacroCell, for: indexPath) as! MacroCell
            cell.food = food
            cell.macroCellMode = MacroCellMode.modes[indexPath.row]
            cell.macroCellDelegate = self
            
            if indexPath.section == 0 {
                cell.isReadOnly = false
            }
            else {
                cell.isReadOnly = true
            }
//            cell.isReadOnly = Bool(indexPath.section)
            return cell
        }
        
        // XXX something has gone wrong, handling with an empty cell
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 32
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == indexServingSize {
            let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: Storyboard.Headers.ServingSizeFoodHeader) as! ServingSizeFoodHeader
            header.food = food
            header.servingSizeFoodHeaderDelegate = self
            header.section = section
            return header
        }
        else if section == indexMacro {
            let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: Storyboard.Headers.ServingSizeMacrosHeader) as! ServingSizeMacrosHeader
            header.food = food
            header.servingSizeMacrosHeaderDelegate = self
            header.section = section
            return header
        }
        else {
            return UIView()
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.setSeparatorInsetZero()
    }
    
    func servingSizeCell(_ servingSizeCell: ServingSizeCell, showValidationAlertForTextField textField: UITextField) {
        canLog = false
        showValidationAlert()
        textField.becomeFirstResponder()
    }
    
    func servingSizeCell(_ servingSizeCell: ServingSizeCell, didUpdateServingSize food: Food) {
        
        // updated serving size
        canLog = true
        tableView.reloadData()
    }
    
    func macroCell(_ macroCell: MacroCell, showValidationAlertForTextField textField: UITextField) {
        canLog = false
        showValidationAlert()
        textField.becomeFirstResponder()
    }
    
    func macroCell(_ macroCell: MacroCell, didUpdateMacro food: Food) {
        
        // updated macro
        canLog = true
        tableView.reloadData()
    }
    
    func servingSizeFoodHeader(_ servingSizeFoodHeader: ServingSizeFoodHeader, shouldLogByServingSize: Bool) {
        isLoggingByServingSize = shouldLogByServingSize
    }
    
    func servingSizeMacrosHeader(_ servingSizeMacrosHeader: ServingSizeMacrosHeader, shouldLogByServingSize: Bool) {
        isLoggingByServingSize = shouldLogByServingSize
    }
    
    func servingSizeMacrosHeader(_ servingSizeMacrosHeader: ServingSizeMacrosHeader, shouldShowInfo food: Food) {
        
        // show meal type info view
        // adjust view size
        mealTypeInfoView.frame = CGRect(x: 0, y: 0, width: view.bounds.width - 40, height: 150)
        
        //layer corner radius
        mealTypeInfoView.layer.cornerRadius = 50.0
        
        // set mealtype
        mealTypeInfoView.macroStats = macroStats
        
        // present popup
        KLCPopup(contentView: mealTypeInfoView).show(with: KLCPopupLayoutMake(.center, .center))
    }
    
    struct Storyboard {
        struct CellIdentifiers {
            static let ServingSizeCell = "kServingSizeCell"
            static let MacroCell = "kMacroCell"
        }
        struct Headers {
            static let ServingSizeFoodHeader = "kServingSizeFoodHeader"
            static let ServingSizeMacrosHeader = "kServingSizeMacrosHeader"
        }
        struct Segues {
            static let MealTypeListSegue = "kMealTypeListSegue"
            static let UnwindViewLogSegue = "kUnwindViewLogSegue"
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == Storyboard.Segues.MealTypeListSegue {
            let mealTypeListViewController = segue.destination as! MealTypeListViewController
            mealTypeListViewController.mealTypeListInitiator = MealTypeListInitiator.createFromServingSize
            mealTypeListViewController.food = food
        }
    }
    
    @IBAction func buttonActionUpdate(_ sender: UIButton) {
        tableView.reloadData()
    }
    
    @IBAction func barButtonActionLog(_ sender: UIBarButtonItem) {
        
        tableView.endEditing(true)
        
        if isDailyMealPlan {
            
            food.dailyMealType = dailyMealType
            food.mealType = mealType!
            food.addedDate = Date()
            NotificationCenter.default.post(name: Notification.Name(rawValue: "RefreshMealPlanIdentifier"), object: nil, userInfo: ["newFood": food, "method": "Read"])
            
            //resign to the daily meal plan viewcontroller
            if let viewControllers = navigationController?.viewControllers {
                for viewController in viewControllers {
                    // some process
                    if viewController.isKind(of: DailyMealPlanDetailViewController.self) {
                        self.navigationController?.popToViewController(viewController, animated: true)
                    }
                }
            }
            return
        }
        
        if !canLog { return }
        
        if isComingFromDashboard {
            performSegue(withIdentifier: Storyboard.Segues.MealTypeListSegue, sender: food)
            return
        }
        
        // log food
        food.logFood(mealType!.id, mealDate: logDate ?? Date(), userGuid: AppConfiguration.sharedAppConfiguration.userDetails!.userId!) { (error) -> () in
            //print("logged food")
            self.performSegue(withIdentifier: Storyboard.Segues.UnwindViewLogSegue, sender: nil)
        }
    }
}
