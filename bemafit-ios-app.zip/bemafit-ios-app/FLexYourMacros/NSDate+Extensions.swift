//
//  NSDate+Extensions.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/6/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

let kMinute = 60
let kDay = kMinute * 24

extension NSDate {
    
    var timeAgo: String {
        
        // current date
        let now = NSDate()
        
        // difference in seconds
        let deltaSeconds = Int(fabs(timeIntervalSinceDate(now)))
        
        // difference in minutes
        let deltaMinutes = deltaSeconds / 60
        
        var value: Int!
        
        if deltaSeconds < 5 {
            // just now
            return NSLocalizedString("Just now", comment: "")
        } else if deltaSeconds < kMinute {
            // seconds ago
            return stringFromFormat("%%d %@seconds ago", withValue: deltaSeconds)
        } else if deltaSeconds < 120 {
            // a minute ago
            return stringFromFormat("A minute ago", withValue: deltaSeconds)
        } else if deltaMinutes < kMinute {
            // minutes ago
            return stringFromFormat("%%d %@minutes ago", withValue: deltaMinutes)
        } else if deltaMinutes < 120 {
            // an hour ago
            return NSLocalizedString("An hour ago", comment: "")
        } else if deltaMinutes < kDay {
            // hours ago
            value = Int(floor(Float(deltaMinutes / kMinute)))
            return stringFromFormat("%%d %@hours ago", withValue: value)
        } else if deltaMinutes < (kDay * 2) {
            // yesterday
            return NSLocalizedString("Yesterday", comment: "")
        } else {
            // date
            let dateFormat = NSDateFormatter()
            dateFormat.dateFormat = "MMMM dd yyyy"
            return dateFormat.stringFromDate(self)
        }
    }
    
    func stringFromFormat(format: String, withValue value: Int) -> String {
        // get the string value from format
        
        // XXX - how to avoid getLocaleFormatUnderscoresWithValue
        let localeFormat = String(format: format, getLocaleFormatUnderscoresWithValue(Double(value)))
        return String(format: NSLocalizedString(localeFormat, comment: ""), value)
    }
    
    func getLocaleFormatUnderscoresWithValue(value: Double) -> String {
        // get the locale format
        
        // country code
        let localeCode = NSLocale.preferredLanguages().first as! String
        
        if localeCode == "ru" {
            let XY = Int(floor(value)) % 100
            let Y = Int(floor(value)) % 10
            
            if Y == 0 || Y > 4 || (XY > 10 && XY < 15) {
                return ""
            }
            
            if Y > 1 && Y < 5 && (XY < 10 || XY > 20) {
                return "_"
            }
            
            if Y == 1 && XY != 11 {
                return "__"
            }
        }
        
        return ""
    }
    
    class func stringToDate(formatter: String, dateString: String) -> NSDate {
        // convert string to date
        
        let dateFormat = NSDateFormatter()
        dateFormat.dateFormat = formatter
        return dateFormat.dateFromString(dateString)!
    }
    
    class func dateToString(formatter: String, date: NSDate) -> String {
        // convert date to string
        
        let dateFormat = NSDateFormatter()
        dateFormat.dateFormat = formatter
        return dateFormat.stringFromDate(date)
    }
    
}
