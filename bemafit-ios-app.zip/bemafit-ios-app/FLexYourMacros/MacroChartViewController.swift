//
//  MacroChartView.swift
//  ChartViews
//
//  Created by DBG-39 on 23/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

import UIKit

class MacroChartViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableViewMacro: UITableView!
    
    let macroArray = [&&"carbohydrates", &&"fat", &&"protein", &&"fiber"]
    
    var macroDetails: MacroModel = MacroModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // Return the number of sections.
        return 3
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        var headerHeight : CGFloat?
        if section == 0 { headerHeight = 0.0 }
        else if section == 1 || section == 2 { headerHeight = 35.0 }
        return headerHeight!
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView: UIView = UIView()
        headerView.frame = CGRect(x: 0, y: 0, width: tableViewMacro.frame.maxX, height: 35.0)
        headerView.backgroundColor = UIColor.lightGray
        let headerBackgroundView = UIView()
        headerBackgroundView.frame = headerView.frame
        headerBackgroundView.backgroundColor = UIColor.gray//UIColor(red: 44.0/255.0, green: 44.0/255.0, blue: 44.0/255.0, alpha: 1.0)
        headerBackgroundView.alpha = 0.5
        headerView .addSubview(headerBackgroundView)
        if section == 2 {
            let labelHeaderTitle: UILabel = UILabel()
            labelHeaderTitle.text = &&"fiber_goal"//fibra Meta
            labelHeaderTitle.frame = CGRect(x: 15, y: 5, width: 120, height: 30)
            labelHeaderTitle.font = UIFont(name: "Helvetica", size: 16.0)
            headerView .addSubview(labelHeaderTitle)
        }
    
        let labelTotal: UILabel = UILabel()
        labelTotal.text = &&"total"
        labelTotal.font = UIFont(name: "Helvetica", size: 16.0)
        labelTotal.frame = CGRect(x: tableView.frame.maxX - 185, y: 5, width: 120, height: 30)
        labelTotal.textAlignment = NSTextAlignment.center
        headerView.addSubview(labelTotal)
        
        let labelGoal: UILabel = UILabel()
        labelGoal.text = &&"goal"
        labelGoal.font = UIFont(name: "Helvetica", size: 16.0)
        labelGoal.frame = CGRect(x: tableView.frame.maxX - 70, y: 5, width: 120, height: 30)
        headerView.addSubview(labelGoal)
        
        return headerView
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        var cellHeight: CGFloat = 0
        if indexPath.section == 0 { cellHeight = 400.0 }
        else if indexPath.section == 1 || indexPath.section == 2 { cellHeight = 30.0 }
        return cellHeight
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var noOfRows: Int = 0
        if section == 1 { noOfRows = 3 }
        else { noOfRows = 1 }
        return noOfRows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell?
        
        if indexPath.section == 0 {
            let cellChart =  tableView.dequeueReusableCell(withIdentifier: "kChartCell") as! ChartTableViewCell
            cellChart.loadGraph(macroDetails)
            cell = cellChart
        } else  if indexPath.section == 1 {
          
            // populate macro cell
            let cellMacro =  tableView.dequeueReusableCell(withIdentifier: "kMacroCell") as! MacroTableViewCell
            cellMacro.macroColor = bulletColorForRow(recordIndex: indexPath)
            if indexPath.row == 0 {
              cellMacro.configure(macroArray[indexPath.row], macroTotal: macroDetails.carbsTotal, macroAchieved: macroDetails.carbAchived)
            } else if indexPath.row == 1 {
                cellMacro.configure(macroArray[indexPath.row], macroTotal: macroDetails.fatTotal, macroAchieved: macroDetails.fatAchived)
                
            } else  if indexPath.row == 2 {
                cellMacro.configure(macroArray[indexPath.row], macroTotal: macroDetails.proteinTotal, macroAchieved: macroDetails.proteinAchived)
                
            }
            cell = cellMacro
            
        }else if indexPath.section == 2 {
            // populate macro cell
            let cellMacro =  tableView.dequeueReusableCell(withIdentifier: "kMacroCell") as! MacroTableViewCell
            cellMacro.macroColor = bulletColorForRow(recordIndex: indexPath)
            cellMacro.configure(macroArray[3], macroTotal: macroDetails.fiberTotal, macroAchieved: macroDetails.fiberAchived)
            cell = cellMacro
        }
        
        return cell!
    }
    
    func bulletColorForRow(recordIndex index: IndexPath) -> UIColor {
        
        return [[UIColor(red: 141.0/255.0, green: 199.0/255.0, blue: 63.0/255.0, alpha: 1.0), UIColor.defaultThemeBlueColor(), UIColor(red: 247.0/255.0, green: 148.0/255.0, blue: 29.0/255.0, alpha: 1.0)], [UIColor.clear]][index.section-1][index.row]
    }
    
    @IBAction func buttonActionClose(_ sender: UIButton) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    
}
