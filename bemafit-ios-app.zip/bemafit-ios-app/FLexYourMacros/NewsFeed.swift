//
//  NewsFeed.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 01/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

enum NewsFeedType: String {
    case StatusPost = "status"
    case ExerciseLog = "exercise"
    case FriendRequestAccepted = "friendrequest"
    case GoalReached = "goal"
    case CheckinStatusPost = "checkin"
    case GuestPost = "guestpost"
    
    static func getNewsFeedType(_ type: String) -> NewsFeedType {
        switch type {
        case "text": return NewsFeedType.StatusPost
        case "goal": return NewsFeedType.GoalReached
        case "exercise": return NewsFeedType.ExerciseLog
        case "checkin": return NewsFeedType.CheckinStatusPost
        case "friends": return NewsFeedType.FriendRequestAccepted
        case "guest_post": return NewsFeedType.GuestPost
        default: return NewsFeedType.StatusPost
        }
    }
}

struct NewsFeedContent: OptionSet {
    fileprivate var value: UInt = 0
    init(_ value: UInt) { self.value = value }
    init(rawValue value: UInt) { self.value = value }
    init(nilLiteral: ()) { value = 0 }
    static var allZeros: NewsFeedContent { return self.init(0) }
    static func fromMask(_ raw: UInt) -> NewsFeedContent { return self.init(raw) }
    var rawValue: UInt { return value }
    var boolValue: Bool { return value != 0 }
    
    static var None: NewsFeedContent { return self.init(0) }
    static var Text: NewsFeedContent { return self.init(1 << 0) }
    static var Image: NewsFeedContent { return self.init(1 << 1) }
}

class NewsFeed: NSObject {
    
    var id = ""
    var stringNewsFeedType = ""
    var newsFeedType: NewsFeedType {
        return NewsFeedType.getNewsFeedType(stringNewsFeedType)
    }
    var stringCreatedDate = ""
    var created: Date {
        return stringCreatedDate.utcDateValue("yyyy-MM-dd HH:mm:ss") ?? Date()
    }
    var data = ""
    var inspireCount = 0
    var stringInspireCount: NSAttributedString {
        return inspireText(inspireCount)
    }
    var likeCount = 0
    var stringLikeCount: NSAttributedString {
        return likeText(likeCount)
    }
    var commentCount = 0
    var stringCommentCount: NSAttributedString {
        let textCount = commentCount > 1 ? &&"comments" : &&"comment"
        let prefix = commentCount > 0 ? "\(commentCount) " : ""
        return NSAttributedString(string: " " + prefix + textCount, attributes: [NSFontAttributeName: prefix.isEmpty ? UIFont.helvetica(12) : UIFont.helveticaBold(12), NSForegroundColorAttributeName: UIColor.darkTextGrayColor()])
    }
    var friendId1 = ""
    var friendName1 = ""
    var friendProfilePic1 = ""
    var friendId2 = ""
    var friendName2 = ""
    var friendProfilePic2 = ""
    var checkinUserId = ""
    var checkinUserName = ""
    var checkinUserProfilePic = ""
    var checkinBusinessDirectoryId = ""
    var checkinBusinessDirectoryName = ""
    var checkinBusinessDirectoryImage = ""
    var userId = ""
    var userName = ""
    var userProfilePic =  ""
    var exerciseUserId = ""
    var exerciseUserName = ""
    var exerciseProfilePic = ""
    var exerciseName = ""
    var feedImage = "" {
        didSet {
            //print("XXX Feed Image Updated for \(stringNewsFeedType) with \(feedImage)")
        }
    }
    var stringGoalDate = ""
    
    var goalDate: Date {
        return stringGoalDate.utcDateValue("yyyy-MM-dd") ?? Date()
    }
    var isLiked = false
    var isInspired = false
    
    var newsFeedContent: NewsFeedContent {
        var content = NewsFeedContent.None
        
        // text mode
        if !data.isEmpty {
            content = content.union(NewsFeedContent.Text)
        }
        
        // image mode
        if !feedImage.isEmpty {
            content = content.union(NewsFeedContent.Image)
        }
        
        if newsFeedType == .CheckinStatusPost {
            content = content.union(NewsFeedContent.Text)
            content = content.union(NewsFeedContent.Image)
        }
        
        return content
    }
    
    // static content heights
    let contentHeightHeader = 75.0
    let contentHeightFooter = 35.0
    
    // dynamic body height
    var contentHeightBody: Double {
        
        // height is static for feeds with image
        if newsFeedContent.intersection(.Image).boolValue {
            return 110.0
        }
        else if newsFeedContent.intersection(.Text).boolValue {
            let bodyWidth = kMainScreenWidth - 40.0
            
            // extra font size for padding
            let font = UIFont.helvetica(13)
            
            return data.expectedHeight(bodyWidth, font: font) + 15.0
        }
        else { return 0.0 }
    }
    
    let padding = 10.0
    
    var savedHeight = 0.0
    var contentHeight: Double {
        
        if savedHeight != 0.0 { return savedHeight }
        
        // save height for future use
        savedHeight = contentHeightHeader + contentHeightBody + contentHeightFooter + padding
        
        return savedHeight
    }
    
    func likeText(_ count: Int) -> NSAttributedString {
        let textCount = count > 1 ? &&"likes" : &&"like"
        let prefix = count > 0 ? "\(count) " : ""
        return NSAttributedString(string: " " + prefix + textCount, attributes: [NSFontAttributeName: prefix.isEmpty ? UIFont.helvetica(12) : UIFont.helveticaBold(12), NSForegroundColorAttributeName: UIColor.darkTextGrayColor()])
        
    }
    
    func inspireText(_ count: Int) -> NSAttributedString {
        let textCount = count > 0 ? &&"inspired" : &&"inspire"
        let prefix = count > 0 ? "\(count) " : ""
        return NSAttributedString(string: " " + prefix + textCount, attributes: [NSFontAttributeName: prefix.isEmpty ? UIFont.helvetica(12) : UIFont.helveticaBold(12), NSForegroundColorAttributeName: UIColor.darkTextGrayColor()])
    }
    
    func getShareContent() -> (FacebookShareModel) {
        
        let facebookShareModel = FacebookShareModel()
        facebookShareModel.link = "http://flexyourmacros.com/"
        switch newsFeedType {
        case .GoalReached:
            
            facebookShareModel.description = userName + " " + &&"goal_heading";
            facebookShareModel.pictureLink = (userProfilePic.isEmpty) ? "" : userProfilePic
            
        case .ExerciseLog:
            
            facebookShareModel.description = exerciseUserName + " " + &&"exercise_heading" + " " + exerciseName
            facebookShareModel.pictureLink = (exerciseProfilePic.isEmpty) ? "" : exerciseProfilePic
            
        case .FriendRequestAccepted:
            
            facebookShareModel.description = friendName1 +  " " + &&"friend_accepted_heading" + " " + friendName2
            facebookShareModel.pictureLink = (friendProfilePic1.isEmpty) ? "" : friendProfilePic1
            
        case .CheckinStatusPost:
            
            facebookShareModel.description = checkinUserName + " " + &&"checkin_heading" + " " + checkinBusinessDirectoryName
            facebookShareModel.pictureLink = (checkinUserProfilePic.isEmpty) ? "" : checkinUserProfilePic
            
        case .StatusPost:
            
            facebookShareModel.description = (data.isEmpty) ? "Changed status" : data
            facebookShareModel.pictureLink = (feedImage.isEmpty) ? "" : feedImage
            
        case .GuestPost:
            
            facebookShareModel.description = (data.isEmpty) ? "Changed status" : data
            facebookShareModel.pictureLink = (feedImage.isEmpty) ? "" : feedImage
        }
        
        return facebookShareModel;
    }
    
    class var objectMapping: RKObjectMapping {
        
        let mappingDictionary = ["feed_id": "id",
            "feed_type": "stringNewsFeedType",
            "created_date": "stringCreatedDate",
            "feed_data": "data",
            "inspire_count": "inspireCount",
            "like_count": "likeCount",
            "comment_count": "commentCount",
            "friend_id1": "friendId1",
            "friend_name1": "friendName1",
            "friend_photo1": "friendProfilePic1",
            "friend_id2": "friendId2",
            "friend_name2": "friendName2",
            "friend_photo2": "friendProfilePic2",
            "checkin_user_id": "checkinUserId",
            "checkin_user_name": "checkinUserName",
            "checkin_profile_photo": "checkinUserProfilePic",
            "checkin_business_id": "checkinBusinessDirectoryId",
            "checkin_business": "checkinBusinessDirectoryName",
            "checkin_business_image": "checkinBusinessDirectoryImage",
            "user_id": "userId",
            "user_name": "userName",
            "profile_photo": "userProfilePic",
            "exc_user_id": "exerciseUserId",
            "exc_user_name": "exerciseUserName",
            "exc_profile_photo": "exerciseProfilePic",
            "exercise": "exerciseName",
            "feed_image": "feedImage",
            "goal_date": "stringGoalDate",
            "like_status": "isLiked",
            "inspire_status": "isInspired"]
        
        let mapping = RKObjectMapping(for: self)
        mapping?.addAttributeMappings(from: mappingDictionary)
        return mapping!
    }
    
    class func showAlert(_ error: NSError?) {
        
        // no need to handle errors if we dont have any :)
        if error == nil { return }
        
        // get the tile and message for the alert
        if let userInfo = error?.userInfo {
            let title = userInfo["title"] as! String
            let message = userInfo["message"] as! String
            
            // show alert
            UIAlertView(title: &&title, message: &&message, delegate: nil, cancelButtonTitle: &&"cancel").show()
        }
    }

    class func fetchPublicNewsFeeds(_ shouldShowHUD: Bool = true, offset: Int = 0, pageMeta: PageMetaModel, completionHandler: @escaping (_ newsFeeds: [NewsFeed], _ pageMeta: PageMetaModel) -> ()) {
        
        if shouldShowHUD {
            SVProgressHUD.show()
        }
        
        let params = ["offset": "\(offset)", "limit": APIRequest.FetchLimit, "hid": pageMeta.hashId, "rid1": pageMeta.rangeId, "rid2": pageMeta.subRangeId]
        
        NewsFeedResponse.fetchPublicNewsFeeds(params) { (newsFeeds, pageMeta, error) in
            
            if shouldShowHUD {
                SVProgressHUD.dismiss()
            }
            
            // handle errors if any
            NewsFeed.showAlert(error)
            
            DispatchQueue.main.async {
                completionHandler(newsFeeds, pageMeta)
            }
        }
    }
    
    // particular user's news feed :userid
    class func fetchNewsFeeds(_ userId: String, offset: Int = 0, pageMeta: PageMetaModel, completionHandler: @escaping (_ newsFeeds: [NewsFeed],  _ pageMeta: PageMetaModel) -> ()) {
        
        SVProgressHUD.show()
        
        let params = ["offset": "\(offset)", "limit": APIRequest.FetchLimit, "hid": pageMeta.hashId, "rid1": pageMeta.rangeId, "rid2": pageMeta.subRangeId]
        
        FeedsParticularUserResponse.fetchNewsFeedsForParticularUser(userId, params: params) { (newsFeeds, pageMeta, error) in
            
            SVProgressHUD.dismiss()
            
            // handle errors if any
            NewsFeed.showAlert(error)
            
            DispatchQueue.main.async {
                completionHandler(newsFeeds, pageMeta)
            }
        }
    }
    
    func fetchComments(_ shouldShowHUD: Bool = true, offset: Int = 0, pageMeta: PageMetaModel, completionHandler: @escaping (_ newsFeedComments: [NewsFeedComment], _ pageMeta: PageMetaModel) -> ()) {
        
        if shouldShowHUD {
            SVProgressHUD.show()
        }
        
        let params = ["offset": "\(offset)", "limit": APIRequest.FetchLimit, "hid": pageMeta.hashId, "rid1": pageMeta.rangeId, "rid2": pageMeta.subRangeId]
        
        NewsFeedCommentsResponse.fetchNewsFeedComments(id, params: params) { (newsFeedComments, pageMeta, error) in
            
            if shouldShowHUD {
                SVProgressHUD.dismiss()
            }
            
            // handle errors if any
            NewsFeed.showAlert(error)
            
            completionHandler(newsFeedComments, pageMeta)
        }
    }
    
    class func create(_ text: String = "", image: UIImage? = nil, completionHandler: @escaping (_ newsFeed: NewsFeed?, _ error: NSError?) -> ()) {
        
        SVProgressHUD.show()
        
        // create params to post
        let params = ["data": text.trimmedString(), "feed_type": "feed"]
        
        // create data to post
        var data: Data?
        if let image = image {
            data = UIImageJPEGRepresentation(image, 0.0)
        }
        
        // create news feed
        CreateNewsFeedResponse.create(params, data: data) { (newsFeed, newsFeedComment, error) -> () in
            
            SVProgressHUD.dismiss()
            
            // handle errors if any
            NewsFeed.showAlert(error)

            completionHandler(newsFeed, error)
        }
    }
    
    func comment(_ text: String = "", image: UIImage? = nil, completionHandler: @escaping (_ newsFeedComment: NewsFeedComment?, _ error: NSError?) -> ()) {
        
        SVProgressHUD.show()
        
        // create params to post
        let params = ["data": text.trimmedString(), "feed_type": "feed_comment", "feed_id": id]
        
        // create data to post
        var data: Data?
        if let image = image {
            data = UIImageJPEGRepresentation(image, 0.0)
        }
        
        // create news feed
        CreateNewsFeedResponse.create(params, data: data) { (newsFeed, newsFeedComment, error) -> () in
            
            SVProgressHUD.dismiss()
            
            // handle errors if any
            NewsFeed.showAlert(error)
            
            completionHandler(newsFeedComment, error)
        }
    }
    
    func inspire(_ inspire: Bool, completionHandler: ((_ newsFeed: NewsFeed, _ error: NSError?) -> ())? = nil) {
        // configure params
        let params = ["motivate_type": "inspire", "feed_type": "feed", "motivate_status": inspire ? "yes" : "no"]
        
        MotivateResponse.updateLikeInspire(params, feedId:"\(id)") { (error) -> () in
            
            // update inspire status
            if error == nil {
                self.isInspired = inspire
                self.inspireCount = inspire ? self.inspireCount + 1 : self.inspireCount - 1
            }
            
            completionHandler?(self, error)
        }
    }
    
    func like(_ like: Bool, completionHandler: ((_ newsFeed: NewsFeed, _ error: NSError?) -> ())? = nil) {
        // configure params
        let params = ["motivate_type": "like", "feed_type": "feed", "motivate_status": like ? "yes" : "no"]
        
        MotivateResponse.updateLikeInspire(params, feedId: "\(id)") { (error) -> () in
            
            // update like status
            if error == nil {
                self.isLiked = like
                self.likeCount = like ? self.likeCount + 1 : self.likeCount - 1
            }
            
            completionHandler?(self, error)
        }
    }
}
