//
//  MessageFriendsSectionCell.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/1/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class MessageFriendsSectionCell: UITableViewCell {

    @IBOutlet weak var labelFriendsCount: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    // set friends count
    var friendsCount: String = " " {
        didSet {
            labelFriendsCount.text = friendsCount
        }
    }
}
