//
//  InviteFriendResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 27/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FriendRequestResponseModel: NSObject {
    
    var userId: String?

    class var objectMapping: RKObjectMapping {
        let mapping = RKObjectMapping(for: self)
        mapping?.addAttributeMappings(from: mappingDictionary)
        // give reference to accesstoken mapping        return metaMapping
        return mapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["userId":"userId"])
    }
}


class InviteFriendResponse: NSObject {
    
    var metaModel: MetaModel?
    var friendRequestResponseModel: FriendRequestResponseModel?
    var userId: String?

    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(InviteFriendResponse.metaModelKeyMapping)
        responseMapping?.addPropertyMapping(InviteFriendResponse.friendRequestResponseModel)

        return responseMapping!
    }
    
    // for invite via userId - FYM Friends
    class var userResponseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.sendFriendsRequestUrl1, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    // for the email invite - Contact Friends
    class var userResponseDescriptorForEmailInvite: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.inviteFriendsUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }

    
   // for invite via userId - FYM Friends
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    // for invite via userId - FYM Friends
    fileprivate class var friendRequestResponseModel : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathFriendRequest, toKeyPath: "friendRequestResponseModel", with: FriendRequestResponseModel.objectMapping)
    }
    
    class func sendInvitationFriend(_ userId:String,completionHandler: @escaping (_ response:InviteFriendResponse) -> ()) {
        RestKitManager.setToken(true)
        
        let invitationResponse = InviteFriendResponse()
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["user_id":userId]
        }
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path:Constants.ServiceConstants.sendFriendsRequestUrl1, parameters: parameterDictionary, constructingBodyWith: { (formData) in
            
        })
//        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path:Constants.ServiceConstants.sendFriendsRequestUrl1, parameters: parameterDictionary, constructingBodyWith: { (formData) in
//            
//        })
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let inviteFriendResponse = mappingResult?.firstObject as! InviteFriendResponse
            //print("respone code :\(inviteFriendResponse.metaModel?.responseCode)")
            //print("respone status :\(inviteFriendResponse.metaModel?.responseStatus)")
            
            //print("fired completion handler for the user***")
            completionHandler(inviteFriendResponse)
            
            
        }) { (operation, error) in
            
            //print("failed to load send invitation with error \(error)")
        }

//        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) -> Void in
//            
//            let inviteFriendResponse = mappingResult.firstObject as! InviteFriendResponse
//            //print("respone code :\(inviteFriendResponse.metaModel?.responseCode)")
//            //print("respone status :\(inviteFriendResponse.metaModel?.responseStatus)")
//            
//            //print("fired completion handler for the user***")
//            completionHandler(response: inviteFriendResponse)
//            
//            
//            }) { (operation, error) in
//                
//                //print("failed to load send invitation with error \(error)")
//        })
        
        RestKitManager.shared().enqueue(operation)
    }
    
    // for the email invite - Contact Friends
    class func sendInvitationFriendViaEmail(_ emailAddress:String,completionHandler: @escaping (_ response:InviteFriendResponse) -> ()) {
        RestKitManager.setToken(true)
        
        let invitationResponse = InviteFriendResponse()
        invitationResponse.userId = AppConfiguration.sharedAppConfiguration.userDetails!.userId
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["email": emailAddress]
        }
        
        //print("invitation parameters are \(parameterDictionary)")
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: invitationResponse, method: .POST, path:nil, parameters: parameterDictionary, constructingBodyWith: { (formData) in
            
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult)in
            
            let inviteFriendResponse = mappingResult?.firstObject as! InviteFriendResponse
            //print("respone code :\(inviteFriendResponse.metaModel?.responseCode)")
            //print("respone status :\(inviteFriendResponse.metaModel?.responseStatus)")
            
            completionHandler(inviteFriendResponse)
            
            
            }) { (operation, error) in
                
                //print("failed to load send invitation with error \(error)")
        }
        
        RestKitManager.shared().enqueue(operation)
    }

    
}
