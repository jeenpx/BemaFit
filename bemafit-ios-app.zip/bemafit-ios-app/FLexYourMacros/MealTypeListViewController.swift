//
//  MealTypeListViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 13/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class MealTypeCell: UITableViewCell {
    
    var mealType = MealType(name: "") {
        didSet {
            configureView()
        }
    }
    
    var shouldDisableUserCreatedMealTypes = false {
        didSet {
            configureView()
        }
    }
    
    var isMealTypeSelected = false {
        didSet {
            accessoryType = isMealTypeSelected ? .checkmark : .none
        }
    }
    
    func configureView() {
        textLabel?.text = mealType.name
        
        // determine whether to disable
        let shouldDisable = shouldDisableUserCreatedMealTypes && !mealType.isDefault
        
        isUserInteractionEnabled = !shouldDisable
        textLabel?.isEnabled = !shouldDisable
        textLabel?.backgroundColor = UIColor.clear
        contentView.backgroundColor = shouldDisable ? UIColor.color(242, green: 242, blue: 242) : UIColor.white
        
    }
}

enum MealTypeListInitiator {
    case searchFood
    case createFromServingSize
    case logByMacros
    case foodRecommendations
    case sendDetails
    case splitFood
    
    static var initiators: [MealTypeListInitiator] {
        return [.searchFood, .createFromServingSize, .logByMacros, .foodRecommendations, .sendDetails, .splitFood]
    }
}

class MealTypeListViewController: UITableViewController, UIAlertViewDelegate {
    
    // meal type selected from view log
    var mealType: MealType?
    
    var logDate = Date()
    
    // currently selected meal type
    var selectedMealType: MealType?
    
    var food = Food()
    
    var isDailyMealPlan = false
    
    var dailyMealType = DailyMealType(dailyMealTypeName: "")

    // selected users to send details
    var selectedUsers = [User]()
    
    // selected users to split food
    var splittedUsers = [User: Int]()
    
    var arrayMealTypes = [MealType]() {
        didSet {
            
            // set the default selected meal type
            selectedMealType = arrayMealTypes[0]
            
            // reload table
            tableView?.reloadData()
        }
    }
    
    // meal type initiator defaults to search food
    var mealTypeListInitiator: MealTypeListInitiator = .searchFood
    
    var isFoodRecommendations: Bool {
        return mealTypeListInitiator == MealTypeListInitiator.foodRecommendations
    }
    
    var shouldCreateFood = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // set default title
        title = &&"log_food"
        
        // remove log button for food recommendation screen
        if isFoodRecommendations {
            navigationItem.rightBarButtonItem = nil
            
            // set title
            title = &&"food_recommendations"
        }
        else if mealTypeListInitiator == .sendDetails {
            navigationItem.rightBarButtonItem?.title = &&"send"
        }
        else if mealTypeListInitiator == .splitFood {
            navigationItem.rightBarButtonItem?.title = &&"split_food"
        }
        
        // fetch meal types
        MealType.fetchMealTypeList { (mealTypes) in
            self.arrayMealTypes = mealTypes
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayMealTypes.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.CellIdentifiers.MealTypeCell, for: indexPath) as! MealTypeCell
        cell.mealType = arrayMealTypes[indexPath.row]
        cell.shouldDisableUserCreatedMealTypes = mealTypeListInitiator == .splitFood || mealTypeListInitiator == .sendDetails || isFoodRecommendations
        cell.isMealTypeSelected = !isFoodRecommendations && arrayMealTypes[indexPath.row] == selectedMealType
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if isFoodRecommendations {
            mealType = arrayMealTypes[indexPath.row]
            performSegue(withIdentifier: Storyboard.Segues.FoodListSegue, sender:nil)
        }
        else {
            selectedMealType = arrayMealTypes[indexPath.row]
            tableView.reloadData()
        }
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.setSeparatorInsetZero()
    }
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        if alertView.buttonTitle(at: buttonIndex) == &&"send_only" {
            let userGuid = AppConfiguration.sharedAppConfiguration.userDetails!.userId!
            let selectedUserIds = self.selectedUsers.map { $0.userId }
            
            self.food.sendDetails(mealType: self.selectedMealType!.id, mealDate: self.logDate, userGuid: userGuid, users: selectedUserIds, completionHandler: { (error) in
                
                if error != nil {
                    //print("failed to send food details")
                }
                else {
                    //print("successfully send food details")
                }
                
                self.loadViewLog()
            })
        }
        else if alertView.buttonTitle(at: buttonIndex) == &&"log_&_send" {
            let userGuid = AppConfiguration.sharedAppConfiguration.userDetails!.userId!
            let selectedUserIds = self.selectedUsers.map { $0.userId }
            
            self.food.sendDetails(true, mealType: self.selectedMealType!.id, mealDate: self.logDate, userGuid: userGuid, users: selectedUserIds, completionHandler: { (error) in
                
                if error != nil {
                    //print("failed to log and send food details")
                }
                else {
                    //print("successfully logged and send food details")
                }
                
                self.loadViewLog()
            })
        }
        //        else if alertView.buttonTitleAtIndex(buttonIndex) == &&"ok" {
        //            self.performSegueWithIdentifier(self.isFromDashboard ? Storyboard.Segues.UnwindDashboardSegue : Storyboard.Segues.UnwindViewLogViewSegue, sender: nil)
        //        }
    }
    
    struct Storyboard {
        struct CellIdentifiers {
            static let MealTypeCell = "kMealTypeCell"
        }
        struct Segues {
            static let FoodListSegue = "kFoodListSegue"
            static let LogMacroSegue = "kSegueLogMacro"
            static let UnwindDashboardSegue = "kUnwindDashboardSegue"
            static let UnwindViewLogViewSegue = "kUnwindViewLogViewSegue"
        }
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == Storyboard.Segues.FoodListSegue {
            let foodListViewController = segue.destination as! FoodListViewController
            foodListViewController.logDate = logDate
            foodListViewController.foodListMode = FoodListMode.foodRecommendation
            foodListViewController.foodRecommendationMealType = mealType
            foodListViewController.isDailyMealPlan = isDailyMealPlan
            foodListViewController.mealType = mealType
        }
    }
    
    func sendFood() {
        // show alert controller if possible else show alert view
        
        if #available(iOS 8.0, *) {
            let alert = UIAlertController(title: &&"confirmation", message: &&"alert_message_log_food", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: &&"send_only", style: .default) { _ in
                let userGuid = AppConfiguration.sharedAppConfiguration.userDetails!.userId!
                let selectedUserIds = self.selectedUsers.map { $0.userId }
                
                self.food.sendDetails(mealType: self.selectedMealType!.id, mealDate: self.logDate, userGuid: userGuid, users: selectedUserIds, completionHandler: { (error) in
                    
                    if error != nil {
                        //print("failed to send food details")
                    }
                    else {
                        //print("successfully send food details")
                    }
                    
                    self.loadViewLog()
                })
                })
            
            alert.addAction(UIAlertAction(title: &&"log_&_send", style: .default) { _ in
                let userGuid = AppConfiguration.sharedAppConfiguration.userDetails!.userId!
                let selectedUserIds = self.selectedUsers.map { $0.userId }
                
                self.food.sendDetails(true, mealType: self.selectedMealType!.id, mealDate: self.logDate, userGuid: userGuid, users: selectedUserIds, completionHandler: { (error) in
                    
                    if error != nil {
                        //print("failed to log and send food details")
                    }
                    else {
                        //print("successfully logged and send food details")
                    }
                    
                    self.loadViewLog()
                })
                })
            
            present(alert, animated: true, completion: nil)
            
            
        } else {
            // Fallback on earlier versions
            let alert = UIAlertView(title: &&"confirmation", message: &&"alert_message_log_food", delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"send_only", &&"log_&_send")
            alert.show()
        }
        
    }
    
    func splitFood() {
        
        food.split(selectedMealType!.id, mealDate: logDate, userGuid: AppConfiguration.sharedAppConfiguration.userDetails!.userId!, splittedUsers: splittedUsers) { (error) -> () in
            if error != nil {
                //print("failed to split food")
            }
            else {
                //print("successfully split food")
            }
            
            self.loadViewLog()
        }
    }
    
    func logFood() {
        
        if shouldCreateFood {
            
            // create food in case of create meal
            food.createFood { (food, meta) in
                
                // meal already exists
                if meta.responseCode != 200 {
                    self.showAlert(&&"notice", message: &&"meal_already_exist")
                    return
                }
                
                self.shouldCreateFood = false
                
                // replace the local food with the created one
                self.food = food
                
                // log food
                self.logFood()
            }
            return
        }
        
        // log food
        food.logFood(selectedMealType!.id, mealDate: logDate, userGuid: AppConfiguration.sharedAppConfiguration.userDetails!.userId!) { (error) -> () in
            
            // navigate out
            self.loadViewLog()
            
            //            // show alert controller if possible else show alert view
            //            if NSClassFromString(Class.UIAlertController) != nil {
            //
            //                let alert = UIAlertController(title: &&"alert_title_log", message: &&"alert_message_log", preferredStyle: .Alert)
            //
            //                alert.addAction(UIAlertAction(title: &&"ok", style: UIAlertActionStyle.Cancel, handler: { (action) in
            //                    self.performSegueWithIdentifier(self.isFromDashboard ? Storyboard.Segues.UnwindDashboardSegue : Storyboard.Segues.UnwindViewLogViewSegue, sender: nil)
            //                }))
            //
            //                self.presentViewController(alert, animated: true) {}
            //            }
            //            else {
            //
            //                UIAlertView(title: &&"alert_title_log", message: &&"alert_message_log", delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok").show()
            //            }
        }
    }
    
    @IBAction func barButtonActionLog(_ sender: UIBarButtonItem) {
        
        // return if the meal types haven't loaded yet
        if selectedMealType == nil { return }
        
        // send food
        if mealTypeListInitiator == .sendDetails {
            sendFood()
        }
        else if mealTypeListInitiator == .splitFood {
            splitFood()
        }
        else {
            logFood()
        }
    }
    
    func showAlert(_ title: String, message: String) {
        UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok").show()
    }
    
}
