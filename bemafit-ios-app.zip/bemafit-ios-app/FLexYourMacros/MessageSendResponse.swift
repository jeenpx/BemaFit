//
//  MessageSendResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/6/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class MessageSendResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    var message: MessageItemModel?
    
   // route instance variables
    var user_id: String?
    var friend_id: String?
    
    // message response mapping
    class var messageSendResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(MessageSendResponse.metaModelKeyMapping)
        
        // give reference to message item model
        responseMapping?.addPropertyMapping(MessageSendResponse.messageSendKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    fileprivate class var messageSendKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMessage, toKeyPath: "message", with: MessageItemModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: messageSendResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.kUrlPostMessage, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    
    class func postMessage(_ message: String, andFriendId friendId: String, completionHandler: @escaping (_ sendMessage: MessageItemModel, _ meta: MetaModel) -> ()) {
        
        SVProgressHUD.show()
        
        // set access token
        RestKitManager.setToken(true)
        
        // input parameter
        let param: Dictionary = ["message": message]
        
        // instance of message model class
        let messageSendResponse = MessageSendResponse()
        
        // set user id
        messageSendResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId
        
        // set friend id
        messageSendResponse.friend_id = friendId
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: messageSendResponse, method: .POST, path: nil, parameters: param, constructingBodyWith: { (formData) in
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let messageSendResponse = mappingResult?.firstObject as! MessageSendResponse
            //print("respone code :\(messageSendResponse.meta?.responseCode)")
            //print("respone status :\(messageSendResponse.meta?.responseStatus)")
            
            SVProgressHUD.dismiss()
            
            completionHandler(messageSendResponse.message ?? MessageItemModel(), messageSendResponse.meta ?? MetaModel())
            
//                if let postMessage: MessageItemModel = messageSendResponse.message {
//                    completionHandler(sendMessage: postMessage)
//                }
            
            }) { (operation, error) in
                
                SVProgressHUD.dismiss()
                
                //print("failed to load postMessage with error \(error)")
        }
        
        RestKitManager.shared().enqueue(operation)
    }
    
    
    
}

