//
//  FriendModel.swift
//  FlexYourMacros
//
//  Created by DBG on 30/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FriendModel: NSObject {
    
    var user_id: String?
    var userName: String?
    var firstName: String?
    var lastName: String?
    var following: String?
    var followers: String?
    var profilePhoto: String?
    var type: String?
    
    class var objectMapping: RKObjectMapping {
        let friendMapping = RKObjectMapping(for: FriendModel.self)
        friendMapping?.addAttributeMappings(from: mappingDictionary)
        return friendMapping!
    }
 
    class var mappingDictionary: [String : String] {
        return(["type":"type","user_id":"user_id", "username":"userName", "first_name":"firstName", "last_name":"lastName", "following":"following","followers":"followers","profile_photo":"profilePhoto"])
    }
    
    
}
