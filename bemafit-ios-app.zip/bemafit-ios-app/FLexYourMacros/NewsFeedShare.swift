//
//  NewsFeedShare.swift
//  FlexYourMacros
//
//  Created by Aromal Sasidharan on 7/13/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
typealias FacebookShareContentCallback = () -> (FacebookShareModel)

class NewsFeedShare: NSObject, UIActionSheetDelegate {

    var currentViewContoller:UIViewController? = nil
    var facebookShareContentCallback : FacebookShareContentCallback?
    
    class var sharedManager: NewsFeedShare {
        struct Singleton {
            static let instance = NewsFeedShare()
        }
        return Singleton.instance
    }
    
    
    func showActionSheet(_ showFacebook: Bool, fromViewController controller: UIViewController, facebookShareContentCallback:@escaping FacebookShareContentCallback)
    {
        self.facebookShareContentCallback = facebookShareContentCallback
        currentViewContoller = controller
        var shareButtons:[String] = []
        if(showFacebook)
        {
            shareButtons.append("Facebook")
        }
        
         let actionSheet = UIActionSheet(title: nil, delegate: nil, cancelButtonTitle: &&"cancel", destructiveButtonTitle: nil, otherButtonTitles: "Facebook")
        
        actionSheet.delegate = self
        actionSheet.show(in: controller.view);
    }
    func actionSheet(_ actionSheet: UIActionSheet, clickedButtonAt buttonIndex: Int) {
        
        switch actionSheet.buttonTitle(at: buttonIndex)! {
            
        case "Facebook":
            
            FacebookManager.showShareDialog(withShareModel: currentViewContoller!, andModel: self.facebookShareContentCallback!(), andCallback: { (status, results, error) -> Void in
                if error != nil {
                    //print(error)
                }
                else {
                    //print("success")
                    
                }
            })
        default :
            break;
        }
    }
}
