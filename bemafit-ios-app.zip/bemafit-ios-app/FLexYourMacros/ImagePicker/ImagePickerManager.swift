//
//  ImagePickerManager.swift
//  ImagePicker
//
//  Created by Deepu S Nath on 10/03/15.
//  Copyright (c) 2015 DBG. All rights reserved.
//

import Foundation
import UIKit
import AssetsLibrary
import AVFoundation

typealias ImagePickerManagerCallback = (_ image: UIImage, _ source: UIImagePickerControllerSourceType) -> ()

class ImagePickerManager: NSObject, UIActionSheetDelegate, UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    // singleton manager
    class var sharedManager :ImagePickerManager {
        struct Singleton {
            static let instance = ImagePickerManager()
        }
        return Singleton.instance
    }
    
    // the view controller that presents the Image picker
    fileprivate var parentViewController: UIViewController?
    
    // completion handler
    fileprivate var completionHandler: ImagePickerManagerCallback?
    
    // action sheet for Image Picker
    fileprivate let actionSheet = UIActionSheet(title: nil, delegate: nil, cancelButtonTitle: &&"cancel", destructiveButtonTitle: nil, otherButtonTitles: &&"take_photo", &&"choose_existing")
    
   
    func presentImagePicker(_ viewController: UIViewController, completionHandler: @escaping ImagePickerManagerCallback) -> () {
        
        //check whether both camera and photolibrary are not accesible
        let mediaStatus = AVCaptureDevice.authorizationStatus(forMediaType: AVMediaTypeVideo)
        let photoLibstatus = ALAssetsLibrary.authorizationStatus()
        
        if !(mediaStatus == .notDetermined || mediaStatus == .authorized || photoLibstatus == .notDetermined || photoLibstatus == .authorized) {
            
            UIAlertView(title: &&"access_denied_title", message: "Please enable gallery or camera permissions", delegate: nil, cancelButtonTitle: &&"cancel").show()
            return
        }
        
        // save the completion handler
        self.completionHandler = completionHandler
        
        // save the parent view controller
        parentViewController = viewController
        
        // present the action sheet
        actionSheet.delegate = self
        actionSheet.show(in: (parentViewController?.view)!)
    }
    
    func actionSheet(_ actionSheet: UIActionSheet, clickedButtonAt buttonIndex: Int) {
        
        // get the source type for image picker controller
        var sourceType: UIImagePickerControllerSourceType
        switch buttonIndex {
        case 2: sourceType = .photoLibrary
        case 1: sourceType = .camera
        default: return
        }
        
        
        // check for permissions
        // splitting up because the status classes doesnt match
        if sourceType == .photoLibrary {
            let status = ALAssetsLibrary.authorizationStatus()
            if !(status == .notDetermined || status == .authorized) {
                
                UIAlertView(title: &&"access_denied_title", message: &&"access_denied_message_photo", delegate: nil, cancelButtonTitle: &&"cancel").show()

                // go out
                return
            }
        }
        else if sourceType == .camera {
            let status = AVCaptureDevice.authorizationStatus(forMediaType: AVMediaTypeVideo)
            if !(status == .notDetermined || status == .authorized) {
                
                UIAlertView(title: &&"access_denied_title", message: &&"access_denied_message_camera", delegate: nil, cancelButtonTitle: &&"cancel").show()
                
                // go out
                return
            }
        }
        
        // configure image picker controller
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.allowsEditing = true
        imagePickerController.sourceType = sourceType
        
        // present the image picker controller
        parentViewController?.present(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        // fire completion handler
        completionHandler?(info[UIImagePickerControllerEditedImage] as! UIImage, picker.sourceType)
        
        // dismiss the image picker
        dismissImagePicker()
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismissImagePicker()
    }
    
    func dismissImagePicker() {
        parentViewController?.dismiss(animated: true, completion: nil)
    }
    
}


