//
//  CustomCellHeader.swift
//  FlexYourMacros
//
//  Created by DBG on 25/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FriendSectionHeader: UITableViewCell {
    
    @IBOutlet weak var labelFriendsCount: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    // set friends count
    var friendsCount: String = " " {
        didSet {
            labelFriendsCount.text = friendsCount
        }
    }
}
