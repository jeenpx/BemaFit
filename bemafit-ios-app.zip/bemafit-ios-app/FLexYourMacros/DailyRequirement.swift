//
//  DailyRequirement.swift
//  FlexYourMacros
//
//  Created by mini on 14/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import CoreData
@objc(DailyRequirement)

class DailyRequirement: NSManagedObject {

    @NSManaged var protein_total: String
    @NSManaged var fat_total: String
    @NSManaged var carbs_total: String
    @NSManaged var fiber_total: String
    @NSManaged var calories_total: String
    @NSManaged var progressDailyType: Progress

    class var entityMapping : RKEntityMapping {
        
        let progressLogMapping: RKEntityMapping = RKEntityMapping(forEntityForName: Constants.Tables.dailyRequirement, in: RestKitManager.shared().managedObjectStore)
        progressLogMapping .addAttributeMappings(from: progressMappingDictionary)
        
        return progressLogMapping
    }
    
    fileprivate class var progressMappingDictionary: [String : String] {
        
        return(["protein_total":"protein_total", "fat_total":"fat_total", "carbs_total":"carbs_total", "fiber_total":"fiber_total", "calories_total":"calories_total"])
    }
    
    class func fetchDailyMacroRequirements(_ progressType: String, completionHandler:(_ dailyRequirement: [Any])->()) {
        
        var error: NSError?
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>()
        let entity = NSEntityDescription.entity(forEntityName: Constants.Tables.dailyRequirement, in: RKObjectManager.shared().managedObjectStore.persistentStoreManagedObjectContext)
        fetchRequest.returnsObjectsAsFaults = false
        fetchRequest.entity = entity
//        fetchRequest.fetchLimit = 1
        
        // set the predicate
        let progressPredicate = NSPredicate(format: "SUBQUERY(progressDailyType, $x, $x.type = %@).@count == progressDailyType.@count",progressType)
        fetchRequest.predicate = progressPredicate
        
        let fetchedObjects: [Any]?
        do {
            fetchedObjects = try RKObjectManager.shared().managedObjectStore.persistentStoreManagedObjectContext .fetch(fetchRequest)
        } catch var error1 as NSError {
            error = error1
            fetchedObjects = nil
        }
        completionHandler(fetchedObjects!)
    }

}
