//
//  SetExtensions.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 5/25/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

extension Set {
    
    var allObjects: [Element] {
        return Array(self)
    }
    
}