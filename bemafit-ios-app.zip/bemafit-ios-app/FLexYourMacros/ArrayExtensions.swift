//
//  ArrayExtensions.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 24/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

extension Array {
    mutating func remove <T: Equatable> (_ object: T) -> Bool {
        for (index, objectToCompare) in self.enumerated() {
            if let objectToCompare = objectToCompare as? T {
                if object == objectToCompare {
                    self.remove(at: index)
                    return true
                }
            }
        }
        return false
    }
    
    mutating func contains <T: Equatable> (_ object: T) -> Bool {
        for (index, objectToCompare) in self.enumerated() {
            if let objectToCompare = objectToCompare as? T {
                if object == objectToCompare {
                    return true
                }
            }
        }
        return false
    }
}

extension NSMutableArray {
    
    func addUtilityButtonWithBackgroundColor(_ backGroundColor: UIColor, andTitleColor titleColor: UIColor, andTitle title: String) {
        // add  an utility button with background and title color
        
        let button = UIButton(type: .custom)
        button.backgroundColor = backGroundColor
        button.setTitle(title, for: UIControlState())
        button.setTitleColor(titleColor, for: UIControlState())
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        add(button)
    }
    
    
    func addUtilityButtonWithCustomImage(_ normalImage: UIImage, andHiglightedImage higlightedImage: UIImage, andSelectedImage selectedImage: UIImage, andBackGroundColor backGroundColor: UIColor = UIColor.defaultGrayColor(), andTitleColor titleColor: UIColor = UIColor.white, andTitle title: String = "") {
        // add  an utility button with background and title color
        
        let button = UIButton(type: .custom)
        button.backgroundColor = backGroundColor
        button.setImage(normalImage, for: UIControlState())
        button.setImage(higlightedImage, for: UIControlState.highlighted)
        button.setImage(selectedImage, for: UIControlState.selected)
        button.setTitle(title, for: UIControlState())
        button.setTitleColor(titleColor, for: UIControlState())
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        add(button)
    }
}
