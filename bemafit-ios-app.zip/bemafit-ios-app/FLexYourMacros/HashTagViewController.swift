//
//  HashTagViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 06/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class HashTagViewController: UITableViewController, NewsFeedCellDelegate, UITableViewDragLoadDelegate, UIAlertViewDelegate {
    
    struct StoryBoard {
        struct CellIdentifiers {
            static let NewsFeedCellIdentifier = "kNewsFeedCell"
        }
        struct Segues {
            static let HashTagToProfileSegue = "khasTagToProfileSegue"
            static let HashTagCommentsSegue = "kHashTagCommentsSegue"
            static let HashTagSegue = "kHashTagSegue"
        }
        struct ViewControllerId {
            static let HashTagViewController = "kHashTagViewController"
        }
    }
    
    // limit value for messages
    var limitValue: Int = 10
    
    // Offset value for messages
    var offsetValue: Int = 0
    
    // store page meta
    var pageMetaModel = PageMetaModel()
    
    var hashTag: String = "" {
        didSet {
            // configure view with the hashtag
            configureView()
        }
    }
    
    var newsFeeds = [NewsFeed]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        pageMetaModel = PageMetaModel()
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            
            // clear news feeds
            self.newsFeeds.removeAll()
            
            tableView.reloadData()
            
            // show empty record message
            tableView.showEmptyTableViewMessage(&&"empty_tableview_message")
            return
        }
        
        // set value 0
        offsetValue = 0
        
        // clear news feeds
        self.newsFeeds.removeAll()
        
        // list feeds
        listFeeds(offsetValue, andLimit: limitValue, doLoadMore: false, pageMetaModel: pageMetaModel)
    }
    
    func configureView() {
        
        // set view title
        navigationItem.title = "#" + hashTag
        
        // set tableview cell classes
        tableView.register(UINib(nibName: "NewsFeedCell", bundle: nil), forCellReuseIdentifier: StoryBoard.CellIdentifiers.NewsFeedCellIdentifier)
        
        // set estimated row height
        // XXX setting the lowest height now, recheck
        tableView.estimatedRowHeight = 230.0
        tableView.rowHeight = UITableViewAutomaticDimension
        
        // set delegate for pull to refresh and load more
        tableView.setDragDelegate(self, refreshDatePermanentKey: "kHashTag")
        
        // hide pull to refresh
        tableView.showRefreshView = false
        
        // show load more
        tableView.showLoadMoreView = true
        
        // tableview footer release text
        tableView.footerReleaseText = NSLocalizedString("release_to_load_more_status", comment: "")
        
        // tableview footer pull up text
        tableView.footerPullUpText = NSLocalizedString("pull_down_to_load_more_status", comment: "")
        
        //tableview footer loading text
        tableView.footerLoadingText = NSLocalizedString("loading_status", comment: "")
        
        
        // XXX fetch newsfeeds based on the hashtag and populate the tableview
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return newsFeeds.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat((newsFeeds[indexPath.row] as NewsFeed).contentHeight)
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCell(withIdentifier: StoryBoard.CellIdentifiers.NewsFeedCellIdentifier) as! NewsFeedCell
        
        // configure cell
        cell.newsFeed = newsFeeds[indexPath.row]
        cell.newsFeedCellDelegate = self
        cell.shareButton.isHidden = true
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        (cell as? NewsFeedCell)?.newsFeed = newsFeeds[indexPath.row]
        
        cell.layoutIfNeeded()
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didSelectHashTag hashTag: String) {
        
        if self.hashTag == hashTag {
            showAlert(&&"notice", message: hashTag + " " + &&"already_shown_hashtag_message")
            return
        }
        // navigate to subhash screens
        let hashTagViewController = storyboard?.instantiateViewController(withIdentifier: StoryBoard.ViewControllerId.HashTagViewController) as! HashTagViewController
        hashTagViewController.hashTag = hashTag
        navigationController?.pushViewController(hashTagViewController, animated: true)
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didSelectUser userId: String) {
        //print(userId)
        performSegue(withIdentifier: StoryBoard.Segues.HashTagToProfileSegue, sender: userId)
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didSelectBusinessDirectory businessDirectoryId: String) {
        DirectoryDetailViewController.loadDirectoryDetail(businessDirectoryId, fromViewcontroller: self)
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didLikeNewsFeed like: Bool) {
        //
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didInspireNewsFeed inspire: Bool) {
        //
    }
    
    func newsFeedCell(_ newsFeedCell: NewsFeedCell, didDeleteNewsFeed delete: Bool) {
        if delete {
            let cellIndexPath = tableView.indexPath(for: newsFeedCell)
            let feedId = newsFeeds[cellIndexPath!.row].id
            
            let reachability = appDelegate!.internetReachable
            if !reachability {
                // no internet
                
                // alert
                AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                return
            }
            
            // delete the feed
            
            
            UIAlertView.show(withTitle: &&"delete_confirmation_title", message: &&"delete_confirmation_message", cancelButtonTitle: &&"ok_button_title", otherButtonTitles: [&&"cancel_button_title"], tap: { (alertview : UIAlertView, buttonIndex : Int) in
                
                
                if buttonIndex == alertview.cancelButtonIndex{
                    NewsFeedDeleteResponse.deleteNewsFeed(feedId, completionHandler: { (responseStatus) -> () in
                        if responseStatus == "OK" {
                            let feed = self.newsFeeds.filter({$0.id == feedId})
                            
                            // remove the feed
                            self.newsFeeds.remove(feed[0])
                            
                            // reload tableview
                            self.tableView.reloadData()
                        }
                    })
                    
                    
                }
            })
            
        }
    }
    
    func buttonActionComments(_ newsFeed: NewsFeed) {
        performSegue(withIdentifier: StoryBoard.Segues.HashTagCommentsSegue, sender: newsFeed)
    }
    
    func dragTableDidTriggerLoadMore(_ tableView: UITableView!) {
        // called when the load more is selected
        
        if !pageMetaModel.isValid {
            
            // cancel load more
            cancelLoadMoreWithInterval()
            return
        }
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            
            // cancel load more
            cancelLoadMoreWithInterval()
            return
        }
        
        if newsFeeds.count > 0 {
            // save messages count to offset
            
            offsetValue = newsFeeds.count
        }
        else {
            
            // set offset to zero
            offsetValue = 0
        }
        
        listFeeds(offsetValue, andLimit: limitValue, doLoadMore: true, pageMetaModel: pageMetaModel)
    }
    
    func cancelLoadMoreWithInterval() {
        
        // finish the load more
        Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(HashTagViewController.finishLoadMore), userInfo: nil, repeats: false)
    }
    
    
    func dragTableLoadMoreCanceled(_ tableView: UITableView!) {
        // called when the load more is cancelled
        
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(HashTagViewController.finishLoadMore), object: nil)
    }
    
    func listFeeds(_ offset: Int, andLimit limit: Int, doLoadMore loadMore: Bool, pageMetaModel pageMeta: PageMetaModel) {
        // list news feeds based on offset, limit and load more status
        
        // extra security when passing hashtags
        let safeHashTag = hashTag.replacingOccurrences(of: "#", with: "")
        
        // get news feeds
        HashTagGetResponse.getHashTagFeedPosts(offset, andLimit: limit, hashTag: safeHashTag, pageMetaModel: pageMeta) { (newsFeeds, pageMeta) -> () in
            
            self.pageMetaModel = pageMeta
            if let feeds = newsFeeds as [NewsFeed]? {
                if self.newsFeeds.isEmpty == false {
                    
                    // append new values to the existing array
                    for feed in feeds {
                        self.newsFeeds.append(feed)
                    }
                    
                } else {
                    
                    // empty array
                    self.newsFeeds = feeds
                }
                
                if loadMore {
                    
                    // finish the load more
                    self.tableView.finishLoadMore()
                }
                // reload tableview
                self.tableView.reloadData()
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // navigate to profile
        if segue.identifier == StoryBoard.Segues.HashTagToProfileSegue {
            let profileViewController = segue.destination as! ProfileViewController
            profileViewController.userId = sender as? String ?? ""
        }
        else if segue.identifier == StoryBoard.Segues.HashTagCommentsSegue {
            let newsFeedCommentsViewController = segue.destination as! NewsFeedCommentsViewController
            newsFeedCommentsViewController.newsFeed = sender as! NewsFeed
        }
    }
    
    func showAlert(_ title: String, message: String) {
        
        if #available(iOS 8.0, *) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: &&"ok", style: .cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        } else {
            // Fallback on earlier versions
            UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok").show()
        }
    }
    
    func buttonShare(_ shareContent: FacebookShareModel) {
        
    }
    
    func finishLoadMore() {
        // to stop the load more and populate the tableview with new items
        
        tableView.finishLoadMore()
        tableView.reloadData()
    }
}
