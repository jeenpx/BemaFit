//
//  UnfriendResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 20/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UnfriendResponse: NSObject {
    
        var metaModel: MetaModel?
        var userId: String?
        var friendId: String?
    
    class var unFriendResponseMapping: RKObjectMapping {
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(UnfriendResponse.metaModelKeyMapping)
        
        return responseMapping!
    }
    
    class var userResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: unFriendResponseMapping, method: .DELETE, pathPattern: Constants.ServiceConstants.UnFriendUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
        
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    class func deleteFriendship(_ friendId:String , completionHandler: @escaping (_ response:UnfriendResponse) -> ()) {
        
        RestKitManager.setToken(true)
        let unfriendResponse = UnfriendResponse()
        
        // userID
        unfriendResponse.userId = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
        
        // friendID
        unfriendResponse.friendId = friendId        
        
        RestKitManager.shared().delete(unfriendResponse, path:nil, parameters: nil, success: { (operation, mappingResult) in
            
            let response = mappingResult?.firstObject as! UnfriendResponse
            //print("respone code :\(response.metaModel?.responseCode)")
            //print("respone status :\(response.metaModel?.responseStatus)")
            
            completionHandler(response)
            
            
            }) { (operation, error) in
                
                //print("failed to load masterdata with error \(error)")
        }

        
    }
    
    
}
