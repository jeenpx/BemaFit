//
//  FacebookConnectResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 25/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FacebookConnectResponse: NSObject {
    
    var metaModel: MetaModel?
    
    class var facebookConnectMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(FacebookConnectResponse.metaModelKeyMapping)
        
        return responseMapping!
    }
    
    class var facebookConnectDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: facebookConnectMapping, method: .POST, pathPattern: Constants.ServiceConstants.facebookConnectUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    
    class func connectwithfb(_ params:[String:String],completionHandler: @escaping (_ response:FacebookConnectResponse) -> ()) {
        
        RestKitManager.setToken(true)
        
        var parameterDictionary = params
        
        
        let request: NSMutableURLRequest = RestKitManager.shared().multipartFormRequest(with: nil, method: .POST, path: Constants.ServiceConstants.facebookConnectUrl, parameters: parameterDictionary, constructingBodyWith: { (formData) in
            
        })
        
        
//        let userDefaults = NSUserDefaults.standardUserDefaults()
//        
//        let deviceAccessToken = userDefaults.objectForKey("token") as? String ?? ""
//        
//        RKObjectManager.sharedManager().HTTPClient.setDefaultHeader("Device-Token", value: deviceAccessToken)

        let operation: RKObjectRequestOperation = RestKitManager.shared().objectRequestOperation(with: request as URLRequest!, success: { (operation, mappingResult) in
            
            let userfbResponse = mappingResult?.firstObject as! FacebookConnectResponse
            //print("respone code ffff:\(userfbResponse.metaModel?.responseCode)")
            //print("respone status :\(userfbResponse.metaModel?.responseStatus)")
            
                // success password changed
                completionHandler(userfbResponse)
                
           
            }) { (operation, error) in
                
                //print("failed  error \(error)")
        }
        
        RestKitManager.shared().enqueue(operation)
    }
    
    
    
    
    
}
