//
//  NewsFeedDeleteResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 12/3/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class NewsFeedDeleteResponse: NSObject {

    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var userId: String?
    var feedId: String?
    
    // message delete response mapping
    class var newsFeedDeleteResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(NewsFeedDeleteResponse.metaModelKeyMapping)
        
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: newsFeedDeleteResponseMapping, method: .DELETE, pathPattern: Constants.ServiceConstants.kNewsFeedDeleteUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func deleteNewsFeed(_ newsFeedId: String, completionHandler: @escaping (_ responseStatus: String) -> ()) {
        // delete the news feed comment
        
        // set access token
        RestKitManager.setToken(true)
        
        let newsFeedDeleteResponse = NewsFeedDeleteResponse()
        newsFeedDeleteResponse.userId = AppConfiguration.sharedAppConfiguration.userDetails?.userId
        newsFeedDeleteResponse.feedId = newsFeedId
        
        RestKitManager.shared().delete(newsFeedDeleteResponse, path: nil, parameters: nil, success: { (operation, mappingResult) in
            
            //print("Success")
            let deleteResponseObject = mappingResult?.firstObject as! NewsFeedDeleteResponse
            
            if let responseMeta = deleteResponseObject.meta {
                
                // completion handler
                completionHandler(responseMeta.responseStatus!)
            }
            
            }) { (operation, error) in
                //print("error \(error)");
        }
    }
}
