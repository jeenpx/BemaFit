//
//  UnfollowUserResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 15/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UnfollowUserResponse: NSObject {
    var metaModel: MetaModel?
    var user_id: String?
    var friend_id:String?
    
    class var userResponseMapping: RKObjectMapping {
        let responseMapping = RKObjectMapping(for: self)
        responseMapping?.addPropertyMapping(UnfollowUserResponse.metaModelKeyMapping)
        return responseMapping!
    }
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", with: MetaModel.objectMapping)
    }
    
    class var userResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .DELETE, pathPattern: Constants.ServiceConstants.kFollowUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class func unfollowUser(_ friendId:String,completionHandler: @escaping (_ response:UnfollowUserResponse) -> ()) {
        RestKitManager.setToken(true)
        
        let unFollowUserResponse = UnfollowUserResponse()
        unFollowUserResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails!.userId
        unFollowUserResponse.friend_id = friendId
        
        RestKitManager.shared().delete(unFollowUserResponse, path:nil, parameters:nil, success:{(operation, mappingResult) in
        
            let unfollowUserResponse = mappingResult?.firstObject as! UnfollowUserResponse
            completionHandler(unfollowUserResponse)
            
            }) { (operation, error) in
        }
    }
}
