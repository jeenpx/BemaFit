//
//  MessageResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/24/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class MessageResponse:NSObject{
    
     // model instance variables
    var meta: MetaModel?
    var messages: [MessageItemModel]?
    var total_messages: String?
    var unreadCount: String?
    
    // route instance variables
    var user_id: String?
    var friend_id: String?
    
    override init() {
        super.init();
    }
    
    // message response mapping
    class var messageResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(for: self)
        responseMapping?.addAttributeMappings(from: mappingDictionary)
        
        // give referece to meta model
        responseMapping?.addPropertyMapping(MessageResponse.metaModelKeyMapping)
        
        // give reference to message item model
        responseMapping?.addPropertyMapping(MessageResponse.messageItemModelKeyMapping)
        
        return responseMapping!
    }
    
    class var mappingDictionary: [String : String] {
        return(["total_messages": "total_messages", "unread_count": "unreadCount"])
    }
    
    // post message response mapping
    class var postMessageMapping: RKObjectMapping {
        
        let postMessageResponseMapping = RKObjectMapping(for: self)
        
        // give referece to meta model
        postMessageResponseMapping?.addPropertyMapping(MessageResponse.metaModelKeyMapping)
        
        return postMessageResponseMapping!
    }
    
    
    
    fileprivate class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", with: MetaModel.objectMapping)
    }
    
    fileprivate class var messageItemModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMessages, toKeyPath: "messages", with: MessageItemModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: messageResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kUrlGetMessages, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    class var postMessageResponseDescriptor: RKResponseDescriptor {
        // create the post message response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: postMessageMapping, method: .POST, pathPattern: Constants.ServiceConstants.kUrlPostMessage, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.successful))
        return responseDescriptor!
    }
    
    
    class func getMessages(_ offset: Int, andLimit limit: Int, andProgressHUD showLoader: Bool, completionHandler: @escaping (_ messages: [MessageItemModel]?, _ unreadCount: String?) -> ()) {
        // get messages
        
        if showLoader {
        SVProgressHUD.show()
        }
        
        // set access token
        RestKitManager.setToken(true)
        
        // input parameters
        let params: Dictionary = ["offset": offset, "limit": limit]
        
        // instance of message model class
        let messageResponse = MessageResponse()
        
        // set user id
        messageResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId
        
        // api call with instance of message model class
        RestKitManager.shared().getObject(messageResponse, path: nil, parameters: params, success: { (operation, mappingResult) in
            
            //print("Success")
            let messageObject = mappingResult?.firstObject as! MessageResponse
            
            // check for success
            if messageObject.meta?.responseCode != 200 {
                //print("failure data\(messageObject.meta?.responseCode)")
                return;
            }
            
            SVProgressHUD.dismiss()
            
            // completion handler for messages
            completionHandler(messageObject.messages as [MessageItemModel]?, messageObject.unreadCount)
            
            }) { (operation, error) in
                SVProgressHUD.dismiss()
                //print("erorrrrrrr \(error)");
        }
        
    }
    
}

