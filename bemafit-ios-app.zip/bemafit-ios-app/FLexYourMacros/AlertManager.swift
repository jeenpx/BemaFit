//
//  UIAlertViewExtension.swift
//  FlexYourMacros
//
//  Created by Attila Roy on 03/08/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class AlertManager: NSObject {
    
    class func showAlert(_ title: String, message: String) {
        // show alert controller if possible else show alert view
        UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"OK").show()
        
    }
    
}
