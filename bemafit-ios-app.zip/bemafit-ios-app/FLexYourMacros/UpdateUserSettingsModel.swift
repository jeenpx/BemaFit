//
//  UpdateUserSettingsModel.swift
//  FlexYourMacros
//
//  Created by DBG on 05/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UpdateUserSettingsModel: NSObject {
    var status:String?
    
    class var objectMapping: RKObjectMapping {
        let updateUserSettingsMapping = RKObjectMapping(for: UpdateUserSettingsModel.self)
        updateUserSettingsMapping?.addAttributeMappings(from: mappingDictionary)
        return updateUserSettingsMapping!
        
    }
    
    class var mappingDictionary: [String : String] {
        return(["status":"status"])
    }
    
}
