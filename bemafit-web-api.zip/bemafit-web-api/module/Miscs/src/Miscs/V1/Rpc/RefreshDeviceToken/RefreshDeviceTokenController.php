<?php
namespace Miscs\V1\Rpc\RefreshDeviceToken;

use Zend\Mvc\Controller\AbstractActionController;

class RefreshDeviceTokenController extends AbstractActionController
{   
    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function refreshDeviceTokenAction()
    {
        $deviceToken = $this->params()->fromPost('device_token');
        if (empty($deviceToken)) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'Device Token Required');
        }
        $currentUserId = $this->getIdentity()->getUserId();

        $user_info = $this->getFymUserDetailTable()->getUserDetailsById($currentUserId);
        if ($user_info) {
            if (!empty($user_info->device_token)) {
                $deviceTokens = unserialize($user_info->device_token);
                $deviceTokens[] = $deviceToken;
                $deviceTokens = array_unique($deviceTokens);
            } else {
                $deviceTokens = array($deviceToken);
            }
            $this->getFymUserDetailTable()->update($currentUserId, array('device_token'=>serialize($deviceTokens)));
            return  array(
                          'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'refreshDeviceToken'),
                          'device_token'=>
                                array('status'=>'OK'),
                    );
        }else {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }

    }
}
