<?php
namespace Miscs\V1\Rpc\FeedCron;

use Zend\Mvc\Controller\AbstractActionController;
use Aws\DynamoDb\DynamoDbClient;
use Aws\DynamoDb\Model\BatchRequest\PutRequest;
use Aws\DynamoDb\Model\BatchRequest\WriteRequestBatch;
use Aws\DynamoDb\Model\Item;
class FeedCronController extends AbstractActionController
{
    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function feedCronAction()
    {

        $config = $this->getServiceLocator()->get('Config');
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);
        $batchCount = 25;
        try {
            echo strtotime('2039-1-1')."<br/>";
            echo date("Y-m-d",strtotime('2099-1-1'))."<br/>";
            $iterator = $dynamodbClient->getIterator('Scan', array(
                'TableName' => 'feed',
                'ScanFilter' => array(
                    'status_id' => array(
                        'AttributeValueList' => array(
                            array('N' => 1)
                        ),
                        'ComparisonOperator' => 'EQ'
                    )

                )
            ), array(
                'limit'     => 50
            ));

            
            $cnt =1;
            foreach ($iterator as $item) {
                $userId = $item['user_id']['S'];
                $feed_type = $item['feed_type_id']['N'];
                $date = $item['date']['S'];
                $created_date = $item['created_date'];
                $object_id = isset($item['object_id'])?$item['object_id']['N']:'';

                echo "<pre>";
                print_r($item);
                echo "</pre>";

                $notification['created_date']   = substr($item['created_date']['N'],0,10);
                $notification['user_id']        =   $userId;
                $notification['type']           =   $feed_type;
                $notification['feed_id']        =   $item['feed_guid']['S'];
                $notification['object_id']           =   $object_id;
                
               
                $nItem = array(
                       'created_date'=> array('N' => $item['created_date']['N']),
                       'creator_id'=> array('N' => $userId),
                       'type'   => array('N' => $feed_type),
                       'feed_id'   => $item['feed_guid'],
                       'feed_created_date'=> array('S' => gmdate('Y-m-d H:i:s', $notification['created_date'])),
                    );

                if ($feed_type == 1) {//Normal feed

                    $nItem['data']    =   $item['data'];
                    if (!empty($item['media'])) {
                        $nItem['feed_image'] = array('M' => 
                                                    array('file'=> $item['media']['M']['file'],
                                                      'type'=> $item['media']['M']['type'],
                                                      'width'=> $item['media']['M']['width'],
                                                      'height'=> $item['media']['M']['height']),
                                                    );
                       
                        $notification['feed_image']['file']    =   $item['media']['M']['file']['S'];
                        $notification['feed_image']['type']    =   $item['media']['M']['type']['S'];
                        $notification['feed_image']['width']    =   $item['media']['M']['width']['N'];
                        $notification['feed_image']['height']    =   $item['media']['M']['height']['N'];
                    }

                } else if ($feed_type == 2) {//Goal

                    $nItem['goal_date']           =  array('S'=> $item['goal_date']['S']);


                } else if ($feed_type == 3) {//Exercise

                    $exerciseInfo = $this->getFymUserDetailTable()->getFeedExerciseDetails($object_id);
                    $nItem['exercise']    =   array('S'=> $exerciseInfo[0]['exercise']);

                } else if ($feed_type == 4) {//Checkin
                    $businessDetails = $this->getFymUserDetailTable()->getBusinessDetailsByCheckinId($object_id);
                    
                    if (isset($businessDetails[0])) {
                        $object_id = $businessDetails[0]['business_id'];
                    } else {
                        $object_id = 0;
                    }
                    $businessInfo = $this->getFymUserDetailTable()->getFeedBusinessDetails($object_id);
                    if ($businessInfo) {
                        $nItem['business'] = array('M' => 
                                                    array('business_id'=>array('S' => $businessInfo[0]['business_id']),
                                                      'business'=>array('S' => $businessInfo[0]['business_name']),
                                                    ));
                        if (!empty($businessInfo[0]['business_image'])) {
                            $nItem['business']['M']['business_image'] =array('S' =>  $businessInfo[0]['business_image']);
                        }
                    }
                } 



                if ($feed_type == 1 || $feed_type == 2 || $feed_type == 3 || $feed_type == 4) {


                    $followers = $this->getFymUserDetailTable()->getFollowerUserIds($userId);

                    //Added the same user for receiving his own notification
                    //array_push($followers,$userId);
                    
                    $totalFollowers = sizeof($followers);
                    if ($totalFollowers > 0) {
                         if ($totalFollowers > 0) {
                             
                             for ($i=0; $i < $totalFollowers; ) {
                                 try
                                 {
                                     $putBatch = WriteRequestBatch::factory($dynamodbClient);
                                     for ($k = $i; $k < $i+$batchCount; $k++) {

                                        if (!isset($followers[$k])) {
                                             $i = $totalFollowers;
                                             break;
                                        }

                                        $followerUserId = $followers[$k];
                                        $nItem['date']   = $item['date'];
                                        $nItem['user_id']   = array('N' => $followerUserId);
                                        if ($followerUserId == $userId)    {
                                            $nItem['mode']   = array('S' => 'self');
                                        }              
                                        $nItem['self_identifier']   = array('S' => $followerUserId .'-'. $userId);
                                         $putBatch->add(new PutRequest($nItem, 'user_notification'));
                                     }//var_dump($nItem);
                                     $putBatch->flush();
                                     
                                 }catch (\Exception $ex) {
                                     echo 'user feed 1-4 insert -> '.$ex->getMessage();
                                 }
                                 if (($i+$batchCount) > $totalFollowers) {
                                     $i=$i+2;
                                 } else {
                                     $i=$i+$batchCount;
                                 }
                                 
                             }
                             
                         }
                    }
                }


                if ($feed_type == 5) {//Friends
                    $userId2 = $item['user_id2']['N'];
                    $user1Followers = $this->getFymUserDetailTable()->getFollowerUserIds($userId);
                    $user2Followers = $this->getFymUserDetailTable()->getFollowerUserIds($userId2);
                    $frndNotifications  = array();
                    
                    $user1Followers =  array_flip ( $user1Followers);
                    $user2Followers =  array_flip ( $user2Followers);
                    
                    if (sizeof($user1Followers) > 0) {
                        
                        foreach ($user1Followers as $user => $value) {
                            $frndNotifications[] = array('user_id' => $user,
                                                         'friend1'  => $userId,
                                                         'friend2'  => $userId2
                                                        );
                            if (isset($user2Followers[$user])) {
                                unset($user2Followers[$user]);
                            }
                        }
                    }

                    if (sizeof($user2Followers) > 0) {
                        
                        foreach ($user2Followers  as $user => $value) {
                            $frndNotifications[] = array('user_id' => $user,
                                                         'friend1'  => $userId2,
                                                         'friend2'  => $userId
                                                        );
                        }
                    }
                    
                    $totalFriendNotification  = sizeof($frndNotifications);
                    if ($totalFriendNotification > 0) {
                        
                        for ($i=0; $i < $totalFriendNotification; ) {
                            try
                            {
                                $putBatch = WriteRequestBatch::factory($dynamodbClient);
                                for ($k = $i; $k < $i+$batchCount; $k++) {

                                    if (!isset($frndNotifications[$k])) {
                                        $i = $totalFriendNotification;
                                        break;
                                    }

                                    $fInfo = $frndNotifications[$k];

                                    if ($fInfo['user_id'] == $fInfo['friend1'] || $fInfo['user_id'] == $fInfo['friend2']) {
                                        $tmpCreatorId = ($fInfo['user_id'] == $fInfo['friend1'])?$fInfo['friend1']:$fInfo['friend2'];
                                        
                                    } else {

                                        $tmpCreatorId = $fInfo['friend1'];
                                    }
                                    

                                    $fItem = array(
                                           'user_id'   => array('N' => $fInfo['user_id']),
                                           'created_date'=> $item['created_date'],
                                           'creator_id'=> array('N' => $tmpCreatorId),
                                           'type'   => array('N' => $feed_type),
                                           'feed_id'   => $item['feed_guid'],
                                           'date'   => $item['date'],
                                           'feed_created_date'=> array('S' => gmdate('Y-m-d H:i:s', $notification['created_date'])),
                                        );
                                    
                                    $fItem['friends'] = array('M' =>  array('friend1'=>array('N' => $fInfo['friend1']),
                                                                  'friend2'=>array('N' => $fInfo['friend2']),
                                                             ));
                                    $fItem['self_identifier']   = array('S' => $fInfo['user_id'] .'-'. $tmpCreatorId);
                                    //Notification to userid2 had already sent when he accept the friend request.
                                    if ($tmpCreatorId != $userId2) {
                                        $putBatch->add(new PutRequest($fItem, 'user_notification'));
                                    }
                                    
                                }
                                $putBatch->flush();
                                
                            }catch (\Exception $ex) {
                                echo 'user feed friends insert -> '.$ex->getMessage();
                            }
                            if (($i+$batchCount) > $totalFriendNotification) {
                                $i=$i+2;
                            } else {
                                $i=$i+$batchCount;
                            }
                            
                        }
                        
                    }

                    
                } else if ($feed_type == 6) {//Guest Post
                   $guest_post_info = $this->getFymUserDetailTable()->getFeedGuestPostAdDetails($object_id); 
                   if (isset($guest_post_info[0])) {
                           $notification['ad_id']       =   $guest_post_info[0]['ad_id'];
                           $notification['ad_content']  =   $guest_post_info[0]['ad_content'];
                           $notification['ad_image']    =   $guest_post_info[0]['ad_image'];
                        
                           $allFymUsers = $this->getFymUserDetailTable()->getAllActiveFymUserIds($userId);
                           $totalFymUsers = sizeof($allFymUsers);
                           if ($totalFymUsers > 0) {
                                if ($totalFymUsers > 0) {
                                    
                                    for ($i=0; $i < $totalFymUsers; ) {
                                        try
                                        {
                                            $putBatch = WriteRequestBatch::factory($dynamodbClient);
                                            for ($k = $i; $k < $i+$batchCount; $k++) {

                                                if (!isset($allFymUsers[$k])) {
                                                    $i = $totalFymUsers;
                                                    break;
                                                }

                                                $fymUserId = $allFymUsers[$k];
                                                

                                                $fItem = array(
                                                       'user_id'   => array('N' => $fymUserId),
                                                       'created_date'=> $item['created_date'],
                                                       'creator_id'=> array('N' => $userId),
                                                       'type'   => array('N' => $feed_type),
                                                       'feed_id'   => $item['feed_guid'],
                                                       'date'   => $item['date'],
                                                       'object_id'=>array('N' => $object_id),
                                                       'feed_created_date'=> array('S' => gmdate('Y-m-d H:i:s', $notification['created_date'])),
                                                    );
                                                $nItem['self_identifier']   = array('S' => $fymUserId .'-'. $userId);
                                                $fItem['ad'] = array('M' =>  array('ad_id'=>array('S' => $guest_post_info[0]['ad_id']),
                                                                              'ad_content'=>array('S' => $guest_post_info[0]['ad_content']),
                                                                         ));
                                                if (!empty($guest_post_info[0]['ad_image'])) {
                                                    $fItem['ad']['M']['ad_image'] =array('S' =>  $guest_post_info[0]['ad_image']);
                                                }
                                                $putBatch->add(new PutRequest($fItem, 'user_notification'));
                                            }
                                            $putBatch->flush();
                                            
                                        }catch (\Exception $ex) {
                                            echo 'user feed guest post insert -> '.$ex->getMessage();
                                        }
                                        if (($i+$batchCount) > $totalFymUsers) {
                                            $i=$i+2;
                                        } else {
                                            $i=$i+$batchCount;
                                        }
                                        
                                    }
                                    
                                }
                           }
                    }
                }


              
               $notification = null;
               $cnt++;

               if (1) {
                    try{ //Update processed feed status to 4
                        $response = $dynamodbClient->updateItem(array(
                            'TableName' => 'feed',
                            'Key' => array(
                                'date' => array( "S" => $date  ) ,
                                'created_date' => $created_date ,
                            ),
                            'AttributeUpdates' => array(
                                'status_id' => array(
                                   'Action' => 'PUT',
                                   'Value' => array('N' => '4'),
                                )
                            ),
                            'ReturnValues' => 'ALL_NEW'
                        ));


                    } catch (\Exception $ex) {
                    echo 'update feed status -> '.$ex->getMessage();
                    }
               }
            }//End for 

            
        } catch (\Exception $ex) {
            echo $ex->getMessage();
            return null;
        }

        exit;
      
    }
}
