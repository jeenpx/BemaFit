<?php
namespace Miscs\V1\Rpc\AwsVerifyEmailAddress;

class AwsVerifyEmailAddressControllerFactory
{
    public function __invoke($controllers)
    {
        return new AwsVerifyEmailAddressController();
    }
}
