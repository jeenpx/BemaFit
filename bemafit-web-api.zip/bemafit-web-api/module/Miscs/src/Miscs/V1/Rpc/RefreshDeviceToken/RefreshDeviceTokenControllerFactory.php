<?php
namespace Miscs\V1\Rpc\RefreshDeviceToken;

class RefreshDeviceTokenControllerFactory
{
    public function __invoke($controllers)
    {
        return new RefreshDeviceTokenController();
    }
}
