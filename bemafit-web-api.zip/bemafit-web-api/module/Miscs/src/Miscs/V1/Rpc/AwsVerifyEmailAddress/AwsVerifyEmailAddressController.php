<?php
namespace Miscs\V1\Rpc\AwsVerifyEmailAddress;

use Zend\Mvc\Controller\AbstractActionController;
use Aws\Ses\SesClient;
use Aws\S3\Exception\S3Exception;
use \Exception;

class AwsVerifyEmailAddressController extends AbstractActionController
{
    public function awsVerifyEmailAddressAction()
    {
        $email = $this->params()->fromPost('email');
        $config = $this->getServiceLocator()->get('Config');
        $ses_client = SesClient::factory($config['amazon_ses']);

        try {
            $result = $ses_client->verifyEmailAddress(array(
                // EmailAddress is required
                'EmailAddress' => $email,
            ));
            //var_dump($result);
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
            exit;
        }
        $result = $ses_client->listVerifiedEmailAddresses(array(
        ));

        var_dump($result['VerifiedEmailAddresses']);
        exit;
        echo $email;
        exit;
    }
}
