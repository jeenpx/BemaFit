<?php
namespace Miscs\V1\Rpc\DynamoDB;

use Zend\Mvc\Controller\AbstractActionController;
use Aws\DynamoDb\DynamoDbClient;


class DynamoDBController extends AbstractActionController
{
    public function dynamoDBAction()
    {
        $config = $this->getServiceLocator()->get('Config');
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);

        $mode = $this->getEvent()->getRequest()->getQuery('mode','');

        if ($mode == 'production') {
            $this->productionTableCreate();
            exit;
        }
        try
        {
            
            $response = $dynamodbClient->scan(array(
                 'TableName' => 'feed',
                 'Limit'=>3,
                 'Count'=>1,
    'ScanFilter' => array(
        'data' => array(
            'AttributeValueList' => array(
                array('S' => 'dummy')
            ),
            'ComparisonOperator' => 'CONTAINS'
        ),
        
    )));
/*

$response = $dynamodbClient->scan(array(
                "TableName" => 'feed',
                "KeyConditions" => array(
                    "ComparisonOperator" => 'EQ',
                    'feed_guid' => array(
                        'AttributeValueList' => array(
                            array("S" => array("08198286cd986"))
                    ),
                 )
            )));

$iterator = $dynamodbClient->getIterator('Scan', array(
    'TableName' => 'errors',
    'ScanFilter' => array(
        'error' => array(
            'AttributeValueList' => array(
                array('S' => 'overflow')
            ),
            'ComparisonOperator' => 'CONTAINS'
        ),
        'time' => array(
            'AttributeValueList' => array(
                array('N' => strtotime('-15 minutes'))
            ),
            'ComparisonOperator' => 'GT'
        )
    )
));
*/

           

            var_dump($response);
            exit;
           //$response = $dynamodbClient->query($result);
          

            /*BEGIN CREATE FEED MOTIVATION*/
            $result =$dynamodbClient->createTable(array(
                'TableName' => 'feed_motivation',
                'AttributeDefinitions' => array(
                    array('AttributeName' => 'id',    'AttributeType' => 'S'),
                    array('AttributeName' => 'motivation_type', 'AttributeType' => 'S'),
                ),
                'KeySchema' => array(
                    array('AttributeName' => 'id', 'KeyType' => 'HASH'),
                    array('AttributeName' => 'motivation_type', 'KeyType' => 'RANGE'),
                ),
                

                'ProvisionedThroughput' => array(
                    'ReadCapacityUnits'  => 10,
                    'WriteCapacityUnits' => 20
                )
            ));
            var_dump($result);
            /*END CREATE FEED MOTIVATION*/


            exit;

            $response = $dynamodbClient->updateItem(array(
                'TableName' => 'feed',
                'Key' => array(
                    'feed_guid'      => array('S' => '5d068d10f2b5b54ea2e4c9064da89386'),
                    
                ),
                "ExpressionAttributeValues" =>  array (
                        ":val1" => array('N' => '1')
                    ) ,
                "UpdateExpression" => "set comment_count = comment_count + :val1",  
                'ReturnValues' => 'ALL_NEW'
            ));

            print_r($response);


           $result = $dynamodbClient->getItem(array(
                'ConsistentRead' => true,
                'TableName' => 'feed',
                'Key'       => array(
                    'feed_guid'   => array('S' => 'feee1'),
                    'user_id' => array('S' => 'Executive overflow2')
                )
            ));
            
            /*
           $result = $dynamodbClient->putItem(array(
            'TableName' => 'errors',
            'Item' => array(
                'id'      => array('N' => '1201'),
                'time'    => array('N' => 123456),
                'error'   => array('S' => 'Executive overflow'),
                'message' => array('S' => 'no vacant areas')
            )
        ));
        */
           // $result = $dynamodbClient->listTables();
            var_dump($result);
        } catch (\Exception $ex) {
            echo 'debug '. $ex->getMessage();
        }



        die();
    }


    public function productionTableCreate()
    {

        try
        {
            $config = $this->getServiceLocator()->get('Config');
            $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);

            /*BEGIN CREATE FEED MOTIVATION*/
            $result =$dynamodbClient->createTable(array(
                'TableName' => 'feed_motivation',
                'AttributeDefinitions' => array(
                    array('AttributeName' => 'id',    'AttributeType' => 'S'),
                    array('AttributeName' => 'motivation_type', 'AttributeType' => 'S'),
                ),
                'KeySchema' => array(
                    array('AttributeName' => 'id', 'KeyType' => 'HASH'),
                    array('AttributeName' => 'motivation_type', 'KeyType' => 'RANGE'),
                ),
                

                'ProvisionedThroughput' => array(
                    'ReadCapacityUnits'  => 10,
                    'WriteCapacityUnits' => 20
                )
            ));
            var_dump($result);
            /*END CREATE FEED MOTIVATION*/

            exit;
            /*BEGIN CREATE HASHTAG*/
            /*
            $result =$dynamodbClient->createTable(array(
                'TableName' => 'hashtag',
                'AttributeDefinitions' => array(
                    array('AttributeName' => 'hashtag',    'AttributeType' => 'S'),
                    array('AttributeName' => 'feed_guid',    'AttributeType' => 'S'),
                    array('AttributeName' => 'posted_by', 'AttributeType' => 'N'),
                    array('AttributeName' => 'created_date', 'AttributeType' => 'N'),
                    array('AttributeName' => 'status_id',  'AttributeType' => 'N'),
                ),
                'KeySchema' => array(
                    array('AttributeName' => 'hashtag', 'KeyType' => 'HASH'),
                    array('AttributeName' => 'created_date', 'KeyType' => 'RANGE'),
                ),
                
                'GlobalSecondaryIndexes' => array(
                    array(
                        'IndexName' => 'StatusIndex',
                        'ProvisionedThroughput' => array (
                            'ReadCapacityUnits' => 5,
                            'WriteCapacityUnits' => 5
                        ),
                        'KeySchema' => array(
                            array(
                                'AttributeName' => 'status_id',
                                'KeyType' => 'HASH'
                            ),
                        ),
                        'Projection' => array(
                            'ProjectionType' => 'ALL'
                        )
                    ),
                    
                ),
                'LocalSecondaryIndexes' => array(
                        array(
                            'IndexName' => 'PostedByIndex',
                            'KeySchema' => array(
                                array('AttributeName' => 'hashtag', 'KeyType' => 'HASH'),
                                array('AttributeName' => 'posted_by',  'KeyType' => 'RANGE'),
                            ),
                            'Projection' => array(
                                'ProjectionType' => 'KEYS_ONLY',
                            ),
                        ),
                        array(
                            'IndexName' => 'HashTagFeedIndex',
                            'KeySchema' => array(
                                array('AttributeName' => 'hashtag', 'KeyType' => 'HASH'),
                                array('AttributeName' => 'feed_guid',  'KeyType' => 'RANGE'),
                            ),
                            'Projection' => array(
                                'ProjectionType' => 'KEYS_ONLY',
                            ),
                        ),
                    ),
                'ProvisionedThroughput' => array(
                    'ReadCapacityUnits'  => 10,
                    'WriteCapacityUnits' => 20
                )
            ));
            var_dump($result);
           */
            /*END CREATE HASHTAG*/


            /*BEGIN CREATE USER_NOTIFICATION*/
            /*
            $result =$dynamodbClient->createTable(array(
                'TableName' => 'user_notification',
                'AttributeDefinitions' => array(
                    array('AttributeName' => 'user_id', 'AttributeType' => 'N'),
                    array('AttributeName' => 'created_date',  'AttributeType' => 'N'),
                    array('AttributeName' => 'status_id',  'AttributeType' => 'N'),
                    array('AttributeName' => 'creator_id',  'AttributeType' => 'N'),
                    array('AttributeName' => 'feed_guid',    'AttributeType' => 'S'),
                    
                ),
                'KeySchema' => array(
                    array('AttributeName' => 'user_id', 'KeyType' => 'HASH'),
                    array('AttributeName' => 'created_date', 'KeyType' => 'RANGE'),
                ),
                
                'GlobalSecondaryIndexes' => array(
                    array(
                        'IndexName' => 'StatusIndex',
                        'ProvisionedThroughput' => array (
                            'ReadCapacityUnits' => 5,
                            'WriteCapacityUnits' => 5
                        ),
                        'KeySchema' => array(
                            array(
                                'AttributeName' => 'status_id',
                                'KeyType' => 'HASH'
                            ),
                        ),
                        'Projection' => array(
                            'ProjectionType' => 'ALL'
                        )
                    ),
                    array(
                        'IndexName' => 'GuidIndex',
                        'ProvisionedThroughput' => array (
                            'ReadCapacityUnits' => 5,
                            'WriteCapacityUnits' => 5
                        ),
                        'KeySchema' => array(
                            array(
                                'AttributeName' => 'feed_guid',
                                'KeyType' => 'HASH'
                            ),
                        ),
                        'Projection' => array(
                            'ProjectionType' => 'ALL'
                        )
                    ),
                    
                    array(
                        'IndexName' => 'CreatorIdIndex',
                        'ProvisionedThroughput' => array (
                            'ReadCapacityUnits' => 5,
                            'WriteCapacityUnits' => 5
                        ),
                        'KeySchema' => array(
                            array( 'AttributeName' => 'user_id', 'KeyType' => 'HASH'  ),
                            array( 'AttributeName' => 'creator_id', 'KeyType' => 'RANGE'  ),
                        ),
                        'Projection' => array(
                            'ProjectionType' => 'ALL'
                        )
                    )

                ),
                'ProvisionedThroughput' => array(
                    'ReadCapacityUnits'  => 10,
                    'WriteCapacityUnits' => 20
                )
            ));
            var_dump($result);
            */
            /*END CREATE USER_NOTIFICATION*/

            
            /*BEGIN CREATE FEED COMMENT*/
            /*
            $result =$dynamodbClient->createTable(array(
                'TableName' => 'feed_comment',
                'AttributeDefinitions' => array(
                    array('AttributeName' => 'feed_comment_guid',    'AttributeType' => 'S'),
                    array('AttributeName' => 'feed_guid',    'AttributeType' => 'S'),
                    array('AttributeName' => 'posted_by', 'AttributeType' => 'N'),
                    array('AttributeName' => 'created_date', 'AttributeType' => 'N'),
                    array('AttributeName' => 'status_id',  'AttributeType' => 'N'),
                ),
                'KeySchema' => array(
                    array('AttributeName' => 'feed_guid', 'KeyType' => 'HASH'),
                    array('AttributeName' => 'created_date', 'KeyType' => 'RANGE'),
                ),
                
                'GlobalSecondaryIndexes' => array(
                    array(
                        'IndexName' => 'StatusIndex',
                        'ProvisionedThroughput' => array (
                            'ReadCapacityUnits' => 5,
                            'WriteCapacityUnits' => 5
                        ),
                        'KeySchema' => array(
                            array(
                                'AttributeName' => 'status_id',
                                'KeyType' => 'HASH'
                            ),
                        ),
                        'Projection' => array(
                            'ProjectionType' => 'ALL'
                        )
                    ),
                    array(
                        'IndexName' => 'FeedCommentGuidIndex',
                        'ProvisionedThroughput' => array (
                            'ReadCapacityUnits' => 5,
                            'WriteCapacityUnits' => 5
                        ),
                        'KeySchema' => array(
                            array(
                                'AttributeName' => 'feed_comment_guid',
                                'KeyType' => 'HASH'
                            ),
                        ),
                        'Projection' => array(
                            'ProjectionType' => 'ALL'
                        )
                    ),
                    

                ),
                'LocalSecondaryIndexes' => array(
                        array(
                            'IndexName' => 'OrderDateIndex',
                            'KeySchema' => array(
                                array('AttributeName' => 'feed_guid', 'KeyType' => 'HASH'),
                                array('AttributeName' => 'posted_by',  'KeyType' => 'RANGE'),
                            ),
                            'Projection' => array(
                                'ProjectionType' => 'KEYS_ONLY',
                            ),
                        ),
                    ),
                'ProvisionedThroughput' => array(
                    'ReadCapacityUnits'  => 10,
                    'WriteCapacityUnits' => 20
                )
            ));
            var_dump($result);
            */
            /*END CREATE FEED COMMENT*/

            
            
            /*BEGIN CREATE FEED*/
            /*
            $result =$dynamodbClient->createTable(array(
                'TableName' => 'feed',
                'AttributeDefinitions' => array(
                    array('AttributeName' => 'date', 'AttributeType' => 'S'),
                    array('AttributeName' => 'created_date',  'AttributeType' => 'N'),
                    array('AttributeName' => 'status_id',  'AttributeType' => 'N'),
                    array('AttributeName' => 'feed_guid',    'AttributeType' => 'S'),
                    array('AttributeName' => 'user_id', 'AttributeType' => 'S'),
                ),
                'KeySchema' => array(
                    array('AttributeName' => 'date', 'KeyType' => 'HASH'),
                    array('AttributeName' => 'created_date', 'KeyType' => 'RANGE'),
                ),
                
                'GlobalSecondaryIndexes' => array(
                    array(
                        'IndexName' => 'StatusIndex',
                        'ProvisionedThroughput' => array (
                            'ReadCapacityUnits' => 5,
                            'WriteCapacityUnits' => 5
                        ),
                        'KeySchema' => array(
                            array(
                                'AttributeName' => 'status_id',
                                'KeyType' => 'HASH'
                            ),
                        ),
                        'Projection' => array(
                            'ProjectionType' => 'ALL'
                        )
                    ),
                    array(
                        'IndexName' => 'GuidIndex',
                        'ProvisionedThroughput' => array (
                            'ReadCapacityUnits' => 5,
                            'WriteCapacityUnits' => 5
                        ),
                        'KeySchema' => array(
                            array(
                                'AttributeName' => 'feed_guid',
                                'KeyType' => 'HASH'
                            ),
                        ),
                        'Projection' => array(
                            'ProjectionType' => 'ALL'
                        )
                    ),
                    
                    array(
                        'IndexName' => 'UserIdIndex',
                        'ProvisionedThroughput' => array (
                            'ReadCapacityUnits' => 5,
                            'WriteCapacityUnits' => 5
                        ),
                        'KeySchema' => array(
                            array(
                                'AttributeName' => 'user_id',
                                'KeyType' => 'HASH'
                            ),
                        ),
                        'Projection' => array(
                            'ProjectionType' => 'ALL'
                        )
                    )

                ),
                'ProvisionedThroughput' => array(
                    'ReadCapacityUnits'  => 10,
                    'WriteCapacityUnits' => 20
                )
            ));
            var_dump($result);
            */
            /*END CREATE FEED*/




           // $result = $dynamodbClient->listTables();
            //var_dump($result);
        } catch (\Exception $ex) {
            echo $ex->getMessage();
        }
        die('production');
    }
}
