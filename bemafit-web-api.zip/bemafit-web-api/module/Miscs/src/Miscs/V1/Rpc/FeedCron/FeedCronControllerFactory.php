<?php
namespace Miscs\V1\Rpc\FeedCron;

class FeedCronControllerFactory
{
    public function __invoke($controllers)
    {
        return new FeedCronController();
    }
}
