<?php
namespace Miscs\V1\Rpc\DynamoDB;

class DynamoDBControllerFactory
{
    public function __invoke($controllers)
    {
        return new DynamoDBController();
    }
}
