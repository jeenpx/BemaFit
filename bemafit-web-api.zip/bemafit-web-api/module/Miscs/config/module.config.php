<?php
return array(
    'controllers' => array(
        'factories' => array(
            'Miscs\\V1\\Rpc\\AwsVerifyEmailAddress\\Controller' => 'Miscs\\V1\\Rpc\\AwsVerifyEmailAddress\\AwsVerifyEmailAddressControllerFactory',
            'Miscs\\V1\\Rpc\\RefreshDeviceToken\\Controller' => 'Miscs\\V1\\Rpc\\RefreshDeviceToken\\RefreshDeviceTokenControllerFactory',
            'Miscs\\V1\\Rpc\\FeedCron\\Controller' => 'Miscs\\V1\\Rpc\\FeedCron\\FeedCronControllerFactory',
            'Miscs\\V1\\Rpc\\DynamoDB\\Controller' => 'Miscs\\V1\\Rpc\\DynamoDB\\DynamoDBControllerFactory',
        ),
    ),
    'router' => array(
        'routes' => array(
            'miscs.rpc.aws-verify-email-address' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/aws/verify-email',
                    'defaults' => array(
                        'controller' => 'Miscs\\V1\\Rpc\\AwsVerifyEmailAddress\\Controller',
                        'action' => 'awsVerifyEmailAddress',
                    ),
                ),
            ),
            'miscs.rpc.refresh-device-token' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/refresh-device-token',
                    'defaults' => array(
                        'controller' => 'Miscs\\V1\\Rpc\\RefreshDeviceToken\\Controller',
                        'action' => 'refreshDeviceToken',
                    ),
                ),
            ),
            'miscs.rpc.feed-cron' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/feed-cron',
                    'defaults' => array(
                        'controller' => 'Miscs\\V1\\Rpc\\FeedCron\\Controller',
                        'action' => 'feedCron',
                    ),
                ),
            ),
            'miscs.rpc.dynamo-db' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/dynamo',
                    'defaults' => array(
                        'controller' => 'Miscs\\V1\\Rpc\\DynamoDB\\Controller',
                        'action' => 'dynamoDB',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            0 => 'miscs.rpc.aws-verify-email-address',
            1 => 'miscs.rpc.refresh-device-token',
            2 => 'miscs.rpc.feed-cron',
            3 => 'miscs.rpc.dynamo-db',
        ),
    ),
    'zf-rpc' => array(
        'Miscs\\V1\\Rpc\\AwsVerifyEmailAddress\\Controller' => array(
            'service_name' => 'AwsVerifyEmailAddress',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'miscs.rpc.aws-verify-email-address',
        ),
        'Miscs\\V1\\Rpc\\RefreshDeviceToken\\Controller' => array(
            'service_name' => 'RefreshDeviceToken',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'miscs.rpc.refresh-device-token',
        ),
        'Miscs\\V1\\Rpc\\FeedCron\\Controller' => array(
            'service_name' => 'FeedCron',
            'http_methods' => array(
                0 => 'GET',
            ),
            'route_name' => 'miscs.rpc.feed-cron',
        ),
        'Miscs\\V1\\Rpc\\DynamoDB\\Controller' => array(
            'service_name' => 'DynamoDB',
            'http_methods' => array(
                0 => 'GET',
            ),
            'route_name' => 'miscs.rpc.dynamo-db',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'Miscs\\V1\\Rpc\\AwsVerifyEmailAddress\\Controller' => 'Json',
            'Miscs\\V1\\Rpc\\RefreshDeviceToken\\Controller' => 'Json',
            'Miscs\\V1\\Rpc\\FeedCron\\Controller' => 'Json',
            'Miscs\\V1\\Rpc\\DynamoDB\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'Miscs\\V1\\Rpc\\AwsVerifyEmailAddress\\Controller' => array(
                0 => 'application/vnd.miscs.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'Miscs\\V1\\Rpc\\RefreshDeviceToken\\Controller' => array(
                0 => 'application/vnd.miscs.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'Miscs\\V1\\Rpc\\FeedCron\\Controller' => array(
                0 => 'application/vnd.miscs.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'Miscs\\V1\\Rpc\\DynamoDB\\Controller' => array(
                0 => 'application/vnd.miscs.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
        ),
        'content_type_whitelist' => array(
            'Miscs\\V1\\Rpc\\AwsVerifyEmailAddress\\Controller' => array(
                0 => 'application/vnd.miscs.v1+json',
                1 => 'application/json',
            ),
            'Miscs\\V1\\Rpc\\RefreshDeviceToken\\Controller' => array(
                0 => 'application/vnd.miscs.v1+json',
                1 => 'application/json',
            ),
            'Miscs\\V1\\Rpc\\FeedCron\\Controller' => array(
                0 => 'application/vnd.miscs.v1+json',
                1 => 'application/json',
            ),
            'Miscs\\V1\\Rpc\\DynamoDB\\Controller' => array(
                0 => 'application/vnd.miscs.v1+json',
                1 => 'application/json',
            ),
        ),
    ),
    'zf-mvc-auth' => array(
        'authorization' => array(
            'Miscs\\V1\\Rpc\\RefreshDeviceToken\\Controller' => array(
                'actions' => array(
                    'RefreshDeviceToken' => array(
                        'GET' => true,
                        'POST' => true,
                        'PUT' => false,
                        'PATCH' => false,
                        'DELETE' => false,
                    ),
                ),
            ),
        ),
    ),
);
