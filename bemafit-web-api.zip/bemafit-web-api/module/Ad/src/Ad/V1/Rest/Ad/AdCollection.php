<?php
namespace Ad\V1\Rest\Ad;

use Zend\Paginator\Paginator;

class AdCollection extends Paginator
{
}
