<?php
namespace Ad\V1\Rest\Ad;

class AdResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('Ad\V1\Rest\AdMapperTableGateway');
        return new AdResource($mapper);
    }
}
