<?php
namespace Ad\V1\Rest\Ad;

class AdEntity
{
}
