<?php

namespace Ad\V1\Rest\Ad;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
    * @param TableGateway $table
    */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    /**
    * check valid ad type
    *
    * @param string $type ad type
    */
    public function isValidType($type)
    {
        $sql ="SELECT id
        FROM ad_location_master 
        WHERE type='".$type."' and status_id=1
        ";
        
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();

        if (count($result->getResource()->fetchAll(2))>0) {
            return true;
        }
        return false;
    }

    /**
    * check valid ad Location
    *
    * @param string $location ad location
    */
    public function isValidLocation($location)
    {
        $sql ="SELECT id
        FROM ad_location_master 
        WHERE name='".$location."' and status_id=1
        ";
        
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        
        if (count($result->getResource()->fetchAll(2))>0) {
            return true;
        }

        return false;
    }

    /**
    * check valid latitude and longitude from postal code table
    *
    * @param string $latitude latitude
    * @param string $longitude longitude
    */
    public function isValidLatLong($latitude, $longitude)
    {
        $sql ="SELECT id
        FROM postal_code
        WHERE latitude='".$latitude."' and longitude='".$longitude."'
        ";
        
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        
        if (count($result->getResource()->fetchAll(2))>0) {
            return true;
        }
        return false;
    }

    /**
    * fecth ad by id
    *
    * @param int $id ad id
    */
    public function fetch($id)
    {
        $resultSet = $this->table->select(array('id' => $id));

        if (0===count($resultSet)) {
            throw new DomainException('Ad not found', 404);
        }
        return $resultSet->current();
    }

    /**
    * fetch all ads from table
    *
    * @param array $params params
    */
    public function fetchAll($params)
    {
        $config = $this->getServiceLocator()->get('Config');
        $this->getAdapter();
        $where = '';
        $adResult = array(); 
        $resultZip = array();
        if (!empty($params->type) and $params->type!='All') {
            if (!$this->isValidType($params->type)) {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Type');
            } else {
                $where.=" AND ad_location_master.type='".$params->type."'";
            }
        }

        if (!empty($params->location) and $params->location!='All') {
            if (!$this->isValidLocation($params->location)) {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Location');
            } else {
                 $where.=" AND ad_location_master.name='".$params->location."'";
            }
        }

        // if (!empty($params->latitude) and $params->latitude!='All' and !empty($params->longitude) and $params->longitude!='All') {
        //     if (!$this->isValidLatLong($params->latitude, $params->longitude)) {
        //          return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid latitude and longitude');
        //     } else {
        //           $where.=" AND (
        //             (pc1.latitude='".$params->latitude."' AND pc1.longitude='".$params->longitude."')
        //                     OR
        //              (pc2.latitude='".$params->latitude."' AND pc2.longitude='".$params->longitude."')
        //              )";
        //     }
        // }

        $geoSearch = '';
        if (!empty($params->latitude) and $params->latitude!='All' and !empty($params->longitude) and $params->longitude!='All') {
            //Extra code added to fix the zip code ad location issue on 16th june 2016
            $lat = addslashes($params->latitude);
            $long = addslashes($params->longitude);
            $queryPostalIds ="SELECT   (  (ACOS( SIN($lat * PI() / 180) *   SIN(postal_code.latitude * PI() / 180) + 
                COS($lat * PI() / 180) *  COS(postal_code.latitude * PI() / 180) * 
                COS(($long - postal_code.longitude) * PI() / 180)  )   * 180 / PI()  ) * 60 * 1.1515   )
                AS distance, postal_code.id,  postal_code.code
                from postal_code
                having distance< 2";
            $statement = $this->adapter->createStatement($queryPostalIds);
            $postalIds  = $statement->execute()->getResource()->fetchAll(2);

            if (sizeof($postalIds) > 0) {
                $postalIdStr = '';
                foreach($postalIds as $postalId) {
                    $postalIdStr = !empty($postalIdStr)?$postalIdStr.','.$postalId['id']:$postalId['id'];
                }

                $where.=" AND ( ad2.radius_value in ($postalIdStr) )";
                // $where.=" AND (
              //   (pc1.latitude=".$params->latitude." AND pc1.longitude=".$params->longitude.") 
              //           OR
              //    (pc2.latitude=".$params->latitude." AND pc2.longitude=".$params->longitude.")
              //    )";
            } else {
                $geoSearch = 'no_geo_matches';

                //If it failed to fetch the ads based on the given zipcodes, then it should not be allowed to fetch any ad entered based on the radius type zipcode 
                $where.=" AND ( ad2.radius_type !='Zipcode' )";
            }
              
        }
        

        $date = date('Y-m-d');
        
        //test
        $sql ="SELECT ad.id,content,business_name,ad_location_master.type,ad_location_master.name,
        IF(ISNULL(ad_image.file),'',ad_image.file) as image_url
        FROM ad
        JOIN ad_location ON ad_id = ad.id 
        JOIN ad_location_master ON ad_location_master.id = ad_location.ad_location_master_id

        LEFT JOIN ad_radius ad1 ON   ad1.ad_id = ad.id and ad1.radius_type='State'
        LEFT JOIN ad_radius ad2 ON   ad2.ad_id = ad.id and ad2.radius_type='Zipcode'

        LEFT JOIN postal_code pc1 ON pc1.state_id   = ad1.radius_value
        LEFT JOIN postal_code pc2 ON pc2.id       = ad2.radius_value

        LEFT JOIN ad_image ON ad_image.ad_id       = ad.id and ad_image.status_id=1
        WHERE time_from<='".$date."' and  time_to>='".$date."' and ad.status_id=1 $where
        
        GROUP BY ad.id
        ORDER BY RAND()
        LIMIT 1
        ";
        
        
        $statement = $this->adapter->createStatement($sql);
        $preview_bucket_url = $config['ad_photo_Settings_guestpost']['thumbs'][1]['ad1400']['bucket'];
        $resultZip  = $statement->execute()->getResource()->fetchAll(2);
        if (count($resultZip) > 0) {
            $resultZip[0]['image_url'] = empty($resultZip[0]['image_url'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$resultZip[0]['image_url']);
            $resultZip[0]['selected_by'] = 'zipcode';
            
        }
       

            
        //if (count($result)==0) 
        {
            if (!empty($params->location) and $params->location!='All') {
                $where =" AND ad_location_master.name='".$params->location."'";
            }

            $sql ="SELECT ad.id,content,business_name,ad_location_master.type,ad_location_master.name,
            IF(ISNULL(ad_image.file),'',ad_image.file) as image_url
            FROM ad
            JOIN ad_location ON ad_id = ad.id 
            JOIN ad_location_master ON ad_location_master.id = ad_location.ad_location_master_id
            LEFT JOIN ad_image ON ad_image.ad_id       = ad.id and ad_image.status_id=1
            WHERE time_from<='".$date."' and  time_to>='".$date."' and ad.status_id=1 $where
            AND all_radius=1
            GROUP BY ad.id
            ORDER BY RAND()
             LIMIT 1
            ";

            $statement = $this->adapter->createStatement($sql);
            $preview_bucket_url = $config['ad_photo_Settings_guestpost']['thumbs'][1]['ad1400']['bucket'];
            $result  = $statement->execute()->getResource()->fetchAll(2);
            if (count($result) > 0) {
                $result[0]['image_url'] = empty($result[0]['image_url'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$result[0]['image_url']);
                $result[0]['selected_by'] = 'all';
            }
        }

        /*This fix is the tweak of an issue resolved on 16th june 2016.
         If no ads matches with zipcode and geo location comparison, then show only the ads with type 'all radius' .

         If an ad matches with the zipcode and geo location comparison, then try to find another ads having type 'all radius' . If found then randomnly select an ad in the both query result.
    
        */

        if (count($resultZip)==0) { 
            //No zipcode matches, then show the all radius ad
            $adResult = $result;
            
        } else if (count($resultZip)>0 && count($result) == 0) { 
            //zipcode matches and no all radius matches, then show the zipcode ad
            $adResult = $resultZip;
            
        } else if (count($resultZip)>0 && count($result) > 0) {
            //both matches, then select one randomly
            
            $rand = rand(1,2);
            if ($rand  == 1) {
                $adResult = $result;
            } else {
                $adResult = $resultZip;
            }
            $adResult[0]['selected_by'] = 'rand';
        }

        
        return $adResult;
    }
}
