<?php
return array(
    'router' => array(
        'routes' => array(
            'ad.rest.ad' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/ad[/:ad_id]',
                    'defaults' => array(
                        'controller' => 'Ad\\V1\\Rest\\Ad\\Controller',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            0 => 'ad.rest.ad',
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'Ad\\V1\\Rest\\Ad\\AdResource' => 'Ad\\V1\\Rest\\Ad\\AdResourceFactory',
        ),
    ),
    'zf-rest' => array(
        'Ad\\V1\\Rest\\Ad\\Controller' => array(
            'listener' => 'Ad\\V1\\Rest\\Ad\\AdResource',
            'route_name' => 'ad.rest.ad',
            'route_identifier_name' => 'ad_id',
            'collection_name' => 'ad',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array('location','type','latitude','longitude'),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'Ad\\V1\\Rest\\Ad\\AdEntity',
            'collection_class' => 'Ad\\V1\\Rest\\Ad\\AdCollection',
            'service_name' => 'Ad',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'Ad\\V1\\Rest\\Ad\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'Ad\\V1\\Rest\\Ad\\Controller' => array(
                0 => 'application/vnd.ad.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
        ),
        'content_type_whitelist' => array(
            'Ad\\V1\\Rest\\Ad\\Controller' => array(
                0 => 'application/vnd.ad.v1+json',
                1 => 'application/json',
            ),
        ),
    ),
    'zf-hal' => array(
        'metadata_map' => array(
            'Ad\\V1\\Rest\\Ad\\AdEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'ad.rest.ad',
                'route_identifier_name' => 'ad_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'Ad\\V1\\Rest\\Ad\\AdCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'ad.rest.ad',
                'route_identifier_name' => 'ad_id',
                'is_collection' => true,
            ),
        ),
    ),
);
