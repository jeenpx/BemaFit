<?php
return array(
    'router' => array(
        'routes' => array(
            'daily-meal-plan.rest.import-meal' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/import-meal[/:import_meal_id]',
                    'defaults' => array(
                        'controller' => 'DailyMealPlan\\V1\\Rest\\ImportMeal\\Controller',
                    ),
                ),
            ),
            'daily-meal-plan.rest.auto-suggest' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/dmp/auto-suggest[/:auto_suggest_id]',
                    'defaults' => array(
                        'controller' => 'DailyMealPlan\\V1\\Rest\\AutoSuggest\\Controller',
                    ),
                ),
            ),
            'daily-meal-plan.rest.refresh' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/dmp/refresh[/:refresh_id]',
                    'defaults' => array(
                        'controller' => 'DailyMealPlan\\V1\\Rest\\Refresh\\Controller',
                    ),
                ),
            ),
            'daily-meal-plan.rest.daily-meal-plan' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/daily-meal-plan[/:daily_meal_plan_id][/:item]',
                    'defaults' => array(
                        'controller' => 'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\Controller',
                    ),
                ),
            ),
            'daily-meal-plan.rest.share' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/dmp/share[/:share_id]',
                    'defaults' => array(
                        'controller' => 'DailyMealPlan\\V1\\Rest\\Share\\Controller',
                    ),
                ),
            ),
            'daily-meal-plan.rest.meal-type' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/dmp/meal-type[/:meal_type_id]',
                    'defaults' => array(
                        'controller' => 'DailyMealPlan\\V1\\Rest\\MealType\\Controller',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            0 => 'daily-meal-plan.rest.import-meal',
            1 => 'daily-meal-plan.rest.auto-suggest',
            2 => 'daily-meal-plan.rest.refresh',
            3 => 'daily-meal-plan.rest.daily-meal-plan',
            4 => 'daily-meal-plan.rest.share',
            5 => 'daily-meal-plan.rest.meal-type',
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'DailyMealPlan\\V1\\Rest\\ImportMeal\\ImportMealResource' => 'DailyMealPlan\\V1\\Rest\\ImportMeal\\ImportMealResourceFactory',
            'DailyMealPlan\\V1\\Rest\\AutoSuggest\\AutoSuggestResource' => 'DailyMealPlan\\V1\\Rest\\AutoSuggest\\AutoSuggestResourceFactory',
            'DailyMealPlan\\V1\\Rest\\Refresh\\RefreshResource' => 'DailyMealPlan\\V1\\Rest\\Refresh\\RefreshResourceFactory',
            'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\DailyMealPlanResource' => 'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\DailyMealPlanResourceFactory',
            'DailyMealPlan\\V1\\Rest\\Share\\ShareResource' => 'DailyMealPlan\\V1\\Rest\\Share\\ShareResourceFactory',
            'DailyMealPlan\\V1\\Rest\\MealType\\MealTypeResource' => 'DailyMealPlan\\V1\\Rest\\MealType\\MealTypeResourceFactory',
        ),
    ),
    'zf-rest' => array(
        'DailyMealPlan\\V1\\Rest\\ImportMeal\\Controller' => array(
            'listener' => 'DailyMealPlan\\V1\\Rest\\ImportMeal\\ImportMealResource',
            'route_name' => 'daily-meal-plan.rest.import-meal',
            'route_identifier_name' => 'import_meal_id',
            'collection_name' => 'import_meal',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'DailyMealPlan\\V1\\Rest\\ImportMeal\\ImportMealEntity',
            'collection_class' => 'DailyMealPlan\\V1\\Rest\\ImportMeal\\ImportMealCollection',
            'service_name' => 'ImportMeal',
        ),
        'DailyMealPlan\\V1\\Rest\\AutoSuggest\\Controller' => array(
            'listener' => 'DailyMealPlan\\V1\\Rest\\AutoSuggest\\AutoSuggestResource',
            'route_name' => 'daily-meal-plan.rest.auto-suggest',
            'route_identifier_name' => 'auto_suggest_id',
            'collection_name' => 'auto_suggest',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(
                0 => 'core_meal',
                1 => 'snacks',
                2 => 'nutritional_plan'
            ),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'DailyMealPlan\\V1\\Rest\\AutoSuggest\\AutoSuggestEntity',
            'collection_class' => 'DailyMealPlan\\V1\\Rest\\AutoSuggest\\AutoSuggestCollection',
            'service_name' => 'AutoSuggest',
        ),
        'DailyMealPlan\\V1\\Rest\\Refresh\\Controller' => array(
            'listener' => 'DailyMealPlan\\V1\\Rest\\Refresh\\RefreshResource',
            'route_name' => 'daily-meal-plan.rest.refresh',
            'route_identifier_name' => 'refresh_id',
            'collection_name' => 'refresh',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'DailyMealPlan\\V1\\Rest\\Refresh\\RefreshEntity',
            'collection_class' => 'DailyMealPlan\\V1\\Rest\\Refresh\\RefreshCollection',
            'service_name' => 'refresh',
        ),
        'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\Controller' => array(
            'listener' => 'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\DailyMealPlanResource',
            'route_name' => 'daily-meal-plan.rest.daily-meal-plan',
            'route_identifier_name' => 'daily_meal_plan_id',
            'collection_name' => 'daily_meal_plan',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(
                0 => 'offset',
                1 => 'limit',
            ),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\DailyMealPlanEntity',
            'collection_class' => 'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\DailyMealPlanCollection',
            'service_name' => 'DailyMealPlan',
        ),
        'DailyMealPlan\\V1\\Rest\\Share\\Controller' => array(
            'listener' => 'DailyMealPlan\\V1\\Rest\\Share\\ShareResource',
            'route_name' => 'daily-meal-plan.rest.share',
            'route_identifier_name' => 'share_id',
            'collection_name' => 'share',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'DailyMealPlan\\V1\\Rest\\Share\\ShareEntity',
            'collection_class' => 'DailyMealPlan\\V1\\Rest\\Share\\ShareCollection',
            'service_name' => 'Share',
        ),
        'DailyMealPlan\\V1\\Rest\\MealType\\Controller' => array(
            'listener' => 'DailyMealPlan\\V1\\Rest\\MealType\\MealTypeResource',
            'route_name' => 'daily-meal-plan.rest.meal-type',
            'route_identifier_name' => 'meal_type_id',
            'collection_name' => 'meal_type',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array('coremeal','snacks','locale'),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'DailyMealPlan\\V1\\Rest\\MealType\\MealTypeEntity',
            'collection_class' => 'DailyMealPlan\\V1\\Rest\\MealType\\MealTypeCollection',
            'service_name' => 'MealType',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'DailyMealPlan\\V1\\Rest\\ImportMeal\\Controller' => 'Json',
            'DailyMealPlan\\V1\\Rest\\AutoSuggest\\Controller' => 'Json',
            'DailyMealPlan\\V1\\Rest\\Refresh\\Controller' => 'Json',
            'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\Controller' => 'Json',
            'DailyMealPlan\\V1\\Rest\\Share\\Controller' => 'Json',
            'DailyMealPlan\\V1\\Rest\\MealType\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'DailyMealPlan\\V1\\Rest\\ImportMeal\\Controller' => array(
                0 => 'application/vnd.daily-meal-plan.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'DailyMealPlan\\V1\\Rest\\AutoSuggest\\Controller' => array(
                0 => 'application/vnd.daily-meal-plan.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'DailyMealPlan\\V1\\Rest\\Refresh\\Controller' => array(
                0 => 'application/vnd.daily-meal-plan.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\Controller' => array(
                0 => 'application/vnd.daily-meal-plan.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'DailyMealPlan\\V1\\Rest\\Share\\Controller' => array(
                0 => 'application/vnd.daily-meal-plan.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'DailyMealPlan\\V1\\Rest\\MealType\\Controller' => array(
                0 => 'application/vnd.daily-meal-plan.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
        ),
        'content_type_whitelist' => array(
            'DailyMealPlan\\V1\\Rest\\ImportMeal\\Controller' => array(
                0 => 'application/vnd.daily-meal-plan.v1+json',
                1 => 'application/json',
            ),
            'DailyMealPlan\\V1\\Rest\\AutoSuggest\\Controller' => array(
                0 => 'application/vnd.daily-meal-plan.v1+json',
                1 => 'application/json',
            ),
            'DailyMealPlan\\V1\\Rest\\Refresh\\Controller' => array(
                0 => 'application/vnd.daily-meal-plan.v1+json',
                1 => 'application/json',
            ),
            'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\Controller' => array(
                0 => 'application/vnd.daily-meal-plan.v1+json',
                1 => 'application/json',
            ),
            'DailyMealPlan\\V1\\Rest\\Share\\Controller' => array(
                0 => 'application/vnd.daily-meal-plan.v1+json',
                1 => 'application/json',
            ),
            'DailyMealPlan\\V1\\Rest\\MealType\\Controller' => array(
                0 => 'application/vnd.daily-meal-plan.v1+json',
                1 => 'application/json',
            ),
        ),
    ),
    'zf-hal' => array(
        'metadata_map' => array(
            'DailyMealPlan\\V1\\Rest\\ImportMeal\\ImportMealEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'daily-meal-plan.rest.import-meal',
                'route_identifier_name' => 'import_meal_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'DailyMealPlan\\V1\\Rest\\ImportMeal\\ImportMealCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'daily-meal-plan.rest.import-meal',
                'route_identifier_name' => 'import_meal_id',
                'is_collection' => true,
            ),
            'DailyMealPlan\\V1\\Rest\\AutoSuggest\\AutoSuggestEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'daily-meal-plan.rest.auto-suggest',
                'route_identifier_name' => 'auto_suggest_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'DailyMealPlan\\V1\\Rest\\AutoSuggest\\AutoSuggestCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'daily-meal-plan.rest.auto-suggest',
                'route_identifier_name' => 'auto_suggest_id',
                'is_collection' => true,
            ),
            'DailyMealPlan\\V1\\Rest\\Refresh\\RefreshEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'daily-meal-plan.rest.refresh',
                'route_identifier_name' => 'refresh_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'DailyMealPlan\\V1\\Rest\\Refresh\\RefreshCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'daily-meal-plan.rest.refresh',
                'route_identifier_name' => 'refresh_id',
                'is_collection' => true,
            ),
            'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\DailyMealPlanEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'daily-meal-plan.rest.daily-meal-plan',
                'route_identifier_name' => 'daily_meal_plan_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\DailyMealPlanCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'daily-meal-plan.rest.daily-meal-plan',
                'route_identifier_name' => 'daily_meal_plan_id',
                'is_collection' => true,
            ),
            'DailyMealPlan\\V1\\Rest\\Share\\ShareEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'daily-meal-plan.rest.share',
                'route_identifier_name' => 'share_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'DailyMealPlan\\V1\\Rest\\Share\\ShareCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'daily-meal-plan.rest.share',
                'route_identifier_name' => 'share_id',
                'is_collection' => true,
            ),
            'DailyMealPlan\\V1\\Rest\\MealType\\MealTypeEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'daily-meal-plan.rest.meal-type',
                'route_identifier_name' => 'meal_type_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'DailyMealPlan\\V1\\Rest\\MealType\\MealTypeCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'daily-meal-plan.rest.meal-type',
                'route_identifier_name' => 'meal_type_id',
                'is_collection' => true,
            ),
        ),
    ),
    'zf-content-validation' => array(
        'DailyMealPlan\\V1\\Rest\\AutoSuggest\\Controller' => array(
            'input_filter' => 'DailyMealPlan\\V1\\Rest\\AutoSuggest\\Validator',
        ),
        'DailyMealPlan\\V1\\Rest\\Refresh\\Controller' => array(
            'input_filter' => 'DailyMealPlan\\V1\\Rest\\Refresh\\Validator',
        ),
        'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\Controller' => array(
            'input_filter' => 'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\Validator',
        ),
    ),
    'input_filter_specs' => array(
        'DailyMealPlan\\V1\\Rest\\AutoSuggest\\Validator' => array(
            0 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'core_meal',
            ),
            1 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'snacks',
            ),
            2 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'calories',
            ),
            3 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'carbs',
            ),
            4 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'fats',
            ),
            5 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'proteins',
            ),
        ),
        'DailyMealPlan\\V1\\Rest\\Refresh\\Validator' => array(
            0 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'type',
            ),
            1 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'genre',
            ),
            2 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'calories',
            ),
            3 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'carbs',
            ),
            4 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'fats',
            ),
            5 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'proteins',
            ),
        ),
        'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\Validator' => array(
            0 => array(
                'required' => false,
                'validators' => array(),
                'filters' => array(),
                'name' => 'name',
            ),
            1 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'name' => 'coremeal',
            ),
            2 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'filters' => array(),
                'name' => 'snacks',
            ),
            3 => array(
                'required' => false,
                'validators' => array(),
                'filters' => array(),
                'name' => 'nutrition_plan',
            ),
            4 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'filters' => array(),
                'name' => 'calorie',
            ),
            5 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'filters' => array(),
                'name' => 'carb',
            ),
            6 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'filters' => array(),
                'name' => 'fat',
            ),
            7 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'filters' => array(),
                'name' => 'protien',
            ),
            8 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'filters' => array(),
                'name' => 'fiber',
            ),
            9 => array(
                'required' => false,
                'validators' => array(),
                'filters' => array(),
                'name' => 'meal_type',
            ),
        ),
    ),
    'zf-mvc-auth' => array(
        'authorization' => array(
            'DailyMealPlan\\V1\\Rest\\DailyMealPlan\\Controller' => array(
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PUT' => true,
                    'PATCH' => true,
                    'DELETE' => true,
                ),
                'entity' => array(
                    'GET' => true,
                    'POST' => true,
                    'PUT' => true,
                    'PATCH' => true,
                    'DELETE' => true,
                ),
            ),
            'DailyMealPlan\\V1\\Rest\\Share\\Controller' => array(
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PUT' => false,
                    'PATCH' => false,
                    'DELETE' => false,
                ),
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PUT' => false,
                    'PATCH' => false,
                    'DELETE' => false,
                ),
            ),
            'DailyMealPlan\\V1\\Rest\\AutoSuggest\\Controller' => array(
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PUT' => false,
                    'PATCH' => false,
                    'DELETE' => false,
                ),
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PUT' => false,
                    'PATCH' => true,
                    'DELETE' => true,
                ),
            ),
        ),
    ),
);
