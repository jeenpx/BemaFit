<?php
require __DIR__ . '/src/DailyMealPlan/Module.php';