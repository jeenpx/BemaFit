<?php
namespace DailyMealPlan;

use DailyMealPlan\V1\Model\DmpDetail;
use DailyMealPlan\V1\Model\DmpDetailTable;

use User\V1\Model\FoodlogDetail;
use User\V1\Model\FoodlogDetailTable;

use DailyMealPlan\V1\Model\DmpMealDetail;
use DailyMealPlan\V1\Model\DmpMealDetailTable;


use ZF\Apigility\Provider\ApigilityProviderInterface;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\ResultSet\ResultSet;

class Module implements ApigilityProviderInterface
{
    public function getConfig()
    {
        return include __DIR__ . '/../../config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'ZF\Apigility\Autoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__,
                ),
            ),
        );
    }

    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'DailyMealPlan\V1\Rest\ImportMealMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\DailyMealPlan\ImportMeal($adapter);
                },
                'DailyMealPlan\V1\Rest\ImportMealMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\ImportMeal\TableGateway('dmp_meal', $adapter);
                    return new V1\Rest\ImportMeal\TableGatewayMapper($tableGateway);
                },


                'DailyMealPlan\V1\Rest\AutoSuggestMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\DailyMealPlan\AutoSuggest($adapter);
                },
                'DailyMealPlan\V1\Rest\AutoSuggestMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\AutoSuggest\TableGateway('dmp_meal', $adapter);
                    return new V1\Rest\AutoSuggest\TableGatewayMapper($tableGateway);
                },

                'DailyMealPlan\V1\Rest\RefreshMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\DailyMealPlan\Refresh($adapter);
                },
                'DailyMealPlan\V1\Rest\RefreshMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Refresh\TableGateway('dmp_meal', $adapter);
                    return new V1\Rest\Refresh\TableGatewayMapper($tableGateway);
                },

                'DailyMealPlan\V1\Rest\DailyMealPlanMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\DailyMealPlan\DailyMealPlan($adapter);
                },
                'DailyMealPlan\V1\Rest\DailyMealPlanMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\DailyMealPlan\TableGateway('dmp', $adapter);
                    return new V1\Rest\DailyMealPlan\TableGatewayMapper($tableGateway);
                },

                'DailyMealPlan\Model\DmpDetailTable' =>  function ($services) {
                    $tableGateway = $services->get('DmpDetailTableGateway');
                    $table = new DmpDetailTable($tableGateway);
                    return $table;
                },
                'DmpDetailTableGateway' => function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new DmpDetail());
                    return new TableGateway('dmp_details', $adapter, null, $resultSetPrototype);
                },

                'DailyMealPlan\Model\DmpMealDetailTable' =>  function ($services) {
                    $tableGateway = $services->get('DmpMealDetailTableGateway');
                    $table = new DmpMealDetailTable($tableGateway);
                    return $table;
                },
                'DmpMealDetailTableGateway' => function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new DmpMealDetail());
                    return new TableGateway('dmp_meal_details', $adapter, null, $resultSetPrototype);
                },


                'DailyMealPlan\V1\Rest\ShareMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\DailyMealPlan\Share($adapter);
                },
                'DailyMealPlan\V1\Rest\ShareMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Share\TableGateway('dmp_share', $adapter);
                    return new V1\Rest\Share\TableGatewayMapper($tableGateway);
                },

                'DailyMealPlan\V1\Rest\MealTypeMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\DailyMealPlan\MealType($adapter);
                },
                'DailyMealPlan\V1\Rest\MealTypeMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\MealType\TableGateway('meal_type', $adapter);
                    return new V1\Rest\MealType\TableGatewayMapper($tableGateway);
                },



            ),
        );
    }
}
