<?php
namespace DailyMealPlan\V1\Rest\Share;

class ShareResourceFactory
{
    public function __invoke($services)
    {
    	$mapper = $services->get('DailyMealPlan\V1\Rest\ShareMapperTableGateway');
        return new ShareResource($mapper);
    }
}
