<?php
namespace DailyMealPlan\V1\Rest\DailyMealPlan;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class DailyMealPlanResource extends AbstractResourceListener
{
    protected $mapper;
 
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }

    /**
     * Create a resource
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        $userId             =   $this->getIdentity()->getUserId();
        return $this->mapper->create($data,$userId);
    }

    /**
     * Delete a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function delete($id)
    {
        $item =  $this->getEvent()->getRouteMatch()->getParam('item');

        
        $userId = $this->getIdentity()->getUserId();
        $dmp    = $this->mapper->delete($id,$item,$userId);

        if($dmp){
            return \Application\Service\FymApiResponse::FymApiResponse(array(
                             'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'Delete Daily meal plan'),
                       ));
        } else {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid entry');
        }
    }

    /**
     * Delete a collection, or members of a collection
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        print_r($data);
        die('sd');
        //return new ApiProblem(405, 'The DELETE method has not been defined for collections');
    }

    /**
     * Fetch a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($guid)
    {
        $userId = $this->getIdentity()->getUserId();
        $dmp = $this->mapper->fetch($guid,$userId);

        if($dmp){
            return \Application\Service\FymApiResponse::FymApiResponse(array(
                             'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'Get Daily meal plan'),
                             'result'=>$dmp
                       ));
        } else {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid entry');
        }
        //return new ApiProblem(405, 'The GET method has not been defined for individual resources');
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($params = array())
    {
        $userId             = $this->getIdentity()->getUserId();
        $params['offset']   = (int)$this->getEvent()->getRequest()->getQuery('offset', 0);
        $params['limit']    = (int)$this->getEvent()->getRequest()->getQuery('limit', 10);
        $dmp = $this->mapper->fetchAll($params,$userId);

        return array(
                      'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'get Daily Meal Plan'),
                      'result'=>$dmp,
                      'total'=>count($dmp),
                );
    }

    /**
     * Patch (partial in-place update) a resource
     *
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        
        $userId             =   $this->getIdentity()->getUserId();
        $item               =  $this->getEvent()->getRouteMatch()->getParam('item');
        $status             =   $this->mapper->patch($data,$id,$item,$userId);

        if($status){
            return \Application\Service\FymApiResponse::FymApiResponse(array(
                             'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'Patch Daily meal plan'),
                             'guid'=>$id
                       ));
        } else {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid entry');
        }
    }

    /**
     * Replace a collection or members of a collection
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return new ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     *
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {

        $userId             =   $this->getIdentity()->getUserId();
        $status             =   $this->mapper->update($data,$id,$userId);

        if($status){
            return \Application\Service\FymApiResponse::FymApiResponse(array(
                             'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'Update Daily meal plan'),
                             'guid'=>$id
                       ));
        } else {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid entry');
        }
    }
}
