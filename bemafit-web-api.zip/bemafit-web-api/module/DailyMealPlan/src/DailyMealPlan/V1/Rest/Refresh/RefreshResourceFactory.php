<?php
namespace DailyMealPlan\V1\Rest\Refresh;

class RefreshResourceFactory
{
    public function __invoke($services)
    {
    	$mapper = $services->get('DailyMealPlan\V1\Rest\RefreshMapperTableGateway');
        return new RefreshResource($mapper);
    }
}
