<?php
namespace DailyMealPlan\V1\Rest\MealType;

class MealTypeResourceFactory
{
    public function __invoke($services)
    {

    	$mapper = $services->get('DailyMealPlan\V1\Rest\MealTypeMapperTableGateway');
        //return new ShareResource($mapper);


        return new MealTypeResource($mapper);
    }
}
