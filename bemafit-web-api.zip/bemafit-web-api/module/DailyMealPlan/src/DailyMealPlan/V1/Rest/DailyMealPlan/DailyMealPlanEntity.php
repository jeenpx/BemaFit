<?php
namespace DailyMealPlan\V1\Rest\DailyMealPlan;

class DailyMealPlanEntity
{
}
