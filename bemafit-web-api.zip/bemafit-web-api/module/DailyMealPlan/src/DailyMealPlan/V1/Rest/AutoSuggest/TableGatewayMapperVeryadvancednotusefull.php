<?php

namespace DailyMealPlan\V1\Rest\AutoSuggest;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    public function getMealTypeTable()
    {
        $sm = $this->getServiceLocator();
        $this->MealTypeTable = $sm->get('MealType\V1\Rest\MealTypeMapperTableGateway');
        return $this->MealTypeTable;
    }

   
    /**
    * To fetch all BusinessDirectory
    *
    * @param string $name
    * @return Entity
    */
   public function fetchAll($params){

      $this->getAdapter();


      $coremeal  =   $params->coremeal;
      $snacks    =   $params->snacks;
      $calories  =   $params->calories;
      $carbs     =   $params->carbs;
      $fats      =   $params->fats;
      $proteins  =   $params->proteins;
      
      $userId    =   $params->userId;

      $utilityObj = new \Application\Service\Utility();
      $locale     = $utilityObj->getLocale(!empty($locale)?$locale:'en');

      if($coremeal<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Core meal required');
      }

      if($calories<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Calorie  required');
      }

      if($carbs<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Carbs  required');
      }

      if($fats<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Fats  required');
      }

      if($proteins<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Proteins  required');
      }

      //$mealType = $this->getMealTypeTable()->fetchAll($userId,$locale);
      //print_r($mealType);

      $focus = array('PROTEIN','CARBOHYDRATE','OPTIONS');

      $results     =  array();
      $data        =  array();
      $debug       =  array();

      $proteinTot  =   0;
      $calorieTot  =   0;
      $carbTot     =   0;
      $fatTot      =   0;

      $finalProteinTot  =   0;
      $finalCalorieTot  =   0;
      $finalCarbTot     =   0;
      $finalFatTot      =   0;


      $breakfastProtienBal       = 0;
      $breakfastCarbsBal         = 0;
      $breakfastCalorieBal       = 0;
      $breakfastFatBal           = 0;
    

    
      $lunchProtienBal           = 0;
      $lunchCarbsBal             = 0;
      $lunchCalorieBal           = 0;
      $lunchFatBal               = 0;
    
    

   
      $dinnerProtienBal          = 0;
      $dinnerCarbsBal            = 0;
      $dinnerCalorieBal          = 0;
      $dinnerFatBal              = 0;
   
    

   
      $snacksProtienBal          = 0;
      $snacksCarbsBal            = 0;
      $snacksCalorieBal          = 0;
      $snacksFatBal              = 0;

      $carbItemCnt               = 0;
      $protienItemCnt            = 0;
    
      $h = 1 ;

      $reports                   = array();


      if($params->snacks>0){
          $cProteinFind = (($params->proteins*80/100)/$coremeal);
          $cCarbFind    = (($params->carbs*80/100)/$coremeal);

          $sProteinFind = (($params->proteins*20/100)/$snacks);
          $sCarbFind    = (($params->carbs*20/100)/$snacks);
      } else {
          $cProteinFind = (($params->proteins)/$coremeal);
          $cCarbFind    = (($params->carbs)/$coremeal);

          $sProteinFind = 0;
          $sCarbFind    = 0;
      }

      // echo $cProteinFind." ";
      // echo $cCarbFind." ";
      // echo $sProteinFind." ";
      // echo $sCarbFind." ";

      for($i=1;$i<=($coremeal+$snacks);$i++){

         

          if($i==1){
              $type      = "BREAKFAST";
              $mealType  = "Breakfast";
              $queryTale = 'AND focus="PROTEIN"';
              $dmpMealTypeSlug = 'coremeal';
              $dmpMealType = 'coremeal'.$i;

              if($params->snacks>0){
                    $proteinFind = (($params->proteins*80/100)/$coremeal);
                    $carbFind    = (($params->carbs*80/100)/$coremeal);
              } else {
                    $proteinFind = (($params->proteins)/$coremeal);
                    $carbFind    = (($params->carbs)/$coremeal);
              }

          } else if($i<=$coremeal){
              $type  = "LUNCH/DINNER";

              if($i==2){
                  $mealType  = "Lunch";
              } else {
                  $mealType  = "Dinner";
              }
              $queryTale = 'AND focus="PROTEIN"';
              $dmpMealTypeSlug = 'coremeal';
              $dmpMealType = 'coremeal'.$i;

              if($params->coremeal>0 and $params->snacks>0){
                    $proteinFind = (($params->proteins*80/100)/$snacks);
                    $carbFind    = (($params->carbs*80/100)/$snacks);
              } else if($params->snacks>0){
                    $proteinFind = (($params->proteins)/$snacks);
                    $carbFind    = (($params->carbs)/$snacks );
              }

          } else {
              $type      = "SNACKS";
              $mealType  = "Snacks";
              $queryTale = '';
              $dmpMealTypeSlug = 'snacks';
              $dmpMealType = 'snacks'.$h;
              $h++;

              if($params->snacks>0){
                    $proteinFind = (($params->proteins*20/100)/$coremeal);
                    $carbFind    = (($params->carbs*20/100)/$coremeal);
              }

          }

          $parent   = 0;
          $row_id   = 0;
          $mainType = 'main_meal';
          $meals    = $this->calculateMeal($type,$proteinFind,$carbFind,$queryTale,$mealType,$dmpMealType,$parent,$row_id,$mainType,$dmpMealTypeSlug);

          $results[] = $meals;
      }



      foreach ($results as $key => $result) {

          $data[$result[0]['fym_dmp_type']]['protien']  =   0;
          $data[$result[0]['fym_dmp_type']]['calorie']  =   0;
          $data[$result[0]['fym_dmp_type']]['carbs']    =   0;
          $data[$result[0]['fym_dmp_type']]['fat']      =   0;
          $data[$result[0]['fym_dmp_type']]['meal']     =   0;
          $data[$result[0]['fym_dmp_type']]['nonfixed'] =   0;
          $data[$result[0]['fym_dmp_type']]['fixed']    =   0;
          $data[$result[0]['fym_dmp_type']]['total']    =   0;
          $data[$result[0]['fym_dmp_type']]['protien_only']    =   0;
          $data[$result[0]['fym_dmp_type']]['carb_only']    =   0;
          $data[$result[0]['fym_dmp_type']]['protein_focus'] = 0;
          $data[$result[0]['fym_dmp_type']]['carb_focus']   = 0;


          foreach($result as $meal){
                   $data[$result[0]['fym_dmp_type']]['total']     +=   1;
                  if($meal['serving_size_fixed']==1){

                     // $data[$meal['fym_dmp_type']]['protien']  +=   $meal['protien'];
                     // $data[$meal['fym_dmp_type']]['calorie']  +=   $meal['calorie'];
                     // $data[$meal['fym_dmp_type']]['carbs']    +=   $meal['carbs'];
                     // $data[$meal['fym_dmp_type']]['fat']      +=   $meal['fat'];

                     // $proteinTot  +=   $meal['protien'];
                     // $calorieTot  +=   $meal['calorie'];
                     // $carbTot     +=   $meal['carbs'];
                     // $fatTot      +=   $meal['fat'];

                     //  $data[$result[0]['fym_dmp_type']]['fixed']     +=   1;
                  
                  } else {
                      // $minServingSize  = 0.25;
                      // $data[$meal['fym_dmp_type']]['protien']  +=  $minServingSize * $meal['protien'];
                      // $data[$meal['fym_dmp_type']]['calorie']  +=  $minServingSize *  $meal['calorie'];
                      // $data[$meal['fym_dmp_type']]['carbs']    +=  $minServingSize *  $meal['carbs'];
                      // $data[$meal['fym_dmp_type']]['fat']      +=  $minServingSize *  $meal['fat'];

                      // $proteinTot  +=   $minServingSize * $meal['protien'];
                      // $calorieTot  +=   $minServingSize * $meal['calorie'];
                      // $carbTot     +=   $minServingSize * $meal['carbs'];
                      // $fatTot      +=   $minServingSize * $meal['fat'];

                      // if($meal['protien']==0){
                      //     $data[$result[0]['fym_dmp_type']]['protien_only']    +=   1;
                      // }

                      // if($meal['carbs']==0){
                      //     $data[$result[0]['fym_dmp_type']]['carb_only']    +=   1;
                      // }

                      // if($meal['carbs'] < $meal['protien'] ){
                      //     $data[$result[0]['fym_dmp_type']]['protein_focus']    +=   1;
                      // }

                      // if($meal['carbs'] > $meal['protien'] ){
                      //     $data[$result[0]['fym_dmp_type']]['carb_focus']    +=   1;
                      // }

                      // $data[$result[0]['fym_dmp_type']]['nonfixed']     +=   1;
                  }

                     
                }

      }

      $proteinBal  = $params->proteins - $proteinTot;

      $carbBal     = $params->carbs    - $carbTot;

      $data['after_nonfix_pro_bal']['protein'] =$proteinBal;
      $data['after_nonfix_carb_bal']['protein'] =$carbBal;

      //print_r($data);
      $meals = array();


      foreach ($results as $key => $result) {
          $data[$result[0]['fym_dmp_type']]['protien']  =   0;
          $data[$result[0]['fym_dmp_type']]['calorie']  =   0;
          $data[$result[0]['fym_dmp_type']]['carbs']    =   0;
          $data[$result[0]['fym_dmp_type']]['fat']      =   0;

          $dmpType          =  $result[0]['fym_dmp_type'];
          $nonFixedItemCnt  =  $data[$dmpType]['nonfixed'];
          $protienNonfixed  =  $data[$result[0]['fym_dmp_type']]['protien_nonfixed']  =   0;
          $carbsNonfixed    =  $data[$result[0]['fym_dmp_type']]['carbs_nonfixed']  =   0;
          $proteinReq       =  $proteinBal/$params->coremeal+$params->snacks;
          $carbReq          =  $carbBal/$params->coremeal+$params->snacks;

          foreach($result as $mkey => $meal){
              if($meal['serving_size_fixed']==0 ){
                     if($meal['carbs'] <= $meal['protien'] and $meal['protien']>0){
                    
                        $servingSize  =  ($proteinBal/$meal['protien']);

                        if($servingSize>=0.25){
                            $data[$meal['fym_dmp_type']]['protien']  +=  $servingSize * $meal['protien'];
                            $data[$meal['fym_dmp_type']]['calorie']  +=  $servingSize *  $meal['calorie'];
                            $data[$meal['fym_dmp_type']]['carbs']    +=  $servingSize *  $meal['carbs'];
                            $data[$meal['fym_dmp_type']]['fat']      +=  $servingSize *  $meal['fat'];

                            $finalProteinTot  +=   $servingSize * $meal['protien'];
                            $finalCalorieTot  +=   $servingSize * $meal['calorie'];
                            $finalCarbTot     +=   $servingSize * $meal['carbs'];
                            $finalFatTot      +=   $servingSize * $meal['fat'];

                            $meal['serving_size'] = $servingSize; 

                            $meals[]   = $meal;
                        
                            $debug[] = array('fixed'=>'protein','name'=>$meal['name'],'calorie'=>$servingSize*$meal['calorie'],'protien'=>$servingSize * $meal['protien'],'carbs'=>$servingSize * $meal['carbs'],'fixed_serving_size'=>$meal['serving_size_fixed'],'serving_size'=>$servingSize,
                            'protien_'=>$meal['protien'],'carb_'=>$meal['carbs'],'calories_'=>$meal['calorie']);
                        } else {
                          $debug[] =$data[$meal['fym_dmp_type']];
                          unset($data[$meal['fym_dmp_type']]);
                        }
                    } else if($meal['carbs']>0){
                        $servingSize  =  ($carbBal/$meal['carbs']);

                        if($servingSize>=0.25){
                            $data[$meal['fym_dmp_type']]['protien']  +=  $servingSize * $meal['protien'];
                            $data[$meal['fym_dmp_type']]['calorie']  +=  $servingSize *  $meal['calorie'];
                            $data[$meal['fym_dmp_type']]['carbs']    +=  $servingSize *  $meal['carbs'];
                            $data[$meal['fym_dmp_type']]['fat']      +=  $servingSize *  $meal['fat'];

                            $finalProteinTot  +=   $servingSize * $meal['protien'];
                            $finalCalorieTot  +=   $servingSize * $meal['calorie'];
                            $finalCarbTot     +=   $servingSize * $meal['carbs'];
                            $finalFatTot      +=   $servingSize * $meal['fat'];

                            $meal['serving_size'] = $servingSize; 

                            $meals[]   = $meal;
                        
                            $debug[] = array('fixed'=>'carb','name'=>$meal['name'],'calorie'=>$servingSize*$meal['calorie'],'protien'=>$servingSize * $meal['protien'],'carbs'=>$servingSize * $meal['carbs'],'fixed_serving_size'=>$meal['serving_size_fixed'],'serving_size'=>$servingSize,
                            'protien_'=>$meal['protien'],'carb_'=>$meal['carbs'],'calories_'=>$meal['calorie']);
                        } else {

                          $debug[] =  $results[$key][$mkey];
                          unset($results[$key][$mkey]);
                        }
                    } else {
                        $debug[] =$results[$key][$mkey];
                         unset($results[$key][$mkey]);
                    }
                    //$nonFixedItemCnt--;
              } else {
                     // print_r($data);
                    $data[$dmpType]['protien']  +=   $meal['protien'];
                    $data[$dmpType]['calorie']  +=   $meal['calorie'];
                    $data[$dmpType]['carbs']    +=   $meal['carbs'];
                    $data[$dmpType]['fat']      +=   $meal['fat'];

                    $finalProteinTot  +=   $meal['protien'];
                    $finalCalorieTot  +=   $meal['calorie'];
                    $finalCarbTot     +=   $meal['carbs'];
                    $finalFatTot      +=   $meal['fat'];



                    $meals[]   = $meal;

                    $debug[] = array('fixed'=>1,'name'=>$meal['name'],'calorie'=>$servingSize*$meal['calorie'],'protien'=>$servingSize * $meal['protien'],'carbs'=>$servingSize * $meal['carbs'],'fixed_serving_size'=>$meal['serving_size_fixed'],'serving_size'=>$servingSize,
                            'protien_'=>$meal['protien'],'carb_'=>$meal['carbs'],'calories_'=>$meal['calorie']);
                       
              }
          }
      }

 



      $reports['last']['achived']['protein']    =    $finalProteinTot;
      $reports['last']['achived']['carb']       =    $finalCarbTot;
      $reports['last']['achived']['calorie']    =    $finalCalorieTot;
      $reports['last']['achived']['fat']        =    $finalFatTot;

      $reports['last']['requested']['protein']    =    $proteins;
      $reports['last']['requested']['carb']       =    $carbs;
      $reports['last']['requested']['calorie']    =    $calories;
      $reports['last']['requested']['fat']        =    $fats;

      $reports['data'] = $data;

      

      return array('results'=>$meals,'report'=>$reports,'debug'=>$debug);


    }

    public function calculateMeal($type,$proteinFind,$carbFind,$queryTale,$mealType,$dmpMealType,$parent,$row_id,$mainType,$dmpMealTypeSlug){
        $results = array();

        $query = "SELECT dmp_meal.*,IF(dmp_meal.serving_size>0,true,false) as serving_size_fixed FROM dmp_meal
                WHERE type='".$type."' $queryTale
                AND status_id=1
                ORDER BY RAND()
                LIMIT 1 ";
        $statement            =   $this->adapter->createStatement($query);

        $result               =   $statement->execute();
        $meal                 =   $result->getResource()->fetch(2);
        $meal['fym_dmp_type'] =   $dmpMealType;
        $meal['meal_type']    =   $mealType;
        $meal['parent']       =   $parent;
        $meal['row_id']       =   $row_id;
        $meal['type']         =   $mainType;
        $meal['when_delete']  =   $meal['id'];
        $meal['fym_dmp_slug'] =   $dmpMealTypeSlug;

        $results[]           =   $meal;


        if($proteinFind<=$meal['protien'] || $carbFind<=$meal['carbs']){
            return $results;
        } else {
            if(count($meal)>0){
                $mealId  =  $meal['id'];
                $mealDets = $this->getAddtMeal($mealId,$mealType,$mealId,$dmpMealType,$dmpMealTypeSlug);

                if(count($mealDets)>0){
                    foreach($mealDets as $mealDet){
                        $mealDet['when_delete'] = $mealId.",".$mealDet['id'];
                        $mealDet['type']        =   'second';//$mainType;
                        $results[]              = $mealDet;

                        $addDets = $this->getAddtMeal($mealDet['id'],$mealType,$mealId,$dmpMealType,$dmpMealTypeSlug);

                        
                          if(count($addDets)>0){
                              foreach ($addDets as $key => $addDet) {

                                  $addDet['when_delete']  = $mealId.",".$mealDet['id'].",".$addDet['id'];
                                  $mealDet['type']        = 'third';
                                  $results[]              = $addDet;
                              }
                          }
                    }
                }
            }
        }

        return $results;
    }

    public function getAddtMeal($mealId,$mealType,$parentId,$dmpMealType,$dmpMealTypeSlug){
        $this->getAdapter();
        $query = "SELECT dmp_meal.*,IF(dmp_meal.serving_size>0,true,false) as serving_size_fixed,row_id,dmp_meal_details.type FROM (select * from dmp_meal_details ORDER BY RAND()) as dmp_meal_details
                  JOIN dmp_meal ON dmp_meal.id  =  dmp_meal_details.assoc_meal_id
                  WHERE dmp_meal_id=$mealId
                  GROUP BY dmp_meal_details.type,row_id
                  ";
        $statement = $this->adapter->createStatement($query);

        $result = $statement->execute();
        $mealDets   = $result->getResource()->fetchAll(2);
        
        if(count($mealDets)>0){
          foreach($mealDets as $key => $mealDet){
              $mealDets[$key] = $mealDet;
              $mealDets[$key]['meal_type'] = $mealType;
              $mealDets[$key]['fym_dmp_type'] = $dmpMealType;
              $mealDets[$key]['parent']    = $mealId;
              $mealDets[$key]['fym_dmp_slug']    = $dmpMealTypeSlug;
              

              //echo $mealId."-";
          }
          return $mealDets;
        }

    }




  
}
