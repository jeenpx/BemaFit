<?php
namespace DailyMealPlan\V1\Rest\Refresh;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class RefreshResource extends AbstractResourceListener
{
    protected $mapper;
 
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }
    /**
     * Create a resource
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        return new ApiProblem(405, 'The POST method has not been defined');
    }

    /**
     * Delete a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function delete($id)
    {
        return new ApiProblem(405, 'The DELETE method has not been defined for individual resources');
    }

    /**
     * Delete a collection, or members of a collection
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        return new ApiProblem(405, 'The DELETE method has not been defined for collections');
    }

    /**
     * Fetch a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($id)
    {
        return new ApiProblem(405, 'The GET method has not been defined for individual resources');
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($params = array())
    {
        
        @$data->type        = $this->getEvent()->getRequest()->getQuery('type', 0);
        $data->meal_type    = $this->getEvent()->getRequest()->getQuery('meal_type', 0);
        $data->row_id       = $this->getEvent()->getRequest()->getQuery('row_id', 0);
        $data->meal_id      = $this->getEvent()->getRequest()->getQuery('meal_id', 0);
        $data->parent_id    = $this->getEvent()->getRequest()->getQuery('parent_id', 0);
        $data->dmp_meal_type= $this->getEvent()->getRequest()->getQuery('dmp_meal_type', 0);
        $data->locale       = $this->getEvent()->getRequest()->getQuery('locale', 0);
        
        //Added on 31/5/2016 to resolve refresh issue
        $data->nutritional_plan    = $this->getEvent()->getRequest()->getQuery('nutritional_plan', 0);
        $refresh = $this->mapper->fetchAll($data);


        return array(
                'meta'=>array('status'=>'ok','code'=>200,'method_name'=>'refresh daily meal plan',
                ),'result'=>$refresh);
        return new ApiProblem(405, 'The GET method has not been defined for collections');
    }

    /**
     * Patch (partial in-place update) a resource
     *
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        return new ApiProblem(405, 'The PATCH method has not been defined for individual resources');
    }

    /**
     * Replace a collection or members of a collection
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return new ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     *
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        return new ApiProblem(405, 'The PUT method has not been defined for individual resources');
    }
}
