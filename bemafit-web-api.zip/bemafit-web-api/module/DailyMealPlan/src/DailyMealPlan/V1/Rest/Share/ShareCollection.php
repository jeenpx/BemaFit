<?php
namespace DailyMealPlan\V1\Rest\Share;

use Zend\Paginator\Paginator;

class ShareCollection extends Paginator
{
}
