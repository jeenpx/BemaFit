<?php
namespace DailyMealPlan\V1\Rest\ImportMeal;

class ImportMealResourceFactory
{
    public function __invoke($services)
    {
    	$mapper = $services->get('DailyMealPlan\V1\Rest\ImportMealMapperTableGateway');
		return new ImportMealResource($mapper);
    }
}


