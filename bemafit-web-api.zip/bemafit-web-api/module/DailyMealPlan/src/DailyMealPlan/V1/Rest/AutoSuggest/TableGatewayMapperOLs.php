<?php

namespace DailyMealPlan\V1\Rest\AutoSuggest;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

   
    /**
    * To fetch all BusinessDirectory
    *
    * @param string $name
    * @return Entity
    */
   public function fetchAll($params){

      $this->getAdapter();


      $coremeal  =   $params->coremeal;
      $snacks    =   $params->snacks;
      $calories  =   $params->calories;
      $carbs     =   $params->carbs;
      $fats      =   $params->fats;
      $proteins  =   $params->proteins;

      if($coremeal<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Core meal required');
      }

      if($calories<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Calorie  required');
      }

      if($carbs<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Carbs  required');
      }

      if($fats<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Fats  required');
      }

      if($proteins<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Proteins  required');
      }


      $focus = array('PROTEIN','CARBOHYDRATE','OPTIONS');

      $results     =  array();
      $data        =  array();
      $debug       =  array();

      $proteinTot  =   0;
      $calorieTot  =   0;
      $carbTot     =   0;
      $fatTot      =   0;



      $breakfastProtienBal       = 0;
      $breakfastCarbsBal         = 0;
      $breakfastCalorieBal       = 0;
      $breakfastFatBal           = 0;
    

    
      $lunchProtienBal           = 0;
      $lunchCarbsBal             = 0;
      $lunchCalorieBal           = 0;
      $lunchFatBal               = 0;
    
    

   
      $dinnerProtienBal          = 0;
      $dinnerCarbsBal            = 0;
      $dinnerCalorieBal          = 0;
      $dinnerFatBal              = 0;
   
    

   
      $snacksProtienBal          = 0;
      $snacksCarbsBal            = 0;
      $snacksCalorieBal          = 0;
      $snacksFatBal              = 0;


      $nonFixedItemCnt          = 0;
      $fixedItemCnt             = 0;

      $protienItemCnt           = 0;
      $carbItemCnt              = 0;
    


      for($i=1;$i<=($coremeal+$snacks);$i++){

          if($snacks>=1){
              $coreMealPer  =   80;
              $snackPer     =   20;
          } else {
              $coreMealPer  =   100;
              $snackPer     =   0;
          }

          if($i==1){
              $type      = "BREAKFAST";
              $mealType  = "Breakfast";
              $queryTale = 'AND focus="PROTEIN"';
          } else if($i<=$coremeal){
              $type  = "LUNCH/DINNER";

              if($i==2){
                  $mealType  = "Lunch";
              } else {
                  $mealType  = "Dinner";
              }
              $queryTale = 'AND focus="PROTEIN"';
          } else {
              $type      = "SNACKS";
              $mealType  = "Snacks";
              $queryTale = '';
          }


          $query = "SELECT dmp_meal.*,IF(dmp_meal.serving_size>0,true,false) as serving_size_fixed FROM dmp_meal
                  WHERE type='".$type."' $queryTale
                  AND status_id=1
                  ORDER BY RAND()
                  LIMIT 1 ";
          $statement = $this->adapter->createStatement($query);

          $result = $statement->execute();
          $meal   = $result->getResource()->fetch(2);
          $meal['meal_type'] = $mealType;
          $meal['parent']    = "0";
          $meal['row_id']    = "0";
          $meal['type']      = 'main_meal';
          $meal['when_delete'] = $meal['id'];
          $meal['main_item']   = 1;

          $report['report']['batch'][$meal['id']]['protien'] =  $meal['protien'];
          $report['report']['batch'][$meal['id']]['calorie'] =  $meal['calorie'];
          $report['report']['batch'][$meal['id']]['carbs']   =  $meal['carbs'];
          $report['report']['batch'][$meal['id']]['fat']     =  $meal['fat'];
          

          $results[]     =   $meal;

          //print_r($meal);
          if($meal['serving_size_fixed']==1){
          
              $data[$mealType]['protien']  =   $meal['protien'];
              $data[$mealType]['calorie']  =   $meal['calorie'];
              $data[$mealType]['carbs']    =   $meal['carbs'];
              $data[$mealType]['fat']      =   $meal['fat'];

              $fixedItemCnt++;
          } else {
              $data[$mealType]['protien']  =   0;
              $data[$mealType]['calorie']  =   0;
              $data[$mealType]['carbs']    =   0;
              $data[$mealType]['fat']      =   0;

              $nonFixedItemCnt++;
          }


          if(count($meal)>0){
              $mealId  =  $meal['id'];
              $mealDets = $this->getAddtMeal($mealId,$mealType,$mealId);

              if(count($mealDets)>0){

                    foreach($mealDets as $mealDet){
                      
                      $mealDet['when_delete'] = $mealId.",".$mealDet['id'];

                      $report['report']['batch'][$mealId]['protien'] +=  $mealDet['protien'];
                      $report['report']['batch'][$mealId]['calorie'] +=  $mealDet['calorie'];
                      $report['report']['batch'][$mealId]['carbs']   +=  $mealDet['carbs'];
                      $report['report']['batch'][$mealId]['fat']     +=  $mealDet['fat'];

                      $results[]     =   $mealDet;

                      if($mealDet['serving_size_fixed']==1){

                          $data[$mealType]['protien']  +=   $mealDet['protien'];
                          $data[$mealType]['calorie']  +=   $mealDet['calorie'];
                          $data[$mealType]['carbs']    +=   $mealDet['carbs'];
                          $data[$mealType]['fat']      +=   $mealDet['fat'];

                          $fixedItemCnt++;
                      } else {
                          $nonFixedItemCnt++;
                      } 



                      $addDets = $this->getAddtMeal($mealDet['id'],$mealType,$mealId);

                      
                        if(count($addDets)>0){
                          foreach ($addDets as $key => $addDet) {

                                $addDet['when_delete'] = $mealId.",".$mealDet['id'].",".$addDet['id'];
                                $results[]    =   $addDet;

                                $report['report']['batch'][$mealId]['protien'] +=  $addDet['protien'];
                                $report['report']['batch'][$mealId]['calorie'] +=  $addDet['calorie'];
                                $report['report']['batch'][$mealId]['carbs']   +=  $addDet['carbs'];
                                $report['report']['batch'][$mealId]['fat']     +=  $addDet['fat'];

                                if($addDet['serving_size_fixed']==1){
                                    
                                    $data[$mealType]['protien']  +=   $addDet['protien'];
                                    $data[$mealType]['calorie']  +=   $addDet['calorie'];
                                    $data[$mealType]['carbs']    +=   $addDet['carbs'];
                                    $data[$mealType]['fat']      +=   $addDet['fat'];

                                    $fixedItemCnt++;
                                } else {
                                    $nonFixedItemCnt++;
                                }

                          }
                        }
                    }
              }
          }
      }

      $totalItem = $fixedItemCnt + $nonFixedItemCnt;

      foreach ($results as $key => $result) {

          if($result['carbs']>$result['protien']){

            if($carbTot>0){
                $minServingSize = $totalItem/($params->carbs-$carbTot);
            } else {
              $minServingSize = 1;
            }

            if($result['serving_size']==0){
              $carbItemCnt++;
            }
            $results[$key]['fym_focus'] = 'carb';
          } else {
            
            if($proteinTot>0){
                $minServingSize = $totalItem/($params->proteins - $proteinTot);
            } else {
              $minServingSize = 1;
            }
            if($result['serving_size']==0){
              $protienItemCnt++;
            }
            $results[$key]['fym_focus'] = 'protien';
          }

          

          if($result['serving_size']==0){

            if($minServingSize<0.25){
                $minServingSize = 0.25;
            }


            $proteinTot  +=   $minServingSize * $result['protien'];
            $calorieTot  +=   $minServingSize * $result['calorie'];
            $carbTot     +=   $minServingSize * $result['carbs'];
            $fatTot      +=   $minServingSize * $result['fat'];
            $results[$key]['serving_size']    = $minServingSize;

          } else {
            $proteinTot  +=   $result['protien'];
            $calorieTot  +=   $result['calorie'];
            $carbTot     +=   $result['carbs'];
            $fatTot      +=   $result['fat'];
          }

      }

      
      $minCarb    = $params->carbs-($params->carbs*10/100);
      $maxCarb    = $params->carbs+($params->carbs*10/100);

      $minProtien = $params->proteins-($params->proteins*10/100);
      $maxProtien = $params->proteins+($params->proteins*10/100);

      $minCalorie = $params->calories-($params->calories*10/100);
      $maxCalorie = $params->calories+($params->calories*10/100);


      if($proteinTot<$minProtien || $carbTot<$minCarb){
        $report['report']['final']['status']  = "nitrion are low";
      } else if($proteinTot>$maxProtien || $carbTot>$maxCarb){
        $report['report']['final']['status']  = "nitrion are high";

      } else {
        $report['report']['final']['status']  = "food_are_okay";
      }


      $results = $this->getAdjustMeal($results,array('res'=>$proteinTot,'req'=>$params->proteins,'min'=>($params->proteins-($params->proteins*10/100)),'max'=>($params->proteins+($params->proteins*10/100))),array('res'=>$carbTot,'req'=>$params->carbs,'min'=>($params->carbs-($params->carbs*10/100)),'max'=>($params->carbs+($params->carbs*10/100))),$nonFixedItemCnt,$protienItemCnt,$carbItemCnt);
      

      // if($proteinTot>$minProtien || $carbTot>$minCarb){
      //   $report['report']['final']['status']  = "exceeded";

      //   if($proteinTot>$carbTot){
      //      $report['report']['final']['status']  = "exceeded_protein";
      //   } else {
      //      $report['report']['final']['status']  = "exceeded_carb";
      //   }
      // } else {
      //   $report['report']['final']['status']  = "not exceeded";
      // }

      // print_r($results);
      // die('protein=>'.$proteinTot.'carb=>'.$carbTot.'calorie=>'.$calorieTot);


      $report['report']['final']['protien']  = $proteinTot;
      $report['report']['final']['carbs']    = $carbTot;
      $report['report']['final']['calories'] = $calorieTot;
      $report['report']['final']['fats']     = $fatTot;
      //$report['report']['final']['nonfixed'] = $tnonFixedItemCnt;
      //$report['report']['final']['fixed']    = $fixedItemCnt;
      $report['report']['final']['protien_req']  = array('res'=>$proteinTot,'req'=>$params->proteins,'min'=>($params->proteins-($params->proteins*10/100)),'max'=>($params->proteins+($params->proteins*10/100)));
      $report['report']['final']['carb_req']     = array('res'=>$carbTot,'req'=>$params->carbs,'min'=>($params->carbs-($params->carbs*10/100)),'max'=>($params->carbs+($params->carbs*10/100)));
      $report['report']['final']['cal_req']      = array('res'=>$calorieTot,'req'=>$params->calories,'min'=>($params->calories-($params->calories*10/100)),'max'=>($params->calories+($params->calories*10/100)));
    

      return array('results'=>$results,'report'=>$report,'debug'=>array());


    }

    public function getAdjustMeal($results,$protien=array(),$carb=array(),$nonFixedItemCnt,$protienItemCnt,$carbItemCnt){
        $proteinTot  = $protien['res'];
        $carbTot     = $carb['res'];

        $proteinReq  = $protien['req'];
        $carbReq     = $carb['req'];

        $proteinMin  = $protien['min'];
        $carbMin     = $carb['min'];

        $proteinMax  = $protien['max'];
        $carbMax     = $carb['max'];

        $report['report']['first']['protein']  = $proteinTot;
        $report['report']['first']['carb']     = $carbTot;


        $adjProteinTot = 0;
        $adjCalorieTot = 0;
        $adjCarbTot    = 0;
        $adjFatTot     = 0;

        if($proteinTot<$proteinMin){
            // "need more protein ".$nonFixedItemCnt;
            echo $protienItemCnt;
            echo "protien needed ";
            echo $needProtien = $proteinReq-$proteinTot;
            echo "protien per item ";
            echo $needProtienPerItem = $needProtien/$protienItemCnt;
            foreach ($results as $key => $result) {
              //echo $result['fym_focus'];
                if($result['fym_focus']=='protien' && $result['serving_size_fixed']==0){
                    $minServingSize =   $needProtienPerItem/$result['protien'];

                    if($minServingSize<0.25){
                        $minServingSize = 0.25;
                    }
                    
                    $adjProteinTot  +=   $minServingSize * $result['protien'];
                    $adjCalorieTot  +=   $minServingSize * $result['calorie'];
                    $adjCarbTot     +=   $minServingSize * $result['carbs'];
                    $adjFatTot      +=   $minServingSize * $result['fat'];
                    echo "<br/>";
                    echo $results[$key]['serving_size']    = $needProtienPerItem;

                } else if($result['serving_size_fixed']==0){
                    $adjProteinTot  +=   $result['serving_size'] * $result['protien'];
                    $adjCalorieTot  +=   $result['serving_size'] * $result['calorie'];
                    $adjCarbTot     +=   $result['serving_size'] * $result['carbs'];
                    $adjFatTot      +=   $result['serving_size'] * $result['fat'];
                } else {
                    $adjProteinTot  +=   $result['protien'];
                    $adjCalorieTot  +=   $result['calorie'];
                    $adjCarbTot     +=   $result['carbs'];
                    $adjFatTot      +=   $result['fat'];
                }
            }

        }

        print_r($results);
        $report['report']['final']['protien']  = $adjProteinTot;
        $report['report']['final']['carbs']    = $adjCarbTot;
        $report['report']['final']['calories'] = $adjCalorieTot;
        $report['report']['final']['fats']     = $adjFatTot;

        print_r($report);
        die('sma');
    }

    public function getAddtMeal($mealId,$mealType,$parentId){
        $this->getAdapter();
        $query = "SELECT dmp_meal.*,IF(dmp_meal.serving_size>0,true,false) as serving_size_fixed,row_id,dmp_meal_details.type FROM (select * from dmp_meal_details ORDER BY RAND()) as dmp_meal_details
                  JOIN dmp_meal ON dmp_meal.id  =  dmp_meal_details.assoc_meal_id
                  WHERE dmp_meal_id=$mealId
                  GROUP BY dmp_meal_details.type,row_id
                  ";
        $statement = $this->adapter->createStatement($query);

        $result = $statement->execute();
        $mealDets   = $result->getResource()->fetchAll(2);
        
        if(count($mealDets)>0){
          foreach($mealDets as $key => $mealDet){
              $mealDets[$key] = $mealDet;
              $mealDets[$key]['meal_type'] = $mealType;
              $mealDets[$key]['parent']    = $mealId;
              //echo $mealId."-";
          }
          return $mealDets;
        }

    }




  
}
