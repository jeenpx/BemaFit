<?php
namespace DailyMealPlan\V1\Rest\MealType;

class MealTypeEntity
{
}
