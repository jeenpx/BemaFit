<?php
namespace DailyMealPlan\V1\Rest\ImportMeal;

class ImportMealEntity
{
}
