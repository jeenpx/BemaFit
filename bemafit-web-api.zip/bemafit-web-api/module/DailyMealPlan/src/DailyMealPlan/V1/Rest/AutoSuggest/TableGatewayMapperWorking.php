<?php

namespace DailyMealPlan\V1\Rest\AutoSuggest;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    public function getMealTypeTable()
    {
        $sm = $this->getServiceLocator();
        $this->MealTypeTable = $sm->get('MealType\V1\Rest\MealTypeMapperTableGateway');
        return $this->MealTypeTable;
    }

   
    /**
    * To fetch all BusinessDirectory
    *
    * @param string $name
    * @return Entity
    */
   public function fetchAll($params){

      $this->getAdapter();


      $coremeal  =   $params->coremeal;
      $snacks    =   $params->snacks;
      $calories  =   $params->calories;
      $carbs     =   $params->carbs;
      $fats      =   $params->fats;
      $proteins  =   $params->proteins;
      
      $userId    =   $params->userId;

      $utilityObj = new \Application\Service\Utility();
      $locale     = $utilityObj->getLocale(!empty($locale)?$locale:'en');

      if($coremeal<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Core meal required');
      }

      if($calories<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Calorie  required');
      }

      if($carbs<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Carbs  required');
      }

      if($fats<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Fats  required');
      }

      if($proteins<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Proteins  required');
      }

      //$mealType = $this->getMealTypeTable()->fetchAll($userId,$locale);
      //print_r($mealType);

      $focus = array('PROTEIN','CARBOHYDRATE','OPTIONS');

      $results     =  array();
      $data        =  array();
      $debug       =  array();

      $proteinTot  =   0;
      $calorieTot  =   0;
      $carbTot     =   0;
      $fatTot      =   0;



      $breakfastProtienBal       = 0;
      $breakfastCarbsBal         = 0;
      $breakfastCalorieBal       = 0;
      $breakfastFatBal           = 0;
    

    
      $lunchProtienBal           = 0;
      $lunchCarbsBal             = 0;
      $lunchCalorieBal           = 0;
      $lunchFatBal               = 0;
    
    

   
      $dinnerProtienBal          = 0;
      $dinnerCarbsBal            = 0;
      $dinnerCalorieBal          = 0;
      $dinnerFatBal              = 0;
   
    

   
      $snacksProtienBal          = 0;
      $snacksCarbsBal            = 0;
      $snacksCalorieBal          = 0;
      $snacksFatBal              = 0;

      $carbItemCnt               = 0;
      $protienItemCnt            = 0;
    
        echo "786";


    }



  
}
