<?php
namespace DailyMealPlan\V1\Rest\ImportMeal;

use Zend\Paginator\Paginator;

class ImportMealCollection extends Paginator
{
}
