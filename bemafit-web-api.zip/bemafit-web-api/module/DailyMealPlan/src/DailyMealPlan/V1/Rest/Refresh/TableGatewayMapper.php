<?php

namespace DailyMealPlan\V1\Rest\Refresh;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    public function getDMPAutosuggest()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('DailyMealPlan\V1\Rest\AutoSuggestMapperTableGateway');
        return $this->Table;
    }

   
    /**
    * To fetch all BusinessDirectory
    *
    * @param string $name
    * @return Entity
    */
   
    public function fetchAll($params){
        
        $this->getAdapter();
        $mealType   =   $params->meal_type;
        $mealId     =   $params->meal_id;
        $parentId   =   $params->parent_id;
        $rowId      =   $params->row_id;
        $type       =   $params->type;
        $dmpMealType=   $params->dmp_meal_type;
        $locale     =   $params->locale;
        $nutritionalPlan = $params->nutritional_plan;


        $query = "SELECT focus as meal_focus,type as meal_type
              FROM  dmp_meal 
              WHERE id=$mealId 
              
              ";

        $statement = $this->adapter->createStatement($query);

        $result = $statement->execute();
        $meal   = $result->getResource()->fetch(2);


        $query = "SELECT dmp_meal.*
              FROM dmp_meal 
              WHERE focus='".$meal['meal_focus']."' AND type='".$meal['meal_type']."' 
              AND nutritional_plan = '".$nutritionalPlan."'
              ORDER BY RAND()
              LIMIT 1 
              ";
        $statement = $this->adapter->createStatement($query);

        $result = $statement->execute();
        $mealDets   = $result->getResource()->fetch(2);

        if(!empty($mealDets)){
              $mealDets['meal_type']     = $mealType;
              $mealDets['parent']        = $parentId;
              $mealDets['row_id']        = $rowId;
              $mealDets['type']          = $type;
              $mealDets['fym_dmp_type']  = $dmpMealType;
              $mealDets['when_delete']   = $parentId.",".$mealDets['id'];

              if($locale=='es' && isset($mealDets['id']) && $mealDets['name_es']!=''){
                $mealDets['name'] =$mealDets['name_es'];
              }

            $results[] = $mealDets;
        } else {
            $results = array();
        }


        return $results;
            


    }
   
    public function fetchAllOLD($params){

        $this->getAdapter();

        ///validatiom for type

        $mealType   =   $params->meal_type;
        $mealId     =   $params->meal_id;
        $parentId   =   $params->parent_id;
        $rowId      =   $params->row_id;
        $type       =   $params->type;
        $dmpMealType=   $params->dmp_meal_type;
        $results    =   array();

        $proteinTot  =   0;
        $calorieTot  =   0;
        $carbTot     =   0;
        $fatTot      =   0;

        if($parentId==0){

          if($mealType=='Breakfast'){
              $type      = "BREAKFAST";
              $queryTale = 'AND focus="PROTEIN"';
          } else if($mealType=='Lunch' || $mealType=='Dinner'){
              $type  = "LUNCH/DINNER";
              $queryTale = 'AND focus="PROTEIN"';
          } else if($mealType=="Snacks"){
              $type      = "SNACKS";
              $queryTale = '';
          }


          $query = "SELECT dmp_meal.* FROM dmp_meal
                  WHERE type='".$type."' $queryTale
                  AND status_id=1
                  ORDER BY RAND()
                  LIMIT 1 ";
          $statement = $this->adapter->createStatement($query);

          $result = $statement->execute();
          $meal   = $result->getResource()->fetch(2);

          $meal['fym_dmp_type'] = $dmpMealType;
          $meal['meal_type'] = $mealType;
          $meal['parent']    = 0;
          $meal['row_id']    = 0;
          $meal['type']      = 'main_meal';
          $meal['when_delete'] = $meal['id'];

          $results[] = $meal;

          $proteinTot  +=   $meal['protien'];
          $calorieTot  +=   $meal['calorie'];
          $carbTot     +=   $meal['carbs'];
          $fatTot      +=   $meal['fat'];

          $data[$mealType]['protien']  =   $meal['protien'];
          $data[$mealType]['calorie']  =   $meal['calorie'];
          $data[$mealType]['carbs']    =   $meal['carbs'];
          $data[$mealType]['fat']      =   $meal['fat'];

          if(count($meal)>0){
              $mealId  =  $meal['id'];
              $mealDets = $this->getDMPAutosuggest()->getAddtMeal($mealId,$mealType,$mealId,'',$dmpMealType);

              if(count($mealDets)>0){

                    foreach($mealDets as $mealDet){

                      $mealDet['when_delete'] = $mealId.",".$mealDet['id'];

                      $results[]    =   $mealDet;

                      $proteinTot  +=   $mealDet['protien'];
                      $calorieTot  +=   $mealDet['calorie'];
                      $carbTot     +=   $mealDet['carbs'];
                      $fatTot      +=   $mealDet['fat'];

                      $data[$mealType]['protien']  +=   $mealDet['protien'];
                      $data[$mealType]['calorie']  +=   $mealDet['calorie'];
                      $data[$mealType]['carbs']    +=   $mealDet['carbs'];
                      $data[$mealType]['fat']      +=   $mealDet['fat'];


                      $addDets = $this->getDMPAutosuggest()->getAddtMeal($mealDet['id'],$mealType,$mealId,'',$dmpMealType);

                      
                        if(count($addDets)>0){
                          foreach ($addDets as $key => $addDet) {

                                $addDet['when_delete'] = $mealId.",".$mealDet['id'].",".$addDet['id'];

                                $results[]    =   $addDet;
                                $proteinTot  +=   $addDet['protien'];
                                $calorieTot  +=   $addDet['calorie'];
                                $carbTot     +=   $addDet['carbs'];
                                $fatTot      +=   $addDet['fat'];

                                $data[$mealType]['protien']  +=   $addDet['protien'];
                                $data[$mealType]['calorie']  +=   $addDet['calorie'];
                                $data[$mealType]['carbs']    +=   $addDet['carbs'];
                                $data[$mealType]['fat']      +=   $addDet['fat'];

                          }
                        }
                    }
              }
          }

          return $results;
          ////////////////////////////////////////

        } else {

            $query = "SELECT dmp_meal.*,row_id,dmp_meal_details.type FROM (select * from dmp_meal_details WHERE row_id=$rowId ORDER BY RAND()) as dmp_meal_details
              JOIN dmp_meal ON dmp_meal.id  =  dmp_meal_details.assoc_meal_id
              WHERE dmp_meal_id=$parentId and assoc_meal_id!=$mealId
              ORDER BY RAND()
              LIMIT 1 
              ";
            $statement = $this->adapter->createStatement($query);

            $result = $statement->execute();
            $mealDets   = $result->getResource()->fetch(2);


            if(count($mealDets)>0){
              $mealDets['meal_type'] = $mealType;
              $mealDets['parent']    = $parentId;
              $mealDets['row_id']        = $rowId;
              $mealDets['type']          = $type;
              $mealDets['fym_dmp_type']          = $dmpMealType;
              $mealDets['when_delete']   = $parentId.",".$mealDets['id'];
            } else {

              $query = "SELECT dmp_meal.*,row_id,dmp_meal_details.type FROM (select * from dmp_meal_details WHERE row_id=$rowId ORDER BY RAND()) as dmp_meal_details
                JOIN dmp_meal ON dmp_meal.id  =  dmp_meal_details.assoc_meal_id
                WHERE dmp_meal_id=$parentId 
                ORDER BY RAND()
                LIMIT 1 
                ";
              $statement = $this->adapter->createStatement($query);

              $result = $statement->execute();
              $mealDets   = $result->getResource()->fetch(2);

              if(count($mealDets)>0){
                $mealDets['meal_type'] = $mealType;
                $mealDets['parent']    = $parentId;
                $mealDets['row_id']        = $rowId;
                $mealDets['type']          = $type;
                $mealDets['fym_dmp_type']          = $dmpMealType;
                $mealDets['when_delete']   = $parentId.",".$mealDets['id'];
              }
            }

            $results[] = $mealDets;

            $recs = $this->getDMPAutosuggest()->getAddtMeal($mealDets['id'],$mealType,$mealId,'',$dmpMealType);

            if(count($recs)>0){
                foreach($recs as $rec){
                    $rec['when_delete'] = $parentId.",".$mealDets['id'].",".$rec['id'];
                    $rec['fym_dmp_type'] = $dmpMealType;
                    $results[] = $rec;
                }
            }
        }

        return $results;


    }

    public function fetchAllOLd2($params){

      $this->getAdapter();
      
      $type     =   $params->type;
      $genre    =   $params->genre;
      
      $carbs     =   $params->carbs;
      $fats      =   $params->fats;
      $proteins  =   $params->proteins;
      $calories  =   $params->calories;

      $genres = array('Protein','Carbohydrate','Additional');
      $types  = array('Breakfast','LunchDinner','Snacks');

      if($type=='' || !in_array($type, $types)){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Meal type required');
      }

      if($genre=='' || !in_array($genre, $genres)){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Genre  required');
      }

      if($carbs<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Carbs  required');
      }

      if($fats<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Fats  required');
      }

      if($proteins<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Proteins  required');
      }

      $query = "SELECT dmp_meal.* FROM dmp_meal
      WHERE type='".$type."' AND genre='".$genre."' 
      AND protien<=".($proteins)." AND calorie<=".($calories)." AND carbs<=".($carbs)." AND fat<=".($fats)."
      AND status_id=1
      ORDER BY RAND()
      LIMIT 1 ";

      $statement = $this->adapter->createStatement($query);

      $result = $statement->execute();
      $rows   = $result->getResource()->fetchAll(2);

      return $rows;

      
    }



  
}
