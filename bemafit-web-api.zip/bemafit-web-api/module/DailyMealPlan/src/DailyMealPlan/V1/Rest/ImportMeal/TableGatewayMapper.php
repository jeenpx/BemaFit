<?php

namespace DailyMealPlan\V1\Rest\ImportMeal;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    public function getDmpMealDetTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('DailyMealPlan\Model\DmpMealDetailTable');
        return $this->Table;
    }

   
    /**
    * To fetch all BusinessDirectory
    *
    * @param string $name
    * @return Entity
    */
   

  public function fetchAllTest(){

        $folder = 'public/data/final/';

        $files = scandir($folder);

        foreach ($files as $key => $file) {
          if($file!='.DS_Store' and $file!='.' and $file!='..'){
              echo $file."----->";




              if (is_file($folder.$file)){
                  $file1 = fopen($folder.$file, "r");

                  while (!feof($file1)) {
                      $raw_data = fgetcsv($file1);

                      if($raw_data[0]!=""){

                            $apiData['id']               = trim($raw_data[0]);
                            $apiData['guid']             = md5(uniqid(rand(), true));
                            $apiData['name']             = trim($raw_data[1]);
                            $apiData['name_es']          = trim($raw_data[2]);


                            preg_match_all('!\d+\.*\d*!',$raw_data[4],$match);

                            if(count($match[0])>0){  

                                $apiData['serving_size']     = $match[0][0];
                            } else {
                                $apiData['serving_size']     = 0;
                            }
                            
                            $apiData['brand']            = trim($raw_data[5]);
                            $apiData['unit']             = trim($raw_data[9]);
                            
                            
                            
                            // echo $raw_data[6];
                            // echo "<br />";

                            
                            


                            $apiData['calorie']          = trim($raw_data[10]);
                            $apiData['fat']              = trim($raw_data[11]);
                            $apiData['saturated']        = floatval($raw_data[12]);
                            $apiData['polyunsaturated']  = floatval($raw_data[13]);
                            $apiData['monounsaturated']  = floatval($raw_data[14]);
                            $apiData['trans']            = floatval($raw_data[15]);
                            $apiData['cholesterol']      = floatval($raw_data[16]);
                            $apiData['sodium']           = floatval($raw_data[17]);
                            $apiData['potassium']        = floatval($raw_data[18]);
                            $apiData['carbs']            = floatval($raw_data[19]);
                            $apiData['fiber']            = floatval($raw_data[20]);
                            $apiData['sugar']            = floatval($raw_data[21]);
                            $apiData['protien']          = floatval($raw_data[22]);
                            $apiData['vitamin_a']        = floatval($raw_data[23]);
                            $apiData['vitamin_c']        = floatval(!empty($raw_data[24])?$raw_data[24]:0);
                            $apiData['calcium']          = floatval(!empty($raw_data[25])?$raw_data[25]:0);
                            $apiData['iron']             = floatval(!empty($raw_data[26])?$raw_data[26]:0);

                            //$apiData['auto_choice']      = !empty($auto_choice)?substr($auto_choice,1):'';
                            //$apiData['pairing_food']      = !empty($pairing_food)?substr($pairing_food,1):'';

                            
                            // $apiData['type']             = trim($raw_data[27]);
                            // $apiData['focus']            = trim($raw_data[28]);
                            
                            $apiData['status_id']        = 1;
                            $apiData['created_date']     = gmdate('Y-m-d H:i:s');

                            //$this->table->insert($apiData);
                            //$mealId = $this->table->lastInsertValue;


                            print_r($apiData);

                      }
                  }
              }


          }
      }


      
  }
   

  public function fetchAll($params){

        $this->getAdapter();
        ini_set('max_execution_time', 0); //300 seconds = 5 minutes

        $sql='truncate dmp_meal';

        $statement = $this->adapter->createStatement($sql);

        $result = $statement->execute();

        $sql='truncate dmp_meal_details';

        $statement = $this->adapter->createStatement($sql);

        $result = $statement->execute();

        $folder = 'public/data/final/';

        $files = scandir($folder);

        foreach ($files as $key => $file) {
          if($file!='.DS_Store' and $file!='.' and $file!='..'){
              echo $file."----->";


              if ($file=='Flexible Dieting.csv') {
                $nutritional_plan = 1;
              } elseif ($file=='Paleo.csv') {
                $nutritional_plan = 4;
              } elseif ($file=='Vegan.csv') {
                $nutritional_plan = 3;
              }

              if (is_file($folder.$file)){
                  $file1 = fopen($folder.$file, "r");

                  while (!feof($file1)) {
                      $raw_data = fgetcsv($file1);

                      if($raw_data[0]!=""){
                        //print_r($raw_data);
                            //echo $apiData['name']."<br/>";
                            //$apiData['id']               = trim($raw_data[0]);
                            $apiData['guid']             = md5(uniqid(rand(), true));
                            $apiData['name']             = trim($raw_data[1]);
                            $apiData['name_es']          = trim($raw_data[2]);

                            preg_match_all('!\d+\.*\d*!',$raw_data[4],$match);

                            if(count($match[0])>0){  

                                $apiData['serving_size']     = $match[0][0];
                            } else {
                                $apiData['serving_size']     = 0;
                            }
                            
                            $apiData['brand']            = trim($raw_data[5]);
                            $apiData['unit']             = trim($raw_data[9]);
                            $apiData['nutritional_plan'] = $nutritional_plan;                         

                            $apiData['calorie']          = trim($raw_data[10]);
                            $apiData['fat']              = trim($raw_data[11]);
                            $apiData['saturated']        = floatval($raw_data[12]);
                            $apiData['polyunsaturated']  = floatval($raw_data[13]);
                            $apiData['monounsaturated']  = floatval($raw_data[14]);
                            $apiData['trans']            = floatval($raw_data[15]);
                            $apiData['cholesterol']      = floatval($raw_data[16]);
                            $apiData['sodium']           = floatval($raw_data[17]);
                            $apiData['potassium']        = floatval($raw_data[18]);
                            $apiData['carbs']            = floatval($raw_data[19]);
                            $apiData['fiber']            = floatval($raw_data[20]);
                            $apiData['sugar']            = floatval($raw_data[21]);
                            $apiData['protien']          = floatval($raw_data[22]);
                            $apiData['vitamin_a']        = floatval($raw_data[23]);
                            $apiData['vitamin_c']        = floatval(!empty($raw_data[24])?$raw_data[24]:0);
                            $apiData['calcium']          = floatval(!empty($raw_data[25])?$raw_data[25]:0);
                            $apiData['iron']             = floatval(!empty($raw_data[26])?$raw_data[26]:0);

                            //$apiData['auto_choice']      = !empty($auto_choice)?substr($auto_choice,1):'';
                            //$apiData['pairing_food']      = !empty($pairing_food)?substr($pairing_food,1):'';

                            
                            $apiData['type']             = trim($raw_data[27]);
                            $apiData['focus']            = trim($raw_data[28]);
                            
                            $apiData['status_id']        = 1;
                            $apiData['created_date']     = gmdate('Y-m-d H:i:s');

                            $this->table->insert($apiData);
                            $mealId = $this->table->lastInsertValue;


                            

                            $auto_choice = '';
                            $row_id =1;
                            /////////////////////////////////////////////////////
                            /// AUTO SELECTING FOOD
                            if(substr_count ($raw_data[6], '-')>0){
                                if(substr_count ($raw_data[6], ',')>0){
                                  $raw_data[6]       = explode(",",$raw_data[6]);

                                  if(count($raw_data[6])>0){
                                      foreach ($raw_data[6] as $value) {
                                         if(substr_count ($value, '-')>0){
                                            $res =  explode("-",$value);
                                            for($i=$res[0];$i<=$res[1];$i++){
                                                //$auto_choice = $auto_choice.','.$i;
                                                $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'auto_choice','row_id'=>$row_id,'assoc_meal_id'=>$i));
                                            }
                                         } else {
                                            //$auto_choice = $auto_choice.','.$value;  
                                            $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'auto_choice','row_id'=>$row_id,'assoc_meal_id'=>$value));
              
                                         }
                                         $row_id++;
                                      }
                                  }
                                } else {
                                  $res =  explode("-",$raw_data[6]);
                                   for($i=$res[0];$i<=$res[1];$i++){
                                      //$auto_choice = $auto_choice.','.$i;
                                      $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'auto_choice','row_id'=>$row_id,'assoc_meal_id'=>$i));
                                      //$row_id++;
                                   }
                                }
                            } else {
                              $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'auto_choice','row_id'=>$row_id,'assoc_meal_id'=>$raw_data[6]));

                              //echo $raw_data[5];
                            }

                            ////////////////////////////////////////////////////
                            


                            $pairing_food = '';
                            $row_id =1;
                            if(substr_count ($raw_data[7], '-')>0){
                               if(substr_count ($raw_data[7], ',')>0){
                                  $raw_data[7]       = explode(",",$raw_data[7]);

                                  if(count($raw_data[7])>0){
                                    foreach ($raw_data[7] as $value) {
                                         if(substr_count ($value, '-')>0){
                                            $res =  explode("-",$value);
                                            for($i=$res[0];$i<=$res[1];$i++){
                                                //$pairing_food = $pairing_food.','.$i;
                                                $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'pairing_food','row_id'=>$row_id,'assoc_meal_id'=>$i));
                                                
                                            }
                                         } else {
                                            //$pairing_food = $pairing_food.','.$value;    
                                            $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'pairing_food','row_id'=>$row_id,'assoc_meal_id'=>$value));

                                         }
                                         $row_id++;
                                      }
                                  } else {

                                     $res =  explode("-",$raw_data[7]);
                                     for($i=$res[0];$i<=$res[1];$i++){
                                        $pairing_food = $pairing_food.','.$i;
                                     }
                                  }
                               } else {
                                  $raw_data[7]       = explode("OR",$raw_data[7]);
                                
                                  if(count($raw_data[7])>0){
                                      foreach ($raw_data[7] as $fkey => $res) {
                                          $res =  explode("-",$res);
                                          if(count($res)>1){
                                            for($i=$res[0];$i<=$res[1];$i++){
                                              $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'pairing_food','row_id'=>$row_id,'assoc_meal_id'=>$i));
                                                                         
                                            }
                                          } else if(count($res)>0){
                                              $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'pairing_food','row_id'=>$row_id,'assoc_meal_id'=>$res[0]));

                                          }
                                      }
                                    
                                  } else {
                                    $res =  explode("-",$raw_data[7]);

                                    for($i=$res[0];$i<=$res[1];$i++){
                                      $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'pairing_food','row_id'=>$row_id,'assoc_meal_id'=>$i));
                                                                 
                                    }
                                     
                                  }
                                  $row_id++;
                               }
                            } else {
                                  $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'pairing_food','row_id'=>$row_id,'assoc_meal_id'=>$raw_data[7]));

                            }

                            //print_r($raw_data);
                            //
                            //
                        
                          $pairing_snack = '';
                          $row_id =1;
                          if(substr_count ($raw_data[8], '-')>0){
                             if(substr_count ($raw_data[8], ',')>0){
                                $raw_data[8]       = explode(",",$raw_data[8]);

                                if(count($raw_data[8])>0){
                                  foreach ($raw_data[8] as $value) {
                                       if(substr_count ($value, '-')>0){
                                          $res =  explode("-",$value);
                                          for($i=$res[0];$i<=$res[1];$i++){
                                              //$pairing_snack = $pairing_snack.','.$i;
                                              $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'pairing_snack','row_id'=>$row_id,'assoc_meal_id'=>$i));
                                              
                                          }
                                       } else {
                                          //$pairing_snack = $pairing_snack.','.$value;    
                                          $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'pairing_snack','row_id'=>$row_id,'assoc_meal_id'=>$value));

                                       }
                                       $row_id++;
                                    }
                                } else {
                                   $res =  explode("-",$raw_data[8]);
                                   for($i=$res[0];$i<=$res[1];$i++){
                                      $pairing_snack = $pairing_snack.','.$i;
                                   }
                                }
                             } else {
                                $res =  explode("-",$raw_data[8]);

                                for($i=$res[0];$i<=$res[1];$i++){
                                  $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'pairing_snack','row_id'=>$row_id,'assoc_meal_id'=>$i));
                                                             
                                }
                                $row_id++; 
                             }
                          } else {
                                $this->getDmpMealDetTable()->create(array('dmp_meal_id'=>$mealId,'type'=>'pairing_snack','row_id'=>$row_id,'assoc_meal_id'=>$raw_data[8]));

                          }

                



                      } else {
                       //print_r($raw_data);
                      }
                  }
                  fclose($file1);
              } else {
                echo "nge";
              }










          }
             
        }

      
        die('done!!!');
  }
   

    public function fetchAll1($params){

        $this->getAdapter();
        ini_set('max_execution_time', 0); //300 seconds = 5 minutes

        $sql='truncate dmp_meal';

        $statement = $this->adapter->createStatement($sql);

        $result = $statement->execute();


        $dir='public/data/Daily Meal Palns 2/';

        // Open a directory, and read its contents
        if (is_dir($dir)){
          if ($dh = opendir($dir)){
            while (($file = readdir($dh)) !== false){
                if($file!='.' && $file!='..' and $file!='.DS_Store'){
                    
                    echo $file.'----' ;

                    //------------------------------------------------------
                    
                    $i = 1;

                    $file1 = fopen($dir.$file, "r");

        while (!feof($file1)) {
            $raw_data = fgetcsv($file1);
            if ($raw_data[2]!="" and $raw_data[2]!="NAMW" and $raw_data[2]!="NAME") {
                //echo $i;
               
               //print_r($raw_data);
               //echo  $raw_data[1];
               
               //echo trim($raw_data[1]);

                if(trim($raw_data[1])=='(Core Choice - Protein)') {
                    $genre = 'Protein';
                } else if(trim($raw_data[1])=='(Core Choice - Carbohydrate)'){
                    $genre = 'Carbohydrate';
                } else if(trim($raw_data[1])=='(Additional Option)'){
                    $genre = 'Additional';
                } else if(trim($raw_data[1])!=''){
                    $genre = $raw_data[1];
                } else {
                    $genre = str_replace(".csv", "",$file);
                }


               $apiData['genre']            = $genre;
               //$apiData['type']             = 'BREAKFAST';
               $apiData['type']             = str_replace(".csv", "",$file) ;


               $apiData['guid']             = md5(uniqid(rand(), true));
               $apiData['name']             = $raw_data[2];
               $apiData['brand']            = $raw_data[3];
               //echo $raw_data[4];
               $apiData['serving_size']    = !empty($raw_data[4])?floatval($raw_data[4]):0;
               $apiData['unit']            = !empty($raw_data[5])?$raw_data[5]:'';


               $apiData['calorie']          = floatval($raw_data[6]);
               $apiData['fat']              = floatval($raw_data[7]);
               $apiData['saturated']        = floatval($raw_data[8]);
               $apiData['polyunsaturated']  = floatval($raw_data[9]);
               $apiData['monounsaturated']  = floatval($raw_data[10]);
               $apiData['trans']            = floatval($raw_data[11]);
               $apiData['cholesterol']      = floatval($raw_data[12]);
               $apiData['sodium']           = floatval($raw_data[13]);
               $apiData['potassium']        = floatval($raw_data[14]);
               $apiData['carbs']            = floatval($raw_data[15]);
               $apiData['fiber']            = floatval($raw_data[16]);
               $apiData['sugar']            = floatval($raw_data[17]);
               $apiData['protien']          = floatval($raw_data[18]);
               $apiData['vitamin_a']        = floatval($raw_data[19]);
               $apiData['vitamin_c']        = floatval(!empty($raw_data[20])?$raw_data[20]:0);
               $apiData['calcium']          = floatval(!empty($raw_data[21])?$raw_data[21]:0);
               $apiData['iron']             = floatval(!empty($raw_data[22])?$raw_data[22]:0);


               $apiData['status_id']        = 1;
               $apiData['created_date']     = gmdate('Y-m-d H:i:s');

               $this->table->insert($apiData);

               
            }

            $i++;
            
        }

                    //-------------------------------------------------------
                }
                
            }
            closedir($dh);
          }
        }




        die('done');

        

    }



    public function fetchAllold($params)
    {

        $this->getAdapter();

       


        ini_set('max_execution_time', 0); //300 seconds = 5 minutes

        $file_path='public/data/Daily Meal Palns 2/Snack-Table 1.csv';

        $file = fopen($file_path, "r");

        // echo "<pre>";
        // print_r(fgetcsv($file));
        // echo "</pre>";
        // 
        $sql='truncate dmp_meal';

        //$statement = $this->adapter->createStatement($sql);

        //$result = $statement->execute();

        $i = 1;

        while (!feof($file)) {
            $raw_data = fgetcsv($file);
            if ($raw_data[2]!="" and $raw_data[2]!="NAMW" and $raw_data[2]!="NAME") {
                //echo $i;
               
               //print_r($raw_data);
               //echo  $raw_data[1];
               
               //echo trim($raw_data[1]);

                if(trim($raw_data[1])=='(Core Choice - Protein)') {
                    $genre = 'Protein';
                } else if(trim($raw_data[1])=='(Core Choice - Carbohydrate)'){
                    $genre = 'Carbohydrate';
                } else if(trim($raw_data[1])=='(Additional Option)'){
                    $genre = 'Additional';
                } else {
                    $genre = 'Snack';
                }


               $apiData['genre']            = $genre;
               //$apiData['type']             = 'BREAKFAST';
               $apiData['type']             = 'Snack';


               $apiData['guid']             = md5(uniqid(rand(), true));
               $apiData['name']             = $raw_data[2];
               $apiData['brand']            = $raw_data[3];
               //echo $raw_data[4];
               $apiData['serving_size']    = !empty($raw_data[4])?$raw_data[4]:'';
               $apiData['calorie']          = floatval($raw_data[5]);
               $apiData['fat']              = floatval($raw_data[6]);
               $apiData['saturated']        = floatval($raw_data[7]);
               $apiData['polyunsaturated']  = floatval($raw_data[8]);
               $apiData['monounsaturated']  = floatval($raw_data[9]);
               $apiData['trans']            = floatval($raw_data[10]);
               $apiData['cholesterol']      = floatval($raw_data[11]);
               $apiData['sodium']           = floatval($raw_data[12]);
               $apiData['potassium']        = floatval($raw_data[13]);
               $apiData['carbs']            = floatval($raw_data[14]);
               $apiData['fiber']            = floatval($raw_data[15]);
               $apiData['sugar']            = floatval($raw_data[16]);
               $apiData['protien']          = floatval($raw_data[17]);
               $apiData['vitamin_a']        = floatval($raw_data[18]);
               $apiData['vitamin_c']        = floatval(!empty($raw_data[19])?$raw_data[19]:0);
               $apiData['calcium']          = floatval($raw_data[20]);
               $apiData['iron']             = floatval($raw_data[21]);


               $apiData['status_id']        = 1;
               $apiData['created_date']     = gmdate('Y-m-d H:i:s');

               $this->table->insert($apiData);

               
            }

            $i++;
            
        }
        
      die('sma 2');
    }

  
}
