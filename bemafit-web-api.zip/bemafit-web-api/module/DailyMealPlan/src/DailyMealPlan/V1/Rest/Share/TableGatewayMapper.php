<?php

namespace DailyMealPlan\V1\Rest\Share;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    public function getDailyMealPlan()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('DailyMealPlan\V1\Rest\DailyMealPlanMapperTableGateway');
        return $this->Table;
    }

    public function getAwsImageUrl($url, $expire = '+1 year')
    {
        $config = $this->getServiceLocator()->get('Config');       
        return $config['aws_s3_path'].'/'.$url;
    }

    public function getDmpDetTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('DailyMealPlan\Model\DmpDetailTable');
        return $this->Table;
    }
   
    /**
    * To fetch all BusinessDirectory
    *
    * @param string $name
    * @return Entity
    */
   
    public function create($params,$userId){
        $this->getAdapter();

        if(empty($params->guid)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Guid required');
        } else {
            $guid   =   $params->guid;   
        }

        if(empty($params->user_id) || count($params->user_id)==0){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'User id required');
        } else {
            $shareIds   = $params->user_id; 

            foreach ($shareIds as $key => $shareId) {
                 $result  =  $this->getUserTable()->getUserByGuid($shareId);

                 if(!$result){
                    return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid user');
                 }
             } 
        }
     

        $sql ="SELECT dmp.id,dmp.guid,name,coremeal,snacks,calorie,carb,fat,protien,fiber,nutrition_plan_id
        FROM dmp
        JOIN user ON dmp.user_id = user.id
        WHERE dmp.status_id=1 AND dmp.user_id=".$userId." AND dmp.guid='".$guid."'";

        
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        $dmp = $result->getResource()->fetch(2);

        if($dmp && count($dmp)>0){

            $sql ="SELECT *
            FROM dmp_details
            WHERE dmp_details.status_id=1  AND dmp_details.dmp_id=".$dmp['id'];

            
            $statement = $this->adapter->createStatement($sql);

            $result  = $statement->execute();
            $dmpDet = $result->getResource()->fetchAll(2);

            foreach ($shareIds as $shareId) {
                 $result  =  $this->getUserTable()->getUserByGuid($shareId);

                 if($result){
                    $apiData['dmp_id']      = $guid;
                    $apiData['added_by']     = $userId;
                    $apiData['user_id']     = $result->id;
                    $apiData['added_date']  = gmdate('Y-m-d H:i:s');
                    $this->table->insert($apiData);

                    unset($apiData);
                    $apiData['guid']    =   md5(uniqid(rand(), true));
                    $apiData['name']    =   !empty($dmp['name'])?$dmp['name']:'';
                    $apiData['coremeal']=   !empty($dmp['coremeal'])?$dmp['coremeal']:0;
                    $apiData['snacks']  =   !empty($dmp['snacks'])?$dmp['snacks']:0;
                    $apiData['nutrition_plan_id']  =   !empty($dmp['nutrition_plan_id'])?$dmp['nutrition_plan_id']:0;
                    $apiData['calorie'] =   !empty($dmp['calorie'])?$dmp['calorie']:0;
                    $apiData['carb']    =   !empty($dmp['carb'])?$dmp['carb']:0;
                    $apiData['fat']     =   !empty($dmp['fat'])?$dmp['fat']:0;
                    $apiData['protien'] =   !empty($dmp['protien'])?$dmp['protien']:0;
                    $apiData['fiber']   =   !empty($dmp['fiber'])?$dmp['fiber']:0;
                    $apiData['added_date']   =   gmdate('Y-m-d H:i:s');
                    $apiData['updated_date'] =   gmdate('Y-m-d H:i:s');
                    $apiData['status_id']    =   1;

                    $apiData['added_by']     = $userId;
                    $apiData['user_id']      = $result->id;


                    $this->getDailyMealPlan()->share($apiData,$dmpDet);
                    unset($apiData);

                 }
             }

             return array(
                      'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'Share Daily Meal Plan')
                      ); 
        } else {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Inavlid Entry');
        }
    
    }
  
}
