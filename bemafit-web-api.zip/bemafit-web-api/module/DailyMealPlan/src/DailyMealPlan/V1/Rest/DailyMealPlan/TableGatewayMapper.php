<?php

namespace DailyMealPlan\V1\Rest\DailyMealPlan;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    public function getAwsImageUrl($url, $expire = '+1 year')
    {
        $config = $this->getServiceLocator()->get('Config');       
        return $config['aws_s3_path'].'/'.$url;
    }

    public function getDmpDetTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('DailyMealPlan\Model\DmpDetailTable');
        return $this->Table;
    }
   
    /**
    * To fetch all BusinessDirectory
    *
    * @param string $name
    * @return Entity
    */
   
    public function create($params,$userId){
        
        if(!isset($params->name)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Name required');
        }

        if(!isset($params->nutritional_plan)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Nutrition plan required');
        }

        if(!isset($params->coremeal)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Core meal required');
        }

        if(!isset($params->snacks)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Snacks required');
        }

        if(!isset($params->calorie)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Calorie  required');
        }

        if(!isset($params->carb)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Carbs  required');
        }

        if(!isset($params->fat)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Fats  required');
        }

        if(!isset($params->protien)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Proteins  required');
        }

        if(!isset($params->fiber)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Fiber  required');
        }

        // if(empty($params->meal_type)){
        //     return \Application\Service\FymApiProblem::ApiProblem(422, 'Meal type  required');
        // }        
        

        /////nutrition_plan_id validation
        $apiData['guid']    =   md5(uniqid(rand(), true));
        $apiData['name']    =   !empty($params->name)?$params->name:'';
        $apiData['coremeal']=   !empty($params->coremeal)?$params->coremeal:0;
        $apiData['snacks']  =   !empty($params->snacks)?$params->snacks:0;
        $apiData['nutrition_plan_id']  =   !empty($params->nutritional_plan)?$params->nutritional_plan:0;
        $apiData['calorie'] =   !empty($params->calorie)?$params->calorie:0;
        $apiData['carb']    =   !empty($params->carb)?$params->carb:0;
        $apiData['fat']     =   !empty($params->fat)?$params->fat:0;
        $apiData['protien'] =   !empty($params->protien)?$params->protien:0;
        $apiData['fiber']   =   !empty($params->fiber)?$params->fiber:0;
        $apiData['added_date']   = gmdate('Y-m-d H:i:s');
        $apiData['updated_date'] = gmdate('Y-m-d H:i:s');
        $apiData['status_id']  =   1;

        $apiData['added_by'] = $userId;
        $apiData['user_id'] = $userId;
        $this->table->insert($apiData);

        $dmpId  = $this->table->lastInsertValue;

        //print_r($apiData);
        foreach ($params->detail as $key => $data) {
           // print_r($data);
            $insert['dmp_id']           = $dmpId;
            $insert['dmp_meal_id']      = $data['id'];
            $insert['dmp_meal_guid']    = $data['guid'];
            $insert['dmp_meal_name']    = $data['name'];
            $insert['dmp_meal_name_es']    = !empty($data['name_es'])?$data['name_es']:'';
            $insert['focus']            = $data['focus'];
            $insert['type']             = $data['type'];
            $insert['brand']            = $data['brand'];
            $insert['serving_size']     = $data['serving_size'];
            $insert['serving_unit']     = $data['unit'];
            $insert['calorie']          = $data['calorie'];
            $insert['fat']              = $data['fat'];
            $insert['saturated']        = $data['saturated'];
            $insert['polyunsaturated']  = $data['polyunsaturated'];
            $insert['monounsaturated']  = $data['monounsaturated'];
            $insert['trans']            = $data['trans'];
            $insert['cholesterol']      = $data['cholesterol'];
            $insert['sodium']           = $data['sodium'];
            $insert['potassium']        = $data['potassium'];
            $insert['carbs']            = $data['carbs'];
            $insert['fiber']            = $data['fiber'];
            $insert['sugar']            = $data['sugar'];
            $insert['protien']          = $data['protien'];
            $insert['vitamin_a']        = $data['vitamin_a'];
            $insert['vitamin_c']        = $data['vitamin_c'];
            $insert['calcium']          = $data['calcium'];
            $insert['iron']             = $data['iron'];
            $insert['meal_type']        = $data['meal_type'];
            $insert['parent']           = $data['parent'];
            $insert['row_id']           = $data['row_id'];
            $insert['when_delete']      = $data['when_delete'];
            $insert['fym_dmp_type']     = $data['fym_dmp_type'];
            $insert['serving_size_fixed'] = $data['serving_size_fixed'];
            $insert['status_id']        = 1;

            $this->getDmpDetTable()->create($insert);
            //print_r($data);
        }

        return array(
                      'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'create Daily Meal Plan'),
                      'guid'=>$apiData['guid']
                      );
    }

    public function fetchAll($params,$userId){
        $this->getAdapter();
        $config = $this->getServiceLocator()->get('Config');


        $sql ="SELECT dmp.guid,dmp.name,added_date,updated_date, 
        CONCAT(user.first_name,' ',user.last_name) as username,user.guid as userid, user.profile_photo as user_profile_photo,
        CONCAT(added_by.first_name,' ',added_by.last_name) as added_username,user.guid as added_userid, added_by.profile_photo as added_profile_photo
        FROM dmp
        JOIN user ON dmp.user_id = user.id
        JOIN user added_by ON dmp.added_by = added_by.id
        WHERE dmp.status_id=1 AND dmp.user_id=".$userId. 
        " ORDER BY dmp.updated_date DESC 
        LIMIT $params->offset,$params->limit";

        
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        $dmps = $result->getResource()->fetchAll(2);

        foreach ($dmps as $key => $dmp) {
            $preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
            $image_url = empty($dmp['user_profile_photo'])?$dmp['user_profile_photo']:$this->getAwsImageUrl($preview_bucket_url.'/'.$dmp['user_profile_photo']);
            $image_url = empty($dmp['added_profile_photo'])?$dmp['added_profile_photo']:$this->getAwsImageUrl($preview_bucket_url.'/'.$dmp['added_profile_photo']);
            
            $dmps[$key]['user_profile_photo']=$image_url;
            $dmps[$key]['added_profile_photo']=$image_url;
        }   

        return $dmps;
    }

    public function delete($guid,$item,$userId){
        $this->getAdapter();
        $config = $this->getServiceLocator()->get('Config');



        $sql ="SELECT dmp.guid
        FROM dmp
        JOIN user ON dmp.user_id = user.id
        WHERE dmp.status_id=1 AND dmp.user_id=".$userId." AND dmp.guid='".$guid."'";

        
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        $dmps = $result->getResource()->fetchAll(2);

        if(count($dmps)>0){
            $apiData['updated_date']   = gmdate('Y-m-d H:i:s');
            $apiData['status_id']      = 4;
            $apiData['added_by']       = $userId;

            if($item==''){
                $this->table->update($apiData,array('guid' => $guid));
            } else {
                unset($apiData['added_by']);
                //echo $guid."---".$item.">>>";
                $sql ="SELECT when_delete
                FROM dmp_details
                WHERE id=$item";

                
                $statement = $this->adapter->createStatement($sql);

                $result  = $statement->execute();
                $result = $result->getResource()->fetch(2);

                if(count($result)>0){
                    $ids = explode(',',$result['when_delete']);
                    foreach($ids as $id){
                        $this->getDmpDetTable()->update($apiData,array('id' => $id));
                    }
                }

                
                $this->getDmpDetTable()->update($apiData,array('id' => $item));
            }

            return true;
        } else {
            return false;
        }
        
    }

    public function fetch($guid,$userId){
        $this->getAdapter();
        $config = $this->getServiceLocator()->get('Config');


        $sql ="SELECT dmp.*,CONCAT(user.first_name,' ',user.last_name) as username,user.guid as userid, user.profile_photo as user_profile_photo,
        CONCAT(added_by.first_name,' ',added_by.last_name) as added_username,user.guid as added_userid, added_by.profile_photo as added_profile_photo,
        nutritional_plan.name as nutrition_plan
        FROM dmp
        JOIN user ON dmp.user_id = user.id
        JOIN user added_by ON dmp.added_by = added_by.id
        LEFT JOIN nutritional_plan ON nutritional_plan.id = dmp.nutrition_plan_id
        WHERE dmp.status_id=1 AND dmp.user_id=".$userId." AND dmp.guid='".$guid."'";

        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        $row     = $result->getResource()->fetch(2);
        
        if($row and count($row)>0){
                
            
                $preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
                $image_url = empty($row['user_profile_photo'])?$row['user_profile_photo']:$this->getAwsImageUrl($preview_bucket_url.'/'.$row['user_profile_photo']);
                $addedimage_url = empty($row['added_profile_photo'])?$row['added_profile_photo']:$this->getAwsImageUrl($preview_bucket_url.'/'.$row['added_profile_photo']);
                
                $row['user_profile_photo']=$image_url; 
                $row['added_profile_photo']=$addedimage_url; 

                $sql ="SELECT id as unique_id,dmp_meal_id as id,dmp_meal_guid as guid,dmp_meal_name as name, IFNULL(dmp_meal_name_es,'') as name_es,focus,type,brand,serving_size,serving_unit as unit,
                    calorie,fat,saturated,polyunsaturated,monounsaturated,trans,cholesterol,sodium,potassium,carbs,fiber,sugar,protien,vitamin_a,serving_size_fixed,
                    vitamin_c,calcium,iron,meal_type,parent,row_id,when_delete,IFNULL(fym_dmp_type, '') as fym_dmp_type

                FROM dmp_details
                WHERE dmp_details.status_id=1 AND dmp_id=".$row['id'];

                $statement = $this->adapter->createStatement($sql);

                $result  = $statement->execute();
                $details = $result->getResource()->fetchAll(2);

                if(count($details)>0){
                    foreach($details as $dkey => $det){
                        $details[$dkey]['when_delete'] = $det['when_delete'];
                    }
                    $row['details'] = $details;
                } else {
                    $row['details'] = array();
                }

                //unset($row['nutrition_plan']);
                unset($row['user_id']);
                unset($row['added_by']);
            
            return $row;
        } else {
            return false;
        }
    }

    public function update($params,$guid,$userId){

        if(!isset($params->name)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Name required');
        }

        if(!isset($params->nutritional_plan)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Nutrition plan required');
        }

        if(!isset($params->coremeal)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Core meal required');
        }

        if(!isset($params->snacks)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Snacks required');
        }

        if(!isset($params->calorie)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Calorie  required');
        }

        if(!isset($params->carb)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Carbs  required');
        }

        if(!isset($params->fat)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Fats  required');
        }

        if(!isset($params->protien)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Proteins  required');
        }

        if(!isset($params->fiber)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Fiber  required');
        }


        $this->getAdapter();
        $config = $this->getServiceLocator()->get('Config');

        $sql ="SELECT dmp.id,dmp.guid
        FROM dmp
        JOIN user ON dmp.user_id = user.id
        WHERE dmp.status_id=1 AND dmp.user_id=".$userId." AND dmp.guid='".$guid."'";

        
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        $dmp = $result->getResource()->fetch(2);
        


        if($dmp and count($dmp)>0){
                 
            $apiData['name']    =   !empty($params->name)?$params->name:'';
            $apiData['coremeal']=   !empty($params->coremeal)?$params->coremeal:0;
            $apiData['snacks']  =   !empty($params->snacks)?$params->snacks:0;
            $apiData['nutrition_plan_id']  =   !empty($params->nutritional_plan)?$params->nutritional_plan:0;
            $apiData['calorie'] =   !empty($params->calorie)?$params->calorie:0;
            $apiData['carb']    =   !empty($params->carb)?$params->carb:0;
            $apiData['fat']     =   !empty($params->fat)?$params->fat:0;
            $apiData['protien'] =   !empty($params->protien)?$params->protien:0;
            $apiData['fiber']   =   !empty($params->fiber)?$params->fiber:0;
            $apiData['added_by'] = $userId;
            $apiData['updated_date'] =gmdate('Y-m-d H:i:s');
            $this->table->update($apiData,array('guid'=>$guid)); 

            $this->getDmpDetTable()->deleteAll(array('dmp_id'=>$dmp['id']));

            foreach ($params->detail as $key => $data) {
            //print_r($data);
                    $insert['dmp_id']           = $dmp['id'];
                    $insert['dmp_meal_id']      = $data['id'];
                    $insert['dmp_meal_name']    = $data['name'];
                    $insert['focus']            = $data['focus'];
                    $insert['type']             = $data['type'];
                    $insert['brand']            = $data['brand'];
                    $insert['serving_size']     = $data['serving_size'];
                    $insert['serving_unit']     = $data['unit'];
                    $insert['calorie']          = $data['calorie'];
                    $insert['fat']              = $data['fat'];
                    $insert['saturated']        = $data['saturated'];
                    $insert['polyunsaturated']  = $data['polyunsaturated'];
                    $insert['monounsaturated']  = $data['monounsaturated'];
                    $insert['trans']            = $data['trans'];
                    $insert['cholesterol']      = $data['cholesterol'];
                    $insert['sodium']           = $data['sodium'];
                    $insert['potassium']        = $data['potassium'];
                    $insert['carbs']            = $data['carbs'];
                    $insert['fiber']            = $data['fiber'];
                    $insert['sugar']            = $data['sugar'];
                    $insert['protien']          = $data['protien'];
                    $insert['vitamin_a']        = $data['vitamin_a'];
                    $insert['vitamin_c']        = $data['vitamin_c'];
                    $insert['calcium']          = $data['calcium'];
                    $insert['iron']             = $data['iron'];
                    $insert['meal_type']        = $data['meal_type'];
                    $insert['parent']           = $data['parent'];
                    $insert['row_id']           = $data['row_id'];
                    $insert['when_delete']      = $data['when_delete'];
                    $insert['fym_dmp_type']     = $data['fym_dmp_type'];
                    
                    $insert['status_id']        = 1;

                    $this->getDmpDetTable()->create($insert);
            //print_r($data);
            }  

            return true;        
        

        } else {
            return false;
        }
    }

    public function patch($params,$guid,$item,$userId){
        
        $this->getAdapter();
        $config = $this->getServiceLocator()->get('Config');

        $mealType  = array("Breakfast","Lunch","Dinner");
        $apiData   = array();

        if(!empty($params->meal_type)){
            if(in_array($params->meal_type,$mealType)){
                $apiData['meal_type'] = !empty($params->meal_type)?$params->meal_type:'';
            } else {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Meal type required');

            }
        }

        $sql ="SELECT dmp.id,dmp.guid
        FROM dmp
        JOIN user ON dmp.user_id = user.id
        WHERE dmp.status_id=1 AND dmp.user_id=".$userId." AND dmp.guid='".$guid."'";

        
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        $dmp = $result->getResource()->fetch(2);
        

        if(count($dmp)>0 && !empty($item) && count($apiData)>0){

            $this->getDmpDetTable()->update($apiData,array('dmp_id'=>$dmp['id'],'id'=>$item)); 

            return true;
        } else {
            return false;
        }
    }

    public function share($params,$dmpDets) {
        $this->table->insert($params);
        $dmpId  = $this->table->lastInsertValue;

        foreach ($dmpDets as $dmpDet) {
            unset($dmpDet['id']);
            $dmpDet['dmp_id'] = $dmpId;
            $this->getDmpDetTable()->create($dmpDet);
        }
        
    }

  
}
