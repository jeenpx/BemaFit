<?php
namespace DailyMealPlan\V1\Rest\MealType;

use Zend\Paginator\Paginator;

class MealTypeCollection extends Paginator
{
}
