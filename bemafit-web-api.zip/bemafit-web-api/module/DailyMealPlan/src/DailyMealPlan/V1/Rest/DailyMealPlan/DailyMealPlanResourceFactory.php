<?php
namespace DailyMealPlan\V1\Rest\DailyMealPlan;

class DailyMealPlanResourceFactory
{
    public function __invoke($services)
    {
    	$mapper = $services->get('DailyMealPlan\V1\Rest\DailyMealPlanMapperTableGateway');
        return new DailyMealPlanResource($mapper);
    }
}
