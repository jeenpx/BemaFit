<?php

namespace DailyMealPlan\V1\Rest\MealType;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    public function getDailyMealPlan()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('DailyMealPlan\V1\Rest\DailyMealPlanMapperTableGateway');
        return $this->Table;
    }

    public function getAwsImageUrl($url, $expire = '+1 year')
    {
        $config = $this->getServiceLocator()->get('Config');       
        return $config['aws_s3_path'].'/'.$url;
    }

    public function getDmpDetTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('DailyMealPlan\Model\DmpDetailTable');
        return $this->Table;
    }

    public function getMealTypeTable()
    {
        $sm = $this->getServiceLocator();
        $this->MealTypeTable = $sm->get('MealType\V1\Rest\MealTypeMapperTableGateway');
        return $this->MealTypeTable;
    }
   
    /**
    * To fetch all BusinessDirectory
    *
    * @param string $name
    * @return Entity
    */
   
    public function fetchAll($params,$userId){

        if(!isset($params->coremeal)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Core meal required');
        }

        if(!isset($params->snacks)){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Snacks required');
        }

        $coremeal  =   $params->coremeal;
        $snacks    =   $params->snacks;

        
        $this->getAdapter();
        $utilityObj = new \Application\Service\Utility();
        $locale     = $utilityObj->getLocale(!empty($params->locale)?$params->locale:'en');

        $mealTypes  =  $this->getMealTypeTable()->dmpMealType($userId,$locale);

        $results    =  array();

        for($i=0;$i<($coremeal);$i++){
            $results[]='';
            if($i<count($mealTypes)){
                $results[$i] =$mealTypes[$i];
                $results[$i]['dmp_meal_type']= $params->locale=='es'?'ComidaPrincipal'.($i+1):'coremeal'.($i+1);
                //$results[$i]['dmp_meal_type']= 'coremeal'.($i+1);
            } else {
                $results[$i] =$mealTypes[(count($mealTypes)-1)];
                $results[$i]['dmp_meal_type']= $params->locale=='es'?'ComidaPrincipal'.($i+1):'coremeal'.($i+1);
                //$results[$i]['dmp_meal_type']= 'coremeal'.($i+1);
            }

        }


        
        for($i=0;$i<($snacks);$i++){
            $results[]=array('id'=>3,'name'=>($params->locale=='es'?'Bocadillo':'Snacks'),'is_default'=>true,'dmp_meal_type'=>$params->locale=='es'?"Bocadillo".($i+1):'snacks'.($i+1));
           //$results[]=array('id'=>3,'name'=>($params->locale=='es'?'Bocadillo':'Snacks'),'is_default'=>true,'dmp_meal_type'=>'snacks'.($i+1));
        }

        return $results;


    
    }
  
}
