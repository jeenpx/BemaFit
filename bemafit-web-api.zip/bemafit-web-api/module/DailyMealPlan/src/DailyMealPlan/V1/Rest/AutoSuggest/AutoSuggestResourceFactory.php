<?php
namespace DailyMealPlan\V1\Rest\AutoSuggest;

class AutoSuggestResourceFactory
{
    public function __invoke($services)
    {
    	$mapper = $services->get('DailyMealPlan\V1\Rest\AutoSuggestMapperTableGateway');
		return new AutoSuggestResource($mapper);
    }
}
