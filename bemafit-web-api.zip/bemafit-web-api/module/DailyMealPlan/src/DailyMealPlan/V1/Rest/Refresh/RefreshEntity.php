<?php
namespace DailyMealPlan\V1\Rest\Refresh;

class RefreshEntity
{
}
