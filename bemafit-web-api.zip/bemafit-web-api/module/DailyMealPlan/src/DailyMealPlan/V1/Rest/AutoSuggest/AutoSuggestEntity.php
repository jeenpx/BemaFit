<?php
namespace DailyMealPlan\V1\Rest\AutoSuggest;

class AutoSuggestEntity
{
}
