<?php
namespace DailyMealPlan\V1\Rest\Refresh;

use Zend\Paginator\Paginator;

class RefreshCollection extends Paginator
{
}
