<?php
namespace DailyMealPlan\V1\Rest\AutoSuggest;

use Zend\Paginator\Paginator;

class AutoSuggestCollection extends Paginator
{
}
