<?php

namespace DailyMealPlan\V1\Rest\AutoSuggest;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    public function getMealTypeTable()
    {
        $sm = $this->getServiceLocator();
        $this->MealTypeTable = $sm->get('MealType\V1\Rest\MealTypeMapperTableGateway');
        return $this->MealTypeTable;
    }

   
    /**
    * To fetch all BusinessDirectory
    *
    * @param string $name
    * @return Entity
    */
   public function fetchAll($params){

      $this->getAdapter();


      $coremeal         =   $params->coremeal;
      $snacks           =   $params->snacks;
      $calories         =   $params->calories;
      $carbs            =   $params->carbs;
      $fats             =   $params->fats;
      $proteins         =   $params->proteins;
      $locale           =   $params->locale;
      

      $nutritional_plan =   !empty($params->nutritional_plan)?$params->nutritional_plan:1;

      $userId    =   $params->userId;

      $utilityObj = new \Application\Service\Utility();
      $locale     = $utilityObj->getLocale(!empty($locale)?$locale:'en');

      if($coremeal<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Core meal required');
      }

      if($calories<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Calorie  required');
      }

      if($carbs<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Carbs  required');
      }

      if($fats<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Fats  required');
      }

      if($proteins<=0){
          return \Application\Service\FymApiProblem::ApiProblem(422, 'Proteins  required');
      }

      //$mealType = $this->getMealTypeTable()->fetchAll($userId,$locale);
      //print_r($mealType);

      $focus = array('PROTEIN','CARBOHYDRATE','OPTIONS');

      $results     =  array();
      $data        =  array();
      $debug       =  array();

      $proteinTot  =   0;
      $calorieTot  =   0;
      $carbTot     =   0;
      $fatTot      =   0;



      $breakfastProtienBal       = 0;
      $breakfastCarbsBal         = 0;
      $breakfastCalorieBal       = 0;
      $breakfastFatBal           = 0;
    

    
      $lunchProtienBal           = 0;
      $lunchCarbsBal             = 0;
      $lunchCalorieBal           = 0;
      $lunchFatBal               = 0;
    
    

   
      $dinnerProtienBal          = 0;
      $dinnerCarbsBal            = 0;
      $dinnerCalorieBal          = 0;
      $dinnerFatBal              = 0;
   
    

   
      $snacksProtienBal          = 0;
      $snacksCarbsBal            = 0;
      $snacksCalorieBal          = 0;
      $snacksFatBal              = 0;

      $carbItemCnt               = 0;
      $protienItemCnt            = 0;


      $calAchived                = 0;
   
      $h = 1 ;
      // "786";
      
      for($i=1;$i<=($coremeal+$snacks);$i++){

          if($i==1){
              $type      = "BREAKFAST";
              $mealType  = $locale=='es'?"Desayuno":"Breakfast";
              $queryTale = 'AND focus="PROTEIN"';
              $dmpMealTypeSlug = 'coremeal';
              $dmpMealType = $locale=='es'?'ComidaPrincipal'.$i:'coremeal'.$i;

              if($params->snacks>0){
                    $proteinFind = (($params->proteins*80/100)/$coremeal);
                    $carbFind    = (($params->carbs*80/100)/$coremeal);
              } else {
                    $proteinFind = (($params->proteins)/$coremeal);
                    $carbFind    = (($params->carbs)/$coremeal);
              }

          } else if($i<=$coremeal){
              $type  = "LUNCH/DINNER";

              if($i==2){
                  $mealType  = $locale=='es'?"Almuerzo":"Lunch";
              } else {
                  $mealType  = $locale=='es'?"Cena":"Dinner";
              }
              $queryTale = 'AND focus="PROTEIN"';
              $dmpMealTypeSlug = 'coremeal';
              $dmpMealType = $locale=='es'?'ComidaPrincipal'.$i:'coremeal'.$i;

              if($params->coremeal>0 and $params->snacks>0){
                    $proteinFind = (($params->proteins*80/100)/$snacks);
                    $carbFind    = (($params->carbs*80/100)/$snacks);
              } else if($params->snacks>0){
                    $proteinFind = (($params->proteins)/$snacks);
                    $carbFind    = (($params->carbs)/$snacks );
              }

          } else {
              $type      = "SNACKS";
              $mealType  = $locale=='es'?"Bocadillo":"Snacks";
              $queryTale = '';
              $dmpMealTypeSlug = 'snacks';
              $dmpMealType = 'snacks'.$h;
              $h++;

              if($params->snacks>0){
                    $proteinFind = (($params->proteins*20/100)/$snacks);
                    $carbFind    = (($params->carbs*20/100)/$snacks);
              }

          }

          $parent   = 0;
          $row_id   = 0;
          $mainType = 'main_meal';
          $meals    = $this->calculateMeal($type,$proteinFind,$carbFind,$queryTale,$mealType,$dmpMealType,$parent,$row_id,$mainType,$dmpMealTypeSlug,$nutritional_plan,$locale);

          $results[] = $meals;
      }

     // print_r($results);


      if($params->snacks>0){
            $CproteinFind = (($params->proteins*80/100)/$coremeal);
            $CcarbFind    = (($params->carbs*80/100)/$coremeal);
            $CcalorieFind = (($params->calories*80/100)/$coremeal);

            $SproteinFind = (($params->proteins*20/100)/$snacks);
            $ScarbFind    = (($params->carbs*20/100)/$snacks);
            $ScalorieFind = (($params->calories*20/100)/$snacks);

            $SproteinReq = (($params->proteins*20/100));
            $ScarbReq    = (($params->carbs*20/100));
            $ScalorieReq = (($params->calories*20/100));
            
      } else {
            $CproteinFind = (($params->proteins)/$coremeal);
            $CcarbFind    = (($params->carbs)/$coremeal);
            $CcalorieFind = (($params->calories)/$coremeal);

            $SproteinFind = 0;
            $ScarbFind    = 0;
            $ScalorieFind = 0;

            $SproteinReq = 0;
            $ScarbReq    = 0;
            $ScalorieReq = 0;
      }

      $data['request']['protien']  =   $params->proteins;
      $data['request']['calorie']  =   $params->calories;
      $data['request']['carbs']    =   $params->carbs;

      $data['request']['per_type']['coremeal']['protien']  =   $CproteinFind;
      $data['request']['per_type']['coremeal']['calorie']  =   $CcalorieFind;
      $data['request']['per_type']['coremeal']['carbs']    =   $CcarbFind;

      $data['request']['per_type']['snacks']['protien']  =   $SproteinFind;
      $data['request']['per_type']['snacks']['calorie']  =   $ScalorieFind;
      $data['request']['per_type']['snacks']['carbs']    =   $ScarbFind;

      $debug = array();
      $wholeList = array();
      $data['cal_achived_coremeal'] = 0;

     


      //protien with fixed
      foreach ($results as $key => $result) {
          $dmpType          =  $result[0]['fym_dmp_type'];

          $data[$dmpType]['fixed_protien']['protien']        =   0;
          $data[$dmpType]['fixed_protien']['calorie']        =   0;
          $data[$dmpType]['fixed_protien']['carbs']          =   0;
          $data[$dmpType]['fixed_protien']['fat']            =   0;

          

          $data[$dmpType]['nonfixed']              =   0;
          $data[$dmpType]['fixed']                 =   0;
          $data[$dmpType]['total']                 =   0;
          $data[$dmpType]['nonfixed_protein_focus']=   0;
          $data[$dmpType]['nonfixed_carb_focus']   =   0;
          $data[$dmpType]['fixed_protein_focus']   =   0;
          $data[$dmpType]['fixed_carb_focus']      =   0;
          $data[$dmpType]['delete_fixed_item']     =   0;
          $data[$dmpType]['delete_nonfixed_item']  =   0;


          if(substr($dmpType,0,8)=='coremeal'){
              $proteinFind  = $CproteinFind;
              $carbFind     = $CcarbFind;   
              $calorieFind  = $CcalorieFind; 
          }else {
              $proteinFind  = $SproteinFind;
              $carbFind     = $ScarbFind;   
              $calorieFind  = $ScalorieFind; 
          }

          $data[$dmpType]['balance_after_fixed_protien']['protien']  =   $proteinFind;
          $data[$dmpType]['balance_after_fixed_protien']['calorie']  =   $calorieFind;
          $data[$dmpType]['balance_after_fixed_protien']['carbs']    =   $carbFind;

          if(count($result)==0){
            return \Application\Service\FymApiProblem::ApiProblem(422, 'No record exist');
          }

          foreach($result as $mkey => $meal){
             

              //echo $data[$dmpType]['balance_after_fixed_protien']['protien'].'<'.$proteinFind;
              //and $data[$dmpType]['balance_after_fixed_protien']['protien']<$proteinFind
              if($meal['serving_size_fixed']==1 && $meal['focus']=='PROTEIN'){
                    $data[$dmpType]['fixed_protien']['protien']  +=   $meal['protien'];
                    $data[$dmpType]['fixed_protien']['calorie']  +=   $meal['calorie'];
                    $data[$dmpType]['fixed_protien']['carbs']    +=   $meal['carbs'];
                    $data[$dmpType]['fixed_protien']['fat']      +=   $meal['fat'];


                    $calAchived +=   $meal['calorie'];
                    $data['cal_achived_coremeal'] +=   $meal['calorie'];
                    $data['cal_achived'][$dmpType] = $calAchived;
                    $data['cal_achived_report'][$dmpType][] = array('cal'=>$meal['calorie'],'serving_size'=>1,'totcal'=>$meal['calorie']*1);

                   
                    $data[$dmpType]['balance_after_fixed_protien']['protien']  -=   $meal['protien'];
                    $data[$dmpType]['balance_after_fixed_protien']['calorie']  -=   $meal['calorie'];
                    $data[$dmpType]['balance_after_fixed_protien']['carbs']    -=   $meal['carbs'];
                    

                    $proteinTot  +=   $meal['protien'];
                    $calorieTot  +=   $meal['calorie'];
                    $carbTot     +=   $meal['carbs'];
                    $fatTot      +=   $meal['fat'];

                    $results[$key][$mkey]['status']          = 'active';

                    //for debug only
                    $debug[] = array(
                        'dmp'=>$dmpType,
                        'nut_achived'=>array(
                            'protien'=>$meal['protien'],
                            'calorie'=> $meal['calorie'],
                            'carbs'=> $meal['carbs'],
                            'fat'=>$meal['fat'],

                          ),
                        'nut_has'=>array(
                            'protien'=> $meal['protien'],
                            'calorie'=> $meal['calorie'],
                            'carbs'=> $meal['carbs'],
                            'fat'=> $meal['fat'],

                          ),
                        'genere'=>'fixed','protien'=>$meal['protien'],'carb'=>$meal['carbs']);

                    
              } else {
                //echo $meal['focus']."-";
              }

              //calculate each meal genre
              if($meal['serving_size_fixed']==1){
                  $data[$dmpType]['fixed']    +=   1;

                  if($meal['focus']=='PROTEIN'){
                      $data[$dmpType]['fixed_protein_focus'] +=   1;
                  } else {
                      $data[$dmpType]['fixed_carb_focus'] +=   1;
                  }
              } else {
                  $data[$dmpType]['nonfixed'] +=   1;

                  if($meal['focus']=='PROTEIN'){
                      $data[$dmpType]['nonfixed_protein_focus']+=   1;
                  } else {
                      $data[$dmpType]['nonfixed_carb_focus']+=   1;
                  }
              }



          }
      }

    //  print_r($results);
      ///protien based non fixed meals
      

      foreach ($results as $key => $result) {
          $dmpType          =  $result[0]['fym_dmp_type'];

          $data[$dmpType]['not_fixed_protien']['protien']        =   0;
          $data[$dmpType]['not_fixed_protien']['calorie']        =   0;
          $data[$dmpType]['not_fixed_protien']['carbs']          =   0;
          $data[$dmpType]['not_fixed_protien']['fat']            =   0;
          $data[$dmpType]['not_fixed_protien']['count']          =   0;

          $data[$dmpType]['delete_nonfixed_protein_item_lesthan']     =   0;

          //echo  $data[$dmpType]['balance_after_fixed_protien']['protien'];
          $data[$dmpType]['balance_after_nonfixed_protien']['protien']  =   $data[$dmpType]['balance_after_fixed_protien']['protien'];
          $data[$dmpType]['balance_after_nonfixed_protien']['calorie']  =   $data[$dmpType]['balance_after_fixed_protien']['calorie'];
          $data[$dmpType]['balance_after_nonfixed_protien']['carbs']    =   $data[$dmpType]['balance_after_fixed_protien']['carbs'];


          foreach($result as $mkey => $meal){
                if($meal['serving_size_fixed']==0 && $meal['focus']=='PROTEIN' && $data[$dmpType]['balance_after_nonfixed_protien']['protien']>0){
                      $protienNeeded  =   ($data[$dmpType]['balance_after_nonfixed_protien']['protien']/(($data[$dmpType]['nonfixed_protein_focus']==0)?1:$data[$dmpType]['nonfixed_protein_focus'] ));
                      $servingSize    =  $protienNeeded/$meal['protien'];

                      if($servingSize<0.25){
                          $data[$dmpType]['delete_nonfixed_protein_item_lesthan']     +=   1;
                          unset($results[$key][$mkey]);
                      } else {

                          $data[$dmpType]['not_fixed_protien']['protien']  +=   ($servingSize * $meal['protien']);
                          $data[$dmpType]['not_fixed_protien']['calorie']  +=   ($servingSize * $meal['calorie']);
                          $data[$dmpType]['not_fixed_protien']['carbs']    +=   ($servingSize * $meal['carbs']);

                          $calAchived +=   ($servingSize * $meal['calorie']);
                          $data['cal_achived'][$dmpType] = $calAchived;
                          
                          $data['cal_achived_coremeal'] += ($servingSize * $meal['calorie']);
                          $data['cal_achived_report'][$dmpType][] = array('cal'=>$meal['calorie'],'serving_size'=>$servingSize,'totcal'=>$meal['calorie']*$servingSize);


                          $data[$dmpType]['not_fixed_protien']['count']  +=   1;


                          $results[$key][$mkey]['serving_size']          = $servingSize;
                          $results[$key][$mkey]['serving_size_adjusted'] = 1;

                          $proteinTot  +=   $servingSize * $meal['protien'];
                          $calorieTot  +=   $servingSize * $meal['calorie'];
                          $carbTot     +=   $servingSize * $meal['carbs'];
                          $fatTot      +=   $servingSize * $meal['fat'];

                          $results[$key][$mkey]['status']          = 'active';

                          $data[$dmpType]['balance_after_nonfixed_protien']['protien']  -=   ($servingSize * $meal['protien']);
                          $data[$dmpType]['balance_after_nonfixed_protien']['calorie']  -=   ($servingSize * $meal['calorie']);
                          $data[$dmpType]['balance_after_nonfixed_protien']['carbs']    -=   ($servingSize * $meal['carbs']);
                          

                          $debug[] = array(
                            'nut_achived'=>array(
                                'protien'=>$servingSize * $meal['protien'],
                                'calorie'=>$servingSize * $meal['calorie'],
                                'carbs'=>$servingSize * $meal['carbs'],
                                'fat'=>$servingSize * $meal['fat'],

                              ),
                            'nut_has'=>array(
                                'protien'=> $meal['protien'],
                                'calorie'=> $meal['calorie'],
                                'carbs'=> $meal['carbs'],
                                'fat'=> $meal['fat'],

                              ),
                            'genere'=>'non_fixed','dmp'=>$dmpType,'type'=>'protien','$protienNeeded'=>$protienNeeded,'$servingSize'=>$servingSize,'balance'=>$data[$dmpType]['balance_after_nonfixed_protien']['protien'],'protirn_focus_count'=>($data[$dmpType]['nonfixed_protein_focus']==0)?1:$data[$dmpType]['nonfixed_protein_focus'],'protien'=>$meal['protien'],'carb'=>$meal['carbs']);
                            
                      }
                      $data[$dmpType]['nonfixed_protein_focus']--;


                }
          }
      }



      //Carb fixed
      


      foreach ($results as $key => $result) {
        if(isset($result[0])){
          $dmpType          =  $result[0]['fym_dmp_type'];

          $data[$dmpType]['fixed_carb']['protien']        =   0;
          $data[$dmpType]['fixed_carb']['calorie']        =   0;
          $data[$dmpType]['fixed_carb']['carbs']          =   0;
          $data[$dmpType]['fixed_carb']['fat']            =   0;

          $data[$dmpType]['balance_after_fixed_carb']['protien']  =   $data[$dmpType]['balance_after_nonfixed_protien']['protien'];
          $data[$dmpType]['balance_after_fixed_carb']['calorie']  =   $data[$dmpType]['balance_after_nonfixed_protien']['calorie'];
          $data[$dmpType]['balance_after_fixed_carb']['carbs']    =   $data[$dmpType]['balance_after_nonfixed_protien']['carbs'];


          foreach($result as $mkey => $meal){

                if($meal['serving_size_fixed']==1 && $meal['focus']=='CARBOHYDRATE' and $data[$dmpType]['balance_after_fixed_carb']['carbs'] > 0){
                      
                      $proteinTot  +=   $meal['protien'];
                      $calorieTot  +=   $meal['calorie'];
                      $carbTot     +=   $meal['carbs'];
                      $fatTot      +=   $meal['fat'];

                      $results[$key][$mkey]['status']          = 'active';

                      //for debug only
                      $debug[] = array(
                          'dmp'=>$dmpType,
                          'fixed_achived'=>array(
                              'protien'=>$meal['protien'],
                              'calorie'=> $meal['calorie'],
                              'carbs'=> $meal['carbs'],
                              'fat'=>$meal['fat'],

                            ),
                          'fixed_has'=>array(
                              'protien'=> $meal['protien'],
                              'calorie'=> $meal['calorie'],
                              'carbs'=> $meal['carbs'],
                              'fat'=> $meal['fat'],

                            ),
                          'genere'=>'fixed','protien'=>$meal['protien'],'carb'=>$meal['carbs']);

                      $results[$key][$mkey]['status']          = 'active';

                      $data[$dmpType]['fixed_carb']['protien']        +=   $meal['protien'];
                      $data[$dmpType]['fixed_carb']['calorie']        +=   $meal['calorie'];
                      $data[$dmpType]['fixed_carb']['carbs']          +=   $meal['carbs'];

                      $calAchived +=   $meal['calorie'];
                      $data['cal_achived'][$dmpType] = $calAchived;
                          $data['cal_achived_report'][$dmpType][] = array('cal'=>$meal['calorie'],'serving_size'=>1,'totcal'=>$meal['calorie']*1);
                      $data['cal_achived_coremeal'] +=  $meal['calorie'];

                      $data[$dmpType]['balance_after_fixed_carb']['protien']  -=   $meal['protien'];
                      $data[$dmpType]['balance_after_fixed_carb']['calorie']  -=   $meal['calorie'];
                      $data[$dmpType]['balance_after_fixed_carb']['carbs']    -=   $meal['carbs'];

                }
          }

        }
      }


      ///////////////////////////////////////////////////////////////////////////////////////////////
      ///                                         non fixed carbs
      ////////////////////////////////////////////////////////////////////////////////////////////
      
      foreach ($results as $key => $result) {
        if(isset($result[0])){
          $dmpType          =  $result[0]['fym_dmp_type'];


          $data[$dmpType]['nonfixed_carb']['protien']        =   0;
          $data[$dmpType]['nonfixed_carb']['calorie']        =   0;
          $data[$dmpType]['nonfixed_carb']['carbs']          =   0;

          $data[$dmpType]['balance_after_nonfixed_carb']['protien']  =   $data[$dmpType]['balance_after_fixed_carb']['protien'];
          $data[$dmpType]['balance_after_nonfixed_carb']['calorie']  =   $data[$dmpType]['balance_after_fixed_carb']['calorie'];
          $data[$dmpType]['balance_after_nonfixed_carb']['carbs']    =   $data[$dmpType]['balance_after_fixed_carb']['carbs'];

          foreach($result as $mkey => $meal){
                if($meal['serving_size_fixed']==0 && $meal['focus']=='CARBOHYDRATE' && $data[$dmpType]['balance_after_nonfixed_carb']['carbs'] > 0){
                    $carbNeeded  =   ($data[$dmpType]['balance_after_nonfixed_carb']['carbs']/(($data[$dmpType]['nonfixed_carb_focus']==0)?1:$data[$dmpType]['nonfixed_carb_focus'] ));
                    $servingSize =    $carbNeeded/$meal['carbs'];
                    

                      if($servingSize<0.25){
                          $data[$dmpType]['delete_nonfixed_protein_item_lesthan']     +=   1;
                          unset($results[$key][$mkey]);
                      } else {
                          $data[$dmpType]['nonfixed_carb']['protien']  +=   $servingSize * $meal['protien'];
                          $data[$dmpType]['nonfixed_carb']['calorie']  +=   $servingSize * $meal['calorie'];
                          $data[$dmpType]['nonfixed_carb']['carbs']    +=   $servingSize * $meal['carbs'];

                          $calAchived +=   ($servingSize * $meal['calorie']);
                          $data['cal_achived'][$dmpType] = $calAchived;
                          $data['cal_achived_report'][$dmpType][] = array('cal'=>$meal['calorie'],'serving_size'=>$servingSize,'totcal'=>$meal['calorie']*$servingSize);                        
                          $data['cal_achived_coremeal'] += ($servingSize * $meal['calorie']);

                          $results[$key][$mkey]['serving_size']          = $servingSize;
                          $results[$key][$mkey]['serving_size_adjusted'] = 1;

                          $proteinTot  +=   $servingSize * $meal['protien'];
                          $calorieTot  +=   $servingSize * $meal['calorie'];
                          $carbTot     +=   $servingSize * $meal['carbs'];
                          $fatTot      +=   $servingSize * $meal['fat'];

                          $data[$dmpType]['balance_after_nonfixed_carb']['protien']  -=   $servingSize * $meal['protien'];
                          $data[$dmpType]['balance_after_nonfixed_carb']['calorie']  -=   $servingSize * $meal['calorie'];
                          $data[$dmpType]['balance_after_nonfixed_carb']['carbs']    -=   $servingSize * $meal['carbs'];

                          $results[$key][$mkey]['status']          = 'active';

                          $debug[] = array(
                            'nut_achived'=>array(
                                'protien'=>$servingSize * $meal['protien'],
                                'calorie'=>$servingSize * $meal['calorie'],
                                'carbs'=>$servingSize * $meal['carbs'],
                                'fat'=>$servingSize * $meal['fat'],

                              ),
                            'nut_has'=>array(
                                'protien'=> $meal['protien'],
                                'calorie'=> $meal['calorie'],
                                'carbs'=> $meal['carbs'],
                                'fat'=> $meal['fat'],

                              ),
                            'genere'=>'non_fixed','dmp'=>$dmpType,'type'=>'carb','$carbNeeded'=>$carbNeeded,'$servingSize'=>$servingSize,'balance'=>$data[$dmpType]['balance_after_nonfixed_carb']['carbs'],'carb_focus_count'=>($data[$dmpType]['nonfixed_carb_focus']==0)?1:$data[$dmpType]['nonfixed_carb_focus'],'protien'=>$meal['protien'],'carb'=>$meal['carbs']);
                      }          
                          $data[$dmpType]['nonfixed_carb_focus']--;
                }
          }
        }
      }//eof non fixed carbs



      $totalCalorieAfterCoreMeal = 0;
      $data['cal_details']       = array();
      foreach($data['cal_achived_report'] as $key1=>$calAchvedData){
          $data['cal_details'][$key1]['total']=0;
          foreach($calAchvedData as $valCal){
              $totalCalorieAfterCoreMeal += $valCal['totcal'];
              $data['cal_details'][$key1][]=$valCal['totcal'];
              $data['cal_details'][$key1]['total']+= $valCal['totcal'];
          }
      }

      $data['cal_details']['last']=$totalCalorieAfterCoreMeal;



      $calAchivedTillCoreMeal = $totalCalorieAfterCoreMeal;
      $data['cal_achived_coremeal'] =$totalCalorieAfterCoreMeal;
      $data['cal_achived_coremeal2'] =$calAchived;
     

      //echo 

      ///snacks
       $tempSnacksCount                       =    $snacks;
       $nonfixedSnacks                        =    0;

       //print_r($data);die('333');
       //echo ' protien--'.$data[$dmpType]['balance_after_nonfixed_carb']['protien'];
       //echo ' carbs--'.$data[$dmpType]['balance_after_nonfixed_carb']['carbs'];   
       //echo ' calorie--'.$data[$dmpType]['balance_after_nonfixed_carb']['calorie']; 
      


          // $SproteinFind  = $SproteinFind + $data[$dmpType]['balance_after_nonfixed_carb']['protien'];
          // $ScarbFind     = $ScarbFind    + $data[$dmpType]['balance_after_nonfixed_carb']['carbs'];   
          // $ScalorieFind  = $ScalorieFind + $data[$dmpType]['balance_after_nonfixed_carb']['calorie']; 

          $data['snacks']['protien']        =   0;
          $data['snacks']['calorie']        =   0;
          $data['snacks']['carbs']          =   0;

     
      foreach ($results as $key => $result) {
        // echo $ScalorieReq."--".$data['snacks']['calorie']."</hr>";
        if(isset($result[0]) ){
          $dmpType          =  $result[0]['fym_dmp_type'];
          $melaType         =  $result[0]['meal_type'];

          $data[$dmpType]['snacks']['protien']        =   0;
          $data[$dmpType]['snacks']['calorie']        =   0;
          $data[$dmpType]['snacks']['carbs']          =   0;

          
          $data[$dmpType]['balance_after_calorie']['protien']  =   $SproteinFind;
          $data[$dmpType]['balance_after_calorie']['calorie']  =   $ScalorieFind;
          $data[$dmpType]['balance_after_calorie']['carbs']    =   $ScarbFind;

          
          foreach($result as $mkey => $meal){
                 // and  $ScalorieReq>$data['snacks']['calorie']
                if($melaType=='Snacks' && $data[$dmpType]['balance_after_calorie']['calorie'] > 0){
                 // echo "sma-",$data[$dmpType]['balance_after_calorie']['calorie']."-";
                //echo $ScalorieReq."--".$data['snacks']['calorie']."</hr>";                    
                if($meal['serving_size_fixed']==0){
                    $nonfixedSnacks++;
                 
                } else {
                        $proteinTot  +=   $meal['protien'];
                        $calorieTot  +=   $meal['calorie'];
                        $carbTot     +=   $meal['carbs'];
                        $fatTot      +=   $meal['fat'];

                        $results[$key][$mkey]['status']          = 'active';

                        //for debug only
                        $debug[] = array(
                            'dmp'=>$dmpType,
                            'fixed_achived'=>array(
                                'protien'=>$meal['protien'],
                                'calorie'=> $meal['calorie'],
                                'carbs'=> $meal['carbs'],
                                'fat'=>$meal['fat'],

                              ),
                            'fixed_has'=>array(
                                'protien'=> $meal['protien'],
                                'calorie'=> $meal['calorie'],
                                'carbs'=> $meal['carbs'],
                                'fat'=> $meal['fat'],

                              ),
                            'genere'=>'fixed','protien'=>$meal['protien'],'carb'=>$meal['carbs']);

                        $results[$key][$mkey]['status']          = 'active';

                        $data[$dmpType]['snacks']['protien']        +=   $meal['protien'];
                        $data[$dmpType]['snacks']['calorie']        +=   $meal['calorie'];
                        $data[$dmpType]['snacks']['carbs']          +=   $meal['carbs'];

                        $calAchived +=   $meal['calorie'];

                        $data['snacks']['protien']                  +=   $meal['protien'];
                        $data['snacks']['calorie']                  +=   $meal['calorie'];
                        $data['snacks']['carbs']                    +=   $meal['carbs'];

                        

                        $data[$dmpType]['balance_after_calorie']['protien']  -=   $meal['protien'];
                        $data[$dmpType]['balance_after_calorie']['calorie']  -=   $meal['calorie'];
                        $data[$dmpType]['balance_after_calorie']['carbs']    -=   $meal['carbs'];
                        $tempSnacksCount--;
                    }
                      
                }
          }
        }
      }


      $data['snacks_report']['nonfixedSnacks']    =    $nonfixedSnacks;
      $data['snacks_report']['bal_cal']           =    $calories-$calAchivedTillCoreMeal ;
      
      if($nonfixedSnacks>0){
          $data['snacks_report']['bal_caltoachiv']    =    (($calories-$calAchivedTillCoreMeal)/$nonfixedSnacks);
          $calNeedAchSnacks   = (($calories-$calAchivedTillCoreMeal)/$snacks);
      } else {
        $calNeedAchSnacks =0;
      }


      ///non fixed snacks
      foreach ($results as $key => $result) {
        // echo $ScalorieReq."--".$data['snacks']['calorie']."</hr>";
        if(isset($result[0])  and $nonfixedSnacks>0){
          $dmpType          =  $result[0]['fym_dmp_type'];
          $melaType         =  $result[0]['meal_type'];

          $data[$dmpType]['snacks']['protien']        =   0;
          $data[$dmpType]['snacks']['calorie']        =   0;
          $data[$dmpType]['snacks']['carbs']          =   0;
          
          $data[$dmpType]['balance_after_calorie']['protien']  =   $SproteinFind;
          $data[$dmpType]['balance_after_calorie']['calorie']  =   $calNeedAchSnacks;
          $data[$dmpType]['balance_after_calorie']['carbs']    =   $ScarbFind;

          
          foreach($result as $mkey => $meal){

                 // and  $ScalorieReq>$data['snacks']['calorie']
                if($melaType=='Snacks' && $data[$dmpType]['balance_after_calorie']['calorie'] > 0){
                 
                 // echo "sma-",$data[$dmpType]['balance_after_calorie']['calorie']."-";
                //echo $ScalorieReq."--".$data['snacks']['calorie']."</hr>";                    
                if($meal['serving_size_fixed']==0){
                     //(($tempSnacksCount==0)?1:$tempSnacksCount )
                          $calorieNeeded  =   ($data[$dmpType]['balance_after_calorie']['calorie']);
                          $servingSize    =    $calorieNeeded/$meal['calorie'];


                        if($servingSize<0.25){
                            $data[$dmpType]['delete_nonfixed_protein_item_lesthan']     +=   1;
                            unset($results[$key][$mkey]);
                        } else {
                            $data[$dmpType]['snacks']['protien']  +=   $servingSize * $meal['protien'];
                            $data[$dmpType]['snacks']['calorie']  +=   $servingSize * $meal['calorie'];
                            $data[$dmpType]['snacks']['carbs']    +=   $servingSize * $meal['carbs'];

                            $calAchived +=   ($servingSize * $meal['calorie']);
                            $data['snacks_report']['nonfixed'][$dmpType]           = $servingSize * $meal['calorie'];
                            $data['snacks_report']['last'][$dmpType] = $calAchived;

                            $results[$key][$mkey]['serving_size']          = $servingSize;
                            $results[$key][$mkey]['serving_size_adjusted'] = 1;

                            $proteinTot  +=   $servingSize * $meal['protien'];
                            $calorieTot  +=   $servingSize * $meal['calorie'];
                            $carbTot     +=   $servingSize * $meal['carbs'];
                            $fatTot      +=   $servingSize * $meal['fat'];

                            $data['snacks']['protien']        +=   $servingSize * $meal['protien'];
                            $data['snacks']['calorie']        +=   $servingSize * $meal['calorie'];;
                            $data['snacks']['carbs']          +=   $servingSize * $meal['carbs'];

                            $data[$dmpType]['balance_after_calorie']['protien']  -=   $servingSize * $meal['protien'];
                            $data[$dmpType]['balance_after_calorie']['calorie']  -=   $servingSize * $meal['calorie'];
                            $data[$dmpType]['balance_after_calorie']['carbs']    -=   $servingSize * $meal['carbs'];

                            $results[$key][$mkey]['status']          = 'active';

                            $debug[] = array(
                              'nut_achived'=>array(
                                  'protien'=>$servingSize * $meal['protien'],
                                  'calorie'=>$servingSize * $meal['calorie'],
                                  'carbs'=>$servingSize * $meal['carbs'],
                                  'fat'=>$servingSize * $meal['fat'],

                                ),
                              'nut_has'=>array(
                                  'protien'=> $meal['protien'],
                                  'calorie'=> $meal['calorie'],
                                  'carbs'=> $meal['carbs'],
                                  'fat'=> $meal['fat'],

                                ),
                              'genere'=>'snacks','dmp'=>$dmpType,'type'=>'carb','$carbNeeded'=>$calorieNeeded,'$servingSize'=>$servingSize,'balance'=>$data[$dmpType]['balance_after_calorie']['calorie']);
                        }          

                        $tempSnacksCount--;
                 
              

                     //$tempSnacksCount--;
                    } 
                      
                }
          }
        }
      }




      $data['last']['achived']['protein']    =    $proteinTot;
      $data['last']['achived']['carb']       =    $carbTot;
      $data['last']['achived']['calorie']    =    $calorieTot;
      $data['last']['achived']['fat']        =    $fatTot;

      $data['last']['balance']['protein']    =    $params->proteins - $proteinTot;
      $data['last']['balance']['carb']       =    $params->carbs    - $carbTot;
      $data['last']['balance']['calorie']    =    $params->calories - $calorieTot;
      $data['last']['balance']['fat']        =    $params->fats     - $fatTot;


      $mealList  = array();
      
      foreach ($results as $key => $result) {
            foreach($result as $mkey => $meal){
                if(isset($meal['status']) &&  $meal['status']=='active'){
                    $meal['calofitem']=$meal['serving_size']*$meal['calorie'];
                    $mealList[]=$meal;
                     $wholeList[$meal['fym_dmp_type']][]   = array('id'=>$meal['id'],'focus'=>$meal['focus'],'cal'=>$meal['serving_size']*$meal['calorie']);
                }
            }
      }

      return array('results'=>$mealList,'report'=>$data,'debug'=>$debug,'wholeList'=>$wholeList);





  }



  public function calculateMeal($type,$proteinFind,$carbFind,$queryTale,$mealType,$dmpMealType,$parent,$row_id,$mainType,$dmpMealTypeSlug,$nutritional_plan,$locale){
        $results = array();

        $query = "SELECT dmp_meal.*,IF(dmp_meal.serving_size>0,true,false) as serving_size_fixed FROM dmp_meal
                WHERE type='".$type."' $queryTale
                AND status_id=1 AND nutritional_plan=".$nutritional_plan."
                ORDER BY RAND()
                LIMIT 1 ";
        $statement            =   $this->adapter->createStatement($query);

        $result               =   $statement->execute();
        $meal                 =   $result->getResource()->fetch(2);
        $meal['fym_dmp_type'] =   $dmpMealType;
        $meal['meal_type']    =   $mealType;
        $meal['parent']       =   $parent;
        $meal['row_id']       =   $row_id;
        $meal['type']         =   $mainType;
        $meal['focus']        =   !empty($meal['focus'])?$meal['focus']:'CALORIE';
        $meal['when_delete']  =   !empty($meal['id'])?$meal['id']:'';
        $meal['fym_dmp_slug'] =   $dmpMealTypeSlug;

        if($locale=='es' && isset($meal['id']) && $meal['name_es']!=''){
          $meal['name'] =$meal['name_es'];
        }

        $results[]           =   $meal;


        // if($proteinFind<=$meal['protien'] || $carbFind<=$meal['carbs']){
        //     return $results;
        // } else {
            if(count($meal)>0 && isset($meal['id'])){
                $mealId  =  $meal['id'];
                $mealDets = $this->getAddtMeal($mealId,$mealType,$mealId,$dmpMealType,$dmpMealTypeSlug,$locale);

                if(count($mealDets)>0){
                    foreach($mealDets as $skey =>$mealDet){
                        $mealDet['when_delete'] = $mealId.",".$mealDet['id'];
                        $mealDet['chance']        =   'second';//$mainType;

                          //echo  $mealDet['id']."-".$mealDet['type']."--";
                          if($mealDet['type']=='auto_choice'){
                           // echo "kunna";
                              $mealDet['focus']='PROTEIN';
                          } else {
                             //echo "mairu";
                              $mealDet['focus']='CARBOHYDRATE';
                          }

                          $focus = $mealDet['focus'];

                        $results[]              = $mealDet;

                        $addDets = $this->getAddtMeal($mealDet['id'],$mealType,$mealId,$dmpMealType,$dmpMealTypeSlug,$locale);

                        
                          if(count($addDets)>0){
                              foreach ($addDets as $key => $addDet) {

                                  $addDet['when_delete']  = $mealId.",".$mealDet['id'].",".$addDet['id'];
                                  $addDet['chance']        = 'third';
                                  $addDet['focus']       = $focus;
                                  $results[]              = $addDet;
                                  
                              }
                          }
                    }
                }

                return $results;
            }
        //}

        
    }


    public function getAddtMeal($mealId,$mealType,$parentId,$dmpMealType,$dmpMealTypeSlug,$locale){
        $this->getAdapter();
        $query = "SELECT dmp_meal.*,IF(dmp_meal.serving_size>0,true,false) as serving_size_fixed,row_id,dmp_meal_details.type 
                  FROM (select * from dmp_meal_details ORDER BY RAND()) as dmp_meal_details
                  JOIN dmp_meal ON dmp_meal.id  =  dmp_meal_details.assoc_meal_id
                  WHERE dmp_meal_id=$mealId
                  GROUP BY dmp_meal_details.type,row_id
                  ORDER BY RAND()
                  ";
        $statement = $this->adapter->createStatement($query);

        $result = $statement->execute();
        $mealDets   = $result->getResource()->fetchAll(2);
        
        if(count($mealDets)>0){
          foreach($mealDets as $key => $mealDet){
              if($locale=='es' && isset($mealDets['id']) && $mealDets['name_es']!=''){
                  $mealDets[$key]['name'] =$mealDets['name_es'];
              }
              $mealDets[$key] = $mealDet;
              $mealDets[$key]['meal_type'] = $mealType;
              $mealDets[$key]['fym_dmp_type'] = $dmpMealType;
              $mealDets[$key]['parent']    = $mealId;
              $mealDets[$key]['fym_dmp_slug']    = $dmpMealTypeSlug;

              
              

              //echo $mealId."-";
          }
          return $mealDets;
        }

    }





















  
}
