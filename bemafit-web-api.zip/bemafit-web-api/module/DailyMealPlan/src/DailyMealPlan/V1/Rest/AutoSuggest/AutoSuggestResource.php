<?php
namespace DailyMealPlan\V1\Rest\AutoSuggest;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class AutoSuggestResource extends AbstractResourceListener
{

    protected $mapper;
 
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }
    /**
     * Create a resource
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        return new ApiProblem(405, 'The POST method has not been defined');
    }

    /**
     * Delete a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function delete($id)
    {
        return new ApiProblem(405, 'The DELETE method has not been defined for individual resources');
    }

    /**
     * Delete a collection, or members of a collection
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        return new ApiProblem(405, 'The DELETE method has not been defined for collections');
    }

    /**
     * Fetch a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($id)
    {
        return new ApiProblem(405, 'The GET method has not been defined for individual resources');
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($params = array())
    {
        @$data->coremeal = $this->getEvent()->getRequest()->getQuery('coremeal', 0);
        $data->snacks    = $this->getEvent()->getRequest()->getQuery('snacks', 0);
        
        $data->calories    = $this->getEvent()->getRequest()->getQuery('calories', 0);
        $data->carbs    = $this->getEvent()->getRequest()->getQuery('carbs', 0);
        $data->fats    = $this->getEvent()->getRequest()->getQuery('fats', 0);
        $data->proteins    = $this->getEvent()->getRequest()->getQuery('proteins', 0);
        $data->nutritional_plan    = $this->getEvent()->getRequest()->getQuery('nutritional_plan', 1);

        $data->locale    = $this->getEvent()->getRequest()->getQuery('locale', 'en');

        @$data->userId = $this->getIdentity()->getUserId();

        $autoSuggest = $this->mapper->fetchAll($data);

        return array(
                'meta'=>array('status'=>'ok','code'=>200,'method_name'=>'get daily meal plan',
                ),'result'=>$autoSuggest['results'],'report'=>$autoSuggest['report'],'debug'=>$autoSuggest['debug'],'wholeList'=>$autoSuggest['wholeList']);
    }

    /**
     * Patch (partial in-place update) a resource
     *
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        return new ApiProblem(405, 'The PATCH method has not been defined for individual resources');
    }

    /**
     * Replace a collection or members of a collection
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return new ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     *
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        return new ApiProblem(405, 'The PUT method has not been defined for individual resources');
    }
}
