<?php
namespace DailyMealPlan\V1\Rest\Share;

class ShareEntity
{
}
