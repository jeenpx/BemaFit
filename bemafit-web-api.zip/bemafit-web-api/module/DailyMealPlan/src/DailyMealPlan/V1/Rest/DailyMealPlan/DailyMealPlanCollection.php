<?php
namespace DailyMealPlan\V1\Rest\DailyMealPlan;

use Zend\Paginator\Paginator;

class DailyMealPlanCollection extends Paginator
{
}
