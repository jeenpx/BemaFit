<?php

namespace DailyMealPlan\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class DmpMealDetailTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function create($data)
    {
        //print_r($data);
        $this->tableGateway->insert($data);
    }

    public function update($userDetailData, $where)
    {
        $this->tableGateway->update($userDetailData, $where);
    }

    public function deleteAll($where)
    {
        $this->tableGateway->delete($where);
    }
}
