<?php
namespace DailyMealPlan\V1\Model;


class DmpDetail
{
	public $id;
    public $guid;
    

    public function getArrayCopy()
    {
        return array(
            'id'     => $this->id,
            'guid' => $this->guid,
        );
    }

    public function exchangeArray(array $array)
    {
        $this->id     = $array['id'];
        $this->guid     = $array['guid'];

    }
    
}
