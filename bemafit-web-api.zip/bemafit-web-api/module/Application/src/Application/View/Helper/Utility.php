<?php

namespace Application\View\Helper;

use Zend\View\Helper\AbstractHelper;
use Zend\Authentication\AuthenticationService;

class Utility extends AbstractHelper
{
    /**
     * @var ServiceManager
     */
    protected $serviceManager;

    /**
     * __invoke
     *
     * @access public
     * @return Organization 
     */
    public function __invoke()
    {
        return $this->getServiceManager()->get('utility_service');
    }

    /**
     * Get serviceManager.
     *
     * @return serviceManager
     */
    public function getServiceManager()
    {
        return $this->serviceManager;
    }

    /**
     * Set serviceManager.
     *
     * @param $serviceManager
     * @return \User\View\Helper\UserProfile
     */
    public function setServiceManager($serviceManager)
    {
        $this->serviceManager = $serviceManager;
        return $this;
    }
}