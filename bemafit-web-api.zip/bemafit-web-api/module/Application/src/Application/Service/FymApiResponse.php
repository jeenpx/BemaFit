<?php

namespace Application\Service;

use AppBase\EventManager\EventProvider;

class FymApiResponse extends EventProvider
{
    
    public  function __construct()
    {
    }
    public function getStatusCodes()
    {

    }
    public static function FymApiResponse($status_code, $extra_parameters = null) {
        
        
        header('Content-type: application/json');
        echo json_encode(
                $status_code
            );
        exit;
    }

}