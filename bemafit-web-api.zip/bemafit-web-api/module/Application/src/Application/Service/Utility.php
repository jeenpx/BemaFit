<?php

namespace Application\Service;
use AppBase\EventManager\EventProvider;
use Aws\S3\S3Client;

class Utility extends EventProvider {
	private $serviceManager;

	public function getFymUserDetailTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('User\Model\FymUserDetailTable');
		return $this->Table;
	}

	function sendIOSPushnotification($deviceTokens = array(), $payload = array(), $notificationCountArr = array()) {

		if (sizeof($deviceTokens) == 0) {
			return false;
		}

		$payload['alert'] = urldecode($payload['alert']);
		$config           = $this->getServiceLocator()->get('Config');
		//$current_user_info = $this->getFymUserDetailTable()->getUserDetailsById(1);
		$pushConf = $config['apple_pushnotifications'];

		$tempPayload = $payload;
		$apnsHost    = $pushConf['apnsHost'];
		$apnsPort    = $pushConf['apnsPort'];
		$apnsCert    = $pushConf['apnsCert'];
		$passphrase  = $pushConf['passphrase'];

		$registration_id = $deviceTokens[0];
		$ctx             = stream_context_create();
		stream_context_set_option($ctx, 'ssl', 'local_cert', $apnsCert);
		stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
		$apns = stream_socket_client(
			'ssl://'.$apnsHost.':'.$apnsPort,
			$error,
			$errorString,
			2,
			STREAM_CLIENT_CONNECT,
			$ctx
		);
		stream_set_blocking($apns, 0);

		if ($apns) {
			$payload['aps'] = array(
				'alert' => $payload['alert'],
				'badge' => 0,
				'sound' => 'default',
			);
			unset($payload['alert']);
			$data = json_encode($payload);

			$total = 250;
			$len   = strlen($data);

			if ($len > $total) {
				/* limit alert message */
				$exeptDataLen = $len-strlen($payload['aps']['alert']);
				if ($exeptDataLen > $total) {
					/* data is too large */
					return array('success' => false, 'message' => 'Data is too large');
				} else {
					$availabledataLen = $total-$exeptDataLen;
					//$payload['aps']['alert'] = substr($payload['aps']['alert'], 0, $availabledataLen);
					$data = json_encode($payload);
				}
			}
			foreach ($deviceTokens as $token) {

				$apple_identifier = 1234;
				$apple_expiry     = time()+(90*24*60*60);
				$cleanToken       = str_replace(' ', '', $token);
				//$apnsMessage = chr(0) . chr(0) . chr(32) . @pack('H*', str_replace(' ', '', $token)) . chr(0) . chr(strlen($data)) . $data;
				try
				{
					$apnsMessage = pack("C", 1).
					pack("N", $apple_identifier).
					pack("N", $apple_expiry).
					pack("n", 32).
					pack("H*", $cleanToken).
					pack("n", strlen($data)).$data;//Enhanced Notification
					fwrite($apns, $apnsMessage);
					usleep(500000);
					if ($this->checkAppleErrorResponse($apns)) {
						$ctx = stream_context_create();
						stream_context_set_option($ctx, 'ssl', 'local_cert', $apnsCert);
						stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
						$apns = stream_socket_client('ssl://'.$apnsHost.':'.$apnsPort, $error, $errorString, 2, STREAM_CLIENT_CONNECT, $ctx);
						stream_set_blocking($apns, 0);
					}
				} catch (\Exception $ex) {
				}
			}
			fclose($apns);
			return array('success' => true);
		}
		return array('success' => false, 'message' => 'Socket connection failed');
	}

	function checkAppleErrorResponse($fp) {
		$apple_error_response = fread($fp, 6);
		if ($apple_error_response) {
			/*
			$error_response = unpack('Ccommand/Cstatus_code/Nidentifier', $apple_error_response); //unpack the error response (first byte 'command" should always be 8)

			if ($error_response['status_code'] == '0') {
			$error_response['status_code'] = '0-No errors encountered';

			} else if ($error_response['status_code'] == '1') {
			$error_response['status_code'] = '1-Processing error';

			} else if ($error_response['status_code'] == '2') {
			$error_response['status_code'] = '2-Missing device token';

			} else if ($error_response['status_code'] == '3') {
			$error_response['status_code'] = '3-Missing topic';

			} else if ($error_response['status_code'] == '4') {
			$error_response['status_code'] = '4-Missing payload';

			} else if ($error_response['status_code'] == '5') {
			$error_response['status_code'] = '5-Invalid token size';

			} else if ($error_response['status_code'] == '6') {
			$error_response['status_code'] = '6-Invalid topic size';

			} else if ($error_response['status_code'] == '7') {
			$error_response['status_code'] = '7-Invalid payload size';

			} else if ($error_response['status_code'] == '8') {
			$error_response['status_code'] = '8-Invalid token';

			} else if ($error_response['status_code'] == '255') {
			$error_response['status_code'] = '255-None (unknown)';

			} else {
			$error_response['status_code'] = $error_response['status_code'].'-Not listed';

			}

			echo '<br><b>+ + + + + + ERROR</b> Response Command:<b>' . $error_response['command'] . '</b>&nbsp;&nbsp;&nbsp;Identifier:<b>' . $error_response['identifier'] . '</b>&nbsp;&nbsp;&nbsp;Status:<b>' . $error_response['status_code'] . '</b><br>';
			echo 'Identifier is the rowID (index) in the database that caused the problem, and Apple will disconnect you from server. To continue sending Push Notifications, just start at the next rowID after this Identifier.<br>';

			 */
			return true;
		}
		return false;
	}

	function truncate($text, $limit, $ellipsis = '...') {
		if (strlen($text) > $limit) {
			$text = trim(substr($text, 0, $limit)).$ellipsis;
		}

		return $text;
	}

	public function photoUpload($params = array()) {

		$target_dir    = $params['upload_dir'];
		$target_file   = $target_dir.$params['image_name'];
		$uploadOk      = 1;
		$imageFileType = pathinfo($_FILES["photo"]["name"], PATHINFO_EXTENSION);
		$status        = false;
		$message       = '';
		// Check if image file is a actual image or fake image
		if (isset($_POST["submit"])) {
			$check = getimagesize($_FILES["photo"]["tmp_name"]);
			if ($check !== false) {
				$message  = "File is an image - ".$check["mime"].".";
				$uploadOk = 1;
			} else {
				$message  = "File is not an image.";
				$uploadOk = 0;
			}
		}
		$sizeInfo     = array();
		$getImageSize = @getimagesize($_FILES["photo"]["tmp_name"]);
		if (isset($getImageSize)) {
			$sizeInfo['width']  = $getImageSize[0];
			$sizeInfo['height'] = $getImageSize[1];
		}
		// Check if file already exists
		if (file_exists($target_file)) {
			$message  = "Sorry, file already exists.";
			$uploadOk = 0;
		}
		// Check file size
		if ($_FILES["photo"]["size"] > 5242880) {
			$message  = "Sorry, your file is too large.";
			$uploadOk = 0;
		}
		$imageFileType = strtolower($imageFileType);
		// Allow certain file formats
		if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			 && $imageFileType != "gif") {
			$message  = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			$uploadOk = 0;
		}
		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
			//$message  =  "Sorry, your file was not uploaded.";
			// if everything is ok, try to upload file
		} else {
			if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file.'.'.$imageFileType)) {
				return array('status' => true, 'file_name' => $params['image_name'].'.'.$imageFileType, 'sizeinfo' => $sizeInfo);
			} else {
				$message = "Sorry, there was an error uploading your file.";
			}
		}
		return array('status' => $status, 'message' => $message, 'sizeinfo' => $sizeInfo);
	}

	/**
	 * easy image resize function
	 * @param  $file - file name to resize
	 * @param  $string - The image data, as a string
	 * @param  $width - new image width
	 * @param  $height - new image height
	 * @param  $proportional - keep image proportional, default is no
	 * @param  $output - name of the new file (include path if needed)
	 * @param  $delete_original - if true the original image will be deleted
	 * @param  $use_linux_commands - if set to true will use "rm" to delete the image, if false will use PHP unlink
	 * @param  $quality - enter 1-100 (100 is best quality) default is 100
	 * @return boolean|resource
	 */
	function smart_resize_image($file,
		$string = null,
		$width = 0,
		$height = 0,
		$proportional = false,
		$output = 'file',
		$delete_original = true,
		$use_linux_commands = false,
		$quality = 100
	) {

		if ($height <= 0 && $width <= 0) {return false;
		}

		if ($file === null && $string === null) {return false;
		}

		# Setting defaults and meta
		$info                         = $file !== null?getimagesize($file):getimagesizefromstring($string);
		$image                        = '';
		$final_width                  = 0;
		$final_height                 = 0;
		list($width_old, $height_old) = $info;
		$cropHeight                   = $cropWidth                   = 0;

		# Calculating proportionality
		if ($proportional) {
			if ($width == 0) {$factor        = $height/$height_old;
			} elseif ($height == 0) {$factor = $width/$width_old;
			} else {
				$factor = min($width/$width_old, $height/$height_old);
			}

			$final_width  = round($width_old*$factor);
			$final_height = round($height_old*$factor);
		} else {
			$final_width  = ($width <= 0)?$width_old:$width;
			$final_height = ($height <= 0)?$height_old:$height;
			$widthX       = $width_old/$width;
			$heightX      = $height_old/$height;

			$x          = min($widthX, $heightX);
			$cropWidth  = ($width_old-$width*$x)/2;
			$cropHeight = ($height_old-$height*$x)/2;
		}

		# Loading image to memory according to type
		switch ($info[2]) {
			case IMAGETYPE_JPEG:$file !== null?$image = imagecreatefromjpeg($file):$image = imagecreatefromstring($string);
				break;
			case IMAGETYPE_GIF:$file !== null?$image = imagecreatefromgif($file):$image = imagecreatefromstring($string);
				break;
			case IMAGETYPE_PNG:$file !== null?$image = imagecreatefrompng($file):$image = imagecreatefromstring($string);
				break;
			default:return false;
		}

		# This is the resizing/resampling/transparency-preserving magic
		$image_resized = imagecreatetruecolor($final_width, $final_height);
		if (($info[2] == IMAGETYPE_GIF) || ($info[2] == IMAGETYPE_PNG)) {
			$transparency = imagecolortransparent($image);
			$palletsize   = imagecolorstotal($image);

			if ($transparency >= 0 && $transparency < $palletsize) {
				$transparent_color = imagecolorsforindex($image, $transparency);
				$transparency      = imagecolorallocate($image_resized, $transparent_color['red'], $transparent_color['green'], $transparent_color['blue']);
				imagefill($image_resized, 0, 0, $transparency);
				imagecolortransparent($image_resized, $transparency);
			} elseif ($info[2] == IMAGETYPE_PNG) {
				imagealphablending($image_resized, false);
				$color = imagecolorallocatealpha($image_resized, 0, 0, 0, 127);
				imagefill($image_resized, 0, 0, $color);
				imagesavealpha($image_resized, true);
			}
		}
		imagecopyresampled($image_resized, $image, 0, 0, $cropWidth, $cropHeight, $final_width, $final_height, $width_old-2*$cropWidth, $height_old-2*$cropHeight);

		# Taking care of original, if needed
		if ($delete_original) {
			if ($use_linux_commands) {exec('rm '.$file);
			} else {
				@unlink($file);
			}
		}

		# Preparing a method of providing result
		switch (strtolower($output)) {
			case 'browser':
				$mime = image_type_to_mime_type($info[2]);
				header("Content-type: $mime");
				$output = NULL;
				break;
			case 'file':
				$output = $file;
				break;
			case 'return':
				return $image_resized;
				break;
			default:
				break;
		}

		# Writing image according to type to the output destination and image quality
		switch ($info[2]) {
			case IMAGETYPE_GIF:imagegif($image_resized, $output);
				break;
			case IMAGETYPE_JPEG:imagejpeg($image_resized, $output, $quality);
				break;
			case IMAGETYPE_PNG:
				$quality = 9-(int) ((0.9*$quality)/10.0);
				imagepng($image_resized, $output, $quality);
				break;
			default:return false;
		}

		return true;
	}

	public function getAwsImageUrl($url) {

		$config = new \Zend\Config\Config('amazon_ses');
		//$config = $this->getServiceLocator()->get('Config');
		$client = S3Client::factory(array(
				// 'key'    => 'AKIAI6BKMDRJ7HAUXGBQ',
				// 'secret' => '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',
				// 'region' => 'us-east-1',
				'key'    => 'AKIAJXZA5BCZGVQOSRHA',
				'secret' => '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',
				'region' => 'us-east-1',
			));

		$url       = 'fymprofile/1b02e25e5ec6005d8208cd24a8e83ae8.jpeg';
		$request   = $client->get($url);
		$signedUrl = $client->createPresignedUrl($request, '+1 year');
	}

	public function getLocale($locale) {
		if (!empty($locale)) {
			if (in_array($locale, array('en', 'es'))) {
				return $locale;
			} else {
				return 'en';
			}
		} else {
			return 'en';
		}
	}

	public function getFacebookProfileIDByAccessToken($access_token) {
		$facebook_info = @json_decode(@file_get_contents("https://graph.facebook.com/me?access_token=".$access_token), true);
		if (!isset($facebook_info['id'])) {
			return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid facebook id');
		}
		return $facebook_info['id'];
	}

	/**
	 * Get serviceManager.
	 *
	 * @return serviceManager
	 */
	public function getServiceLocator() {
		return $this->serviceManager;
	}

	/**
	 * Set serviceManager.
	 *
	 * @param $serviceManager
	 * @return \User\View\Helper\UserProfile
	 */
	public function setServiceManager($serviceManager) {
		$this->serviceManager = $serviceManager;
		return $this;
	}

	function stripslashes_deep($value)
	{
	    $value = is_array($value) ?
	                array_map('stripslashes_deep', $value) :
	                stripslashes($value);

	    return $value;
	}


}
