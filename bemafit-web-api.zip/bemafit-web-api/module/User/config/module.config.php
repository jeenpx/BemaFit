<?php
return array(
    'service_manager' => array(
        'factories' => array(
            'ZF\\OAuth2\\Service\\OAuth2Server' => 'User\\MvcAuth\\Factory\\NamedOAuth2ServerFactory',
            'User\\V1\\Rest\\User\\UserResource' => 'User\\V1\\Rest\\User\\UserResourceFactory',
            'User\\V1\\Rest\\UserProfile\\UserProfileResource' => 'User\\V1\\Rest\\UserProfile\\UserProfileResourceFactory',
            'User\\V1\\Rest\\Foodlog\\FoodlogResource' => 'User\\V1\\Rest\\Foodlog\\FoodlogResourceFactory',
            'User\\V1\\Rest\\Exerciselog\\ExerciselogResource' => 'User\\V1\\Rest\\Exerciselog\\ExerciselogResourceFactory',
            'User\\V1\\Rest\\Weightlog\\WeightlogResource' => 'User\\V1\\Rest\\Weightlog\\WeightlogResourceFactory',
            'User\\V1\\Rest\\FriendRequest\\FriendRequestResource' => 'User\\V1\\Rest\\FriendRequest\\FriendRequestResourceFactory',
            'User\\V1\\Rest\\Friends\\FriendsResource' => 'User\\V1\\Rest\\Friends\\FriendsResourceFactory',
            'User\\V1\\Rest\\Macro\\MacroResource' => 'User\\V1\\Rest\\Macro\\MacroResourceFactory',
            'User\\V1\\Rest\\Follow\\FollowResource' => 'User\\V1\\Rest\\Follow\\FollowResourceFactory',
            'User\\V1\\Rest\\Progress\\ProgressResource' => 'User\\V1\\Rest\\Progress\\ProgressResourceFactory',
            'User\\V1\\Rest\\UserSettings\\UserSettingsResource' => 'User\\V1\\Rest\\UserSettings\\UserSettingsResourceFactory',
        ),
    ),
    'view_manager' => array(
        'template_path_stack' => array(
            0 => __DIR__ . '/../view',
        ),
        'strategies' => array(
            0 => 'ViewJsonStrategy',
        ),
    ),
    'zf-oauth2' => array(
        'storage' => 'User\\OAuth2\\Adapter\\PdoAdapter',
    ),
    'router' => array(
        'routes' => array(
            'user.rest.user' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user[/:user_id]',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rest\\User\\Controller',
                    ),
                ),
            ),
            'user.rest.user-profile' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user/[:guid]/user-profile[/:type]',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rest\\UserProfile\\Controller',
                    ),
                ),
            ),
            'user.rest.foodlog' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/foodlog[/:foodlog_id]',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rest\\Foodlog\\Controller',
                    ),
                ),
            ),
            'user.rest.exerciselog' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/exerciselog[/:exerciselog_id]',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rest\\Exerciselog\\Controller',
                    ),
                ),
            ),
            'user.rpc.forgot-password' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user/forgotpassword',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rpc\\ForgotPassword\\Controller',
                        'action' => 'forgotPassword',
                    ),
                ),
            ),
            'user.rest.weightlog' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/weightlog[/:weightlog_id]',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rest\\Weightlog\\Controller',
                    ),
                ),
            ),
            'user.rpc.verify-user' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user/verify',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rpc\\VerifyUser\\Controller',
                        'action' => 'verifyUser',
                    ),
                ),
            ),
            'user.rest.friend-request' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user/friend-request[/:friend_id]',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rest\\FriendRequest\\Controller',
                    ),
                ),
            ),
            'user.rest.friends' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user[/:user_id]/friends[/:friend_id]',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rest\\Friends\\Controller',
                    ),
                ),
            ),
            'user.rest.macro' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/macro[/:macro_id]',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rest\\Macro\\Controller',
                    ),
                ),
            ),
            'user.rest.follow' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user/[:user_id]/follow[/:friend_id]',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rest\\Follow\\Controller',
                    ),
                ),
            ),
            'user.rest.progress' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/progress[/:progress_id]',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rest\\Progress\\Controller',
                    ),
                ),
            ),
            'user.rpc.change-password' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user[/:user_id]/changepassword',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rpc\\ChangePassword\\Controller',
                        'action' => 'changePassword',
                    ),
                ),
            ),
            'user.rpc.invite-friends' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user[/:user_id]/invitefriends',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rpc\\InviteFriends\\Controller',
                        'action' => 'inviteFriends',
                    ),
                ),
            ),
            'user.rest.user-settings' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user/[:user_id]/user-settings[/:user_settings_id]',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rest\\UserSettings\\Controller',
                    ),
                ),
            ),
            'user.rpc.change-profile-photo' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user[/:user_id]/profile-photo',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rpc\\ChangeProfilePhoto\\Controller',
                        'action' => 'changeProfilePhoto',
                    ),
                ),
            ),
            'user.rpc.logout' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user/logout',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rpc\\Logout\\Controller',
                        'action' => 'logout',
                    ),
                ),
            ),
            'user.rpc.facebook-login' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/fb-auth',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rpc\\FacebookLogin\\Controller',
                        'action' => 'facebookLogin',
                    ),
                ),
            ),
            'user.rpc.facebook-connect' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/fb-connect',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rpc\\FacebookConnect\\Controller',
                        'action' => 'facebookConnect',
                    ),
                ),
            ),
            'user.rpc.contact' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/contact',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rpc\\Contact\\Controller',
                        'action' => 'contact',
                    ),
                ),
            ),
            'user.rpc.refresh-token' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/refresh-token',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rpc\\RefreshToken\\Controller',
                        'action' => 'refreshToken',
                    ),
                ),
            ),
            'user.rpc.resend-confirmation-email' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/resend-mail',
                    'defaults' => array(
                        'controller' => 'User\\V1\\Rpc\\ResendConfirmationEmail\\Controller',
                        'action' => 'resendConfirmationEmail',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            0 => 'user.rest.user',
            2 => 'user.rest.user-profile',
            3 => 'user.rest.foodlog',
            4 => 'user.rest.exerciselog',
            5 => 'user.rpc.forgot-password',
            6 => 'user.rest.weightlog',
            7 => 'user.rpc.verify-user',
            8 => 'user.rest.friend-request',
            9 => 'user.rest.friends',
            11 => 'user.rest.macro',
            12 => 'user.rest.follow',
            13 => 'user.rest.progress',
            14 => 'user.rpc.change-password',
            15 => 'user.rpc.invite-friends',
            16 => 'user.rest.user-settings',
            17 => 'user.rpc.change-profile-photo',
            18 => 'user.rpc.logout',
            19 => 'user.rpc.facebook-login',
            20 => 'user.rpc.facebook-connect',
            21 => 'user.rpc.contact',
            22 => 'user.rpc.refresh-token',
            23 => 'user.rpc.resend-confirmation-email',
        ),
    ),
    'zf-rest' => array(
        'User\\V1\\Rest\\User\\Controller' => array(
            'listener' => 'User\\V1\\Rest\\User\\UserResource',
            'route_name' => 'user.rest.user',
            'route_identifier_name' => 'user_id',
            'collection_name' => 'user',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'User\\V1\\Rest\\User\\UserEntity',
            'collection_class' => 'User\\V1\\Rest\\User\\UserCollection',
            'service_name' => 'user',
        ),
        'User\\V1\\Rest\\UserProfile\\Controller' => array(
            'listener' => 'User\\V1\\Rest\\UserProfile\\UserProfileResource',
            'route_name' => 'user.rest.user-profile',
            'route_identifier_name' => 'user_profile_id',
            'collection_name' => 'user_profile',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'User\\V1\\Rest\\UserProfile\\UserProfileEntity',
            'collection_class' => 'User\\V1\\Rest\\UserProfile\\UserProfileCollection',
            'service_name' => 'UserProfile',
        ),
        'User\\V1\\Rest\\Foodlog\\Controller' => array(
            'listener' => 'User\\V1\\Rest\\Foodlog\\FoodlogResource',
            'route_name' => 'user.rest.foodlog',
            'route_identifier_name' => 'foodlog_id',
            'collection_name' => 'foodlog',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(
                0 => 'date',
                1 => 'limit',
                2 => 'offset',
            ),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'User\\V1\\Rest\\Foodlog\\FoodlogEntity',
            'collection_class' => 'User\\V1\\Rest\\Foodlog\\FoodlogCollection',
            'service_name' => 'foodlog',
        ),
        'User\\V1\\Rest\\Exerciselog\\Controller' => array(
            'listener' => 'User\\V1\\Rest\\Exerciselog\\ExerciselogResource',
            'route_name' => 'user.rest.exerciselog',
            'route_identifier_name' => 'exerciselog_id',
            'collection_name' => 'exerciselog',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(
                0 => 'date',
                1 => 'limit',
                2 => 'offset',
            ),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'User\\V1\\Rest\\Exerciselog\\ExerciselogEntity',
            'collection_class' => 'User\\V1\\Rest\\Exerciselog\\ExerciselogCollection',
            'service_name' => 'exerciselog',
        ),
        'User\\V1\\Rest\\Weightlog\\Controller' => array(
            'listener' => 'User\\V1\\Rest\\Weightlog\\WeightlogResource',
            'route_name' => 'user.rest.weightlog',
            'route_identifier_name' => 'weightlog_id',
            'collection_name' => 'weightlog',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(
                0 => 'date',
            ),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'User\\V1\\Rest\\Weightlog\\WeightlogEntity',
            'collection_class' => 'User\\V1\\Rest\\Weightlog\\WeightlogCollection',
            'service_name' => 'weightlog',
        ),
        'User\\V1\\Rest\\FriendRequest\\Controller' => array(
            'listener' => 'User\\V1\\Rest\\FriendRequest\\FriendRequestResource',
            'route_name' => 'user.rest.friend-request',
            'route_identifier_name' => 'friend_id',
            'collection_name' => 'friend_request',
            'entity_http_methods' => array(
                0 => 'PUT',
                1 => 'POST',
                2 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'POST',
                1 => 'PUT',
                2 => 'DELETE',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'User\\V1\\Rest\\FriendRequest\\FriendRequestEntity',
            'collection_class' => 'User\\V1\\Rest\\FriendRequest\\FriendRequestCollection',
            'service_name' => 'FriendRequest',
        ),
        'User\\V1\\Rest\\Friends\\Controller' => array(
            'listener' => 'User\\V1\\Rest\\Friends\\FriendsResource',
            'route_name' => 'user.rest.friends',
            'route_identifier_name' => 'user_id',
            'collection_name' => 'friends',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'DELETE',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'User\\V1\\Rest\\Friends\\FriendsEntity',
            'collection_class' => 'User\\V1\\Rest\\Friends\\FriendsCollection',
            'service_name' => 'Friends',
        ),
        'User\\V1\\Rest\\Macro\\Controller' => array(
            'listener' => 'User\\V1\\Rest\\Macro\\MacroResource',
            'route_name' => 'user.rest.macro',
            'route_identifier_name' => 'macro_id',
            'collection_name' => 'macro',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(
                0 => 'date',
                1 => 'limit',
            ),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'User\\V1\\Rest\\Macro\\MacroEntity',
            'collection_class' => 'User\\V1\\Rest\\Macro\\MacroCollection',
            'service_name' => 'macro',
        ),
        'User\\V1\\Rest\\Follow\\Controller' => array(
            'listener' => 'User\\V1\\Rest\\Follow\\FollowResource',
            'route_name' => 'user.rest.follow',
            'route_identifier_name' => 'follow_id',
            'collection_name' => 'follow',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'DELETE',
                2 => 'POST',
            ),
            'collection_http_methods' => array(
                0 => 'POST',
                1 => 'DELETE',
                2 => 'GET',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'User\\V1\\Rest\\Follow\\FollowEntity',
            'collection_class' => 'User\\V1\\Rest\\Follow\\FollowCollection',
            'service_name' => 'Follow',
        ),
        'User\\V1\\Rest\\Progress\\Controller' => array(
            'listener' => 'User\\V1\\Rest\\Progress\\ProgressResource',
            'route_name' => 'user.rest.progress',
            'route_identifier_name' => 'progress_id',
            'collection_name' => 'progress',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(
                0 => 'progress_type',
                1 => 'progress_date',
                2 => 'progress_date_type',
                3 => 'progress_page_count',
            ),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'User\\V1\\Rest\\Progress\\ProgressEntity',
            'collection_class' => 'User\\V1\\Rest\\Progress\\ProgressCollection',
            'service_name' => 'progress',
        ),
        'User\\V1\\Rest\\UserSettings\\Controller' => array(
            'listener' => 'User\\V1\\Rest\\UserSettings\\UserSettingsResource',
            'route_name' => 'user.rest.user-settings',
            'route_identifier_name' => 'user_settings_id',
            'collection_name' => 'user_settings',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'User\\V1\\Rest\\UserSettings\\UserSettingsEntity',
            'collection_class' => 'User\\V1\\Rest\\UserSettings\\UserSettingsCollection',
            'service_name' => 'UserSettings',
        ),
    ),
    'controllers' => array(
        'invokables' => array(),
        'factories' => array(
            'User\\V1\\Rpc\\ForgotPassword\\Controller' => 'User\\V1\\Rpc\\ForgotPassword\\ForgotPasswordControllerFactory',
            'User\\V1\\Rpc\\VerifyUser\\Controller' => 'User\\V1\\Rpc\\VerifyUser\\VerifyUserControllerFactory',
            'User\\V1\\Rpc\\ChangePassword\\Controller' => 'User\\V1\\Rpc\\ChangePassword\\ChangePasswordControllerFactory',
            'User\\V1\\Rpc\\InviteFriends\\Controller' => 'User\\V1\\Rpc\\InviteFriends\\InviteFriendsControllerFactory',
            'User\\V1\\Rpc\\ChangeProfilePhoto\\Controller' => 'User\\V1\\Rpc\\ChangeProfilePhoto\\ChangeProfilePhotoControllerFactory',
            'User\\V1\\Rpc\\Logout\\Controller' => 'User\\V1\\Rpc\\Logout\\LogoutControllerFactory',
            'User\\V1\\Rpc\\FacebookLogin\\Controller' => 'User\\V1\\Rpc\\FacebookLogin\\FacebookLoginControllerFactory',
            'User\\V1\\Rpc\\FacebookConnect\\Controller' => 'User\\V1\\Rpc\\FacebookConnect\\FacebookConnectControllerFactory',
            'User\\V1\\Rpc\\Contact\\Controller' => 'User\\V1\\Rpc\\Contact\\ContactControllerFactory',
            'User\\V1\\Rpc\\RefreshToken\\Controller' => 'User\\V1\\Rpc\\RefreshToken\\RefreshTokenControllerFactory',
            'User\\V1\\Rpc\\ResendConfirmationEmail\\Controller' => 'User\\V1\\Rpc\\ResendConfirmationEmail\\ResendConfirmationEmailControllerFactory',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'User\\V1\\Rest\\User\\Controller' => 'Json',
            'User\\V1\\Rest\\UserProfile\\Controller' => 'Json',
            'User\\V1\\Rest\\Foodlog\\Controller' => 'Json',
            'User\\V1\\Rest\\Exerciselog\\Controller' => 'Json',
            'User\\V1\\Rpc\\ForgotPassword\\Controller' => 'Json',
            'User\\V1\\Rest\\Weightlog\\Controller' => 'Json',
            'User\\V1\\Rpc\\VerifyUser\\Controller' => 'Json',
            'User\\V1\\Rest\\FriendRequest\\Controller' => 'Json',
            'User\\V1\\Rest\\Friends\\Controller' => 'Json',
            'User\\V1\\Rest\\Macro\\Controller' => 'Json',
            'User\\V1\\Rest\\Follow\\Controller' => 'Json',
            'User\\V1\\Rest\\Progress\\Controller' => 'Json',
            'User\\V1\\Rpc\\ChangePassword\\Controller' => 'Json',
            'User\\V1\\Rpc\\InviteFriends\\Controller' => 'Json',
            'User\\V1\\Rest\\UserSettings\\Controller' => 'Json',
            'User\\V1\\Rpc\\ChangeProfilePhoto\\Controller' => 'Json',
            'User\\V1\\Rpc\\Logout\\Controller' => 'Json',
            'User\\V1\\Rpc\\FacebookLogin\\Controller' => 'Json',
            'User\\V1\\Rpc\\FacebookConnect\\Controller' => 'Json',
            'User\\V1\\Rpc\\Contact\\Controller' => 'Json',
            'User\\V1\\Rpc\\RefreshToken\\Controller' => 'Json',
            'User\\V1\\Rpc\\ResendConfirmationEmail\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'User\\V1\\Rest\\User\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'User\\V1\\Rest\\UserProfile\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'User\\V1\\Rest\\Foodlog\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rest\\Exerciselog\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rpc\\ForgotPassword\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'User\\V1\\Rest\\Weightlog\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'User\\V1\\Rpc\\VerifyUser\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'User\\V1\\Rest\\FriendRequest\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'User\\V1\\Rest\\Friends\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'User\\V1\\Rest\\Macro\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'User\\V1\\Rest\\Follow\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'User\\V1\\Rest\\Progress\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'User\\V1\\Rpc\\ChangePassword\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'User\\V1\\Rpc\\InviteFriends\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'User\\V1\\Rest\\UserSettings\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'User\\V1\\Rpc\\ChangeProfilePhoto\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'User\\V1\\Rpc\\Logout\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'User\\V1\\Rpc\\FacebookLogin\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'User\\V1\\Rpc\\FacebookConnect\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'User\\V1\\Rpc\\Contact\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'User\\V1\\Rpc\\RefreshToken\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'User\\V1\\Rpc\\ResendConfirmationEmail\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
        ),
        'content_type_whitelist' => array(
            'User\\V1\\Rest\\User\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
                2 => 'multipart/form-data',
            ),
            'User\\V1\\Rest\\Foodlog\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rest\\Exerciselog\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rpc\\ForgotPassword\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rest\\Weightlog\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rpc\\VerifyUser\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rest\\FriendRequest\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rest\\Friends\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rest\\Macro\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rest\\Follow\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rest\\Progress\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rpc\\ChangePassword\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rpc\\InviteFriends\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rest\\UserSettings\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rpc\\ChangeProfilePhoto\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rpc\\Logout\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rest\\UserProfile\\Controller' => array(
                0 => 'application/json',
            ),
            'User\\V1\\Rpc\\FacebookLogin\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rpc\\FacebookConnect\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rpc\\Contact\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rpc\\RefreshToken\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
            'User\\V1\\Rpc\\ResendConfirmationEmail\\Controller' => array(
                0 => 'application/vnd.user.v1+json',
                1 => 'application/json',
            ),
        ),
        'zf-hal' => array(
            'metadata_map' => array(
                'User\\V1\\Rest\\User\\UserEntity' => array(
                    'entity_identifier_name' => 'id',
                    'route_name' => 'user.rest.user',
                    'route_identifier_name' => 'user_id',
                    'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
                ),
                'User\\V1\\Rest\\User\\UserCollection' => array(
                    'entity_identifier_name' => 'id',
                    'route_name' => 'user.rest.user',
                    'route_identifier_name' => 'user_id',
                    'is_collection' => true,
                ),
                'User\\V1\\Rest\\Progress\\ProgressEntity' => array(
                    'entity_identifier_name' => 'id',
                    'route_name' => 'user.rest.progress',
                    'route_identifier_name' => 'progress_id',
                    'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
                ),
                'User\\V1\\Rest\\Progress\\ProgressCollection' => array(
                    'entity_identifier_name' => 'id',
                    'route_name' => 'user.rest.progress',
                    'route_identifier_name' => 'progress_id',
                    'User\\V1\\Rest\\UserProfile\\UserProfileEntity' => array(
                        'entity_identifier_name' => 'id',
                        'route_name' => 'user.rest.user-profile',
                        'route_identifier_name' => 'user_profile_id',
                        'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
                    ),
                    'User\\V1\\Rest\\UserProfile\\UserProfileCollection' => array(
                        'entity_identifier_name' => 'id',
                        'route_name' => 'user.rest.user-profile',
                        'route_identifier_name' => 'user_profile_id',
                        'is_collection' => true,
                    ),
                    'User\\V1\\Rest\\Foodlog\\FoodlogEntity' => array(
                        'entity_identifier_name' => 'id',
                        'route_name' => 'user.rest.foodlog',
                        'route_identifier_name' => 'foodlog_id',
                        'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
                    ),
                    'User\\V1\\Rest\\Foodlog\\FoodlogCollection' => array(
                        'entity_identifier_name' => 'id',
                        'route_name' => 'user.rest.foodlog',
                        'route_identifier_name' => 'foodlog_id',
                        'is_collection' => true,
                    ),
                    'User\\V1\\Rest\\Exerciselog\\ExerciselogEntity' => array(
                        'entity_identifier_name' => 'id',
                        'route_name' => 'user.rest.exerciselog',
                        'route_identifier_name' => 'exerciselog_id',
                        'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
                    ),
                    'User\\V1\\Rest\\Exerciselog\\ExerciselogCollection' => array(
                        'entity_identifier_name' => 'id',
                        'route_name' => 'user.rest.exerciselog',
                        'route_identifier_name' => 'exerciselog_id',
                        'is_collection' => true,
                    ),
                ),
            ),
            'zf-content-validation' => array(
                'User\\V1\\Rest\\User\\Controller' => array(
                    'input_filter' => 'User\\V1\\Rest\\User\\Validator',
                ),
                'User\\V1\\Rest\\Progress\\Controller' => array(
                    'input_filter' => 'User\\V1\\Rest\\Progress\\Validator',
                ),
                'User\\V1\\Rest\\Foodlog\\Controller' => array(
                    'input_filter' => 'User\\V1\\Rest\\Foodlog\\Validator',
                ),
                'User\\V1\\Rest\\Exerciselog\\Controller' => array(
                    'input_filter' => 'User\\V1\\Rest\\Exerciselog\\Validator',
                ),
            ),
            'zf-mvc-auth' => array(
                'authorization' => array(
                    'User\\V1\\Rest\\User\\Controller' => array(
                        'entity' => array(
                            'GET' => false,
                            'POST' => false,
                            'PATCH' => false,
                            'PUT' => false,
                            'DELETE' => false,
                        ),
                        'collection' => array(
                            'GET' => false,
                            'POST' => true,
                            'PATCH' => false,
                            'PUT' => false,
                            'DELETE' => false,
                        ),
                    ),
                    'User\\V1\\Rest\\Progress\\Controller' => array(
                        'entity' => array(
                            'GET' => true,
                            'POST' => true,
                            'PATCH' => true,
                            'PUT' => true,
                            'DELETE' => true,
                        ),
                        'collection' => array(
                            'GET' => true,
                            'POST' => true,
                            'PATCH' => true,
                            'PUT' => true,
                            'DELETE' => true,
                        ),
                    ),
                    'User\\V1\\Rest\\UserProfile\\Controller' => array(
                        'entity' => array(
                            'GET' => true,
                            'POST' => false,
                            'PATCH' => false,
                            'PUT' => false,
                            'DELETE' => false,
                        ),
                        'collection' => array(
                            'GET' => true,
                            'POST' => false,
                            'PATCH' => false,
                            'PUT' => false,
                            'DELETE' => false,
                        ),
                    ),
                    'User\\V1\\Rest\\Foodlog\\Controller' => array(
                        'entity' => array(
                            'GET' => false,
                            'POST' => false,
                            'PATCH' => false,
                            'PUT' => false,
                            'DELETE' => false,
                        ),
                        'collection' => array(
                            'GET' => true,
                            'POST' => true,
                            'PATCH' => false,
                            'PUT' => false,
                            'DELETE' => false,
                        ),
                    ),
                    'User\\V1\\Rest\\Exerciselog\\Controller' => array(
                        'entity' => array(
                            'GET' => false,
                            'POST' => false,
                            'PATCH' => false,
                            'PUT' => false,
                            'DELETE' => false,
                        ),
                        'collection' => array(
                            'GET' => false,
                            'POST' => true,
                            'PATCH' => false,
                            'PUT' => false,
                            'DELETE' => false,
                        ),
                    ),
                ),
            ),
            'zf-mvc-auth-user' => array(
                'authorization' => array(
                    'User\\V1\\Rest\\User\\Controller' => array(
                        'user' => array(
                            'entity' => false,
                            'collection' => false,
                        ),
                        'application' => array(
                            'entity' => 'all',
                            'collection' => 'all',
                        ),
                    ),
                ),
            ),
        ),
    ),
    'zf-content-validation' => array(
        'User\\V1\\Rest\\User\\Controller' => array(
            'input_filter' => 'User\\V1\\Rest\\User\\Validator',
        ),
        'User\\V1\\Rest\\Foodlog\\Controller' => array(
            'input_filter' => 'User\\V1\\Rest\\Foodlog\\Validator',
        ),
        'User\\V1\\Rest\\Exerciselog\\Controller' => array(
            'input_filter' => 'User\\V1\\Rest\\Exerciselog\\Validator',
        ),
        'User\\V1\\Rest\\Weightlog\\Controller' => array(
            'input_filter' => 'User\\V1\\Rest\\Weightlog\\Validator',
        ),
        'zf-rpc' => array(
            'User\\V1\\Rpc\\ForgotPassword\\Controller' => array(
                'service_name' => 'ForgotPassword',
                'http_methods' => array(
                    0 => 'POST',
                ),
                'route_name' => 'user.rpc.forgot-password',
            ),
        ),
        'zf-hal' => array(
            'metadata_map' => array(
                'User\\V1\\Rest\\Weightlog\\WeightlogEntity' => array(
                    'entity_identifier_name' => 'id',
                    'route_name' => 'user.rest.weightlog',
                    'route_identifier_name' => 'weightlog_id',
                    'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
                ),
                'User\\V1\\Rest\\Weightlog\\WeightlogCollection' => array(
                    'entity_identifier_name' => 'id',
                    'route_name' => 'user.rest.weightlog',
                    'route_identifier_name' => 'weightlog_id',
                    'is_collection' => true,
                ),
            ),
        ),
        'zf-mvc-auth' => array(
            'authorization' => array(
                'User\\V1\\Rest\\User\\Controller' => array(
                    'entity' => array(
                        'GET' => false,
                        'POST' => false,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                    'collection' => array(
                        'GET' => false,
                        'POST' => false,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                ),
                'User\\V1\\Rest\\Progress\\Controller' => array(
                    'entity' => array(
                        'GET' => false,
                        'POST' => false,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                    'collection' => array(
                        'GET' => false,
                        'POST' => false,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                ),
                'User\\V1\\Rest\\UserProfile\\Controller' => array(
                    'entity' => array(
                        'GET' => false,
                        'POST' => false,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                    'collection' => array(
                        'GET' => false,
                        'POST' => false,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                ),
                'User\\V1\\Rest\\Foodlog\\Controller' => array(
                    'entity' => array(
                        'GET' => false,
                        'POST' => false,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                    'collection' => array(
                        'GET' => false,
                        'POST' => false,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                ),
                'User\\V1\\Rest\\Exerciselog\\Controller' => array(
                    'entity' => array(
                        'GET' => false,
                        'POST' => false,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                    'collection' => array(
                        'GET' => false,
                        'POST' => false,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                ),
                'User\\V1\\Rpc\\ForgotPassword\\Controller' => array(
                    'actions' => array(
                        'forgotPassword' => array(
                            'GET' => false,
                            'POST' => false,
                            'PATCH' => false,
                            'PUT' => false,
                            'DELETE' => false,
                        ),
                    ),
                ),
            ),
        ),
        'User\\V1\\Rpc\\VerifyUser\\Controller' => array(
            'input_filter' => 'User\\V1\\Rpc\\VerifyUser\\Validator',
        ),
        'User\\V1\\Rest\\FriendRequest\\Controller' => array(
            'input_filter' => 'User\\V1\\Rest\\FriendRequest\\Validator',
        ),
        'User\\V1\\Rest\\Macro\\Controller' => array(
            'input_filter' => 'User\\V1\\Rest\\Macro\\Validator',
        ),
        'User\\V1\\Rest\\Progress\\Controller' => array(
            'input_filter' => 'User\\V1\\Rest\\Progress\\Validator',
        ),
        'User\\V1\\Rpc\\ChangePassword\\Controller' => array(
            'input_filter' => 'User\\V1\\Rpc\\ChangePassword\\Validator',
        ),
        'User\\V1\\Rpc\\InviteFriends\\Controller' => array(
            'input_filter' => 'User\\V1\\Rpc\\InviteFriends\\Validator',
        ),
    ),
    'zf-hal' => array(
        'metadata_map' => array(
            'User\\V1\\Rest\\FriendRequest\\FriendRequestEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.friend-request',
                'route_identifier_name' => 'friend_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'User\\V1\\Rest\\FriendRequest\\FriendRequestCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.friend-request',
                'route_identifier_name' => 'friend_id',
                'is_collection' => true,
            ),
            'User\\V1\\Rest\\Friends\\FriendsEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.friends',
                'route_identifier_name' => 'user_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'User\\V1\\Rest\\Friends\\FriendsCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.friends',
                'route_identifier_name' => 'user_id',
                'is_collection' => true,
            ),
            'User\\V1\\Rest\\Macro\\MacroEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.macro',
                'route_identifier_name' => 'macro_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'User\\V1\\Rest\\Macro\\MacroCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.macro',
                'route_identifier_name' => 'macro_id',
                'is_collection' => true,
            ),
            'User\\V1\\Rest\\Follow\\FollowEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.follow',
                'route_identifier_name' => 'follow_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'User\\V1\\Rest\\Follow\\FollowCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.follow',
                'route_identifier_name' => 'follow_id',
                'is_collection' => true,
            ),
            'User\\V1\\Rest\\Progress\\ProgressEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.progress',
                'route_identifier_name' => 'progress_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'User\\V1\\Rest\\Progress\\ProgressCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.progress',
                'route_identifier_name' => 'progress_id',
                'is_collection' => true,
            ),
            'User\\V1\\Rest\\UserSettings\\UserSettingsEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.user-settings',
                'route_identifier_name' => 'user_settings_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'User\\V1\\Rest\\UserSettings\\UserSettingsCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.user-settings',
                'route_identifier_name' => 'user_settings_id',
                'is_collection' => true,
            ),
            'User\\V1\\Rest\\User\\UserEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.user',
                'route_identifier_name' => 'user_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'User\\V1\\Rest\\User\\UserCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.user',
                'route_identifier_name' => 'user_id',
                'is_collection' => true,
            ),
            'User\\V1\\Rest\\UserProfile\\UserProfileEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.user-profile',
                'route_identifier_name' => 'user_profile_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'User\\V1\\Rest\\UserProfile\\UserProfileCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.user-profile',
                'route_identifier_name' => 'user_profile_id',
                'is_collection' => true,
            ),
            'User\\V1\\Rest\\Exerciselog\\ExerciselogEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.exerciselog',
                'route_identifier_name' => 'exerciselog_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'User\\V1\\Rest\\Exerciselog\\ExerciselogCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'user.rest.exerciselog',
                'route_identifier_name' => 'exerciselog_id',
                'is_collection' => true,
            ),
        ),
    ),
    'zf-mvc-auth' => array(
        'authorization' => array(
            'User\\V1\\Rest\\User\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
            'User\\V1\\Rest\\UserProfile\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
            'User\\V1\\Rest\\Foodlog\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
            'User\\V1\\Rest\\Exerciselog\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
            'User\\V1\\Rest\\Weightlog\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
            'User\\V1\\Rest\\FriendRequest\\Controller' => array(
                'entity' => array(
                    'GET' => false,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => false,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => true,
                    'DELETE' => true,
                ),
            ),
            'User\\V1\\Rest\\Friends\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
            'User\\V1\\Rpc\\VerifyUser\\Controller' => array(
                'actions' => array(
                    'VerifyUser' => array(
                        'GET' => false,
                        'POST' => false,
                        'PUT' => false,
                        'PATCH' => false,
                        'DELETE' => false,
                    ),
                ),
            ),
            'User\\V1\\Rest\\Macro\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
            'User\\V1\\Rest\\Follow\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => true,
                ),
            ),
            'User\\V1\\Rest\\Progress\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
            'User\\V1\\Rest\\UserSettings\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
            'User\\V1\\Rpc\\ChangePassword\\Controller' => array(
                'actions' => array(
                    'changePassword' => array(
                        'GET' => false,
                        'POST' => true,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                ),
            ),
            'User\\V1\\Rpc\\InviteFriends\\Controller' => array(
                'actions' => array(
                    'inviteFriends' => array(
                        'GET' => false,
                        'POST' => true,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                ),
            ),
            'User\\V1\\Rpc\\ChangeProfilePhoto\\Controller' => array(
                'actions' => array(
                    'changeProfilePhoto' => array(
                        'GET' => false,
                        'POST' => true,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                ),
            ),
            'User\\V1\\Rpc\\Logout\\Controller' => array(
                'actions' => array(
                    'logout' => array(
                        'GET' => false,
                        'POST' => true,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                ),
            ),
            'User\\V1\\Rpc\\FacebookConnect\\Controller' => array(
                'actions' => array(
                    'FacebookConnect' => array(
                        'GET' => false,
                        'POST' => true,
                        'PUT' => false,
                        'PATCH' => false,
                        'DELETE' => false,
                    ),
                ),
            ),
            'User\\V1\\Rpc\\Contact\\Controller' => array(
                'actions' => array(
                    'Contact' => array(
                        'GET' => false,
                        'POST' => true,
                        'PUT' => false,
                        'PATCH' => false,
                        'DELETE' => false,
                    ),
                ),
            ),
            'User\\V1\\Rpc\\RefreshToken\\Controller' => array(
                'actions' => array(
                    'RefreshToken' => array(
                        'GET' => false,
                        'POST' => false,
                        'PUT' => false,
                        'PATCH' => false,
                        'DELETE' => false,
                    ),
                ),
            ),
        ),
    ),
    'zf-rpc' => array(
        'User\\V1\\Rpc\\VerifyUser\\Controller' => array(
            'service_name' => 'VerifyUser',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'user.rpc.verify-user',
        ),
        'User\\V1\\Rpc\\ChangePassword\\Controller' => array(
            'service_name' => 'ChangePassword',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'user.rpc.change-password',
        ),
        'User\\V1\\Rpc\\InviteFriends\\Controller' => array(
            'service_name' => 'InviteFriends',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'user.rpc.invite-friends',
        ),
        'User\\V1\\Rpc\\ChangeProfilePhoto\\Controller' => array(
            'service_name' => 'ChangeProfilePhoto',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'user.rpc.change-profile-photo',
        ),
        'User\\V1\\Rpc\\Logout\\Controller' => array(
            'service_name' => 'Logout',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'user.rpc.logout',
        ),
        'User\\V1\\Rpc\\FacebookLogin\\Controller' => array(
            'service_name' => 'FacebookLogin',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'user.rpc.facebook-login',
        ),
        'User\\V1\\Rpc\\FacebookConnect\\Controller' => array(
            'service_name' => 'FacebookConnect',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'user.rpc.facebook-connect',
        ),
        'User\\V1\\Rpc\\Contact\\Controller' => array(
            'service_name' => 'Contact',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'user.rpc.contact',
        ),
        'User\\V1\\Rpc\\RefreshToken\\Controller' => array(
            'service_name' => 'RefreshToken',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'user.rpc.refresh-token',
        ),
        'User\\V1\\Rpc\\ResendConfirmationEmail\\Controller' => array(
            'service_name' => 'ResendConfirmationEmail',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'user.rpc.resend-confirmation-email',
        ),
    ),
    'verificationDays' => 1,
    'defaultSettings' => '1,2,6,12,13,14,18,24,25',
    'facebook_credentials' => array(
        'app_id' => '802619706493288',
        'app_secret' => 'a0682a14536ffb8194240c56e1d5bd0e',
    ),
    'input_filter_specs' => array(
        'User\\V1\\Rest\\User\\Validator' => array(
            0 => array(
                'name' => 'user_name',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => true,
                'continue_if_empty' => true,
            ),
            1 => array(
                'name' => 'first_name',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
                'error_message' => 'firstName required.',
            ),
            2 => array(
                'name' => 'last_name',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
                'error_message' => 'lastName required',
            ),
            3 => array(
                'name' => 'email',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
                'error_message' => 'email required.',
            ),
            4 => array(
                'name' => 'password',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => true,
                'continue_if_empty' => true,
                'error_message' => 'password required',
            ),
            5 => array(
                'name' => 'facebookId',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            6 => array(
                'name' => 'gender',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => true,
                'continue_if_empty' => true,
            ),
            7 => array(
                'name' => 'dob',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => true,
                'continue_if_empty' => true,
            ),
            8 => array(
                'name' => 'height',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            9 => array(
                'name' => 'weight',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            10 => array(
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'name' => 'diet_formula',
                'continue_if_empty' => false,
            ),
            11 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'diet_activity_level',
            ),
            12 => array(
                'name' => 'dietGoal',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => true,
                'continue_if_empty' => true,
            ),
            13 => array(
                'required' => false,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => true,
                'name' => 'diet_goal_calories',
                'continue_if_empty' => true,
            ),
            14 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'diet_nutritional_plan',
            ),
            15 => array(
                'name' => 'dietFiber',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => true,
                'continue_if_empty' => true,
            ),
            16 => array(
                'name' => 'dietMacros',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => true,
                'continue_if_empty' => true,
            ),
            17 => array(
                'required' => false,
                'validators' => array(),
                'filters' => array(),
                'name' => 'website',
                'continue_if_empty' => false,
                'allow_empty' => true,
            ),
            18 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'filters' => array(),
                'name' => 'fat',
                'continue_if_empty' => true,
            ),
            19 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'diet_calory_type',
            ),
            20 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'filters' => array(),
                'name' => 'diet_macro_fiber',
                'continue_if_empty' => true,
                'allow_empty' => true,
            ),
            21 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'filters' => array(),
                'name' => 'diet_macro_fat',
                'continue_if_empty' => true,
                'allow_empty' => true,
            ),
            22 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'filters' => array(),
                'name' => 'diet_macro_carbs',
                'continue_if_empty' => true,
                'allow_empty' => true,
            ),
            23 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'filters' => array(),
                'name' => 'diet_macro_protein',
                'continue_if_empty' => true,
                'allow_empty' => true,
            ),
            24 => array(
                'required' => false,
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'filters' => array(),
                'name' => 'no_of_meals',
                'continue_if_empty' => true,
                'allow_empty' => true,
            ),
        ),
        'User\\V1\\Rest\\Progress\\Validator' => array(
            0 => array(
                'name' => 'progress_type',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymProgressReportType',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            1 => array(
                'name' => 'progress_date',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Zend\\Validator\\Date',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            2 => array(
                'name' => 'progress_date_type',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            3 => array(
                'name' => 'progress_page_count',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Zend\\I18n\\Validator\\Int',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
        ),
        'User\\V1\\Rest\\Foodlog\\Validator' => array(
            0 => array(
                'name' => 'log_type',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymFoodLogType',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            1 => array(
                'name' => 'meal_type',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            2 => array(
                'name' => 'meal_date',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Zend\\Validator\\Date',
                        'options' => array(),
                    ),
                ),
            ),
            3 => array(
                'name' => 'approve',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            4 => array(
                'name' => 'food_brand_name',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            5 => array(
                'name' => 'food_serving_size',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            6 => array(
                'name' => 'food_serving_no',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            7 => array(
                'name' => 'food_calorie',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            8 => array(
                'name' => 'food_fibre',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            9 => array(
                'name' => 'food_fat',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            10 => array(
                'name' => 'food_carb',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            11 => array(
                'name' => 'food_protein',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            12 => array(
                'name' => 'food_saturated',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            13 => array(
                'name' => 'food_polyunsaturated',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            14 => array(
                'name' => 'food_monosaturated',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            15 => array(
                'name' => 'food_trans',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            16 => array(
                'name' => 'food_cholestrol',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            17 => array(
                'name' => 'food_sodium',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            18 => array(
                'name' => 'food_pottassium',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            19 => array(
                'name' => 'food_id',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            20 => array(
                'name' => 'food_name',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
            21 => array(
                'name' => 'food_unit',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
            ),
        ),
        'User\\V1\\Rest\\Exerciselog\\Validator' => array(
            0 => array(
                'name' => 'log_type',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymExerciseLogType',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            1 => array(
                'name' => 'exercise_type',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            2 => array(
                'name' => 'exercise_date',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Zend\\Validator\\Date',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
        ),
        'User\\V1\\Rest\\Weightlog\\Validator' => array(
            0 => array(
                'name' => 'log_date',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Zend\\Validator\\Date',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            1 => array(
                'name' => 'log_weight',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            2 => array(
                'name' => 'log_bodyfat',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
            ),
        ),
        'User\\V1\\Rpc\\VerifyUser\\Validator' => array(),
        'User\\V1\\Rest\\FriendRequest\\Validator' => array(
            0 => array(
                'name' => 'response_status',
                'required' => false,
                'filters' => array(
                    0 => array(
                        'name' => 'Zend\\Filter\\StringTrim',
                        'options' => array(),
                    ),
                ),
                'validators' => array(),
                'allow_empty' => true,
                'continue_if_empty' => true,
            ),
        ),
        'User\\V1\\Rpc\\Macro\\Validator' => array(
            0 => array(
                'name' => 'date',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Zend\\Validator\\Date',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            1 => array(
                'name' => 'limit',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Zend\\I18n\\Validator\\Int',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
        ),
        'User\\V1\\Rest\\Macro\\Validator' => array(
            0 => array(
                'name' => 'date',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Zend\\Validator\\Date',
                        'options' => array(),
                    ),
                ),
            ),
            1 => array(
                'name' => 'limit',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Zend\\I18n\\Validator\\Int',
                        'options' => array(),
                    ),
                ),
            ),
        ),
        'User\\V1\\Rpc\\ChangePassword\\Validator' => array(
            0 => array(
                'name' => 'old_password',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            1 => array(
                'name' => 'new_password',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
        ),
        'User\\V1\\Rpc\\InviteFriends\\Validator' => array(
            0 => array(
                'name' => 'email',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Zend\\Validator\\EmailAddress',
                        'options' => array(),
                    ),
                ),
            ),
        ),
    ),
);
