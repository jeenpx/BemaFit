<?php
namespace User\MvcAuth\Authentication;

use ZF\MvcAuth\MvcAuthEvent;
use Zend\ServiceManager\ServiceManager;
use Zend\ServiceManager\ServiceManagerAwareInterface;
use User\MvcAuth\Identity;
use ZF\MvcAuth\Identity\GuestIdentity as ZF_GuestIdentity;
use ZF\MvcAuth\Identity\AuthenticatedIdentity as ZF_AuthenticatedIdentity;

class AuthenticationPost implements ServiceManagerAwareInterface
{
    public function __invoke(MvcAuthEvent $mvcAuthEvent)
    {
        $mvcEvent = $mvcAuthEvent->getMvcEvent();
        $identity = $mvcAuthEvent->getIdentity();

        if ($identity instanceof ZF_AuthenticatedIdentity) {
            $user_id = $identity->getName();
            $OAuth2Server = $this->getServiceManager()->get('ZF\OAuth2\Service\OAuth2Server');

            $identity = new Identity\AuthenticatedIdentity($identity);
            $identity->setName($user_id);
            if($userDetails  = $OAuth2Server()->getStorage('access_token')->getUserById($user_id)){
                $identity->setUserId($userDetails['id']);
                $identity->setName($userDetails['first_name'] . " " . $userDetails['last_name']);
                $identity->setFirstName($userDetails['first_name']);
                $identity->setLastName($userDetails['last_name']);
                $identity->setUsername($userDetails['username']);
                if(isset($userDetails['role'])){
                    $identity->setRole($userDetails['role']);
                }
                $identity->setLoggedIn(true);
            } else {
                $identity->setRole('application');
                $identity->setLoggedIn(false);
            }
            $mvcEvent->setParam('ZF\MvcAuth\Identity', $identity);
        } else {
            $identity = new Identity\GuestIdentity();
            $mvcEvent->setParam('ZF\MvcAuth\Identity', $identity);
        }
    }

    /**
     * Retrieve service manager instance
     *
     * @return ServiceManager
     */
    public function getServiceManager()
    {
        return $this->serviceManager;
    }

    /**
     * Set service manager instance
     *
     * @param ServiceManager $serviceManager
     * @return Organization
     */
    public function setServiceManager(ServiceManager $serviceManager)
    {
        $this->serviceManager = $serviceManager;
        return $this;
    }
}
?>