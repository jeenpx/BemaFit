<?php
namespace User\MvcAuth\Authorization;

use ZF\MvcAuth\MvcAuthEvent;
use Zend\ServiceManager\ServiceManager;
use Zend\ServiceManager\ServiceManagerAwareInterface;

class AuthorizationListener implements ServiceManagerAwareInterface
{
    public function __invoke(MvcAuthEvent $mvcAuthEvent)
    {
        $config = $this->getServiceManager()->get('config');
        $authorization = $mvcAuthEvent->getAuthorizationService();
        $method = $mvcAuthEvent->getMvcEvent()->getRequest()->getMethod();
        $resourceString = $mvcAuthEvent->getResource();
        $resource = explode("::", $resourceString)[0];
        $type = explode("::", $resourceString)[1];
        $role = $this->getServiceManager()->get('api-identity')->getRoleId();
        if(!$authorization->hasResource($resourceString)){
            $authorization->addResource($resourceString);
        }
        if(isset($config['zf-mvc-auth-user']['authorization'][$resource])){
            if(
                (isset($config['zf-mvc-auth-user']['authorization'][$resource][$role][$type]) && $config['zf-mvc-auth-user']['authorization'][$resource][$role][$type] == 'all') || 
                (isset($config['zf-mvc-auth-user']['authorization'][$resource][$role][$type][$method]) && $config['zf-mvc-auth-user']['authorization'][$resource][$role][$type][$method])
            ){
                if($role != "application" && !$this->getServiceManager()->get('api-identity')->isLoggedIn()){
                    $authorization->deny(null, $resourceString, $method);
                } else {
                    $authorization->addRole($role);
                    $authorization->allow($role, $resourceString, $method); 
                }
            } else {
                $authorization->deny(null, $resourceString, $method);
            }
        }
    }

    /**
     * Retrieve service manager instance
     *
     * @return ServiceManager
     */
    public function getServiceManager()
    {
        return $this->serviceManager;
    }

    /**
     * Set service manager instance
     *
     * @param ServiceManager $serviceManager
     * @return Organization
     */
    public function setServiceManager(ServiceManager $serviceManager)
    {
        $this->serviceManager = $serviceManager;
        return $this;
    }
}
?>