<?php
/**
 * @license   http://opensource.org/licenses/BSD-3-Clause BSD-3-Clause
 * @copyright Copyright (c) 2013 Zend Technologies USA Inc. (http://www.zend.com)
 */

namespace User\MvcAuth\Identity;

use Zend\Permissions\Rbac\AbstractRole as AbstractRbacRole;
use ZF\MvcAuth\Identity\IdentityInterface as IdentityInterface;

class GuestIdentity extends AbstractRbacRole implements IdentityInterface
{
    protected static $identity = 'guest';

    public function __construct()
    {
        $this->name = static::$identity;
    }

    public function getRoleId()
    {
        return static::$identity;
    }

    public function getAuthenticationIdentity()
    {
        return null;
    }

    public function isLoggedIn()
    {
        return false;
    }
}
