<?php
/**
 * @license   http://opensource.org/licenses/BSD-3-Clause BSD-3-Clause
 * @copyright Copyright (c) 2013 Zend Technologies USA Inc. (http://www.zend.com)
 */

namespace User\MvcAuth\Identity;

use Zend\Permissions\Rbac\AbstractRole as AbstractRbacRole;
use ZF\MvcAuth\Identity\IdentityInterface as IdentityInterface;

class AuthenticatedIdentity extends AbstractRbacRole implements IdentityInterface
{
    protected $identity;
    protected $user_id;
    protected $first_name;
    protected $last_name;
    protected $username;
    protected $logged_in;
    protected $role = 'user';

    public function __construct($identity)
    {
        $this->identity = $identity;
    }

    public function setLoggedIn($logged_in)
    {
        $this->logged_in = $logged_in;
    }

    public function isLoggedIn()
    {
        return $this->logged_in;
    }

    public function setRole($role)
    {
        $this->role = $role;
    }

    public function getRoleId()
    {
        return $this->role;
    }

    public function getAuthenticationIdentity()
    {
        return $this->identity;
    }

    public function setUserId($user_id)
    {
        $this->user_id = $user_id;
    }

    public function getUserId()
    {
        return $this->user_id;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function setFirstName($first_name)
    {
        $this->first_name = $first_name;
    }

    public function getFirstName()
    {
        return $this->first_name;
    }

    public function setLastName($last_name)
    {
        $this->last_name = $last_name;
    }

    public function getLastName()
    {
        return $this->last_name;
    }

    public function getEmail()
    {
        return $this->identity['user_id'];
    }

    public function setUsername($username)
    {
        $this->username = $username;
    }

    public function getUsername()
    {
        return $this->username;
    }
}