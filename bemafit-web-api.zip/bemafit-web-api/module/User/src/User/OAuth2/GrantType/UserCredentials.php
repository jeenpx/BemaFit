<?php

namespace User\OAuth2\GrantType;

use OAuth2\Storage\UserCredentialsInterface;
use OAuth2\ResponseType\AccessTokenInterface;
use OAuth2\RequestInterface;
use OAuth2\ResponseInterface;
use OAuth2\GrantType\GrantTypeInterface;
use Zend\Mvc\Controller\AbstractActionController;
use Aws\S3\S3Client;
/**
 *
 * @author Brent Shaffer <bshafs at gmail dot com>
 */
class UserCredentials extends AbstractActionController implements GrantTypeInterface 
{
    private $userInfo;

    protected $storage;

    /**
     * @param OAuth2\Storage\UserCredentialsInterface $storage REQUIRED Storage class for retrieving user credentials information
     */
    public function __construct(UserCredentialsInterface $storage)
    {
        $this->storage = $storage;
    }

    public function getQuerystringIdentifier()
    {
        return 'password';
    }

    public function validateRequest(RequestInterface $request, ResponseInterface $response)
    {
        if (!$request->request("password") || !$request->request("username")) {
            $response->setError(400, 'invalid_request', 'Missing parameters: "username" and "password" required');

            return null;
        }

        if (!$this->storage->checkUserCredentials($request->request("username"), $request->request("password"))) {
            $response->setError(401, 'invalid_grant', 'Invalid username and password combination');

            return null;
        }
        
        $userInfo = $this->storage->getUserDetails($request->request("username"));

        if (empty($userInfo)) {
            $response->setError(400, 'invalid_grant', 'Unable to retrieve user information');

            return null;
        }

        if (!isset($userInfo['user_id'])) {
            throw new \LogicException("you must set the user_id on the array returned by getUserDetails");
        }

        $this->userInfo = $userInfo;

        return true;
    }

    public function getClientId()
    {
        return null;
    }

    public function getUserId()
    {
        return $this->userInfo['user_id'];
    }

    public function getScope()
    {
        return isset($this->userInfo['scope']) ? $this->userInfo['scope'] : null;
    }

    public function getUserDetailTable()
    {
        $sm = $this->getServiceLocator(); var_dump($sm);exit;
        $this->Table = $sm->get('User\Model\UserDetailTable');
        return $this->Table;
    }

    public function createAccessToken(AccessTokenInterface $accessToken, $client_id, $user_id, $scope='')
    {

        $preview_bucket_url = 'fymprofilethumbs/profile200';
        if ($this->userInfo['profile_photo']!='') {
           
            $image_url = 'https://s3.amazonaws.com/'.$preview_bucket_url.'/'.$this->userInfo['profile_photo'];

        } else {
            $image_url = '';
        }
        

        $accessTokenDetails['meta'] = array('status'=>'OK', 'code'=>200, 'methodName' => 'login');
        $accessTokenDetails['accessToken'] = $accessToken->createAccessToken($client_id, $user_id, '');//$scope
        $accessTokenDetails['diet'] =
                            array('no_of_meals'=>(string)$this->userInfo['no_of_meals'], 'diet_formula'=>$this->userInfo['formula'], 'diet_calory_type'=>$this->userInfo['diet_calory_type'], 'diet_macro_type'=>$this->userInfo['diet_macro_type'], 'diet_activity_level'=>$this->userInfo['activity_level_id'],
                                  'diet_goal_option_id'=> !empty($this->userInfo['goal_option_id'])?$this->userInfo['goal_option_id']:"",
                                  'diet_nutritional_plan'=>$this->userInfo['neutirition_plan_id'], 'diet_maintain_calories'=>$this->userInfo['calories'], 'diet_goal_calories'=>$this->userInfo['diet_goal_calories'], 'diet_fiber'=>$this->userInfo['fiber'],
                                  'diet_macros'=> array('diet_macro_fat'=>$this->userInfo['fat'], 'diet_macro_protein'=>$this->userInfo['protein'], 'diet_macro_carbs'=>$this->userInfo['carbs']),
                                   );
        $accessTokenDetails['user'] = array('user_id'=>$this->userInfo['guid'], 'user_type'=>(string)$this->userInfo['type'], 'first_name'=>$this->userInfo['first_name'], 'last_name'=>$this->userInfo['last_name'], 'user_name'=>$this->userInfo['username'], 'email'=>$this->userInfo['email'],
                                    'description'=>empty($this->userInfo['description'])?"":$this->userInfo['description'], 'push_notification' => $this->userInfo['push_notification'],
                                  'website'=>$this->userInfo['website'], 'profile_photo' => $image_url, 'facebook_id'=>$this->userInfo['facebook_user_id'], 'gender'=>$this->userInfo['gender'], 'dob'=>$this->userInfo['dob'], 'height'=>$this->userInfo['height'], 'weight'=>$this->userInfo['weight'],
                                  'fat'=>$this->userInfo['body_fat']);
        return $accessTokenDetails;
    }
}
