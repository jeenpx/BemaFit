<?php
namespace User\V1\Model;

class InviteUserDetail
{
        public $id;
        public $user_id;
        public $email;
        public $status_id;
        public $created_date;
        public $updated_date;
    

    public function getArrayCopy()
    {
        
    }

    public function exchangeArray(array $data)
    {
        $this->id   = (isset($data["id"])) ? $data["id"] : null;
        $this->user_id   = (isset($data["user_id"])) ? $data["user_id"] : null;
        $this->username   = (isset($data["username"])) ? $data["username"] : null;
        $this->email   = (isset($data["email"])) ? $data["email"] : null;
        $this->status_id   = (isset($data["status_id"])) ? $data["status_id"] : null;
        $this->created_date   = (isset($data["created_date"])) ? $data["created_date"] : null;
        $this->updated_date   = (isset($data["updated_date"])) ? $data["updated_date"] : null;

    }
}
