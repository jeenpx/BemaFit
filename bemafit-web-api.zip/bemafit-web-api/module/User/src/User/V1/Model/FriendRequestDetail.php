<?php
namespace User\V1\Model;

class FriendRequestDetail
{
    public $height;
    public $weight;

    public function exchangeArray($data)
    {
        $this->height    = (isset($data['height'])) ? $data['height'] : null;
        $this->weight = (isset($data['weight'])) ? $data['weight'] : null;
    }
}
