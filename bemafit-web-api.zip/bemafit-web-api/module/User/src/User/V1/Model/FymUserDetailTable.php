<?php
namespace User\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class FymUserDetailTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }
    
    public function fetch()
    {
        $resultSet = $this->tableGateway->select(array('id'=>2));
        return $resultSet;
    }

    public function getUserDetailsByGuid($userGuId)
    {
        $resultSet = $this->tableGateway->select(array('guid'=>$userGuId));
        return $resultSet->current();
    }

    public function getUserDetailsById($userId)
    {
        $resultSet = $this->tableGateway->select(array('id'=>$userId));
        return $resultSet->current();
    }

    public function getUserDetailsByEmailStatus($email)
    {
        $resultSet = $this->tableGateway->select(array('email'=>$email));
        return $resultSet->current();
    }

    public function getUserDetailsByEmail($email)
    {
        $resultSet = $this->tableGateway->select(array('email'=>$email, 'status_id'=>1));
        return $resultSet->current();
    }

    public function getUserDetailsByUserName($username)
    {
        $resultSet = $this->tableGateway->select(array('username'=>$username, 'status_id'=>1));
        return $resultSet->current();
    }

    public function getUserDetailsByUserNameStatus($username)
    {
        $resultSet = $this->tableGateway->select(array('username'=>$username));
        return $resultSet->current();
    }

    public function getUserDetailsByFacebookId($facebookId)
    {
        $resultSet = $this->tableGateway->select(array('facebook_user_id'=>$facebookId, 'status_id'=>1));
        return $resultSet->current();
    }

    public function getUserDetailsByFacebookOrEmail($email, $facebookId)
    {
        $where = new \Zend\Db\Sql\Where();
        $email = empty($email)?null:$email;
        $facebookId = empty($facebookId)?null:$facebookId;
        $where->NEST->equalTo('email', $email)->OR->equalTo('facebook_user_id', $facebookId)->UNNEST;
        $where->equalTo('status_id', 1);
        $rowset = $this->tableGateway->select($where);
        return $rowset->current();
    }

    public function update($user_id, $data)
    {
        if (is_numeric($user_id) && $user_id > 0) {
            return $this->tableGateway->update($data, array('id' => $user_id));
        }
    }

    public function getVersion(){
        $adapter = $this->tableGateway->getAdapter();
        $versionTable = new \Zend\Db\TableGateway\TableGateway('version', $adapter);
        $versionData = $versionTable->select();
        return ($versionData->current());
    }

    public function getUsersAllDetails($user_id, $field='id', $status_id=1)
    {
        $subQuery = '';
        if ($field=='id') {
            $subQuery = "AND u.id = ?";
        } else if ($field=='guid') {
            $subQuery = "AND u.guid = ?";
        }
        
        $sql = "SELECT 
                u.id AS user_id  , u.guid  , u.username  , u.email  , u.first_name  , u.last_name  , u.role  , u.password  , u.profile_photo  , u.type  , u.status_id  , u.website  , u.remember_token  , 
                u.gender  , u.dob  , u.facebook_user_id  , u.facebook_access_token  , u.date_last_login  , u.temp_password  , u.verified  , u.date_added  , u.added_by  , u.date_updated  , u.updated_by,
                ud.height  , ud.weight  , ud.body_fat  , ud.formula  , ud.diet_calory_type  , ud.diet_macro_type  , ud.activity_level_id  , ud.goal_option_id  , ud.protein  , ud.fat  , ud.carbs  , ud.fiber  , 
                ud.calories  , ud.meals_per_day  , ud.neutirition_plan_id  , ud.email_verification_code  , ud.recovery_password  
                FROM user u 
                JOIN user_details ud ON u.id=ud.user_id 
                WHERE u.status_id=? $subQuery";
                
        $statement = $this->tableGateway->adapter->createStatement($sql, array($status_id, $user_id));

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);
        return $data;
    }

    public function getUserDetailsByFacebookProfileId($facebookProfileId)
    {
        $resultSet = $this->tableGateway->select(array('facebook_user_id'=>$facebookProfileId, 'status_id'=>1));
        return $resultSet->current();
    }

    public function getUnprocessedFeedData()
    {
        $sql = "SELECT  fd.id  , fd.user_id  , fd.feed_id  , fd.parent_id  , fd.object_id  , fd.feed_type_id  , fd.status_id  , fd.data  , fd.like_count  , fd.inspire_count  , fd.comment_count  , fd.created_date  , fd.updated_date  , fd.cron_process_date  
                FROM feed f 
                JOIN feed_data fd ON f.id=fd.feed_id 
                WHERE fd.parent_id=0 AND  fd.status_id=1 AND fd.cron_process_date IS NULL 
                ORDER BY fd.id 
                LIMIT 0,10";
                
        $statement = $this->tableGateway->adapter->createStatement($sql);

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);
        return $data;
    }

    public function getFollowers($userId)
    {
        $sql = "SELECT u.id, u.guid, u.username, u.profile_photo
                FROM user_follower uf 
                JOIN `user` u ON uf.user_id = u.id 
                WHERE uf.following_user_id=$userId";
                
        $statement = $this->tableGateway->adapter->createStatement($sql);

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);
        return $data;
    }
    public function updateFeedDataAsProcessed($feed_data_id)
    {
        $sql = "UPDATE feed_data SET cron_process_date = '".gmdate('Y-m-d H:i:s') ."' WHERE id=$feed_data_id";
                
        $statement = $this->tableGateway->adapter->createStatement($sql);

        $result = $statement->execute();
      
    }

    public function getBusinessDetailsByCheckinId($userCheckinId)
    {
        $sql = "SELECT uci.user_id, uci.business_id
                FROM user_check_in uci 
                WHERE uci.id=$userCheckinId";
        return $this->tableGateway->adapter->createStatement($sql)->execute()->getResource()->fetchAll(2);
    }

    public function getFeedBusinessDetails($business_id)
    {
        $sql = "SELECT b.guid AS business_id, b.name AS business_name, bi.file as business_image
                FROM business b 
                LEFT JOIN business_image bi ON b.id=bi.business_id AND bi.status_id=1
                WHERE b.id='$business_id' AND b.status_id=1";
        return $this->tableGateway->adapter->createStatement($sql)->execute()->getResource()->fetchAll(2);
    }

    public function getFeedExerciseDetails($exercise_log_id)
    {
        $sql = "SELECT e.id AS exercise_id, e.name AS exercise
                FROM  user_exercise_log uel 
                JOIN exercise e ON uel.exercise_id=e.id
                WHERE uel.id='$exercise_log_id' AND e.status_id=1";
        return $this->tableGateway->adapter->createStatement($sql)->execute()->getResource()->fetchAll(2);
    }

    public function getFeedGuestPostAdDetails($ad_id)
    {
        $sql = "SELECT a.id AS a_id, a.guid as ad_id, a.content AS ad_content, ai.file AS ad_image
                FROM ad a 
                LEFT JOIN ad_image ai ON a.id=ai.ad_id AND ai.status_id=1
                WHERE a.id='$ad_id' AND a.status_id=1";
        return $this->tableGateway->adapter->createStatement($sql)->execute()->getResource()->fetchAll(2);
    }

    public function getFollowerUserIds($user_id)
    {
        $sql = "SELECT uf.user_id FROM user_follower uf 
                JOIN `user` u ON uf.user_id=u.id 
                WHERE uf.following_user_id='$user_id' AND uf.status_id=1
                AND u.status_id=1
                ORDER BY uf.user_id";
        return $this->tableGateway->adapter->createStatement($sql)->execute()->getResource()->fetchAll(7);
    }

    public function getAllActiveFymUserIds($user_id)
    {
        $sql = "SELECT u.id
                FROM `user` u 
                WHERE u.status_id=1 AND u.role<>'Admin'
                ORDER BY u.id
                ";
        return $this->tableGateway->adapter->createStatement($sql)->execute()->getResource()->fetchAll(7);
    }

    public function getAllActiveFymUserIdsByUserIDs($user_ids)
    {
        $sql = "SELECT u.id AS u_id  , u.guid AS user_id  , u.username  , u.email  , u.first_name  , u.last_name  , u.role  , u.password  , 
                       u.profile_photo  , u.type  , u.status_id  , u.website  , u.remember_token  , u.gender  , u.dob  , u.facebook_user_id  , 
                       u.facebook_access_token  , u.date_last_login  , u.temp_password  , u.verified  , u.date_added  , u.added_by  , 
                       u.date_updated  , u.updated_by  , u.device_token  , u.registration_id  
                FROM `user` u 
                WHERE u.status_id=1  AND u.id IN ($user_ids)
                ORDER BY u.id
                ";
        return $this->tableGateway->adapter->createStatement($sql)->execute()->getResource()->fetchAll(2);
    }
}
