<?php

namespace User\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class FoodlogDetailTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function create($userDetailData)
    {
        $this->tableGateway->insert($userDetailData);
    }

    public function update($userDetailData, $where)
    {
        $this->tableGateway->update($userDetailData, $where);
    }
}
