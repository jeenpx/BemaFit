<?php
namespace User\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class InviteUserDetailTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function getFriendRequestMapper()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\FriendRequestMapperTableGateway');
        return $this->Table;
    }

    public function getInvitedUserByEmail($userId, $email)
    {
        $resultSet = $this->tableGateway->select(array('email'=>$email, 'user_id'=>$userId,  'status_id'=>1));
        return $resultSet->current();
    }

    public function inviteUser($userId, $email)
    {
        return $this->tableGateway->insert(array('email'=>$email, 'user_id'=>$userId,  'status_id'=>1, 'created_date'=>gmdate('Y-m-d H:i:s')    ));
    }

    public function updateInvitedUser($id, $data)
    {   
        return $this->tableGateway->update($data, array('id'=>$id));
    }
     
    public function getInvitedUsers($email)
    {
        $resultSet = $this->tableGateway->select(array('email'=>$email, 'status_id'=>1));
        return $resultSet;
    }
}
