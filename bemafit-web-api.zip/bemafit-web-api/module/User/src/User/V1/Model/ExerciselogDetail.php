<?php
namespace User\V1\Model;

class ExerciselogDetail
{
    public function exchangeArray($data)
    {
       
    }
}
