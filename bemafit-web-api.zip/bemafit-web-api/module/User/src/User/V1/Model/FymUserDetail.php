<?php
namespace User\V1\Model;

class FymUserDetail
{
    public $id;
    public $guid;
    

    public function getArrayCopy()
    {
        return array(
            'id'     => $this->id,
            'guid' => $this->guid,
            'user_id' => $this->user_id,
            'type' => $this->type,
            'date_added' => $this->date_added,
            'verified' => $this->verified,
            'password' => $this->password,
            'photo' => $this->profile_photo,
        );
    }

    public function exchangeArray(array $array)
    {
        $this->id     = $array['id'];
        $this->guid     = $array['guid'];
        $this->username     = $array['username'];
        $this->user_id     = $array['id'];
        $this->email     = $array['email'];
        $this->first_name     = $array['first_name'];
        $this->last_name     = $array['last_name'];
        $this->type     = $array['type'];
        $this->date_added     = $array['date_added'];
        $this->verified     = $array['verified'];
        $this->password     = $array['password'];
        $this->profile_photo     = $array['profile_photo'];
        $this->device_token     = $array['device_token'];
    }
}
