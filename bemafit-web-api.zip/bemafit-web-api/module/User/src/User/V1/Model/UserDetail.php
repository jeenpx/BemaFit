<?php
namespace User\V1\Model;

class UserDetail
{
    public $id;
    public $user_id;
    public $height;
    public $weight;
    public $weight_unit_id;
    public $body_fat;
    public $formula;
    public $diet_calory_type;
    public $diet_macro_type;
    public $activity_level_id;
    public $goal_option_id;
    public $protein;
    public $fat;
    public $carbs;
    public $fiber;
    public $calories;
    public $diet_goal_calories;
    public $meals_per_day;
    public $neutirition_plan_id;
    public $email_verification_code;
    public $recovery_password;
    public $no_of_meals;
    public $push_notification;
    public $description;

    public function exchangeArray($data)
    {
        $this->id   = (isset($data["id"])) ? $data["id"] : null;
        $this->user_id   = (isset($data["user_id"])) ? $data["user_id"] : null;
        $this->height   = (isset($data["height"])) ? $data["height"] : null;
        $this->weight   = (isset($data["weight"])) ? $data["weight"] : null;
        $this->weight_unit_id   = (isset($data["weight_unit_id"])) ? $data["weight_unit_id"] : null;
        $this->body_fat   = (isset($data["body_fat"])) ? $data["body_fat"] : null;
        $this->formula   = (isset($data["formula"])) ? $data["formula"] : null;
        $this->diet_calory_type   = (isset($data["diet_calory_type"])) ? $data["diet_calory_type"] : null;
        $this->diet_macro_type   = (isset($data["diet_macro_type"])) ? $data["diet_macro_type"] : null;
        $this->activity_level_id   = (isset($data["activity_level_id"])) ? $data["activity_level_id"] : null;
        $this->goal_option_id   = (isset($data["goal_option_id"])) ? $data["goal_option_id"] : null;
        $this->protein   = (isset($data["protein"])) ? $data["protein"] : null;
        $this->fat   = (isset($data["fat"])) ? $data["fat"] : null;
        $this->carbs   = (isset($data["carbs"])) ? $data["carbs"] : null;
        $this->fiber   = (isset($data["fiber"])) ? $data["fiber"] : null;
        $this->calories   = (isset($data["calories"])) ? $data["calories"] : null;
        $this->diet_goal_calories   = (isset($data["diet_goal_calories"])) ? $data["diet_goal_calories"] : null;
        $this->meals_per_day   = (isset($data["meals_per_day"])) ? $data["meals_per_day"] : null;
        $this->neutirition_plan_id   = (isset($data["neutirition_plan_id"])) ? $data["neutirition_plan_id"] : null;
        $this->email_verification_code   = (isset($data["email_verification_code"])) ? $data["email_verification_code"] : null;
        $this->recovery_password   = (isset($data["recovery_password"])) ? $data["recovery_password"] : null;
        $this->no_of_meals   = (isset($data["no_of_meals"])) ? $data["no_of_meals"] : null;
        $this->push_notification   = (isset($data["push_notification"])) ? $data["push_notification"] : null;
        $this->description   = (isset($data["description"])) ? $data["description"] : null;
    }
}
