<?php

namespace User\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class ExerciselogDetailTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function create($userDetailData)
    {
        $this->tableGateway->insert($userDetailData);
    }

    public function update($userDetailData, $where)
    {
        $this->tableGateway->update($userDetailData, $where);
    }

    public function fetchAll()
    {
        $resultSet = $this->tableGateway->select();
        return $resultSet;
    }

    public function fetch($id)
    {
        $sql = "SELECT eto.option AS name, ueld.value
        FROM user_exercise_log_det ueld
        JOIN exercise_type_option eto ON eto.id = ueld.exercise_type_option_id
        WHERE ueld.user_exercise_log_id=$id";
                
        $statement = $this->tableGateway->adapter->createStatement($sql);
        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);
        return $data;
    }

    public function getUserDietDetails($userId)
    {
        echo 'here';
        exit;
    }
}
