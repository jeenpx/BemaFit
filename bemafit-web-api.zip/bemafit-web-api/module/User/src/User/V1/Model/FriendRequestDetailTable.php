<?php
namespace User\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class FriendRequestDetailTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function create($friendrequestdata)
    {
        $this->tableGateway->insert($friendrequestdata);
    }

    public function getFriendRequestDetails($guid,$currentUserId)
    {  
        $sql = 'SELECT f.id AS friend_id, u.id AS sender_id, f.friend_id AS my_id
                FROM `user` u 
                JOIN friends f ON u.id = f.user_id
                WHERE u.guid=? AND u.status_id=1 AND f.status_id=3 AND f.friend_id=?';

        $statement = $this->tableGateway->adapter->createStatement($sql, array($guid, $currentUserId));

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);
        return $data;
    }

    public function getFollowUserDetails($user_id, $friend_id)
    {
        $adapter = $this->tableGateway->getAdapter();
        $followTable = new \Zend\Db\TableGateway\TableGateway('user_follower', $adapter);
        $follow_data = $followTable->select(array('user_id'=>$user_id, 'following_user_id'=>$friend_id,'status_id'=>1));

        return ($follow_data->current());
    }

    public function followUser($data)
    {
        $adapter = $this->tableGateway->getAdapter();
        $followTable = new \Zend\Db\TableGateway\TableGateway('user_follower', $adapter);

        $follow_info = $this->getFollowUserDetails($data['user_id'], $data['following_user_id']);
        if (!$follow_info) {
            return $followTable->insert($data);
        }
    }

    public function unFollowUser($currentUserId, $friendId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $followTable = new \Zend\Db\TableGateway\TableGateway('user_follower', $adapter);
        return $followTable->update(array('status_id'=>4), array('user_id'=>$currentUserId, 'following_user_id'=>$friendId));
    }

    public function getFollowDetailsOfUser($user_id)
    {
        /*$sql = 'SELECT     u.guid AS user_id, u.username,  u.first_name, u.last_name, u.profile_photo, 
                COUNT(DISTINCT ufollowing.id) following ,COUNT(DISTINCT ufollowers.id) followers
                FROM user u 
                LEFT JOIN user_follower ufollowers ON u.id= ufollowers.following_user_id AND ufollowers.status_id=1 
                LEFT JOIN user_follower ufollowing ON u.id= ufollowing.user_id AND ufollowing.status_id=1
                WHERE u.id= ? AND u.status_id=1 ';
        */

        $sql = 'SELECT     u.guid AS user_id, u.username,  u.first_name, u.last_name, u.profile_photo, 
                COUNT(DISTINCT usr_following.id) following ,COUNT(DISTINCT usr_followers.id) followers
                FROM `user` u 
                LEFT JOIN user_follower ufollowers ON u.id= ufollowers.following_user_id AND ufollowers.status_id=1 
                LEFT JOIN user_follower ufollowing ON u.id= ufollowing.user_id AND ufollowing.status_id=1
                LEFT JOIN `user` usr_followers ON ufollowers.user_id=usr_followers.id AND usr_followers.status_id=1
                LEFT JOIN `user` usr_following ON ufollowing.following_user_id=usr_following.id AND usr_following.status_id=1
                WHERE u.id=     ? AND u.status_id=1 
                ';


        $statement = $this->tableGateway->adapter->createStatement($sql, array($user_id));

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);

        return $data;
    }
     
    public function getFriendRequestSent($user_id, $friend_id)
    {
        $sql = 'SELECT * FROM friends f WHERE user_id = ? AND friend_id=? AND status_id=3';

        $statement = $this->tableGateway->adapter->createStatement($sql, array($user_id, $friend_id));

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);

        return $data;
        
    }

    public function isFriends($user_id, $friend_id)
    {
        $sql = 'SELECT * FROM friends f WHERE user_id = ? AND friend_id=? AND status_id=1';

        $statement = $this->tableGateway->adapter->createStatement($sql, array($user_id, $friend_id));

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);

        return $data;
        
    }

    public function updateMessageAsRead($currentUserId, $friendId)
    {
        $sql = "UPDATE message SET receiver_message_status_id = 7,  updated_date ='". gmdate('Y-m-d H:i:s')."' 
                WHERE sender_id = $friendId AND receiver_id=$currentUserId AND sender_message_status_id<>4 AND receiver_message_status_id<>4";

        $this->tableGateway->adapter->createStatement($sql)->execute();

        
    }
}
