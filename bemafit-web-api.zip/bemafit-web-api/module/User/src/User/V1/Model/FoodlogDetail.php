<?php
namespace User\V1\Model;

class FoodlogDetail
{
    public function exchangeArray($data)
    {
       
    }
}
