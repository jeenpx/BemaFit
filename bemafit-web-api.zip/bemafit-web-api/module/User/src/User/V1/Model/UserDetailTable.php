<?php
namespace User\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class UserDetailTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function create($userDetailData)
    {
        $this->tableGateway->insert($userDetailData);
    }

    public function update($user_id, $userDetailData)
    {
        if (is_numeric($user_id) && $user_id > 0) {
            $this->tableGateway->update($userDetailData, array('user_id' => $user_id));
        }
    }

    public function fetchAll()
    {
        $resultSet = $this->tableGateway->select();
        return $resultSet;
    }

    public function getUserDetailsById($user_id)
    {
        $resultSet = $this->tableGateway->select(array('user_id'=>$user_id));
        return $resultSet->current();
    }

    public function getFriendShipInfo($user_id, $friend_id)
    {
        $sql = "SELECT * FROM friends f 
                WHERE ((f.user_id=$user_id AND f.friend_id=$friend_id) 
                    OR (f.user_id=$friend_id AND f.friend_id=$user_id)) 
                    AND (f.status_id=1 OR f.status_id=3) ";
        //die($sql);
        $statement = $this->tableGateway->adapter->createStatement($sql);

        $result = $statement->execute();
        return $result->getResource()->fetch(2);
        
    }

    public function getFollowAndFriendsInfoWithAUser($userId, $friend_id)
    {
        $sql = "SELECT uf.id AS follow_id,  fs.status_id AS receive_status, fr.status_id AS send_status FROM 
                user u 
                LEFT JOIN user_follower uf ON uf.user_id= u.id AND uf.following_user_id=$friend_id  AND uf.status_id=1  AND uf.user_id=$userId
                LEFT JOIN friends fs ON u.id=fs.friend_id AND fs.status_id<>2 AND fs.user_id=$friend_id
                LEFT JOIN friends fr ON u.id=fr.user_id AND fr.status_id<>2 AND fr.friend_id=$friend_id

                WHERE u.id=$userId
                ORDER BY uf.id DESC ";
        //die($sql);
        $statement = $this->tableGateway->adapter->createStatement($sql);

        $result = $statement->execute();
        return $result->getResource()->fetch(2);
    }

    public function getFollowStatus($userId, $friend_id)
    {
        $sql = "SELECT uf.id AS follow_id,  fs.status_id AS receive_status, fr.status_id AS send_status FROM 
                user u 
                LEFT JOIN user_follower uf ON uf.user_id= u.id AND uf.following_user_id=$friend_id  AND uf.status_id=1  AND uf.user_id=$userId
                LEFT JOIN friends fs ON u.id=fs.friend_id AND fs.status_id<>2 AND fs.user_id=$friend_id
                LEFT JOIN friends fr ON u.id=fr.user_id AND fr.status_id<>2 AND fr.friend_id=$friend_id

                WHERE u.id=$userId
                ORDER BY uf.id DESC ";
        //die($sql);
        $statement = $this->tableGateway->adapter->createStatement($sql);

        $result = $statement->execute();
        return $result->getResource()->fetch(2);
    }

    public function fetch()
    {
         $resultSet = $this->tableGateway->select(array('id'=>2));
         return $resultSet;
    }

    public function getUserDetails($userId)
    {
        $sql = "SELECT u.id,ud.height,ud.weight,u.dob,u.gender
                FROM `user` u
                LEFT JOIN user_details ud ON ud.user_id=u.id
                WHERE u.id=$userId";
        //die($sql);
        $statement = $this->tableGateway->adapter->createStatement($sql);

        $result = $statement->execute();
        return $result->getResource()->fetch(2);
    }
}
