<?php
namespace User\V1\Rpc\ForgotPassword;

class ForgotPasswordControllerFactory
{
    public function __invoke($controllers)
    {
        return new ForgotPasswordController();
    }
}
