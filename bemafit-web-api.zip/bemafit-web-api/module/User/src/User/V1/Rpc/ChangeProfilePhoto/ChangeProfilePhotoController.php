<?php
namespace User\V1\Rpc\ChangeProfilePhoto;

use Zend\Mvc\Controller\AbstractActionController;
use Aws\S3\S3Client;

class ChangeProfilePhotoController extends AbstractActionController
{
    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    /**
    * Change Profile Photo
    *
    * @return Entity
    */
    public function changeProfilePhotoAction()
    {
        $config = $this->getServiceLocator()->get('Config');
        $guid = $this->getEvent()->getRouteMatch()->getParam('user_id');
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($guid);

        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $currentUserId    = $user_info->id;
        
        if (isset($_FILES['photo'])) {
            $image_name = $this->getUserTable()->getUploadProfilePhoto();

            if ($currentUserId > 0 && $image_name!='') {
                $this->getUserTable()->updateUser($currentUserId, array('profile_photo' => $image_name));
                $config = $this->getServiceLocator()->get('Config');
                $preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
                $image_url = empty($image_name)?$image_name:$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$image_name);
                $response['meta'] = array('status'=>'OK', 'code'=>200, 'methodName' => 'changeProfilePhoto');
                $response['change_profile_photo'] = array('status'=>'OK', 'photo' => $image_url);
                return $response;
            }
              
        } else {
            return new \ZF\ApiProblem\ApiProblemResponse(
                new \ZF\ApiProblem\ApiProblem(404, 'Photo not found')
            );
        }
        exit;
    }
}
