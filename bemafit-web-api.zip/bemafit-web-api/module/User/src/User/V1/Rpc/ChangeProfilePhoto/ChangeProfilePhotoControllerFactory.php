<?php
namespace User\V1\Rpc\ChangeProfilePhoto;

class ChangeProfilePhotoControllerFactory
{
    public function __invoke($controllers)
    {
        return new ChangeProfilePhotoController();
    }
}
