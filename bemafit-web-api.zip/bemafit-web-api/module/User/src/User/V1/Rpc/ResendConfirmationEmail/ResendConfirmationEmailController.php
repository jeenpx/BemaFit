<?php
namespace User\V1\Rpc\ResendConfirmationEmail;

use Zend\Mvc\Controller\AbstractActionController;

class ResendConfirmationEmailController extends AbstractActionController
{
    public function getUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\UserDetailTable');
        return $this->Table;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

  

    public function resendConfirmationEmailAction()
    {
        $config = $this->getServiceLocator()->get('Config');
        $email = $this->params()->fromPost('email');
        $validator = new \Zend\Validator\EmailAddress();
        if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL) == true) {
            $user = $this->getUserTable()->getUserByEmail($email);
            
            if ($user) {
                $email_verification_code  =  $user->guid.'-'.md5(uniqid(rand(), true));
                $this->getUserDetailTable()->update($user->id, array('email_verification_code'  => $email_verification_code));
                $mail_status = $this->getUserTable()->sendConfirmationMail(array('first_name'=>$user->first_name, 'last_name'=>$user->last_name, 'email'=>$user->email),
                                                            array('email_verification_code'=>$email_verification_code));
                if($mail_status['status']) {
                    return  array(
                          'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'resendConfirmationEmail'),
                          'resendEmail'=>
                                array('status'=>'OK'),
                    );
                } else {
                    return  \Application\Service\FymApiProblem::ApiProblem(503, 'Could not send email');
                }
            } else {
                return  \Application\Service\FymApiProblem::ApiProblem(404, 'Email not exists.');
            
            }
            
        } else {
             return  \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid email');
             
            
        }
        return true;

    }
}
