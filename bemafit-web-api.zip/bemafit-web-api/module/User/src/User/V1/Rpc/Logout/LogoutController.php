<?php
namespace User\V1\Rpc\Logout;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Authentication\AuthenticationService;

class LogoutController extends AbstractActionController
{
    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    /**
    * Logout
    *
    * @return Entity
    */
    public function logoutAction()
    {
        $access_token = str_replace('Bearer ', '', $this->params()->fromHeader('Authorization')->getFieldValue());
        $currentUserId = $this->getIdentity()->getUserId();

        $user_info = $this->getFymUserDetailTable()->getUserDetailsById($currentUserId);
        $headers = getallheaders();
        $currentDeviceToken = !empty($headers['Device-Token'])?$headers['Device-Token']:'';
        if ($user_info) {
            if (!empty($user_info->device_token)) {
                $deviceTokens = unserialize($user_info->device_token);
                if (!empty($currentDeviceToken)) {
                    foreach ($deviceTokens as $key => $dToken) {
                        if ($dToken == $currentDeviceToken) {
                            unset($deviceTokens[$key]);
                            $deviceTokens = array_values($deviceTokens);
                            $this->getFymUserDetailTable()->update($currentUserId, array('device_token'=>serialize($deviceTokens)));
                            break;
                        }
                    }
                }
            }
        }

        if (!empty($access_token)) {
            $status = $this->getUserTable()->logout($access_token);
            if ($status) {
                return  array(
                      'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'logout'),
                );
            } else {
                return  \Application\Service\FymApiProblem::ApiProblem(422, 'Logout failed');
            }
        }
        exit;
    }
}
