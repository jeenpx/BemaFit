<?php
namespace User\V1\Rpc\InviteFriends;

use Zend\Mvc\Controller\AbstractActionController;
use Aws\Ses\SesClient;

class InviteFriendsController extends AbstractActionController
{
    public function getInviteUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\InviteUserTable');
        return $this->Table;
    }

    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    /**
    * Invite Friends
    *
    * @param int $user_id
    * @return Entity
    */
    public function inviteFriendsAction()
    {
        $guid = $this->getEvent()->getRouteMatch()->getParam('user_id');
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($guid);
        $config = $this->getServiceLocator()->get('Config');
        if (!$user_info) {
            return  \Application\Service\FymApiProblem::ApiProblem(422, 'User not exists.');
        }
        
        $email = $this->params()->fromPost('email');
        $invite_info = $this->getInviteUserDetailTable()->getInvitedUserByEmail($user_info->id, $email);

        if (!empty($invite_info->id) && $invite_info->id > 0) {
            $this->getInviteUserDetailTable()->updateInvitedUser($invite_info->id, array('updated_date'=>gmdate('Y-m-d H:i:s')));
        }
            

        $htmlViewPart = new \Zend\View\Model\ViewModel();
        $htmlViewPart->setTerminal(true)
           ->setTemplate('invite_user')
           ->setVariables(array(
              'name' => $user_info->first_name.' '.$user_info->last_name,
              'application_link'=>'applink',
              'site_url'=>$config['site_url']
            ));

            $htmlOutput = $this->getServiceLocator()
                ->get('viewrenderer')
                ->render($htmlViewPart);

            
            /*SENDING EMAIL*/
            $ses_client = SesClient::factory($config['amazon_ses']);

        try {
            $result = $ses_client->sendEmail(array(
            'Source' => "BemaFit<". $config['mail']['default_sender_id'].">",
            'Destination' => array(
                'ToAddresses' => array($email),
            ),
            'Message' => array(
                'Subject' => array(
                    'Data' => 'You are invited to BemaFit',
                    'Charset' => 'UTF-8',
                ),
                'Body' => array(
                    
                    'Html' => array(
                        'Data' => $htmlOutput,
                        'Charset' => 'UTF-8',
                    ),
                ),
            ),
            'ReplyToAddresses' => array($config['mail']['default_sender_id'])
            ));

            if ($result) {
                if (!empty($result['MessageId'])) {
                    if (!$invite_info) {
                        $this->getInviteUserDetailTable()->inviteUser($user_info->id, $email);
                    }
                    return  array(
                          'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'inviteFriend'),
                          'invite_friend'=>
                                array('status'=>'OK'),
                    );
                }
            }
        } catch (\Exception $ex) {
            return  \Application\Service\FymApiProblem::ApiProblem(406, $ex->getMessage());
        }

        /*END SENDING EMAIL*/
    }
}
