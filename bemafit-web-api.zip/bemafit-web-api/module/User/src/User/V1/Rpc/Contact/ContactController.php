<?php
namespace User\V1\Rpc\Contact;

use Zend\Mvc\Controller\AbstractActionController;
use Aws\Ses\SesClient;

class ContactController extends AbstractActionController
{
    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function contactAction()
    {
        $currentUserId = $this->getIdentity()->getUserId();
        $user_info = $this->getFymUserDetailTable()->getUserDetailsById($currentUserId);
        $email = $user_info->email;
        $config = $this->getServiceLocator()->get('Config');
        $message = $this->params()->fromPost('message');

        if (empty($message)) {
            return  \Application\Service\FymApiProblem::ApiProblem(404, 'Message required');
        }
      
        /*SENDING EMAIL*/
        $ses_client = SesClient::factory($config['amazon_ses']);

        try {
            $result = $ses_client->sendEmail(array(
            'Source' => $config['fym_email_source'],
            'Destination' => array(
                'ToAddresses' => array($config['conactfym_mailto']),
            ),
            'Message' => array(
                'Subject' => array(
                    'Data' => 'Contact BemaFit',
                    'Charset' => 'UTF-8',
                ),
                'Body' => array(
                    
                    'Html' => array(
                        'Data' => $message,
                        'Charset' => 'UTF-8',
                    ),
                ),
            ),
            'ReplyToAddresses' => array($email)
            ));

            if ($result) {
                if (!empty($result['MessageId'])) {
                    return  array(
                          'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'contactFYM'),
                          'contact'=>
                                array('status'=>'OK'),
                    );
                }
            }
        } catch (\Exception $ex) {
            return  \Application\Service\FymApiProblem::ApiProblem(406, $ex->getMessage());
        }

        /*END SENDING EMAIL*/
        exit;
    }
}
