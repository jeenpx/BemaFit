<?php
namespace User\V1\Rpc\FacebookLogin;

use Zend\Mvc\Controller\AbstractActionController;
use Facebook\FacebookSession;

class FacebookLoginController extends AbstractActionController
{
    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function facebookLoginAction()
    {
        $config = $this->getServiceLocator()->get('Config');

        $facebookAccessToken = $this->params()->fromPost('facebook_access_token');
        if (empty($facebookAccessToken)) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'Access Token Required');
        }

        $access_token = str_replace('Basic ', '', $this->params()->fromHeader('Authorization')->getFieldValue());
        $deviceTokenHeader =  $this->params()->fromHeader('Device-Token');
        $deviceToken = !empty($deviceTokenHeader)?$deviceTokenHeader->getFieldValue():'';
        
        FacebookSession::setDefaultApplication($config['facebook_credentials']['app_id'], $config['facebook_credentials']['app_secret']);

        $session = new FacebookSession($facebookAccessToken);


        // To validate the session:
        try {
            $result = $session->validate();

            if (!$result) {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid or expired Access Token');
            }

            //Facebook session is valid. Now get facebook user id from access token.
            $utilityObj = new \Application\Service\Utility();
            $facebookProfileId =  $utilityObj->getFacebookProfileIDByAccessToken($facebookAccessToken);

            $user_info = $this->getFymUserDetailTable()->getUserDetailsByFacebookProfileId($facebookProfileId);

            if (empty($user_info)) {
                return \Application\Service\FymApiProblem::ApiProblem(404, 'Facebook Id not found');
            }

            /*Valid User. Call Auth using curl*/

            try {

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $config['oauthUrl']);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, array('username' => $user_info->email, 'password' => $user_info->password, 'grant_type'=>'password'));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
                $headers = array();
                $headers[] = 'Content-Type: multipart/form-data; charset=utf-8';
                $headers[] = 'Authorization: Basic '.$access_token;
                $headers[] = 'Device-Token: '.$deviceToken;

                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

                $server_output = curl_exec($ch);

                curl_close($ch);

                $result = json_decode($server_output, true);
                if (isset($result['meta']['status']) && $result['meta']['status'] == 'OK') {
                    header('Content-Type: application/json');
                    echo (( $server_output ));
                } else {
                    return \Application\Service\FymApiProblem::ApiProblem(422, '', array('messages'=>$result));
                }
                exit;

                
            } catch (FacebookRequestException $ex) {
                return \Application\Service\FymApiProblem::ApiProblem(422, $ex->getMessage());
            }

            /*curl call end*/
        } catch (FacebookRequestException $ex) {
            return \Application\Service\FymApiProblem::ApiProblem(422, $ex->getMessage());
        } catch (\Exception $ex) {
            return \Application\Service\FymApiProblem::ApiProblem(422, $ex->getMessage());
        }

        /*
        
         This reference code will be deleted after testing

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $config['oauthUrl']);
        //curl_setopt($ch, CURLOPT_URL,"carechoices.lh/employees/test");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, array('username' => 'arunssjoshi@gmail.com', 'password' => '123456', 'grant_type'=>'password'));  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $headers = array();
        //$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=utf-8';
        $headers[] = 'Content-Type: multipart/form-data; charset=utf-8';
        $headers[] = 'Authorization: Basic '.$access_token;
        $headers[] = 'grant_type: password';

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $server_output = curl_exec($ch);

        curl_close($ch);

        header('Content-Type: application/json');
        echo (( $server_output ));
        */
        exit;

    
        
    }
}
