<?php
namespace User\V1\Rpc\ChangePassword;

use Zend\Mvc\Controller\AbstractActionController;

class ChangePasswordController extends AbstractActionController
{
    
    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    /**
    * Change Password
    *
    * @param string $old_password
    * @param string $new_password
    * @return Entity
    */
    public function changePasswordAction()
    {
        $old_password      = $this->params()->fromPost('old_password');
        $new_password      = $this->params()->fromPost('new_password');
        $guid = $this->getEvent()->getRouteMatch()->getParam('user_id');

        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($guid);

        if (!$user_info) {
            return  \Application\Service\FymApiProblem::ApiProblem(404, 'User not exists.');
        }

        if ($old_password !== $user_info->password) {
            return  \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Old Password.');
        }

        $status = $this->getFymUserDetailTable()->update($user_info->id, array('password'=>$new_password));
        
        return  array(
                  'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'changePassword'),
                  'change_password'=>
                        array('status'=>'OK'),
        );
    }
}
