<?php
namespace User\V1\Rpc\InviteFriends;

class InviteFriendsControllerFactory
{
    public function __invoke($controllers)
    {
        return new InviteFriendsController();
    }
}
