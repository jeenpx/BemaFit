<?php
namespace User\V1\Rpc\ResendConfirmationEmail;

class ResendConfirmationEmailControllerFactory
{
    public function __invoke($controllers)
    {
        return new ResendConfirmationEmailController();
    }
}
