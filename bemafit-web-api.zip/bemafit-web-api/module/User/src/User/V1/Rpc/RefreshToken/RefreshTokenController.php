<?php
namespace User\V1\Rpc\RefreshToken;

use Zend\Mvc\Controller\AbstractActionController;

class RefreshTokenController extends AbstractActionController
{
    public function refreshTokenAction()
    {
        $config = $this->getServiceLocator()->get('Config');
        $refresh_token = $this->params()->fromPost('refresh_token');
        $access_token = str_replace('Basic ', '', $this->params()->fromHeader('Authorization')->getFieldValue());
        if (empty($refresh_token)) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'Refresh token not found');
        }
        try {

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $config['oauthUrl']);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, array('refresh_token' => $refresh_token, 'grant_type'=>'refresh_token'));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            $headers = array();
            $headers[] = 'Content-Type: multipart/form-data; charset=utf-8';
            $headers[] = 'Authorization: Basic '.$access_token;

            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $server_output = curl_exec($ch);

            curl_close($ch);

            
            //$result = unserialize('a:5:{s:12:"access_token";s:40:"7dc12f4d4e4dec3734bdbf1226dec04f0fe7b09b";s:10:"expires_in";i:3600000;s:10:"token_type";s:6:"Bearer";s:5:"scope";N;s:13:"refresh_token";s:40:"9702c8944059f01b09e91f33cba358ddfa0f53a6";}');
            $result = json_decode($server_output, true);
            //var_dump($result);
            
            if (isset($result['access_token'])) {
                $response['meta'] = array('status'=>'OK', 'code'=>200, 'methodName'=>'refreshAccessToken');
                $result['scope'] = '';
                $response['accessToken'] = $result;
                header('Content-Type: application/json');
                echo ( json_encode($response ));
                exit;
            } else {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Refresh token');
            }
            exit;

            
        } catch (FacebookRequestException $ex) {
            return \Application\Service\FymApiProblem::ApiProblem(422, $ex->getMessage());
        }
        echo $refresh_token;
        die('here');
    }
}
