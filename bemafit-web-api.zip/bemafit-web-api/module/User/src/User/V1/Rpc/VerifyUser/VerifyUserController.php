<?php
namespace User\V1\Rpc\VerifyUser;

use Zend\Mvc\Controller\AbstractActionController;

class VerifyUserController extends AbstractActionController
{
    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function getFeedMapper()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Feeds\V1\Rest\FeedMapperTableGateway');
        return $this->Table;
    }

    /**
    * Verify User
    *
    * @return Entity
    */
    public function verifyUserAction()
    {
        $email      = $this->params()->fromPost('email');
        $facebookId = $this->params()->fromPost('facebook_id');
        $username = $this->params()->fromPost('username');
        $verifytype = $this->params()->fromPost('type');

        $config = $this->getServiceLocator()->get('Config');

        $response['meta'] = array('status'=>'OK', 'code'=>200, 'methodName' => 'verifyUser');
        $response['user'] = array();

        $response['user']['facebook_exists'] = false;
        $response['user']['email_exists'] = false;

        if (trim($email)=='' && trim($facebookId)=='') {
            return  \Application\Service\FymApiProblem::ApiProblem(422, 'Email or facebook id required.');
        }

        if (trim($facebookId)!='') {
            $user_info_by_facebookId = $this->getFymUserDetailTable()->getUserDetailsByFacebookId($facebookId);
            if ($user_info_by_facebookId && ($facebookId)) {
                $response['user']['facebook_exists'] = true;
                $user_info = $user_info_by_facebookId ;
            }
        }
            


        if (trim($email)!='') {
            if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
                return  \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Email Id');
            } else {
                $user_info_by_email = $this->getFymUserDetailTable()->getUserDetailsByEmailStatus($email);
                if ($user_info_by_email && ($email)) {
                    $response['user']['email_exists'] =   true;
                    if (!$response['user']['facebook_exists']) {
                        $user_info = $user_info_by_email ;
                    }
                }
            }
        }

        //$user_info = $this->getFymUserDetailTable()->getUserDetailsByFacebookOrEmail($email, $facebookId);

        $user_info_by_username = $this->getFymUserDetailTable()->getUserDetailsByUserNameStatus($username);   
        $response['user']['username_exists'] =   ($user_info_by_username && ($username))?true:false;

        if (!empty($user_info)) {
            //var_dump($user_info);
            $remDays  = floor((time() - strtotime($user_info->date_added))/(60*60*24));
            
            $response['user']['verification_days_remaining'] =   0;
            $response['user']['user_valid'] =   true;
            $response['user']['email_verified'] =   true;
            $response['user']['user_exists'] =   true;

            if ($user_info->verified == 'No') {
                $response['user']['email_verified'] =   false;
                $response['user']['verification_days_remaining'] =   $remDays;
                if ($remDays > $config['verificationDays']) {
                    $response['user']['user_valid'] =   false;
                }
            }
        } else {
            $response['user']['verification_days_remaining'] =   0;
            $response['user']['user_valid'] =   false;
            $response['user']['email_verified'] =   false;
            $response['user']['user_exists'] =   false;
        }
            
        return $response;
        exit;
    }
}
