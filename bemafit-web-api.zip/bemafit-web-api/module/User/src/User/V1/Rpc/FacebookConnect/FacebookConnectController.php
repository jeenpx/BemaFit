<?php
namespace User\V1\Rpc\FacebookConnect;

use Zend\Mvc\Controller\AbstractActionController;
use Facebook\FacebookSession;

class FacebookConnectController extends AbstractActionController
{
    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function facebookConnectAction()
    {
        $config = $this->getServiceLocator()->get('Config');
        $currentUserId = $this->getIdentity()->getUserId();
        $facebookAccessToken = $this->params()->fromPost('facebook_access_token');
        $action =  $this->params()->fromPost('action');
        if (!in_array($action, array('connect', 'disconnect'))) {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid action');
        }

        $response['meta'] = array('status'=>'OK', 'code'=>200, 'methodName' => 'facebookConnect');
        
        if ($action == 'connect') {
            if (empty($facebookAccessToken)) {
                return \Application\Service\FymApiProblem::ApiProblem(404, 'Access Token Required');
            }
            FacebookSession::setDefaultApplication($config['facebook_credentials']['app_id'], $config['facebook_credentials']['app_secret']);
            $session = new FacebookSession($facebookAccessToken);
            try {
                $result = $session->validate();
                if ($result) {
                    //Facebook session is valid. Now get facebook user id from access token.
                    $utilityObj = new \Application\Service\Utility();
                    $facebookProfileId =   $utilityObj->getFacebookProfileIDByAccessToken($facebookAccessToken);

                    if ($facebookProfileId > 0) {
                        $user_info = $this->getFymUserDetailTable()->getUserDetailsByFacebookProfileId($facebookProfileId);
                        if (empty($user_info)) {
                            $this->getFymUserDetailTable()->update($currentUserId, array('facebook_user_id'=>$facebookProfileId));
                            $response['change_profile_photo'] = array('status'=>'OK', 'facebook_profile_id' => $facebookProfileId);
                        } else {
                            return \Application\Service\FymApiProblem::ApiProblem(425, "Another user connected through this facebook account.");
                        }
                    } else {
                        return \Application\Service\FymApiProblem::ApiProblem(422, 'Facebook profile id is not available.');
                    }

                } else {
                    return \Application\Service\FymApiProblem::ApiProblem(426, 'Facebook Connect: Invalid or expired Access Token');
                }
            } catch (FacebookRequestException $ex) {
                return \Application\Service\FymApiProblem::ApiProblem(428, "Facebook Connect: ".$ex->getMessage());
            } catch (\Exception $ex) {
                return \Application\Service\FymApiProblem::ApiProblem(428, "Facebook Connect: ".$ex->getMessage());
            }
        } else {
            $this->getFymUserDetailTable()->update($currentUserId, array('facebook_user_id'=>''));
            $response['change_profile_photo'] = array('status'=>'OK', 'facebook_profile_id' => '');
        }

        return $response;
        die();
    }
}
