<?php
namespace User\V1\Rpc\VerifyUser;

class VerifyUserControllerFactory
{
    public function __invoke($controllers)
    {
        return new VerifyUserController();
    }
}
