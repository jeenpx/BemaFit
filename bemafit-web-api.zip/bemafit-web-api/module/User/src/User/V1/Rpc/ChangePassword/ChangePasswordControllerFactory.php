<?php
namespace User\V1\Rpc\ChangePassword;

class ChangePasswordControllerFactory
{
    public function __invoke($controllers)
    {
        return new ChangePasswordController();
    }
}
