<?php
namespace User\V1\Rpc\ForgotPassword;

use Zend\Mvc\Controller\AbstractActionController;
use ZF\ApiProblem\ApiProblem;
use Zend\Mail\Transport\Smtp as SmtpTransport;
use Zend\Mail\Transport\SmtpOptions;
use Aws\Ses\SesClient;

class ForgotPasswordController extends AbstractActionController
{
    public function getUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\UserDetailTable');
        return $this->Table;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    /**
    * Forgot Password
    *
    * @param email $email
    * @return Entity
    */
    public function forgotPasswordAction()
    {
        $config = $this->getServiceLocator()->get('Config');
        $email = $this->params()->fromPost('email');
        $validator = new \Zend\Validator\EmailAddress();
        if (!empty($email) && $validator->isValid($email)) {
            $user = $this->getUserTable()->getUserByEmail($email);

            if ($user) {
                $userId = $user->id;
                $tempPassword = strtoupper(substr(md5(uniqid(rand(), true)), 24, 8));
                $this->getUserTable()->updateUser($userId, array('temp_password'=>$tempPassword));
                $htmlViewPart = new \Zend\View\Model\ViewModel();
                $htmlViewPart->setTerminal(true)
                   ->setTemplate('forgotpassword')
                   ->setVariables(array(
                      'name' => $user->first_name.' '.$user->last_name,
                      'password' => $tempPassword,
                      'site_url'=>$config['site_url']
                   ));

                $htmlOutput = $this->getServiceLocator()
                    ->get('viewrenderer')
                    ->render($htmlViewPart);

                

                /*SENDING EMAIL*/

                $ses_client = SesClient::factory($config['amazon_ses']);

                try {
                    $result = $ses_client->sendEmail(array(
                    'Source' => "BemaFit<". $config['mail']['default_sender_id'].">",
                    'Destination' => array(
                        'ToAddresses' => array($email),
                    ),
                    'Message' => array(
                        'Subject' => array(
                            'Data' => 'New password for BemaFit',
                            'Charset' => 'UTF-8',
                        ),
                        'Body' => array(
                            
                            'Html' => array(
                                'Data' => $htmlOutput,
                                'Charset' => 'UTF-8',
                            ),
                        ),
                    ),
                    'ReplyToAddresses' => array($config['mail']['default_sender_id'])
                    ));
                
                    if ($result) {
                        if (!empty($result['MessageId'])) {
                            $response['meta'] = array('status'=>'OK', 'code'=>200, 'methodName' => 'forgotpassword');
                            $response['forgot_password'] = array('status'=>'OK');
                            return $response;
                        }
                    }
                
                } catch (\Exception $ex) {
                    return  \Application\Service\FymApiProblem::ApiProblem(406, $ex->getMessage());
                    
                }
                /*END SENDING EMAIL*/
               
                
            } else {
                return  \Application\Service\FymApiProblem::ApiProblem(404, 'Email not exists.');
            
            }
            
        } else {
             return  \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid email');
             
            
        }
        return true;
    }
}
