<?php

namespace User\V1\Rest\UserProfile;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use Zend\Validator\Db\NoRecordExists;
use ZF\ApiProblem\ApiProblem;
use Zend\Http\Request;
use ZF\Rest\AbstractResourceListener;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\UserDetailTable');
        return $this->Table;
    }

    public function getFriendRequestDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FriendRequestDetailTable');
        return $this->Table;
    }

    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getFeedMapper()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Feeds\V1\Rest\FeedMapperTableGateway');
        return $this->Table;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }
    
    /**
    * Create User Profile
    *
    * @param array $data
    * @return Entity
    */
    public function create($data)
    {
        $config = $this->getServiceLocator()->get('Config');
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data->user_id);
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $data->currentUserId = $user_info->id;
        $profile_photo = $user_info->profile_photo;
        $apiData = null;

        if (isset($data->first_name)) {
            $apiData['first_name'] = $data->first_name;
        }
        if (isset($data->last_name)) {
            $apiData['last_name'] = $data->last_name;
        }
        if (!empty($data->website)) {
            if (filter_var($data->website, FILTER_VALIDATE_URL) === false) {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid website');
            }
            $apiData['website'] = $data->website;
        }

        if (!empty($data->type)) {
            if (strtolower($data->type) != 'public' && strtolower($data->type) != 'private') {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid type');
            }
            $apiData['type']= $data->type;
        }

        if (!empty($data->push_notification)) {
            if ($data->push_notification != 'Yes' && $data->push_notification != 'No') {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid push notification');
            }
            $userDetailData ['push_notification'] = $data->push_notification;
        }

        if (!empty($data->description)) {
            $userDetailData ['description'] = $data->description;
        }

        
        if ( !empty($data->gender) && strtoupper(trim($data->gender)) != 'M' && strtoupper(trim($data->gender)) != 'F') {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Possible gender values are M and F');
        }
        if (!empty($data->gender)) {
            $apiData['gender'] = $data->gender;
        }
        
        
        if (isset($data->dob)) {
            $apiData['dob'] = $data->dob;
        }
        if (isset($data->email)) {
            $user_info = $this->getFymUserDetailTable()->getUserDetailsByEmail($data->email);
            if (isset($user_info->id) && $user_info->id != $data->currentUserId) {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Email already exists.');
            } else {
                $apiData['email'] = $data->email;
            }
        }

        if (isset($data->username)) {
            $user_info = $this->getFymUserDetailTable()->getUserDetailsByUserName($data->username);
            if (isset($user_info->id) && $user_info->id != $data->currentUserId) {
                return \Application\Service\FymApiProblem::ApiProblem(423, 'Username already exists.');
            } else {
                $apiData['username'] = $data->username;
                if (empty($profile_photo) || strlen($profile_photo)<6) {
                    $apiData['profile_photo'] = substr(strtolower($data->username),0,1).".png";
                }
            }
        }




        if ($apiData && $data->currentUserId > 0) {
            $this->table->update($apiData, array('id' => $data->currentUserId));
        }

        if (isset($data->height)) {
            $apiData['height'] = $data->height;
            $userDetailData ['height'] = $data->height;
       
            if ($userDetailData && $data->currentUserId > 0) {
                $this->getUserDetailTable()->update($data->currentUserId, $userDetailData);
            }
        }

        $user_info = $this->getFymUserDetailTable()->getUsersAllDetails($data->user_id, 'guid');
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $user_info = $user_info[0];

        $calcualted_values = $this->getUserTable()->getCalculatedCalorieValues(array('diet_activity_level'=>$user_info['activity_level_id'],
                                                                                   'diet_goal_calories'=>$user_info['calories'],
                                                                                   'fat'=>$user_info['fat'],
                                                                                   'gender'=>$user_info['gender'],
                                                                                   'height'=>$user_info['height'],
                                                                                   'weight'=>$user_info['weight'],
                                                                                   'dob'=>$user_info['dob'],
                                                                                   'diet_goal_option'=>$user_info['goal_option_id'],
                                                                                   'diet_formula'=>$user_info['formula'],
                                                                                   'diet_calory_type'=>$user_info['diet_calory_type'],
                                                                                   'diet_macro_type'=>$user_info['diet_macro_type'],
                                                                                   'diet_nutritional_plan'=>$user_info['neutirition_plan_id'],
                                                                                   'diet_macro_fiber'=>$user_info['fiber'],
                                                                                   'diet_macro_fat'=>$user_info['fat'],
                                                                                   'diet_macro_carbs'=>$user_info['carbs'],
                                                                                   'diet_macro_protein'=>$user_info['protein'],
                                                                                   ));
        
        $calculated_calorie_data = array('protein'  => $calcualted_values['protein'],
                'fat'  => $calcualted_values['fat'],
                'carbs'  => $calcualted_values['carbs'],
                'fiber'  => $calcualted_values['fiber'],
                'calories'  => $calcualted_values['diet_maintain'] ,
                'diet_goal_calories'  => $calcualted_values['diet_goal_calories'] ,
                );

        if ($calculated_calorie_data && $data->currentUserId > 0) {
            $this->getUserDetailTable()->update($data->currentUserId, $calculated_calorie_data);
        }

        $user_info = (object) $user_info;
        
        $user_detail = $this->getUserDetailTable()->getUserDetailsById($user_info->user_id);
        $user_detail = (array)$user_detail;

        $follow_info = $this->getFriendRequestDetailTable()->getFollowDetailsOfUser($user_info->user_id);

        $preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
        $image_url = empty($user_info->profile_photo)?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$user_info->profile_photo);


        $user_detail_response['meta'] = array('status'=>'OK', 'code'=>200, 'methodName' => 'updateBasicUserInfo');

        $user_detail_response['user'] = array('user_id'=>$user_info->guid, 'user_type'=>(string)$user_info->type, 'first_name'=>$user_info->first_name, 'last_name'=>$user_info->last_name, 'user_name'=>$user_info->username, 'email'=>$user_info->email,
                                  'push_notification'=>$user_detail['push_notification'], 'website'=>$user_info->website, 'website'=>$user_info->website, 'profile_photo' => $image_url, 'facebook_id'=>$user_info->facebook_user_id, 'gender'=>$user_info->gender,
                                  'dob'=>$user_info->dob,  'height'=>$user_detail['height'],  'weight'=>$user_detail['weight'],  'fat'=>$user_detail['body_fat'],
                                  );
        
        $user_detail_response['diet'] =
                           array('no_of_meals'  => empty($user_detail['no_of_meals'])?"":$user_detail['no_of_meals'], 'diet_formula'=>$user_detail['formula'], 'diet_calory_type'=>$user_detail['diet_calory_type'], 'diet_macro_type'=>$user_detail['diet_macro_type'], 'diet_activity_level'=>$user_detail['activity_level_id'],
                                  'diet_goal_option_id'=> $user_detail['goal_option_id'],
                                  'diet_nutritional_plan'=>$user_detail['neutirition_plan_id'], 'diet_maintain_calories'=>$user_detail['calories'], 'diet_goal_calories'=>(string)$user_detail['diet_goal_calories'], 'diet_fiber'=>$user_detail['fiber'],
                                  'diet_macros'=> array('diet_macro_fat'=>$user_detail['fat'], 'diet_macro_protein'=>$user_detail['protein'], 'diet_macro_carbs'=>$user_detail['carbs']),
                                   );
        return  $user_detail_response;


       
    }

    /**
    * Fetch User Profile
    *
    * @param int $id
    * @return Entity
    */
    public function fetch($id)
    {
        $resultSet = $this->table->select(array('id' => $id));
        if (0 === count($resultSet)) {
            throw new DomainException('User not found', 404);
        }
        return $resultSet->current();
    }

    /**
    * Fetch User Profile
    *
    * @param array $params
    * @return Entity
    */
    public function fetchAll($params)
    {
        $config = $this->getServiceLocator()->get('Config');
        $guid = $params['guid'];
        $userId = $params['userId'];
        $type = $params['type'];

        if ($type == 'feeds') {
            $params['logged_in_user_id'] = $params['userId'];
            return $this->getFeedMapper()->getUserProfileFeed($params);
        }

        if ($guid == 'me') {
            $userId  =  $params['userId'];
            $resultSet = $this->table->select(array('id' => $userId));
        } else {
            $resultSet = $this->table->select(array('guid' => $guid));
        }
        if (!$resultSet->current()) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $user_info = $resultSet->current();

        $user_detail = $this->getUserDetailTable()->getUserDetailsById($user_info->id);
        $user_detail = (array)$user_detail;


        //getFollowAndFriendsInfoWithAUser
        $friends_info = $this->getUserDetailTable()->getFriendShipInfo($params['userId'], $user_info->id);


        $follow_info_check = $this->getFriendRequestDetailTable()->getFollowUserDetails($params['userId'], $user_info->id);
        
        if ($follow_info_check) {
            $follow_status = 'Yes';
        } else {
            $follow_status = 'No';
        }


        if ($friends_info) {
            if ($friends_info['status_id'] == 1) {
                $friend_status = 'friends';
            } else {
                if($friends_info['user_id'] == $params['userId']) {
                    $friend_status = 'friendRequestSent';
                } else {
                    $friend_status = 'friendRequestReceived';
                }
            }
        } else {
            $friend_status= 'nonFriend';
        }

     

       
        $follow_info = $this->getFriendRequestDetailTable()->getFollowDetailsOfUser($user_info->id);
        
        $preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
        $image_url = empty($user_info->profile_photo)?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$user_info->profile_photo);
        
        $user_detail_response = array();
        $user_detail_response['meta'] = array('status'=>'OK', 'code'=>200, 'methodName' => 'getUserProfile');

        $user_detail_response['user'] = array('id'=>$user_info->id, 'user_id'=>$user_info->guid, 'user_type'=>(string)$user_info->type, 'first_name'=>$user_info->first_name, 'last_name'=>$user_info->last_name, 'user_name'=>$user_info->username, 'email'=>$user_info->email,
                                  'push_notification'=>$user_detail['push_notification'], 'description'=>empty($user_detail['description'])?"":$user_detail['description'], 'website'=>$user_info->website, 'website'=>$user_info->website, 'profile_photo' => $image_url, 'facebook_id'=>$user_info->facebook_user_id, 'gender'=>$user_info->gender,
                                  'dob'=>$user_info->dob,  'height'=>$user_detail['height'],  'weight'=>$user_detail['weight'],  'fat'=>$user_detail['body_fat'],
                                  'following'=> $follow_info[0]['following'], 'followers'=> $follow_info[0]['followers'],
                                  'follow_status'=>$follow_status, 'friend_status'=>$friend_status);
        
        $user_detail_response['diet'] =
                           array('no_of_meals'  => empty($user_detail['no_of_meals'])?"":$user_detail['no_of_meals'], 'diet_formula'=>$user_detail['formula'], 'diet_calory_type'=>$user_detail['diet_calory_type'], 'diet_macro_type'=>$user_detail['diet_macro_type'], 'diet_activity_level'=>$user_detail['activity_level_id'],
                                  'diet_goal_option_id'=> $user_detail['goal_option_id'],
                                  'diet_nutritional_plan'=>$user_detail['neutirition_plan_id'], 'diet_maintain_calories'=>$user_detail['calories'], 'diet_goal_calories'=>(string)$user_detail['diet_goal_calories'], 'diet_fiber'=>$user_detail['fiber'],
                                  'diet_macros'=> array('diet_macro_fat'=>$user_detail['fat'], 'diet_macro_protein'=>$user_detail['protein'], 'diet_macro_carbs'=>$user_detail['carbs']),
                                   );
        return  $user_detail_response;
    }

    /**
    * Delete User Profile
    *
    * @param int $id
    * @return Entity
    */
    public function delete($id)
    {
        $result = $this->table->delete(array('id' => $id));

        if (!$result) {
            return false;
        }

        return true;
    }
}
