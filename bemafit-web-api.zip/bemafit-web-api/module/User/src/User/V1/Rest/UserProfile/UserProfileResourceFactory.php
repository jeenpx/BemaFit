<?php
namespace User\V1\Rest\UserProfile;

class UserProfileResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('User\V1\Rest\UserProfileMapperTableGateway');
        return new UserProfileResource($mapper);
    }
}
