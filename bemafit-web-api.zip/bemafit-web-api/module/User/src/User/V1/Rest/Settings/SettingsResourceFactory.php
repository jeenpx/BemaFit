<?php
namespace User\V1\Rest\Settings;

class SettingsResourceFactory
{
    public function __invoke($services)
    {
        return new SettingsResource();
    }
}
