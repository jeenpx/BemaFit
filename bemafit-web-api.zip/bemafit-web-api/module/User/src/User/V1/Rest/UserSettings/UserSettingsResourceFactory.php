<?php
namespace User\V1\Rest\UserSettings;

class UserSettingsResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('User\V1\Rest\UserSettings\UserSettingsMapperTableGateway');
        return new UserSettingsResource($mapper);
    }
}
