<?php
namespace User\V1\Rest\Follow;

class FollowResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('User\V1\Rest\FollowMapperTableGateway');
        return new FollowResource($mapper);
    }
}
