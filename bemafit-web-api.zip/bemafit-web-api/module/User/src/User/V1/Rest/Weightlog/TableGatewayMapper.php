<?php

namespace User\V1\Rest\Weightlog;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use Zend\Validator\Db\NoRecordExists;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    /**
    * Create Weightlog
    *
    * @param array $data
    * @return Entity
    */
    public function create($data)
    {
        $apiData['user_id']       =   $data->user_id;
        $apiData['date']          =   $data->log_date;
        $apiData['created_date']  =   gmdate('Y-m-d H:i:s')    ;

        if ($data->log_weight>0) {
            $apiData['weight']     =   $data->log_weight;
        }

        if ($data->log_bodyfat>0) {
            $apiData['body_fat']   =   $data->log_bodyfat;
        }

        $apiData['status_id']     =   1;

        $resultSet = $this->table->select(array('user_id' => $data->user_id,'date'=>$data->log_date));
       
        if (0 === count($resultSet)) {
            $this->table->insert($apiData);

            $resultSet = $this->table->select(array('id' => $this->table->lastInsertValue));
            if (0 === count($resultSet)) {
                throw new DomainException('Insert operation failed or did not result in new row', 500);
            }
        } else {
            $record = $resultSet->current();
            $this->table->update($apiData, array('id' => $record->id));
        }
        return array('meta'=>array('status'=>'ok','code'=>200,'method_name'=>'progress'),'log'=>array());
    }

    /**
    * Fetch all Weightlog
    *
    * @param array $params
    * @return Entity
    */
    public function fetchAll($params)
    {
        $where = new \Zend\Db\Sql\Where();
        $where->equalTo('user_weight_log.status_id', 1)
              ->equalTo('user_weight_log.user_id', $params['userId'])
              ->equalTo('user_weight_log.date', $params['date']);

        $select = $this->table->getSql()->select();
        $select->columns(array('id','date', 'weight', 'body_fat'))
           ->where($where);
        $row = $this->table->selectWith($select);

        return $row->toArray();
    }
   
    /**
    * Delete Weightlog
    *
    * @param array $data
    * @return Entity
    */
    public function delete($data)
    {
        $resultSet = $this->table->select(array('user_id' => $data->user_id, 'id'=>$data->id));
       
        if (0 === count($resultSet)) {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Record!');
        } else {
            $result = $this->table->update(array('status_id'=>4, 'updated_date'=>gmdate('Y-m-d H:i:s')    ), array('id' => $data->id));

            if (!$result) {
                return false;
            }
            return true;
        }
    }
}
