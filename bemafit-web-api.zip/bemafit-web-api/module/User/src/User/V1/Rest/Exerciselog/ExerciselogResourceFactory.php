<?php
namespace User\V1\Rest\Exerciselog;

class ExerciselogResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('User\V1\Rest\ExerciselogMapperTableGateway');
        return new ExerciselogResource($mapper);
    }
}
