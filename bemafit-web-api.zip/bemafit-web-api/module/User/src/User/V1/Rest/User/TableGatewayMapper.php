<?php

namespace User\V1\Rest\User;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use Zend\Validator\Db\NoRecordExists;
use ZF\ApiProblem\ApiProblem;
use Zend\Crypt\Password\Bcrypt;
use Aws\Ses\SesClient;
use Aws\S3\S3Client;
use Facebook\FacebookSession;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;
    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\UserDetailTable');
        return $this->Table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getMasterTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('MasterData\V1\Model\MasterTable');
        return $this->Table;
    }

    public function getInviteUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\InviteUserTable');
        return $this->Table;
    }

    public function getFriendRequestMapperTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\FriendRequestMapperTableGateway');
        return $this->Table;
    }

    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function getUserSettingsMapperTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserSettings\UserSettingsMapperTableGateway');
        return $this->Table;
    }

    /**
    * User Validation
    *
    * @param array $data
    * @return Entity
    */
    public function customValidation($data)
    {
        $config = $this->getServiceLocator()->get('Config');

        $activityLevels =    $this->getMasterTable()->getActivityLevels($data->diet_activity_level);
        if (!$activityLevels) {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid activity level');
        }

        $nutritionalPlans =    $this->getMasterTable()->getnutritionalPlans($data->diet_nutritional_plan);
        if (!$nutritionalPlans) {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid diet nutritional plan level');
        }

        if ($data->diet_calory_type=='custom' && trim($data->diet_goal_calories)=='') {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Calorie required');
        }

        if (strtoupper(trim($data->gender)) != 'M' && strtoupper(trim($data->gender)) != 'F') {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Possible gender values are M and F');
        }

        if (!empty($data->website)) {
            if (filter_var($data->website, FILTER_VALIDATE_URL) === false) {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid website');
            }
        }

        if (!in_array($data->diet_formula, array('physique', 'lean_mass'))) {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid diet formula');
        }

        if (!in_array($data->diet_calory_type, array('custom', 'calculated'))) {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid diet calory type');
        }

        if (!in_array($data->diet_macro_type, array('custom', 'calculated'))) {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid diet macro type');
        }

        if ($data->diet_macro_type == 'custom') {
            if (empty($data->diet_macro_fiber) || empty($data->diet_macro_fat) || empty($data->diet_macro_carbs) || empty($data->diet_macro_protein)) {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'All diet macros required for diet macro type custom');
            }
        }

        
        

    }

    public function validateAndGetFacebookProfileID($data)
    {
        $config = $this->getServiceLocator()->get('Config');
        $this->facebook_id = '';
        if (!empty($data->facebook_access_token)) {
            FacebookSession::setDefaultApplication($config['facebook_credentials']['app_id'], $config['facebook_credentials']['app_secret']);
            $session = new FacebookSession($data->facebook_access_token);
            try {
                $result = $session->validate();
                if ($result) {
                    //Facebook session is valid. Now get facebook user id from access token.
                    $utilityObj = new \Application\Service\Utility();
                    return   $utilityObj->getFacebookProfileIDByAccessToken($data->facebook_access_token);
                } else {
                    return \Application\Service\FymApiProblem::ApiProblem(422, 'Facebook Connect: Invalid or expired Access Token');
                }
            } catch (FacebookRequestException $ex) {
                return \Application\Service\FymApiProblem::ApiProblem(422, "Facebook Connect: ".$ex->getMessage());
            } catch (\Exception $ex) {
                return \Application\Service\FymApiProblem::ApiProblem(422, "Facebook Connect: ".$ex->getMessage());
            }
        }
        return '';
    }

    /**
    * Create User
    *
    * @param array $data
    * @return Entity
    */
    public function create($data)
    {
        $config = $this->getServiceLocator()->get('Config');
        $file_upload_settings = $config['user_photo_Settings'];

         
        $utilityObj = new \Application\Service\Utility();
        $config = $this->getServiceLocator()->get('Config');

        $this->customValidation($data);
        $facebook_profile_id = $this->validateAndGetFacebookProfileID($data);

        if (!empty($data->facebook_access_token)) {
            $fb_user_exist = $this->table->select(array('facebook_user_id'=>$facebook_profile_id, 'status_id'=>1));

            if ($fb_user_exist->current()) {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Another user connected through this facebook account.');
            }
        }
        
        if (!empty($data->email)) {
            if (filter_var($data->email, FILTER_VALIDATE_EMAIL) === false) {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Email');
            }
        } else {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'Email Required');
        }
        
        if (strlen(trim($data->password)) < 6) {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Password should be atleast 6 characters');
        }

        if (trim($data->user_name)=='') {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'username required');
        }
       
        $validator = new  NoRecordExists(
            array(
                'adapter' => $this->getAdapter(),
                'table' => 'user',
                'field' => 'username',
                //'exclude' => ' user.status_id=1',
                'message' => 'User already exists.',
            )
        );

        if (!$validator->isValid($data->user_name)) {
            $messages = $validator->getMessages();
            return \Application\Service\FymApiProblem::ApiProblem(200, $messages['recordFound']);
        }

        $validator = new  NoRecordExists(
            array(
                'adapter' => $this->getAdapter(),
                'table' => 'user',
                'field' => 'email',
                //'exclude' => ' user.status_id=1',
                'message' => 'Email already exists.',
            )
        );
        
        if (!$validator->isValid($data->email)) {
            $messages = $validator->getMessages();
            return \Application\Service\FymApiProblem::ApiProblem(200, $messages['recordFound']);
        }

        $image_name = $this->getUploadProfilePhoto();
        
        $preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];

        if (empty($image_name)) {
            $image_name = substr(strtolower($data->user_name),0,1).".png";
        }


        $image_url = empty($image_name)?'':$this->getAwsImageUrl($preview_bucket_url.'/'.$image_name);
        //$securePass = $bcrypt->create($data->password);
        $apiData['guid']        =   md5(uniqid(rand(), true));
        $apiData['username']    =   $data->user_name;
        $apiData['email']       =   $data->email;
        
        $apiData['first_name']  =   $data->first_name;
        $apiData['last_name']   =   $data->last_name;
        $apiData['role']        =   'User';
        $apiData['password']    =   $data->password;
        $apiData['profile_photo']        = $image_name;
        $apiData['type']        = 'Public';
        $apiData['status_id']   =   1;
        $apiData['website']     =   $data->website ;
        $apiData['gender']      =   $data->gender;
        $apiData['dob']         =   $data->dob;
        $apiData['facebook_user_id']    =   $facebook_profile_id;
        $apiData['date_added'] = gmdate('Y-m-d H:i:s')    ;

        $this->table->insert($apiData);
        $newuserId = $this->table->lastInsertValue;

        if ($newuserId > 0) {
            $calcualted_values = $this->getCalculatedCalorieValues(array('diet_activity_level'=>$data->diet_activity_level,
                                                                                   'diet_goal_calories'=>$data->diet_goal_calories,
                                                                                   'fat'=>$data->fat,
                                                                                   'gender'=>$data->gender,
                                                                                   'height'=>$data->height,
                                                                                   'weight'=>$data->weight,
                                                                                   'dob'=>$data->dob,
                                                                                   'diet_goal_option'=>$data->diet_goal_option,
                                                                                   'diet_formula'=>$data->diet_formula,
                                                                                   'diet_calory_type'=>$data->diet_calory_type,
                                                                                   'diet_macro_type'=>$data->diet_macro_type,
                                                                                   'diet_nutritional_plan'=>$data->diet_nutritional_plan,
                                                                                   'diet_macro_fiber'=>$data->diet_macro_fiber,
                                                                                   'diet_macro_fat'=>$data->diet_macro_fat,
                                                                                   'diet_macro_carbs'=>$data->diet_macro_carbs,
                                                                                   'diet_macro_protein'=>$data->diet_macro_protein,
                                                                                   ));

            $userDetailData = array(
                'user_id'=> $newuserId,
                'height' => $data->height,
                'weight'  => $data->weight,
                'body_fat'  => $data->fat,
                'formula' => $data->diet_formula,
                'activity_level_id'  => $data->diet_activity_level ,
                'diet_calory_type'  => $data->diet_calory_type ,
                'diet_macro_type'  => $data->diet_macro_type ,
                'goal_option_id'  => !empty($data->diet_goal_option)?$data->diet_goal_option:null,
                'protein'  => $calcualted_values['protein'],
                'fat'  => $calcualted_values['fat'],
                'carbs'  => $calcualted_values['carbs'],
                'fiber'  => $calcualted_values['fiber'],
                'calories'  => $calcualted_values['diet_maintain'] ,
                'diet_goal_calories'  => $calcualted_values['diet_goal_calories'] ,
                'neutirition_plan_id'  => $data->diet_nutritional_plan,
                'email_verification_code'  => $apiData['guid'].'-'.md5(uniqid(rand(), true)),
                'no_of_meals'  => !empty($data->no_of_meals)?$data->no_of_meals:"",
            );

            $this->getUserDetailTable()->create($userDetailData);
            $this->sendAutoFriendRequestsToInvitedUsers($apiData['guid'], $apiData['email']);
            $this->getUserSettingsMapperTable()->insertDefaultSettings($newuserId);
            $this->getUserSettingsMapperTable()->insertDefaultWeightLog(array('user_id'=>$newuserId, 'date'=>$apiData['date_added'], 'weight'=>$data->weight,
                    'body_fat'=>$data->fat, 'status_id'=>1, 'created_date'=>$apiData['date_added']));


        } else {
        }

        $resultSet = $this->table->select(array('id' => $this->table->lastInsertValue));
        if (0 === count($resultSet)) {
            throw new DomainException('Insert operation failed or did not result in new row', 500);
        }


        $mail_status = $this->sendConfirmationMail($apiData, $userDetailData);
        return array(
                      'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'createUser'),
                      'user'=>
                            array('user_id'=>$apiData['guid'], 'type'=>$apiData['type'], 'first_name'=>$data->first_name, 'last_name'=>$data->last_name, 'user_name'=>$data->user_name, 'email'=>$data->email,
                                  'website'=>$data->website, 'facebook_id'=>$facebook_profile_id, 'gender'=>$data->gender, 'profile_photo'=>$image_url, 
                                  'push_notification'=>'Yes', 'dob'=>$data->dob, 'height'=>$data->height, 'weight'=>$data->weight,
                                  'fat'=>$data->fat),
                      'mail_status'=>$mail_status,
                      'diet'=>
                            array('no_of_meals'  => $userDetailData['no_of_meals'],'diet_formula'=>$data->diet_formula, 'diet_activity_level'=>$data->diet_activity_level, 'diet_macro_type'=>$data->diet_macro_type, 'diet_calory_type'=>$data->diet_calory_type,
                                  'diet_goal_option_id'=> $calcualted_values['goal_option_id'],
                                  'diet_nutritional_plan'=>$data->diet_nutritional_plan, 'diet_maintain_calories'=>(string)$calcualted_values['diet_maintain'], 'diet_goal_calories'=>(string)$calcualted_values['diet_goal_calories'], 'diet_fiber'=>(string)$calcualted_values['fiber'],
                                  'diet_macros'=> array('diet_macro_fat'=>(string)$calcualted_values['fat'], 'diet_macro_protein'=>(string)$calcualted_values['protein'], 'diet_macro_carbs'=>(string)$calcualted_values['carbs']),
                                   )
                );
    }

    /**
    * Update User
    *
    * @param int $id
    * @param array $data
    * @return Entity
    */
    public function update($id, $data)
    {
        $config = $this->getServiceLocator()->get('Config');
        $resultSet = $this->table->select(array('guid' => $id, 'status_id'=>1));
        if (0 === count($resultSet)) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $user = $resultSet->current();  
        $validator = new  NoRecordExists(
            array(
                'adapter' => $this->getAdapter(),
                'table' => 'user',
                'field' => 'email',
                'exclude' => " user.status_id=1 AND user.email = '".$data->email."' AND user.guid <>'".$id."'",
                'message' => 'User already exists.',
            )
        );

        if (!$validator->isValid($data->email)) {
            $messages = $validator->getMessages();
            return \Application\Service\FymApiProblem::ApiProblem(422, 'User already exists.');
        }

        $this->customValidation($data);

        

        $preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
        $image_url = empty($user->profile_photo)?'':$this->getAwsImageUrl($preview_bucket_url.'/'.$user->profile_photo);

        $apiData['email']       =   $data->email;
        
        $apiData['first_name']  =   $data->first_name;
        $apiData['last_name']   =   $data->last_name;
        $apiData['role']        =   'User';
        $apiData['status_id']   =   1;
        $apiData['website']     =   $data->website ;
        $apiData['gender']      =   $data->gender;
        $apiData['dob']         =   $data->dob;
        //$apiData['facebook_user_id']    =   $data-> facebook_id;
        $apiData['date_updated'] = gmdate('Y-m-d H:i:s')    ;
        $apiData['updated_by'] = $id;


        $this->table->update($apiData, array('guid' => $id));

        $calcualted_values = $this->getCalculatedCalorieValues(array('diet_activity_level'=>$data->diet_activity_level,
                                                                                   'diet_goal_calories'=>$data->diet_goal_calories,
                                                                                   'fat'=>$data->fat,
                                                                                   'gender'=>$data->gender,
                                                                                   'height'=>$data->height,
                                                                                   'weight'=>$data->weight,
                                                                                   'dob'=>$data->dob,
                                                                                   'diet_goal_option'=>$data->diet_goal_option,
                                                                                   'diet_formula'=>$data->diet_formula,
                                                                                   'diet_calory_type'=>$data->diet_calory_type,
                                                                                   'diet_macro_type'=>$data->diet_macro_type,
                                                                                   'diet_nutritional_plan'=>$data->diet_nutritional_plan,
                                                                                   'diet_macro_fiber'=>$data->diet_macro_fiber,
                                                                                   'diet_macro_fat'=>$data->diet_macro_fat,
                                                                                   'diet_macro_carbs'=>$data->diet_macro_carbs,
                                                                                   'diet_macro_protein'=>$data->diet_macro_protein,
                                                                                   ));
        //var_dump( $calcualted_values);
        $userDetailData = array(
                'height' => $data->height,
                'weight'  => $data->weight,
                'body_fat'  => $data->fat,
                'formula' => $data->diet_formula,
                'activity_level_id'  => $data->diet_activity_level ,
                'diet_calory_type'  => $data->diet_calory_type ,
                'diet_macro_type'  => $data->diet_macro_type ,
                'goal_option_id'  => $data->diet_goal_option,
                'protein'  => $calcualted_values['protein'],
                'fat'  => $calcualted_values['fat'],
                'carbs'  => $calcualted_values['carbs'],
                'fiber'  => $calcualted_values['fiber'],
                'calories'  => $calcualted_values['diet_maintain'] ,
                'diet_goal_calories'  => $calcualted_values['diet_goal_calories'] ,
                'neutirition_plan_id'  => $data->diet_nutritional_plan,
                'no_of_meals'  => !empty($data->no_of_meals)?$data->no_of_meals:"",
            );
    
        $this->getUserDetailTable()->update($user->id, $userDetailData);

        $user_detail = $this->getUserDetailTable()->getUserDetailsById($user->id);

        return array(
                     'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'updateUser'),
                     'user'=>
                            array('user_id'=>$user->guid, 'user_type'=>$user->type, 'first_name'=>$data->first_name, 'last_name'=>$data->last_name, 'user_name'=>$user->username, 'email'=>$data->email,
                                  'website'=>$data->website, 'facebook_id'=>$data->facebook_id, 'gender'=>$data->gender, 'profile_photo'=>$image_url, 
                                  'push_notification'=>$user_detail->push_notification, 'dob'=>$data->dob, 'height'=>$data->height, 'weight'=>$data->weight,
                                  'fat'=>$data->fat),
                      'diet'=>
                            array('no_of_meals'  => $userDetailData['no_of_meals'], 'diet_formula'=>$data->diet_formula, 'diet_activity_level'=>$data->diet_activity_level, 'diet_macro_type'=>$data->diet_macro_type, 'diet_calory_type'=>$data->diet_calory_type,
                                  'diet_goal_option_id'=> $calcualted_values['goal_option_id'],
                                  'diet_nutritional_plan'=>$data->diet_nutritional_plan, 'diet_maintain_calories'=>(string)$calcualted_values['diet_maintain'], 'diet_goal_calories'=>(string)$calcualted_values['diet_goal_calories'], 'diet_fiber'=>(string)$calcualted_values['fiber'],
                                  'diet_macros'=> array('diet_macro_fat'=>(string)$calcualted_values['fat'], 'diet_macro_protein'=>(string)$calcualted_values['protein'], 'diet_macro_carbs'=>(string)$calcualted_values['carbs']),
                                   )
                );

    }

    /**
    * Calculate nutrtion details
    *
    * @param array $params
    * @return Entity
    */
    public function getCalculatedCalorieValues($params)
    {
        $activityLevels =    $this->getMasterTable()->getActivityLevels($params['diet_activity_level']);

        $activity_level = $activityLevels[0];
        $activity_weight = $activityLevels[0]['weight'];

        $age  = floor((time() - strtotime($params['dob']))/(60*60*24*365));
        $weightInKg = $params['weight'] / 2.2046;

        if ($params['diet_calory_type']=='custom') {
            $TDEE = $params['diet_goal_calories'];
        } else {
            if ($params['diet_formula'] == 'lean_mass') {
                $lean_body_mass =   $weightInKg * ((100 - $params['fat']) / 100 ) ;
                $BMR            =   21.6 * ($weightInKg * ((100 - $params['fat']) / 100 )) + 370;
            } else {
                if ($params['gender'] == 'M') {
                    $BMR = ((10 * $weightInKg) + (6.25 * $params['height']) - (5 * $age) +5);
                } else {
                    $BMR = ((10 * $weightInKg) + (6.25 * $params['height']) - (5 * $age)-161);
                }
            }
            $TDEE = ceil($BMR * $activity_weight);
        }
        



        //*//$TDEE = ceil($BMR * $activity_weight);
        
        $goal_option_id = '';
        $diet_goal_id = '';
        $goal_percentage = 0;

        if (!empty($params['diet_goal_option'])) {
            $goal_option_info =    $this->getMasterTable()->getGoals($params['diet_goal_option']);
            if ($goal_option_info) {
                $goal_option_id = $goal_option_info[0]['goal_option_id'];
                $goal_percentage = $goal_option_info[0]['percentage'];
                $diet_goal_id =  $goal_option_info[0]['id'];
            } else {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid goal option');
            }
        }
       
        $SUGGESTED_TDEE =   $TDEE;
        $diet_maintain =   $TDEE;
        if ($diet_goal_id == 2) {
            $SUGGESTED_TDEE =   $TDEE * ((100 - $goal_percentage)/100);
        } else if ($diet_goal_id == 3) {
            $SUGGESTED_TDEE =   $TDEE * ((100 + $goal_percentage)/100);
        }



        if ($params['diet_macro_type'] == 'custom') {
            $fiber = $params['diet_macro_fiber'];
            $fat = $params['diet_macro_fat'];
            $carbs = $params['diet_macro_carbs'];
            $protein = $params['diet_macro_protein'];
        } else {
            if ($params['diet_nutritional_plan'] == 1) {
                $protein = $params['weight'] * 1;
                $fat = $params['weight'] * .35;
                $carbs = ($SUGGESTED_TDEE - ($protein * 4) - ($fat * 9)) / 4;
                $fiber = $SUGGESTED_TDEE * .014;

               
            } else {
                /*WILL BE UPDATED WITH NEW FORMULA LATER*/
                $protein = $params['weight'] * 1;
                $fat = $params['weight'] * .35;
                $carbs = ($SUGGESTED_TDEE - ($protein * 4) - ($fat * 9)) / 4;
                $fiber = $SUGGESTED_TDEE * .014;
            }
        }

        
        

        return array(   'protein'  => $protein,
                        'fat'  => $fat,
                        'carbs'  => ($carbs),
                        'fiber'  => $fiber,
                        'diet_goal_calories'  => ($SUGGESTED_TDEE),
                        'diet_maintain' => $diet_maintain,
                        'goal_option_id' =>$goal_option_id,
                    );

    }

    /**
    * Update profile photo
    *
    * @return Entity
    */
    public function getUploadProfilePhoto()
    {
        if (isset($_FILES['photo'])) {
            $config = $this->getServiceLocator()->get('Config');
            $file_upload_settings = $config['user_photo_Settings'];
            
            $utilityObj = new \Application\Service\Utility();
            $image_name = md5(uniqid(rand(), true));
            $file_upload_status = $utilityObj->photoUpload(array('upload_dir'=>$file_upload_settings['server_upload_path'], 'image_name'=>$image_name));

            if (!$file_upload_status['status']) {
                return \Application\Service\FymApiProblem::ApiProblem(406, $file_upload_status['message']);
            } else {
                $image_name = $file_upload_status['file_name'];
            }
            
            //Valid file exists to upload
            if (!empty($image_name)) {
                $config = $this->getServiceLocator()->get('Config');
                $file_upload_settings = $config['user_photo_Settings'];

                $s3_upload_status = true;
                $s3_client = S3Client::factory($config['amazon_s3']);
                try {
                    $result = $s3_client->putObject(array(
                        'Bucket'     => $file_upload_settings['bucket'],
                        'Key'        => $image_name,
                        'SourceFile' => $file_upload_settings['server_upload_path'].$image_name
                    ));

                    //Successfully uploaded to amason s3. Then resize image and upload these thumbs to s3
                    if (isset($result['ObjectURL'])) {
                        $utilityObj = new \Application\Service\Utility();

                        foreach ($file_upload_settings['thumbs'] as $thumb) {
                            $key = key($thumb);
                            $resize_status = $utilityObj->smart_resize_image(
                                $file_upload_settings['server_upload_path'].$image_name,
                                $file_upload_settings['server_upload_path'].$image_name,
                                $thumb[$key]['width'],
                                0,
                                true,
                                $file_upload_settings['thumb_server_upload_path'].$image_name,
                                false,
                                false,
                                $quality = 100
                            );

                            //Resize successfull. Upload to amazon
                            if ($resize_status) {
                                try {
                                    $result = $s3_client->putObject(array(
                                        'Bucket'     => $thumb[$key]['bucket'],
                                        'Key'        => $image_name,
                                        'SourceFile' => $file_upload_settings['thumb_server_upload_path'].$image_name
                                    ));
                                } catch (\Exception $ex) {
                                    $s3_upload_status = false;
                                    //var_dump($ex->getMessage());
                                }
                            }
                        }

                        if (file_exists($file_upload_settings['server_upload_path'].$image_name)) {
                            if (is_file($file_upload_settings['server_upload_path'].$image_name)) {
                                unlink($file_upload_settings['server_upload_path'].$image_name);
                            }
                        }
                        if (file_exists($file_upload_settings['thumb_server_upload_path'].$image_name)) {
                            if (is_file($file_upload_settings['thumb_server_upload_path'].$image_name)) {
                                unlink($file_upload_settings['thumb_server_upload_path'].$image_name);
                            }
                        }
                        
                        if ($s3_upload_status) {
                            return $image_name;
                        }

                        //var_dump($result['ObjectURL']);
                    }
                } catch (\Exception $ex) {
                    $s3_upload_status = false;
                }
            
            }
        }

    }

    /**
    * Fetch user details
    *
    * @param int $id
    * @return Entity
    */
    public function fetch($id)
    {
        $resultSet = $this->table->select(array('id' => $id));
        if (0 === count($resultSet)) {
            throw new DomainException('User not found', 404);
        }
        return $resultSet->current();
    }

    /**
    * Fetch all users
    *
    * @param array $params
    * @return Entity
    */
    public function fetchAll($params)
    {   
        $config = $this->getServiceLocator()->get('Config');
        $this->getAdapter();
        $where_arr = array($params['user_id'], $params['user_id']);
        $subQuery = '';
        $excludeQuery = '';
        $exclude  = $params['exclude'];
        if ($params['keyword']!='') {
            $keywords = preg_split('#\s+#', $params['keyword']);
            $subQuery = "AND (  u.first_name LIKE ?  OR u.last_name LIKE ?   OR u.username LIKE ? ) ";
            //array_push($where_arr, '');
            array_push($where_arr, '%'.trim($params['keyword']).'%', '%'.trim($params['keyword']).'%', '%'.trim($params['keyword']).'%');
            if(trim($keywords[1]) !='') {
              $subQuery = "AND ( u.first_name LIKE ?  OR u.last_name LIKE ?  OR u.username LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ? OR u.username LIKE ? OR u.username LIKE ? )";
              array_push($where_arr,'%'.trim($keywords[0]).'%', '%'.trim($keywords[1]).'%', '%'.trim($keywords[0]).'%', '%'.trim($keywords[1]).'%');
            }
        }

        if (isset($params['exclude']) && $params['exclude']=='friends') {
            $excludeQuery.= " AND  IF(fs.status_id=1,0,1)";
        }

        if (isset($params['exclude']) && $params['exclude']=='friendsAndRequestReceived') {
            $excludeQuery.= " AND  IF((fs.status_id=1 OR fr.status_id=3),0,1)";
        }

        array_push($where_arr, $params['offset'], $params['limit']);
        $sql = "SELECT SQL_CALC_FOUND_ROWS  DISTINCT  u.id, u.guid AS user_id, u.username, u.email, u.first_name, u.last_name, u.profile_photo, 
                fs.status_id AS send_status, fr.status_id AS receive_status, 
                COUNT(DISTINCT usr_following.id) following ,COUNT(DISTINCT usr_followers.id) followers
                FROM `user` u
                LEFT JOIN user_follower ufollowers ON u.id= ufollowers.following_user_id AND ufollowers.status_id=1 
                LEFT JOIN user_follower ufollowing ON u.id= ufollowing.user_id AND ufollowing.status_id=1
                LEFT JOIN friends fs ON u.id=fs.friend_id AND (fs.status_id = 1 OR fs.status_id = 3 )  AND fs.user_id=?
                LEFT JOIN friends fr ON u.id=fr.user_id AND (fr.status_id=1 OR fr.status_id=3 ) AND fr.friend_id=?
                LEFT JOIN `user` usr_followers ON ufollowers.user_id=usr_followers.id AND usr_followers.status_id=1
                LEFT JOIN `user` usr_following ON ufollowing.following_user_id=usr_following.id AND usr_following.status_id=1
                WHERE 1   AND  u.role!='Admin' AND u.status_id=1 AND u.id<>".$params['user_id']." $excludeQuery $subQuery
                GROUP BY u.id 
                ORDER BY u.username
                LIMIT ?, ?";
        //die($sql);
        $statement = $this->adapter->createStatement($sql, $where_arr);

        $result = $statement->execute();
        $users = $result->getResource()->fetchAll(2);
        $user_list = array();
        foreach ($users as $user) {
            if ($user['send_status'] == 1) {
                $status = 'friends';
            } else if ($user['send_status'] == 3) {
                $status = 'friendRequestSent';
            } else if ($user['receive_status'] == 3) {
                $status = 'friendRequestReceived';
            } else {
                $status= 'nonFriend';
            }
            $preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
            $image_url = empty($user['profile_photo'])?$user['profile_photo']:$this->getAwsImageUrl($preview_bucket_url.'/'.$user['profile_photo']);

            $user_list[] = array ('user_id'=> $user['user_id'], 'user_name'=> $user['username'], 'email'=>$user['email'], 'first_name'=> (string)$user['first_name'], 'last_name'=> (string)$user['last_name'],
                                'following'=> $user['following'] , 'followers'=> $user['followers'], 'profile_photo'=> (string)$image_url, 'status'=>$status);
            
        }
        $total_rows = $this->adapter->createStatement('SELECT FOUND_ROWS()  as total_rows')->execute()->getResource()->fetchAll()[0]['total_rows'];

        return array(
                      'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'getUsers'),
                      'friends'=>$user_list,
                      'total_users'=>$total_rows,
                );

    }

    public function test($id, $data)
    {
        $this->table->update($data, array('id' => $id));
    }

    /**
    * Delete user
    *
    * @param int $id
    * @return Entity
    */
    public function delete($id)
    {
        $result = $this->table->delete(array('id' => $id));

        if (!$result) {
            return false;
        }

        return true;
    }

    /**
    * Get user by email
    *
    * @param string $email
    * @return Entity
    */
    public function getUserByEmail($email)
    {
        $resultSet = $this->table->select(array('email'=>$email,'status_id'=>1));

        if (0 === count($resultSet)) {
            return false;
        }

        return $resultSet->current();
    }

    /**
    * Get user by id
    *
    * @param string $userId
    * @return Entity
    */
    public function getUserById($userId)
    {
        $resultSet = $this->table->select(array('id'=>$userId,'status_id'=>1));

        if (0 === count($resultSet)) {
            return false;
        }

        return $resultSet->current();
    }

    /**
    * Get user by guid
    *
    * @param string $guid
    * @return Entity
    */
    public function getUserByGuid($guid)
    {
        $resultSet = $this->table->select(array('guid'=>$guid,'status_id'=>1));

        if (0 === count($resultSet)) {
            return false;
        }

        return $resultSet->current();
    }

    /**
    * Update user
    *
    * @param int $id
    * @param array $data
    * @return Entity
    */
    public function updateUser($id, $data)
    {
        return $this->table->update($data, array('id' => $id));
    }

    /**
    * Check is Active user
    *
    * @param int $user_id
    * @return Entity
    */
    public function isActiveUser($user_id)
    {
        $resultSet = $this->table->select(array('id'=>$user_id,'status_id'=>1));

        if (0 === count($resultSet)) {
            return false;
        }

        return true;
    }

    /**
    * Send Confirmation Mail
    *
    * @param array $apiData
    * @param array $userDetailData
    * @return Entity
    */
    public function sendConfirmationMail($apiData, $userDetailData)
    {
     
        $config = $this->getServiceLocator()->get('Config');

        $htmlViewPart = new \Zend\View\Model\ViewModel();
        $htmlViewPart->setTerminal(true)
           ->setTemplate('emailconfirmation')
           ->setVariables(array(
              'name' => $apiData['first_name'].' '.$apiData['last_name'],
              'confirmation_url' => $config['emailVerificationUrl'].$userDetailData['email_verification_code'],
              'site_url'=>$config['site_url']
           ));

        $htmlOutput = $this->getServiceLocator()
            ->get('viewrenderer')
            ->render($htmlViewPart);
           

        /*SENDING EMAIL*/
        $ses_client = SesClient::factory($config['amazon_ses']);

        try {
            $result = $ses_client->sendEmail(array(
            'Source' => "FYM<". $config['mail']['default_sender_id'].">",
            'Destination' => array(
                'ToAddresses' => array($apiData['email']),
            ),
            'Message' => array(
                'Subject' => array(
                    'Data' => 'Confirmation from FYM',
                    'Charset' => 'UTF-8',
                ),
                'Body' => array(
                    
                    'Html' => array(
                        'Data' => $htmlOutput,
                        'Charset' => 'UTF-8',
                    ),
                ),
            ),
            'ReplyToAddresses' => array($config['mail']['default_sender_id'])
            ));
        
            if ($result) {
                if (!empty($result['MessageId'])) {
                    return array('status'=>true, 'message'=>'Confirmation email sent');
                } else {
                    return array('status'=>false, 'message'=>'Email not sent');
                }
            }
        
        } catch (\Exception $ex) {
            return array('status'=>false, 'message'=>$ex->getMessage());
        }
        /*END SENDING EMAIL*/

        return true;
     
    }

    /**
    * get Aws Image Url
    *
    * @param string $url
    * @param string $expire
    * @return Entity
    */
    public function getAwsImageUrl($url, $expire = '+1 year')
    {
        //https://s3.amazonaws.com/fymprofilethumbs/profile200/20880310a0f33ed80909be449f0c3439.jpg
        $config = $this->getServiceLocator()->get('Config');
        /*
        //Code for presigned url
         
        $client = S3Client::factory($config['amazon_s3']);
        $request = $client->get($url);
        $client->createPresignedUrl($request, $expire);
        */
        return $config['aws_s3_path'].'/'.$url;
    }

    /**
    * Send Auto Friend Requests To Invited Users
    *
    * @param int $newuserId
    * @param Email $email
    * @return Entity
    */
    public function sendAutoFriendRequestsToInvitedUsers($newuserId, $email)
    {
        $invited_users = $this->getInviteUserDetailTable()->getInvitedUsers($email);
        

   
        foreach ($invited_users as $user) {
            $user_info = $this->getUserById($user->user_id);
            if ($user_info) {
                $friendRequestObj = (object) array('user_id' => $newuserId, 'currentUserId'=>$user_info->id);
                $this->getFriendRequestMapperTable()->createFriendRequest($friendRequestObj);
            }
        }
    }

    /**
    * logout
    *
    * @param string $access_token
    * @return Entity
    */
    public function logout($access_token)
    {
        $adapter = $this->table->getAdapter();
        $followTable = new \Zend\Db\TableGateway\TableGateway('oauth_access_tokens', $adapter);
        return $followTable->delete(array('access_token'=>$access_token));
       
    }
}
