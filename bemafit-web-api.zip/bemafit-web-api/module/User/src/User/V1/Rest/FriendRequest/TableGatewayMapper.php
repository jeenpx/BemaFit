<?php

namespace User\V1\Rest\FriendRequest;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }
    
    public function getFriendRequestDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FriendRequestDetailTable');
        return $this->Table;
    }

    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function getFeedMapper()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Feeds\V1\Rest\FeedMapperTableGateway');
        return $this->Table;
    }

    public function getUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\UserDetailTable');
        return $this->Table;
    }

    /**
    * Friend Request
    *
    * @param array $data
    * @return Entity
    */
    public function create($data)
    {
        return $this->createFriendRequest($data);
    }
    
    /**
    * Freind Request
    *
    * @param array $data
    * @return Entity
    */
    public function createFriendRequest($data)
    {
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data->user_id);
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $friendId    = $user_info->id;
        $currentUserId = $data->currentUserId;
        
        $is_friends = $this->getFriendRequestDetailTable()->isFriends($currentUserId, $friendId);
        if ($is_friends) {
            return \Application\Service\FymApiProblem::ApiProblem(406, 'You are already friends');
        }

        $friend_request_info = $this->getFriendRequestDetailTable()->getFriendRequestSent($currentUserId, $friendId);
        if ($friend_request_info) {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'You are already sent a friend request to this user');
        }

        $utilityObj = $this->getServiceLocator()->get('utility_service');
        

        $apiData['guid']        =   md5(uniqid(rand(), true));
        $apiData['user_id']     =   $currentUserId;
        $apiData['friend_id']   =   $friendId;
        $apiData['status_id']   =   3;
        $apiData['created_at'] = gmdate('Y-m-d H:i:s')    ;

        $this->table->insert($apiData);
        $newuserId = $this->table->lastInsertValue;

        $friendRequestData['status_id']   =   3;
        $friendRequestData['user_id'] = $currentUserId;
        $friendRequestData['friend_id'] = $newuserId;
        $friendRequestData['created_at'] = gmdate('Y-m-d H:i:s')    ;
        $status = $this->getFriendRequestDetailTable()->create($friendRequestData);
        
        $user_dtails_info  = $this->getUserDetailTable()->getUserDetailsById($user_info->user_id);
        $sendPushNotification = (!empty($user_dtails_info->push_notification)&& $user_dtails_info->push_notification=='Yes') ?true:false;

        //Begin Send IOS Push Notification
        if (!empty($user_info->device_token) && $sendPushNotification) {
            $logged_in_userinfo =  $this->getFymUserDetailTable()->getUserDetailsById($currentUserId);
            $device_tokens = unserialize($user_info->device_token); 
            $payload['alert'] = $logged_in_userinfo->username.' is requesting to be your friend';
            $payload['sender_id'] = $logged_in_userinfo->guid;
            $payload['sender_user_name'] = $logged_in_userinfo->username;
            $payload['type'] = 'friend_request_sent';
            $utilityObj->sendIOSPushnotification($device_tokens, $payload, 'friend_request_sent');
        }
        //End Send IOS Push Notification
        
        return  array(
                      'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'sendFriendRequest'),
                      'friendRequest'=>
                            array('userId'=>$data->user_id),
                );
    }

    /**
    * Fetch Freind
    *
    * @param int $id
    * @return Entity
    */
    public function fetch($id)
    {
        $resultSet = $this->table->select(array('id' => $id));
        if (0 === count($resultSet)) {
            throw new DomainException('Business not found', 404);
        }
        return $resultSet->current();
    }

    /**
     * @return Collection
     */
    public function fetchAll()
    {
        return new BusinessCollection(new DbTableGateway($this->table, null, array('created_date' => 'DESC')));
    }

    /**
    * Update Friend request
    *
    * @param int $id
    * @param array $data
    * @return Entity
    */
    public function update($id, $data)
    {   
       
        $logged_in_userinfo =  $this->getFymUserDetailTable()->getUserDetailsById($data->currentUserId);
        $friend_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($id);
        

        $utilityObj = $this->getServiceLocator()->get('utility_service');


        $friend_request_info = $this->getFriendRequestDetailTable()->getFriendRequestDetails($id,$data->currentUserId);

        if (!$friend_request_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }

        if (empty($data->response_status) || ($data->response_status!='Accepted' && $data->response_status!='Rejected')) {
            return \Application\Service\FymApiProblem::ApiProblem(406, 'Invalid response status');
        }

        $response['meta'] = array('status'=>'OK', 'code'=>200, 'methodName' => 'respondFriendRequest');
        
        $friend_id = $friend_request_info[0]['friend_id'];
        $apiData['updated_at'] = gmdate('Y-m-d H:i:s')    ;
        
        if ($data->response_status == 'Rejected') {
            $apiData['status_id']   =   6;
            $friendRequestData['status_id']   =   6;
        } else if ($data->response_status == 'Accepted') {
            $apiData['status_id']   =   1;
            $friendRequestData['status_id']   =   5;

            $friendData['created_at'] = gmdate('Y-m-d H:i:s')    ;
            $friendData['status_id']      =   1;
            $friendData['guid']        =   md5(uniqid(rand(), true));
            $friendData['user_id']     =   $friend_request_info[0]['my_id'];
            $friendData['friend_id']   =   $friend_request_info[0]['sender_id'];
            $this->table->insert($friendData);
            $newFriendId = $this->table->lastInsertValue;

           
            /*When accept a friend request, both users will be follow by each other*/
            $followUserData['user_id']     =   $friend_request_info[0]['my_id'];
            $followUserData['following_user_id']   =   $friend_request_info[0]['sender_id'];
            $followUserData['status_id']   =   1;
            $followUserData['created_at'] = gmdate('Y-m-d H:i:s')    ;
            $status = $this->getFriendRequestDetailTable()->followUser($followUserData);

            $followUserData['user_id']     =   $friend_request_info[0]['sender_id'];
            $followUserData['following_user_id']   =   $friend_request_info[0]['my_id'];
            $followUserData['status_id']   =   1;
            $followUserData['created_at'] = gmdate('Y-m-d H:i:s')    ;
            $status = $this->getFriendRequestDetailTable()->followUser($followUserData);

            //Insert two entries in feed table
            $this->getFeedMapper()->insertCustomFeedData('friends', $friend_id, $friend_request_info[0]['sender_id'], array('user_id2'=>$friendData['user_id']));
            //$this->getFeedMapper()->insertCustomFeedData('friends', $newFriendId, $friendData['user_id']);
            
            $user_dtails_info  = $this->getUserDetailTable()->getUserDetailsById($friend_info->user_id);
            $sendPushNotification = (!empty($user_dtails_info->push_notification)&& $user_dtails_info->push_notification=='Yes') ?true:false;

            //Begin Send IOS Push Notification
            if (!empty($friend_info->device_token) && $sendPushNotification) {
                $device_tokens = unserialize($friend_info->device_token); 
                $payload['alert'] = $logged_in_userinfo->username.' have accepted your friendship';
                $payload['sender_id'] = $logged_in_userinfo->guid;
                $payload['sender_user_name'] = $logged_in_userinfo->username;
                $payload['type'] = 'friend_request_accepted';
                $utilityObj->sendIOSPushnotification($device_tokens, $payload, 'friend_request_accepted');
            }
            //End Send IOS Push Notification
        }


        if ($friend_id > 0) {
            $this->table->update($apiData, array('id' => $friend_id));

            $friendRequestData['user_id'] = $friend_request_info[0]['my_id'];
            $friendRequestData['friend_id'] = $friend_id;
            $friendRequestData['created_at'] = gmdate('Y-m-d H:i:s')    ;
            $this->getFriendRequestDetailTable()->create($friendRequestData);
            
        }
        
        $response['friendRequest'] = array('status'=>'OK');
        return $response;

    }

    /**
    * Delete Friend request
    *
    * @param array $data
    * @return Entity
    */
    public function delete($data)
    {
        $resultSet = $this->table->select(array('id' => $data->id));
      
        if (0 === count($resultSet)) {
            throw new DomainException('Delete operation failed', 500);
        }
      
        $update_date['updated_date'] = gmdate('Y-m-d H:i:s')    ;
        $update_date['status_id'] = 4;
        $this->table->update($update_date, array('id' => $data->id));
        return true;
    }
}
