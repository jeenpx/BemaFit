<?php
namespace User\V1\Rest\FriendRequest;

class FriendRequestEntity
{
}
