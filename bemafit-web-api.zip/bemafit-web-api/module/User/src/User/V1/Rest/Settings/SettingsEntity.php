<?php
namespace User\V1\Rest\Settings;

class SettingsEntity
{
}
