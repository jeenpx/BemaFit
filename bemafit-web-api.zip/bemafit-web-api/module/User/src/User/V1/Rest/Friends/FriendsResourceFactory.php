<?php
namespace User\V1\Rest\Friends;

class FriendsResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('User\V1\Rest\Friends\FriendMapperTableGateway');
        return new FriendsResource($mapper);
    }
}
