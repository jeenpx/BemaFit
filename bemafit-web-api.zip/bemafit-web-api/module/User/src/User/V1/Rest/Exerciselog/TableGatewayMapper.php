<?php

namespace User\V1\Rest\Exerciselog;

use DomainException;

use Zend\Mvc\Controller\AbstractActionController;

use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController {
	/**
	 * @var TableGateway
	 */
	protected $table;

	/**
	 * @param TableGateway $table
	 */
	public function __construct(TableGateway $table) {
		$this->table = $table;
	}

	public function getFeedMapper() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('Feeds\V1\Rest\FeedMapperTableGateway');
		return $this->Table;
	}

	public function getExerciseTypeTable() {
		$sm                      = $this->getServiceLocator();
		$this->ExerciseTypeTable = $sm->get('Exercise\V1\Rest\ExerciseTypeMapperTableGateway');
		return $this->ExerciseTypeTable;
	}

	public function getUserTable() {
		$sm              = $this->getServiceLocator();
		$this->UserTable = $sm->get('User\V1\Rest\UserMapperTableGateway');
		return $this->UserTable;
	}

	public function getExerciseTable() {
		$sm                  = $this->getServiceLocator();
		$this->ExerciseTable = $sm->get('Exercise\V1\Rest\ExerciseMapperTableGateway');
		return $this->ExerciseTable;
	}

	public function getExerciselogDetailTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('User\Model\ExerciselogDetailTable');
		return $this->Table;
	}

	public function getFymUserDetailTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('User\Model\FymUserDetailTable');
		return $this->Table;
	}

	public function getAdapter() {
		$sm            = $this->getServiceLocator();
		$this->adapter = $sm->get('Db\Adapter\Adapter');
		return $this->adapter;
	}

	/**
	 * Create Exercise log
	 *
	 * @param array $data
	 * @return Entity
	 */
	public function create($data) {
		$utilityObj = new \Application\Service\Utility();
		$locale     = $utilityObj->getLocale(!empty($data->locale)?$data->locale:'en');
		$master_user_id = $data->user_id;
		$log_ids = array();

		$data->exercise_type = $this->getExerciseTypeTable()->fetchById($data->exercise_type);

		if (!$data->exercise_type) {
			return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Exercise Type');
		}

		foreach ($data->users as $user_data) {
			$user_data['user_id'] = @$this->getFymUserDetailTable()->getUserDetailsByGuid($user_data['user_id'])->id;

			if (!$this->getUserTable()->isActiveUser($user_data['user_id'])) {
				return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid User');
			}

			if (!empty($user_data['exercise_details'][0]['exercise_id'])) {
				if (!$this->getExerciseTable()->isValidExercise($user_data['exercise_details'][0]['exercise_id'])) {
					return \Application\Service\FymApiProblem::ApiProblem(422, 'This exercise is no longer available, please try another exercise.');
				}
			}

			if (empty($user_data['exercise_details'][0]['exercise_name']) or $user_data['exercise_details'][0]['exercise_name'] == '') {
				return \Application\Service\FymApiProblem::ApiProblem(422, 'Exercise Name required ');
			}

			if (empty($user_data['exercise_details'][0]['exercise_calorie_burned']) or $user_data['exercise_details'][0]['exercise_calorie_burned'] == '') {
				return \Application\Service\FymApiProblem::ApiProblem(422, 'Calorie burned required ');
			}
		}

		foreach ($data->users as $user_data) {

			$exerciseId = $user_data['exercise_details'][0]['exercise_id'];

			if (!empty($exerciseId)) {
				$exerciseDet = $this->getExerciseTable()->getExercise($exerciseId);
			}

			if ($locale == 'es') {
				$nameFld                  = 'exercise_name_es';
				$apiData['exercise_name'] = !empty($exerciseDet->name)?$exerciseDet->name:'';
			} else {
				$nameFld                     = 'exercise_name';
				$apiData['exercise_name_es'] = !empty($exerciseDet->name_es)?$exerciseDet->name_es:'';
			}

			$apiData['user_id']          = @$this->getFymUserDetailTable()->getUserDetailsByGuid($user_data['user_id'])->id;
			$apiData['exercise_type_id'] = $data->exercise_type;
			$apiData['exercise_id']      = $user_data['exercise_details'][0]['exercise_id'];
			$apiData[$nameFld]           = !empty($user_data['exercise_details'][0]['exercise_name'])?addslashes($user_data['exercise_details'][0]['exercise_name']):'';
			$apiData['calorie_burned']   = $user_data['exercise_details'][0]['exercise_calorie_burned'];
			$apiData['method']           = $data->log_type;
			$apiData['exercise_date']    = $data->exercise_date;
			$apiData['status_id']        = 1;
			$apiData['added_date']       = gmdate('Y-m-d H:i:s');
			$apiData['created_by']       = $data->user_id;
			$apiData['source_id']        = $data->source_id;

			$where = new \Zend\Db\Sql\Where();
			$where->equalTo('user_exercise_log.user_id', $apiData['user_id'])
						->equalTo('user_exercise_log.source_id', $apiData['source_id']);
						$select = $this->table->getSql()->select();
						$select->columns(array('id', 'user_id', 'source_id'))
	 					->where($where);
			$row = $this->table->selectWith($select)->toArray();

			if(0 == count($row)) {
				$this->table->insert($apiData);
				array_push($log_ids, $this->table->lastInsertValue);
				if(($master_user_id == $apiData['user_id']) && ($apiData['source_id'] == -1)) {
					$master_source_id = $this->table->lastInsertValue;
				}
			} else {
				$log_exists = true;
				$existing_log_id = $row[0]['id'];
				$this->table->update($apiData, array('id' => $existing_log_id));
			}

			if(!$log_exists) $this->getFeedMapper()->insertCustomFeedData('exercise', $this->table->lastInsertValue, $apiData['user_id']);

			if ($apiData['exercise_type_id'] == 1) {
				$insert_array = array('user_exercise_log_id' => $log_exists ? $existing_log_id : $this->table->lastInsertValue,
					'exercise_type_option_id'                   => 1,
					'value'                                     => $user_data['exercise_details'][0]['exercise_time'],
				);

				$log_exists ? $this->getExerciselogDetailTable()->update($insert_array, array('user_exercise_log_id' => $insert_array['user_exercise_log_id'], 'exercise_type_option_id' => $insert_array['exercise_type_option_id'])) : $this->getExerciselogDetailTable()->create($insert_array);

				$insert_array = array('user_exercise_log_id' => $log_exists ? $existing_log_id : $this->table->lastInsertValue,
					'exercise_type_option_id'                   => 2,
					'value'                                     => $user_data['exercise_details'][0]['exercise_calorie_burned'],
				);

				$log_exists ? $this->getExerciselogDetailTable()->update($insert_array, array('user_exercise_log_id' => $insert_array['user_exercise_log_id'], 'exercise_type_option_id' => $insert_array['exercise_type_option_id'])) : $this->getExerciselogDetailTable()->create($insert_array);

				$insert_array = array('user_exercise_log_id' => $log_exists ? $existing_log_id : $this->table->lastInsertValue,
					'exercise_type_option_id'                   => 3,
					'value'                                     => $user_data['exercise_details'][0]['exercise_distance'],
				);

				$log_exists ? $this->getExerciselogDetailTable()->update($insert_array, array('user_exercise_log_id' => $insert_array['user_exercise_log_id'], 'exercise_type_option_id' => $insert_array['exercise_type_option_id'])) : $this->getExerciselogDetailTable()->create($insert_array);

			} else if ($apiData['exercise_type_id'] == 2) {
				$insert_array = array('user_exercise_log_id' => $log_exists ? $existing_log_id : $this->table->lastInsertValue,
					'exercise_type_option_id'                   => 4,
					'value'                                     => $user_data['exercise_details'][0]['exercise_time'],
				);

				$log_exists ? $this->getExerciselogDetailTable()->update($insert_array, array('user_exercise_log_id' => $insert_array['user_exercise_log_id'], 'exercise_type_option_id' => $insert_array['exercise_type_option_id'])) : $this->getExerciselogDetailTable()->create($insert_array);

				$insert_array = array('user_exercise_log_id' => $log_exists ? $existing_log_id : $this->table->lastInsertValue,
					'exercise_type_option_id'                   => 5,
					'value'                                     => $user_data['exercise_details'][0]['exercise_calorie_burned'],
				);

				$log_exists ? $this->getExerciselogDetailTable()->update($insert_array, array('user_exercise_log_id' => $insert_array['user_exercise_log_id'], 'exercise_type_option_id' => $insert_array['exercise_type_option_id'])) : $this->getExerciselogDetailTable()->create($insert_array);

				$insert_array = array('user_exercise_log_id' => $log_exists ? $existing_log_id : $this->table->lastInsertValue,
					'exercise_type_option_id'                   => 6,
					'value'                                     => $user_data['exercise_details'][0]['exercise_sets'],
				);

				$log_exists ? $this->getExerciselogDetailTable()->update($insert_array, array('user_exercise_log_id' => $insert_array['user_exercise_log_id'], 'exercise_type_option_id' => $insert_array['exercise_type_option_id'])) : $this->getExerciselogDetailTable()->create($insert_array);

				$insert_array = array('user_exercise_log_id' => $log_exists ? $existing_log_id : $this->table->lastInsertValue,
					'exercise_type_option_id'                   => 7,
					'value'                                     => $user_data['exercise_details'][0]['exercise_sets_reps'],
				);

				$log_exists ? $this->getExerciselogDetailTable()->update($insert_array, array('user_exercise_log_id' => $insert_array['user_exercise_log_id'], 'exercise_type_option_id' => $insert_array['exercise_type_option_id'])) : $this->getExerciselogDetailTable()->create($insert_array);

			if(isSet($user_data['exercise_details'][0]['exercise_sets_reps_max'])) {
				$insert_array = array('user_exercise_log_id' => $log_exists ? $existing_log_id : $this->table->lastInsertValue,
					'exercise_type_option_id'                   => 9,
					'value'                                     => $user_data['exercise_details'][0]['exercise_sets_reps_max'],
				);

				$log_exists ? $this->getExerciselogDetailTable()->update($insert_array, array('user_exercise_log_id' => $insert_array['user_exercise_log_id'], 'exercise_type_option_id' => $insert_array['exercise_type_option_id'])) : $this->getExerciselogDetailTable()->create($insert_array);
			}

				$insert_array = array('user_exercise_log_id' => $log_exists ? $existing_log_id : $this->table->lastInsertValue,
					'exercise_type_option_id'                   => 8,
					'value'                                     => $user_data['exercise_details'][0]['exercise_weight_per_set'],
				);

				$log_exists ? $this->getExerciselogDetailTable()->update($insert_array, array('user_exercise_log_id' => $insert_array['user_exercise_log_id'], 'exercise_type_option_id' => $insert_array['exercise_type_option_id'])) : $this->getExerciselogDetailTable()->create($insert_array);
			}
		}

		if(isSet($master_source_id)) {
			foreach ($log_ids as $log_id) {
				$this->table->update(array('source_id' => $master_source_id), array('id' => $log_id));
			}
		}

		return array('status' => 'ok', 'code' => 200, 'method_name' => 'Exerciselog', 'method_type' => $data->log_type);
	}

	/**
	 * Fetch Exercise log
	 *
	 * @param int $id
	 * @return Entity
	 */
	public function fetch($id) {
		$resultSet = $this->table->select(array('id' => $id));
		if (0 === count($resultSet)) {
			throw new DomainException('Business not found', 404);
		}
		return $resultSet->current();
	}

	/**
	 * Fetch All Exercise log
	 *
	 * @param array $params
	 * @return Entity
	 */
	public function fetchAll($params) {
		$this->getAdapter();

		$utilityObj = new \Application\Service\Utility();
		$locale     = $utilityObj->getLocale(!empty($params['locale'])?$params['locale']:'en');

		if ($locale == 'es') {
			$nameFld  = 'name_es';
			$enameFld = 'IF((ISNULL(user_exercise_log.exercise_name_es) OR user_exercise_log.exercise_name_es=""),(IF((ISNULL(exercise.name_es) OR exercise.name_es=""),user_exercise_log.exercise_name,exercise.name_es)),user_exercise_log.exercise_name_es) ';
		} else {
			$nameFld  = 'name';
			$enameFld = 'IF((ISNULL(user_exercise_log.exercise_name) OR user_exercise_log.exercise_name=""),(IF((ISNULL(exercise.name) OR exercise.name=""),user_exercise_log.exercise_name_es,exercise.name)),user_exercise_log.exercise_name) ';

		}

		if (empty($params['limit'])) {
			$params['limit'] = (int) 10;
		}

		if (empty($params['offset'])) {
			$params['offset'] = 0;
		}

		$sql = "SELECT user_exercise_log.id,exercise_date,exercise_id,$enameFld as exercise_name,calorie_burned,exercise_type.id as type_id,exercise_type." .$nameFld." as type,method,source_id
        FROM user_exercise_log
        LEFT JOIN exercise ON exercise.id = user_exercise_log.exercise_id
        JOIN exercise_type ON exercise_type.id = user_exercise_log.exercise_type_id
        WHERE user_exercise_log.status_id =1 AND user_id =".$params['userId']." AND (exercise_date='".$params['date']."')
        ORDER BY user_exercise_log.id
        LIMIT ".$params['offset'].", ".$params['limit'];

		$statement = $this->adapter->createStatement($sql);

		$result = $statement->execute();
		$rows   = $result->getResource()->fetchAll(2);

		foreach ($rows as $key => $row) {
			$rows[$key]['exercise_name'] = !empty(($row['exercise_name']))?($row['exercise_name']):"";
			unset($rows[$key]['name']);
			unset($rows[$key]['name_es']);
			$exerciseDets                = $this->getExerciselogDetailTable()->fetch($row['id']);

			foreach ($exerciseDets as $exerciseDet) {
				$rows[$key]['details'][$exerciseDet['name']] = $exerciseDet['value'];
			}
		}

		return $rows;
	}

	/**
	 * Update Exercise log
	 *
	 * @param int $id
	 * @param array $data
	 * @param int $userId
	 * @return Entity
	 */
	public function update($id, $data, $userId) {
		$update['exercise_date'] = $data->exercise_date;
		$update['updated_date']  = gmdate('Y-m-d H:i:s');

		$this->table->update($update, array('id' => $id, 'user_id' => $userId));

		$resultSet = $this->table->select(array('id' => $id));
		if (0 === count($resultSet)) {
			throw new DomainException('Update operation failed or result in row deletion', 500);
		}
		return $resultSet->current();
	}

	/**
	 * Delete Exercise log
	 *
	 * @param array $data
	 * @return Entity
	 */
	public function delete($data) {
		$resultSet = $this->table->select(array('id' => $data->id, 'status_id' => 1, 'user_id' => $data->user_id));

		if (0 === count($resultSet)) {
			return \Application\Service\FymApiProblem::ApiProblem(500, 'Delete operation failed');
		}

		$update_date['updated_date'] = gmdate('Y-m-d H:i:s');
		$update_date['status_id']    = 4;
		$this->table->update($update_date, array('id' => $data->id));
		return true;
	}
}
