<?php
namespace User\V1\Rest\Foodlog;

use Zend\Paginator\Paginator;

class FoodlogCollection extends Paginator
{
}
