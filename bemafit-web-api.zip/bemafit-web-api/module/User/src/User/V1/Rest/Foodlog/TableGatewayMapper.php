<?php

namespace User\V1\Rest\FoodLog;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->UserTable = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->UserTable;
    }

    public function getMealTypeTable()
    {
        $sm = $this->getServiceLocator();
        $this->MealTypeTable = $sm->get('MealType\V1\Rest\MealTypeMapperTableGateway');
        return $this->MealTypeTable;
    }

    public function getMealTable()
    {
        $sm = $this->getServiceLocator();
        $this->MealTable = $sm->get('Meal\V1\Rest\MealMapperTableGateway');
        return $this->MealTable;
    }

    public function getFoodlogDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FoodlogDetailTable');
        return $this->Table;
    }

    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function getUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\UserDetailTable');
        return $this->Table;
    }

    public function getFeedMapper()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Feeds\V1\Rest\FeedMapperTableGateway');
        return $this->Table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    /**
    * Food Log
    *
    * @param array $data
    * @return Entity
    */
    public function create($data)
    {
        $this->getAdapter();
        if (!is_object($data)) {
            throw new InvalidArgumentException(sprintf('Invalid data provided to %s; must be an array or Traversable', __METHOD__));
        }

        $data->meal_type = $this->getMealTypeTable()->fetchById($data->meal_type);

        if (!$data->meal_type) {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Meal Type');
        }
        
        foreach ($data->users as $user_data) {
            //echo '$$$'.$user_data['user_id'].'$$$';
            $user_data['user_id'] = @$this->getFymUserDetailTable()->getUserDetailsByGuid($user_data['user_id'])->id;
            if (!$this->getUserTable()->isActiveUser($user_data['user_id'])) {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid User');
            }

            if ($data->log_type=='Log' and $data->user_id!=$user_data['user_id']) {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Log type should be Send or Share');
            }

            if (isset($user_data['food_details'][0]['food_id']) and $user_data['food_details'][0]['food_id']!='') {
                if (!$this->getMealTable()->isValidMealByGuid($user_data['food_details'][0]['food_id']) || is_numeric($user_data['food_details'][0]['food_id'])) {
                    return \Application\Service\FymApiProblem::ApiProblem(422, 'This food is no longer available, please try another food.');
                }
            }
        }

        $logged_in_userinfo =  $this->getFymUserDetailTable()->getUserDetailsById($data->user_id);

        foreach ($data->users as $user_data) {
            //print_r($user_data);
            $apiData['user_id']             =   @$this->getFymUserDetailTable()->getUserDetailsByGuid($user_data['user_id'])->id;
            
            if (isset($user_data['food_details'][0]['food_id']) and $user_data['food_details'][0]['food_id']!='') {
                $apiData['meal_id']             =   @$this->getMealTable()->getByGuid(!empty($user_data['food_details'][0]['food_id']) ?$user_data['food_details'][0]['food_id']:'1')->id;
            }
            
            if (!empty($user_data['food_details'][0]['food_meal_type'])) {
                $data->food_meal_type = $this->getMealTypeTable()->fetchById($user_data['food_details'][0]['food_meal_type']);
            } else {
                $data->food_meal_type = false;
            }
            //return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Meal Type');
    
            
            $apiData['approve']             =   $user_data['approve'];
            //$apiData['meal_id']           =   !empty($user_data['food_details'][0]['food_id']) ?$user_data['food_details'][0]['food_id']:'1';
            $apiData['meal_name']           =   !empty($user_data['food_details'][0]['food_name'])?addslashes(($user_data['food_details'][0]['food_name'])):'';
            $apiData['brand_name']          =   !empty($user_data['food_details'][0]['food_brand_name'])?$user_data['food_details'][0]['food_brand_name']:'';
            $apiData['meal_type_id']        =   !empty($data->food_meal_type)?$data->food_meal_type:$data->meal_type;
            $apiData['serving_size']        =   !empty($user_data['food_details'][0]['food_serving_size'])?$user_data['food_details'][0]['food_serving_size']:'';
            $apiData['number_of_serving']   =   !empty($user_data['food_details'][0]['food_serving_no'])?$user_data['food_details'][0]['food_serving_no']:'';
            $apiData['unit']                =   !empty($user_data['food_details'][0]['food_unit'])?$user_data['food_details'][0]['food_unit']:'';

            $apiData['meal_date']           =   $data->meal_date;
            $apiData['method']              =   $data->log_type;
            $apiData['status_id']           =   1;
            $apiData['created_by']          =   $data->user_id;
            $apiData['created_date']        =   gmdate('Y-m-d H:i:s')    ;

            $apiData['meal_calorie']        =   !empty($user_data['food_details'][0]['food_calorie'])?$user_data['food_details'][0]['food_calorie']:0;
            $apiData['meal_protein']        =   !empty($user_data['food_details'][0]['food_protein'])?$user_data['food_details'][0]['food_protein']:0;
            $apiData['meal_fibre']          =   !empty($user_data['food_details'][0]['food_fibre'])?$user_data['food_details'][0]['food_fibre']:0;
            $apiData['meal_fat']            =   !empty($user_data['food_details'][0]['food_fat'])?$user_data['food_details'][0]['food_fat']:0;
            $apiData['meal_carb']           =   !empty($user_data['food_details'][0]['food_carb'])?$user_data['food_details'][0]['food_carb']:0;

            $this->table->insert($apiData);

            $user_info = $this->getFymUserDetailTable()->getUserDetailsById($apiData['user_id']);

            $user_dtails_info  = $this->getUserDetailTable()->getUserDetailsById($apiData['user_id']);
            $sendPushNotification = (!empty($user_dtails_info->push_notification)&& $user_dtails_info->push_notification=='Yes') ?true:false;

            //Begin Send IOS Push Notification
            if (!empty($user_info->device_token) && $sendPushNotification) {
              $device_tokens = unserialize($user_info->device_token);
              $payload['alert'] = $logged_in_userinfo->username.' has split food with you';
              $payload['sender_id'] = $logged_in_userinfo->guid;
              $payload['sender_user_name'] = $logged_in_userinfo->username;
              $payload['type'] = 'split_food';
              $utilityObj = $this->getServiceLocator()->get('utility_service');
              $utilityObj->sendIOSPushnotification($device_tokens, $payload, 'split_food');
            }


            //$this->table->lastInsertValue
            //data for feed
            
            if ($user_data['approve']=='Yes' and $data->user_id==$apiData['user_id']) {
                $sql ="SELECT id,meal_date as date,SUM(meal_calorie) AS calories,SUM(meal_protein) AS protein,SUM(meal_fibre) AS fiber,SUM(meal_fat) AS fat,SUM(meal_carb) AS carbs
                FROM user_food_log
                WHERE status_id=1 AND approve='Yes' AND user_id=".$apiData['user_id']." AND meal_date='".$data->meal_date."' 
                GROUP BY meal_date ";
                
                $statement = $this->adapter->createStatement($sql);

                $result   = $statement->execute();
                $foodlog  = (object) $result->current();

                

                $userInfo = $this->getUserDetailTable()->getUserDetailsById($apiData['user_id']);

                $overValue = 10;
                $belowValue= 5;
               
              
                if (!$this->getFeedMapper()->checkFeedTrack(array('type'=>'goal', 'user_id'=>$apiData['user_id'], 'date'=>$data->meal_date))) {
                    if ($foodlog->protein>=($userInfo->protein-$belowValue) and $foodlog->protein<=($userInfo->protein+$overValue)) {
                        if ($foodlog->fat>=($userInfo->fat-$belowValue) and $foodlog->fat<=($userInfo->fat+$overValue)) {
                            if ($foodlog->carbs>=($userInfo->carbs-$belowValue) and $foodlog->carbs<=($userInfo->carbs+$overValue)) {
                                if ($foodlog->fiber>=($userInfo->fiber-$belowValue) and $foodlog->fiber<=($userInfo->fiber+$overValue)) {
                                    if ($foodlog->calories>=($userInfo->calories-$belowValue) and $foodlog->calories<=($userInfo->calories+$overValue)) {
                                       // $this->getFeedMapper()->insertCustomFeedData('goal', $this->table->lastInsertValue, $apiData['user_id'], $data->meal_date);
                                       $this->getFeedMapper()->insertCustomFeedData('goal', $this->table->lastInsertValue, $apiData['user_id'], array('goal_date'=>$data->meal_date));
                                       $this->getFeedMapper()->feedTrackInsert(array('type'=>'goal', 'user_id'=>$apiData['user_id'], 'date'=>$data->meal_date)); 
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (!empty($user_data['food_details'][0]['food_calorie'])) {
                //1
                $insert_array = array('user_food_log_id'=>$this->table->lastInsertValue,
                  'macro_id' => 1,
                  'value' => $user_data['food_details'][0]['food_calorie']
                );
                $this->getFoodlogDetailTable()->create($insert_array);
            }

            if (!empty($user_data['food_details'][0]['food_protein'])) {
                //12
                $insert_array = array('user_food_log_id'=>$this->table->lastInsertValue,
                  'macro_id' => 12,
                  'value' => $user_data['food_details'][0]['food_protein']
                );
                $this->getFoodlogDetailTable()->create($insert_array);
            }

            if (!empty($user_data['food_details'][0]['food_fibre'])) {
                //11
                $insert_array = array('user_food_log_id'=>$this->table->lastInsertValue,
                  'macro_id' => 11,
                  'value' => $user_data['food_details'][0]['food_fibre']
                );
                $this->getFoodlogDetailTable()->create($insert_array);
            }

            if (!empty($user_data['food_details'][0]['food_fat'])) {
                //2
                $insert_array = array('user_food_log_id'=>$this->table->lastInsertValue,
                  'macro_id' => 2,
                  'value' => $user_data['food_details'][0]['food_fat']
                );
                $this->getFoodlogDetailTable()->create($insert_array);
            }

            if (!empty($user_data['food_details'][0]['food_carb'])) {
                //10
                $insert_array = array('user_food_log_id'=>$this->table->lastInsertValue,
                  'macro_id' => 10,
                  'value' => $user_data['food_details'][0]['food_carb']
                );
                $this->getFoodlogDetailTable()->create($insert_array);
            }

            if (!empty($user_data['food_details'][0]['food_saturated'])) {
                //3
                $insert_array = array('user_food_log_id'=>$this->table->lastInsertValue,
                  'macro_id' => 3,
                  'value' => $user_data['food_details'][0]['food_saturated']
                );
                $this->getFoodlogDetailTable()->create($insert_array);
            }

            if (!empty($user_data['food_details'][0]['food_polyunsaturated'])) {
                //4
                $insert_array = array('user_food_log_id'=>$this->table->lastInsertValue,
                  'macro_id' => 4,
                  'value' => $user_data['food_details'][0]['food_polyunsaturated']
                );
                $this->getFoodlogDetailTable()->create($insert_array);
            }

            if (!empty($user_data['food_details'][0]['food_monosaturated'])) {
                //5
                $insert_array = array('user_food_log_id'=>$this->table->lastInsertValue,
                  'macro_id' => 5,
                  'value' => $user_data['food_details'][0]['food_monosaturated']
                );
                $this->getFoodlogDetailTable()->create($insert_array);
            }

            if (!empty($user_data['food_details'][0]['food_trans'])) {
                //6
                $insert_array = array('user_food_log_id'=>$this->table->lastInsertValue,
                  'macro_id' => 6,
                  'value' => $user_data['food_details'][0]['food_trans']
                );
                $this->getFoodlogDetailTable()->create($insert_array);
            }

            if (!empty($user_data['food_details'][0]['food_cholestrol'])) {
                //7
                $insert_array = array('user_food_log_id'=>$this->table->lastInsertValue,
                  'macro_id' => 7,
                  'value' => $user_data['food_details'][0]['food_cholestrol']
                );
                $this->getFoodlogDetailTable()->create($insert_array);
            }

            if (!empty($user_data['food_details'][0]['food_sodium'])) {
                //8
                $insert_array = array('user_food_log_id'=>$this->table->lastInsertValue,
                  'macro_id' => 8,
                  'value' => $user_data['food_details'][0]['food_sodium']
                );
                $this->getFoodlogDetailTable()->create($insert_array);
            }

            if (!empty($user_data['food_details'][0]['food_pottassium'])) {
                //9
                $insert_array = array('user_food_log_id'=>$this->table->lastInsertValue,
                  'macro_id' => 9,
                  'value' => $user_data['food_details'][0]['food_pottassium']
                );
                $this->getFoodlogDetailTable()->create($insert_array);
            }
        }
        return array('meta'=>array('status'=>'ok', 'code'=>200, 'method_name'=>'Food Log', 'method_type'=>$data->log_type),'log_id'=>$this->table->lastInsertValue);
    }

    /**
    * Fetch All Food Log
    *
    * @param array $params
    * @return Entity
    */
    public function fetchAll($params)
    {
        $this->getAdapter();

        $utilityObj = new \Application\Service\Utility();
        $locale     = $utilityObj->getLocale(!empty($params['locale'])?$params['locale']:'en');
        
        if ($locale=='es') {
            $nameFld = 'name_es';
        } else {
            $nameFld = 'name';
        }

        if (empty($params['limit'])) {
            $params['limit'] = (int)10;
        } else {
            $params['limit'] = (int)$params['limit'];
        }

        if (empty($params['offset'])) {
            $params['offset'] = 0;
        } else {
            $params['offset'] = (int)$params['offset'];
        }

        

        $sql ="SELECT id,meal_date as date,SUM(meal_calorie) AS calorie,SUM(meal_protein) AS protein,SUM(meal_fibre) AS fibre,SUM(meal_fat) AS fat,SUM(meal_carb) AS carb
        FROM user_food_log
        WHERE status_id=1 AND approve='Yes' AND user_id=".$params['userId']." AND meal_date='".$params['date']."' 
        GROUP BY meal_date ";
        
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        $foodlogs = $result->getResource()->fetch();

        $sql ="SELECT id,exercise_date AS date,SUM(calorie_burned) AS calorie_burned
        FROM user_exercise_log
        WHERE status_id =1 AND user_id =".$params['userId']." AND exercise_date='".$params['date']."'
        GROUP BY exercise_date";

        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        $exerciselogs = $result->getResource()->fetch();

        $data['macros']=array('calorie_achived'=>(string)($foodlogs['calorie']-$exerciselogs['calorie_burned']),
                            'protein_achived'=>!empty($foodlogs['protein'])? (string) $foodlogs['protein']:'0',
                            'fibre_achived'=>!empty($foodlogs['fibre'])? (string) $foodlogs['fibre']:'0',
                            'fat_achived'=>!empty($foodlogs['fat'])? (string) $foodlogs['fat']:'0',
                            'carb_achived'=> !empty($foodlogs['carb'])? (string) $foodlogs['carb']:'0',
                            );

        $where = new \Zend\Db\Sql\Where();
        $where->equalTo('user_food_log.status_id', 1)
            ->equalTo('user_food_log.user_id', $params['userId'])
            ->equalTo('user_food_log.meal_date', $params['date']);

        $select = $this->table->getSql()->select();
        $select->columns(array('id','log_date'=>'meal_date','food_id'=>'meal_id','food_name'=>'meal_name','number_of_serving','food_unit'=>'unit',
                        'food_calorie'=>'meal_calorie','food_protein'=>'meal_protein','food_fibre'=>'meal_fibre','food_fat'=>'meal_fat','food_carb'=>'meal_carb','approve','brand_name','serving_size','method'
            ))
           ->where($where)
           ->join(array('meal_type' => 'meal_type_master'), 'meal_type.id = user_food_log.meal_type_id', array('type'=>$nameFld), $select::JOIN_INNER);
        

        $select->limit($params['limit']);
        $select->offset($params['offset']);

        $row = $this->table->selectWith($select);

        $foodlogs = $row->toArray();
        //print_r($foodlogs);
       // die('---');

        foreach ($foodlogs as $key => $foodlog) {
            $foodlogs[$key]['food_id'] = !empty($foodlog['food_id'])?$foodlog['food_id']:"";
            $foodlogs[$key]['brand_name'] = !empty($foodlog['brand_name'])?stripslashes($foodlog['brand_name']):"";
            $foodlogs[$key]['serving_size'] = !empty($foodlog['serving_size'])?$foodlog['serving_size']:"";
            $foodlogs[$key]['food_unit'] = !empty($foodlog['food_unit'])?$foodlog['food_unit']:"";
            $foodlogs[$key]['food_name'] = !empty(($foodlog['food_name']))?stripslashes($foodlog['food_name']):"";

            $query = "SELECT nutrition_fact.name,user_food_log_nutrition_fact.value
            FROM user_food_log_nutrition_fact
            LEFT JOIN nutrition_fact ON nutrition_fact.id=user_food_log_nutrition_fact.macro_id
            WHERE user_food_log_id=".$foodlog['id'];

            $statement = $this->adapter->createStatement($query);

            $nutritionFactDet  = $statement->execute();
            $nutritionFacts = $nutritionFactDet->getResource()->fetchAll(2);

            foreach ($nutritionFacts as $nkey => $nutritionFact) {
                ///$data[$unit['name']]=$nutritionFact;
                $foodlogs[$key]['nutrition_facts'][$nutritionFact['name']]=!empty($nutritionFact['value'])?$nutritionFact['value']:'';
            }

        }

        $data['foodlog'] = $foodlogs;

        return $data;
    }

    /**
    * Update Food Log
    *
    * @param int $id
    * @param array $params
    * @param int $userId
    * @return Entity
    */
    public function update($id, $data, $userId)
    {
        if (!empty($data->meal_type)) {
            $update['meal_type_id']     = $this->getMealTypeTable()->fetchById($data->meal_type);
        }

        if (!empty($data->approve)) {
            $update['approve']     = $data->approve;

            if ($data->approve!='Yes' and $data->approve!='No' and $data->approve!='Deny') {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Approve Method');
            }
        }

        if (!empty($data->food_brand_name)) {
            $update['brand_name']     = $data->food_brand_name;
        }

        if (!empty($data->food_serving_size)) {
            $update['serving_size']     = $data->food_serving_size;
        }

        if (!empty($data->food_serving_no)) {
            $update['number_of_serving']     = $data->food_serving_no;
        }

        if (!empty($data->food_calorie)) {
            $update['meal_calorie']     = $data->food_calorie;
        }

        if (!empty($data->food_fibre)) {
            $update['meal_fibre']     = $data->food_fibre;
        }

        if (!empty($data->food_fat)) {
            $update['meal_fat']     = $data->food_fat;
        }

        if (!empty($data->food_carb)) {
            $update['meal_carb']     = $data->food_carb;
        }

        if (!empty($data->food_protein)) {
            $update['meal_protein']     = $data->food_protein;
        }

        if (!empty($data->food_unit)) {
            $update['unit']     = $data->food_unit;
        }

        if (!empty($data->food_name)) {
            $update['meal_name']     = $data->food_name;
        }

        if (!empty($data->food_id)) {
            if (!$this->getMealTable()->isValidMealByGuid($data->food_id) || is_numeric($data->food_id)) {
                    return \Application\Service\FymApiProblem::ApiProblem(422, 'This food is no longer available, please try another food.');
            }

            $data->food_id         =   @$this->getMealTable()->getByGuid(!empty($data->food_id) ?$data->food_id: $data->food_id)->id;
            $update['meal_id']     = $data->food_id;
        }

        $update['updated_date']    =    gmdate('Y-m-d H:i:s');
        $update['updated_by']      =    $userId;

        $this->table->update($update, array('id' => $id,'user_id'=>$userId));

        $resultSet = $this->table->select(array('id' => $id, 'user_id'=>$userId));

        if (0 === count($resultSet)) {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Sorry, cant update value, please check logged user.');
            //throw new DomainException('Update operation failed or result in row deletion', 500);
        } else {
            if (!empty($data->food_calorie)) {
                //1
                $update_array = array(
                  'value' => $data->food_calorie
                );
                $this->getFoodlogDetailTable()->update($update_array, array('user_food_log_id'=>$id, 'macro_id'=>1));
            }

            if (!empty($data->food_protein)) {
                //12
                $update_array = array(
                  'value' => $data->food_protein
                );
                $this->getFoodlogDetailTable()->update($update_array, array('user_food_log_id'=>$id, 'macro_id'=>12));
            }

            if (!empty($data->food_fibre)) {
                //11
                $update_array = array(
                  'value' => $data->food_fibre
                );
                $this->getFoodlogDetailTable()->update($update_array, array('user_food_log_id'=>$id, 'macro_id'=>11));
 
            }

            if (!empty($data->food_fat)) {
                //2
                $update_array = array(
                  'value' => $data->food_fat
                );
                $this->getFoodlogDetailTable()->update($update_array, array('user_food_log_id'=>$id, 'macro_id'=>2));

            }

            if (!empty($data->food_carb)) {
                //10
                $update_array = array(
                  'value' => $data->food_carb
                );
                $this->getFoodlogDetailTable()->update($update_array, array('user_food_log_id'=>$id, 'macro_id'=>10));

            }

            if (!empty($data->food_saturated)) {
                //3
                $update_array = array(
                  'value' => $data->food_saturated
                );
                $this->getFoodlogDetailTable()->update($update_array, array('user_food_log_id'=>$id, 'macro_id'=>3));

            }

            if (!empty($data->food_polyunsaturated)) {
                //4
                $update_array = array(
                  'value' => $data->food_polyunsaturated
                );
                $this->getFoodlogDetailTable()->update($update_array, array('user_food_log_id'=>$id, 'macro_id'=>4));
            }

            if (!empty($data->food_monosaturated)) {
                //5
                $update_array = array(
                  'value' => $data->food_monosaturated
                );
                $this->getFoodlogDetailTable()->update($update_array, array('user_food_log_id'=>$id, 'macro_id'=>5));
            }

            if (!empty($data->food_trans)) {
                //6
                $update_array = array(
                  'value' => $data->food_trans
                );
                $this->getFoodlogDetailTable()->update($update_array, array('user_food_log_id'=>$id, 'macro_id'=>6));
         
            }

            if (!empty($data->food_cholestrol)) {
                //7
                $update_array = array(
                  'value' => $data->food_cholestrol
                );
                $this->getFoodlogDetailTable()->update($update_array, array('user_food_log_id'=>$id, 'macro_id'=>7));
 
            }

            if (!empty($data->food_sodium)) {
                //8
                $update_array = array(
                  'value' => $data->food_sodium
                );
                $this->getFoodlogDetailTable()->update($update_array, array('user_food_log_id'=>$id, 'macro_id'=>8));
 
            }

            if (!empty($data->food_pottassium)) {
                //9
                $update_array = array(
                  'value' => $data->food_pottassium
                );
                $this->getFoodlogDetailTable()->update($update_array, array('user_food_log_id'=>$id, 'macro_id'=>9));
 
            }
        }
        $result = $resultSet->current();
        //print_r($result);
        $result->food_name = utf8_encode($result->meal_name);
        $result->brand_name = utf8_encode($result->brand_name);

        unset($result->meal_name);
        return $result;
    }

    /**
    * Delete Food Log
    *
    * @param array $data
    * @return Entity
    */
    public function delete($data)
    {
        $resultSet = $this->table->select(array('id' => $data->id,'status_id'=>1));

        if (0 === count($resultSet)) {
            return \Application\Service\FymApiProblem::ApiProblem(500, 'Invalid entry');
        }

        $update_date['updated_date'] = gmdate('Y-m-d H:i:s')    ;
        $update_date['status_id'] = 4;
        $this->table->update($update_date, array('id' => $data->id));
        return true;

       // $resultSet = $this->table->select(array('id' => $data->id));
    }
}
