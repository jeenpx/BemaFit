<?php
namespace User\V1\Rest\User;

class UserResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('User\V1\Rest\UserMapperTableGateway');
        return new UserResource($mapper);
        //return new UserResource();
    }
}
