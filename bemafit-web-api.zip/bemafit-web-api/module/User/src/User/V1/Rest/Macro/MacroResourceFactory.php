<?php
namespace User\V1\Rest\Macro;

class MacroResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('User\V1\Rest\MacroMapperTableGateway');
        return new MacroResource($mapper);
    }
}
