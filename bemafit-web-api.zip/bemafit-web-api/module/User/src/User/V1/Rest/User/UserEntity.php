<?php
namespace User\V1\Rest\User;

class UserEntity
{
    public $first_name;
    public $email;
    public $id;
    public $guid;

    public function getArrayCopy()
    {
        return array(
            'id'     => $this->id,
            'guid'     => $this->guid,
            'user' => array(
                           'id'     => $this->id,
                            'firstName'     => $this->first_name,
                            'email' => $this->email,
                            'username' => $this->username,
                            'guid'     => $this->guid,
                        )
        );
    }

    public function exchangeArray(array $array)
    {
        $this->firstName     = $array['firstName'];
        $this->email = $array['email'];
        $this->userName = $array['userName'];
        $this->guid = $array['guid'];
    }
}
