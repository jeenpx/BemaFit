<?php
namespace User\V1\Rest\Foodlog;

class FoodlogResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('User\V1\Rest\FoodlogMapperTableGateway');
        return new FoodlogResource($mapper);
    }
}
