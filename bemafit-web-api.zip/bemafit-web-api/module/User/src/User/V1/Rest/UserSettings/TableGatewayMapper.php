<?php

namespace User\V1\Rest\UserSettings;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use Zend\Validator\Db\NoRecordExists;
use ZF\ApiProblem\ApiProblem;
use Zend\Crypt\Password\Bcrypt;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    /**
    * User Setting
    *
    * @param array $data
    * @return Entity
    */
    public function create($data)
    {
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data->user_id);
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $userId = $user_info->id;

        if (empty($data->settings)) {
            return \Application\Service\FymApiProblem::ApiProblem(406, 'Settings required');
        }

        $settings = @json_decode($data->settings, true);

        $this->getAdapter();
        $query = "SELECT s.id AS setting_id
                    FROM settings s 
                    WHERE s.status_id=1
                    ";
        $statement = $this->adapter->createStatement($query, array($userId));

        $result = $statement->execute();
        $db_settings = $result->getResource()->fetchAll(2);
        if (sizeof($db_settings) > 0) {
            $db_settings_list = array();
            foreach ($db_settings as $db_setting) {
                $db_settings_list[$db_setting['setting_id']] = true;
            }
        }


        
        if (count($settings) > 0) {
            foreach ($settings as $setting) {
                if (!isset($db_settings_list[$setting['setting_id']])) {
                    continue;
                }

                $resultSet = $this->table->select(array('user_id' => $userId, 'setting_id'=>$setting['setting_id']));
                if (0 === count($resultSet)) {
                    $apiData['user_id']         =   $userId;
                    $apiData['setting_id']    =   $setting['setting_id'];
                    $apiData['value']    =   $setting['status'];
                    $apiData['created_at'] = gmdate('Y-m-d H:i:s')    ;

                    $this->table->insert($apiData);
                    $newId = $this->table->lastInsertValue;
                } else {
                    $updateData['value']    =   $setting['status'];
                    $updateData['updated_at'] = gmdate('Y-m-d H:i:s')    ;
                    $this->table->update($updateData, array('user_id' => $userId, 'setting_id'=>$setting['setting_id']));
                }
            }
        }
        return array(
              'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'updateUserSettings'),
              'update_settings'=>array('status'=>'OK'),
        );
    }

    /**
    * Get User Setting
    *
    * @param array $data
    * @return Entity
    */
    public function fetchAll($data)
    {
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data->user_id);
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $utilityObj = new \Application\Service\Utility();
        $locale     = $utilityObj->getLocale(!empty($data['locale'])?$data['locale']:'en');
        
        if ($locale=='es') {
            $nameFld = 'name_es';
        } else {
            $nameFld = 'name';
        }
        $userId = $user_info->id;

        $this->getAdapter();
        $query = "SELECT s.id AS setting_id, s.slug, s.$nameFld AS name, s.type, IF( us.value='Yes',us.value,'No') AS status, us.id AS user_settings_id
                    FROM settings s 
                    LEFT JOIN user_settings us ON s.id = us.setting_id AND us.user_id=? 
                    WHERE s.status_id=1
                    ";
        $statement = $this->adapter->createStatement($query, array($userId));

        $result = $statement->execute();
        $settings = $result->getResource()->fetchAll(2);
        $settings_list = array();
        foreach ($settings as $setting) {
            $settings_list[] = array ('setting_id'=> $setting['setting_id'], 'setting_slug'=> $setting['slug'], 'title'=> $setting['name'], 'type'=> $setting['type'] ,
                                      'status'=> $setting['status']);
        }
        $user_settings = array();
        $user_settings['meta'] = array('status'=>'OK', 'code'=>200, 'methodName' => 'getUserSettings');
        $user_settings['settings'] = $settings_list;

        
        return  $user_settings;
    }

    /**
     * @param string $id
     * @param array|Traversable|\stdClass $data
     * @return Entity
     */
    public function update($id, $data)
    {
       
    }

    /**
    * Insert Default Settings
    *
    * @param int $user_id
    * @return Entity
    */
    public function insertDefaultSettings($user_id)
    {
        $config = $this->getServiceLocator()->get('Config');
        $settings = explode(',', $config['defaultSettings']);

        $user_settings = array();
        $created_at = gmdate('Y-m-d H:i:s')    ;
        foreach ($settings as $setting_id) {
            $user_settings = array('user_id'=>$user_id, 'setting_id'=>$setting_id,
                                   'value'=>'Yes', 'created_at'=>$created_at );
            $this->table->insert($user_settings);
        }
    }

    public function insertDefaultWeightLog($data)
    {
        $adapter = $this->getAdapter();
        $userWeightTable = new \Zend\Db\TableGateway\TableGateway('user_weight_log', $adapter);
        $userWeightTable->insert($data);
       
    }
}
