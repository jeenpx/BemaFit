<?php
namespace User\V1\Rest\Progress;

class ProgressResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('User\V1\Rest\ProgressMapperTableGateway');
        return new ProgressResource($mapper);
    }
}
