<?php
namespace User\V1\Rest\Friends;

use Zend\Paginator\Paginator;

class FriendsCollection extends Paginator
{
}
