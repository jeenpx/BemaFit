<?php
namespace User\V1\Rest\Progress;

class ProgressEntity
{
}
