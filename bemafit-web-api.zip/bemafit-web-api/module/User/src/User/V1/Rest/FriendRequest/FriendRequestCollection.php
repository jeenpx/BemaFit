<?php
namespace User\V1\Rest\FriendRequest;

use Zend\Paginator\Paginator;

class FriendRequestCollection extends Paginator
{
}
