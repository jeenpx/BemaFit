<?php
namespace User\V1\Rest\Friends;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class FriendsResource extends AbstractResourceListener
{
    
    protected $mapper;
 
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }

    /**
     * Create a resource
     * Not using as per system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The POST method has not been defined');
    }

    /**
     * Delete a collection, or members of a collection
     * Not using as per system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The DELETE method has not been defined for collections');
    }

    /**
     * Fetch a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($id)
    {
        $filter['offset'] = $this->getEvent()->getRequest()->getQuery('offset', 0);
        $filter['limit'] = $this->getEvent()->getRequest()->getQuery('limit', 10);
        $filter['keyword'] = $this->getEvent()->getRequest()->getQuery('keyword', '');
        $filter['type'] = $this->getEvent()->getRequest()->getQuery('type', 'all');
        return $this->mapper->fetch($id, $filter);
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The GET method has not been defined for individual resources');
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($params = array())
    {
        return $this->mapper->fetchAll($params);
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The GET method has not been defined for collections');
    }

    /**
     * Patch (partial in-place update) a resource
     * Not using as per system requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PATCH method has not been defined for individual resources');
    }

    /**
     * Replace a collection or members of a collection
     * Not using as per system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     * Not using as per system requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for individual resources');
    }

    /**
     * Delete a resource
     *
     * @param  mixed $userId
     * @return ApiProblem|mixed
     */
    public function delete($userId)
    {
        $friendId = $this->getEvent()->getRouteMatch()->getParam('friend_id');
        return $this->mapper->delete($userId, $friendId);
        exit;
    }
}
