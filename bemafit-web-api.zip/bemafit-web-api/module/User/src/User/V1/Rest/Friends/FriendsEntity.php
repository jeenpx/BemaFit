<?php
namespace User\V1\Rest\Friends;

class FriendsEntity
{
    public $id;
    public $username;

    public function getArrayCopy()
    {
        return array(
            'id'        => $this->guid,
            'username'  => $this->username,
            'first_name'=> $this->first_name,
            'last_name' => $this->last_name,
            'following' => $this->following,
            'followers' => $this->followers,
        );
    }

    public function exchangeArray(array $array)
    {
        $this->guid         = $array['id'];
        $this->username     = $array['username'];
        $this->first_name   = $array['first_name'];
        $this->last_name    = $array['last_name'];
        
        $this->following    = $array['following'];
        $this->followers    = $array['followers'];
    }
}
