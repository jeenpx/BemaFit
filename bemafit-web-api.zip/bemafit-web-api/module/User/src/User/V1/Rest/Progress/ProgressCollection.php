<?php
namespace User\V1\Rest\Progress;

use Zend\Paginator\Paginator;

class ProgressCollection extends Paginator
{
}
