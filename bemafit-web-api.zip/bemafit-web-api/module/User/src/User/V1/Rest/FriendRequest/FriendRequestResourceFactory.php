<?php
namespace User\V1\Rest\FriendRequest;

class FriendRequestResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('User\V1\Rest\FriendRequestMapperTableGateway');
        return new FriendRequestResource($mapper);
    }
}
