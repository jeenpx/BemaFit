<?php
namespace User\V1\Rest\Weightlog;

use Zend\Paginator\Paginator;

class WeightlogCollection extends Paginator
{
}
