<?php
namespace User\V1\Rest\Settings;

use Zend\Paginator\Paginator;

class SettingsCollection extends Paginator
{
}
