<?php
namespace User\V1\Rest\User;

use Zend\Paginator\Paginator;

class UserCollection extends Paginator
{
}
