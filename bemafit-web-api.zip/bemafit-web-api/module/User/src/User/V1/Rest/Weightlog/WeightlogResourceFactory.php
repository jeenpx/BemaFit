<?php
namespace User\V1\Rest\Weightlog;

class WeightlogResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('User\V1\Rest\WeightlogMapperTableGateway');
        return new WeightlogResource($mapper);
    }
}
