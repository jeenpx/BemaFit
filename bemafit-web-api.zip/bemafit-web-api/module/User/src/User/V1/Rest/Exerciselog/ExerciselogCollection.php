<?php
namespace User\V1\Rest\Exerciselog;

use Zend\Paginator\Paginator;

class ExerciselogCollection extends Paginator
{
}
