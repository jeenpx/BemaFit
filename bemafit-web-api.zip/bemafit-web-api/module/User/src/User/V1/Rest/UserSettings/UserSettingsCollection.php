<?php
namespace User\V1\Rest\UserSettings;

use Zend\Paginator\Paginator;

class UserSettingsCollection extends Paginator
{
}
