<?php
namespace User\V1\Rest\FriendRequest;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class FriendRequestResource extends AbstractResourceListener
{
    protected $mapper;
 
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }

    /**
     * Create a resource
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        $data->currentUserId = $this->getIdentity()->getUserId();
        return $this->mapper->create($data);
    }

    /**
     * Update a resource
     *
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        $data->currentUserId = $this->getIdentity()->getUserId();
        return $this->mapper->update($id, $data);
    }
}
