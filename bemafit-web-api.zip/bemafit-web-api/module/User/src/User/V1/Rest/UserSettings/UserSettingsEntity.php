<?php
namespace User\V1\Rest\UserSettings;

class UserSettingsEntity
{
}
