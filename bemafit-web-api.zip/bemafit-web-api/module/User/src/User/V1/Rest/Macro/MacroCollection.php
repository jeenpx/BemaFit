<?php
namespace User\V1\Rest\Macro;

use Zend\Paginator\Paginator;

class MacroCollection extends Paginator
{
}
