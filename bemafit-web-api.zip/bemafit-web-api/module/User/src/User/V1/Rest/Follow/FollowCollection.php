<?php
namespace User\V1\Rest\Follow;

use Zend\Paginator\Paginator;

class FollowCollection extends Paginator
{
}
