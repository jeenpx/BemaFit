<?php
namespace User\V1\Rest\Macro;

class MacroEntity
{
}
