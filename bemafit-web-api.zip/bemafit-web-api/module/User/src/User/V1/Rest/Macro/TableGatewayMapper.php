<?php

namespace User\V1\Rest\Macro;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->UserTable = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->UserTable;
    }

    public function getUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\UserDetailTable');
        return $this->Table;
    }

    /**
     * @param array|Traversable|\stdClass $data
     * @return Entity
     */
    public function create($data)
    {
        return array('meta'=>array('status'=>'ok','code'=>200,'method_name'=>'FoodLod','method_type'=>$data->log_type));
    }
   
    /**
    * Fetch Macro
    *
    * @param array $params
    * @return Entity
    */
    public function fetchAll($params)
    {
        $startDate = $params['date'];
        $limit     = !empty($params['limit'])?$params['limit']:1;
        $endDate   = date('Y-m-d', strtotime($startDate . "+$limit days"));

        $user_info = $this->getUserDetailTable()->getUserDetailsById($params['userId']);
        $this->getAdapter();
        $sql ="SELECT meal_date as date,SUM(meal_calorie) AS calorie,SUM(meal_protein) AS protein,SUM(meal_fibre) AS fibre,SUM(meal_fat) AS fat,SUM(meal_carb) AS carb
        FROM user_food_log
        WHERE status_id=1 AND approve='Yes' AND user_id=".$params['userId']." AND (meal_date>='".$startDate."' AND  meal_date<='".$endDate."')
        GROUP BY meal_date ";
        
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        $foodlogs = $result->getResource()->fetchAll(2);

        $sql ="SELECT exercise_date AS date,SUM(calorie_burned) AS calorie_burned
        FROM user_exercise_log
        WHERE status_id =1 AND user_id =".$params['userId']." AND (exercise_date>='".$startDate."' AND  exercise_date<='".$endDate."')
        GROUP BY exercise_date";

        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        $exerciselogs = $result->getResource()->fetchAll(2);

        $j=0;
        // $tmp=array();
        // foreach ($exerciselogs as $exerciselog) {
        //     $tmp[$exerciselog['date']]=$exerciselog['calorie_burned'];
        // }
        // $exerciselogs=$tmp;
        //print_r($exerciselogs);

        ///////////////////////////////////////////////////////////////////tt
        $reports = array();
        for ($i=0; $i < $limit; $i++) {
            $currentDate = date('Y-m-d', strtotime($startDate . "+$i days"));
            $reports[$i] = array('date'=>$currentDate,
                                'protein_total'=>!empty($user_info->protein)?$user_info->protein:"0",
                                'fat_total'=>!empty($user_info->fat)?$user_info->fat:"0",
                                'carbs_total'=>!empty($user_info->carbs)?$user_info->carbs:"0",
                                'fiber_total'=>!empty($user_info->fiber)?$user_info->fiber:"0",
                                'calories_total'=>!empty($user_info->diet_goal_calories)?$user_info->diet_goal_calories:"0",
                                'calorie_achived' => "0",
                                'protein_achived' => "0",
                                'fibre_achived'   => "0",
                                'fat_achived'     => "0",
                                'carb_achived'    => "0",
                                );
            $k=0;
            foreach ($foodlogs as $foodlog) {
                if ($foodlog['date']==$currentDate) {
                    //echo $foodlog['date'].'=='.$currentDate;
                    $reports[$i]['calorie_achived'] = (string)($foodlogs[$k]['calorie']);
                    $reports[$i]['protein_achived'] = (string)$foodlogs[$k]['protein'];
                    $reports[$i]['fibre_achived']   = (string)$foodlogs[$k]['fibre'];
                    $reports[$i]['fat_achived']     = (string)$foodlogs[$k]['fat'];
                    $reports[$i]['carb_achived']    = (string)$foodlogs[$k]['carb'];
                } else {
                }
               
                $k++;
            }
            foreach ($exerciselogs as $exerciselog) {
                //print_r($exerciselog);
                //echo $currentDate;
                //echo (!empty($exerciselog['calorie_burned'])?$exerciselog['calorie_burned']:"0");
                if ($exerciselog['date']==$currentDate) {
                    $reports[$i]['calorie_achived'] = (string)($reports[$i]['calorie_achived'] - (!empty($exerciselog['calorie_burned'])?$exerciselog['calorie_burned']:"0"));
                }
            }
        }
        return $reports;
    }
}
