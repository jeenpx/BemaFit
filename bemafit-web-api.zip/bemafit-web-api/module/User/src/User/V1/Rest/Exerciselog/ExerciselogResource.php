<?php
namespace User\V1\Rest\Exerciselog;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class ExerciselogResource extends AbstractResourceListener
{
    protected $mapper;
 
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }

    /**
     * Create a resource
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        $data->user_id = $this->getIdentity()->getUserId();
        if(isset($data->user_ids)) {
          foreach ($data->user_ids as $user_id) {
            foreach ($data->exercise_details as $exercise_details) {
              $new_data = (array)$data;
              unset($new_data['user_ids']);
              unset($new_data['exercise_details']);
              $new_data['exercise_type'] = $exercise_details['exercise_type'];
              unset($exercise_details['exercise_type']);
              $new_data['users'] = array();
              $new_data['users'][0] = array('user_id' => $user_id, 'exercise_details' => array($exercise_details)
                                            );
              $resp = $this->mapper->create((object)$new_data);
            }
          }
        } else
        $this->mapper->create($data);
        return \Application\Service\FymApiResponse::FymApiResponse(array(
                             'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'Exercise Log'),
                       ));
    }

    /**
     * Delete a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function delete($id)
    {
        @$data->user_id =    $this->getIdentity()->getUserId();
        $data->id = $id;
        $this->mapper->delete($data);

        return \Application\Service\FymApiResponse::FymApiResponse(array(
                             'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'Log Delete'),
                       ));
    }

    /**
     * Delete a collection, or members of a collection
     * Not using as per current as per current system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The DELETE method has not been defined for collections');
    }

    /**
     * Fetch a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($id)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The GET method has not been defined for individual resources');
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($params = array())
    {
        $locale = $this->getEvent()->getRequest()->getQuery('locale');
        $exercise = $this->mapper->fetchAll(array('locale'=>$locale,'limit'=>$params['limit'],'offset'=>$params['offset'],'date'=>$params['date'],'userId'=>$this->getIdentity()->getUserId()));

        return array(
        'meta'=>array('status'=>'ok','code'=>200,'method_name'=>'get exercise'),'exercise'=>$exercise);
    }

    /**
     * Patch (partial in-place update) a resource
     *
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        $exercise = $this->mapper->update($id, $data, $this->getIdentity()->getUserId());

        if ($exercise) {
            return array(
            'meta'=>array('status'=>'ok','code'=>200,'method_name'=>'update exercise log',
            'exercise'=>$exercise));
        }
    }

    /**
     * Replace a collection or members of a collection
     * Not using as per current as per current system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     * Not using as per current as per current system requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for individual resources');
    }
}
