<?php

namespace User\V1\Rest\Progress;

use Zend\Mvc\Controller\AbstractActionController;

use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController {
	/**
	 * @var TableGateway
	 */
	protected $table;

	/**
	 * @param TableGateway $table
	 */
	public function __construct(TableGateway $table) {
		$this->table = $table;
	}

	public function getUserDetailTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('User\Model\UserDetailTable');
		return $this->Table;
	}

	public function getAdapter() {
		$sm            = $this->getServiceLocator();
		$this->adapter = $sm->get('Db\Adapter\Adapter');
		return $this->adapter;
	}

	/**
	 * Fetch Progress
	 *
	 * @param array $params
	 * @return Entity
	 */
	public function fetchAll($params) {

		$this->getAdapter();

		if (in_array($params->progress_type, array('Weight', 'Bodyfat', 'Macro', 'Exercise'))) {
			if (in_array($params->progress_date_type, array('Week', 'Month'))) {
				$week  = date("W", strtotime($params->progress_date));
				$month = date("m", strtotime($params->progress_date));
				$year  = date("Y", strtotime($params->progress_date));

				$sql = "SELECT body_fat,weight,date as log_date
                FROM user_weight_log
                WHERE status_id=1 AND user_id=".$params['userId']."
                ORDER BY log_date ASC LIMIT 1";
				$statement = $this->adapter->createStatement($sql);

				$result         = $statement->execute();
				$firstWeightlog = $result->getResource()->fetch(2);

				if (!$firstWeightlog) {
					$firstWeightlog = array('body_fat' => '', 'weight' => '', 'log_date' => '');
				}

				$sql = "SELECT body_fat,weight,date as log_date
                FROM user_weight_log
                WHERE status_id=1 AND user_id=".$params['userId']."
                ORDER BY log_date DESC LIMIT 1";
				$statement = $this->adapter->createStatement($sql);

				$result        = $statement->execute();
				$lastWeightlog = $result->getResource()->fetch(2);

				if (!$lastWeightlog) {
					$lastWeightlog = array('body_fat' => '', 'weight' => '', 'log_date' => '');
				}

				if ($params->progress_type == 'Weight' || $params->progress_type == 'Bodyfat') {
					if ($params->progress_date_type == 'Week') {
						$where = "AND WEEK(date,3)=".$week." AND YEAR(date)=".$year;
					} else if ($params->progress_date_type == 'Month') {
						$where = "AND MONTH(date)=".$month." AND YEAR(date)=".$year;
					} else {
						$where = "";
					}

					$sql = "SELECT body_fat,weight,date as log_date
                    FROM user_weight_log
                    WHERE status_id=1 AND user_id=".$params['userId']."  ".$where;

					$statement = $this->adapter->createStatement($sql);

					$result    = $statement->execute();
					$weightlog = $result->getResource()->fetchAll(2);

					$result = array('type' => $params->progress_type, 'first_entry' => $firstWeightlog, 'last_entry' => $lastWeightlog, 'report' => $weightlog);
					return $result;
				} else if ($params->progress_type == 'Exercise') {
					$sql = "SELECT exercise_date AS log_date,calorie_burned AS calorie,exercise_type.name as type, user_exercise_log.exercise_name as name,IF(user_exercise_log.exercise_type_id=1,ueld1.value,ueld2.value) AS amount
                    FROM user_exercise_log
                    JOIN exercise_type ON exercise_type.id = user_exercise_log.exercise_type_id
                    LEFT JOIN user_exercise_log_det ueld1 ON ueld1.user_exercise_log_id=user_exercise_log.id AND ueld1.exercise_type_option_id=1
                    LEFT JOIN user_exercise_log_det ueld2 ON ueld2.user_exercise_log_id=user_exercise_log.id AND ueld2.exercise_type_option_id=4
                    WHERE user_exercise_log.status_id =1 AND user_exercise_log.user_id =".$params['userId']."
                    ORDER BY user_exercise_log.exercise_date ASC
                    LIMIT 1";

					$statement = $this->adapter->createStatement($sql);

					$result           = $statement->execute();
					$firstExerciselog = $result->getResource()->fetch(2);

					if (!$firstExerciselog) {
						$firstExerciselog = array('log_date' => '', 'calorie' => '', 'type' => '', 'name' => '', 'amount' => '');
					}

					$sql = "SELECT exercise_date AS log_date,calorie_burned AS calorie,exercise_type.name as type, user_exercise_log.exercise_name as name,IF(user_exercise_log.exercise_type_id=1,ueld1.value,ueld2.value) AS amount
                    FROM user_exercise_log
                    JOIN exercise_type ON exercise_type.id = user_exercise_log.exercise_type_id
                    LEFT JOIN user_exercise_log_det ueld1 ON ueld1.user_exercise_log_id=user_exercise_log.id AND ueld1.exercise_type_option_id=1
                    LEFT JOIN user_exercise_log_det ueld2 ON ueld2.user_exercise_log_id=user_exercise_log.id AND ueld2.exercise_type_option_id=4
                    WHERE user_exercise_log.status_id =1 AND user_exercise_log.user_id =".$params['userId']."
                    ORDER BY user_exercise_log.exercise_date DESC
                    LIMIT 1";

					$statement = $this->adapter->createStatement($sql);

					$result          = $statement->execute();
					$lastExerciselog = $result->getResource()->fetch(2);

					if (!$lastExerciselog) {
						$lastExerciselog = array('log_date' => '', 'calorie' => '', 'type' => '', 'name' => '', 'amount' => '');
					}

					if ($params->progress_date_type == 'Week') {
						$where = " AND WEEK(exercise_date,3)=".$week." AND YEAR(exercise_date)=".$year;
					} else if ($params->progress_date_type == 'Month') {
						$where = " AND MONTH(exercise_date)=".$month." AND YEAR(exercise_date)=".$year;
					} else {
						$where = " ";
					}

					$sql = "SELECT exercise_date AS log_date,SUM(calorie_burned) AS calorie,exercise_type.name as type, user_exercise_log.exercise_name as name,IF(user_exercise_log.exercise_type_id=1,ueld1.value,ueld2.value) AS amount
                    FROM user_exercise_log
                    JOIN exercise_type ON exercise_type.id = user_exercise_log.exercise_type_id
                    LEFT JOIN user_exercise_log_det ueld1 ON ueld1.user_exercise_log_id=user_exercise_log.id AND ueld1.exercise_type_option_id=1
                    LEFT JOIN user_exercise_log_det ueld2 ON ueld2.user_exercise_log_id=user_exercise_log.id AND ueld2.exercise_type_option_id=4
                    WHERE user_exercise_log.status_id =1 AND user_exercise_log.user_id =".$params['userId'].$where."
                    GROUP BY exercise_date,exercise_type.id";

					$statement = $this->adapter->createStatement($sql);

					$result       = $statement->execute();
					$exerciselogs = $result->getResource()->fetchAll(2);

					$result = array('type' => $params->progress_type, 'first_entry' => $firstExerciselog, 'last_entry' => $lastExerciselog, 'report' => $exerciselogs);
					return $result;

				} else if ($params->progress_type == 'Macro') {
					$user_info = $this->getUserDetailTable()->getUserDetailsById($params['userId']);

					if ($params->progress_date_type == 'Week') {
						$where = " AND WEEK(meal_date,3)=".$week." AND YEAR(meal_date)=".$year;
					} else if ($params->progress_date_type == 'Month') {
						$where = " AND MONTH(meal_date)=".$month." AND YEAR(meal_date)=".$year;
					} else {
						$where = " ";
					}

					$sql = "SELECT meal_date as log_date,SUM(meal_calorie) AS calorie,SUM(meal_protein) AS protein,SUM(meal_fibre) AS fibre,SUM(meal_fat) AS fat,SUM(meal_carb) AS carb
                    FROM user_food_log
                    WHERE status_id=1 AND approve='Yes' AND user_id=".$params['userId'].$where."
                    GROUP BY meal_date ";

					$statement = $this->adapter->createStatement($sql);

					$result = $statement->execute();
					$macros = $result->getResource()->fetchAll(2);

					$sql = "SELECT SUM(meal_calorie) AS calorie,SUM(meal_protein) AS protein,SUM(meal_fibre) AS fibre,SUM(meal_fat) AS fat,SUM(meal_carb) AS carb
                    FROM user_food_log
                    WHERE status_id=1 AND approve='Yes' AND user_id=".$params['userId'].$where."
                    ";

					$statement = $this->adapter->createStatement($sql);

					$result      = $statement->execute();
					$consolidate = $result->getResource()->fetchAll(2);

					$required_per_day = array('protein_total' => $user_info->protein, 'fat_total' => $user_info->fat,
						'carbs_total'                            => $user_info->carbs, 'fiber_total'                            => $user_info->fiber,
						'calories_total'                         => $user_info->calories);

					if ($params->progress_date_type == 'Week') {
						$count = 7;
					} else if ($params->progress_date_type == 'Month') {
						$count = cal_days_in_month(CAL_GREGORIAN, $month, $year);
						// 31;
					} else {
						$count = 1;
					}

					$required_per_reporting_period = array('protein_total' => (string) ($user_info->protein*$count),
						'fat_total'                                           => (string) ($user_info->fat*$count),
						'carbs_total'                                         => (string) ($user_info->carbs*$count),
						'fiber_total'                                         => (string) ($user_info->fiber*$count),
						'calories_total'                                      => (string) ($user_info->calories*$count));

					$result = array('type' => $params->progress_type, 'report' => $macros, 'consolidate' => $consolidate, 'required_per_day' => $required_per_day, 'required_per_reporting_period' => $required_per_reporting_period);
					return $result;
				}

			} else {
				return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Date type');
			}
		} else {
			return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Progress type');
		}
	}
}
