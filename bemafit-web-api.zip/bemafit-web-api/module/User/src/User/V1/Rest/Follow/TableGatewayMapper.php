<?php

namespace User\V1\Rest\Follow;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }
    
    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function getFriendRequestDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FriendRequestDetailTable');
        return $this->Table;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    /**
    * Follow user
    *
    * @param array $data
    * @return Entity
    */
    public function create($data)
    {
        $user_id  = $data->user_id;
        $friendGuid = $data->friendGuid;

        if ($user_id == $friendGuid) {
            return \Application\Service\FymApiProblem::ApiProblem(408, 'You cannot follow yourself');
        }

        $friend_request_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($friendGuid);
        if (!$friend_request_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }

        $friendId = $friend_request_info->id;
        $current_user_info   = $this->getFymUserDetailTable()->getUserDetailsByGuid($user_id);
        $currentUserId       = $current_user_info->id;

        $follow_info = $this->getFriendRequestDetailTable()->getFollowUserDetails($currentUserId, $friendId);

        if ($follow_info) {
            return \Application\Service\FymApiProblem::ApiProblem(408, 'You are already following this user');
        }

        $apiData['user_id']     =   $currentUserId;
        $apiData['following_user_id']   =   $friendId;
        $apiData['status_id']   =   1;
        $apiData['created_at'] = gmdate('Y-m-d H:i:s')    ;

        $status = $this->getFriendRequestDetailTable()->followUser($apiData);

        return  array(
                  'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'followUser'),
                  'follow'=>
                        array('status'=>'OK'),
            );
    }
    

    /**
    * Get followers list
    *
    * @param array $data
    * @return Entity
    */
    public function fetchAll($data)
    {
        //var_dump($data);exit;
        $config = $this->getServiceLocator()->get('Config');
        $this->getAdapter();
        $user_id  = $data->user_id;
        $current_user_info   = $this->getFymUserDetailTable()->getUserDetailsByGuid($user_id);
        $currentUserId       = $current_user_info->id;
        $loggedInUserId      = $data['loggedInUserId'];
        if ($data->type!='followers' && $data->type!='following') {
            return \Application\Service\FymApiProblem::ApiProblem(406, 'Invalid type');
        }
       
        if ($data->type == 'followers') {
            $sql = "SELECT  SQL_CALC_FOUND_ROWS     u.guid AS user_id, u.username, u.first_name, u.last_name, u.type as user_type, u.profile_photo,
                    IF(ufme.id IS NULL,'No','Yes') AS follow_status
                      FROM user_follower uf 
                      JOIN user u ON uf.user_id=u.id
                      LEFT JOIN user_follower ufme ON uf.user_id=ufme.following_user_id AND ufme.user_id=? AND ufme.status_id=1
                      WHERE uf.following_user_id=? AND uf.status_id=1 AND u.status_id=1
                      ORDER BY u.first_name, u.last_name 
                      LIMIT ?,?";
            $statement = $this->adapter->createStatement($sql, array($loggedInUserId, $currentUserId, (int)  $data->offset, (int)  $data->limit));
        } else {
            $sql = "SELECT  SQL_CALC_FOUND_ROWS     u.guid AS user_id, u.username, u.first_name, u.type as user_type, u.last_name, u.profile_photo,
                    IF(ufme.id IS NULL,'No','Yes') AS follow_status
                      FROM user_follower uf 
                      JOIN user u ON uf.following_user_id=u.id
                      LEFT JOIN user_follower ufme ON uf.following_user_id=ufme.following_user_id AND ufme.user_id=? AND ufme.status_id=1
                      WHERE uf.user_id=? AND uf.status_id=1 AND u.status_id=1
                      ORDER BY u.first_name, u.last_name 
                      LIMIT ?,? ";
            $statement = $this->adapter->createStatement($sql, array($loggedInUserId, $currentUserId,  (int) $data->offset,  (int) $data->limit));
        }

        $result = $statement->execute();
        $users = $result->getResource()->fetchAll(2);
        $total_rows = $this->adapter->createStatement('SELECT FOUND_ROWS()  as total_rows')->execute()->getResource()->fetchAll()[0]['total_rows'];
        $user_list = array();
        foreach ($users as $user) {
            $preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
            $image_url = empty($user['profile_photo'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$user['profile_photo']);

            $user_list[] = array ('user_id'=> $user['user_id'], 'user_type'=>$user['user_type'], 'user_name'=> $user['username'], 'first_name'=> $user['first_name'], 
                'last_name'=> $user['last_name'], 'profile_photo'=> $image_url, 'follow_status'=>$user['follow_status']);
        }

        return array(
              'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'getFollowUsers'),
              'follow_list'=> $user_list,
              'total_users'=>$total_rows
        );
    }
    
    /**
    * Delete followers list
    *
    * @param array $data
    * @return Entity
    */
    public function deleteList($data)
    {
        $user_id  = $data['user_id'];
        $friendGuid = $data['friendGuid'];

        $friend_request_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($friendGuid);
        if (!$friend_request_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $friendId = $friend_request_info->id;

        $current_user_info   = $this->getFymUserDetailTable()->getUserDetailsByGuid($user_id);
        $currentUserId       = $current_user_info->id;

        $follow_info = $this->getFriendRequestDetailTable()->getFollowUserDetails($currentUserId, $friendId);

        if (!$follow_info) {
            return \Application\Service\FymApiProblem::ApiProblem(408, 'You are not following this user');
        }
        $status = $this->getFriendRequestDetailTable()->unFollowUser($currentUserId, $friendId);

        return \Application\Service\FymApiResponse::FymApiResponse(array(
                      'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'unFollow'),
                ));
    }
}
