<?php
namespace User\V1\Rest\Follow;

class FollowEntity
{
}
