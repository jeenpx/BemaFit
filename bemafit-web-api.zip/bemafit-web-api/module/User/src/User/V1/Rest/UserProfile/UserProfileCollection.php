<?php
namespace User\V1\Rest\UserProfile;

use Zend\Paginator\Paginator;

class UserProfileCollection extends Paginator
{
}
