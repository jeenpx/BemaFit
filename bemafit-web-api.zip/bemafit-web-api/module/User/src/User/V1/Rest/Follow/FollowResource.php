<?php
namespace User\V1\Rest\Follow;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class FollowResource extends AbstractResourceListener
{
    protected $mapper;
 
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }

    /**
     * Create a resource
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        $data->user_id  = $this->getEvent()->getRouteMatch()->getParam('user_id');
        $data->friendGuid = $this->getEvent()->getRouteMatch()->getParam('friend_id');
        return $this->mapper->create($data);
    }

    /**
     * Delete a resource
     * Not using as per system requirement
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function delete($id)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The DELETE method has not been defined for individual resources');
    }

    /**
     * Delete a collection, or members of a collection
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        $data['user_id']  = $this->getEvent()->getRouteMatch()->getParam('user_id');
        $data['friendGuid'] = $this->getEvent()->getRouteMatch()->getParam('friend_id');
        return $this->mapper->deleteList($data);
    }

    /**
     * Fetch a resource
     * Not using as per system requirement
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($id)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The GET method has not been defined for individual resources');
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($params = array())
    {
        $params['offset'] = $this->getEvent()->getRequest()->getQuery('offset', 0);
        $params['limit'] = $this->getEvent()->getRequest()->getQuery('limit', 10);
        $params['type'] = $this->getEvent()->getRequest()->getQuery('type', '');
        $params['user_id'] = $this->getEvent()->getRouteMatch()->getParam('user_id');
        $params['loggedInUserId'] = $this->getIdentity()->getUserId();
        return $this->mapper->fetchAll($params);
    }

    /**
     * Patch (partial in-place update) a resource
     * Not using as per system requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PATCH method has not been defined for individual resources');
    }

    /**
     * Replace a collection or members of a collection
     * Not using as per system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     * Not using as per system requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for individual resources');
    }
}
