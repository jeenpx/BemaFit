<?php
namespace User\V1\Rest\UserProfile;

class UserProfileEntity
{
    public $user_info;

    public function getArrayCopy()
    {
        return array(
            'id'     => $this->id,
            'user_info' => $this->user_info
        );
    }

    public function exchangeArray(array $array)
    {
        $this->user_info     = $array['user_info'];
    }
}
