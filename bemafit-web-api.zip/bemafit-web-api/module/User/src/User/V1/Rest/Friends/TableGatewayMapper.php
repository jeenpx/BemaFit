<?php

namespace User\V1\Rest\Friends;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use Zend\Validator\Db\NoRecordExists;
use ZF\ApiProblem\ApiProblem;
use Zend\Crypt\Password\Bcrypt;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function getFriendRequestDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FriendRequestDetailTable');
        return $this->Table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    /**
    * Fetch friends
    *
    * @param string $userGuId
    * @param array $filter
    * @return Entity
    */
    public function fetch($userGuId, $filter)
    {
        $config = $this->getServiceLocator()->get('Config');
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($userGuId);
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $type = $filter['type'];
        $userId = $user_info->id;
        $this->getAdapter();
        $where_arr = array($userId,$userId);
        $subQuery = '';

        if ($filter['keyword']!='') {
            $subQuery = "AND ( IF(f.status_id=3,  ufr.first_name LIKE ? ,  u.first_name LIKE ? ) OR 
                               IF(f.status_id=3,  ufr.last_name LIKE ? ,  u.last_name LIKE ? )  OR 
                               IF(f.status_id=3,  ufr.username LIKE ? ,  u.username LIKE ? ) 
                               ) ";
            //array_push($where_arr, '');
            array_push($where_arr, '%'.$filter['keyword'].'%', '%'.$filter['keyword'].'%', '%'.$filter['keyword'].'%', '%'.$filter['keyword'].'%','%'.$filter['keyword'].'%', '%'.$filter['keyword'].'%');
        }

        if ($type == 'friends') {
            $subQuery.= " AND f.status_id=1";
        }

        $sql = "SELECT SQL_CALC_FOUND_ROWS  DISTINCT  u.guid AS user_id, u.username,  u.first_name, u.last_name, u.profile_photo, 
                     f.status_id AS `type`, ufr.guid AS fr_guid, ufr.username AS fr_username,  ufr.first_name AS fr_first_name, ufr.last_name AS fr_last_name, ufr.profile_photo AS fr_profile_photo,
                COUNT(DISTINCT usr_following.id) following ,COUNT(DISTINCT usr_followers.id) followers,  COUNT(DISTINCT ufr_ufollowing.id) fr_following ,COUNT(DISTINCT ufr_ufollowers.id) fr_followers
                FROM friends f 
                JOIN user u ON f.friend_id=u.id
                LEFT JOIN user_follower ufollowers ON u.id= ufollowers.following_user_id AND ufollowers.status_id=1 
                LEFT JOIN user_follower ufollowing ON u.id= ufollowing.user_id AND ufollowing.status_id=1
                LEFT JOIN `user` ufr ON ufr.id=f.user_id
                LEFT JOIN user_follower ufr_ufollowers ON f.user_id= ufr_ufollowers.following_user_id AND ufr_ufollowers.status_id=1 
                LEFT JOIN user_follower ufr_ufollowing ON f.user_id= ufr_ufollowing.user_id AND ufr_ufollowing.status_id=1
                LEFT JOIN `user` usr_followers ON ufollowers.user_id=usr_followers.id  AND usr_followers.status_id=1
                LEFT JOIN `user` usr_following ON ufollowing.following_user_id=usr_following.id AND usr_following.status_id=1
                WHERE ((f.user_id= ? AND f.status_id=1) OR  (f.friend_id=? AND f.status_id=3)) AND ufr.status_id=1  AND u.status_id=1 
                
                AND IF(f.status_id=1, u.id<>$userId,1)  $subQuery 
                GROUP BY f.id
                ORDER BY IF(f.status_id=3, ufr.username,u.username) 
                LIMIT ".$filter['offset']." , ".$filter['limit'];
        
        $statement = $this->adapter->createStatement($sql, $where_arr);

        $result = $statement->execute();
        $friends = $result->getResource()->fetchAll(2);
        $friend_list = array();
        $preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
        
        foreach ($friends as $friend) {
            
            if ($friend['type'] == 3) {
                $image_url = empty($friend['fr_profile_photo'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$friend['fr_profile_photo']);
                $friend_list[] = array ('type'=>'FriendRequest', 'user_id'=> $friend['fr_guid'], 'username'=> $friend['fr_username'], 'first_name'=> $friend['fr_first_name'], 'last_name'=> $friend['fr_last_name'] ,
                                    'following'=> $friend['fr_following'] , 'followers'=> $friend['fr_followers'], 'profile_photo'=> $image_url);
            } else {
                $image_url = empty($friend['profile_photo'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$friend['profile_photo']);
                $friend_list[] = array ('type'=>'Friend', 'user_id'=> $friend['user_id'], 'username'=> $friend['username'], 'first_name'=> $friend['first_name'], 'last_name'=> $friend['last_name'] ,
                                    'following'=> $friend['following'] , 'followers'=> $friend['followers'], 'profile_photo'=> $image_url);
            }
            
        }

        $total_rows = $this->adapter->createStatement('SELECT FOUND_ROWS()  as total_rows')->execute()->getResource()->fetchAll()[0]['total_rows'];

        $sql = "SELECT COUNT(id) AS total_friends FROM friends WHERE user_id=? AND friend_id<>$userId AND status_id=1";
        //die($sql);
        $statement = $this->adapter->createStatement($sql, array($userId));
        $total_friends = $statement->execute()->getResource()->fetchAll()[0]['total_friends'];
        return array(
                      'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'getFriends'),
                      'friends'=>$friend_list,
                      'total_items'=>$total_rows,
                      'total_friends'=>$total_friends
                );
    }

    /**
     * @return Collection
     */
    public function fetchAll()
    {
        return new FriendsCollection(new DbTableGateway($this->table, null, array('created_at' => 'DESC')));
    }

    /**
    * Update friends
    *
    * @param int $id
    * @param array $data
    * @return Entity
    */
    public function update($id, $data)
    {
        if (is_object($data)) {
            $data = (array) $data;
        }

        if (! isset($data['updated_date'])) {
            $data['updated_date'] = gmdate('Y-m-d H:i:s')    ;
        }

        $this->table->update($data, array('id' => $id));

        $resultSet = $this->table->select(array('id' => $id));
        if (0 === count($resultSet)) {
            throw new DomainException('Update operation failed or result in row deletion', 500);
        }
        return $resultSet->current();
    }

    /**
    * Delete friends
    *
    * @param int $user_id
    * @param int $friend_id
    * @return Entity
    */
    public function delete($user_id, $friend_id)
    {
        $friend_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($friend_id);
        if (!$friend_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'Friend not found');
        }
        $friendId        =   $friend_info->id;
        
        
        $current_user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($user_id);
        if (!$current_user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }

        $currentUserId   =   $current_user_info->id;

        $friend_info     =    $this->table->select(array('user_id' => $currentUserId, 'friend_id' => $friendId, 'status_id' => 1))->current();

        if (!$friend_info) {
            return \Application\Service\FymApiProblem::ApiProblem(406, 'You are not friends');
        }

        $date_time = gmdate('Y-m-d H:i:s')    ;

        $this->table->update(array('status_id'=>4, 'updated_at'=>$date_time), array('user_id' => $currentUserId, 'friend_id' => $friendId));
        $this->table->update(array('status_id'=>4, 'updated_at'=>$date_time), array('user_id' => $friendId, 'friend_id' => $currentUserId));

        $friendRequestData['status_id']   =   4;
        $friendRequestData['user_id'] = $currentUserId;
        $friendRequestData['friend_id'] = $friend_info->id;
        $friendRequestData['created_at'] = date($date_time);
        $status = $this->getFriendRequestDetailTable()->create($friendRequestData);

        $this->getFriendRequestDetailTable()->unFollowUser($currentUserId, $friendId);
        $this->getFriendRequestDetailTable()->unFollowUser($friendId, $currentUserId);
        return \Application\Service\FymApiResponse::FymApiResponse(array(
                      'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'deleteFriend'),
                ));
    }
}
