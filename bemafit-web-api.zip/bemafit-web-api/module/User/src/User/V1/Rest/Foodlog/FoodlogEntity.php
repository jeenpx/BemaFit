<?php
namespace User\V1\Rest\Foodlog;

class FoodlogEntity
{
}
