<?php
namespace User\V1\Rest\Exerciselog;

class ExerciselogEntity
{
}
