<?php
namespace User;

use ZF\Apigility\Provider\ApigilityProviderInterface;
use ZF\MvcAuth\Authentication\DefaultAuthenticationListener;
use Zend\Mvc\MvcEvent;
use ZF\MvcAuth\MvcAuthEvent;
use User\V1\Model\UserDetail;
use User\V1\Model\UserDetailTable;
use User\V1\Model\ExerciselogDetail;
use User\V1\Model\ExerciselogDetailTable;

use User\V1\Model\FoodlogDetail;
use User\V1\Model\FoodlogDetailTable;

use User\V1\Model\FriendRequestDetail;
use User\V1\Model\FriendRequestDetailTable;
use User\V1\Model\FymUserDetail;
use User\V1\Model\FymUserDetailTable;

use User\V1\Model\InviteUserDetail;
use User\V1\Model\InviteUserDetailTable;

use Zend\ModuleManager\Feature\AutoloaderProviderInterface;
use Zend\ModuleManager\Feature\ConfigProviderInterface;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;

class Module implements ApigilityProviderInterface
{
    public function getConfig()
    {
        return include __DIR__ . '/../../config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'ZF\Apigility\Autoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__,
                ),
            ),
        );
    }

    public function onBootstrap(MvcEvent $mvcEvent)
    {
        $app      = $mvcEvent->getApplication();
        $events   = $app->getEventManager();
        $this->services = $app->getServiceManager();

        $events->attach(MvcAuthEvent::EVENT_AUTHENTICATION_POST, $this->services->get('User\MvcAuth\Authentication\AuthenticationPost'), 1000);
        $events->attach(MvcAuthEvent::EVENT_AUTHORIZATION, $this->services->get('User\MvcAuth\Authorization\AuthorizationListener'), 100);

         $sm = $mvcEvent->getApplication()->getServiceManager();
         $adapter = $sm->get('Db\Adapter\Adapter');
         \Zend\Db\TableGateway\Feature\GlobalAdapterFeature::setStaticAdapter($adapter);
    }

    public function getServiceConfig()
    {
        return array(
            'invokables' => array(
                'User\MvcAuth\Authorization\AuthorizationListener' => 'User\MvcAuth\Authorization\AuthorizationListener',
                'User\MvcAuth\Authentication\AuthenticationPost' => 'User\MvcAuth\Authentication\AuthenticationPost',
            ),
            'factories' => array(
                'User\OAuth2\Adapter\PdoAdapter' => function ($serviceManager) {
                    $config = $serviceManager->get('Config');
                    if (!isset($config['zf-oauth2']['db']) || empty($config['zf-oauth2']['db'])) {
                        throw new \ZF\OAuth2\Adapter\Exception\RuntimeException(
                            'The database configuration [\'zf-oauth2\'][\'db\'] for OAuth2 is missing'
                        );
                    }

                    $username = isset($config['zf-oauth2']['db']['username']) ? $config['zf-oauth2']['db']['username'] : null;
                    $password = isset($config['zf-oauth2']['db']['password']) ? $config['zf-oauth2']['db']['password'] : null;
                    $options  = isset($config['zf-oauth2']['db']['options']) ? $config['zf-oauth2']['db']['options'] : array();

                    $oauth2ServerConfig = array();
                    if (isset($config['zf-oauth2']['storage_settings']) && is_array($config['zf-oauth2']['storage_settings'])) {
                        $oauth2ServerConfig = $config['zf-oauth2']['storage_settings'];
                    }

                    return new OAuth2\Adapter\PdoAdapter(array(
                        'dsn'      => $config['zf-oauth2']['db']['dsn'],
                        'username' => $username,
                        'password' => $password,
                        'options'  => $options,
                    ), $oauth2ServerConfig);
                },
                'User\V1\Rest\UserMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\User\UserMapper($adapter);
                },
                'User\V1\Rest\UserMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\User\TableGateway('user', $adapter);
                    return new V1\Rest\User\TableGatewayMapper($tableGateway);
                },
                'User\V1\Rest\FriendRequestMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\FriendRequest\FriendRequestMapper($adapter);
                },
                'User\V1\Rest\FriendRequestMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\FriendRequest\TableGateway('friends', $adapter);
                    return new V1\Rest\FriendRequest\TableGatewayMapper($tableGateway);
                },
                'User\Model\FriendRequestDetailTable' =>  function ($sm) {
                     $tableGateway = $sm->get('FriendRequestDetailTableGateway');
                     $table = new FriendRequestDetailTable($tableGateway);
                     return $table;
                },
                'FriendRequestDetailTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new FriendRequestDetail());
                     return new TableGateway('friend_request', $dbAdapter, null, $resultSetPrototype);
                },
                'User\V1\Rest\UserProfileMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\User\UserMapper($adapter);
                },
                'User\V1\Rest\UserProfileMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\UserProfile\TableGateway('user', $adapter);
                    return new V1\Rest\UserProfile\TableGatewayMapper($tableGateway);
                },
                'User\Model\UserDetailTable' =>  function ($sm) {
                     $tableGateway = $sm->get('UserDetailTableGateway');
                     $table = new UserDetailTable($tableGateway);
                     return $table;
                },
                'UserDetailTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new UserDetail());
                     return new TableGateway('user_details', $dbAdapter, null, $resultSetPrototype);
                },
                'User\Model\FymUserDetailTable' =>  function ($sm) {
                     $tableGateway = $sm->get('FymUserDetailTableGateway');
                     $table = new FymUserDetailTable($tableGateway);
                     return $table;
                },
                'FymUserDetailTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new FymUserDetail());
                    return new TableGateway('user', $dbAdapter, null, $resultSetPrototype);
                },
                'User\Model\InviteUserTable' =>  function ($sm) {
                    $tableGateway = $sm->get('InviteUserTableGateway');
                    $table = new InviteUserDetailTable($tableGateway);
                    return $table;
                },
                'InviteUserTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new InviteUserDetail());
                    return new TableGateway('invite_user', $dbAdapter, null, $resultSetPrototype);
                },
                'User\Model\ExerciselogDetailTable' =>  function ($sm) {
                    $tableGateway = $sm->get('ExerciselogDetailTableGateway');
                    $table = new ExerciselogDetailTable($tableGateway);
                    return $table;
                },
                'ExerciselogDetailTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new ExerciselogDetail());
                    return new TableGateway('user_exercise_log_det', $dbAdapter, null, $resultSetPrototype);
                },
                'User\Model\FoodlogDetailTable' =>  function ($sm) {
                    $tableGateway = $sm->get('FoodlogDetailTableGateway');
                    $table = new FoodlogDetailTable($tableGateway);
                    return $table;
                },
                'FoodlogDetailTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new FoodlogDetail());
                    return new TableGateway('user_food_log_nutrition_fact', $dbAdapter, null, $resultSetPrototype);
                },
                'User\V1\Rest\ProgressMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\Progress\ProgressMapper($adapter);
                },
                'User\V1\Rest\ProgressMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Progress\TableGateway('user_weight_log', $adapter);
                    return new V1\Rest\Progress\TableGatewayMapper($tableGateway);
                },
                'User\V1\Rest\FoodlogMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\Foodlog\FoodLogMapper($adapter);
                },
                'User\V1\Rest\FoodlogMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Foodlog\TableGateway('user_food_log', $adapter);
                    return new V1\Rest\Foodlog\TableGatewayMapper($tableGateway);
                },
                'User\V1\Rest\ExerciselogMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\Exerciselog\ExerciselogMapper($adapter);
                },
                'User\V1\Rest\ExerciselogMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Exerciselog\TableGateway('user_exercise_log', $adapter);
                    return new V1\Rest\Exerciselog\TableGatewayMapper($tableGateway);
                },
                'User\V1\Rest\WeightlogMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\Weightlog\WeightlogMapper($adapter);
                },
                'User\V1\Rest\WeightlogMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Weightlog\TableGateway('user_weight_log', $adapter);
                    return new V1\Rest\Weightlog\TableGatewayMapper($tableGateway);
                },
                'User\V1\Rest\Friends\FriendMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\Friends\BusinessMapper($adapter);
                },
                'User\V1\Rest\Friends\FriendMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Friends\TableGateway('friends', $adapter);
                    return new V1\Rest\Friends\TableGatewayMapper($tableGateway);
                },
                'User\V1\Rest\UserSettings\UserSettingsMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\UserSettings\TableGateway('user_settings', $adapter);
                    return new V1\Rest\UserSettings\TableGatewayMapper($tableGateway);
                },
                'User\V1\Rest\MacroMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\Macro\MacroMapper($adapter);
                },
                'User\V1\Rest\MacroMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Macro\TableGateway('user_exercise_log', $adapter);
                    return new V1\Rest\Macro\TableGatewayMapper($tableGateway);
                },
                'User\V1\Rest\FollowMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Follow\TableGateway('user_follower', $adapter);
                    return new V1\Rest\Follow\TableGatewayMapper($tableGateway);
                },
            )
        );
    }
}
