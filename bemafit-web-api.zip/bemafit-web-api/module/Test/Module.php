<?php
require __DIR__ . '/src/Test/Module.php';
