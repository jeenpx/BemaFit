<?php
namespace Test\V1\Rest\TestApi;

class TestApiResourceFactory
{
    public function __invoke($services)
    {
        return new TestApiResource();
    }
}
