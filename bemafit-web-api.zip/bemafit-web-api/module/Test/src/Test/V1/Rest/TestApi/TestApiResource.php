<?php
namespace Test\V1\Rest\TestApi;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;
use Aws\Ses\SesClient;
use Aws\S3\S3Client;

class TestApiResource extends AbstractResourceListener
{
    /**
     * Create a resource
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {

       
        $utilityObj = $this->getServiceLocator()->get('utility_service');
       // var_dump($_POST);
        $utilityObj->sendIOSPushnotification(array($_POST['device_token']), $_POST, 'message_sent');
        exit;
      // $config = $this->getServiceLocator()->get('Config');
      // $ses_client = SesClient::factory($config['amazon_ses']);
       $client = S3Client::factory(array(
            'key' => 'AKIAI6BKMDRJ7HAUXGBQ',
            'secret' => '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',
            'region' => 'us-east-1',
        ));

        $url = 'fymprofile/1b02e25e5ec6005d8208cd24a8e83ae8.jpeg';
        $request = $client->get($url);
        $signedUrl = $client->createPresignedUrl($request, '+1 year');
        
        echo  $signedUrl.'<br/>';
                
        $url = 'fymprofilethumbs/profile200/cc53e458d88a2d433bb06e7ecd456fdc.jpeg';
        $request = $client->get($url);
        $signedUrl = $client->createPresignedUrl($request, '+1 year');
        
        echo  $signedUrl.'<br/>';

        $url = 'fymprofilethumbs/profile300/1b02e25e5ec6005d8208cd24a8e83ae8.jpeg';
        $request = $client->get($url);
        $signedUrl = $client->createPresignedUrl($request, '+1 year');
        
        echo  $signedUrl;exit;

/*
        $result = $client->listBuckets();
        //var_dump( $result);
        foreach ($result['Buckets'] as $bucket) {
            // Each Bucket value will contain a Name and CreationDate
            echo "{$bucket['Name']} - {$bucket['CreationDate']}\n";
        }
*/
        try
                {

                    
                    $result = $client->putObject(array(
                        'Bucket'     => 'fymprofile',
                        'Key'        => 'data_from_file.jpg',
                        'SourceFile' => '/var/www/test/arun_ss.jpg'
                       
                    ));


        $url = 'fymprofile/data_from_file.jpg';

        $request = $client->get($url);
        $signedUrl = $client->createPresignedUrl($request, '+1 year');
        
        //echo  $signedUrl;exit;
                    
                  
        /*
        $result = $client->putObject(array(
            'Bucket'     => 'fymprofile',
            'Key'    => 'data_from_stream.jpg',
            'Body'   => fopen('/home/arunss/Desktop/arun_ss.jpg', 'r+')
        ));

        
        
         'Key'        => 'arun_ss.jpg',
            'SourceFile' => '/home/arunss/Desktop/arun_ss.jpg',
            'Metadata'   => array(
                'Foo' => 'abc',
                'Baz' => '123'
         */
        var_dump($result['ObjectURL']);
        }catch(\Exception $ex)
                {
                    var_dump($ex->getMessage());
                    
                }
        
        exit;
        return $data;
        return new ApiProblem(405, 'The POST method has not been defined');
    }

    function curl_get_file_size( $url ) {
      // Assume failure.
      $result = -1;

      $curl = curl_init( $url );

      // Issue a HEAD request and follow any redirects.
      curl_setopt( $curl, CURLOPT_NOBODY, true );
      curl_setopt( $curl, CURLOPT_HEADER, true );
      curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
      curl_setopt( $curl, CURLOPT_FOLLOWLOCATION, true );
      //curl_setopt( $curl, CURLOPT_USERAGENT, $_SERVER['USER_AGENT'] );

      $data = curl_exec( $curl );
      curl_close( $curl );

      if( $data ) {
        $content_length = "unknown";
        $status = "unknown";

        if( preg_match( "/^HTTP\/1\.[01] (\d\d\d)/", $data, $matches ) ) {
          $status = (int)$matches[1];
        }

        if( preg_match( "/Content-Length: (\d+)/", $data, $matches ) ) {
          $content_length = (int)$matches[1];
        }

        // http://en.wikipedia.org/wiki/List_of_HTTP_status_codes
        if( $status == 200 || ($status > 300 && $status <= 308) ) {
          $result = $content_length;
        }
      }

      return $result;
    }

    /**
     * Delete a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function delete($id)
    {
        return new ApiProblem(405, 'The DELETE method has not been defined for individual resources');
    }

    /**
     * Delete a collection, or members of a collection
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        return new ApiProblem(405, 'The DELETE method has not been defined for collections');
    }

    /**
     * Fetch a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($id)
    {die('here');
        return new ApiProblem(405, 'The GET method has not been defined for individual resources');
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($params = array())
    {
       $weightInKg = 103;
       $params['height'] = 181;
       $age = 32;

       echo  $BMR = round((10 * $weightInKg) + (6.25 * $params['height']) - (5 * $age) +5);
       //echo  $BMR = round((10 * $weightInKg) + (6.25 * $params['height']) - (5 * $age)-161);
       exit;

       /*
       
    How to calculate for Men
10 x weight (kg) + 6.25 x height (cm) - 5 x age (y) + 5
        */
            
                /*
                $client = SesClient::factory(array(
                    'profile' => '<profile in your aws credentials file>',
                    'region'  => '<region name>'
                ));
                */

                $client = SesClient::factory(array(
                    'key' => 'AKIAJXN5HVRTANP4PSXA',
                    'secret' => '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',
                    'region' => 'us-east-1',
                ));

                
/*
                $result = $client->verifyEmailAddress(array(
                // EmailAddress is required
                'EmailAddress' => 'arun.ss@digitalbrandgroup.com',
            ));
 var_dump($result);
                $result = $client->listVerifiedEmailAddresses(array(
));

                var_dump($result); exit;
               */
                try
                {


                $result = $client->sendEmail(array(
                    'Source' => 'arun.ss@digitalbrandgroup.com',
                    'Destination' => array(
                        'ToAddresses' => array('arunssjoshi@gmail.com' ),
                    ),
                    'Message' => array(
                        'Subject' => array(
                            // Data is required
                            'Data' => 'test subject',
                            'Charset' => 'UTF-8',
                        ),
                        'Body' => array(
                            
                            'Html' => array(
                                // Data is required
                                'Data' => 'html conent',
                                'Charset' => 'UTF-8',
                            ),
                        ),
                    ),
                    'ReplyToAddresses' => array('arunssjoshi@gmail.com')
                ));
               var_dump($result->getStructure());exit;
                //var_dump(get_class_methods($result));exit;
                if( $result) {
                    echo ($result['MessageId']);
                }
                
                }catch(\Exception $ex)
                {
                    var_dump($ex->getMessage());
                    
                }
            
        exit;
    }

    /**
     * Patch (partial in-place update) a resource
     *
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        return new ApiProblem(405, 'The PATCH method has not been defined for individual resources');
    }

    /**
     * Replace a collection or members of a collection
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return new ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     *
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        return new ApiProblem(405, 'The PUT method has not been defined for individual resources');
    }
}
