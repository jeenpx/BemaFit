<?php
namespace Test\V1\Rest\TestApi;

class TestApiEntity
{
}
