<?php
namespace Test\V1\Rest\TestApi;

use Zend\Paginator\Paginator;

class TestApiCollection extends Paginator
{
}
