<?php
namespace Test\V1\Rpc\PutTest;

class PutTestControllerFactory
{
    public function __invoke($controllers)
    {
        return new PutTestController();
    }
}
