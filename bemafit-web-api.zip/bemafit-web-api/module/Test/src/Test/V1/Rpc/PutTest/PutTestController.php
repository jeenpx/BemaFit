<?php
namespace Test\V1\Rpc\PutTest;

use Zend\Mvc\Controller\AbstractActionController;

class PutTestController extends AbstractActionController
{
    public function putTestAction()
    {
    	die('put test');
    }
}
