<?php
return array(
    'router' => array(
        'routes' => array(
            'test.rest.test-api' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/test-api[/:test_api_id]',
                    'defaults' => array(
                        'controller' => 'Test\\V1\\Rest\\TestApi\\Controller',
                    ),
                ),
            ),
            'test.rpc.put-test' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/put-test',
                    'defaults' => array(
                        'controller' => 'Test\\V1\\Rpc\\PutTest\\Controller',
                        'action' => 'putTest',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            0 => 'test.rest.test-api',
            1 => 'test.rpc.put-test',
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'Test\\V1\\Rest\\TestApi\\TestApiResource' => 'Test\\V1\\Rest\\TestApi\\TestApiResourceFactory',
        ),
    ),
    'zf-rest' => array(
        'Test\\V1\\Rest\\TestApi\\Controller' => array(
            'listener' => 'Test\\V1\\Rest\\TestApi\\TestApiResource',
            'route_name' => 'test.rest.test-api',
            'route_identifier_name' => 'test_api_id',
            'collection_name' => 'test_api',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
                4 => 'POST',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
                2 => 'PUT',
                3 => 'PATCH',
                4 => 'DELETE',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'Test\\V1\\Rest\\TestApi\\TestApiEntity',
            'collection_class' => 'Test\\V1\\Rest\\TestApi\\TestApiCollection',
            'service_name' => 'TestApi',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'Test\\V1\\Rest\\TestApi\\Controller' => 'HalJson',
            'Test\\V1\\Rpc\\PutTest\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'Test\\V1\\Rest\\TestApi\\Controller' => array(
                0 => 'application/vnd.test.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'Test\\V1\\Rpc\\PutTest\\Controller' => array(
                0 => 'application/vnd.test.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
        ),
        'content_type_whitelist' => array(
            'Test\\V1\\Rest\\TestApi\\Controller' => array(
                0 => 'application/vnd.test.v1+json',
                1 => 'application/json',
            ),
            'Test\\V1\\Rpc\\PutTest\\Controller' => array(
                0 => 'application/vnd.test.v1+json',
                1 => 'application/json',
            ),
        ),
    ),
    'zf-hal' => array(
        'metadata_map' => array(
            'Test\\V1\\Rest\\TestApi\\TestApiEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'test.rest.test-api',
                'route_identifier_name' => 'test_api_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'Test\\V1\\Rest\\TestApi\\TestApiCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'test.rest.test-api',
                'route_identifier_name' => 'test_api_id',
                'is_collection' => true,
            ),
        ),
    ),
    'controllers' => array(
        'factories' => array(
            'Test\\V1\\Rpc\\PutTest\\Controller' => 'Test\\V1\\Rpc\\PutTest\\PutTestControllerFactory',
        ),
    ),
    'zf-rpc' => array(
        'Test\\V1\\Rpc\\PutTest\\Controller' => array(
            'service_name' => 'PutTest',
            'http_methods' => array(
                0 => 'PUT',
            ),
            'route_name' => 'test.rpc.put-test',
        ),
    ),
);
