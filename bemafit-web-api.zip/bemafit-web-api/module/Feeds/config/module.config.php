<?php
return array(
    'router' => array(
        'routes' => array(
            'feeds.rest.feed' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user/:user_id/feed[/:feed_id][/:list_type][/:list_type_id]',
                    'defaults' => array(
                        'controller' => 'Feeds\\V1\\Rest\\Feed\\Controller',
                    ),
                ),
            ),
            'feeds.rpc.motivate' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user/:user_id/feed/:feed_id/motivate',
                    'defaults' => array(
                        'controller' => 'Feeds\\V1\\Rpc\\Motivate\\Controller',
                        'action' => 'motivate',
                    ),
                ),
            ),
            'feeds.rpc.hash-tag' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/feed/hashtag/:hashtag',
                    'defaults' => array(
                        'controller' => 'Feeds\\V1\\Rpc\\HashTag\\Controller',
                        'action' => 'hashTag',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            0 => 'feeds.rest.feed',
            1 => 'feeds.rpc.motivate',
            2 => 'feeds.rpc.hash-tag',
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'Feeds\\V1\\Rest\\Feed\\FeedResource' => 'Feeds\\V1\\Rest\\Feed\\FeedResourceFactory',
        ),
    ),
    'zf-rest' => array(
        'Feeds\\V1\\Rest\\Feed\\Controller' => array(
            'listener' => 'Feeds\\V1\\Rest\\Feed\\FeedResource',
            'route_name' => 'feeds.rest.feed',
            'route_identifier_name' => 'feed_id',
            'collection_name' => 'feed',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'Feeds\\V1\\Rest\\Feed\\FeedEntity',
            'collection_class' => 'Feeds\\V1\\Rest\\Feed\\FeedCollection',
            'service_name' => 'Feed',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'Feeds\\V1\\Rest\\Feed\\Controller' => 'Json',
            'Feeds\\V1\\Rpc\\Motivate\\Controller' => 'Json',
            'Feeds\\V1\\Rpc\\HashTag\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'Feeds\\V1\\Rest\\Feed\\Controller' => array(
                0 => 'application/json',
            ),
            'Feeds\\V1\\Rpc\\Motivate\\Controller' => array(
                0 => 'application/vnd.feeds.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
            'Feeds\\V1\\Rpc\\HashTag\\Controller' => array(
                0 => 'application/vnd.feeds.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
        ),
        'content_type_whitelist' => array(
            'Feeds\\V1\\Rest\\Feed\\Controller' => array(
                0 => 'application/json',
            ),
            'Feeds\\V1\\Rpc\\Motivate\\Controller' => array(
                0 => 'application/vnd.feeds.v1+json',
                1 => 'application/json',
            ),
            'Feeds\\V1\\Rpc\\HashTag\\Controller' => array(
                0 => 'application/vnd.feeds.v1+json',
                1 => 'application/json',
            ),
        ),
    ),
    'zf-hal' => array(
        'metadata_map' => array(
            'Feeds\\V1\\Rest\\Feed\\FeedEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'feeds.rest.feed',
                'route_identifier_name' => 'feed_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'Feeds\\V1\\Rest\\Feed\\FeedCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'feeds.rest.feed',
                'route_identifier_name' => 'feed_id',
                'is_collection' => true,
            ),
        ),
    ),
    'controllers' => array(
        'factories' => array(
            'Feeds\\V1\\Rpc\\Motivate\\Controller' => 'Feeds\\V1\\Rpc\\Motivate\\MotivateControllerFactory',
            'Feeds\\V1\\Rpc\\HashTag\\Controller' => 'Feeds\\V1\\Rpc\\HashTag\\HashTagControllerFactory',
        ),
    ),
    'zf-rpc' => array(
        'Feeds\\V1\\Rpc\\Motivate\\Controller' => array(
            'service_name' => 'Motivate',
            'http_methods' => array(
                0 => 'POST',
            ),
            'route_name' => 'feeds.rpc.motivate',
        ),
        'Feeds\\V1\\Rpc\\HashTag\\Controller' => array(
            'service_name' => 'HashTag',
            'http_methods' => array(
                0 => 'GET',
            ),
            'route_name' => 'feeds.rpc.hash-tag',
        ),
    ),
    'zf-mvc-auth' => array(
        'authorization' => array(
            'Feeds\\V1\\Rest\\Feed\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
            'Feeds\\V1\\Rpc\\Motivate\\Controller' => array(
                'actions' => array(
                    'motivate' => array(
                        'GET' => false,
                        'POST' => true,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                ),
            ),
            'Feeds\\V1\\Rpc\\HashTag\\Controller' => array(
                'actions' => array(
                    'hashTag' => array(
                        'GET' => true,
                        'POST' => false,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                ),
            ),
        ),
    ),
    'aws_s3_path'=>'https://s3.amazonaws.com',
    'feed_photo_Settings' => array('bucket'=>'fymfeeds',
                                   'server_upload_path' =>'public/uploads/feed/',
                                   'thumb_server_upload_path' =>'public/uploads/feed_thumbs/',
                                    'thumbs'=> array(
                                            array('feed200' => array('bucket'=>'fymfeedthumb/feed200',
                                                                     'width'=>200)
                                            ),
                                            array('feed600' => array('bucket'=>'fymfeedthumb/feed600',
                                                                     'width'=>600)
                                            )
                                        )
                                    ),
    'user_photo_Settings' => array('bucket'=>'fymprofile',
                                   'server_upload_path' =>'public/uploads/profile/',
                                   'thumb_server_upload_path' =>'public/uploads/profile_thumbs/',
                                    'thumbs'=> array(
                                            array('profile200' => array('bucket'=>'fymprofilethumbs/profile200',
                                                                     'width'=>200)
                                            ),
                                            array('profile600' => array('bucket'=>'fymprofilethumbs/profile600',
                                                                     'width'=>600)
                                            )
                                        )
                                    ),
    'meal_photo_Settings' => array(  'bucket'=>'fymmeal',
                                       'server_upload_path' =>'public/uploads/meal/',
                                       'thumb_server_upload_path' =>'public/uploads/mealthumbs/',
                                       'thumbs'=> array(
                                                array('meal100' => array(
                                                                         'bucket'=>'fymmealthumbs/meal100',
                                                                         'width'=>100
                                                                    )
                                                ),
                                                array('meal225' => array(
                                                                         'bucket'=>'fymmealthumbs/meal225',
                                                                         'width'=>700
                                                                    )
                                                ),
                                                array('meal600' => array(
                                                                         'bucket'=>'fymmealthumbs/meal600',
                                                                         'width'=>600
                                                                    )
                                                )
                                       )
     ),
    'business_photo_Settings' => array('bucket'=>'fymbusiness',
                                       'server_upload_path' =>'public/uploads/business/',
                                       'thumb_server_upload_path' =>'public/uploads/businessthumbs/',
                                       'thumbs'=> array(
                                                array('business100' => array(
                                                                         'bucket'=>'fymbusinessthumb/business100',
                                                                         'width'=>100,
                                                                    )
                                                ),
                                                array('business1900' => array(
                                                                         'bucket'=>'fymbusinessthumb/business1900',
                                                                         'width'=>1920,
                                                                    )
                                                ),
                                       )
     ),
    'ad_photo_Settings_guestpost' => array(  'bucket'=>'fymad',
                                       'server_upload_path' =>'public/uploads/ad/',
                                       'thumb_server_upload_path' =>'public/uploads/adthumbs/',
                                       'thumbs'=> array(
                                                array('ad100' => array(
                                                                         'bucket'=>'fymadthumb/ad100',
                                                                         'width'=>100,
                                                                    )
                                                ),
                                                array('ad1400' => array(
                                                                         'bucket'=>'fymadthumb/ad1400',
                                                                         'width'=>576,
                                                                    )
                                                ),
                                                array('ad600' => array(
                                                                         'bucket'=>'fymadthumb/ad600',
                                                                         'width'=>600,
                                                                    )
                                                ),
                                       )
     ),
);
