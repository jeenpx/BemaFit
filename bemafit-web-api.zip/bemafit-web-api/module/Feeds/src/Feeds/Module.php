<?php
namespace Feeds;

use Feeds\V1\Model\FeedDetailsDetail;
use Feeds\V1\Model\FeedDetailsDetailTable;

use Zend\Db\ResultSet\ResultSet;
use ZF\Apigility\Provider\ApigilityProviderInterface;
use Zend\Db\TableGateway\TableGateway;

class Module implements ApigilityProviderInterface
{
    public function getConfig()
    {
        return include __DIR__ . '/../../config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'ZF\Apigility\Autoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__,
                ),
            ),
        );
    }

    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'Feeds\V1\Rest\FeedMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Feed\TableGateway('feed', $adapter);
                    return new V1\Rest\Feed\TableGatewayMapper($tableGateway);
                },
                'Feeds\Model\FeedDetailsDetailTable' =>  function ($sm) {
                     $tableGateway = $sm->get('FeedDetailsDetailTableGateway');
                     $table = new FeedDetailsDetailTable($tableGateway);
                     $table->setConfig($sm->get('config'));
                     return $table;
                },
                'FeedDetailsDetailTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new FeedDetailsDetail());
                     return new TableGateway('feed_data', $dbAdapter, null, $resultSetPrototype);
                },
            ),
        );
    }
}
