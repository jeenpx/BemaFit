<?php
namespace Feeds\V1\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\Sql\Expression;

use Zend\Db\TableGateway\TableGateway;
use Aws\DynamoDb\DynamoDbClient;

class FeedDetailsDetailTable {
	protected $tableGateway;
	protected $configValues;

	public function __construct(TableGateway $tableGateway) {
		$this->tableGateway = $tableGateway;
	}

	public function setConfig($config) {
		$this->configValues = $config;
	}

	public function createFeedDetails($data) {
		$this->tableGateway->insert($data);
		return $this->tableGateway->lastInsertValue;
	}

	public function insertFeedMedia($data) {
		$adapter        = $this->tableGateway->getAdapter();
		$feedMediaTable = new \Zend\Db\TableGateway\TableGateway('feed_data_media', $adapter);
		$status         = $feedMediaTable->insert($data);
		return $feedMediaTable->lastInsertValue;
	}

	public function getFeedDataById($feed_data_id) {
		$resultSet = $this->tableGateway->select(array('id' => $feed_data_id, 'status_id' => 1));
		return $resultSet->current();
	}

	public function update($user_id, $data) {
		if (is_numeric($user_id) && $user_id > 0) {
			return $this->tableGateway->update($data, array('id' => $user_id));
		}
	}

	public function createFeedMotivateDetails($data) {
		$adapter         = $this->tableGateway->getAdapter();
		$feedDetailTable = new \Zend\Db\TableGateway\TableGateway('feed_data_details', $adapter);
		$status          = $feedDetailTable->insert($data);
		return $feedDetailTable->lastInsertValue;
	}

	public function updateMotivateCount($feed_data_id, $apiData, $expression = '') {
		if ($feed_data_id > 0) {
			if ($apiData['type'] == 'Like') {
				$status = $this->tableGateway->update(array('like_count' => new Expression('like_count '.$expression)), array('id' => $feed_data_id));
			} else if ($apiData['type'] == 'Inspire') {
				$status = $this->tableGateway->update(array('inspire_count' => new Expression('inspire_count '.$expression)), array('id' => $feed_data_id));
			} else if ($apiData['type'] == 'Comment') {
				$status = $this->tableGateway->update(array('comment_count' => new Expression('comment_count '.$expression)), array('feed_id' => $feed_data_id, 'parent_id' => 0));
			}
		}

	}

	public function updateDynamoMotivateCount($table, $feed_info, $motivation_type, $expression = '+') {
		$config       = $this->configValues;
		$dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);
		
		if ($motivation_type == 'like') {
			$updateExpression = "set like_count = like_count $expression :val1";
		} else if ($motivation_type== 'inspire') {
			$updateExpression = "set inspire_count = inspire_count $expression :val1";
		} else if ($motivation_type == 'comment') {
			$updateExpression = "set comment_count = comment_count $expression :val1";
		}

		
		
		$table_key = ($table == 'feed')?"feed_guid":"feed_comment_guid";
		//var_dump($feed_info);
		try{
			if ($table =='feed') {
				//$response = $dynamodbClient->updateItem
				$response = $dynamodbClient->updateItem(array(
				    'TableName' => 'feed',
				    'Key' => array(
				        'date'      =>  $feed_info->feed_data['date'],
				        'created_date'      => $feed_info->feed_data['created_date'],
				        
				    ),
				    "ExpressionAttributeValues" =>  array (
				            ":val1" => array('N' => '1')
				        ) ,
				    "UpdateExpression" => $updateExpression,  
				    'ReturnValues' => 'ALL_NEW'
				));
			}
		    
		} catch (\Exception $ex) {
		    echo 'motivate counter -> '.$ex->getMessage();
		}
	}


	public function deleteMotivation($data) {
		if ($data['user_id'] > 0 && $data['feed_data_id'] > 0 && $data['type'] != '') {
			$adapter         = $this->tableGateway->getAdapter();
			$feedDetailTable = new \Zend\Db\TableGateway\TableGateway('feed_data_details', $adapter);
			$status          = $feedDetailTable->update(array('status_id' => 4), array('user_id' => $data['user_id'], 'feed_data_id' => $data['feed_data_id'], 'type' => $data['type']));
		}
	}

	public function insertHashTag($hashtag, $user_id) {
		$adapter      = $this->tableGateway->getAdapter();
		$hashtagTable = new \Zend\Db\TableGateway\TableGateway('hashtag', $adapter);
		$resultSet    = $hashtagTable->select(array('hashtag' => $hashtag, 'status_id' => 1));

		$hashTagInfo = $resultSet->current();

		if ($hashTagInfo) {
			return $hashTagInfo->id;
		} else {
			$status = $hashtagTable->insert(array('hashtag' => $hashtag, 'status_id' => 1, 'created_by' => $user_id, 'created_date' => gmdate('Y-m-d H:i:s')));
			return $hashtagTable->lastInsertValue;
		}
	}

	public function insertHashTagDetail($data) {
		$adapter            = $this->tableGateway->getAdapter();
		$hashtagDetailTable = new \Zend\Db\TableGateway\TableGateway('hashtag_detail', $adapter);
		$status             = $hashtagDetailTable->insert($data);
		return $hashtagDetailTable->lastInsertValue;
	}

	public function getFeedComment($comment_id) {
		$resultSet = $this->tableGateway->select(array('id' => $comment_id, 'status_id' => 1));
		return $resultSet->current();
	}

	public function deleteFeedComment($comment_id, $feed_id) {
		$this->tableGateway->update(array('status_id'     => 4), array('id'     => $comment_id, 'status_id'     => 1));
		$this->tableGateway->update(array('status_id'     => 4), array('id'     => $comment_id, 'status_id'     => 1));
		$this->updateMotivateCount($feed_id, array('type' => 'Comment'), '- 1');
	}

	public function getHashTagFeeds($current_user_id, $hashtag, $offset, $limit) {

		$sql = "SELECT  SQL_CALC_FOUND_ROWS    fd.id, f.id AS feed_id, f.guid AS feed_gu_id, fd.data, fd.created_date,
                fd.like_count, fd.inspire_count, fd.comment_count,
                u.username, u.profile_photo,u.guid, fdm.type as media_type, fdm.media_url, fdm.width as image_width, fdm.height as image_height,
                IF(fddLike.type IS NULL,FALSE,TRUE) AS like_status, IF(fddInspire.type IS NULL,FALSE,TRUE) AS inspire_status
                FROM feed_data fd
                JOIN user u ON fd.user_id=u.id
                JOIN hashtag_detail hd ON fd.id=hd.feed_id
                JOIN feed f ON fd.feed_id=f.id
                JOIN hashtag h ON hd.hashtag_id=h.id
                LEFT JOIN feed_data_media fdm ON fd.id=fdm.feed_data_id
                LEFT JOIN feed_data_details fddLike ON fd.id=fddLike.feed_data_id AND fddLike.type='Like' AND fddLike.user_id=$current_user_id AND fddLike.status_id=1
                LEFT JOIN feed_data_details fddInspire ON fd.id=fddInspire.feed_data_id AND fddInspire.type='Inspire' AND fddInspire.user_id=$current_user_id AND fddInspire.status_id=1
                WHERE u.status_id=1  AND h.status_id=1 AND hd.status_id=1 AND fd.parent_id=0 AND h.status_id=1  AND h.hashtag=? AND fd.status_id=1 and f.status_id=1
                ORDER BY fd.created_date DESC
                LIMIT ?, ?";

		$statement = $this->tableGateway->adapter->createStatement($sql, array($hashtag, $offset, $limit));
		$result    = $statement->execute();
		$feeds     = $result->getResource()->fetchAll(2);

		$total_rows = $this->tableGateway->adapter->createStatement('SELECT FOUND_ROWS()  as total_rows')->execute()->getResource()->fetchAll()[0]['total_rows'];

		$feed_list                  = array();
		$preview_bucket_url         = $this->configValues['feed_photo_Settings']['thumbs'][0]['feed200']['bucket'];
		$preview_profile_bucket_url = $this->configValues['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];

		foreach ($feeds as $feed) {
			$default_width = $this->configValues['feed_photo_Settings']['thumbs'][0]['feed200']['width'];
			$image_url     = empty($feed['profile_photo'])?'':$this->configValues['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$feed['profile_photo'];

			if ($feed['media_type'] == 'Image') {
				$feed_image = empty($feed['media_url'])?$feed['media_url']:$this->configValues['aws_s3_path'].'/'.$preview_bucket_url.'/'.$feed['media_url'];
			} else {
				$feed_image = '';
			}

			if ($feed['image_width'] > 0 && $feed['image_width'] > 0) {
				$height = $feed['image_height']/($feed['image_width']/$default_width);
			} else {
				$height = $default_width = 0;
			}

			$feed_list[] = array('feed_id' => $feed['feed_gu_id'], 'feed_type' => 'text', 'feed_data' => urldecode($feed['data']), 'created_date' => $feed['created_date'],
				'user_id'                     => $feed['guid'], 'user_name'                     => $feed['username'], 'profile_photo'                     => $image_url, 'feed_image'                     => $feed_image,
				'feed_image_width'            => $default_width, 'feed_image_height'            => floor($height),
				'like_count'                  => $feed['like_count'], 'inspire_count'                  => $feed['inspire_count'], 'comment_count'                  => $feed['comment_count'],
				'like_status'                 => (bool) $feed['like_status'], 'inspire_status'                 => (bool) $feed['inspire_status'],
			);
		}

		return array(
			'meta'        => array('status'        => 'OK', 'code'        => 200, 'methodName'        => 'getHashTagPosts'),
			'feeds'       => $feed_list,
			'total_feeds' => $total_rows
		);

	}
}
