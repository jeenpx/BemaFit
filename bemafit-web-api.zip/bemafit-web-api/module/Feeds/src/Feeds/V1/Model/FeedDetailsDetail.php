<?php

namespace Feeds\V1\Model;

class FeedDetailsDetail
{
    public $id;
    public $data;
    public $user_id;
    public $feed_id;
    public $parent_id;

    public function getArrayCopy()
    {
        return array(
            'id'     => $this->id,
            'data' => $this->data,
            'user_id' => $this->user_id,
            'feed_id' => $this->feed_id,
            'parent_id' => $this->parent_id,
        );
    }

    public function exchangeArray(array $array)
    {
        $this->id     = $array['id'];
        $this->data     = $array['data'];
        $this->user_id     = $array['user_id'];
        $this->feed_id     = $array['feed_id'];
        $this->parent_id     = $array['parent_id'];
    }
}
