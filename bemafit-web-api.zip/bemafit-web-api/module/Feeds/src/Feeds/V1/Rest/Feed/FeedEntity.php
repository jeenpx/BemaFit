<?php
namespace Feeds\V1\Rest\Feed;

class FeedEntity
{
}
