<?php
namespace Feeds\V1\Rest\Feed;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class FeedResource extends AbstractResourceListener
{
    
    protected $mapper;
 
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }
    
    /**
     * Create a resource
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        $data->userId = $this->getEvent()->getRouteMatch()->getParam('user_id');
        $data->currentUserId = $this->getIdentity()->getUserId();
        return $this->mapper->create($data);
    }

    /**
     * Delete a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function delete($id)
    {
        $list_type =  $this->getEvent()->getRouteMatch()->getParam('list_type');

        $data['currentUserId'] = $this->getIdentity()->getUserId();
        $data['feed_id'] = $id;
        $data['user_id'] =  $this->getEvent()->getRouteMatch()->getParam('user_id');

        if (isset($data['feed_id']) && $list_type == 'comment') {
            $data['list_type_id'] =  $this->getEvent()->getRouteMatch()->getParam('list_type_id');
            return $this->mapper->deleteFeedComment($data);
        }

        return $this->mapper->delete($data);
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The DELETE method has not been defined for individual resources');
    }

    /**
     * Delete a collection, or members of a collection
     * Not using as per current system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The DELETE method has not been defined for collections');
    }

    /**
     * Fetch a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($id)
    {
        $data['feed_id'] =  $this->getEvent()->getRouteMatch()->getParam('feed_id');
        $data['user_id'] =  $this->getEvent()->getRouteMatch()->getParam('user_id');
        $list_type =  $this->getEvent()->getRouteMatch()->getParam('list_type');
        $data['offset'] = (int) $this->getEvent()->getRequest()->getQuery('offset', 0);
        $data['limit'] = (int) $this->getEvent()->getRequest()->getQuery('limit', 10);
        $data['hid'] =  $this->getEvent()->getRequest()->getQuery('hid','');
        $data['rid1'] =  $this->getEvent()->getRequest()->getQuery('rid1','');
        if (isset($data['feed_id']) && $list_type == 'comments') {
            return $this->mapper->getFeedComments($data);
        }
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The GET method has not been defined for individual resources');
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($params = array())
    {
        $params['offset'] = (int) $this->getEvent()->getRequest()->getQuery('offset', 0);
        $params['limit'] = (int) $this->getEvent()->getRequest()->getQuery('limit', 10);
        $params['user_id'] =  $this->getEvent()->getRouteMatch()->getParam('user_id');
        $params['hid'] =  $this->getEvent()->getRequest()->getQuery('hid','');
        $params['rid1'] =  $this->getEvent()->getRequest()->getQuery('rid1','');
        $params['rid2'] =  $this->getEvent()->getRequest()->getQuery('rid2','');
        $params['logged_in_user_id'] =  $this->getIdentity()->getUserId();
        return $this->mapper->fetchAll($params);
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The GET method has not been defined for collections');
    }

    /**
     * Patch (partial in-place update) a resource
     * Not using as per current system requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PATCH method has not been defined for individual resources');
    }

    /**
     * Replace a collection or members of a collection
     * Not using as per current system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     * Not using as per current system requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for individual resources');
    }
}
