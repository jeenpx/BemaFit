<?php
namespace Feeds\V1\Rest\Feed;

use Zend\Paginator\Paginator;

class FeedCollection extends Paginator
{
}
