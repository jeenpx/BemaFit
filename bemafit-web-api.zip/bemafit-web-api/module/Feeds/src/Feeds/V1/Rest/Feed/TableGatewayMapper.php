<?php

namespace Feeds\V1\Rest\Feed;

use Aws\S3\S3Client;

use Zend\Mvc\Controller\AbstractActionController;

use ZF\ApiProblem\ApiProblem;
use Aws\DynamoDb\DynamoDbClient;
use Aws\DynamoDb\Model\BatchRequest\PutRequest;
use Aws\DynamoDb\Model\BatchRequest\WriteRequestBatch;
use Aws\DynamoDb\Model\Item;


class TableGatewayMapper extends AbstractActionController {
    /**
     * @var TableGateway
     */
    protected $table;
    protected $configValues;
    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table) {
        $this->table           = $table;
        $this->feed_image_name = '';
        $this->sizeInfo        = '';
    }


    public function getFymUserDetailTable() {
        $sm          = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function getFeedDetailsDetailTable() {
        $sm          = $this->getServiceLocator();
        $this->Table = $sm->get('Feeds\Model\FeedDetailsDetailTable');
        return $this->Table;
    }

    public function getAdapter() {
        $sm            = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getFeedMapper() {
        $sm          = $this->getServiceLocator();
        $this->Table = $sm->get('Feeds\V1\Rest\FeedMapperTableGateway');
        return $this->Table;
    }

    public function getUserTable() {
        $sm          = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    /**
     * To create Feed
     *
     * @param array $data
     * @return Entity
     */
    public function create($data) {
        //print_r($data);
        $config = $this->getServiceLocator()->get('Config');
        // if (empty($data->data)) {
        //     return \Application\Service\FymApiProblem::ApiProblem(406, 'Feed cannot be empty');
        // }

        if ($data->feed_type != 'feed' && $data->feed_type != 'feed_comment') {
            return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid feed type');
        }



        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data->userId);
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $image_name = '';
        if (isset($_FILES['photo'])) {
            $config               = $this->getServiceLocator()->get('Config');
            $file_upload_settings = $config['feed_photo_Settings'];

            $utilityObj         = new \Application\Service\Utility();
            $image_name         = md5(uniqid(rand(), true));
            $file_upload_status = $utilityObj->photoUpload(array('upload_dir' => $file_upload_settings['server_upload_path'], 'image_name' => $image_name));

            if (!$file_upload_status['status']) {
                return \Application\Service\FymApiProblem::ApiProblem(406, $file_upload_status['message']);
            } else {
                $image_name     = $file_upload_status['file_name'];
                $this->sizeInfo = $file_upload_status['sizeinfo'];
            }

        }

        $data->user_id      = $userId      = $user_info->id;
        $data->feed_type_id = 1;
        $data->image_name   = $image_name;
        $data->created_date = time(gmdate('Y-m-d H:i:s'));

        $preview_profile_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
        $profile_url                = empty($user_info->profile_photo)?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$user_info->profile_photo;
        $default_width              = $config['feed_photo_Settings']['thumbs'][0]['feed200']['width'];
        $default_large_width        = $config['feed_photo_Settings']['thumbs'][1]['feed600']['width'];

        if (!empty($this->sizeInfo['width']) && !empty($this->sizeInfo['width'])) {
            $height = $this->sizeInfo['height']/($this->sizeInfo['width']/$default_width);
            $height_large = $this->sizeInfo['height']/($this->sizeInfo['width']/$default_large_width);
        } else {
            $height_large = $height = $default_width = 0;
        }

        if ($data->feed_type == 'feed') {
            
            $data->feed_guid = md5(uniqid(rand(), true));
            $newId           = 0;//$this->table->lastInsertValue;
            $data->parent_id = 0;

            $feed_data_id    = $this->saveFeedDetails($newId, $data);
            

            if (!empty($this->feed_image_name)) {
                $preview_bucket_url    = $config['feed_photo_Settings']['thumbs'][0]['feed200']['bucket'];
                $this->feed_image_name = empty($this->feed_image_name)?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$this->feed_image_name);
            }

            return array(
                'meta'              => array('status'              => 'OK', 'code'              => 200, 'methodName'              => 'createFeed'),
                'feed'              => array('feed_id'              => $data->feed_guid, 'feed_type'              => 'text', 'created_date'              => gmdate('Y-m-d H:i:s', $data->created_date),
                    'feed_data'        => ($data->data), 'inspire_count'        => 0, 'like_count'        => 0, 'comment_count'        => 0,
                    'friend_id1'       => '', 'friend_name1'       => '', 'friend_photo1'       => '',
                    'friend_id2'       => '', 'friend_name2'       => '', 'friend_photo2'       => '',
                    'checkin_user_id'  => '', 'checkin_user_name'  => '', 'checkin_profile_photo'  => '', 'checkin_business'  => '',
                    'user_id'          => $user_info->guid, 'user_name'          => $user_info->username, 'profile_photo'          => $profile_url,
                    'exc_user_id'      => '', 'exc_user_name'      => '', 'exc_profile_photo'      => '', 'exercise'      => '',
                     'feed_image'      => $this->feed_image_name,
                    'feed_image_width' => $default_width, 'feed_image_height' => floor($height), 
                    'feed_image_large_width' => $default_large_width, 'feed_image_height' => floor($height_large),
                    'goal_date' => '',
                    'ad_id'            => '',
                    'comment_count'    => 0, 'comment_count'    => 0, 'like_status'    => false, 'inspire_status'    => false
                ),
            );
        } else if ($data->feed_type == 'feed_comment') {
            if (!$data->feed_id) {
                return \Application\Service\FymApiProblem::ApiProblem(406, 'Feed required');
            }


            $data->feed_data = $this->getDFeedByFeedGuid($data->feed_id);

            
            if (!$data->feed_data) {
                return \Application\Service\FymApiProblem::ApiProblem(404, 'Feed not found');
            }

            $data->feed_comment_guid = md5(uniqid(rand(), true));
            $feed_data_id = $this->saveFeedDetails($data->feed_id, $data);

            // INCREMENT COMMENT COUNT
            $this->getFeedDetailsDetailTable()->updateDynamoMotivateCount('feed', $data, 'comment', $expression = '+');
            


            //$this->insertHashTags($userId, $feed_data_id, $data->data, 'feed');

            if (!empty($this->feed_image_name)) {
                $preview_bucket_url    = $config['feed_photo_Settings']['thumbs'][0]['feed200']['bucket'];
                $this->feed_image_name = empty($this->feed_image_name)?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$this->feed_image_name);
            }

            return array(
                'meta'              => array('status'              => 'OK', 'code'              => 200, 'methodName'              => 'createFeedComment'),
                'feed_comment'      => array('comment'      => $data->data, "feed_image"      => $this->feed_image_name,
                    'feed_image_width' => $default_width, 'feed_image_height' => floor($height),
                    'created_date'     => gmdate('Y-m-d H:i:s',$data->created_date),
                    'user_id'          => $user_info->guid, 'user_name'          => $user_info->username, 'profile_photo'          => $profile_url,
                    'feed_comment_id'  => $data->feed_comment_guid, 'inspire_count'  => 0, 'like_count'  => 0),
            );
        }
    }
   
    /**
     * To save Feed Details
     *
     * @param int $feedId
     * @param array $data
     * @return Entity
     */
    public function saveFeedDetails($feedId, $data) {   
        
        $config       = $this->getServiceLocator()->get('Config');
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);
        
        $guid = isset($data->feed_guid)?$data->feed_guid:'';
        $data->date = gmdate('Y-m-d');
        $this->feedImageUpload($data);

        if ($data->feed_type != 'feed_comment') {
            try {
                $item = array(
                        'date' => array('S' => $data->date),
                        'created_date'=>array('N' => $data->created_date),//'created_date'=>array('N' => $data->created_date.$data->user_id),
                        'feed_guid'      => array('S' => $data->feed_guid),
                        'user_id'    => array('S' => $data->user_id),
                        'feed_type_id'=>array('N' => $data->feed_type_id),
                        'status_id'=>array('N' => 1),
                        'like_count'=>array('N' => 0),
                        'inspire_count'=>array('N' => 0),
                        'comment_count'=>array('N' => 0),
                        
                    );
                if (!empty($data->data)) {
                    $item['data'] = array('S' => ($data->data));
                }
                if (isset($data->user_id2)) {
                    $item['user_id2'] = array('N' => ($data->user_id2));
                }
                if (isset($data->object_id)) {
                    $item['object_id'] = array('N' => ($data->object_id));
                }
                if (isset($data->goal_date)) {
                    $item['goal_date'] = array('S' => ($data->goal_date));
                }
                if (!empty($data->image_name)) {
                    $item['media'] = array('M' => array('type'=>array('S' => 'image'),
                                                          'file'=>array('S' => $data->image_name),
                                                          'width'=>array('N' => $this->sizeInfo['width']),
                                                          'height'=>array('N' => $this->sizeInfo['height']),
                                                          ));
                }
                
                //$this->SelfCronAction('2015-08-21' , '1440140270336');
               
                $result = $dynamodbClient->putItem(array(
                    'TableName' => 'feed',
                    'Item' => $item
                ));
                if (!empty($data->data)) {
                    $this->insertHashTags($data->user_id, $data->feed_guid, $data->data, array('feed_date'=>$item['date'], 'feed_created_date'=>$item['created_date']), 'feed');
                }

                $this->SelfCronAction($item['date']['S'], $item['created_date']['N']);
                

                //var_dump($result);
            } catch (\Exception $ex) {
                echo 'first insert -> '.$ex->getMessage();
            }


            
        } else {
            try {
                $item = array(
                    'feed_comment_guid'      => array('S' => $data->feed_comment_guid),
                    'feed_guid'      => array('S' => $data->feed_id),
                    'posted_by'    => array('N' => $data->user_id),
                    'feed_type_id'=>array('N' => $data->feed_type_id),
                    'data'=>array('S' => ($data->data)),
                    'comment_created_date'=>array('S' => gmdate('Y-m-d H:i:s', $data->created_date)),
                    'status_id'=>array('N' => 1),
                    'like_count'=>array('N' => 0),
                    'inspire_count'=>array('N' => 0),
                    'created_date'=>array('N' => $data->created_date.'.'.$data->user_id),
                );

                if (!empty($data->image_name)) {
                    $item['media'] = array('M' => array('type'=>array('S' => 'image'),
                                      'file'=>array('S' => $data->image_name),
                                      'width'=>array('N' => $this->sizeInfo['width']),
                                      'height'=>array('N' => $this->sizeInfo['height']),
                                      ));
                }

                $result = $dynamodbClient->putItem(array(
                    'TableName' => 'feed_comment',
                    'Item' => $item
                ));
                //var_dump($result);
            } catch (\Exception $ex) {
                echo 'comment insert -> '.$ex->getMessage();
            }
        }
    }

    public function feedImageUpload($data)
    {
        //Valid file exists to upload
        if (!empty($data->image_name)) {
            $config               = $this->getServiceLocator()->get('Config');
            $file_upload_settings = $config['feed_photo_Settings'];

            $s3_upload_status = true;
            $s3_client        = S3Client::factory($config['amazon_s3']);
            try {
                $result = $s3_client->putObject(array(
                        'Bucket'     => $file_upload_settings['bucket'],
                        'Key'        => $data->image_name,
                        'SourceFile' => $file_upload_settings['server_upload_path'].$data->image_name
                    ));

                //Successfully uploaded to amason s3. Then resize image and upload these thumbs to s3
                if (isset($result['ObjectURL'])) {
                    $utilityObj = new \Application\Service\Utility();

                    foreach ($file_upload_settings['thumbs'] as $thumb) {
                        $key = key($thumb);

                        $resize_status = $utilityObj->smart_resize_image(
                            $file_upload_settings['server_upload_path'].$data->image_name,
                            $file_upload_settings['server_upload_path'].$data->image_name,
                            $thumb[$key]['width'],
                            0,
                            true,
                            $file_upload_settings['thumb_server_upload_path'].$data->image_name,
                            false,
                            false,
                            $quality = 100
                        );

                        //Resize successfull. Upload to amazon
                        if ($resize_status) {
                            try {
                                $result = $s3_client->putObject(array(
                                        'Bucket'     => $thumb[$key]['bucket'],
                                        'Key'        => $data->image_name,
                                        'SourceFile' => $file_upload_settings['thumb_server_upload_path'].$data->image_name
                                    ));
                            } catch (\Exception $ex) {
                                $s3_upload_status = false;
                                //var_dump($ex->getMessage());
                            }
                        }
                    }

                    if (file_exists($file_upload_settings['server_upload_path'].$data->image_name)) {
                        if (is_file($file_upload_settings['server_upload_path'].$data->image_name)) {
                            unlink($file_upload_settings['server_upload_path'].$data->image_name);
                        }
                    }

                    if (file_exists($file_upload_settings['thumb_server_upload_path'].$data->image_name)) {
                        if (is_file($file_upload_settings['thumb_server_upload_path'].$data->image_name)) {
                            unlink($file_upload_settings['thumb_server_upload_path'].$data->image_name);
                        }
                    }

                    if ($s3_upload_status) {
                       $this->feed_image_name = $data->image_name;
                    }
                }
            } catch (\Exception $ex) {
                $s3_upload_status = false;
            }
            return $s3_upload_status;
        }
    }

    /**
     * To get Feed Comments
     *
     * @param array $data
     * @return Entity
     */
    public function getFeedComments($data) {   
        $this->getAdapter();
        $config    = $this->getServiceLocator()->get('Config');
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data['user_id']);
        $hid   = $data['hid'];
        $rid1   = $data['rid1'];
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }

        $feed_data = $this->getDFeedByFeedGuid($data['feed_id']);

        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);
        if (!$feed_data) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'Feed not found');
        }

        try
        {
            $options = array(
                    'TableName' => 'feed_comment',
                    'KeyConditionExpression' => 'feed_guid = :v_id',
                    'ExpressionAttributeValues' =>  array (
                        ':v_id' => array('S' => $data['feed_id'])
                    ),
                    'ScanIndexForward'=>false,
                    'Count'=>true,
                    'Limit'=>10
                );
          
            if (!empty($data['hid']) && !empty($data['rid1'])) {  
                $options['ExclusiveStartKey'] = array(
                                    'created_date' => array('N' => $rid1),
                                    'feed_guid' => array('S' => $hid)
                                    
                );
            }

            $response = $dynamodbClient->query($options);

            //var_dump($response);
            $feeds = $response->toArray()['Items'];
            //print_r($feeds);
            $feed_comment_list = array();
            $feedOwners = array();
            $page_meta["hid"] =  "";
            $page_meta["rid1"] =  "";
            if (sizeof($feeds) > 0) {
                //Traverse through all feed and find all the available user ids. And later use these id to get information of these users.
                //print_r($feed);
                foreach ($feeds as $key => $feed) {
                    if(!empty($feed['posted_by']['N'])){
                        $feedOwners[$feed['posted_by']['N']]  = true;

                        //print_r($feed);
                    }
                }

                $userIdStr = '';
                foreach($feedOwners as $fOwner=>$value) {
                    $userIdStr = ($userIdStr!='')?$userIdStr.','.$fOwner:$fOwner;
                }
                $userRawData  = $this->getFymUserDetailTable()->getAllActiveFymUserIdsByUserIDs($userIdStr);
                $userInfo = array();
                foreach($userRawData as $uData) {
                    $userInfo[$uData['u_id']] = $uData;
                }

                $preview_profile_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
                $feed_bucket_url         = $config['feed_photo_Settings']['thumbs'][0]['feed200']['bucket'];

                foreach ($feeds as $key => $feedItem) {
                  $default_width = $config['feed_photo_Settings']['thumbs'][0]['feed200']['width'];
                  if($feedItem['status_id']['N']==1){
                    $feed_comment["feed_comment_id"] = $feedItem['feed_comment_guid']["S"];
                    $feed_comment["comment"] = $feedItem['data']["S"];
                    $feed_comment["feed_image"] = "";
                    $feed_comment["feed_image_width"] = 0;
                    $feed_comment["feed_image_height"] = 0;
                    $feed_comment["created_date"] = $feedItem['comment_created_date']["S"];
                    $feed_comment["status"] = $feedItem['status_id']['N'];

                    $creatorId = $feedItem['posted_by']['N'];
                    if (isset($userInfo[$creatorId])) {
                        $creator = $userInfo[$creatorId];
                    } else {
                        continue;
                    }

                    //$creator
                    $user_image_url = empty($creator['profile_photo'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$creator['profile_photo'];
                    $feed_comment["user_id"]        =  $creator['user_id'];
                    $feed_comment["user_name"]      =  $creator['username'];
                    $feed_comment["profile_photo"]  =  $user_image_url;

                    if (isset($feedItem['media'])) {
                        $feed_comment["feed_image"] =  !empty($feedItem['media']['M']['file']['S'])?$config['aws_s3_path'].'/'.$feed_bucket_url.'/'.$feedItem['media']['M']['file']['S']:"";
                        $feed_comment["feed_image_width"] =  $feedItem['media']['M']['width']['N'];
                        $feed_comment["feed_image_height"] =  $feedItem['media']['M']['height']['N'];

                        if (!empty($feed_comment['feed_image_width']) && $feed_comment['feed_image_width'] > 0 ) {
                             $height = $feed_comment['feed_image_height']/($feed_comment['feed_image_width']/$default_width);

                        } else {
                            $height = $default_width = 0;
                        }

                        $feed_comment["feed_image_width"] =  $default_width;
                        $feed_comment["feed_image_height"] =  $height;


                    }
                   
                    $feed_comment["inspire_count"] = "0";
                    $feed_comment["like_count"] = "0";

                    array_push($feed_comment_list, $feed_comment);
                    
                }
                
                if (isset($response['LastEvaluatedKey'])) {
                    $page_meta["hid"] =  $response['LastEvaluatedKey']['feed_guid']['S'];
                    $page_meta["rid1"] =  $response['LastEvaluatedKey']['created_date']['N'];
                }
              }
            }
            return array(
                'page_meta'=>$page_meta, 'meta'           => array('status'           => 'OK', 'code'           => 200, 'methodName'           => 'getFeedComments'),
                'comments'       => $feed_comment_list,
                'total_comments' => 0
            );
        } catch( \Exception $ex) {
            echo "Comment get". $ex->getMessage();
        }

        exit;


        $feed_info = $this->getFeedMapper()->getFeedByFeedGuid($data['feed_id']);
        if (!$feed_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'Feed not exists.');
        }

        $sql = "SELECT  SQL_CALC_FOUND_ROWS   fd.feed_type_id, f.id AS feed_id, f.guid AS feed_guid, fd.id AS feed_comment_id,
                      fd.feed_id AS feed_data_feed_id, fd.data, fd.parent_id, fd.created_date,  fd.like_count, fd.inspire_count, fd.comment_count,
                      fdm.type as media_type, fdm.media_url,u.guid AS user_id, u.username, u.profile_photo, fdm.width as image_width, fdm.height as image_height
              FROM feed f
              JOIN feed_data fd ON f.id=fd.parent_id
              LEFT JOIN user u ON fd.user_id=u.id
              LEFT JOIN feed_data_media fdm ON fd.id=fdm.feed_data_id
              WHERE f.status_id=1 AND fd.status_id=1 AND u.status_id=1 AND f.guid=?
              ORDER BY fd.created_date DESC
              LIMIT ?, ?";

        $statement = $this->adapter->createStatement($sql, array($data['feed_id'], $data['offset'], $data['limit']));

        $result   = $statement->execute();
        $comments = $result->getResource()->fetchAll(2);

        $total_rows                 = $this->adapter->createStatement('SELECT FOUND_ROWS()  as total_rows')->execute()->getResource()->fetchAll()[0]['total_rows'];
        $comment_list               = array();
        $preview_bucket_url         = $config['feed_photo_Settings']['thumbs'][0]['feed200']['bucket'];
        $preview_profile_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];

        foreach ($comments as $comment) {
            $default_width = $config['feed_photo_Settings']['thumbs'][0]['feed200']['width'];
            if ($comment['media_type'] == 'Image') {
                $feed_image = empty($comment['media_url'])?$comment['media_url']:$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$comment['media_url']);
            } else {
                $feed_image = '';
            }

            if ($comment['image_width'] > 0 && $comment['image_width'] > 0) {
                $height = $comment['image_height']/($comment['image_width']/$default_width);
            } else {
                $height = $default_width = 0;
            }

            $profile_url = empty($comment['profile_photo'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$comment['profile_photo'];

            $comment_list[] = array('feed_comment_id' => $comment['feed_comment_id'], 'comment' => $comment['data'], 'feed_image' => $feed_image,
                'feed_image_width'                       => $default_width, 'feed_image_height'                       => floor($height),
                'created_date'                           => $comment['created_date'],
                'user_id'                                => $comment['user_id'], 'user_name'                                => $comment['username'], 'profile_photo'                                => $profile_url,
                'inspire_count'                          => $comment['inspire_count'], 'like_count'                          => $comment['like_count'],
            );
        }

        return array(
            'meta'           => array('status'           => 'OK', 'code'           => 200, 'methodName'           => 'getFeedComments'),
            'comments'       => $comment_list,
            'total_comments' => $total_rows
        );

    }

    /**
     * To delete feed
     *
     * @param array $data
     * @return Entity
     */
    public function delete($data) {
        $config = $this->getServiceLocator()->get('Config');
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);


        // $feed_id   = $data['feed_id'];
        // $options = array(
        //             'TableName' => 'hashtag',
        //             'KeyConditionExpression' => 'hashtag = :v_id',
        //             'ExpressionAttributeValues' =>  array (
        //                 ':v_id' => array('S' => 'sma')
        //             ),
        //             'ScanIndexForward'=>false,
        //             'Count'=>true,
        //             'Limit'=>100000000
        //         );
          

        // $response = $dynamodbClient->query($options);

        // //var_dump($response);
        // $hashtags = $response->toArray()['Items'];
        // print_r($hashtags);



        // die('---------------------------');    

        //$config       = $this->configValues;
        //print_r($config);

        //die('12');

        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data['user_id']);
        $feed_id   = $data['feed_id'];
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }

        $currentUserId = $user_info->id;
        //$feed_info     = $this->getFeedMapper()->getFeedByFeedGuid($feed_id);
        $feed_info = $this->getFeedMapper()->getDFeedByFeedGuid($feed_id);
        
        if (!$feed_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'Feed not exists.');
        }


        $string = !empty($feed_info['data']['S'])?$feed_info['data']['S']:'';

        
    

        if ($feed_info['user_id']['S'] != $currentUserId) {
            //return \Application\Service\FymApiProblem::ApiProblem(403, 'Permission Denied');
        }

        if ($feed_info['feed_guid']['S']!="") {

            $this->deleteHashTags($string,$currentUserId,$feed_id);
            //$this->table->update(array('status_id' => 4), array('id' => $feed_info[0]['feed_id']));
            try{ //Update processed feed status to 5 to delete
                $response = $dynamodbClient->updateItem(array(
                    'TableName' => 'feed',
                    'Key' => array(
                        'date'      =>    $feed_info['date'],
                        'created_date' => $feed_info['created_date']
                    ),
                    'AttributeUpdates' => array(
                        'status_id' => array(
                           'Action' => 'PUT',
                           'Value' => array('N' => '5'),
                        )
                    ),
                    'ReturnValues' => 'ALL_NEW'
                ));
            } catch (\Exception $ex) {
                echo 'debug 1 -> '.$ex->getMessage();
            }


            

        }

        
        return \Application\Service\FymApiResponse::FymApiResponse(array(
                'meta' => array('status' => 'OK', 'code' => 200, 'methodName' => 'deleteFeed','id'=>$feed_id),
            ));
    }

    public function deleteHashTags($string,$currentUserId,$feed_id){
        $config = $this->getServiceLocator()->get('Config');
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);


        if($string!='') {
            try{
            preg_match_all("/(#\w+)/", $string, $matches);
            if (sizeof($matches[0]) > 0) {
                $hashtags = $matches[0];

                foreach ($hashtags as $hashtag) {
                    $hashtag = substr($hashtag,1);

                    $options = array(
                                'TableName' => 'hashtag',
                                'KeyConditionExpression' => 'hashtag = :v_id',
                                'ExpressionAttributeValues' =>  array (
                                    ':v_id' => array('S' => $hashtag)
                                ),
                                'ScanIndexForward'=>false,
                                'Count'=>true,
                                'Limit'=>100000000
                            );
                      

                    $response = $dynamodbClient->query($options);

                    $results = $response->toArray()['Items'];

                    foreach ($results as $rec) {
                        if($rec['feed_guid']['S']==$feed_id && $rec['posted_by']['N']==$currentUserId){

                            try {
                                $result = $dynamodbClient->deleteItem(array(
                                    'TableName' => 'hashtag',
                                    'Key' => array(
                                       'hashtag'        => $rec['hashtag'],
                                       'created_date'   => $rec['created_date'],
                                    )
                                ));

                            }catch (\Exception $ex) {
                                echo 'dlet hash delete -> '.$ex->getMessage();
                            }

                        }
                    }

                }
            } 
        

        }  catch (\Exception $ex) {
                echo 'debug dlete hash tag -> '.$ex->getMessage();
        }

        }
        /////////////////////////////////////////////////////////
    }

    /**
     * To delete feed Comment
     *
     * @param array $data
     * @return Entity
     */
    public function deleteFeedComment($data) {
        $config = $this->getServiceLocator()->get('Config');
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);

        $user_info  = $this->getFymUserDetailTable()->getUserDetailsByGuid($data['user_id']);
        $feed_id    = $data['feed_id'];
        $comment_id = $data['list_type_id'];
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }

        $currentUserId = $user_info->id;

        $feed_info = $this->getFeedMapper()->getDFeedByFeedGuid($feed_id);


        
        if (!$feed_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'Feed not exists.');
        }

        try
        {


            $options = array(
                    'TableName' => 'feed_comment',
                    'KeyConditionExpression' => 'feed_guid = :v_id',
                    'ExpressionAttributeValues' =>  array (
                        ':v_id' => array('S' => $data['feed_id'])
                    ),
                    'ScanIndexForward'=>false,
                    'Count'=>true,
                    'Limit'=>100000000
                );
          
            if (!empty($data['hid']) && !empty($data['rid1'])) {  
                $options['ExclusiveStartKey'] = array(
                                    'created_date' => array('N' => $rid1),
                                    'feed_guid' => array('S' => $hid)
                                    
                );
            }

            $response = $dynamodbClient->query($options);

            //var_dump($response);
            $comments = $response->toArray()['Items'];



            $stat = 0;
            foreach($comments as $comment){
                
                if($comment['feed_comment_guid']['S']==$comment_id && ($comment['posted_by']['N']==$currentUserId || $feed_info['user_id']['S'] == $currentUserId) ){
                    $stat = 1;
                    

                    try { //Update processed feed status to 4
                        $response = $dynamodbClient->updateItem(array(
                            'TableName' => 'feed_comment',
                            'Key' => array(
                                    'feed_guid'    => $comment['feed_guid'],
                                    'created_date' => $comment['created_date']
                                ),
                                'AttributeUpdates' => array(
                                    'status_id' => array(
                                       'Action' => 'PUT',
                                       'Value' => array('N' => '4'),
                                    )
                                ),
                            'ReturnValues' => 'ALL_NEW'
                        ));


                        // INCREMENT COMMENT COUNT
                       // $feed_info = $this->getFeedMapper()->getDFeedByFeedGuid($feed_id);
                        @$rec->feed_data =  $feed_info;

                    
                        $this->getFeedDetailsDetailTable()->updateDynamoMotivateCount('feed',$rec, 'comment', $expression = '-');

                    } catch (\Exception $ex) {
                        echo 'debug commengt -> '.$ex->getMessage();
                    }
                }
            }

            if($stat==0){
                return \Application\Service\FymApiProblem::ApiProblem(403, 'Permission Denied');
            }

            return \Application\Service\FymApiResponse::FymApiResponse(array(
                'meta' => array('status' => 'OK', 'code' => 200, 'methodName' => 'delete Feed comment','id'=>$comment_id),
            ));



        } catch (\Exception $ex) {
                echo 'debug dlete commengt -> '.$ex->getMessage();
            }
    }
    public function deleteFeedCommentOLD($data) {
        //$config       = $this->configValues;
        $config = $this->getServiceLocator()->get('Config');
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);


        $user_info  = $this->getFymUserDetailTable()->getUserDetailsByGuid($data['user_id']);
        $feed_id    = $data['feed_id'];
        $comment_id = $data['list_type_id'];
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }

        $currentUserId = $user_info->id;

        $feed_info = $this->getFeedMapper()->getDFeedByFeedGuid($feed_id);
        
        if (!$feed_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'Feed not exists.');
        }

        $comment = $this->getFeedMapper()->getDFeedCommentByFeedGuid($feed_id);
        if (!$comment) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'Feed comment not exists.');
        }


        print_r($comment);

        die('');

        //|| $comment->user_id == $currentUserId
        if ($feed_info['user_id']['S'] == $currentUserId ) {
            echo "insis";
            //$this->getFeedDetailsDetailTable()->deleteFeedComment($comment_id, $comment->feed_id);
            try { //Update processed feed status to 4
                $response = $dynamodbClient->updateItem(array(
                    'TableName' => 'feed_comment',
                    'Key' => array(
                            'feed_guid'    => $feed_info['feed_guid'],
                            'created_date' => $feed_info['created_date']
                        ),
                        'AttributeUpdates' => array(
                            'status_id' => array(
                               'Action' => 'PUT',
                               'Value' => array('N' => '4'),
                            )
                        ),
                    'ReturnValues' => 'ALL_NEW'
                ));

            } catch (\Exception $ex) {
                echo 'debug commengt -> '.$ex->getMessage();
            }
        } else {
            return \Application\Service\FymApiProblem::ApiProblem(403, 'Permission Denied');
        }

        return \Application\Service\FymApiResponse::FymApiResponse(array(
                'meta' => array('status' => 'OK', 'code' => 200, 'methodName' => 'delete Feed comment','id'=>$comment_id),
            ));



    }

    /**
     * To fetch All Feed
     *
     * @param array $data
     * @return Entity
     */
    

    

    public function fetchAll($data,$feed_mode='feed') {
       
        $config = $this->getServiceLocator()->get('Config');
        $this->getAdapter();
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data['user_id']);
        //$feed_id   = $data['feed_id'];

        $hid   = $data['hid'];
        $rid1   = $data['rid1'];
        $rid2   = $data['rid2'];
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $currentUserId = $user_info->id;
        $logged_in_user_id = $data['logged_in_user_id'];
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);
        
        try
        {
            if ($feed_mode =='feed')  {
                $options = array(
                        'TableName' => 'user_notification',
                        'KeyConditionExpression' => 'user_id = :v_id',
                        'ExpressionAttributeValues' =>  array (
                            ':v_id' => array('N' => $currentUserId)
                        ),
                        'ScanIndexForward'=>false,
                        'Count'=>true,
                        'Limit'=>10
                    );
              
                if (!empty($data['hid']) && !empty($data['rid1'])) {  
                    $options['ExclusiveStartKey'] = array(
                                        'created_date' => array('N' => $rid1),
                                        'user_id' => array('N' => $hid)
                                        
                    );
                }
            } else {
                //Un commented to resolve self profile issue (10th june 2016)
                $options = array(
                    'TableName' => 'user_notification',
                    'IndexName' => 'selfProfileIndex',
                    'KeyConditionExpression' => 'user_id = :v_user_id',
                    'FilterExpression' => 'creator_id = :v_creator_id ',
                    'ExpressionAttributeValues' =>  array (
                        ':v_user_id' => array('N' => $currentUserId),
                        ':v_creator_id' => array('N' => $currentUserId)
                    ),
                    'Select' => 'ALL_ATTRIBUTES',
                    'ScanIndexForward' => false,
                    'Count'=>true,
                    'Limit'=>30
                );

                //Commented to resolve self profile issue (10th june 2016)
                // $options = array(
                //     'TableName' => 'user_notification',
                //     'KeyConditionExpression' => 'user_id = :v_id',
                //     'ExpressionAttributeValues' =>  array (
                //         ':v_id' => array('N' => $currentUserId)
                //     ),
                //     'ScanIndexForward'=>false,
                //     'Count'=>true,
                //     'Limit'=>10
                // );


              
                
                if (!empty($data['hid']) && !empty($data['rid1'])) {  
                    $options['ExclusiveStartKey'] = array(
                                        'created_date' => array('N' => $rid1),
                                        'user_id' => array('N' => $hid),
                                        //'creator_id' => array('N' => $rid2)
                                        
                    );

                    if (!empty($rid2)) {
                        $options['ExclusiveStartKey']['creator_id'] = array('N' => $rid2);
                    }
                }  
            }

            $response = $dynamodbClient->query($options);
            //print_r($response);
            $feeds = $response->toArray()['Items'];
            $feed_list = array();
            $page_meta["hid"] =  "";
            $page_meta["rid1"] =  "";
            $page_meta["rid2"] =  "";
            if (sizeof($feeds) > 0 ){
                $feedOwners = array();
                
                $motivationSearchKeys = array();
                $feedDetailsKeys = array();
                //Traverse through all feed and find all the available user ids. And later use these id to get information of these users.
                foreach ($feeds as $key => $feed) {
                    if ($feed['type']['N']==1 || $feed['type']['N']==2 || $feed['type']['N']==3 || $feed['type']['N']==4 || $feed['type']['N']==6) {
                        $feedOwners[$feed['creator_id']['N']]  = true;
                    } else if ($feed['type']['N']==5) {
                        $feedOwners[$feed['creator_id']['N']]  = true;
                        $feedOwners[$feed['friends']['M']['friend1']['N']]  = true;
                        $feedOwners[$feed['friends']['M']['friend2']['N']]  = true;
                    }

                    //Search feed motivation table to check whether the current user has motivated that feed in like or inspire
                    $motivationSearchKeys[] = array(
                        'id'   => array('S' => $feed['feed_id']['S'].'-'.$logged_in_user_id),
                        'motivation_type'  => array('S' => 'like'),
                    );
                    $motivationSearchKeys[] = array(
                        'id'   => array('S' => $feed['feed_id']['S'].'-'.$logged_in_user_id),
                        'motivation_type'  => array('S' => 'inspire'),
                    );

                    $feedDetailsKeys[] = array(
                        'date'   => array('S' => $feed['date']['S']),
                        'created_date'  => array('N' => $feed['created_date']['N']),
                    );
                }
                
                $motivatedResult = $dynamodbClient->batchGetItem(array(
                    'RequestItems' => array(
                        'feed_motivation' => array(
                            'Keys'           => $motivationSearchKeys,
                            'ConsistentRead' => true
                        )
                    )
                ));

                $feedDetailsResult = $dynamodbClient->batchGetItem(array(
                    'RequestItems' => array(
                        'feed' => array(
                            'Keys'           => $feedDetailsKeys,
                            'ConsistentRead' => true
                        )
                    )
                ));
               
                //die('111');
                $feedInfo = array();
                if (isset($feedDetailsResult->toArray()['Responses']['feed']) && sizeof($feedDetailsResult->toArray()['Responses']['feed']) > 0) {
                    foreach ($feedDetailsResult->toArray()['Responses']['feed'] as $feedDet) {
                                $feedInfo[$feedDet['feed_guid']['S']] = $feedDet;
                                $feedInfo[$feedDet['feed_guid']['S']]['status'] = $feedDet['status_id']['N'];
                    }
                } else {
                    continue;
                }

                //print_r($feedInfo);

                //die('sma');

                $motivations = array();
               
                foreach ($motivatedResult['Responses']['feed_motivation'] as $key => $value) {
                    $motivations[$value['id']['S']][$value['motivation_type']['S']] = true;
                }
                
                $userIdStr = '';
                foreach($feedOwners as $fOwner=>$value) {
                    $userIdStr = ($userIdStr!='')?$userIdStr.','.$fOwner:$fOwner;
                }
                $userRawData  = $this->getFymUserDetailTable()->getAllActiveFymUserIdsByUserIDs($userIdStr);
                $userInfo = array();
                foreach($userRawData as $uData) {
                    $userInfo[$uData['u_id']] = $uData;
                }
                
                $feed = null;
                $preview_profile_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
                $preview_bucket_url_ad      = $config['ad_photo_Settings_guestpost']['thumbs'][0]['ad100']['bucket'];
                $preview_bucket_url_ad_large= $config['ad_photo_Settings_guestpost']['thumbs'][2]['ad600']['bucket'];
                $feed_bucket_url            = $config['feed_photo_Settings']['thumbs'][0]['feed200']['bucket'];
                $feed_bucket_large_url      = $config['feed_photo_Settings']['thumbs'][1]['feed600']['bucket'];
                $business_bucket_url        = $config['business_photo_Settings']['thumbs'][0]['business100']['bucket'];
                //Traverse through all feeds and build the final feed response
                foreach ($feeds as $key => $feedItem) {
                  $fid = $feedItem['feed_id']['S'];
                  if($feedInfo[$fid]['status']!=5){
                    
                    $feed["cd"] =  $feedItem['created_date']['N'];
                    $feed["feed_id"] = $feedItem['feed_id']['S'];
                    $feed["feed_type"] =  "";
                    $feed["created_date"] = $feedItem['feed_created_date']['S'];
                    $feed["feed_data"] =  "";
                    $feed["inspire_count"] =  !empty($feedInfo[$fid]['inspire_count']['N'])?$feedInfo[$fid]['inspire_count']['N']:0;
                    $feed["like_count"] =  !empty($feedInfo[$fid]['like_count']['N'])?$feedInfo[$fid]['like_count']['N']:0;
                    $feed["comment_count"] =  !empty($feedInfo[$fid]['comment_count']['N'])?$feedInfo[$fid]['comment_count']['N']:0;
                    $feed["friend"] =  "";
                    $feed["friend_id1"] =  "";
                    $feed["friend_name1"] =  "";
                    $feed["friend_photo1"] =  "";
                    $feed["friend_id2"] =  "";
                    $feed["friend_name2"] =  "";
                    $feed["friend_photo2"] =  "";
                    $feed["checkin_user_id"] =  "";
                    $feed["checkin_user_name"] =  "";
                    $feed["checkin_profile_photo"] =  "";
                    $feed["checkin_business"] =  "";
                    $feed["checkin_business_id"] =  "";
                    $feed["checkin_business_image"] =  "";
                    $feed["user_id"] =  "";
                    $feed["user_name"] =  "";
                    $feed["profile_photo"] =  "";
                    $feed["exc_user_id"] =  "";
                    $feed["exc_user_name"] =  "";
                    $feed["exc_profile_photo"] =  "";
                    $feed["exercise"] =  "";
                    $feed["feed_image"] =  "";
                    $feed["feed_image_large"] =  "";
                    $feed["feed_image_width"] =  0;
                    $feed["feed_image_height"] =  0;
                    $feed["goal_date"] =  "";
                    $feed["ad_id"] =  "";
                    $feed["like_status"] =  isset($motivations[$feedItem['feed_id']['S'].'-'.$logged_in_user_id]['like'])?true:false;
                    $feed["inspire_status"] =  isset($motivations[$feedItem['feed_id']['S'].'-'.$logged_in_user_id]['inspire'])?true:false;
                  


                    $creatorId = $feedItem['creator_id']['N'];
                    if (isset($userInfo[$creatorId])) {
                        $creator = $userInfo[$creatorId];
                    } else {
                        continue;
                    }

                    //$creator
                    $user_image_url = empty($creator['profile_photo'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$creator['profile_photo'];
                    $feed["user_id"]        =  $creator['user_id'];
                    $feed["user_name"]      =  $creator['username'];
                    $feed["profile_photo"]  =  $user_image_url;
                    //var_dump($creator);
                   
                    if ($feedItem['type']['N']==1) {
                        $feed["feed_type"] =  "text";
                        $feed["feed_data"] =  $feedItem['data']['S'];
                        
                        if (isset($feedItem['feed_image'])) {
                            $feed["feed_image"] =  !empty($feedItem['feed_image']['M']['file']['S'])?$config['aws_s3_path'].'/'.$feed_bucket_url.'/'.$feedItem['feed_image']['M']['file']['S']:"";
                            $feed["feed_image_large"] =  !empty($feedItem['feed_image']['M']['file']['S'])?$config['aws_s3_path'].'/'.$feed_bucket_large_url.'/'.$feedItem['feed_image']['M']['file']['S']:"";
                            $feed["feed_image_width"] =  $feedItem['feed_image']['M']['width']['N'];
                            $feed["feed_image_height"] =  $feedItem['feed_image']['M']['height']['N'];


                        }
                       
                    } else if ($feedItem['type']['N']==2) {
                        $feed["feed_type"] =  "goal";
                        $feed["goal_date"] =  $feedItem['goal_date']['S'];
                    } else if ($feedItem['type']['N']==3) {
                        $feed["feed_type"] =  "exercise";
                        $feed["exc_user_id"]        =  $creator['user_id'];
                        $feed["exc_user_name"]      =  $creator['username'];
                        $feed["exc_profile_photo"]  =  $user_image_url;
                    } else if ($feedItem['type']['N']==4) {
                        $feed["feed_type"] =  "checkin";

                        $feed["checkin_user_id"]        =  $creator['user_id'];
                        $feed["checkin_user_name"]      =  $creator['username'];
                        $feed["checkin_profile_photo"]  =  $user_image_url;
                        $feed["checkin_business"]       =  !empty($feedItem['business']['M']['business']['S'])?$feedItem['business']['M']['business']['S']:'';
                        $feed["checkin_business_id"]    =  !empty($feedItem['business']['M']['business_id']['S'])?$feedItem['business']['M']['business_id']['S']:"";
                        $feed["checkin_business_image"] = !(empty($feedItem['business']['M']['business_image']))?$config['aws_s3_path'].'/'.$business_bucket_url.'/'.$feedItem['business']['M']['business_image']['S']:"";
                    
                    } else if ($feedItem['type']['N']==5) {
                        $feed["feed_type"] =  "friends";
                        $friend1 = $userInfo[$feedItem['friends']['M']['friend1']['N']];
                        $feed["friend_id1"] =  $friend1['user_id'];
                        $feed["friend_name1"] =  $friend1['username'];
                        $feed["friend_photo1"] =  empty($friend1['profile_photo'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$friend1['profile_photo'];
                        @$friend2 = $userInfo[$feedItem['friends']['M']['friend2']['N']];
                        $feed["friend_id2"] =  $friend2['user_id'];
                        $feed["friend_name2"] =  $friend2['username'];
                        $feed["friend_photo2"] =  empty($friend2['profile_photo'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$friend2['profile_photo'];
                    } else if ($feedItem['type']['N']==6) {
                        $guest_ad_id = isset($feedItem['object_id'])?$feedItem['object_id']['N']:0;
                        
                        if (empty($guest_ad_id)) {
                            continue;
                        }
                        $guest_post_info = $this->getFymUserDetailTable()->getFeedGuestPostAdDetails($guest_ad_id); 
                        if(!$guest_post_info) {
                            continue;
                        }
                        $feed["feed_type"] =  "guest_post";
                        $feed["ad_id"] =  $feedItem['ad']['M']['ad_id']['S'];
                        $feed["feed_image"] =  empty($feedItem['ad']['M']['ad_image']['S'])?'':$config['aws_s3_path'].'/'.$preview_bucket_url_ad.'/'.$feedItem['ad']['M']['ad_image']['S'];
                        $feed["feed_image_large"] =  empty($feedItem['ad']['M']['ad_image']['S'])?'':$config['aws_s3_path'].'/'.$preview_bucket_url_ad_large.'/'.$feedItem['ad']['M']['ad_image']['S'];
                        $feed["feed_data"] =  $feedItem['ad']['M']['ad_content']['S'];
                    }

                    array_push($feed_list, $feed);

                    if (isset($response['LastEvaluatedKey'])) {
                        $page_meta["hid"] =  $response['LastEvaluatedKey']['user_id']['N'];
                        $page_meta["rid1"] =  $response['LastEvaluatedKey']['created_date']['N'];
                        $page_meta["rid2"] =  !empty($response['LastEvaluatedKey']['creator_id']['N'])?$response['LastEvaluatedKey']['creator_id']['N']:'';
                    }
                    
                }
                
                
                
              }      

                
            }
            return array('page_meta'  => $page_meta, 
                'meta'       => array('status'       => 'OK', 'code'       => 200, 'methodName'       => ($feed_mode=='feed')?'getFeed':'getUserFeed'),
                'feeds'      => $feed_list,

                'total_feed' => 0
            );
            //var_dump($feeds);
        } catch (\Exception $ex) {
            echo 'get user notification -> '.$ex->getMessage();
        }


        exit;
        

    }

    
    /**
     * To feed for user profile
     *
     * @param array $data
     * @return Entity
     */
    public function getUserProfileFeed($data) {
        
        $config = $this->getServiceLocator()->get('Config');
        $this->getAdapter();
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data['guid']);

        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $currentUserId = $user_info->id;
        $data['user_id'] = $user_info->guid;
        return $this->fetchAll($data, 'self_feed');
        

    } 
    public function getUserProfileFeedOld($data) {
        $config = $this->getServiceLocator()->get('Config');
        $this->getAdapter();
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data['guid']);

        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $currentUserId = $user_info->id;

        $sql = "SELECT  SQL_CALC_FOUND_ROWS f.guid AS feed_id, fd.feed_type_id,ft.name AS feed_type,  fd.feed_type_id, fd.data,  fd.like_count, fd.inspire_count, fd.comment_count, fd.created_date, frds.friend_id, frds.user_id,
                u.username AS txt_username, u.guid AS txt_userid, u.profile_photo AS txt_profile_photo,
                fUser1.username AS username1, fUser1.guid AS userid1, fUser1.first_name AS first_name1, fUser1.last_name AS last_name1, fUser1.profile_photo AS profile_photo1,
                fUser2.username AS username2, fUser2.guid AS userid2, fUser2.first_name AS first_name2, fUser2.last_name AS last_name2, fUser2.profile_photo AS profile_photo2,

                chkUser.username AS chk_username, chkUser.guid AS chk_userid,  chkUser.profile_photo AS chk_profile_photo, b.guid AS business_id,  b.name AS business,
                excUser.username AS exc_username, excUser.guid AS exc_userid,  excUser.profile_photo AS exc_profile_photo, e.guid AS exercise_id,  e.name AS exercise,
                ufl.meal_date,
                fdm.type as media_type, fdm.media_url, fdm.width as image_width, fdm.height as image_height,
                IF(fddLike.type IS NULL,FALSE,TRUE) AS like_status, IF(fddInspire.type IS NULL,FALSE,TRUE) AS inspire_status

                FROM  feed f
                JOIN feed_data fd ON f.id=fd.feed_id AND fd.parent_id=0
                JOIN feed_type ft ON fd.feed_type_id=ft.id
                LEFT JOIN friends frds ON fd.object_id=frds.id AND fd.feed_type_id=5
                LEFT JOIN user fUser1 ON frds.user_id = fUser1.id
                LEFT JOIN user fUser2 ON frds.friend_id = fUser2.id

                LEFT JOIN user_check_in uci ON fd.object_id=uci.id AND fd.feed_type_id=4
                LEFT JOIN user chkUser ON uci.user_id=chkUser.id
                LEFT JOIN business b ON uci.business_id=b.id

                LEFT JOIN user_exercise_log uel ON fd.object_id=uel.id
                LEFT JOIN user excUser ON uel.user_id=excUser.id
                LEFT JOIN exercise e ON uel.exercise_id=e.id
                LEFT JOIN user_food_log ufl ON fd.object_id=ufl.id
                LEFT JOIN user u on fd.user_id=u.id
                LEFT JOIN feed_data_media fdm ON fd.id=fdm.feed_data_id
                LEFT JOIN feed_data_details fddLike ON fd.id=fddLike.feed_data_id AND fddLike.type='Like' AND fddLike.user_id=? AND fddLike.status_id=1
                LEFT JOIN feed_data_details fddInspire ON fd.id=fddInspire.feed_data_id AND fddInspire.type='Inspire' AND fddInspire.user_id=? AND fddInspire.status_id=1

                WHERE f.user_id=? AND f.status_id=1
                GROUP BY  fd.feed_id
                ORDER BY fd.created_date DESC
                LIMIT ?, ?";

        $statement = $this->adapter->createStatement($sql, array($currentUserId, $currentUserId, $currentUserId, (int) $data['offset'], (int) $data['limit']));
        $result    = $statement->execute();
        $feeds     = $result->getResource()->fetchAll(2);

        $total_rows = $this->adapter->createStatement('SELECT FOUND_ROWS()  as total_rows')->execute()->getResource()->fetchAll()[0]['total_rows'];

        $preview_bucket_url         = $config['feed_photo_Settings']['thumbs'][0]['feed200']['bucket'];
        $preview_profile_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];

        $feed_list = array();
        foreach ($feeds as $feed) {
            $default_width = $config['feed_photo_Settings']['thumbs'][0]['feed200']['width'];
            $feed          = $this->formatString($feed);

            $friend1_image_url  = empty($feed['profile_photo1'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$feed['profile_photo1'];
            $friend2_image_url  = empty($feed['profile_photo2'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$feed['profile_photo2'];
            $exc_user_image_url = empty($feed['exc_profile_photo'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$feed['exc_profile_photo'];
            $chk_user_image_url = empty($feed['chk_profile_photo'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$feed['chk_profile_photo'];
            $txt_user_image_url = empty($feed['txt_profile_photo'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$feed['txt_profile_photo'];

            if ($feed['media_type'] == 'Image') {
                $feed_image = empty($feed['media_url'])?$feed['media_url']:$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$feed['media_url']);
            } else {
                $feed_image = '';
            }

            if ($feed['image_width'] > 0 ) {
                $height = $feed['image_height']/($feed['image_width']/$default_width);
            } else {
                $height = $default_width = 0;
            }

            $feed_list[] = array('feed_id' => $feed['feed_id'], 'feed_type' => $feed['feed_type'], 'created_date' => $feed['created_date'],
                'feed_data'                   => urldecode($feed['data']), 'inspire_count'                   => $feed['inspire_count'], 'like_count'                   => $feed['like_count'], 'comment_count'                   => $feed['comment_count'],
                'friend_id1'                  => $feed['userid1'], 'friend_name1'                  => $feed['username1'], 'friend_photo1'                  => $friend1_image_url,
                'friend_id2'                  => $feed['userid2'], 'friend_name2'                  => $feed['username2'], 'friend_photo2'                  => $friend2_image_url,
                'checkin_user_id'             => $feed['chk_userid'], 'checkin_user_name'             => $feed['chk_username'], 'checkin_profile_photo'             => $chk_user_image_url, 'checkin_business'             => $feed['business'],
                'user_id'                     => $feed['txt_userid'], 'user_name'                     => $feed['txt_username'], 'profile_photo'                     => $txt_user_image_url,
                'exc_user_id'                 => $feed['exc_userid'], 'exc_user_name'                 => $feed['exc_username'], 'exc_profile_photo'                 => $exc_user_image_url, 'exercise'                 => $feed['exercise'], 'feed_image'                 => $feed_image,
                'feed_image_width'            => $default_width, 'feed_image_height'            => floor($height), 'goal_date'            => $feed['meal_date'],
                'ad_id'                       => '',
                'comment_count'               => $feed['comment_count'], 'comment_count'               => $feed['comment_count'], 'like_status'               => (bool) $feed['like_status'], 'inspire_status'               => (bool) $feed['inspire_status'],
            );
        }

        return array(
            'meta'       => array('status'       => 'OK', 'code'       => 200, 'methodName'       => 'getUserFeed'),
            'feeds'      => $feed_list,
            'total_feed' => $total_rows
        );

    }


    public function fetchAllOld($data) {
        $config = $this->getServiceLocator()->get('Config');
        $this->getAdapter();
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data['user_id']);
        $feed_id   = $data['feed_id'];
        if (!$user_info) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
        }
        $currentUserId = $user_info->id;
        $sql           = "SELECT  SQL_CALC_FOUND_ROWS f.guid AS feed_id, uf.following_user_id, fd.feed_type_id,ft.name AS feed_type,  fd.feed_type_id, fd.data,  fd.like_count, fd.inspire_count, fd.comment_count, fd.created_date, frds.friend_id, frds.user_id,
                u.username AS txt_username, u.guid AS txt_userid, u.profile_photo AS txt_profile_photo,
                fUser1.username AS username1, fUser1.guid AS userid1, fUser1.first_name AS first_name1, fUser1.last_name AS last_name1, fUser1.profile_photo AS profile_photo1,
                fUser2.username AS username2, fUser2.guid AS userid2, fUser2.first_name AS first_name2, fUser2.last_name AS last_name2, fUser2.profile_photo AS profile_photo2,

                chkUser.username AS chk_username, chkUser.guid AS chk_userid, chkUser.profile_photo AS chk_profile_photo, b.guid AS business_id,  b.name AS business,
                excUser.username AS exc_username, excUser.guid AS exc_userid, excUser.profile_photo AS exc_profile_photo, e.guid AS exercise_id,  e.name AS exercise,
                ufl.meal_date,
                fdm.type as media_type, fdm.media_url, fdm.width as image_width, fdm.height as image_height,
                ad.guid AS ad_id, ad.content AS ad_content, adi.file AS ad_image,
                IF(fddLike.type IS NULL,FALSE,TRUE) AS like_status, IF(fddInspire.type IS NULL,FALSE,TRUE) AS inspire_status

                FROM feed f
                LEFT JOIN user_follower uf ON (uf.following_user_id=f.user_id OR uf.following_user_id=f.user_id2 )
                LEFT JOIN feed_data fd ON f.id=fd.feed_id AND fd.parent_id=0
                LEFT JOIN feed_type ft ON fd.feed_type_id=ft.id
                LEFT JOIN friends frds ON fd.object_id=frds.id AND fd.feed_type_id=5
                LEFT JOIN `user` fUser1 ON frds.user_id = fUser1.id
                LEFT JOIN `user` fUser2 ON frds.friend_id = fUser2.id

                LEFT JOIN user_check_in uci ON fd.object_id=uci.id AND fd.feed_type_id=4
                LEFT JOIN `user` chkUser ON uci.user_id=chkUser.id
                LEFT JOIN business b ON uci.business_id=b.id

                LEFT JOIN user_exercise_log uel ON fd.object_id=uel.id
                LEFT JOIN `user` excUser ON uel.user_id=excUser.id
                LEFT JOIN exercise e ON uel.exercise_id=e.id

                LEFT JOIN user_food_log ufl ON fd.object_id=ufl.id

                LEFT JOIN user u on fd.user_id=u.id

                LEFT JOIN feed_data_media fdm ON fd.id=fdm.feed_data_id

                LEFT JOIN feed_data_details fddLike ON fd.id=fddLike.feed_data_id AND fddLike.type='Like' AND fddLike.user_id=? AND fddLike.status_id=1
                LEFT JOIN feed_data_details fddInspire ON fd.id=fddInspire.feed_data_id AND fddInspire.type='Inspire' AND fddInspire.user_id=? AND fddInspire.status_id=1

                LEFT JOIN ad ON fd.object_id=ad.id AND ad.status_id=1 AND fd.feed_type_id=6
                LEFT JOIN ad_image adi ON ad.id=adi.ad_id

                WHERE (uf.user_id=? OR  f.user_id=? OR u.role='Admin') AND f.status_id=1  AND u.status_id=1 AND
                IF (u.role='User', (uf.status_id=1 AND f.created_date > uf.created_at)  ,1)
                GROUP BY  fd.feed_id
                ORDER BY fd.created_date DESC

                LIMIT ?, ?";
        //IF (u.role='User',uf.status_id=1,1)
        $statement = $this->adapter->createStatement($sql, array($currentUserId, $currentUserId, $currentUserId, $currentUserId, (int) $data['offset'], (int) $data['limit']));

        $result = $statement->execute();
        $feeds  = $result->getResource()->fetchAll(2);
        //var_dump($feeds);

        $total_rows = $this->adapter->createStatement('SELECT FOUND_ROWS()  as total_rows')->execute()->getResource()->fetchAll()[0]['total_rows'];

        $preview_bucket_url         = $config['feed_photo_Settings']['thumbs'][0]['feed200']['bucket'];
        $preview_profile_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
        $preview_bucket_url_ad      = $config['ad_photo_Settings_guestpost']['thumbs'][1]['ad1400']['bucket'];
        $feed_list                  = array();
        foreach ($feeds as $feed) {
            $default_width = $config['feed_photo_Settings']['thumbs'][0]['feed200']['width'];
            $feed          = $this->formatString($feed);

            if ($feed['feed_type_id'] == 1) {
                $feed_image = empty($feed['media_url'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$feed['media_url']);
                $feed_data  = urldecode($feed['data']);
            } else if ($feed['feed_type_id'] == 6) {
                $feed_image = empty($feed['ad_image'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url_ad.'/'.$feed['ad_image']);
                $feed_data  = $feed['ad_content'];
            } else {
                $feed_image = '';
                $feed_data  = '';
            }

            if ($feed['image_width'] > 0 ) {
                $height = $feed['image_height']/($feed['image_width']/$default_width);
            } else {
                $height = $default_width = 0;
            }

            $friend1_image_url  = empty($feed['profile_photo1'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$feed['profile_photo1'];
            $friend2_image_url  = empty($feed['profile_photo2'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$feed['profile_photo2'];
            $exc_user_image_url = empty($feed['exc_profile_photo'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$feed['exc_profile_photo'];
            $chk_user_image_url = empty($feed['chk_profile_photo'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$feed['chk_profile_photo'];
            $txt_user_image_url = empty($feed['txt_profile_photo'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$feed['txt_profile_photo'];

            $feed_list[] = array('feed_id' => $feed['feed_id'], 'feed_type' => $feed['feed_type'], 'created_date' => $feed['created_date'],
                'feed_data'                   => $feed_data, 'inspire_count'                   => $feed['inspire_count'], 'like_count'                   => $feed['like_count'], 'comment_count'                   => $feed['comment_count'],
                'friend_id1'                  => $feed['userid1'], 'friend_name1'                  => $feed['username1'], 'friend_photo1'                  => $friend1_image_url,
                'friend_id2'                  => $feed['userid2'], 'friend_name2'                  => $feed['username2'], 'friend_photo2'                  => $friend2_image_url,
                'checkin_user_id'             => $feed['chk_userid'], 'checkin_user_name'             => $feed['chk_username'], 'checkin_profile_photo'             => $chk_user_image_url, 'checkin_business'             => $feed['business'],
                'user_id'                     => $feed['txt_userid'], 'user_name'                     => $feed['txt_username'], 'profile_photo'                     => $txt_user_image_url,
                'exc_user_id'                 => $feed['exc_userid'], 'exc_user_name'                 => $feed['exc_username'], 'exc_profile_photo'                 => $exc_user_image_url, 'exercise'                 => $feed['exercise'],
                'feed_image'                  => $feed_image, 'feed_image_width'                  => $default_width, 'feed_image_height'                  => floor($height),
                'goal_date'                   => $feed['meal_date'],
                'ad_id'                       => $feed['ad_id'],
                'comment_count'               => $feed['comment_count'], 'comment_count'               => $feed['comment_count'], 'like_status'               => (bool) $feed['like_status'], 'inspire_status'               => (bool) $feed['inspire_status'],
            );
        }

        return array(
            'meta'       => array('status'       => 'OK', 'code'       => 200, 'methodName'       => 'getFeed'),
            'feeds'      => $feed_list,
            'total_feed' => $total_rows
        );

    }


    public function formatString($row) {
        foreach ($row as $key => $value) {
            if ($value === null) {
                $row[$key] = '';
            }
        }
        return $row;
    }

    /*Return feed and its data. This will not return the comments*/
    public function getFeed($feed_id) {
        $this->getAdapter();
        $query = "SELECT f.id AS feed_id, f.guid as feed_guid, f.user_id , fd.feed_type_id, fd.data, fd.like_count, fd.inspire_count
                FROM feed f
                JOIN feed_data fd ON f.id=fd.feed_id
                WHERE f.status_id=1 AND fd.status_id=1 AND f.id=?";
        $statement = $this->adapter->createStatement($query, array($feed_id));
        $result    = $statement->execute();
        return $result->getResource()->fetchAll(2);

    }

    /*Return feed and its data. This will not return the comments*/
    public function getFeedByFeedGuid($feed_guid) {
        $this->getAdapter();
        $query = "SELECT f.id AS feed_id, f.guid as feed_guid, f.user_id , fd.feed_type_id, fd.data, fd.id as feed_data_id, fd.like_count, fd.inspire_count
                FROM feed f
                JOIN feed_data fd ON f.id=fd.feed_id
                WHERE f.status_id=1 AND fd.status_id=1 AND fd.parent_id=0 AND f.guid=?";

        $statement = $this->adapter->createStatement($query, array($feed_guid));
        $result    = $statement->execute();
        return $result->getResource()->fetchAll(2);

    }

    public function getDFeedByFeedGuid($feed_guid) {
        $config = $this->getServiceLocator()->get('Config');
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);
        
        try {
            $results = $dynamodbClient->getIterator('Scan', array(
                'TableName' => 'feed',
                'ScanFilter' => array(
                    'feed_guid' => array(
                        'AttributeValueList' => array(
                            array('S' => $feed_guid)
                        ),
                        'ComparisonOperator' => 'EQ'
                    )
                )
            ))->toArray();

            if (!empty($results)) {
                return $results[0];
            } else {
                return null;
            }
           
            
        } catch (\Exception $ex) {
            $ex->getMessage();
            return null;
        }
        
    }

    public function getDFeedCommentByFeedGuid($feed_comment_guid) {

        $config = $this->getServiceLocator()->get('Config');
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);
        
        try {
            
            $result = $dynamodbClient->query(array(
                'TableName' => 'feed_comment',
                'KeyConditionExpression' => 'feed_guid = :fguid ',
                'ExpressionAttributeValues' =>  array(
                    ':fguid' => array('S' => $feed_comment_guid),
                ),
                'ConsistentRead' => false
            ));

            //print_r($result['Items']);

            if (isset($result['Count']) && $result['Count'] > 0) {
                return $result['Items'][0];
            } else {
                return null;
            }
           
            
        } catch (\Exception $ex) {
            echo $ex->getMessage();
            return null;
        }
        
    }

    /**
     * Get motivate Feed
     *
     * @param int $user_id
     * @param int $feed_data_id
     * @param string $motivate_type
     * @return Entity
     */
    public function motivateFeed($user_id, $feed_data_id, $motivate_type) {
        $this->getAdapter();

        if ($motivate_type == 'Like' || $motivate_type == 'Unlike') {
            $temp_motivate_type = 'Like';
        } else {
            $temp_motivate_type = 'Inspire';
        }

        $query = "SELECT * FROM feed_data_details fdt
                WHERE fdt.status_id=1 AND fdt.user_id=$user_id AND fdt.feed_data_id = $feed_data_id AND fdt.type='$temp_motivate_type'";

        $statement       = $this->adapter->createStatement($query);
        $result          = $statement->execute();
        $motivate_status = $result->getResource()->fetchAll(2);

        if ($motivate_status) {
            $motivate_status = $motivate_status[0];
            if ($motivate_type == 'Like' || $motivate_type == 'Inspire') {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid motivate status');
            }
        } else {
            if ($motivate_type == 'Unlike' || $motivate_type == 'UnInspire') {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid motivate status');
            }
        }

        $apiData['feed_data_id'] = $feed_data_id;
        $apiData['user_id']      = $user_id;
        $apiData['type']         = $motivate_type;
        if ($motivate_type == 'Like' || $motivate_type == 'Inspire') {
            $apiData['status_id']    = 1;
            $apiData['created_date'] = gmdate('Y-m-d H:i:s');

            $feed_data_motivate_id = $this->getFeedDetailsDetailTable()->createFeedMotivateDetails($apiData);
            if ($feed_data_motivate_id > 0) {
                $this->getFeedDetailsDetailTable()->updateMotivateCount($feed_data_id, $apiData, '+ 1');
            }
        } else {
            if ($motivate_type == 'Unlike') {
                $apiData['type'] = 'Like';
            } else {
                $apiData['type'] = 'Inspire';
            }

            $this->getFeedDetailsDetailTable()->deleteMotivation($apiData);
            $this->getFeedDetailsDetailTable()->updateMotivateCount($feed_data_id, $apiData, '- 1');
        }
    }

    /**
     * Motivate Feed
     *
     * @param int $feed_data_id
     * @param int $user_id
     * @param string $motivate_type
     * @param string $motivate_status
     * @return Entity
     */
    public function motivate($table, $user_id, $data, $motivate_type, $motivate_status) {
        $config       = $this->getServiceLocator()->get('Config');
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);
        //var_dump($data['user_id']['S']);exit;
        try
        {
            $result = $dynamodbClient->getItem(array(
                'ConsistentRead' => true,
                'TableName' => 'feed_motivation',
                'Key'       => array(
                    'id'   => array('S' => $data->feed_data['feed_guid']['S'].'-'.$user_id),
                    'motivation_type' => array('S' => $motivate_type)
                )
            ));


            if (isset($result['Item'])) {
                if ($motivate_status == 'yes') {
                    return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid motivate status');
                } else {
                    try
                    {
                        $result = $dynamodbClient->deleteItem(array(
                            'TableName' => 'feed_motivation',
                            'Key' => array(
                               'id'   => array('S' => $data->feed_data['feed_guid']['S'].'-'.$user_id),
                               'motivation_type' => array('S' => $motivate_type),
                            )
                        ));
                        $this->getFeedDetailsDetailTable()->updateDynamoMotivateCount($table, $data, $motivate_type, $expression = '-');
                    }catch (\Exception $ex) {
                        //echo 'motivate delete -> '.$ex->getMessage();
                    }
                }
            } else {
                if ($motivate_status == 'yes') {
                    try
                    {
                        $result = $dynamodbClient->putItem(array(
                            'TableName' => 'feed_motivation',
                            'Item' => array(
                               'id'   => array('S' => $data->feed_data['feed_guid']['S'].'-'.$user_id),
                               'motivation_type' => array('S' => $motivate_type),
                               'created_date'=> array('S' => gmdate('Y-m-d H:i:s')),
                            )
                        ));
                        $this->getFeedDetailsDetailTable()->updateDynamoMotivateCount($table, $data, $motivate_type, $expression = '+');
                    }catch (\Exception $ex) {
                        //echo 'motivate insert -> '.$ex->getMessage();
                    }

                } else {
                    return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid motivate status');
                }
            }
        } catch (\Exception $ex) {
                //echo 'first insert -> '.$ex->getMessage();
        }
        

    }

    /**
     * Insert Hash tags
     *
     * @param int $user_id
     * @param int $feed_id
     * @param string $string
     * @param string $type
     * @return Entity
     */
    public function insertHashTags($user_id, $feed_id, $string, $params, $type = 'feed') {
        $config    = $this->getServiceLocator()->get('Config');
        preg_match_all("/(#\w+)/", $string, $matches);
        if (sizeof($matches[0]) > 0) {
            $hashtags = $matches[0];
           
            $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);
            $putBatch = WriteRequestBatch::factory($dynamodbClient);
            try{
                $created_date = time(gmdate('Y-m-d H:i:s'));
                foreach ($hashtags as $hashtag) {
                           $nItem['hashtag']   = array('S' => substr($hashtag,1));
                           $nItem['created_date']   = array('N' => $created_date);
                           $nItem['feed_guid']   = array('S' => $feed_id);
                           $nItem['posted_by']   = array('N' => $user_id);
                           $nItem['type']   = array('S' => $type);
                           $nItem['feed_date']   = $params['feed_date'];
                           $nItem['feed_created_date']   = $params['feed_created_date'];
                           $putBatch->add(new PutRequest($nItem, 'hashtag'));
                }
                $putBatch->flush();
            }catch (\Exception $ex) {
                    echo 'hash tag insert -> '.$ex->getMessage();
            }
           
        }
    }

    /**
     * Get Hash tag id
     *
     * @param int $user_id
     * @param int $feed_id
     * @param string $string
     * @param string $type
     * @return Entity
     */
    public function getHashTagId($hashtag, $user_id) {
        return $this->getFeedDetailsDetailTable()->insertHashTag($hashtag, $user_id);
    }

    /**
     * Check feed data exist
     *
     * @param type $type
     * @param int $objectId
     * @param int $userId
     * @param date $date
     * @return Entity
     */
    public function isFeedDataExist($type, $objectId, $userId, $date) {
        $data = new \stdClass();
        if ($type == 'goal') {
            $data->feed_type_id = 2;
        } else if ($type == 'exercise') {
            $data->feed_type_id = 3;
        } else if ($type == 'checkin') {
            $data->feed_type_id = 4;
        } else if ($type == 'friends') {
            $data->feed_type_id = 5;
        } else {
            return false;
        }

        $this->getAdapter();
        $query = "SELECT f.id AS feed_id, f.guid AS feed_guid, f.user_id , fd.feed_type_id, fd.data, fd.id AS feed_data_id, fd.like_count, fd.inspire_count
        FROM feed f
        JOIN feed_data fd ON f.id=fd.feed_id
        WHERE f.status_id=1 AND fd.status_id=1 AND fd.parent_id=0 AND f.user_id=$userId AND fd.feed_type_id=$data->feed_type_id AND DATE(f.created_date)='" .$date."' ";

        $statement = $this->adapter->createStatement($query);
        $result    = $statement->execute();

        if (count($result->getResource()->fetchAll(2)) > 0) {
            return true;
        }

        return false;

    }

    /**
     * Insert Custom feed data
     *
     * @param type $type
     * @param int $object_id
     * @param int $user_id
     * @return Entity
     */
    public function insertCustomFeedData($type, $object_id, $user_id, $params = null) {
        
        $this->getAdapter();
        $query = "  SELECT s.id AS setting_id, s.slug, s.name, s.type, IF( us.value='Yes',us.value,'No') AS status, us.id AS user_settings_id
                    FROM settings s
                    LEFT JOIN user_settings us ON s.id = us.setting_id AND us.user_id=$user_id WHERE s.status_id=1 AND s.type='feed'
";

        $statement = $this->adapter->createStatement($query);
        $result    = $statement->execute();

        $userSettings = $result->getResource()->fetchAll(2);
        $data         = new \stdClass();
        $slug         = '';

        if ($type == 'goal') {
            $data->feed_type_id = 2;
            $slug               = 'have-reached-my-goal';
        } else if ($type == 'exercise') {
            $data->feed_type_id = 3;
            $slug               = 'have-performed-an-exercise';
        } else if ($type == 'checkin') {
            $data->feed_type_id = 4;
            $slug               = 'have-checked-into-a-restaurant/-business';
        } else if ($type == 'friends') {
            $data->feed_type_id = 5;
            $slug               = 'became-friends-with-someone';
        } else {
            return false;
        }

        $config       = $this->getServiceLocator()->get('Config');
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);

        if (sizeof($userSettings)) {
            foreach ($userSettings as $key => $setting) {
                if ($setting['slug'] == $slug) {
                    if ($setting['status'] == 'No') {
                        return false;
                    } else {
                        break;
                    }
                } else {
                    continue;
                }
            }
        }

        
        $data->feed_guid      = md5(uniqid(rand(), true));
        $data->user_id   = $user_id;
        $data->object_id = $object_id;
        $data->feed_type = 'feed';
        $data->created_date = time(gmdate('Y-m-d H:i:s'));
        if (!empty($params['user_id2']) && $data->feed_type_id == 5) {
            $data->user_id2 = $params['user_id2'];
        }

        if (!empty($params['goal_date']) && $data->feed_type_id == 2) {
            $data->goal_date = $params['goal_date'];
        }
        
        $feed_data_id    = $this->saveFeedDetails('', $data);
    }


    public function SelfCronAction($date, $created_date)
    {
        
        $config = $this->getServiceLocator()->get('Config');
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);
        $batchCount = 25;
        try {
            
            $feedDetailsKeys[] = array(
                'date'   => array('S' => $date),
                'created_date'  => array('N' => $created_date),
            );
            $feedDetailsResult = $dynamodbClient->batchGetItem(array(
                'RequestItems' => array(
                    'feed' => array(
                        'Keys'           => $feedDetailsKeys,
                        'ConsistentRead' => true
                    )
                )
            ));

            if (!isset($feedDetailsResult['Responses']['feed'][0])) {
                break;
            }

          
            $followers = array();
            
            $cnt =1;
            foreach ($feedDetailsResult['Responses']['feed'] as $item) {
                $userId = $item['user_id']['S'];
                $feed_type = $item['feed_type_id']['N'];
                $date = $item['date']['S'];
                $created_date = $item['created_date'];
                $object_id = isset($item['object_id'])?$item['object_id']['N']:'';

                

                $notification['created_date']   = substr($item['created_date']['N'],0,10);
                $notification['user_id']        =   $userId;
                $notification['type']           =   $feed_type;
                $notification['feed_id']        =   $item['feed_guid']['S'];
                $notification['object_id']           =   $object_id;
                
               
                $nItem = array(
                       'created_date'=> array('N' => $item['created_date']['N']),
                       'creator_id'=> array('N' => $userId),
                       'type'   => array('N' => $feed_type),
                       'feed_id'   => $item['feed_guid'],
                       'feed_created_date'=> array('S' => gmdate('Y-m-d H:i:s', $notification['created_date'])),
                    );

                if ($feed_type == 1) {//Normal feed

                    $nItem['data']    =   $item['data'];
                    if (!empty($item['media'])) {
                        $nItem['feed_image'] = array('M' => 
                                                    array('file'=> $item['media']['M']['file'],
                                                      'type'=> $item['media']['M']['type'],
                                                      'width'=> $item['media']['M']['width'],
                                                      'height'=> $item['media']['M']['height']),
                                                    );
                       
                        $notification['feed_image']['file']    =   $item['media']['M']['file']['S'];
                        $notification['feed_image']['type']    =   $item['media']['M']['type']['S'];
                        $notification['feed_image']['width']    =   $item['media']['M']['width']['N'];
                        $notification['feed_image']['height']    =   $item['media']['M']['height']['N'];
                    }

                } else if ($feed_type == 2) {//Goal

                    $nItem['goal_date']           =  array('S'=> $item['goal_date']['S']);


                } else if ($feed_type == 3) {//Exercise

                    $exerciseInfo = $this->getFymUserDetailTable()->getFeedExerciseDetails($object_id);
                    $nItem['exercise']    =   array('S'=> $exerciseInfo[0]['exercise']);

                } else if ($feed_type == 4) {//Checkin
                    $businessDetails = $this->getFymUserDetailTable()->getBusinessDetailsByCheckinId($object_id);
                    
                    if (isset($businessDetails[0])) {
                        $object_id = $businessDetails[0]['business_id'];
                    } else {
                        $object_id = 0;
                    }
                    $businessInfo = $this->getFymUserDetailTable()->getFeedBusinessDetails($object_id);
                    
                    if ($businessInfo) {
                        $nItem['business'] = array('M' => 
                                                    array('business_id'=>array('S' => $businessInfo[0]['business_id']),
                                                      'business'=>array('S' => $businessInfo[0]['business_name']),
                                                    ));
                        if (!empty($businessInfo[0]['business_image'])) {
                            $nItem['business']['M']['business_image'] =array('S' =>  $businessInfo[0]['business_image']);
                        }

                    }
                } 



                if ($feed_type == 1 || $feed_type == 2 || $feed_type == 3 || $feed_type == 4) {


                    array_push($followers,$userId);
                  
                    //Added the same user for receiving his own notification
                    
                    
                    $totalFollowers = sizeof($followers);
                    if ($totalFollowers > 0) {
                         if ($totalFollowers > 0) {
                             
                             for ($i=0; $i < $totalFollowers; ) {
                                 try
                                 {
                                     $putBatch = WriteRequestBatch::factory($dynamodbClient);
                                     for ($k = $i; $k < $i+$batchCount; $k++) {

                                        if (!isset($followers[$k])) {
                                             $i = $totalFollowers;
                                             break;
                                        }

                                        $followerUserId = $followers[$k];
                                        $nItem['date']   = $item['date'];
                                        $nItem['user_id']   = array('N' => $followerUserId);
                                        if ($followerUserId == $userId)    {
                                            $nItem['mode']   = array('S' => 'self');
                                        }              
                                        $nItem['self_identifier']   = array('S' => $followerUserId .'-'. $userId);
                                         $putBatch->add(new PutRequest($nItem, 'user_notification'));
                                     }

                                     $putBatch->flush();
                                     
                                 }catch (\Exception $ex) {
                                     echo 'user feed 1-4 insert -> '.$ex->getMessage();
                                 }
                                 if (($i+$batchCount) > $totalFollowers) {
                                     $i=$i+2;
                                 } else {
                                     $i=$i+$batchCount;
                                 }
                                 
                             }
                             
                         }
                    }
                }


                if ($feed_type == 5) {//Friends
                    $userId2 = $item['user_id2']['N'];
                    $frndNotifications  = array();
                    
                    $user1Followers[$userId2] =  true;

                    
                    //exit;
                    if (sizeof($user1Followers) > 0) {
                        
                        foreach ($user1Followers as $user => $value) {
                            $frndNotifications[] = array('user_id' => $user,
                                                         'friend1'  => $userId,
                                                         'friend2'  => $userId2
                                                        );
                           
                        }
                    }

                    
                    
                    $totalFriendNotification  = sizeof($frndNotifications);
                    if ($totalFriendNotification > 0) {
                        
                        for ($i=0; $i < $totalFriendNotification; ) {
                            try
                            {
                                $putBatch = WriteRequestBatch::factory($dynamodbClient);
                                for ($k = $i; $k < $i+$batchCount; $k++) {

                                    if (!isset($frndNotifications[$k])) {
                                        $i = $totalFriendNotification;
                                        break;
                                    }

                                    $fInfo = $frndNotifications[$k];

                                    $fItem = array(
                                           'user_id'   => array('N' => $fInfo['user_id']),
                                           'created_date'=> $item['created_date'],
                                           'creator_id'=> array('N' => $userId2),
                                           'type'   => array('N' => $feed_type),
                                           'feed_id'   => $item['feed_guid'],
                                           'date'   => $item['date'],
                                           'feed_created_date'=> array('S' => gmdate('Y-m-d H:i:s', $notification['created_date'])),
                                        );
                                    
                                    $fItem['friends'] = array('M' =>  array('friend1'=>array('N' => $fInfo['friend2']),
                                                                  'friend2'=>array('N' => $fInfo['friend1']),
                                                             ));
                                    $fItem['self_identifier']   = array('S' => $fInfo['user_id'] .'-'. $userId2);
                                    $putBatch->add(new PutRequest($fItem, 'user_notification'));
                                }
                                $putBatch->flush();
                                
                            }catch (\Exception $ex) {
                                echo 'user feed friends insert -> '.$ex->getMessage();
                            }
                            if (($i+$batchCount) > $totalFriendNotification) {
                                $i=$i+2;
                            } else {
                                $i=$i+$batchCount;
                            }
                            
                        }
                        
                    }

                    
                }
               $notification = null;
               $cnt++;
            }//End for 

            
        } catch (\Exception $ex) {
            echo $ex->getMessage();
            return null;
        }

        
      
    }

    public function feedTrackInsert($params= array())
    {
        $input['type'] = $params['type'];
        $input['user_id'] = $params['user_id'];
        $input['date'] = $params['date'];
        $input['created_date'] = gmdate('Y-m-d H:i:s');

        $adapter = $this->getAdapter();
        $feedTrackTable = new \Zend\Db\TableGateway\TableGateway('feed_track', $adapter);
        $feedTrackTable->insert($input);
    }
    public function checkFeedTrack($params= array())
    {
      
        $adapter = $this->getAdapter();
        $feedTrackTable = new \Zend\Db\TableGateway\TableGateway('feed_track', $adapter);
        $feedTrack = $feedTrackTable->select($params)->current();
        return $feedTrack;
    }
}
