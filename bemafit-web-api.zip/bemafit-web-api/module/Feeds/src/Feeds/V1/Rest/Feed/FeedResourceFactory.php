<?php
namespace Feeds\V1\Rest\Feed;

class FeedResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('Feeds\V1\Rest\FeedMapperTableGateway');
        return new FeedResource($mapper);
    }
}
