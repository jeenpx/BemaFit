<?php
namespace Feeds\V1\Rpc\Motivate;

use Zend\Mvc\Controller\AbstractActionController;

class MotivateController extends AbstractActionController
{
    public function getFymUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function getFeedMapper()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Feeds\V1\Rest\FeedMapperTableGateway');
        return $this->Table;
    }

    public function getFeedDetailsDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Feeds\Model\FeedDetailsDetailTable');
        return $this->Table;
    }

    public function motivateAction()
    {
        $guid = $this->getEvent()->getRouteMatch()->getParam('user_id');
        $feed_id = $this->getEvent()->getRouteMatch()->getParam('feed_id');
        $user_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($guid);

        $motivate_type = trim($this->params()->fromPost('motivate_type'));
        $motivate_status = strtolower(trim($this->params()->fromPost('motivate_status')));
        $feed_type = strtolower(trim($this->params()->fromPost('feed_type')));

        if ($motivate_type != 'like' && $motivate_type != 'inspire') {
            return new \ZF\ApiProblem\ApiProblemResponse(
                new \ZF\ApiProblem\ApiProblem(422, 'Invalid motivate type')
            );
        }

        if ($motivate_status != 'yes' && $motivate_status != 'no') {
            return new \ZF\ApiProblem\ApiProblemResponse(
                new \ZF\ApiProblem\ApiProblem(422, 'Invalid motivate status')
            );
        }

        if ($feed_type != 'feed' && $feed_type != 'feed_comment') {
            return new \ZF\ApiProblem\ApiProblemResponse(
                new \ZF\ApiProblem\ApiProblem(422, 'Invalid feed type')
            );
        }

        if (!$user_info) {
            return new \ZF\ApiProblem\ApiProblemResponse(
                new \ZF\ApiProblem\ApiProblem(404, 'User not exists.')
            );
        }
        
        if ($feed_type == 'feed') {
            $feed_info = $this->getFeedMapper()->getDFeedByFeedGuid($feed_id);
            if (!$feed_info) {
                return new \ZF\ApiProblem\ApiProblemResponse(
                    new \ZF\ApiProblem\ApiProblem(404, 'Feed not exists.')
                );
            }
        } else {
            $feed_data_info = $this->getFeedMapper()->getDFeedCommentByFeedGuid($feed_id);
            if (!$feed_data_info) {
                return new \ZF\ApiProblem\ApiProblemResponse(
                    new \ZF\ApiProblem\ApiProblem(404, 'Feed comment not exists.')
                );
            }
        }

        $data = new \stdClass();
        

        if ($feed_type == 'feed') {
            $data->feed_data = $feed_info;
            $this->getFeedMapper()->motivate($feed_type, $user_info->id, $data, $motivate_type, $motivate_status);
        }
        

        return  array(
                      'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'motivate'),
                      'motivate'=>
                            array('status'=>'OK'),
                );
    }
}
