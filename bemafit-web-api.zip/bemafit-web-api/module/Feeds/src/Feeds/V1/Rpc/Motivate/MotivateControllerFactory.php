<?php
namespace Feeds\V1\Rpc\Motivate;

class MotivateControllerFactory
{
    public function __invoke($controllers)
    {
        return new MotivateController();
    }
}
