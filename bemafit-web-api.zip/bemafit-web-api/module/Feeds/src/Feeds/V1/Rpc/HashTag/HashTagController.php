<?php
namespace Feeds\V1\Rpc\HashTag;

use Zend\Mvc\Controller\AbstractActionController;
use ZF\Rest\AbstractResourceListener;
use Aws\DynamoDb\DynamoDbClient;
class HashTagController extends AbstractActionController
{
    public function getFeedDetailsDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Feeds\Model\FeedDetailsDetailTable');
        return $this->Table;
    }

    public function getFymUserDetailTable() {
        $sm          = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\FymUserDetailTable');
        return $this->Table;
    }

    public function hashTagAction()
    {
        $config    = $this->getServiceLocator()->get('Config');
        $offset = (int) $this->getEvent()->getRequest()->getQuery('offset', 0);
        $limit = (int) $this->getEvent()->getRequest()->getQuery('limit', 10);
        $hashtag = $this->getEvent()->getRouteMatch()->getParam('hashtag');
        $currentUserId = $this->getIdentity()->getUserId();
        $hid   = $this->getEvent()->getRequest()->getQuery('hid', 0);
        $rid1   = $this->getEvent()->getRequest()->getQuery('rid1', 0);
        $dynamodbClient = DynamoDbClient::factory($config['amazon_dynamo']);
       
        
        try
        {
            $options = array(
                'TableName' => 'hashtag',
                'KeyConditionExpression' => 'hashtag = :v_id',
                'ExpressionAttributeValues' =>  array (
                    ':v_id' => array('S' => $hashtag)
                ),
                'ScanIndexForward'=>false,
                'Count'=>true,
                'Limit'=>10
            );
          
            if (!empty($hid) && !empty($rid1)) {  
                $options['ExclusiveStartKey'] = array(
                                    'created_date' => array('N' => $rid1),
                                    'hashtag' => array('S' => $hid)
                                    
                );
            }

            $responseHash = $dynamodbClient->query($options);
            $feeds = $responseHash->toArray()['Items'];

            $page_meta = array();
            $feed_list = array();
            $page_meta["hid"] =  "";
            $page_meta["rid1"] =  "";
            $page_meta["rid2"] =  "";
            if (sizeof($feeds) > 0) {
                $motivationSearchKeys = array();
                $feedDetailsKeys = array();
                $preview_profile_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
                $feed_bucket_url         = $config['feed_photo_Settings']['thumbs'][0]['feed200']['bucket'];
                foreach ($feeds as $key => $feed) {
                    $feedOwners[$feed['posted_by']['N']]  = true;
                    

                    //Search feed motivation table to check whether the current user has motivated that feed in like or inspire
                    $motivationSearchKeys[] = array(
                        'id'   => array('S' => $feed['feed_guid']['S'].'-'.$currentUserId),
                        'motivation_type'  => array('S' => 'like'),
                    );
                    $motivationSearchKeys[] = array(
                        'id'   => array('S' => $feed['feed_guid']['S'].'-'.$currentUserId),
                        'motivation_type'  => array('S' => 'inspire'),
                    );

                    $feedDetailsKeys[] = array(
                        'date'   => array('S' => $feed['feed_date']['S']),
                        'created_date'  => array('N' => $feed['feed_created_date']['N']),
                    );
                }

                $motivatedResult = $dynamodbClient->batchGetItem(array(
                    'RequestItems' => array(
                        'feed_motivation' => array(
                            'Keys'           => $motivationSearchKeys,
                            'ConsistentRead' => true
                        )
                    )
                ));
                $motivations = array();
               
                foreach ($motivatedResult['Responses']['feed_motivation'] as $key => $value) {
                    $motivations[$value['id']['S']][$value['motivation_type']['S']] = true;
                }

                $feedDetailsResult = $dynamodbClient->batchGetItem(array(
                    'RequestItems' => array(
                        'feed' => array(
                            'Keys'           => $feedDetailsKeys,
                            'ConsistentRead' => true
                        )
                    )
                ));
                $feedInfo = array();
                if (isset($feedDetailsResult->toArray()['Responses']['feed']) && sizeof($feedDetailsResult->toArray()['Responses']['feed']) > 0) {
                    foreach ($feedDetailsResult->toArray()['Responses']['feed'] as $feedDet) {
                        $feedInfo[$feedDet['feed_guid']['S']] = $feedDet;
                    }
                } else {
                    continue;
                }


                
                $userIdStr = '';
                foreach($feedOwners as $fOwner=>$value) {
                    $userIdStr = ($userIdStr!='')?$userIdStr.','.$fOwner:$fOwner;
                }
                $userRawData  = $this->getFymUserDetailTable()->getAllActiveFymUserIdsByUserIDs($userIdStr);
                $userInfo = array();
                foreach($userRawData as $uData) {
                    $userInfo[$uData['u_id']] = $uData;
                }
                $feed = null;
                //var_dump($feedOwners);
                foreach ($feeds as $key => $feedItem) {
                    
                    $feedData = $feedInfo[$feedItem['feed_guid']["S"]];
                    //var_dump($feedData);exit;
                    //$feed["xxx"] = $feedData;
                    $feed["feed_id"] =  $feedItem['feed_guid']["S"];
                    $feed["feed_type"] =  "text";
                    $feed["feed_data"] =  $feedData['data']["S"];
                    $feed["created_date"] =  gmdate('Y-m-d H:i:s', $feedItem['created_date']["N"]);
                    $feed["user_id"] =  $feedItem['posted_by']["N"];
                    $creatorId = $feedItem['posted_by']["N"];
                    if (isset($userInfo[$creatorId])) {
                        $creator = $userInfo[$creatorId];
                    } else {
                        continue;
                    }

                    $user_image_url = empty($creator['profile_photo'])?'':$config['aws_s3_path'].'/'.$preview_profile_bucket_url.'/'.$creator['profile_photo'];
                    $feed["user_id"]        =  $creator['user_id'];
                    $feed["user_name"]      =  $creator['username'];
                    $feed["profile_photo"]  =  $user_image_url;

                    $feed["feed_image"] =  "";
                    $feed["feed_image_width"] =  0;
                    $feed["feed_image_height"] =  0;

                    if (isset($feedData['media'])) {
                        $feed["feed_image"] =  !empty($feedData['media']['M']['file']['S'])?$config['aws_s3_path'].'/'.$feed_bucket_url.'/'.$feedData['media']['M']['file']['S']:"";
                        $feed["feed_image_width"] =  $feedData['media']['M']['width']['N'];
                        $feed["feed_image_height"] =  $feedData['media']['M']['height']['N'];
                    }
                    $feed["like_count"] =  $feedData['like_count']["N"];
                    $feed["inspire_count"] =  $feedData['inspire_count']["N"];
                    $feed["comment_count"] =  $feedData['comment_count']["N"];
                    $feed["like_status"] =  isset($motivations[$feedData['feed_guid']['S'].'-'.$currentUserId]['like'])?true:false;
                    $feed["inspire_status"] =  isset($motivations[$feedData['feed_guid']['S'].'-'.$currentUserId]['inspire'])?true:false;
                    //var_dump($feed['feed_guid']);
                    
                    //var_dump($response);
                    array_push($feed_list, $feed);
                }

                if (isset($responseHash['LastEvaluatedKey'])) {
                    $page_meta["hid"] =  $responseHash['LastEvaluatedKey']['hashtag']['S'];
                    $page_meta["rid1"] =  $responseHash['LastEvaluatedKey']['created_date']['N'];
                }
            }
            
            return array(
                'page_meta'=>$page_meta, 'meta'        => array('status'        => 'OK', 'code'        => 200, 'methodName'        => 'getHashTagPosts'),
                'feeds'       => $feed_list,
                'total_feeds' => 0
            );
            
        } catch(\Exception $ex) {
            echo 'get hashtag posts '. $ex->getMessage();
        }
        exit;
        return $this->getFeedDetailsDetailTable()->getHashTagFeeds($current_user_id, $hashtag, $offset, $limit);
    }
}
