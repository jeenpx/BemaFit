<?php
namespace Feeds\V1\Rpc\HashTag;

class HashTagControllerFactory
{
    public function __invoke($controllers)
    {
        return new HashTagController();
    }
}
