<?php
require __DIR__ . '/src/Feeds/Module.php';
