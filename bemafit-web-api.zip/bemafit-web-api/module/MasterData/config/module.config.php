<?php
return array(
    'controllers' => array(
        'factories' => array(
            'MasterData\\V1\\Rpc\\Masterdata\\Controller' => 'MasterData\\V1\\Rpc\\Masterdata\\MasterdataControllerFactory',
        ),
    ),
    'router' => array(
        'routes' => array(
            'master-data.rpc.masterdata' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/masterdata[/:type]',
                    'defaults' => array(
                        'controller' => 'MasterData\\V1\\Rpc\\Masterdata\\Controller',
                        'action' => 'masterdata',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            0 => 'master-data.rpc.masterdata',
        ),
    ),
    'zf-rpc' => array(
        'MasterData\\V1\\Rpc\\Masterdata\\Controller' => array(
            'service_name' => 'masterdata',
            'http_methods' => array(
                0 => 'GET',
            ),
            'route_name' => 'master-data.rpc.masterdata',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'MasterData\\V1\\Rpc\\Masterdata\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'MasterData\\V1\\Rpc\\Masterdata\\Controller' => array(
                0 => 'application/vnd.master-data.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
        ),
        'content_type_whitelist' => array(
            'MasterData\\V1\\Rpc\\Masterdata\\Controller' => array(
                0 => 'application/vnd.master-data.v1+json',
                1 => 'application/json',
            ),
        ),
    ),
    'zf-content-validation' => array(
        'MasterData\\V1\\Rpc\\Masterdata\\Controller' => array(
            'input_filter' => 'MasterData\\V1\\Rpc\\Masterdata\\Validator',
        ),
    ),
    'input_filter_specs' => array(
        'MasterData\\V1\\Rpc\\Masterdata\\Validator' => array(),
    ),
    'zf-mvc-auth' => array(
        'authorization' => array(
            'MasterData\\V1\\Rpc\\Masterdata\\Controller' => array(
                'actions' => array(
                    'masterdata' => array(
                        'GET' => false,
                        'POST' => false,
                        'PATCH' => false,
                        'PUT' => false,
                        'DELETE' => false,
                    ),
                ),
            ),
        ),
    ),
);
