<?php
return array(
    'MasterData\\V1\\Rpc\\Masterdata\\Controller' => array(
        'GET' => array(
            'description' => 'Type input will be a json array. Eg: ["goal","mealType"]. This API will list all master data, if the type input is empty.
goal, activityLevel, businessCategory, nutritionalPlan, exerciseType, mealType, mealCategory',
            'request' => null,
            'response' => '{
  "masterdata": {
    "goal": [
      {
        "guid": "f5671de2a84911e495d0001e8cf540dd",
        "name": "Maintain"
      },
      {
        "guid": "f567212ca84911e495d0001e8cf5dfgr",
        "name": "Fat Loss"
      },
      {
        "guid": "f567225da84911e495d0001e8weyghh",
        "name": "Custom"
      }
    ],
    "activityLevel": [
      {
        "name": "Sedentary",
        "description": "little or no exercise"
      },
      {
        "name": "Lightly Active\\r",
        "description": "light exercise/sports 1-3 days/week, approx. 590 Cal/day"
      },
      {
        "name": "Moderately Active",
        "description": "moderate exercise/sports 3-5 days/week, approx. 870 Cal/day"
      },
      {
        "name": "Very Active",
        "description": "hard exercise/sports 6-7 days a week, approx. 1150 Cal/day"
      },
      {
        "name": "Extra Active",
        "description": "very hard exercise/sports and physical job, approx. 1580 Cal/day"
      }
    ],
    "businessCategory": [
      {
        "name": "Gym"
      },
      {
        "name": "Retail"
      },
      {
        "name": "Nutrition"
      }
    ],
    "nutritionalPlan": [
      {
        "name": "Flexible Dieting/IIFYM",
        "description": "Utilize FYM Recommended Macro Formula"
      },
      {
        "name": "Vegetarian",
        "description": "Utilize the Same FYM Recommended Macronutrient Formula used for Flexible Dieting/IIFYM"
      },
      {
        "name": "Vegan",
        "description": "Utilize the Same FYM Recommended Macronutrient Formula used for Flexible Dieting/IIFYM"
      },
      {
        "name": "Paleo",
        "description": "Utilize the Same FYM Recommended Macronutrient Formula used for Flexible Dieting/IIFYM"
      }
    ],
    "exerciseType": [
      {
        "name": "Cardiovascular"
      },
      {
        "name": "Strength"
      }
    ],
    "mealType": [
      {
        "name": "Breakfast"
      },
      {
        "name": "Lunch"
      },
      {
        "name": "Snacks"
      },
      {
        "name": "Dinner"
      }
    ],
    "mealCategory": [
      {
        "name": "Low Carb"
      },
      {
        "name": "Low Fat"
      },
      {
        "name": "High Protein"
      }
    ]
  }
}',
        ),
    ),
);
