<?php
namespace MasterData;

use ZF\Apigility\Provider\ApigilityProviderInterface;
use MasterData\V1\Model\Master;
use MasterData\V1\Model\MasterTable;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;

class Module implements ApigilityProviderInterface
{
    public function getConfig()
    {
        return include __DIR__ . '/../../config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'ZF\Apigility\Autoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__,
                ),
            ),
        );
    }

    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'MasterData\V1\Model\MasterTable' =>  function ($sm) {
                    $tableGateway = $sm->get('MasterTableGateway');
                    $table = new MasterTable($tableGateway);
                    return $table;
                },
                'MasterTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Master());
                    return new TableGateway('activity_level_master', $dbAdapter, null, $resultSetPrototype);
                },
            ),
        );
    }
}
