<?php
namespace MasterData\V1\Rpc\Masterdata;

use Zend\Mvc\Controller\AbstractActionController;

class MasterdataController extends AbstractActionController
{
    public function getMasterTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('MasterData\V1\Model\MasterTable');
        return $this->Table;
    }

    /**
     * Return All master data. type parameter will accept json array. If type is empty, This call will return all masterdata.
     * Sample type input ["goal","activityLevel"]
     * @return json Array.
     */
    public function masterdataAction()
    {
        $type = $this->params('type');


        if ($type == 'mealCategoryCustom') {
            $type = '["mealCategory"]';
        }
        $typeList = !empty($type)?json_decode($type, true):null;
        $typeList = ($typeList[0]=='all')?null:$typeList;
        if (is_array($typeList)) {
            $typeList = array_flip($typeList);
        }

        $masterData = array();
        $masterData_es = array();

        if (isset($typeList['goal']) || !$typeList) {
            $goal_list =    $this->getMasterTable()->getGoals();
            if (sizeof($goal_list) > 0) {
                $masterData['goal'] = array();
                $masterData_es['goal'] = array();
                $goal_id = 0;
                $goals = array();
                $goals_es = array();
                $goal_options = array();
                foreach ($goal_list as $key => $goal) {
                    if (!isset($goals[$goal['id']])) {
                        $goals[$goal['id']] = array('id'=>$goal['id'], 'goal'=>$goal['goal'], 'goal_options'=> array(array('goal_option_id'=>$goal['goal_option_id'], 'percentage'=>$goal['percentage'], 'goal_option'=>$goal['goal_option'])));
                        $goals_es[$goal['id']] = array('id'=>$goal['id'], 'goal'=>$goal['goal_es'], 'goal_options'=> array(array('goal_option_id'=>$goal['goal_option_id'], 'percentage'=>$goal['percentage'], 'goal_option'=>$goal['goal_option_es'])));
                    } else {
                        array_push($goals[$goal['id']]['goal_options'], array('goal_option_id'=>$goal['goal_option_id'], 'percentage'=>$goal['percentage'], 'goal_option'=>$goal['goal_option']));
                        array_push($goals_es[$goal['id']]['goal_options'], array('goal_option_id'=>$goal['goal_option_id'], 'percentage'=>$goal['percentage'], 'goal_option'=>$goal['goal_option_es']));
                    }
                    
                }

                foreach ($goals as $key => $goal) {
                    array_push($masterData['goal'], $goal);
                    array_push($masterData_es['goal'], $goals_es[$key]);
                }
                
            }
        }

        if (isset($typeList['activityLevel']) || !$typeList) {
            $activityLevels =    $this->getMasterTable()->getActivityLevels();

            if (sizeof($activityLevels) > 0) {
                $masterData['activityLevel'] = array();
                $masterData_es['activityLevel'] = array();
                foreach ($activityLevels as $key => $activityLevel) {
                    array_push($masterData['activityLevel'], array('id'=>$activityLevel['id'], 'value' => $activityLevel['weight'],'name'=>$activityLevel['name'], 'description'=>$activityLevel['description']));
                    array_push($masterData_es['activityLevel'], array('id'=>$activityLevel['id'], 'value' => $activityLevel['weight'],'name'=>$activityLevel['name_es'], 'description'=>$activityLevel['description_es']));
                }
            }
        }

        if (isset($typeList['businessCategory']) || !$typeList) {
            $businessCategories =    $this->getMasterTable()->getBusinessCategories();

            if (sizeof($businessCategories) > 0) {
                $masterData['businessCategory'] = array();
                $masterData_es['businessCategory'] = array();
                foreach ($businessCategories as $key => $businessCategory) {
                    array_push($masterData['businessCategory'], array('id'=>$businessCategory['id'], 'name'=>$businessCategory['name']));
                    array_push($masterData_es['businessCategory'], array('id'=>$businessCategory['id'], 'name'=>$businessCategory['name']));
                }
            }
        }

        if (isset($typeList['nutritionalPlan']) || !$typeList) {
            $nutritionalPlans =    $this->getMasterTable()->getnutritionalPlans();

            if (sizeof($nutritionalPlans) > 0) {
                $masterData['nutritionalPlan'] = array();
                $masterData_es['nutritionalPlan'] = array();
                foreach ($nutritionalPlans as $key => $nutritionalPlan) {
                    array_push($masterData['nutritionalPlan'], array('id'=>$nutritionalPlan['id'], 'name'=>$nutritionalPlan['name'], 'description'=>$nutritionalPlan['description']));
                    array_push($masterData_es['nutritionalPlan'], array('id'=>$nutritionalPlan['id'], 'name'=>$nutritionalPlan['name_es'], 'description'=>$nutritionalPlan['description_es']));
                }
            }
        }

        if (isset($typeList['nutritionFact']) || !$typeList) {
            $nutritionFacts =    $this->getMasterTable()->getnutritionFacts();

            if (sizeof($nutritionFacts) > 0) {
                $masterData['nutritionFact'] = array();
                $masterData_es['nutritionFact'] = array();
                foreach ($nutritionFacts as $key => $nutritionFact) {
                    array_push($masterData['nutritionFact'], array('id'=>$nutritionFact['id'], 'name'=>$nutritionFact['name']));
                    array_push($masterData_es['nutritionFact'], array('id'=>$nutritionFact['id'], 'name'=>$nutritionFact['name_es']));
                }
            }
        }

        if (isset($typeList['exerciseType']) || !$typeList) {
            $exerciseTypes =    $this->getMasterTable()->getexerciseTypes();

            if (sizeof($exerciseTypes) > 0) {
                $masterData['exerciseType'] = array();
                $masterData_es['exerciseType'] = array();
                foreach ($exerciseTypes as $key => $exerciseType) {
                    array_push($masterData['exerciseType'], array('id'=>$exerciseType['id'], 'name'=>$exerciseType['name']));
                    array_push($masterData_es['exerciseType'], array('id'=>$exerciseType['id'], 'name'=>$exerciseType['name_es']));
                }
            }
        }

        if (isset($typeList['mealType']) || !$typeList) {
            $mealTypes =    $this->getMasterTable()->getmealTypes();

            if (sizeof($mealTypes) > 0) {
                $masterData['mealType'] = array();
                $masterData_es['mealType'] = array();
                foreach ($mealTypes as $key => $mealType) {
                    array_push($masterData['mealType'], array('id'=>$mealType['id'], 'name'=>$mealType['name']));
                    array_push($masterData_es['mealType'], array('id'=>$mealType['id'], 'name'=>$mealType['name_es']));
                }
            }
        }

        if (isset($typeList['mealCategory']) || !$typeList) {
            $mealCategories =    $this->getMasterTable()->mealCategories();

            if (sizeof($mealCategories) > 0) {
                $masterData['mealCategory'] = array();
                $masterData_es['mealCategory'] = array();
                foreach ($mealCategories as $key => $mealCategory) {
                    array_push($masterData['mealCategory'], array('id'=>$mealCategory['id'], 'name'=>$mealCategory['name']));
                    array_push($masterData_es['mealCategory'], array('id'=>$mealCategory['id'], 'name'=> !empty($mealCategory['name_es'])?$mealCategory['name_es']:$mealCategory['name']  ));
                }
            }
        }
        return array(   'meta' => array('status'=>'OK', 'code'=>200, 'methodName' => 'masterData'),
                        'masterdata'=>$masterData,
                        'masterdata_es'=>$masterData_es
                    );
        
    }
}
