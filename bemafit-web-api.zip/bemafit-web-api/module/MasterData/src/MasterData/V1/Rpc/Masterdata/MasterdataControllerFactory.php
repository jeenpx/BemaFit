<?php
namespace MasterData\V1\Rpc\Masterdata;

class MasterdataControllerFactory
{
    public function __invoke($controllers)
    {
        return new MasterdataController();
    }
}
