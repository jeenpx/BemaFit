<?php
namespace MasterData\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class MasterTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
    * Get Activity Levels
    *
    * @param int $activity_level_id
    * @return Entity
    */
    public function getActivityLevels($activity_level_id=0)
    {
        $subQuery = ($activity_level_id>0)? " AND id = ?":"";
        $sql = "SELECT * FROM activity_level_master WHERE status_id = 1 $subQuery ";

        $statement = $this->tableGateway->adapter->createStatement($sql, array($activity_level_id));

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);

        return $data;
    }

    /**
    * Get Goals
    *
    * @param int $goal_option_id
    * @return Entity
    */
    public function getGoals($goal_option_id='')
    {
        $subQuery = !empty($goal_option_id)? " AND go.id = ?":"";
        $sql = "SELECT g.id, g.name AS goal, g.name_es as goal_es ,  IF(go.id IS NULL,'',go.id) AS goal_option_id, 
                IF ( go.value IS NULL,'', go.value) AS goal_option, IF ( go.value_es IS NULL,'', go.value_es) AS goal_option_es, IF( go.percentage IS NULL,'' ,go.percentage) AS percentage
                FROM goal g 
                LEFT JOIN goal_option go ON g.id=go.goal_id
                WHERE g.status_id=1 AND  IF (go.id IS NOT NULL ,go.status_id=1,1)
                $subQuery 
                ";

        $statement = $this->tableGateway->adapter->createStatement($sql, array($goal_option_id));

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);

        return $data;
    }

    /**
    * Get Business Categories
    *
    * @return Entity
    */
    public function getBusinessCategories()
    {
        $sql = 'SELECT * FROM business_category_master WHERE status_id = ?';

        $statement = $this->tableGateway->adapter->createStatement($sql, array(1));

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);

        return $data;
    }

    /**
    * Get Nutritional Plans
    *
    * @param int $nutritional_plan_id
    * @return Entity
    */
    public function getnutritionalPlans($nutritional_plan_id=0)
    {
        $subQuery = ($nutritional_plan_id>0)? " AND id = ?":"";
        $sql = "SELECT * FROM nutritional_plan WHERE status_id = 1 $subQuery";

        $statement = $this->tableGateway->adapter->createStatement($sql, array($nutritional_plan_id));

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);

        return $data;
    }

    /**
    * Get Nutrition Facts
    *
    * @param int $nutrition_fact_id
    * @return Entity
    */
    public function getnutritionFacts($nutrition_fact_id=0)
    {
        $subQuery = ($nutrition_fact_id>0)? " AND id = ?":"";
        $sql = "SELECT * FROM nutrition_fact WHERE status_id = 1 $subQuery";

        $statement = $this->tableGateway->adapter->createStatement($sql, array($nutrition_fact_id));

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);

        return $data;
    }

    /**
    * Get Exercise Types
    *
    * @return Entity
    */
    public function getexerciseTypes()
    {
        $sql = 'SELECT * FROM exercise_type WHERE status_id = ?';

        $statement = $this->tableGateway->adapter->createStatement($sql, array(1));

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);

        return $data;
    }

    /**
    * Get Meal Types
    *
    * @return Entity
    */
    public function getmealTypes()
    {
        $sql = "SELECT mtm.* FROM meal_type_master mtm 
                JOIN user u ON mtm.created_by=u.id 
                 WHERE mtm.status_id = 1 AND u.role='Admin'";

        $statement = $this->tableGateway->adapter->createStatement($sql);

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);

        return $data;
    }

    /**
    * Get Meal Categories
    *
    * @return Entity
    */
    public function mealCategories()
    {
        $sql = 'SELECT * FROM meal_category_master WHERE status_id = ?';

        $statement = $this->tableGateway->adapter->createStatement($sql, array(1));

        $result = $statement->execute();
        $data = $result->getResource()->fetchAll(2);

        return $data;
    }
}
