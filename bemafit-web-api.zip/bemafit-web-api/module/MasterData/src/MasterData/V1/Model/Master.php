<?php
namespace MasterData\V1\Model;

class Master
{
    public $user_id;
    public $first_name;

    public function exchangeArray($data)
    {
        $this->user_id    = (isset($data['user_id'])) ? $data['user_id'] : null;
        $this->first_name = (isset($data['first_name'])) ? $data['first_name'] : null;
    }
}
