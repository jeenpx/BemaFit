<?php
return array(
    'validators' => array(
        'invokables' => array(
            'Fym\Validator\FymUser' => 'Fym\Validator\FymUser',
            'Fym\Validator\FymFoodLogType' => 'Fym\Validator\FymFoodLogType',
            'Fym\Validator\FymExerciseLogType' => 'Fym\Validator\FymExerciseLogType',
            'Fym\Validator\FymActiveUser' => 'Fym\Validator\FymActiveUser',
            'Fym\Validator\FymProgressReportType' => 'Fym\Validator\FymProgressReportType',
            'Fym\Validator\FymIsFloat' => 'Fym\Validator\FymIsFloat',
        ),
    ),
);
