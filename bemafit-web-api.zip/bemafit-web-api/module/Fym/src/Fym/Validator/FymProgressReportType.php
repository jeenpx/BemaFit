<?php
namespace Fym\Validator;

use Zend\Validator\AbstractValidator;

class FymProgressReportType extends AbstractValidator
{
    const MSG_ERROR = 'InvalidProgressReportType';
   

    protected $messageTemplates = array(
        self::MSG_ERROR => "'%value%' is not valid progress type, Weight, Bodyfat, Macro, Exercise"
    );
    
    public function isValid($value)
    {
        $allowedTypes  = array('Weight','Bodyfat','Macro','Exercise');
        
        $this->setValue($value);

        if (!in_array($value, $allowedTypes)) {
            $this->error(self::MSG_ERROR);
            return false;
        }
        return true;
    }
}
