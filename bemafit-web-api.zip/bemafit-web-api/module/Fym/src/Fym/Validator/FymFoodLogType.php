<?php
namespace Fym\Validator;

use Zend\Validator\AbstractValidator;

class FymFoodLogType extends AbstractValidator
{
    const MSG_ERROR = 'InvalidLogType';   

    protected $messageTemplates = array(
        self::MSG_ERROR => "'%value%' is not valid log type, use Log,Copy,Share,Send"
    );
    
    public function isValid($value)
    {
        $allowedTypes  = array('Log','Copy','Send','Share');
        $this->setValue($value);

        if (!in_array($value, $allowedTypes)) {
            $this->error(self::MSG_ERROR);
            return false;
        }
        return true;
    }
}
