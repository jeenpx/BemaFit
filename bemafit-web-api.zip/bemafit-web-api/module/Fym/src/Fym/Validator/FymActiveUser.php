<?php
namespace Fym\Validator;

use Zend\Validator\AbstractValidator;
use Zend\Validator\Db\RecordExists;

class FymActiveUser extends AbstractValidator
{
    const MSG_ERROR = 'FymActiveUser';
   
    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    protected $messageTemplates = array(
        self::MSG_ERROR => "User not exists"
       
    );
    
    public function isValid($value)
    {
        $validator = new  RecordExists(
            array(
                'adapter' => \Zend\Db\TableGateway\Feature\GlobalAdapterFeature::getStaticAdapter(),
                'table' => 'user',
                'field' => 'guid',
                'exclude' => ' user.status_id=1',
            )
        );

        $this->setValue($value);
        if (!$validator->isValid($value)) {
            $this->error(self::MSG_ERROR);
            return false;
        }

        return true;
    }
}
