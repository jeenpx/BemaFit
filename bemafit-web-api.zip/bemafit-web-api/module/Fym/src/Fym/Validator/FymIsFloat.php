<?php
namespace Fym\Validator;

use Zend\Validator\AbstractValidator;

class FymIsFloat extends AbstractValidator
{
    const MSG_ERROR = 'notFloat';

    protected $messageTemplates = array(
        self::MSG_ERROR => "Invalid Entry"
    );
    
    public function isValid($value)
    {
        $allowedTypes  = array('Log','Copy','Send');
        $this->setValue($value);

        if (!empty($value) && !is_numeric($value)) {
            $this->error(self::MSG_ERROR);
            return false;
        }
        return true;
    }
}
