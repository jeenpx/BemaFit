<?php
require __DIR__ . '/src/Fym/Module.php';
