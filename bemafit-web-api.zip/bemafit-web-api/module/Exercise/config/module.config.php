<?php
return array(
    'router' => array(
        'routes' => array(
            'exercise.rest.exercise' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/exercise[/:exercise_id]',
                    'defaults' => array(
                        'controller' => 'Exercise\\V1\\Rest\\Exercise\\Controller',
                    ),
                ),
            ),
            'exercise.rest.exercise-type' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/exercise-type[/:exercise_type_id]',
                    'defaults' => array(
                        'controller' => 'Exercise\\V1\\Rest\\ExerciseType\\Controller',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            0 => 'exercise.rest.exercise',
            1 => 'exercise.rest.exercise-type',
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'Exercise\\V1\\Rest\\Exercise\\ExerciseResource' => 'Exercise\\V1\\Rest\\Exercise\\ExerciseResourceFactory',
            'Exercise\\V1\\Rest\\ExerciseType\\ExerciseTypeResource' => 'Exercise\\V1\\Rest\\ExerciseType\\ExerciseTypeResourceFactory',
        ),
    ),
    'zf-rest' => array(
        'Exercise\\V1\\Rest\\Exercise\\Controller' => array(
            'listener' => 'Exercise\\V1\\Rest\\Exercise\\ExerciseResource',
            'route_name' => 'exercise.rest.exercise',
            'route_identifier_name' => 'exercise_id',
            'collection_name' => 'exercise',
            'entity_http_methods' => array(
                0 => 'GET',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(
                0 => 'name',
                1 => 'type',
                2 => 'limit',
                3 => 'offset',
                4 => 'locale',
            ),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'Exercise\\V1\\Rest\\Exercise\\ExerciseEntity',
            'collection_class' => 'Exercise\\V1\\Rest\\Exercise\\ExerciseCollection',
            'service_name' => 'Exercise',
        ),
        'Exercise\\V1\\Rest\\ExerciseType\\Controller' => array(
            'listener' => 'Exercise\\V1\\Rest\\ExerciseType\\ExerciseTypeResource',
            'route_name' => 'exercise.rest.exercise-type',
            'route_identifier_name' => 'exercise_type_id',
            'collection_name' => 'exercise_type',
            'entity_http_methods' => array(
                0 => 'GET',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'Exercise\\V1\\Rest\\ExerciseType\\ExerciseTypeEntity',
            'collection_class' => 'Exercise\\V1\\Rest\\ExerciseType\\ExerciseTypeCollection',
            'service_name' => 'ExerciseType',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'Exercise\\V1\\Rest\\Exercise\\Controller' => 'Json',
            'Exercise\\V1\\Rest\\ExerciseType\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'Exercise\\V1\\Rest\\Exercise\\Controller' => array(
                0 => 'application/vnd.exercise.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
            'Exercise\\V1\\Rest\\ExerciseType\\Controller' => array(
                0 => 'application/vnd.exercise.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
        ),
        'content_type_whitelist' => array(
            'Exercise\\V1\\Rest\\Exercise\\Controller' => array(
                0 => 'application/vnd.exercise.v1+json',
                1 => 'application/json',
            ),
            'Exercise\\V1\\Rest\\ExerciseType\\Controller' => array(
                0 => 'application/vnd.exercise.v1+json',
                1 => 'application/json',
            ),
        ),
    ),
    'zf-hal' => array(
        'metadata_map' => array(
            'Exercise\\V1\\Rest\\Exercise\\ExerciseEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'exercise.rest.exercise',
                'route_identifier_name' => 'exercise_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'Exercise\\V1\\Rest\\Exercise\\ExerciseCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'exercise.rest.exercise',
                'route_identifier_name' => 'exercise_id',
                'is_collection' => true,
            ),
            'Exercise\\V1\\Rest\\ExerciseType\\ExerciseTypeEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'exercise.rest.exercise-type',
                'route_identifier_name' => 'exercise_type_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'Exercise\\V1\\Rest\\ExerciseType\\ExerciseTypeCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'exercise.rest.exercise-type',
                'route_identifier_name' => 'exercise_type_id',
                'is_collection' => true,
            ),
        ),
    ),
    'zf-content-validation' => array(
        'Exercise\\V1\\Rest\\Exercise\\Controller' => array(
            'input_filter' => 'Exercise\\V1\\Rest\\Exercise\\Validator',
        ),
    ),
    'input_filter_specs' => array(
        'Exercise\\V1\\Rest\\Exercise\\Validator' => array(
            0 => array(
                'name' => 'type',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            1 => array(
                'name' => 'amount',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            2 => array(
                'name' => 'calorie_burned',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            3 => array(
                'name' => 'distance',
                'required' => false,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            4 => array(
                'name' => 'number_of_sets',
                'required' => false,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            5 => array(
                'name' => 'rep_sets',
                'required' => false,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            6 => array(
                'name' => 'rep_set_weight',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            7 => array(
                'name' => 'locale',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            8 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'name',
            ),
        ),
    ),
    'zf-mvc-auth' => array(
        'authorization' => array(
            'Exercise\\V1\\Rest\\Exercise\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
            ),
            'Exercise\\V1\\Rest\\ExerciseType\\Controller' => array(
                'entity' => array(
                    'GET' => false,
                    'POST' => false,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
                'collection' => array(
                    'GET' => false,
                    'POST' => false,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
        ),
    ),
);
