<?php
namespace Exercise\V1\Model;

class ExerciseDetails
{
    public function exchangeArray($data)
    {
        $this->id         = (isset($data['id'])) ? $data['id'] : null;
        $this->meal_id    = (isset($data['meal_id'])) ? $data['meal_id'] : null;
        $this->unit_id    = (isset($data['unit_id'])) ? $data['unit_id'] : null;
    }
}
