<?php

namespace Exercise\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class ExerciseDetailsTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }
    
    public function create($exercise_id, $exercise_type_option_id, $value)
    {
        $this->tableGateway->insert(array('exercise_id'=>$exercise_id,'exercise_type_option_id'=>$exercise_type_option_id,'value'=>$value));
        return $this->tableGateway->lastInsertValue;
    }
}
