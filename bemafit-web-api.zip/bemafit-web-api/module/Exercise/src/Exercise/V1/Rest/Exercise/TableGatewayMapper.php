<?php
namespace Exercise\V1\Rest\Exercise;

use Zend\Mvc\Controller\AbstractActionController;

use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController {
	/**
	 * @var TableGateway
	 */
	protected $table;

	/**
	 * @param TableGateway $table
	 */
	public function __construct(TableGateway $table) {
		$this->table = $table;
	}

	public function getExerciseTypeTable() {
		$sm                      = $this->getServiceLocator();
		$this->ExerciseTypeTable = $sm->get('Exercise\V1\Rest\ExerciseTypeMapperTableGateway');
		return $this->ExerciseTypeTable;
	}

	public function getAdapter() {
		$sm            = $this->getServiceLocator();
		$this->adapter = $sm->get('Db\Adapter\Adapter');
		return $this->adapter;
	}

	public function getUserTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
		return $this->Table;
	}

	public function getExerciseDetailsTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('Exercise\Model\ExerciseDetailsTable');
		return $this->Table;
	}

	public function getUserDetailTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('User\Model\UserDetailTable');
		return $this->Table;
	}

	/**
	 * To create new exercise
	 *
	 * @param array $data
	 * @return Entity
	 */
	public function create($data) {
		if ($data->type == '1') {
			if (empty($data->distance)) {
				return \Application\Service\FymApiProblem::ApiProblem(422, 'Distance required');
			}
		} else if ($data->type == '2') {
			if (empty($data->number_of_sets)) {
				return \Application\Service\FymApiProblem::ApiProblem(422, 'Number of Sets Required');
			}
			if (empty($data->rep_sets)) {
				return \Application\Service\FymApiProblem::ApiProblem(422, 'Rep/ Sets Required');
			}
			if (empty($data->rep_set_weight)) {
				return \Application\Service\FymApiProblem::ApiProblem(422, 'Rep/ Weight per Set Required');
			}
		}

		$guid   = md5(uniqid(rand(), true));
		$typeId = $this->getExerciseTypeTable()->fetchById($data->type);

		if (!$typeId) {
			return \Application\Service\FymApiProblem::ApiProblem(404, 'Invalid Exercise Type');
		}

		$user = $this->getUserDetailTable()->getUserDetails($data->userId);

		if (!empty($user['dob']) and !empty($user['weight']) and !empty($user['height']) and $data->calorie_burned>0 and $data->amount>0) {
			$age = date_diff(date_create($user['dob']), date_create('now'))->y;

			if ($user['gender'] == 'M') {
				$bmr = round((13.75*($user['weight']/2.2046))+(5*$user['height'])-(6.76*$age)+66);
			} else {
				$bmr = round((9.56*($user['weight']/2.2046))+(1.85*$user['height'])-(4.68*$age)+655);
			}

			$metValue = ($data->calorie_burned/($bmr/24)/($data->amount/3600));

			// For males: BMR = (13.75 x WKG) + (5 x HC) - (6.76 x age) + 66
			// For females: BMR = (9.56 x WKG) + (1.85 x HC) - (4.68 x age) + 655
		} else {
			$metValue = 0;
		}

		$utilityObj = new \Application\Service\Utility();
		$locale     = $utilityObj->getLocale(!empty($data->locale)?$data->locale:'en');

		if ($locale == 'es') {
			$languageId = 2;
			$nameFld    = 'name_es';
		} else {
			$languageId = 1;
			$nameFld    = 'name';
		}

		$resultSet = $this->table->select(array($nameFld => ($data->name), 'status_id' => 1));
		if (!empty($resultSet->current()->id)) {
			return \Application\Service\FymApiProblem::ApiProblem(404, 'Exercise already exist');
		}

		$apiData = array('guid' => $guid, $nameFld => addslashes(($data->name)), 'language_id' => $languageId, 'exercise_type_id' => $typeId, 'met_value' => $metValue, 'status_id' => 1, 'created_by' => $data->userId, 'created_date' => gmdate('Y-m-d H:i:s'));
		$this->table->insert($apiData);

		if ($data->type == '1') {
			$this->getExerciseDetailsTable()->create($this->table->lastInsertValue, 1, $data->amount);
			$this->getExerciseDetailsTable()->create($this->table->lastInsertValue, 2, $data->calorie_burned);
			$this->getExerciseDetailsTable()->create($this->table->lastInsertValue, 3, $data->distance);
		} else if ($data->type == '2') {
			$this->getExerciseDetailsTable()->create($this->table->lastInsertValue, 4, $data->amount);
			$this->getExerciseDetailsTable()->create($this->table->lastInsertValue, 5, $data->calorie_burned);
			$this->getExerciseDetailsTable()->create($this->table->lastInsertValue, 6, $data->number_of_sets);
			$this->getExerciseDetailsTable()->create($this->table->lastInsertValue, 7, $data->rep_sets);
			$this->getExerciseDetailsTable()->create($this->table->lastInsertValue, 8, $data->rep_set_weight);
		}

		return $this->fetch($this->table->lastInsertValue, $locale);
	}

	/**
	 * To fetch a exerbise by id
	 *
	 * @param int $id
	 * @return Entity
	 */
	public function fetch($id, $locale) {
		if ($locale == 'es') {
			$nameFld  = 'IF(ISNULL(e.name_es),e.name,e.name_es) ';
			$nameFldC = 'name_es';
		} else {
			$nameFld  = 'IF(ISNULL(e.name),e.name_es,e.name) ';
			$nameFldC = 'name';
		}

		$this->getAdapter();
		$sql = "SELECT e.id,e.guid,$nameFld as name,et." .$nameFldC." as exercise_type,met_value
        FROM exercise e
        LEFT JOIN exercise_type et ON et.id = e.exercise_type_id
        WHERE e.id=$id";

		$statement = $this->adapter->createStatement($sql);
		$result    = $statement->execute();
		$exercise  = $result->getResource()->fetch(2);

		if (!empty($exercise)) {
			//$exercise['name'] = utf8_encode($exercise['name']);

			$sql = "SELECT eto.option,ed.value
            FROM exercise e
            LEFT JOIN exercise_type et ON et.id =e.exercise_type_id
            LEFT JOIN exercise_type_option eto ON eto.exercise_type_id =et.id
            LEFT JOIN exercise_details ed ON ed.exercise_id=e.id AND ed.exercise_type_option_id = eto.id
            WHERE e.id=".$exercise['id'];

			$statement = $this->adapter->createStatement($sql);

			$result       = $statement->execute();
			$exerciseDets = $result->getResource()->fetchAll(2);

			foreach ($exerciseDets as $dkey => $exerciseDet) {
				$exercise['exercise_det'][$exerciseDet['option']] = (string) !empty($exerciseDet['value'])?(string) $exerciseDet['value']:(string) 0;
			}

			return $exercise;
		} else {
			return \Application\Service\FymApiProblem::ApiProblem(422, 'Exercise not exist');
		}

	}

	/**
	 * To fetch all Exercise
	 *
	 * @param array $params
	 * @param int $userId
	 * @return Entity
	 */
	public function fetchAll($params, $userId) {
		$utilityObj = new \Application\Service\Utility();
		$locale     = $utilityObj->getLocale($params->locale);

		$where = '';
		if (!empty($params['name']) and $params['name'] != '') {
			$where .= " AND ".($locale == 'es'?'e.name_es':'e.name')." like '%".$params['name']."%' ";
		}

		if (!empty($params['type']) and $params['type'] != '') {
			if ($this->getExerciseTypeTable()->fetchById($params['type'])) {
				$where .= " AND et.id='".$params['type']."' ";
			} else {
				return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Type');
			}

		}

		if (empty($params->limit)) {
			$params->limit = 10;
		}

		if (empty($params->offset)) {
			$params->offset = 0;
		}

		$this->getAdapter();

		if ($locale == 'es') {
			$nameFld = 'IF(ISNULL(e.name_es),e.name,e.name_es) ';
			$orderBy = 'ORDER BY if(e.name_es = "" or e.name_es is null,1,0),e.name_es';
		} else {
			$nameFld = 'IF(ISNULL(e.name),e.name_es,e.name) ';
			$orderBy = 'ORDER BY if(e.name = "" or e.name is null,1,0),e.name';
		}

		$sql = "SELECT e.id,e.guid,$nameFld as name,et.id as exercise_type,met_value
        FROM exercise e
        LEFT JOIN exercise_type et ON et.id = e.exercise_type_id
        JOIN user ON user.id= e.created_by
        WHERE e.status_id=1
		" .$where."
		".$orderBy."
        LIMIT ".$params->offset.",".$params->limit;
		//AND (user.role='Admin' OR user.id=$userId)
		$statement = $this->adapter->createStatement($sql);

		$result    = $statement->execute();
		$exercises = $result->getResource()->fetchAll(2);

		foreach ($exercises as $key => $exercise) {
			//$exercises[$key]['name'] =utf8_encode($exercise['name']);
			$exercises[$key]['met_value'] = (string) !empty($exercise['met_value'])?$exercise['met_value']:"";


			$user = $this->getUserDetailTable()->getUserDetails($userId);

			if (!empty($user['dob']) and !empty($user['weight']) and !empty($user['height'])) {
				$age = date_diff(date_create($user['dob']), date_create('now'))->y;

				if ($user['gender'] == 'M') {
					$bmr = round((13.75*($user['weight']/2.2046))+(5*$user['height'])-(6.76*$age)+66);
				} else {
					$bmr = round((9.56*($user['weight']/2.2046))+(1.85*$user['height'])-(4.68*$age)+655);
				}

				//Calorie Burn = (BMR / 24) x MET x T

				 $calBurn = (($bmr/24)*(!empty($exercise['met_value'])?$exercise['met_value']:0) * (60/3600) );
				 $calBurnHr = (($bmr/24)*(!empty($exercise['met_value'])?$exercise['met_value']:0) * 1 );

				// For males: BMR = (13.75 x WKG) + (5 x HC) - (6.76 x age) + 66
				// For females: BMR = (9.56 x WKG) + (1.85 x HC) - (4.68 x age) + 655
			} else {
				$calBurn = 0;
			}

			$exercises[$key]['cal_burned_min'] = number_format($calBurn,2);
			$exercises[$key]['cal_burned_hour'] = number_format($calBurnHr,2);


			$sql = "SELECT eto.option,ed.value
            FROM exercise e
            LEFT JOIN exercise_type et ON et.id =e.exercise_type_id
            LEFT JOIN exercise_type_option eto ON eto.exercise_type_id =et.id
            LEFT JOIN exercise_details ed ON ed.exercise_id=e.id AND ed.exercise_type_option_id = eto.id
            WHERE e.id=".$exercise['id'];

			$statement = $this->adapter->createStatement($sql);

			$result       = $statement->execute();
			$exerciseDets = $result->getResource()->fetchAll(2);

			foreach ($exerciseDets as $dkey => $exerciseDet) {
				$exercises[$key]['exercise_det'][$exerciseDet['option']] = (string) !empty($exerciseDet['value'])?(string) $exerciseDet['value']:(string) 0;
			}

			// to find recent value
			// $sql ="SELECT IF(et.id=1,ueld1.value,ueld2.value) AS amount
			// FROM user_exercise_log uel
			// LEFT JOIN exercise_type et ON et.id = uel.exercise_type_id
			// LEFT JOIN user_exercise_log_det ueld1 ON ueld1.user_exercise_log_id=uel.id AND ueld1.exercise_type_option_id=1
			// LEFT JOIN user_exercise_log_det ueld2 ON ueld2.user_exercise_log_id=uel.id AND ueld2.exercise_type_option_id=4
			// WHERE  uel.exercise_id=".$exercise['id']." AND uel.user_id=$userId
			// ORDER BY uel.id DESC
			// LIMIT 1";

			//  $statement = $this->adapter->createStatement($sql);

			// $result  = $statement->execute();
			// $exercise_det = $result->getResource()->fetch();
			// $exercises[$key]['amount']= (string)!empty($exercise_det['amount'])?$exercise_det['amount']:"0";
		}
		//print_r($exercises);
		return $exercises;
	}

	/**
	 * To Validate Exercise by id
	 *
	 * @param int $id
	 * @return Entity
	 */
	public function isValidExercise($id) {
		$resultSet = $this->table->select(array('id' => $id));
		if (0 === count($resultSet)) {
			return false;
		}
		return true;
	}

	/**
	 * To get Exercise by id
	 *
	 * @param int $id
	 * @return Entity
	 */
	public function getExercise($id) {
		$resultSet = $this->table->select(array('id' => $id));
		if (0 === count($resultSet)) {
			return false;
		}
		return $resultSet->current();
	}

}
