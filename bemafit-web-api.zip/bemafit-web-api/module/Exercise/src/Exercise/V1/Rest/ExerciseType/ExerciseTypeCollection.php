<?php
namespace Exercise\V1\Rest\ExerciseType;

use Zend\Paginator\Paginator;

class ExerciseTypeCollection extends Paginator
{
}
