<?php
namespace Exercise\V1\Rest\ExerciseType;

class ExerciseTypeResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('Exercise\V1\Rest\ExerciseTypeMapperTableGateway');
        return new ExerciseTypeResource($mapper);
    }
}
