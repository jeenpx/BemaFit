<?php
namespace Exercise\V1\Rest\Exercise;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class ExerciseResource extends AbstractResourceListener
{
    protected $mapper;
    
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }
    /**
     * Create a resource
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        @$data->userId = $this->getIdentity()->getUserId();
        $result        = $this->mapper->create($data);
        return array('meta'=>array('status'=>'ok','code'=>200,'method_name'=>'Add Exercise'),'result'=>$result);
    }

    /**
     * Delete a resource
     * Not using as per current system requirement
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function delete($id)
    {
        return new ApiProblem(405, 'The DELETE method has not been defined for individual resources');
    }

    /**
     * Delete a collection, or members of a collection
     * Not using as per current system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        return new ApiProblem(405, 'The DELETE method has not been defined for collections');
    }

    /**
     * Fetch a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($id)
    {
        $locale = $this->getEvent()->getRequest()->getQuery('locale');
        $result = $this->mapper->fetch($id, $locale);

        if ($result) {
            return array('meta'=>array('status'=>'ok','code'=>200,'method_name'=>'Get Exercise det'),'result'=>$result);
        }
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($params = array())
    {
        $result = $this->mapper->fetchAll($params, @$this->getIdentity()->getUserId());
        return array('meta'=>array('status'=>'ok','code'=>200,'method_name'=>'Get Exercise'),'result'=>$result);
    }

    /**
     * Patch (partial in-place update) a resource
     * Not using as per current system requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        return new ApiProblem(405, 'The PATCH method has not been defined for individual resources');
    }

    /**
     * Replace a collection or members of a collection
     * Not using as per current system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return new ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     * Not using as per current system requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        return new ApiProblem(405, 'The PUT method has not been defined for individual resources');
    }
}
