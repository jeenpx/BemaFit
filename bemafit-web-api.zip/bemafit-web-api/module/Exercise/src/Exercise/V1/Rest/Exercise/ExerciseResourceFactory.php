<?php
namespace Exercise\V1\Rest\Exercise;

class ExerciseResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('Exercise\V1\Rest\ExerciseMapperTableGateway');
        return new ExerciseResource($mapper);
    }
}
