<?php
namespace Exercise\V1\Rest\Exercise;

use Zend\Paginator\Paginator;

class ExerciseCollection extends Paginator
{
}
