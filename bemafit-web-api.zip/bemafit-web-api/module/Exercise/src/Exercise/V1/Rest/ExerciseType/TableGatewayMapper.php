<?php

namespace Exercise\V1\Rest\ExerciseType;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }


    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    /**
    * To fetch all Exercise Type
    *
    * @return Entity
    */
    public function fetchAll($locale)
    {
        $this->getAdapter();

        $utilityObj = new \Application\Service\Utility();
        $locale     = $utilityObj->getLocale(!empty($locale)?$locale:'en');

        if ($locale=='es') {
            $nameFld = 'name_es';
        } else {
            $nameFld = 'name';
        }

        $sql ="SELECT exercise_type.id,exercise_type.".$nameFld." as name
        FROM exercise_type        
        WHERE exercise_type.status_id=1 
        AND ".$nameFld."!=''
        ORDER BY exercise_type.id";
        
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        return $result->getResource()->fetchAll(2);
    }

    /**
    * To fetch Exercise Type by name
    *
    * @param int $id
    * @return Entity
    */
    public function fetchByName($name)
    {
        $resultSet = $this->table->select(array('name' => $name));
        if (0 === count($resultSet)) {
            return false;
        }
        return $resultSet->current()->id;
    }

    /**
    * To fetch Exercise Type by id
    *
    * @param int $id
    * @return Entity
    */
    public function fetchById($id)
    {
        $resultSet = $this->table->select(array('id' => $id));
        if (0 === count($resultSet)) {
            return false;
        }
        return $resultSet->current()->id;
    }
}
