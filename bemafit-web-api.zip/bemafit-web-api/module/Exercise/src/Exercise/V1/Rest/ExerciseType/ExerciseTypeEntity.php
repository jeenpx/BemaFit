<?php
namespace Exercise\V1\Rest\ExerciseType;

class ExerciseTypeEntity
{
    public $id;
    public $name;

    public function getArrayCopy()
    {
        return array(
            'id'     => $this->id,
            'name'  => $this->name
        );
    }

    public function exchangeArray(array $array)
    {
        $this->id     = $array['id'];
        $this->name  = $array['name'];
    }
}
