<?php
namespace Exercise;

use ZF\Apigility\Provider\ApigilityProviderInterface;

use Exercise\V1\Model\ExerciseDetails;
use Exercise\V1\Model\ExerciseDetailsTable;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;

class Module implements ApigilityProviderInterface
{
    public function getConfig()
    {
        return include __DIR__ . '/../../config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'ZF\Apigility\Autoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__,
                ),
            ),
        );
    }

    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'Exercise\V1\Rest\ExerciseTypeMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\ExerciseType\ExerciseTypeMapper($adapter);
                },
                'Exercise\V1\Rest\ExerciseTypeMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\ExerciseType\TableGateway('exercise_type', $adapter);
                    return new V1\Rest\ExerciseType\TableGatewayMapper($tableGateway);
                },
                'Exercise\V1\Rest\ExerciseMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\Exercise\ExerciseMapper($adapter);
                },
                'Exercise\V1\Rest\ExerciseMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Exercise\TableGateway('exercise', $adapter);
                    return new V1\Rest\Exercise\TableGatewayMapper($tableGateway);
                },
                'Exercise\Model\ExerciseDetailsTable' =>  function ($sm) {
                     $tableGateway = $sm->get('ExerciseDetailsTableGateway');
                     $table = new ExerciseDetailsTable($tableGateway);
                     return $table;
                },
                'ExerciseDetailsTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new ExerciseDetails());
                     return new TableGateway('exercise_details', $dbAdapter, null, $resultSetPrototype);
                },
            )
        );
    }
}
