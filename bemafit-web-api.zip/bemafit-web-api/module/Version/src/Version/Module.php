<?php
namespace Version;

use Version\V1\Model\VersionDetail;
use Version\V1\Model\VersionDetailTable;

use ZF\Apigility\Provider\ApigilityProviderInterface;

class Module implements ApigilityProviderInterface
{
    public function getConfig()
    {
        return include __DIR__ . '/../../config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'ZF\Apigility\Autoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__,
                ),
            ),
        );
    }

    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'VersionDetailTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new VersionDetail());
                     return new TableGateway('version', $dbAdapter, null, $resultSetPrototype);
                },
                'User\Model\VersionDetailTable' =>  function ($sm) {
                     $tableGateway = $sm->get('VersionDetailTableGateway');
                     $table = new FymUserDetailTable($tableGateway);
                     return $table;
                },
            )
        );
    }
}
