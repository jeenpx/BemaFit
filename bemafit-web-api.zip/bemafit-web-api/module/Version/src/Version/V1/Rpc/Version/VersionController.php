<?php
namespace Version\V1\Rpc\Version;

use Zend\Mvc\Controller\AbstractActionController;

class VersionController extends AbstractActionController {
	public function getFymUserDetailTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('User\Model\FymUserDetailTable');
		return $this->Table;
	}

	public function versionAction() {
		$version = $this->getFymUserDetailTable()->getVersion();

		return array(
			'meta'    => array('status'    => 'OK', 'code'    => 200, 'methodName'    => 'getVesrion'),
			'version' => $version['version']

		);
		exit;
	}
}
