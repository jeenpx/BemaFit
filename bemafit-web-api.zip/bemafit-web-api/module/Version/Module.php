<?php
require __DIR__ . '/src/Version/Module.php';