<?php
return array(
    'controllers' => array(
        'factories' => array(
            'Version\\V1\\Rpc\\Version\\Controller' => 'Version\\V1\\Rpc\\Version\\VersionControllerFactory',
        ),
    ),
    'router' => array(
        'routes' => array(
            'version.rpc.version' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/version',
                    'defaults' => array(
                        'controller' => 'Version\\V1\\Rpc\\Version\\Controller',
                        'action' => 'version',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            0 => 'version.rpc.version',
        ),
    ),
    'zf-rpc' => array(
        'Version\\V1\\Rpc\\Version\\Controller' => array(
            'service_name' => 'Version',
            'http_methods' => array(
                0 => 'GET',
            ),
            'route_name' => 'version.rpc.version',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'Version\\V1\\Rpc\\Version\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'Version\\V1\\Rpc\\Version\\Controller' => array(
                0 => 'application/vnd.version.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ),
        ),
        'content_type_whitelist' => array(
            'Version\\V1\\Rpc\\Version\\Controller' => array(
                0 => 'application/vnd.version.v1+json',
                1 => 'application/json',
            ),
        ),
    ),
);
