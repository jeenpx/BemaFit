<?php

/*
 * This file is part of the CdnLight package.
 * @copyright Copyright (c) 2012 Blanchon Vincent - France (http://developpeur-zend-framework.fr - blanchon.vincent@gmail.com)
 */

namespace AppBase\View\Helper;

use Zend\View\Helper\AbstractHelper;
use Zend\Stdlib\Exception\InvalidArgumentException;
use Zend\Uri\Http as HttpUri;

class Link extends AbstractHelper
{

    /**
     * Cdn config, array of server config
     * @var array
     */
    protected $cdnConfig;

    /**
     * Construct the cdn helper
     *
     * @param array $cdnConfig
     */
    public function __construct(array $cdnConfig)
    {
        $this->setCdnConfig($cdnConfig);
    }

    /**
     * Set the Cdn servers config
     *
     * @param array $cdnConfig
     * @return HeadScript
     */
    public function setCdnConfig(array $cdnConfig)
    {
        if(empty($cdnConfig)) {
            throw new InvalidArgumentException('Cdn config must be not empty');
        }
        $this->cdnConfig = $cdnConfig;
        return $this;
    }

    /**
     * Usage of image view helper
     * @param string $src
     * @return Image
     */
    public function __invoke($src = null, $context = 'images')
    {
        if(null === $src) {
            return $this;
        }
	
        return $this->cdn($src, $context);
    }

    /**
     * Get cdn link
     * @param string $src
     */
    public function cdn($src, $context)
    {
        if(!is_string($src)) {
            throw new InvalidArgumentException('Source file must be a string');
        }
        
        if( is_array($context) && !empty($context)){
            foreach($context as $key=>$value){                 
                $config = $this->cdnConfig[$value];
                $this->setCdnConfig($config);
            }
        } else {
            $config = $this->cdnConfig[$context];
        }
        	
		if(isset($config['folder'])){
			$src = $config['folder'] . $src;
		}
		
        $uri = new HttpUri($src);
        if($uri->getHost()) {
            return $uri->toString();
        }
		$uri->setScheme($config['scheme']);
        $uri->setHost($config['host']);
		
        return $uri->toString();
    }
}
