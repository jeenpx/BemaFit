<?php

namespace AppBase\Db\Adapter\Mongo;

use Mongo;
use MongoClient;
use MongoDB;
use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;

class MongoDbAdaptor implements FactoryInterface
{
    /**
     * Server connection string
     *
     * @var string
     */
    protected $server = 'mongodb://localhost:27017';

    /**
     * Connection options
     *
     * @var array
     */
    protected $options = array(
        'connect' => true
    );

    protected $dbName = 'test';

    public function createService(ServiceLocatorInterface $services)
    {
        $config = $services->get('Config');
        if(isset($config['mongoDb']) && isset($config['mongoDb']['server'])){
            $this->server = $config['mongoDb']['server'];
        }
        if(isset($config['mongoDb']) && isset($config['mongoDb']['options'])){
            $this->options = $config['mongoDb']['options'];
        }
        if(isset($config['mongoDb']) && isset($config['mongoDb']['db'])){
            $this->dbName = $config['mongoDb']['db'];
        }

        $connectionService = new Mongo($this->server, $this->options);
        return new MongoDB($connectionService, $this->dbName);
    }
}
