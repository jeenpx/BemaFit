<?php

namespace AppBase\Mapper;

use Zend\Stdlib\Hydrator\HydratorInterface;
use Zend\Stdlib\Hydrator\ClassMethods;
use AppBase\EventManager\EventProvider;
use AppBase\Db\Adapter\Mongo\MongoDbAdaptor;
use AppBase\Db\Adapter\Mongo\HydratingMongoCursor;
use AppBase\Db\Adapter\Mongo\HydratingPaginatorAdapter;
use Zend\ServiceManager\ServiceLocatorInterface;
use MongoCollection;
use MongoDB;
use MongoID;

abstract class AbstractMongoDbMapper extends EventProvider
{
    /**
     * @var Adapter
     */
    protected $dbAdapter;

    /**
     * @var HydratorInterface
     */
    protected $hydrator;

    /**
     * @var object
     */
    protected $entityPrototype;

    /**
     * @var HydratingResultSet
     */
    protected $resultSetPrototype;

    /**
     * @var string
     */
    protected $collectionName;

    /**
     * @var string
     */
    protected $collection;

    /**
     * @var boolean
     */
    private $isInitialized = false;

    /**
     * @var service manger
     */
    protected $services;

    /**
     * Performs some basic initialization setup and checks before running a query
     * @return null
     */
    public function initialize()
    {
        if ($this->isInitialized) {
            return;
        }

        if (!$this->dbAdapter instanceof MongoDB) {
            throw new \Exception('No db adapter present');
        }

        if (!$this->hydrator instanceof HydratorInterface) {
            $this->hydrator = new ClassMethods;
        }

        if (!is_object($this->entityPrototype)) {
            throw new \Exception('No entity prototype set');
        }

        if (!$this->collection instanceof MongoCollection) {
            $this->collection = new MongoCollection($this->dbAdapter, $this->collectionName);
        }

        $this->isInitialized = true;
    }

    /**
     * @return resultSet
     */
    public function getResult($find, $entityPrototype = null, HydratorInterface $hydrator = null)
    {
        $hydrator = $hydrator ?: $this->getHydrator();
        $entityPrototype = $entityPrototype ?: $this->getEntityPrototype();

        if(is_array($find)) {
            $resultset = $hydrator->hydrate($find, clone $entityPrototype); 
        } else {
            $resultset = new HydratingMongoCursor(
                $find,
                $hydrator,
                $entityPrototype
            );  
        }

        return $resultset;
    }

    /**
     * @return MongoCollection
     */
    protected function getCollection()
    {
        return $this->collection;
    }

    /**
     * @return string
     */
    protected function getCollectionName()
    {
        return $this->collectionName;
    }

    /**
     * @return object
     */
    public function getEntityPrototype()
    {
        return $this->entityPrototype;
    }

    /**
     * @param object $modelPrototype
     * @return AbstractDbMapper
     */
    public function setEntityPrototype($entityPrototype)
    {
        $this->entityPrototype = $entityPrototype;
        $this->resultSetPrototype = null;
        return $this;
    }

    /**
     * @return Adapter
     */
    public function getDbAdapter()
    {
        return $this->dbAdapter;
    }

    /**
     * @param Adapter $dbAdapter
     * @return AbstractDbMapper
     */
    public function setDbAdapter(MongoDB $dbAdapter)
    {
        $this->dbAdapter = $dbAdapter;
        return $this;
    }

    /**
     * @return HydratorInterface
     */
    public function getHydrator()
    {
        if (!$this->hydrator) {
            $this->hydrator = new ClassMethods(false);
        }
        return $this->hydrator;
    }

    /**
     * @param HydratorInterface $hydrator
     * @return AbstractDbMapper
     */
    public function setHydrator(HydratorInterface $hydrator)
    {
        $this->hydrator = $hydrator;
        $this->resultSetPrototype = null;
        return $this;
    }

    public function setServiceLocator(ServiceLocatorInterface $serviceLocator)
    {
        $this->services = $serviceLocator;
        return $this;
    }

    public function getServiceLocator()
    {
        return $this->services;
    }


    /**
     * Uses the hydrator to convert the entity to an array.
     *
     * Use this method to ensure that you're working with an array.
     *
     * @param object $entity
     * @return array
     */
    protected function entityToArray($entity, HydratorInterface $hydrator = null, $ignore = array())
    {
        if (is_array($entity)) {
            foreach($ignore as $key){
                unset($entity[$key]);
            }
            return $entity; // cut down on duplicate code
        } elseif (is_object($entity)) {
            if (!$hydrator) {
                $hydrator = $this->getHydrator();
            }
            $entity = $hydrator->extract($entity);
            foreach($ignore as $key){
                unset($entity[$key]);
            }
            return $entity;
        }
        throw new Exception\InvalidArgumentException('Entity passed to db mapper should be an array or object.');
    }

    /**
     * @param id
     * @return mongoid
     */
    public function getMongoId($id)
    {
        if($id instanceof MongoID){
            return $id;
        } else {
            return new MongoID($id);
        }
    }
}
