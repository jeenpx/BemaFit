<?php

namespace AppBase\Mapper\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{}