<?php

namespace AppBase\Mapper\Exception;

interface ExceptionInterface
{}