<?php

namespace AppBase\Mvc\Controller;
	
use Zend\Mvc\Controller\AbstractActionController;
	
class AppActionController extends AbstractActionController
{
	
}
?>