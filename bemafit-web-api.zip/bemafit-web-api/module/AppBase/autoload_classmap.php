<?php
return array(
    'AppBase\Module'                                   	=> __DIR__ . '/Module.php',
    'AppBase\View\Model\ScriptModel'                   	=> __DIR__ . '/src/AppBase/View/Model/ScriptModel.php',
    'AppBase\Module'                                    => __DIR__ . '/Module.php',
    'AppBase\Form\ProvidesEventsForm'                   => __DIR__ . '/src/AppBase/Form/ProvidesEventsForm.php',
    'AppBase\Mapper\Exception\ExceptionInterface'       => __DIR__ . '/src/AppBase/Mapper/Exception/ExceptionInterface.php',
    'AppBase\Mapper\Exception\InvalidArgumentException' => __DIR__ . '/src/AppBase/Mapper/Exception/InvalidArgumentException.php',
    'AppBase\Mapper\AbstractMysqlDbMapper'              => __DIR__ . '/src/AppBase/Mapper/AbstractMysqlDbMapper.php',
    'AppBase\EventManager\EventProvider'                => __DIR__ . '/src/AppBase/EventManager/EventProvider.php',
    'AppBase\Module\AbstractModule'                     => __DIR__ . '/src/AppBase/Module/AbstractModule.php',
    'AppBase\OAuth2\Adapter\PdoAdapter'                 => __DIR__ . '/src/AppBase/OAuth2/Adapter/PdoAdapter.php',
);