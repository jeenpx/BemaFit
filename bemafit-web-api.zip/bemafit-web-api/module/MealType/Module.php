<?php
require __DIR__ . '/src/MealType/Module.php';
