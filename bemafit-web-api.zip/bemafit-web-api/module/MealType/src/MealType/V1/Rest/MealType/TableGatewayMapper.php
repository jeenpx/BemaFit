<?php

namespace MealType\V1\Rest\MealType;

use Zend\Mvc\Controller\AbstractActionController;

use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController {
	/**
	 * @var TableGateway
	 */
	protected $table;

	/**
	 * @param TableGateway $table
	 */
	public function __construct(TableGateway $table) {
		$this->table = $table;
	}

	public function getAdapter() {
		$sm            = $this->getServiceLocator();
		$this->adapter = $sm->get('Db\Adapter\Adapter');
		return $this->adapter;
	}

	public function getUserTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
		return $this->Table;
	}

	/**
	 * Create meal
	 *
	 * @param array $data
	 * @return Entity
	 */
	public function create($data) {
		$this->getAdapter();

		$utilityObj = new \Application\Service\Utility();
		$locale     = $utilityObj->getLocale(!empty($data->locale)?$data->locale:'en');

		if ($locale == 'es') {
			$nameFld = 'name_es';
		} else {
			$nameFld = 'name';
		}

		//$data->meal_type = addslashes(utf8_decode($data->meal_type));

		$apiData = array($nameFld => addslashes($data->meal_type), 'status_id' => 1, 'created_by' => $data->userId, 'created_date' => gmdate('Y-m-d H:i:s'));

		$limit = 10;

		$sql = "SELECT meal_type_master.id,meal_type_master.".$nameFld." as name
        FROM meal_type_master
        JOIN user ON user.id = meal_type_master.created_by
        WHERE meal_type_master.status_id=1 AND (meal_type_master.created_by=".$data->userId." OR user.role='Admin')
        AND ".$nameFld."='".addslashes($data->meal_type)."'
        ORDER BY meal_type_master.id";

		$statement = $this->adapter->createStatement($sql);

		$result = $statement->execute();

		if (count($result->getResource()->fetchAll(2)) == 0) {
			$resultSet = $this->table->select(array('status_id' => 1, 'created_by' => $data->userId));
			if (count($resultSet->toArray()) < $limit) {
				$this->table->insert($apiData);

				$resultSet = $this->table->select(array('id' => $this->table->lastInsertValue));

				if (0 === count($resultSet)) {
					return \Application\Service\FymApiProblem::ApiProblem(500, 'Insert operation failed or did not result in new row');
				}
				return $resultSet->current();
			} else {
				return \Application\Service\FymApiProblem::ApiProblem(500, 'Meal Type Limit exceeded, Limit is '.$limit);
			}
		} else {
			return \Application\Service\FymApiProblem::ApiProblem(500, 'Meal Type already exist');
		}
	}

	/**
	 * Fetch Meal Type by name
	 *
	 * @param array $name
	 * @return Entity
	 */
	public function fetchByName($name) {
		$resultSet = $this->table->select(array('name' => $name));

		if (0 === count($resultSet)) {
			return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Meal Type');
		}
		return $resultSet->current()->id;
	}

	/**
	 * Fetch Meal Type by id
	 *
	 * @param array $id
	 * @return Entity
	 */
	public function fetchById($id) {
		$resultSet = $this->table->select(array('id' => $id));

		if (0 === count($resultSet)) {
			return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Meal Type');
		}
		return $resultSet->current()->id;
	}

	/**
	 * Fetch All Meal Type
	 *
	 * @param array $name
	 * @return Entity
	 */
	public function fetchAll($userId, $locale) {
		$this->getAdapter();

		$utilityObj = new \Application\Service\Utility();
		$locale     = $utilityObj->getLocale(!empty($locale)?$locale:'en');

		if ($locale == 'es') {
			$nameFld = 'IF(ISNULL(meal_type_master.name_es),meal_type_master.name,meal_type_master.name_es) ';
		} else {
			$nameFld = 'IF(ISNULL(meal_type_master.name),meal_type_master.name_es,meal_type_master.name)';
		}

		$sql = "SELECT meal_type_master.id,$nameFld as name,IF(user.role='Admin','true','false') as is_default
        FROM meal_type_master
        JOIN user ON user.id = meal_type_master.created_by
        WHERE meal_type_master.status_id=1 AND (meal_type_master.created_by=" .$userId." OR user.role='Admin')
        ORDER BY meal_type_master.id";

		$statement = $this->adapter->createStatement($sql);

		$result = $statement->execute();
		$results = $result->getResource()->fetchAll(2);
		foreach ($results as $key => $value) {
			$results[$key]['name'] = stripslashes($value['name']);
		}
		return $results;
	}

	/**
	 * Fetch All Meal Type
	 *
	 * @param array $name
	 * @return Entity
	 */
	public function dmpMealType($userId, $locale) {
		$this->getAdapter();

		$utilityObj = new \Application\Service\Utility();
		$locale     = $utilityObj->getLocale(!empty($locale)?$locale:'en');

		if ($locale == 'es') {
			$nameFld = 'IF(ISNULL(meal_type_master.name_es),meal_type_master.name,meal_type_master.name_es) ';
		} else {
			$nameFld = 'IF(ISNULL(meal_type_master.name),meal_type_master.name_es,meal_type_master.name)';
		}

		$sql = "SELECT meal_type_master.id,$nameFld as name,IF(user.role='Admin','true','false') as is_default
        FROM meal_type_master
        JOIN user ON user.id = meal_type_master.created_by
        WHERE meal_type_master.status_id=1 AND (meal_type_master.created_by=" .$userId." OR user.role='Admin') AND name!='Snacks'
        ORDER BY meal_type_master.id";

		$statement = $this->adapter->createStatement($sql);

		$result = $statement->execute();
		$results = $result->getResource()->fetchAll(2);
		foreach ($results as $key => $value) {
			$results[$key]['name'] = stripslashes($value['name']);
		}
		return $results;
	}

	/**
	 * Update Meal Type
	 *
	 * @param int $id
	 * @param array $data
	 * @return Entity

	public function update($id, $data)
	{
	if (is_object($data)) {
	$data = (array) $data;
	}

	if (! isset($data['updated_date'])) {
	$data['updated_date'] = gmdate('Y-m-d H:i:s')    ;
	}

	$this->table->update($data, array('id' => $id));

	$resultSet = $this->table->select(array('id' => $id));
	if (0 === count($resultSet)) {
	throw new DomainException('Update operation failed or result in row deletion', 500);
	}
	return $resultSet->current();
	}

	 */

	/**
	 * Delete Meal Type
	 *
	 * @param int $id
	 * @return Entity
	 */
	public function delete($id) {
		$result = $this->table->delete(array('id' => $id));

		if (!$result) {
			return false;
		}

		return true;
	}
}
