<?php
namespace MealType\V1\Rest\MealType;

class MealTypeEntity
{
}
