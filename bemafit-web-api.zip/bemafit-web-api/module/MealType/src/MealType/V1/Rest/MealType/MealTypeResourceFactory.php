<?php
namespace MealType\V1\Rest\MealType;

class MealTypeResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('MealType\V1\Rest\MealTypeMapperTableGateway');
        return new MealTypeResource($mapper);
    }
}
