<?php
namespace MealType\V1\Rest\MealType;

use Zend\Paginator\Paginator;

class MealTypeCollection extends Paginator
{
}
