<?php
namespace MealType\V1\Rest\MealType;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class MealTypeResource extends AbstractResourceListener
{
    protected $mapper;
 
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }

    /**
     * Create a resource
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        @$data->userId = $this->getIdentity()->getUserId();
        $result = $this->mapper->create($data);

        if ($result) {
            return array('meta'=>array('status'=>'ok','code'=>200,'method_name'=>'Create meal type'));
        }
    }

    /**
     * Delete a resource
     * Not using as per current
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function delete($id)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The DELETE method has not been defined for individual resources');
    }

    /**
     * Delete a collection, or members of a collection
     * Not using as per current
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The DELETE method has not been defined for collections');
    }

    /**
     * Fetch a resource
     * Not using as per current
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($id)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The GET method has not been defined for individual resources');
    }

    /**
     * Fetch a resource by name
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetchByName($name)
    {
        return $this->fetchByName($name);
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($params = array())
    {
        $locale = $this->getEvent()->getRequest()->getQuery('locale');
        $result =  $this->mapper->fetchAll($this->getIdentity()->getUserId(), $locale);
        return array(
                'meta'=>array('status'=>'ok','code'=>200,'method_name'=>'get meal type'),'meal_type'=>$result
                );
    }

    /**
     * Patch (partial in-place update) a resource
     * Not using as per current
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PATCH method has not been defined for individual resources');
    }

    /**
     * Replace a collection or members of a collection
     * Not using as per current
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     * Not using as per current
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for individual resources');
    }
}
