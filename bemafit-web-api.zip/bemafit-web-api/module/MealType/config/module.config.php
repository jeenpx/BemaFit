<?php
return array(
    'router' => array(
        'routes' => array(
            'meal-type.rest.meal-type' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/meal-type[/:meal_type_id]',
                    'defaults' => array(
                        'controller' => 'MealType\\V1\\Rest\\MealType\\Controller',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            0 => 'meal-type.rest.meal-type',
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'MealType\\V1\\Rest\\MealType\\MealTypeResource' => 'MealType\\V1\\Rest\\MealType\\MealTypeResourceFactory',
        ),
    ),
    'zf-rest' => array(
        'MealType\\V1\\Rest\\MealType\\Controller' => array(
            'listener' => 'MealType\\V1\\Rest\\MealType\\MealTypeResource',
            'route_name' => 'meal-type.rest.meal-type',
            'route_identifier_name' => 'meal_type_id',
            'collection_name' => 'meal_type',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'MealType\\V1\\Rest\\MealType\\MealTypeEntity',
            'collection_class' => 'MealType\\V1\\Rest\\MealType\\MealTypeCollection',
            'service_name' => 'MealType',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'MealType\\V1\\Rest\\MealType\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'MealType\\V1\\Rest\\MealType\\Controller' => array(
                0 => 'application/vnd.meal-type.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
        ),
        'content_type_whitelist' => array(
            'MealType\\V1\\Rest\\MealType\\Controller' => array(
                0 => 'application/vnd.meal-type.v1+json',
                1 => 'application/json',
            ),
        ),
    ),
    'zf-hal' => array(
        'metadata_map' => array(
            'MealType\\V1\\Rest\\MealType\\MealTypeEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'meal-type.rest.meal-type',
                'route_identifier_name' => 'meal_type_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'MealType\\V1\\Rest\\MealType\\MealTypeCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'meal-type.rest.meal-type',
                'route_identifier_name' => 'meal_type_id',
                'is_collection' => true,
            ),
        ),
    ),
    'zf-mvc-auth' => array(
        'authorization' => array(
            'MealType\\V1\\Rest\\MealType\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
        ),
    ),
    'zf-content-validation' => array(
        'MealType\\V1\\Rest\\MealType\\Controller' => array(
            'input_filter' => 'MealType\\V1\\Rest\\MealType\\Validator',
        ),
    ),
    'input_filter_specs' => array(
        'MealType\\V1\\Rest\\MealType\\Validator' => array(
            0 => array(
                'required' => true,
                'validators' => array(),
                'filters' => array(),
                'name' => 'meal_type',
            ),
        ),
    ),
);
