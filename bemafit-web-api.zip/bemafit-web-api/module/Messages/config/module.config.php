<?php
return array(
    'router' => array(
        'routes' => array(
            'messages.rest.message' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/user[/:user_id]/message[/:friend_id][/:message_id]',
                    'defaults' => array(
                        'controller' => 'Messages\\V1\\Rest\\Message\\Controller',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            0 => 'messages.rest.message',
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'Messages\\V1\\Rest\\Message\\MessageResource' => 'Messages\\V1\\Rest\\Message\\MessageResourceFactory',
        ),
    ),
    'zf-rest' => array(
        'Messages\\V1\\Rest\\Message\\Controller' => array(
            'listener' => 'Messages\\V1\\Rest\\Message\\MessageResource',
            'route_name' => 'messages.rest.message',
            'route_identifier_name' => 'message_id',
            'collection_name' => 'message',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'DELETE',
                2 => 'POST',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
                2 => 'DELETE',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'Messages\\V1\\Rest\\Message\\MessageEntity',
            'collection_class' => 'Messages\\V1\\Rest\\Message\\MessageCollection',
            'service_name' => 'Message',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'Messages\\V1\\Rest\\Message\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'Messages\\V1\\Rest\\Message\\Controller' => array(
                0 => 'application/vnd.messages.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
        ),
        'content_type_whitelist' => array(
            'Messages\\V1\\Rest\\Message\\Controller' => array(
                0 => 'application/vnd.messages.v1+json',
                1 => 'application/json',
            ),
        ),
    ),
    'zf-hal' => array(
        'metadata_map' => array(
            'Messages\\V1\\Rest\\Message\\MessageEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'messages.rest.message',
                'route_identifier_name' => 'message_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'Messages\\V1\\Rest\\Message\\MessageCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'messages.rest.message',
                'route_identifier_name' => 'message_id',
                'is_collection' => true,
            ),
        ),
    ),
    'zf-mvc-auth' => array(
        'authorization' => array(
            'Messages\\V1\\Rest\\Message\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => true,
                ),
            ),
        ),
    ),
    'zf-content-validation' => array(
        'Messages\\V1\\Rest\\Message\\Controller' => array(
            'input_filter' => 'Messages\\V1\\Rest\\Message\\Validator',
        ),
    ),
    'input_filter_specs' => array(
        'Messages\\V1\\Rest\\Message\\Validator' => array(
            0 => array(
                'name' => 'message',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
            ),
        ),
    ),
    'messages_push_notificatin_interval' => 10,
);
