<?php
namespace Messages\V1\Rest\Message;

class MessageEntity
{
}
