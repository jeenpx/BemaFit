<?php
namespace Messages\V1\Rest\Message;

class MessageResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('Messages\V1\Rest\MessageMapperTableGateway');
        return new MessageResource($mapper);
    }
}
