<?php
namespace Messages\V1\Rest\Message;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class MessageResource extends AbstractResourceListener
{
    protected $mapper;
 
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }

    /**
     * Create a resource
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        $data->friendId = $this->getEvent()->getRouteMatch()->getParam('friend_id');
        $data->currentUserId = $this->getIdentity()->getUserId();
        return $this->mapper->create($data);
    }

    /**
     * Delete a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function delete($id)
    {
        $data['friendId'] = $this->getEvent()->getRouteMatch()->getParam('friend_id');
        $data['currentUserId'] = $this->getIdentity()->getUserId();
        $data['messageId'] = $id;
        return $this->mapper->delete($data);
        exit;
    }

    /**
     * Delete a collection, or members of a collection
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        $data['friendId'] = $this->getEvent()->getRouteMatch()->getParam('friend_id');
        $data['currentUserId'] = $this->getIdentity()->getUserId();
        return $this->mapper->deleteList($data);
    }

    /**
     * Fetch a resource
     * Not using as per current system requirement
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($id)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The GET method has not been defined for individual resources');
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($data = array())
    {
        $data->friendId = $this->getEvent()->getRouteMatch()->getParam('friend_id');
        $data->currentUserId = $this->getIdentity()->getUserId();
        $data->offset = $this->getEvent()->getRequest()->getQuery('offset', 0);
        $data->limit = $this->getEvent()->getRequest()->getQuery('limit', 10);
        return $this->mapper->fetchAll($data);
    }

    /**
     * Patch (partial in-place update) a resource
     * Not using as per current system requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PATCH method has not been defined for individual resources');
    }

    /**
     * Replace a collection or members of a collection
     * Not using as per current system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     * Not using as per current system requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for individual resources');
    }
}
