<?php
namespace Messages\V1\Rest\Message;

use Zend\Paginator\Paginator;

class MessageCollection extends Paginator
{
}
