<?php

namespace Messages\V1\Rest\Message;

use Zend\Mvc\Controller\AbstractActionController;

use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController {
	/**
	 * @var TableGateway
	 */
	protected $table;

	/**
	 * @param TableGateway $table
	 */
	public function __construct(TableGateway $table) {
		$this->table = $table;
	}

	public function getAdapter() {
		$sm            = $this->getServiceLocator();
		$this->adapter = $sm->get('Db\Adapter\Adapter');
		return $this->adapter;
	}

	public function getFymUserDetailTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('User\Model\FymUserDetailTable');
		return $this->Table;
	}

	public function getFriendRequestDetailTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('User\Model\FriendRequestDetailTable');
		return $this->Table;
	}

	public function getUserTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
		return $this->Table;
	}

	public function getUserDetailTable() {
		$sm          = $this->getServiceLocator();
		$this->Table = $sm->get('User\Model\UserDetailTable');
		return $this->Table;
	}

	/**
	 * Create message
	 *
	 * @param array data
	 * @return Entity
	 */
	public function create($data) {
		/*
		$utilityObj = new \Application\Service\Utility();
		$payload['alert'] = 'this is a spaced content';
		$utilityObj->sendIOSPushnotification(array('85abaab1086453510a34dff1a3f2da3198385ef62ba9f8fd9a308f2e0e164915'), $payload, 'message_sent');

		 */
		$this->getAdapter();
		$config      = $this->getServiceLocator()->get('Config');
		$friend_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data->friendId);
		if (!$friend_info) {
			return \Application\Service\FymApiProblem::ApiProblem(404, 'Friend not found');
		}
		$friendId      = $friend_info->id;
		$currentUserId = $data->currentUserId;

		$current_user_info = $this->getFymUserDetailTable()->getUserDetailsById($currentUserId);
		if (!$current_user_info) {
			return \Application\Service\FymApiProblem::ApiProblem(404, 'User not found');
		}

		$is_friends = $this->getFriendRequestDetailTable()->isFriends($currentUserId, $friendId);
		if (!$is_friends) {
			return \Application\Service\FymApiProblem::ApiProblem(406, 'Message cannot be sent to non friends');
		}

		$apiData['guid']                       = md5(uniqid(rand(), true));
		$apiData['message']                    = urlencode($data->message);
		$apiData['sender_id']                  = $currentUserId;
		$apiData['receiver_id']                = $friendId;
		$apiData['sender_message_status_id']   = 1;
		$apiData['receiver_message_status_id'] = 8;
		$apiData['created_date']               = gmdate('Y-m-d H:i:s');
		$apiData['thread_id']                  = ($currentUserId < $friendId)?$currentUserId.$friendId:$friendId.$currentUserId;

		$sql = "SELECT  * from message m WHERE m.sender_id=$currentUserId AND m.receiver_id = $friendId
                ORDER BY m.created_date DESC
                LIMIT 0,1";

		$statement = $this->adapter->createStatement($sql);

		$result   = $statement->execute();
		$messages = $result->getResource()->fetchAll(2);

		$this->table->insert($apiData);
		$newMessageId = $this->table->lastInsertValue;

		$preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
		//AND receiver_message_status_id = 7

		$user_dtails_info     = $this->getUserDetailTable()->getUserDetailsById($friend_info->user_id);
		$sendPushNotification = (!empty($user_dtails_info->push_notification) && $user_dtails_info->push_notification == 'Yes')?true:false;

		if (!empty($friend_info->device_token) && $sendPushNotification) {

			$utilityObj = $this->getServiceLocator()->get('utility_service');
			$diff       = 0;
			if (isset($messages[0])) {
				$diff = ($messages[0]['receiver_message_status_id'] == 7)?floor((strtotime($apiData['created_date'])-strtotime($messages[0]['created_date']))/60):0;
			}

			//Logic tempararly commented
			//if ($diff > $config['messages_push_notificatin_interval'] || empty($messages)) {
			$alert = (strlen($apiData['message']) > 235)?substr($apiData['message'], 0, 232).'...':$apiData['message'];

			$device_tokens               = unserialize($friend_info->device_token);
			$payload['alert']            = $alert;
			$payload['sender_id']        = $current_user_info->guid;
			$payload['sender_user_name'] = $current_user_info->username;
			$payload['message_id']       = $apiData['guid'];
			$payload['type']             = 'message_sent';
			$utilityObj->sendIOSPushnotification($device_tokens, $payload, 'message_sent');
			//}
		}

		if ($newMessageId > 0) {
			$image_url          = empty($current_user_info->profile_photo)?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$current_user_info->profile_photo);
			$reveiver_image_url = empty($friend_info->profile_photo)?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$friend_info->profile_photo);
			return array(
				'meta'         => array('status'         => 'OK', 'code'         => 200, 'methodName'         => 'sendMessage'),
				'message'      => array('message_id'      => $apiData['guid'], 'sender_id'      => $currentUserId, 'sender_user_name'      => $current_user_info->username, 'sender_first_name'      => $current_user_info->first_name, 'sender_last_name'      => $current_user_info->last_name, 'sender_photo'      => $image_url,
					'receiver_id' => $data->friendId, 'receiver_user_name' => $friend_info->username, 'receiver_first_name' => $friend_info->first_name, 'receiver_last_name' => $friend_info->last_name, 'receiver_photo' => $reveiver_image_url,
					'message'     => urldecode($apiData['message']), 'read_status'     => 'Read', 'created_date'     => $apiData['created_date'],
				));
		} else {
			return \Application\Service\FymApiProblem::ApiProblem(500, 'Error occured');
		}

	}

	/**
	 * Delete message
	 *
	 * @param array data
	 * @return Entity
	 */
	public function delete($data) {
		$this->getAdapter();
		$friend_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data['friendId']);
		if (!$friend_info) {
			return \Application\Service\FymApiProblem::ApiProblem(404, 'Friend not found');
		}
		$friendId      = $friend_info->id;
		$currentUserId = $data['currentUserId'];

		$resultSet    = $this->table->select(array('guid' => $data['messageId']));
		$message_data = $resultSet->current();

		if (!$message_data) {
			return \Application\Service\FymApiProblem::ApiProblem(404, 'Message not found');
		}

		if (($message_data->receiver_id == $friendId && $message_data->sender_id == $currentUserId) || ($message_data->receiver_id == $currentUserId && $message_data->sender_id == $friendId)) {
			if ($message_data->sender_id == $currentUserId) {
				$apiData['sender_message_status_id'] = 4;
			} else {
				$apiData['receiver_message_status_id'] = 4;
			}

			$apiData['updated_date'] = gmdate('Y-m-d H:i:s');

			$this->table->update($apiData, array('guid' => $data['messageId'], 'id' => $message_data->id));
		}

		return \Application\Service\FymApiResponse::FymApiResponse(array(
				'meta' => array('status' => 'OK', 'code' => 200, 'methodName' => 'deleteMessage'),
			));

	}

	/**
	 * Fetch all message
	 *
	 * @param array data
	 * @return Entity
	 */
	public function fetchAll($data) {
		$this->getAdapter();
		if (!isset($data->friendId)) {
			return $this->getInbox($data);
			exit;
		}
		$config = $this->getServiceLocator()->get('Config');
		//$this->getFeedMapper()->insertCustomFeedData('goal', 3, 120);

		$friend_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data->friendId);
		if (!$friend_info) {
			return \Application\Service\FymApiProblem::ApiProblem(404, 'Friend not found');
		}
		$friendId      = $friend_info->id;
		$currentUserId = $data->currentUserId;

		$sql = "SELECT  SQL_CALC_FOUND_ROWS   m.id,m.guid AS message_id, us.guid as sender_id, us.username as sender_user_name,  us.first_name sender_first_name, us.last_name AS sender_last_name, us.profile_photo AS sender_photo,
                        ur.guid as receiver_id,  ur.username as receiver_user_name, ur.first_name AS receiver_first_name,  ur.last_name AS receiver_last_name, ur.profile_photo as reciver_photo, m.message ,m.created_date
                FROM message m
                JOIN user us ON m.sender_id = us.id
                JOIN user ur ON m.receiver_id=ur.id
                WHERE IF(m.sender_id= ?, m.sender_message_status_id<>4,1)  AND
                      IF(m.receiver_id= ?, m.receiver_message_status_id<>4,1)  AND
                      ((m.sender_id=? AND m.receiver_id= ?) OR (m.sender_id= ? AND m.receiver_id=?)  )
                ORDER BY m.created_date DESC
                LIMIT ".$data->offset.", ".$data->limit;

		$statement = $this->adapter->createStatement($sql, array($currentUserId, $currentUserId, $friendId, $currentUserId, $currentUserId, $friendId));

		$result             = $statement->execute();
		$messages           = $result->getResource()->fetchAll(2);
		$total_rows         = $this->adapter->createStatement('SELECT FOUND_ROWS()  as total_rows')->execute()->getResource()->fetchAll()[0]['total_rows'];
		$message_list       = array();
		$preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
		foreach ($messages as $message) {
			$image_url          = empty($message['sender_photo'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$message['sender_photo']);
			$receiver_image_url = empty($message['reciver_photo'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$message['reciver_photo']);

			$message_list[] = array('message_id' => $message['message_id'], 'sender_id' => $message['sender_id'], 'sender_user_name' => $message['sender_user_name'], 'sender_first_name' => $message['sender_first_name'], 'sender_last_name' => $message['sender_last_name'], 'sender_photo' => $image_url,
				'receiver_id'                       => $message['receiver_id'], 'receiver_user_name'                       => $message['receiver_user_name'], 'receiver_first_name'                       => $message['receiver_first_name'], 'receiver_last_name'                       => $message['receiver_last_name'], 'receiver_photo'                       => $receiver_image_url,
				'message'                           => urldecode($message['message']), 'read_status'                           => 'Read', 'created_date'                           => $message['created_date']);
		}

		$this->getFriendRequestDetailTable()->updateMessageAsRead($currentUserId, $friendId);

		/*$this->table->update(
		array('receiver_message_status_id'=>7, 'updated_date'=>gmdate('Y-m-d H:i:s')    ),
		array('sender_id' => $friendId, 'receiver_id' => $currentUserId)
		);*/

		return array(
			'meta'           => array('status'           => 'OK', 'code'           => 200, 'methodName'           => 'getMessageThread'),
			'messages'       => $message_list,
			'total_messages' => $total_rows
		);
	}

	/**
	 * Get Inbox messages
	 *
	 * @param array data
	 * @return Entity
	 */
	public function getInbox($data) {
		$config        = $this->getServiceLocator()->get('Config');
		$currentUserId = $data->currentUserId;
		$sql           = "SELECT  SQL_CALC_FOUND_ROWS   m.guid as message_id,m.message,  m.sender_message_status_id, m.receiver_message_status_id, m.sender_id, m.receiver_id, m.created_date,
                us.guid AS sender_id, us.username as sender_user_name, us.first_name sender_first_name, us.last_name AS sender_last_name, us.profile_photo AS sender_photo,
                ur.guid AS receiver_id, ur.username as receiver_user_name, ur.first_name AS receiver_first_name,  ur.last_name AS receiver_last_name, ur.profile_photo AS receiver_photo,
                IF(m.sender_id=?,m.sender_message_status_id,m.receiver_message_status_id) AS read_status
                FROM message m
                JOIN user us ON m.sender_id = us.id
                JOIN user ur ON m.receiver_id=ur.id
                WHERE  m.created_date = (
                              SELECT MAX(m2.created_date)
                              FROM message m2
                              WHERE m.thread_id=m2.thread_id
                              AND IF(m2.sender_id= ?, m2.sender_message_status_id<>4,1)
                              AND IF(m2.receiver_id= ?, m2.receiver_message_status_id<>4,1)
                              GROUP BY m2.thread_id
                               )
                AND (m.sender_id=? OR m.receiver_id=?)
                AND us.status_id=1 AND ur.status_id=1
                ORDER BY m.created_date DESC
                LIMIT ".$data->offset.", ".$data->limit;

		$statement = $this->adapter->createStatement($sql, array($currentUserId, $currentUserId, $currentUserId, $currentUserId, $currentUserId));

		$result       = $statement->execute();
		$messages     = $result->getResource()->fetchAll(2);
		$total_rows   = $this->adapter->createStatement('SELECT FOUND_ROWS()  as total_rows')->execute()->getResource()->fetchAll()[0]['total_rows'];
		$message_list = array();

		$preview_bucket_url = $config['user_photo_Settings']['thumbs'][0]['profile200']['bucket'];
		foreach ($messages as $message) {
			$sender_image_url   = empty($message['sender_photo'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$message['sender_photo']);
			$receiver_image_url = empty($message['receiver_photo'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$message['receiver_photo']);
			$read_status        = ($message['read_status'] == 8)?"UnRead":"Read";
			$message_list[]     = array('message_id' => $message['message_id'], 'sender_id' => $message['sender_id'], 'sender_user_name' => $message['sender_user_name'], 'sender_first_name' => $message['sender_first_name'], 'sender_last_name' => $message['sender_last_name'], 'sender_photo' => $sender_image_url,
				'receiver_id'                           => $message['receiver_id'], 'receiver_user_name'                           => $message['receiver_user_name'], 'receiver_first_name'                           => $message['receiver_first_name'], 'receiver_last_name'                           => $message['receiver_last_name'], 'receiver_photo'                           => $receiver_image_url,
				'message'                               => urldecode($message['message']), 'read_status'                               => $read_status, 'created_date'                               => $message['created_date']);
		}

		$unread_count = $this->adapter->createStatement("SELECT COUNT(m.id) AS unread_count FROM message m WHERE m.receiver_id=$currentUserId  AND m.receiver_message_status_id=8")->execute()->getResource()->fetchAll()[0]['unread_count'];

		return array(
			'meta'           => array('status'           => 'OK', 'code'           => 200, 'methodName'           => 'getMessages'),
			'messages'       => $message_list,
			'total_messages' => $total_rows,
			'unread_count'   => $unread_count
		);

	}

	/**
	 * Delete list messages
	 *
	 * @param array data
	 * @return Entity
	 */
	public function deleteList($data) {
		$friend_info = $this->getFymUserDetailTable()->getUserDetailsByGuid($data['friendId']);
		if (!$friend_info) {
			return \Application\Service\FymApiProblem::ApiProblem(404, 'Friend not found');
		}
		$friendId      = $friend_info->id;
		$currentUserId = $data['currentUserId'];

		if ($friendId > 0 && $currentUserId > 0) {
			$deleteTime = gmdate('Y-m-d H:i:s');
			$this->table->update(
				array('sender_message_status_id' => 4, 'updated_date' => $deleteTime),
				array('sender_id'                => $currentUserId, 'receiver_id'                => $friendId)
			);

			$this->table->update(
				array('receiver_message_status_id' => 4, 'updated_date' => $deleteTime),
				array('sender_id'                  => $friendId, 'receiver_id'                  => $currentUserId)
			);
		}
		return \Application\Service\FymApiResponse::FymApiResponse(array(
				'meta' => array('status' => 'OK', 'code' => 200, 'methodName' => 'deleteMessageThread'),
			));
	}
}
