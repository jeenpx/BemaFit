<?php
namespace Meal;

use ZF\Apigility\Provider\ApigilityProviderInterface;

use Meal\V1\Model\MealUnitMaster;
use Meal\V1\Model\MealUnitMasterTable;
use Meal\V1\Model\MealUnit;
use Meal\V1\Model\MealUnitTable;
use Meal\V1\Model\MealUnitNutritionFact;
use Meal\V1\Model\MealUnitNutritionFactTable;
use Meal\V1\Model\MealCategoryMaster;
use Meal\V1\Model\MealCategoryMasterTable;
use Meal\V1\Model\MealCategory;
use Meal\V1\Model\MealCategoryTable;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;

class Module implements ApigilityProviderInterface
{
    public function getConfig()
    {
        return include __DIR__ . '/../../config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'ZF\Apigility\Autoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__,
                ),
            ),
        );
    }

   
    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'Meal\V1\Rest\MealMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\Meal\MealMapper($adapter);
                },
                'Meal\V1\Rest\MealMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Meal\TableGateway('meal', $adapter);
                    return new V1\Rest\Meal\TableGatewayMapper($tableGateway);
                },
                'Meal\Model\MealUnitMasterTable' =>  function ($sm) {
                     $tableGateway = $sm->get('MealUnitMasterTableGateway');
                     $table = new MealUnitMasterTable($tableGateway);
                     return $table;
                },
                'MealUnitMasterTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new MealUnitMaster());
                     return new TableGateway('meal_unit_master', $dbAdapter, null, $resultSetPrototype);
                },
                'Meal\Model\MealUnitTable' =>  function ($sm) {
                     $tableGateway = $sm->get('MealUnitTableGateway');
                     $table = new MealUnitTable($tableGateway);
                     return $table;
                },
                'MealUnitTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new MealUnit());
                     return new TableGateway('meal_unit', $dbAdapter, null, $resultSetPrototype);
                },
                'Meal\Model\MealUnitNutritionFactTable' =>  function ($sm) {
                     $tableGateway = $sm->get('MealUnitNutritionFactTableGateway');
                     $table = new MealUnitNutritionFactTable($tableGateway);
                     return $table;
                },
                'MealUnitNutritionFactTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new MealUnitNutritionFact());
                     return new TableGateway('meal_unit_nutrition_fact', $dbAdapter, null, $resultSetPrototype);
                },
                'Meal\Model\MealCategoryMasterTable' =>  function ($sm) {
                     $tableGateway = $sm->get('MealCategoryMasterTableGateway');
                     $table = new MealCategoryMasterTable($tableGateway);
                     return $table;
                },
                'MealCategoryMasterTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new MealCategoryMaster());
                     return new TableGateway('meal_category_master', $dbAdapter, null, $resultSetPrototype);
                },
                'Meal\Model\MealCategoryTable' =>  function ($sm) {
                     $tableGateway = $sm->get('MealCategoryTableGateway');
                     $table = new MealCategoryTable($tableGateway);
                     return $table;
                },
                'MealCategoryTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new MealCategory());
                     return new TableGateway('meal_category', $dbAdapter, null, $resultSetPrototype);
                },
            )
        );
    }
}
