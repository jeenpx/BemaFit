<?php

namespace Meal\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class MealCategoryTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function create($category, $mealId)
    {
        $this->tableGateway->insert(array('meal_id'=>$mealId, 'meal_category_master_id'=>$category));
    }

    public function update($category, $mealId)
    {
        $this->tableGateway->update(array('meal_category_master_id'=>$category), array('meal_id'=>$mealId));
    }
}
