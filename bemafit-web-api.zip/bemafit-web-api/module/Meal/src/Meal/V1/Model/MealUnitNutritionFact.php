<?php
namespace Meal\V1\Model;

class MealUnitNutritionFact
{
    public function exchangeArray($data)
    {
        $this->id               = (isset($data['id'])) ? $data['id'] : null;
        $this->meal_unit_id     = (isset($data['meal_unit_id'])) ? $data['meal_unit_id'] : null;
        $this->nutrition_fact_id= (isset($data['nutrition_fact_id'])) ? $data['nutrition_fact_id'] : null;
        $this->value            = (isset($data['value'])) ? $data['value'] : null;
        $this->unit             = (isset($data['unit'])) ? $data['unit'] : null;
    }
}
