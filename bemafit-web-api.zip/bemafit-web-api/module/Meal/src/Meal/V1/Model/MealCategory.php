<?php
namespace Meal\V1\Model;

class MealCategory
{
    public function exchangeArray($data)
    {
        $this->id                         = (isset($data['id'])) ? $data['id'] : null;
        $this->meal_id                    = (isset($data['meal_id'])) ? $data['meal_id'] : null;
        $this->meal_category_master_id    = (isset($data['meal_category_master_id'])) ? $data['meal_category_master_id'] : null;
    }
}
