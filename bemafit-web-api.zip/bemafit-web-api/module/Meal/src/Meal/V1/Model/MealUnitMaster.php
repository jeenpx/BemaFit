<?php
namespace Meal\V1\Model;

class MealUnitMaster
{
   

    public function exchangeArray($data)
    {
        $this->id    = (isset($data['id'])) ? $data['id'] : null;
        $this->name  = (isset($data['name'])) ? $data['name'] : null;
    }
}
