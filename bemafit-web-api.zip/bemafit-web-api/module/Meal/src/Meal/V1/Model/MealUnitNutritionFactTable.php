<?php

namespace Meal\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class MealUnitNutritionFactTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }
    
    public function create($unitId, $nutritionFact, $value, $unit)
    {
        $this->tableGateway->insert(array('meal_unit_id'=>$unitId,'nutrition_fact_id'=>$nutritionFact,'value'=>$value));
        return $this->tableGateway->lastInsertValue;
    }

    public function update($unitId, $nutritionFact, $value, $unit)
    {
        $this->tableGateway->update(array('value'=>$value), array('meal_unit_id'=>$unitId,'nutrition_fact_id'=>$nutritionFact));
    }
}
