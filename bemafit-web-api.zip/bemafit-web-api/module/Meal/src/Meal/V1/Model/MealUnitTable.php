<?php

namespace Meal\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class MealUnitTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }
    
    public function create($unit_id, $meal_id)
    {
        $this->tableGateway->insert(array('unit_id'=>$unit_id, 'meal_id'=>$meal_id));
        return $this->tableGateway->lastInsertValue;
    }

    public function update($unitId, $mealId)
    {
        $this->tableGateway->update(array('unit_id'=>$unitId), array('meal_id'=>$mealId));
        $result = $this->tableGateway->select(array('unit_id'=>$unitId, 'meal_id'=>$mealId));
        return $result->current()->id;
    }
}
