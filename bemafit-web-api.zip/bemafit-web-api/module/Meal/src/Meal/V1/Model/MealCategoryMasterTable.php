<?php

namespace Meal\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class MealCategoryMasterTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }
    
    public function fetchByName($name)
    {
        $result = $this->tableGateway->select(array('name'=>$name,'status_id'=>1));
        return $result->current()->id;
    }

    public function fetchById($id)
    {
        $result = $this->tableGateway->select(array('id'=>$id,'status_id'=>1));
        return $result->current()->id;
    }

    public function isValid($name)
    {
        $result = $this->tableGateway->select(array('name'=>$name,'status_id'=>1));
       
        if (0 === count($result)) {
            return false;
        }
        return true;
    }


    public function isValidById($id)
    {
        $result = $this->tableGateway->select(array('id'=>$id,'status_id'=>1));
       
        if (0 === count($result)) {
            return false;
        }
        return true;
    }
}
