<?php

namespace Meal\V1\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Zend\Db\Adapter\Adapter;

class MealUnitMasterTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
         $this->tableGateway = $tableGateway;
    }

    public function fetchByName($name)
    {
        $unitResultSet = $this->tableGateway->select(array('name' => $name));

        if (0 === count($unitResultSet)) {
            return false;
        } else {
            return $unitResultSet;
        }
    }

    public function create($name)
    {
        $this->tableGateway->insert(array('name'=>$name));
        $unitResultSet = $this->tableGateway->select(array('name' => $name));
        return $unitResultSet;
    }
}
