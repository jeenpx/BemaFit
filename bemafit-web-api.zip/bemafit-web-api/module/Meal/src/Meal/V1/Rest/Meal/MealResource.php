<?php
namespace Meal\V1\Rest\Meal;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class MealResource extends AbstractResourceListener
{

    protected $mapper;
    
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }

    /**
     * Create a resource
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        $result = $this->mapper->create($data, $this->getIdentity()->getUserId());
        return array('meta'=>array('status'=>'ok', 'code'=>200, 'method_name'=>'Add Meal'), 'food'=>$result);
    }

    /**
     * Delete a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function delete($id)
    {
        $result = $this->mapper->delete($id, $this->getIdentity()->getUserId());
        return \Application\Service\FymApiResponse::FymApiResponse(array(
                             'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'Delete Meal'),
        ));
         
    }

    /**
     * Delete a collection, or members of a collection
     * Not using as per current system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The DELETE method has not been defined for collections');
    }

    /**
     * Fetch a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($id)
    {
        $locale = $this->getEvent()->getRequest()->getQuery('locale');
        $result = $this->mapper->fetch($id, $locale);
        return array(
                'meta'=>array('status'=>'ok','code'=>200,'method_name'=>'get food'),
                    'food'=>$result
                );
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($params = array())
    {
        $params->userId = $this->getIdentity()->getUserId();
        $foodList = $this->mapper->fetchAll($params);
        return array(
                'meta'=>array('status'=>'ok','code'=>200,'method_name'=>'get food'),
                    'food'=>$foodList
                );
    }

    /**
     * Patch (partial in-place update) a resource
     * Not using as per current system requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PATCH method has not been defined for individual resources');
    }

    /**
     * Replace a collection or members of a collection
     * Not using as per current system requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     *
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        $result = $this->mapper->update($id, $data, $this->getIdentity()->getUserId());
        return array('status'=>'ok','code'=>200,'method_name'=>'Update Meal','result'=>$result);
    }
}
