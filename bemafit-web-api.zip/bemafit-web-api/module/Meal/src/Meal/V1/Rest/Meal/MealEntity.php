<?php
namespace Meal\V1\Rest\Meal;

class MealEntity
{
    public $id;
    public $guid;
    public $name;
    public $meal_type_id;
    public $language_id;
    public $brand_name;
    public $serving_size;
    public $serving_size_unit;
    public $saving_per_container;
    public $vendor_verified;

    public function getArrayCopy()
    {
        return array(
            'id'     => $this->id,
            'guid' => $this->guid,
            'name'  => $this->name,
            'meal_type_id'  => $this->meal_type_id,
            'language_id'  => $this->language_id,
            'brand_name'  => $this->brand_name,
            'serving_size'  => $this->serving_size,
            'serving_size_unit'  => $this->serving_size_unit,
            'serving_per_container'  => $this->saving_per_container,
            'vendor_verified'  => $this->saving_per_container
        );
    }

    public function exchangeArray(array $array)
    {
        $this->id     = $array['id'];
        $this->guid = $array['guid'];
        $this->name  = $array['name'];
        $this->meal_type_id  = $array['meal_type_id'];
        $this->language_id  = $array['language_id'];
        $this->brand_name  = $array['brand_name'];
        $this->serving_size  = $array['serving_size'];
        $this->serving_size_unit  = $array['serving_size_unit'];
        $this->serving_per_container  = $array['serving_per_container'];
        $this->vendor_verified  = $array['vendor_verified'];
    }
}
