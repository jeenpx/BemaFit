<?php
namespace Meal\V1\Rest\Meal;

class MealResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('Meal\V1\Rest\MealMapperTableGateway');
        return new MealResource($mapper);
    }
}
