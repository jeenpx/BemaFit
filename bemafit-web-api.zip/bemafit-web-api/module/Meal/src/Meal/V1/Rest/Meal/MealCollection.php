<?php
namespace Meal\V1\Rest\Meal;

use Zend\Paginator\Paginator;

class MealCollection extends Paginator
{
}
