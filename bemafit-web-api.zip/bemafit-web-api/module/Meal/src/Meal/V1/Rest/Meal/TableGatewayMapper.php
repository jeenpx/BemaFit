<?php

namespace Meal\V1\Rest\Meal;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;
use Zend\Http\Client;
use Zend\Http\Client\Adapter\Curl;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }


    public function getMealTypeTable()
    {
        $sm = $this->getServiceLocator();
        $this->MealTypeTable = $sm->get('MealType\V1\Rest\MealTypeMapperTableGateway');
        return $this->MealTypeTable;
    }

    public function getUserDetailTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\Model\UserDetailTable');
        return $this->Table;
    }

    public function getMealUnitMasterTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Meal\Model\MealUnitMasterTable');
        return $this->Table;
    }

    public function getMealUnitTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Meal\Model\MealUnitTable');
        return $this->Table;
    }
    

    public function getMealUnitNutritionFactTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Meal\Model\MealUnitNutritionFactTable');
        return $this->Table;
    }

    public function getMealCategoryMasterTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Meal\Model\MealCategoryMasterTable');
        return $this->Table;
    }

    public function getMealCategoryTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Meal\Model\MealCategoryTable');
        return $this->Table;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }
    /**
    * return the day of the week
    *
    * @param array $data
    * @param integer userId
    * @return Entity
    */
    public function create($data, $userId)
    {
        $utilityObj = new \Application\Service\Utility();
        $locale     = $utilityObj->getLocale(!empty($data->locale)?$data->locale:'en');

        if ($locale=='es') {
            $languageId=2;
            $nameFld = 'name_es';
            $brandNameFld = 'brand_name_es';
        } else {
            $languageId=1;
            $nameFld = 'name';
            $brandNameFld = 'brand_name';
        }
        
        $resultSet = $this->table->select(array($nameFld => ($data->name),'status_id'=>1));
        if (!empty($resultSet->current()->id)) {
            return \Application\Service\FymApiProblem::ApiProblem(404, 'Meal Allready exist');
        }

        $guid = md5(uniqid(rand(), true));
        $unit = $this->getMealUnitMasterTable()->fetchByName($data->serving_size_unit);
                  
        if (!$unit) {
            $unit = $this->getMealUnitMasterTable()->create($data->serving_size_unit);
        }

        $unit = $unit->current();

        foreach ($data->category as $category) {
            if (empty($category['id']) || !$this->getMealCategoryMasterTable()->isValidById($category['id'])) {
                return \Application\Service\FymApiProblem::ApiProblem(404, 'Invalid Category');
            }
        }

        

        $apiData = array(
            'guid' => $guid,
            $nameFld => addslashes($data->name),
            'language_id' =>$languageId,
            $brandNameFld =>addslashes($data->brand_name),
            'vendor_verified'=>'No',
            'status_id' =>1,
            'created_by' => $userId,
            'added_date' =>gmdate('Y-m-d H:i:s')    ,

            'serving_size'=> $data->serving_size,
            'serving_size_unit' => $unit->id,
            'serving_per_container' => $data->serving_per_container
            );

        $this->table->insert($apiData);

        $id = $this->table->lastInsertValue;

        foreach ($data->category as $category) {
            $category = $this->getMealCategoryMasterTable()->fetchById($category['id']);
            $this->getMealCategoryTable()->create($category, $id);
        }

        $unitId = $this->getMealUnitTable()->create($unit->id, $id);

        $this->getMealUnitNutritionFactTable()->create($unitId, 1, !empty($data->calories)?$data->calories:0, 'cal');
        $this->getMealUnitNutritionFactTable()->create($unitId, 2, !empty($data->fat)?$data->fat:0, 'g');
        $this->getMealUnitNutritionFactTable()->create($unitId, 3, !empty($data->saturated)?$data->saturated:0, 'g');
        $this->getMealUnitNutritionFactTable()->create($unitId, 4, !empty($data->polyunsaturated)?$data->polyunsaturated:0, 'g');
        $this->getMealUnitNutritionFactTable()->create($unitId, 5, !empty($data->monosaturated)?$data->monosaturated:0, 'g');
        $this->getMealUnitNutritionFactTable()->create($unitId, 6, !empty($data->trans)?$data->trans:0, 'g');
        $this->getMealUnitNutritionFactTable()->create($unitId, 7, !empty($data->cholestrol)?$data->cholestrol:0, 'mg');
        $this->getMealUnitNutritionFactTable()->create($unitId, 8, !empty($data->sodium)?$data->sodium:0, 'mg');
        $this->getMealUnitNutritionFactTable()->create($unitId, 9, !empty($data->pottassium)?$data->pottassium:0, 'mg');
        $this->getMealUnitNutritionFactTable()->create($unitId, 10, !empty($data->carbohydrates)?$data->carbohydrates:0, 'g');
        $this->getMealUnitNutritionFactTable()->create($unitId, 11, !empty($data->fiber)?$data->fiber:0, 'g');
        $this->getMealUnitNutritionFactTable()->create($unitId, 12, !empty($data->protien)?$data->protien:0, 'g');

        return $this->fetch($id, $locale);
    }

    /**
    * fetch meal details
    *
    * @param int id
    * @return Entity
    */
    public function fetch($id, $locale)
    {

        $this->getAdapter();

       
        if ($id>=1000000) {
            $resultSet = $this->table->select(array('upc_id' => $id));

            if (0 === count($resultSet)) {
                    $result  =   $this->getDataApi($id);
                if (!$result->status) {
                    
                    $statement = $this->adapter->createStatement("insert into barcode_error_log (upc_code,error_message,date) values ($id,'".$result->errorMessage."','".gmdate('Y-m-d H:i:s')."') ");
                    $ins  = $statement->execute();

                    return \Application\Service\FymApiProblem::ApiProblem(404, $result->errorMessage);
                }

                //var_dump($result);die('sma');

                $guid = md5(uniqid(rand(), true));

                $unit = $this->getMealUnitMasterTable()->fetchByName($result->nf_serving_size_unit);
              
                if (!$unit) {
                    $unit = $this->getMealUnitMasterTable()->create($result->nf_serving_size_unit);
                }

                $unit = $unit->current();

                $apiData = array(
                    'guid' => $guid,
                    'name' => addslashes($result->item_name),
                    'language_id' =>1,
                    'brand_name' =>addslashes($result->brand_name),
                    'description' =>addslashes($result->item_description),
                    'vendor_verified'=>'No',
                    'status_id' =>1,
                    'created_by' => 1,
                    'added_date' =>gmdate('Y-m-d H:i:s')    ,

                    'serving_size'=> $result->nf_serving_size_qty,
                    'serving_size_unit' => $unit->id,
                    'serving_per_container' => $result->nf_servings_per_container,

                    'upc_id' => $id,
                    'upc_last_update' => date('Y-m-d H:i:s', strtotime($result->updated_at))
                    );
                    $this->table->insert($apiData);
                    $id = $this->table->lastInsertValue;

                    $unitId = $this->getMealUnitTable()->create($unit->id, $id);

                    $this->getMealUnitNutritionFactTable()->create($unitId, 1, !empty($result->nf_calories)?$result->nf_calories:0, 'cal');
                    $this->getMealUnitNutritionFactTable()->create($unitId, 2, !empty($result->nf_total_fat)?$result->nf_total_fat:0, 'g');
                    $this->getMealUnitNutritionFactTable()->create($unitId, 3, !empty($result->nf_saturated_fat)?$result->nf_saturated_fat:0, 'g');
                    $this->getMealUnitNutritionFactTable()->create($unitId, 4, !empty($result->nf_polyunsaturated_fat)?$result->nf_polyunsaturated_fat:0, 'g');
                    $this->getMealUnitNutritionFactTable()->create($unitId, 5, !empty($result->nf_monounsaturated_fat)?$result->nf_monounsaturated_fat:0, 'g');
                    $this->getMealUnitNutritionFactTable()->create($unitId, 6, !empty($result->nf_trans_fatty_acid)?$result->nf_trans_fatty_acid:0, 'g');
                    $this->getMealUnitNutritionFactTable()->create($unitId, 7, !empty($result->nf_cholesterol)?$result->nf_cholesterol:0, 'mg');
                    $this->getMealUnitNutritionFactTable()->create($unitId, 8, !empty($result->nf_sodium)?$result->nf_sodium:0, 'mg');
                    $this->getMealUnitNutritionFactTable()->create($unitId, 9, !empty($result->nf_pottassium)?$result->nf_pottassium:0, 'mg');
                    $this->getMealUnitNutritionFactTable()->create($unitId, 10, !empty($result->nf_total_carbohydrate)?$result->nf_total_carbohydrate:0, 'g');
                    $this->getMealUnitNutritionFactTable()->create($unitId, 11, !empty($result->nf_dietary_fiber)?$result->nf_dietary_fiber:0, 'g');
                    $this->getMealUnitNutritionFactTable()->create($unitId, 12, !empty($result->nf_protein)?$result->nf_protein:0, 'g');
            } else {

                $id = $resultSet->current()->id;
                // if (date('Y-m-d') == date('Y-m-d', strtotime($resultSet->current()->added_date)) or date('Y-m-d') == date('Y-m-d', strtotime($resultSet->current()->updated_date))) {
                //     $id = $resultSet->current()->id;
                // } else {
                //     $result  =   $this->getDataApi($id);

                //     if (!$result->status) {
                //         return \Application\Service\FymApiProblem::ApiProblem(404, $result->errorMessage);
                //     }
                //         //die(date('Y-m-d',strtotime($result->updated_at)).'!='.date('Y-m-d',strtotime($resultSet->current()->upc_last_update)));
                //     if (date('Y-m-d', strtotime($result->updated_at))!=date('Y-m-d', strtotime($resultSet->current()->upc_last_update))) {
                //         $unit = $this->getMealUnitMasterTable()->fetchByName($result->nf_serving_size_unit);
                //         $unit = $unit->current();

                //         $apiData = array(
                //             'name' => addslashes($result->item_name),
                //             'brand_name' =>addslashes($result->brand_name),
                //             'description' =>addslashes($result->item_description),
                //             'updated_by' => 1,
                //             'updated_date' =>gmdate('Y-m-d H:i:s')    ,

                //             'serving_size'=> $result->nf_serving_size_qty,
                //             'serving_size_unit' => $unit->id,
                //             'serving_per_container' => $result->nf_servings_per_container,

                //             'upc_last_update' => date('Y-m-d H:i:s', strtotime($result->updated_at))
                //         );

                //         $id = $resultSet->current()->id;

                //         $this->table->update($apiData, array('id'=>$resultSet->current()->id));
                //         $unitId = $this->getMealUnitTable()->update($unit->id, $id);

                //         $this->getMealUnitNutritionFactTable()->update($unitId, 1, !empty($result->nf_calories)?$result->nf_calories:0, 'cal');
                //         $this->getMealUnitNutritionFactTable()->update($unitId, 2, !empty($result->nf_total_fat)?$result->nf_total_fat:0, 'g');
                //         $this->getMealUnitNutritionFactTable()->update($unitId, 3, !empty($result->nf_saturated_fat)?$result->nf_saturated_fat:0, 'g');
                //         $this->getMealUnitNutritionFactTable()->update($unitId, 4, !empty($result->nf_polyunsaturated_fat)?$result->nf_polyunsaturated_fat:0, 'g');
                //         $this->getMealUnitNutritionFactTable()->update($unitId, 5, !empty($result->nf_monounsaturated_fat)?$result->nf_monounsaturated_fat:0, 'g');
                //         $this->getMealUnitNutritionFactTable()->update($unitId, 6, !empty($result->nf_trans_fatty_acid)?$result->nf_trans_fatty_acid:0, 'g');
                //         $this->getMealUnitNutritionFactTable()->update($unitId, 7, !empty($result->nf_cholesterol)?$result->nf_cholesterol:0, 'mg');
                //         $this->getMealUnitNutritionFactTable()->update($unitId, 8, !empty($result->nf_sodium)?$result->nf_sodium:0, 'mg');
                //         $this->getMealUnitNutritionFactTable()->update($unitId, 9, !empty($result->nf_pottassium)?$result->nf_pottassium:0, 'mg');
                //         $this->getMealUnitNutritionFactTable()->update($unitId, 10, !empty($result->nf_total_carbohydrate)?$result->nf_total_carbohydrate:0, 'g');
                //         $this->getMealUnitNutritionFactTable()->update($unitId, 11, !empty($result->nf_dietary_fiber)?$result->nf_dietary_fiber:0, 'g');
                //         $this->getMealUnitNutritionFactTable()->update($unitId, 12, !empty($result->nf_protein)?$result->nf_protein:0, 'g');

                //     }
                    
                      
                // }
            }
        }
       
        if ($this->isValidMeal($id)) {
            $this->getAdapter();

            $utilityObj = new \Application\Service\Utility();
            $locale     = $utilityObj->getLocale($locale);
            
            if ($locale=='es') {
                $nameFld = 'IF(ISNULL(m.name_es),m.name,m.name_es) ';
            } else {
                $nameFld = 'IF(ISNULL(m.name),m.name_es,m.name) ';
            }

            $sql ="SELECT m.id,m.guid,$nameFld as name,m.serving_size,m.serving_size_unit,m.serving_per_container,".($locale=='es'?'m.brand_name_es':'m.brand_name')." as brand_name,      
            mu.id as unit_id,mum.name as unit
            FROM meal m
            LEFT JOIN meal_unit mu ON mu.meal_id= m.id and mu.unit_id=m.serving_size_unit
            LEFT JOIN meal_unit_master mum ON mum.id = m.serving_size_unit
            WHERE  m.id=".$id;

            $statement = $this->adapter->createStatement($sql);

            $result  = $statement->execute();
            $meal    = $result->current();

            if ($meal) {
                $sql ="SELECT nf.name,munf.value
                FROM meal_unit mu
                JOIN meal_unit_nutrition_fact munf ON munf.meal_unit_id = mu.id
                LEFT JOIN nutrition_fact nf ON nf.id = munf.nutrition_fact_id
                WHERE mu.meal_id=".$meal['id']." and mu.unit_id=".$meal['serving_size_unit'];
                
                $statement = $this->adapter->createStatement($sql);

                $result  = $statement->execute();
                $nutritionFacts   = $result->getResource()->fetchAll(2);

                foreach ($nutritionFacts as $nkey => $nutritionFact) {
                    ///$data[$unit['name']]=$nutritionFact;
                    $meal['nutrition_facts'][$nutritionFact['name']]=$nutritionFact['value'];
                }

                $sql ="SELECT mtm.id,".($locale=='es'?'mtm.name_es':'mtm.name')." as name
                FROM meal_type mt
                LEFT JOIN meal_type_master mtm ON mtm.id = mt.meal_type_master_id
                WHERE mt.meal_id=".$id;

                $statement = $this->adapter->createStatement($sql);

                $result  = $statement->execute();
                $mealType= $result->getResource()->fetchAll(2);
                $meal['meal_type']=$mealType;
                return $meal;

            } else {
                 return \Application\Service\FymApiProblem::ApiProblem(404, 'Meal not found');
            }
           
        } else {
             return \Application\Service\FymApiProblem::ApiProblem(404, 'Meal not found');
        }
    }

    /**
    * fetch meal details from nutritionix
    *
    * @param int upc_code
    * @return Entity
    */
    public function getDataApi($id)
    {
        $config = $this->getServiceLocator()->get('Config');
        $url = $config['nutritionix']['url'].'item?upc='.$id.'&appId='.$config['nutritionix']['appId'].'&appKey='.$config['nutritionix']['appKey'];
           
        $curl_handle=curl_init();
        curl_setopt($curl_handle, CURLOPT_URL, $url);
        curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
        curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
        $buffer = curl_exec($curl_handle);
        curl_close($curl_handle);
        $response =json_decode($buffer);
        if (empty($buffer)) {
            $response->status=false;
            $response->errorMessage='Internal Error';
            return $response;
        } else {
            if (isset($response->error_message)) {
                $response->status=false;
                $response->errorMessage=$response->error_message;

                return $response;
            } else {
                $response->status =true;
                return $response;
            }
            return $response;
        }








         
        // $adapter = new Curl();
        // $client = new Client($url);
        // $client->setAdapter($adapter);
            
        // $result = $client->send($client->getRequest());
       
        // if($result->getBody()){
        //     $response = json_decode($result->getBody());
        //     var_dump($response);
        //     if (!empty($response->error_message)) {
        //         $response->status=false;
        //         $response->errorMessage=$response->error_message;

        //         return $response;
        //     } else {
        //         $response->status =true;
        //         return $response;
        //     }
        // } else {
        //     die('sdsds');
        //     $response->status=false;
        //     $response->errorMessage='Internal Error';
        //     return $response;
        // }
    }

    /**
    * to check valid meal by id
    *
    * @param int upc_code
    * @return Entity
    */
    public function isValidMeal($id)
    {
        $resultSet = $this->table->select(array('id' => $id,'status_id'=>'1'));
        if (0 === count($resultSet)) {
            return false;
        }
        return true;
    }

    /**
    * to check valid meal by guid
    *
    * @param int upc_code
    * @return Entity
    */
    public function isValidMealByGuid($guid)
    {
        $resultSet = $this->table->select(array('guid' => $guid,'status_id'=>'1'));

        if (0 === count($resultSet)) {
            return false;
        }
        return true;
    }

    /**
    * to fetch meal by name
    *
    * @param int upc_code
    * @return Entity
    */
    public function fetchByName($name)
    {
        $resultSet = $this->table->select(array('name' => $name));
        
        if (0 === count($resultSet)) {
            throw new DomainException('Meal not found', 404);
        }
        return $resultSet->current()->id;
    }

    /**
    * to fetch meal by guid
    *
    * @param string $guid
    * @return Entity
    */
    public function getByGuid($guid)
    {
        $resultSet = $this->table->select(array('guid' => $guid));
        //print_r($resultSet->toArray());
        if (0 === count($resultSet)) {
            throw new DomainException('Meal not found', 404);
        }
        return $resultSet->current();
    }

    /**
    * to get meal count by user name
    *
    * @param int $userId
    * @return Entity
    */
    public function getMealCountByUser($userId)
    {
        $sql ="SELECT meal_type_master.id
        FROM meal_type_master
        JOIN user ON user.id = meal_type_master.created_by
        WHERE meal_type_master.status_id=1 AND (meal_type_master.created_by=".$userId." OR user.role='Admin')";
        
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        return $mealTypeCount = count($result->getResource()->fetchAll(2));
    }

    /**
    * to fetch all meal
    *
    * @param array $params
    * @return Entity
    */
    public function fetchAll($params)
    { 
        $config = $this->getServiceLocator()->get('Config');
        $this->getAdapter();

        $utilityObj = new \Application\Service\Utility();
        $locale     = $utilityObj->getLocale($params->locale);
        
        $where = "";
        $orderBy = "";
        $group =0;

        if (!empty($params->meal_type) and $params->meal_type!='All') {
            //$mealId   =   $this->getMealTypeTable()->fetchById($params->meal_type);
            $where .= " AND meal_type.meal_type_master_id = ".$params->meal_type;
        }
        
        if (!empty($params->keyword)) {
            $where .= " AND (  ".($locale=='es'?'m.name_es':'m.name')." like '%".addslashes($params->keyword)."%' OR ".($locale=='es'?'m.brand_name_es':'m.brand_name')." like '%".addslashes($params->keyword)."%'  ) ";
        }

        if (!empty($params->meal_category and $params->meal_category!='All')) {
            $where .= " AND meal_category_master.id='".$params->meal_category."' ";
        }

        $orderBy = ' ORDER BY m.calorie DESC';

        if (!empty($params->search_type and $params->search_type=='food_recommendation')) {

            $where .= " AND m.vendor_verified='Yes' ";
          
            $date   = !empty($params->date)?$params->date:date('Y-m-d');

            $mealCount = $this->getMealCountByUser($params['userId']);

            $user_info = $this->getUserDetailTable()->getUserDetailsById($params['userId']);

            $sql ="SELECT id
            FROM user_food_log
            WHERE status_id=1 AND approve='Yes' AND user_id=".$params['userId']." AND meal_date='".$date."'
            GROUP BY meal_type_id";
            
            $statement = $this->adapter->createStatement($sql);

            $result  = $statement->execute();
            $foodlogCount = $result->getResource()->fetchAll(2);

            $foodlogCount = (count($foodlogCount));

            $sql ="SELECT meal_date as date,SUM(meal_calorie) AS calorie,SUM(meal_protein) AS protein,SUM(meal_fibre) AS fibre,SUM(meal_fat) AS fat,SUM(meal_carb) AS carb
            FROM user_food_log
            WHERE status_id=1 AND approve='Yes' AND user_id=".$params['userId']." AND meal_date='".$date."'
            GROUP BY meal_date";
            
            $statement = $this->adapter->createStatement($sql);

            $result  = $statement->execute();
            $foodlogs = $result->getResource()->fetch();


            $sql ="SELECT exercise_date AS date,SUM(calorie_burned) AS calorie_burned
            FROM user_exercise_log
            WHERE status_id =1 AND user_id =".$params['userId']." AND (exercise_date='".$date."')
            GROUP BY exercise_date";

            $statement = $this->adapter->createStatement($sql);

            $result  = $statement->execute();
            $exerciselogs = $result->getResource()->fetch();

            if (is_array($foodlogs) || is_array($exerciselogs)) {
                if (is_array($foodlogs)) {
                    $calorieAchived    = !empty($foodlogs['calorie'])?$foodlogs['calorie']:0;
                    $proteinAchived    = !empty($foodlogs['protein'])?$foodlogs['protein']:0;
                    $fibreAchived      = !empty($foodlogs['fibre'])?$foodlogs['fibre']:0;
                    $fatAchived        = !empty($foodlogs['fat'])?$foodlogs['fat']:0;
                    $carbAchived       = !empty($foodlogs['carb'])?$foodlogs['carb']:0;
                } else {
                    $calorieAchived    = 0;
                    $proteinAchived    = 0;
                    $fibreAchived      = 0;
                    $fatAchived        = 0;
                    $carbAchived       = 0;
                }

                if (is_array($exerciselogs)) {
                    $calorieBurned    = $exerciselogs['calorie_burned'];
                } else {
                    $calorieBurned    = 0;
                }

                $remCount = $mealCount - $foodlogCount;
                                   
                $proteinRem =(($user_info->protein-$proteinAchived)/$remCount);
                $fatRem     =(($user_info->fat-$fatAchived)/$remCount);
                $carbsRem   =(($user_info->carbs-$carbAchived)/$remCount);
                $fiberRem   =(($user_info->fiber-$fibreAchived)/$remCount);
                $caloriesRem=((($user_info->calories-$calorieAchived)+$calorieBurned)/$remCount);
           
                //$where = '';
                $fixedPercentage =10;

                if ($proteinRem>0) {
                    $proteinPer = ($proteinRem*$fixedPercentage)/100;
                    $where .= " AND  (muf_protien.value>=0 and muf_protien.value<=".($proteinRem+$proteinPer).") ";
                } else {
                    $where .= " AND (muf_protien.value=0) ";
                }
                
                if ($fatRem>0) {
                    $fatPer = ($fatRem*$fixedPercentage)/100;
                    $where .= " AND  (muf_fat.value>=0 and muf_fat.value<=".($fatRem+$fatPer).") ";
                } else {
                    $where .= " AND  (muf_fat.value=0) ";
                }

                if ($carbsRem>0) {
                    $carbsPer = ($carbsRem*$fixedPercentage)/100;
                    $where .= " AND  (muf_carb.value>=0 and muf_carb.value<=".($carbsRem+$carbsPer).") ";
                } else {
                    $where .= " AND  (muf_carb.value=0) ";
                }

                if ($fiberRem>0) {
                    $fiberPer = ($fiberRem*$fixedPercentage)/100;
                    $where .= " AND  (muf_fiber.value>=0 and muf_fiber.value<=".($fiberRem+$fiberPer).") ";
                } else {
                    $where .= " AND  (muf_fiber.value=0) ";
                }

                if ($caloriesRem>0) {
                    $caloriesPer = ($caloriesRem*$fixedPercentage)/100;
                    $where .= " AND  (muf_cal.value>=0 and muf_cal.value<=".($caloriesRem+$caloriesPer).") ";
                } else {
                    $where .= " AND  (muf_cal.value=0) ";
                }
               //echo $where;

            } else {
                $user_info->calories;
                $proteinRem =(($user_info->protein)/$mealCount);
                $fatRem     =(($user_info->fat)/$mealCount);
                $carbsRem   =(($user_info->carbs)/$mealCount);
                $fiberRem   =(($user_info->fiber)/$mealCount);
                $caloriesRem=(($user_info->calories)/$mealCount);
                //no entry
                $where .= " AND  (muf_protien.value<=$proteinRem) ";
                $where .= " AND  (muf_fat.value<=$fatRem) ";
                $where .= " AND  (muf_carb.value<=$carbsRem) ";
                $where .= " AND  (muf_fiber.value<=$fiberRem) ";
                $where .= " AND  (muf_cal.value<=$caloriesRem) ";
               
            }

           $orderBy = ' ORDER BY m.calorie DESC';

        } else if (!empty($params->search_type and $params->search_type=='serving_size')) {
            $date   = !empty($params->date)?$params->date:date('Y-m-d');

            $mealCount = $this->getMealCountByUser($params['userId']);

            $user_info = $this->getUserDetailTable()->getUserDetailsById($params['userId']);

            $sql ="SELECT meal_date as date,SUM(meal_calorie) AS calorie
            FROM user_food_log
            WHERE status_id=1 AND approve='Yes' AND user_id=".$params['userId']." AND meal_date='".$date."'
            GROUP BY meal_date";
            
            $statement = $this->adapter->createStatement($sql);

            $result  = $statement->execute();
            $foodlogs = $result->getResource()->fetch();

            $sql ="SELECT exercise_date AS date,SUM(calorie_burned) AS calorie_burned
            FROM user_exercise_log
            WHERE status_id =1 AND user_id =".$params['userId']." AND (exercise_date='".$date."')
            GROUP BY exercise_date";

            $statement = $this->adapter->createStatement($sql);

            $result  = $statement->execute();
            $exerciselogs = $result->getResource()->fetch();

            if (is_array($foodlogs) || is_array($exerciselogs)) {
                if (is_array($foodlogs)) {
                    $calorieAchived    = !empty($foodlogs['calorie'])?$foodlogs['calorie']:0;
                } else {
                    $calorieAchived    = 0;
                }

                if (is_array($exerciselogs)) {
                    $calorieBurned    = $exerciselogs['calorie_burned'];
                } else {
                    $calorieBurned    = 0;
                }
               
                $caloriesRem=((($user_info->calories-$calorieAchived)+$calorieBurned));

                if ($caloriesRem>0) {
                    $where .= " AND  (meal_unit_nutrition_fact.nutrition_fact_id =1 and meal_unit_nutrition_fact.value<=".($caloriesRem).") ";
                } else {
                    $where .= " AND  (meal_unit_nutrition_fact.nutrition_fact_id =1 and meal_unit_nutrition_fact.value<=0) ";
                }

               
            }

            $orderBy = ' ORDER BY m.calorie DESC';
        } else if(!empty($params->search_type and $params->search_type=='daily_meal_plan')){
            
            $sql ="SELECT value
            FROM system_settings
            WHERE settings='daily_meal_plan_verified_meal_only'
            ";

            $statement = $this->adapter->createStatement($sql);

            $result  = $statement->execute();
            $settings = $result->getResource()->fetch();

    
            if($settings['value']=='verified'){
                $where .= " AND vendor_verified ='Yes' ";
            }else if($settings['value']=='non-verified'){
                $where .= " AND vendor_verified ='No' ";
            } else {
                $where .= " ";
            }
            
        } else {
            if ($locale=='es') {
                $orderBy = 'ORDER BY if(m.name_es = "" or m.name_es is null,1,0),m.name_es';
            } else {
                $orderBy = 'ORDER BY if(m.name = "" or m.name is null,1,0),m.name';
            }
            //echo $orderBy;
        }

        if (empty($params->limit)) {
            $params->limit =10;
        }

        if (empty($params->offset)) {
            $params->offset =0;
        }

        // if (!empty($params->search_type) and $params->search_type=='food_recommendation') {
        //     $addFld = ',muf_protien.value as protien,muf_fat.value as fat,muf_carb.value as carb,muf_fiber.value as fiber,muf_cal.value as cal ';
        // } else {
        //     $addFld = ',meal_unit_nutrition_fact.value as calorie';
        // }

        if ($locale=='es') {
            $nameFld = 'IF(ISNULL(m.name_es),m.name,m.name_es) ';
        } else {
            $nameFld = 'IF(ISNULL(m.name),m.name_es,m.name) ';
        }

        $sql ="SELECT m.id,m.guid,$nameFld as name,m.serving_size,m.serving_per_container,      
        m.serving_size_unit as unit_id,mum.name as unit,meal_image.file as meal_image,".($locale=='es'?'m.brand_name_es':'m.brand_name')." as brand_name,vendor_verified
        FROM meal m";

        

        if (!empty($params->meal_type) and $params->meal_type!='All') {
           
            $sql .="
            LEFT JOIN meal_type ON meal_type.meal_id = m.id
            LEFT JOIN meal_type_master ON meal_type_master.id = meal_type.meal_type_master_id";

            $group =1;
        }

        if (!empty($params->meal_category and $params->meal_category!='All')) { 
                   
            $sql .="
            LEFT JOIN meal_category ON meal_category.meal_id =  m.id
            LEFT JOIN meal_category_master ON meal_category_master.id =  meal_category.meal_category_master_id";

            $group =1;
        }

        $sql .="
        LEFT JOIN meal_image ON meal_image.meal_id = m.id
        LEFT JOIN meal_unit_master mum ON mum.id = m.serving_size_unit 
        ";


        if (!empty($params->search_type) and $params->search_type=='food_recommendation') {
            //AND mu.unit_id=m.serving_size_unit
            $sql .="
            JOIN meal_unit mu ON mu.meal_id= m.id and mu.unit_id=m.serving_size_unit 
            LEFT JOIN meal_unit_nutrition_fact muf_protien ON muf_protien.meal_unit_id=mu.id AND muf_protien.nutrition_fact_id=12
            LEFT JOIN meal_unit_nutrition_fact muf_fat ON muf_fat.meal_unit_id=mu.id AND muf_fat.nutrition_fact_id=2
            LEFT JOIN meal_unit_nutrition_fact muf_carb ON muf_carb.meal_unit_id=mu.id AND muf_carb.nutrition_fact_id=10
            LEFT JOIN meal_unit_nutrition_fact muf_fiber ON muf_fiber.meal_unit_id=mu.id AND muf_fiber.nutrition_fact_id=11
            LEFT JOIN meal_unit_nutrition_fact muf_cal ON muf_cal.meal_unit_id=mu.id AND muf_cal.nutrition_fact_id=1";
        } else if(!empty($params->search_type) and $params->search_type=='serving_size'){
            $sql .="
            JOIN meal_unit mu ON mu.meal_id= m.id and mu.unit_id=m.serving_size_unit  
            LEFT JOIN meal_unit_nutrition_fact ON meal_unit_nutrition_fact.meal_unit_id = mu.id AND nutrition_fact_id=1";
        }


        // if (!empty($params->search_type) and $params->search_type=='food_recommendation') {
        //     //AND mu.unit_id=m.serving_size_unit
        //     $sql .="
        //     LEFT JOIN meal_unit mu ON mu.meal_id= m.id
        //     LEFT JOIN meal_unit_master mum ON mum.id = mu.unit_id 
        //     LEFT JOIN meal_unit_nutrition_fact muf_protien ON muf_protien.meal_unit_id=mu.id AND muf_protien.nutrition_fact_id=12
        //     LEFT JOIN meal_unit_nutrition_fact muf_fat ON muf_fat.meal_unit_id=mu.id AND muf_fat.nutrition_fact_id=2
        //     LEFT JOIN meal_unit_nutrition_fact muf_carb ON muf_carb.meal_unit_id=mu.id AND muf_carb.nutrition_fact_id=10
        //     LEFT JOIN meal_unit_nutrition_fact muf_fiber ON muf_fiber.meal_unit_id=mu.id AND muf_fiber.nutrition_fact_id=11
        //     LEFT JOIN meal_unit_nutrition_fact muf_cal ON muf_cal.meal_unit_id=mu.id AND muf_cal.nutrition_fact_id=1";
        // } else {
        //     $sql .="
        //     LEFT JOIN meal_unit mu ON mu.meal_id= m.id AND mu.unit_id=m.serving_size_unit
        //     LEFT JOIN meal_unit_master mum ON mum.id = mu.unit_id            
        //     LEFT JOIN meal_unit_nutrition_fact ON meal_unit_nutrition_fact.meal_unit_id = mu.id AND nutrition_fact_id=1
        //     LEFT JOIN nutrition_fact         ON nutrition_fact.id  = meal_unit_nutrition_fact.nutrition_fact_id";
        // }

        $sql .="
        WHERE m.status_id=1 and  
        ".($locale=='es'?'m.name_es!=""':'m.name!=""')."
        ".$where."
        ". (($group==1)?' GROUP BY m.id ':'') ."
        ".$orderBy."
        LIMIT ".$params->offset.",".$params->limit."
        ";
        // GROUP BY m.id
        //echo $sql;
        //die('111');
        //echo "---------";
        $statement = $this->adapter->createStatement($sql);

        $result  = $statement->execute();
        $food    = $result->getResource()->fetchAll(2);

        $preview_bucket_url = $config['meal_photo_Settings']['thumbs'][1]['meal225']['bucket'];
        $preview_bucket_large_url = $config['meal_photo_Settings']['thumbs'][2]['meal600']['bucket'];
        foreach ($food as $key => $foodDet) {
            //$food[$key]['name'] =utf8_encode($foodDet['name']);
            
            $food[$key]['serving_per_container'] =!empty($foodDet['serving_per_container'])?$foodDet['serving_per_container']:'';
            $food[$key]['brand_name'] =!empty($foodDet['brand_name'])?$foodDet['brand_name']:'';

            if (!empty($foodDet['meal_image'])) {
                $mealImage = empty($foodDet['meal_image'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$foodDet['meal_image']);
                $mealImageLarge = empty($foodDet['meal_image'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_large_url.'/'.$foodDet['meal_image']);
            } else {
                $mealImage = '';
                $mealImageLarge ='';
            }
            $food[$key]['meal_image'] = $mealImage;
            $food[$key]['meal_image_large'] = $mealImageLarge;

            $sql ="SELECT nf.name,munf.value
            FROM meal_unit mu
            JOIN meal_unit_nutrition_fact munf ON munf.meal_unit_id = mu.id
            LEFT JOIN nutrition_fact nf ON nf.id = munf.nutrition_fact_id
            WHERE mu.unit_id=".$foodDet['unit_id']." and mu.meal_id=".$foodDet['id'];;

            //echo "<hr >";
            
            $statement = $this->adapter->createStatement($sql);

            $result  = $statement->execute();
            $nutritionFacts   = $result->getResource()->fetchAll(2);

            foreach ($nutritionFacts as $nkey => $nutritionFact) {
                $food[$key]['nutrition_facts'][$nutritionFact['name']]=$nutritionFact['value'];
            }

            $sql ="SELECT mtm.id,mtm.name
            FROM meal_type mt
            LEFT JOIN meal_type_master mtm ON mtm.id = mt.meal_type_master_id
            WHERE mt.meal_id=".$foodDet['id'];

            $statement = $this->adapter->createStatement($sql);

            $result  = $statement->execute();
            $mealType= $result->getResource()->fetchAll(2);
            $food[$key]['meal_type'] = $mealType;


        }

        if (!empty($params->search_type and $params->search_type=='food_recommendation' and $params->print=='yes')) {
            //die('sdsdsdsdsdsdsdsds');
            $food['print']['date']    = date('Y-m-d');
            $food['print']['mealCount']   =@$mealCount;
            $food['print']['foodlogs']   =@$foodlogs;
            $food['print']['exerciselogs']   =@$exerciselogs;
            $food['print']['remCount']   =@$remCount;

            $food['print']['proteinRem']   =@$proteinRem;
            $food['print']['fatRem']   =@$fatRem;
            $food['print']['carbsRem']   =@$carbsRem;
            $food['print']['fiberRem']   =@$fiberRem;
            $food['print']['caloriesRem']   =@$caloriesRem;

            $food['print']['proteinPer']   =@$proteinPer;
            $food['print']['fatPer']   =@$fatPer;
            $food['print']['carbsPer']   =@$carbsPer;
            $food['print']['fiberPer']   =@$fiberPer;
            $food['print']['caloriesPer']   =@$caloriesPer;
        }

        if (!empty($params->print and $params->print=='query')) {
            $food['print']['sql']   = $sql;
        }
        return $food;
    }

    /**
    * to update meal
    *
    * @param int $id
    * @param array $data
    * @param int $userId
    * @return Entity
    */
    public function update($id, $data, $userId)
    {
        $utilityObj = new \Application\Service\Utility();
        $locale     = $utilityObj->getLocale(!empty($data->locale)?$data->locale:'en');

        if ($locale=='es') {
            $languageId=2;
            $nameFld = 'name_es';
            $brandNameFld = 'brand_name_es';
        } else {
            $languageId=1;
            $nameFld = 'name';
            $brandNameFld = 'brand_name';
        }

        $unit = $this->getMealUnitMasterTable()->fetchByName($data->serving_size_unit);
                  
        if (!$unit) {
            $unit = $this->getMealUnitMasterTable()->create($data->serving_size_unit);
        }

        $unit = $unit->current();

        foreach ($data->category as $category) {
            if (!$this->getMealCategoryMasterTable()->isValidById($category['id'])) {
                return \Application\Service\FymApiProblem::ApiProblem(404, 'Invalid Category');
            }
        }

        //$category = $this->getMealCategoryMasterTable()->fetchByName($data->category);
        //die('222');

        $apiData = array(
            $nameFld => addslashes($data->name),
            $brandNameFld =>addslashes($data->brand_name),
            'updated_by' => $userId,
            'updated_date' =>gmdate('Y-m-d H:i:s')    ,
            'language_id' => $languageId,
            'serving_size'=> $data->serving_size,
            'serving_size_unit' => $unit->id,
            'serving_per_container' => $data->serving_per_container
            );

        $this->table->update($apiData, array('id'=>$id));

        $unitId = $this->getMealUnitTable()->update($unit->id, $id);

        foreach ($data->category as $category) {
            $category = $this->getMealCategoryMasterTable()->fetchById($category['id']);
            //$this->getMealCategoryTable()->create($category, $id);
            $this->getMealCategoryTable()->update($category, $id);
        }

        //$category = $this->getMealCategoryMasterTable()->fetchByName($data->category);

        $this->getMealUnitNutritionFactTable()->update($unitId, 1, !empty($data->calories)?$data->calories:0, 'cal');
        $this->getMealUnitNutritionFactTable()->update($unitId, 2, !empty($data->fat)?$data->fat:0, 'g');
        $this->getMealUnitNutritionFactTable()->update($unitId, 3, !empty($data->saturated)?$data->saturated:0, 'g');
        $this->getMealUnitNutritionFactTable()->update($unitId, 4, !empty($data->polyunsaturated)?$data->polyunsaturated:0, 'g');
        $this->getMealUnitNutritionFactTable()->update($unitId, 5, !empty($data->monosaturated)?$data->monosaturated:0, 'g');
        $this->getMealUnitNutritionFactTable()->update($unitId, 6, !empty($data->trans)?$data->trans:0, 'g');
        $this->getMealUnitNutritionFactTable()->update($unitId, 7, !empty($data->cholestrol)?$data->cholestrol:0, 'mg');
        $this->getMealUnitNutritionFactTable()->update($unitId, 8, !empty($data->sodium)?$data->sodium:0, 'mg');
        $this->getMealUnitNutritionFactTable()->update($unitId, 9, !empty($data->pottassium)?$data->pottassium:0, 'mg');
        $this->getMealUnitNutritionFactTable()->update($unitId, 10, !empty($data->carbohydrates)?$data->carbohydrates:0, 'g');
        $this->getMealUnitNutritionFactTable()->update($unitId, 11, !empty($data->fiber)?$data->fiber:0, 'g');
        $this->getMealUnitNutritionFactTable()->update($unitId, 12, !empty($data->protien)?$data->protien:0, 'g');

        $resultSet = $this->table->select(array('id' => $id));

        if (0 === count($resultSet)) {
            throw new DomainException('Update operation failed or result in row deletion', 500);
        }
        $meal = $resultSet->current();
        
        if ($locale=='es') {
            $meal->name = ($meal->name_es);
        } else {
            $meal->name = ($meal->name);
        }
        unset($meal->name_es);
        //print_r($meal);
        return $meal;
    }

    /**
    * Delete meal
    *
    * @param int $id
    * @return Entity
    */
    public function delete($id)
    {
        $resultSet = $this->table->select(array('id' => $id,'status_id'=>1));

        if (0 === count($resultSet)) {
            throw new DomainException('Update operation failed or result in row deletion', 500);
        } else {
            $result = $this->table->update(array('updated_date' =>gmdate('Y-m-d H:i:s')    , 'status_id'=>4), array('id' => $id));
            return true;
        }
    }
}
