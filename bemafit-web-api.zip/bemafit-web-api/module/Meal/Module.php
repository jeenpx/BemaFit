<?php
require __DIR__ . '/src/Meal/Module.php';
