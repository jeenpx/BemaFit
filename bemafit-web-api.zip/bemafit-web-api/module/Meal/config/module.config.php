<?php
return array(
    'router' => array(
        'routes' => array(
            'meal.rest.meal' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/meal[/:meal_id]',
                    'defaults' => array(
                        'controller' => 'Meal\\V1\\Rest\\Meal\\Controller',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            0 => 'meal.rest.meal',
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'Meal\\V1\\Rest\\Meal\\MealResource' => 'Meal\\V1\\Rest\\Meal\\MealResourceFactory',
        ),
    ),
    'zf-rest' => array(
        'Meal\\V1\\Rest\\Meal\\Controller' => array(
            'listener' => 'Meal\\V1\\Rest\\Meal\\MealResource',
            'route_name' => 'meal.rest.meal',
            'route_identifier_name' => 'meal_id',
            'collection_name' => 'meal',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(
                0 => 'keyword',
                1 => 'meal_category',
                2 => 'meal_type',
                3 => 'offset',
                4 => 'limit',
                5 => 'search_type',
                6 => 'print',
                7 => 'date',
                8 => 'locale',
            ),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'Meal\\V1\\Rest\\Meal\\MealEntity',
            'collection_class' => 'Meal\\V1\\Rest\\Meal\\MealCollection',
            'service_name' => 'Meal',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'Meal\\V1\\Rest\\Meal\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'Meal\\V1\\Rest\\Meal\\Controller' => array(
                0 => 'application/vnd.meal.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
        ),
        'content_type_whitelist' => array(
            'Meal\\V1\\Rest\\Meal\\Controller' => array(
                0 => 'application/vnd.meal.v1+json',
                1 => 'application/json',
            ),
        ),
    ),
    //sma1
    // 'nutritionix' => array(
    //     'url' => 'https://api.nutritionix.com/v1_1/',
    //     'appId' => '1fa6b1cc',
    //     'appKey' => '48999a66cc65b2f1fcd227c1272da8ff',
    // ),
    //sma2
    // 'nutritionix' => array(
    //     'url' => 'https://api.nutritionix.com/v1_1/',
    //     'appId' => 'b9b24b17',
    //     'appKey' => '6d790c8103ebc4f321c6aaf87c36e502',
    // ),
    // //shemeerdbg
    // 'nutritionix' => array(
    //     'url' => 'https://api.nutritionix.com/v1_1/',
    //     'appId' => 'e8d5f138',
    //     'appKey' => '3ee5e0b725f3e1a7850aa5a1f172464b',
    // ),
    // //shemeermali
    // 'nutritionix' => array(
    //     'url' => 'https://api.nutritionix.com/v1_1/',
    //     'appId' => 'f7740dc8',
    //     'appKey' => '4bd21291a70a283cdbc0301e4ba13573',
    // ),
    // //flexyourmacros(default)
    // 'nutritionix' => array(
    //     'url' => 'https://api.nutritionix.com/v1_1/',
    //     'appId' => '2125098e',
    //     'appKey' => '15db55ade42b9b1ebbd42bb62f94ee37',
    // ),
    // //sma5
    // 'nutritionix' => array(
    //     'url' => 'https://api.nutritionix.com/v1_1/',
    //     'appId' => '62308ff3',
    //     'appKey' => 'a9889c4d2ff5b52b164c008f2521765c',
    // ),
    // //sma6
    // 'nutritionix' => array(
    //     'url' => 'https://api.nutritionix.com/v1_1/',
    //     'appId' => 'b8dfe5c4',
    //     'appKey' => '04cfd2cddd19b3a0aaf0d108b5757f94',
    // ),
    // //sma7
    // 'nutritionix' => array(
    //     'url' => 'https://api.nutritionix.com/v1_1/',
    //     'appId' => '56796fd1',
    //     'appKey' => '0fb7bf357a080a3f3c664d027f2ff043',
    // ),
    // //sma8
    // 'nutritionix' => array(
    //     'url' => 'https://api.nutritionix.com/v1_1/',
    //     'appId' => 'aaca5855',
    //     'appKey' => '4ae985e0c74924acc72fe7f50a6844a4',
    // ),
    // //sma9
    // 'nutritionix' => array(
    //     'url' => 'https://api.nutritionix.com/v1_1/',
    //     'appId' => 'aad652e9',
    //     'appKey' => '85933dcb670cf12c27f8c5d02b762457',
    // ),
    //sma10
    'nutritionix' => array(
        'url' => 'https://api.nutritionix.com/v1_1/',
        'appId' => '3cab07fb',
        'appKey' => 'b58f7bd7edd62fc98e0f0edc9881525e',
    ),
    'zf-hal' => array(
        'metadata_map' => array(
            'Meal\\V1\\Rest\\Meal\\MealEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'meal.rest.meal',
                'route_identifier_name' => 'meal_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'Meal\\V1\\Rest\\Meal\\MealCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'meal.rest.meal',
                'route_identifier_name' => 'meal_id',
                'is_collection' => true,
            ),
        ),
    ),
    'zf-mvc-auth' => array(
        'authorization' => array(
            'Meal\\V1\\Rest\\Meal\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => true,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
        ),
    ),
    'zf-content-validation' => array(
        'Meal\\V1\\Rest\\Meal\\Controller' => array(
            'input_filter' => 'Meal\\V1\\Rest\\Meal\\Validator',
        ),
    ),
    'input_filter_specs' => array(
        'Meal\\V1\\Rest\\Meal\\Validator' => array(
            0 => array(
                'name' => 'brand_name',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            1 => array(
                'name' => 'serving_size',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            2 => array(
                'name' => 'serving_size_unit',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            3 => array(
                'name' => 'serving_per_container',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            4 => array(
                'name' => 'calories',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            5 => array(
                'name' => 'fat',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            6 => array(
                'name' => 'saturated',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            7 => array(
                'name' => 'polyunsaturated',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            8 => array(
                'name' => 'monosaturated',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            9 => array(
                'name' => 'trans',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            10 => array(
                'name' => 'cholestrol',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            11 => array(
                'name' => 'sodium',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            12 => array(
                'name' => 'pottassium',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            13 => array(
                'name' => 'carbohydrates',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            14 => array(
                'name' => 'fiber',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            15 => array(
                'name' => 'protien',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'Fym\\Validator\\FymIsFloat',
                        'options' => array(),
                    ),
                ),
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            16 => array(
                'name' => 'locale',
                'required' => false,
            ),
        ),
    ),
);
