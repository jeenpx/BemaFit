<?php
namespace BusinessDirectory\V1\Rest\CheckIn;

class CheckInResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('BusinessDirectory\V1\Rest\CheckInMapperTableGateway');
        return new CheckInResource($mapper);
    }
}
