<?php

namespace BusinessDirectory\V1\Rest\BusinessDirectory;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getUserTable()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('User\V1\Rest\UserMapperTableGateway');
        return $this->Table;
    }

    /**
     * to fetch a BusinessDirectory
     *
     * @param int $id
     * @return Entity
     */
    public function fetch($id)
    {
        $resultSet = $this->table->select(array('id' => $id));
        if (0 === count($resultSet)) {
            throw new DomainException('Business Directory not found', 404);
        }
        return $resultSet->current();
    }

    /**
     * to check exist a BusinessDirectory by guuid
     *
     * @param string $guid
     * @return Entity|false
     */
    public function isExistByGuid($guid)
    {
        $resultSet = $this->table->select(array('guid' => $guid));
        if (0 === count($resultSet)) {
            return false;
        }
        return $resultSet->current();
    }

    /**
    * to fetch BusinessDirectory by name
    *
    * @param string $name
    * @return Entity
    */
    public function fetchByName($name)
    {
        $resultSet = $this->table->select(array('name' => $name));
        if (0 === count($resultSet)) {
            throw new DomainException('Business Directory not found', 404);
        }
        return $resultSet->current()->id;
    }

    /**
     * @param string $id
     * @return Entity
     */
    public function isValidMeal($id)
    {
        $resultSet = $this->table->select(array('id' => $id));
        if (0 === count($resultSet)) {
            return false;
        }
        return true;
    }

    /**
    * To fetch all BusinessDirectory
    *
    * @param string $name
    * @return Entity
    */
    public function fetchAll($params)
    {
        $config = $this->getServiceLocator()->get('Config');
        $zipcode   = $params->zipcode;
        $address   = $params->address;
        $location  = $params->location;
        $arr_where = array($params->latitude, $params->longitude);

        if (!empty($params->type)) {
            $business_category_info = $this->validateBusinessCategory($params->type);

            if (!$business_category_info) {
                return \Application\Service\FymApiProblem::ApiProblem(422, 'Invalid Business Category type');
            }
            $where =" AND business_category_master.name=?";
            array_push($arr_where, $params->type);
        } else {
            $where =" ";
        }

        if (!empty($params->bid)) {
            $where .=" AND b.guid=?";
            array_push($arr_where, $params->bid);
        }

        /*
        if (!empty($zipcode)) {
             $where .=" AND b.zipcode= ?";
             array_push($arr_where, $zipcode);
        }

        if (!empty($address)) {
             $where .=" AND b.address1 Like ?";
             array_push($arr_where, $address.'%');
        }*/

        if (!empty($location)) {
             $where .="  AND (s.state_code=? OR s.state_name LIKE ? OR b.zipcode= ? OR b.address1 LIKE ? OR b.address2 LIKE ?)";
             array_push($arr_where, $location, $location.'%', $location, $location.'%', $location.'%');
        }

        $this->getAdapter();

        $sql ="SELECT  SQL_CALC_FOUND_ROWS   b.id,b.guid, b.guid as business_id, b.name,address1,IFNULL(b.address2,'') as address2, s.state_code as state_code, premium_listing, b.phone, b.url as website,  IFNULL(b.description,'') AS description,
                      ROUND( SQRT( POW((69.1 * (? - b.latitude)), 2) + POW((53 * (? - b.longitude)), 2)), 1) AS distance
                FROM business b
                JOIN business_category ON business_category.business_id = b.id
                JOIN business_category_master ON business_category_master.id = business_category.business_category_master_id
                LEFT JOIN states s ON b.state=s.id
                WHERE b.status_id=1 AND business_category_master.status_id=1  $where 
                GROUP BY b.id 
                ORDER BY  case when premium_listing =1 then 0 else 1 end, distance  asc 
                LIMIT ".$params->offset.", ".$params->limit;

        $statement = $this->adapter->createStatement($sql, $arr_where);
        $result  = $statement->execute();
        $business = $result->getResource()->fetchAll(2);
        $total_rows = $this->adapter->createStatement('SELECT FOUND_ROWS()  as total_rows')->execute()->getResource()->fetchAll()[0]['total_rows'];
        $preview_bucket_url = $config['business_photo_Settings']['thumbs'][0]['business100']['bucket'];
        foreach ($business as $key => $record) {
            $sql ="SELECT business_category_master.name
            FROM business_category
            JOIN business_category_master ON business_category_master.id = business_category.business_category_master_id
            WHERE business_id=".$record['id']." AND business_category_master.status_id=1 
            ";

            $statement = $this->adapter->createStatement($sql);
            $result    = $statement->execute();
            $category  = $result->getResource()->fetchAll(2);

            $business[$key]['category']= $category;
            $business[$key]['distance']= !empty($params->latitude)?$business[$key]['distance']:'';
            $sql ="SELECT file,IFNULL(description, '') as description
            FROM business_image
            WHERE business_id=".$record['id']."
            ";

            $statement = $this->adapter->createStatement($sql);

            $result    = $statement->execute();
            $images    = $result->getResource()->fetchAll(2);
            
           
            if ($images) {
                foreach ($images as $image) {
                    //Temporary fix. Will be updated with aws url
                    $images[key($images)]['file'] = empty($images[key($images)]['file'])?'':$this->getUserTable()->getAwsImageUrl($preview_bucket_url.'/'.$images[key($images)]['file']);
                    //$images[key($images)]['file'] = 'http://fym.dbgstage.com/'.$images[key($images)]['file'];
                }
            }
            
            $business[$key]['images']= $images;


            //http://fym.dbgstage.com/
            $sql ="SELECT day,open,close
            FROM business_working_hours
            WHERE business_id=".$record['id']."
            ";

            $statement = $this->adapter->createStatement($sql);
            $result    = $statement->execute();
            $workingHours    = $result->getResource()->fetchAll(2);
            $business[$key]['working_hours']= $workingHours;
        }
        
        return array(
                      'meta'=>array('status'=>'OK', 'code'=>200, 'methodName' => 'getBusiness'),
                      'business'=> $business,
                      'total_rows'=>$total_rows
                );
        
    }

    /**
    * To validate BusinessDirectory Category
    *
    * @param string $category
    * @return Entity
    */
    public function validateBusinessCategory($category)
    {
        $adapter = $this->getAdapter();
        $bc_master_table = new \Zend\Db\TableGateway\TableGateway('business_category_master', $adapter);
        $business_category_data = $bc_master_table->select(array('name'=>$category, 'status_id'=>1));
        return $business_category_data->current();
    }
}
