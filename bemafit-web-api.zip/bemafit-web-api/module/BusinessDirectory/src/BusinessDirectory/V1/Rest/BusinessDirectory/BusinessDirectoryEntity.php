<?php
namespace BusinessDirectory\V1\Rest\BusinessDirectory;

class BusinessDirectoryEntity
{
}
