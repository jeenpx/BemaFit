<?php
namespace BusinessDirectory\V1\Rest\BusinessDirectory;

use Zend\Paginator\Paginator;

class BusinessDirectoryCollection extends Paginator
{
}
