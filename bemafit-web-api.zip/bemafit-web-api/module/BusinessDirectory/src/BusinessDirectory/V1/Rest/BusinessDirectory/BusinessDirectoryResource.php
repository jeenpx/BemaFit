<?php
namespace BusinessDirectory\V1\Rest\BusinessDirectory;

use ZF\ApiProblem\ApiProblem;
use ZF\Rest\AbstractResourceListener;

class BusinessDirectoryResource extends AbstractResourceListener
{
    protected $mapper;
 
    public function __construct($mapper)
    {
        $this->mapper = $mapper;
    }
    /**
     * Create a resource
     * Not using as per current requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function create($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The POST method has not been defined');
    }

    /**
     * Delete a resource
     * Not using as per current requirement
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function delete($id)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The DELETE method has not been defined for individual resources');
    }

    /**
     * Delete a collection, or members of a collection
     * Not using as per current requirement
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function deleteList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The DELETE method has not been defined for collections');
    }

    /**
     * Fetch a resource
     *
     * @param  mixed $id
     * @return ApiProblem|mixed
     */
    public function fetch($id)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The GET method has not been defined for individual resources');
    }

    /**
     * Fetch all or a subset of resources
     *
     * @param  array $params
     * @return ApiProblem|mixed
     */
    public function fetchAll($params = array())
    {
        $params->zipcode = $this->getEvent()->getRequest()->getQuery('zipcode', 0);
        $params->address = $this->getEvent()->getRequest()->getQuery('address', '');
        $params->location = $this->getEvent()->getRequest()->getQuery('location', '');
        $params->latitude = $this->getEvent()->getRequest()->getQuery('latitude', 0);
        $params->longitude = $this->getEvent()->getRequest()->getQuery('longitude', 0);
        $params->offset = $this->getEvent()->getRequest()->getQuery('offset', 0);
        $params->limit = $this->getEvent()->getRequest()->getQuery('limit', 10);
        $params->bid = $this->getEvent()->getRequest()->getQuery('bid', '');
        $business = $this->mapper->fetchAll($params);
        return $business;
        return array(
                'meta'=>array('status'=>'ok','code'=>200,'method_name'=>'get business',
                ),'business'=>$business);
    }

    /**
     * Patch (partial in-place update) a resource
     * Not using as per current requirement
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function patch($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PATCH method has not been defined for individual resources');
    }

    /**
     * Replace a collection or members of a collection
     *
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function replaceList($data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for collections');
    }

    /**
     * Update a resource
     *
     * @param  mixed $id
     * @param  mixed $data
     * @return ApiProblem|mixed
     */
    public function update($id, $data)
    {
        return \Application\Service\FymApiProblem::ApiProblem(405, 'The PUT method has not been defined for individual resources');
    }
}
