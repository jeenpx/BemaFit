<?php
namespace BusinessDirectory\V1\Rest\CheckIn;

class CheckInEntity
{
}
