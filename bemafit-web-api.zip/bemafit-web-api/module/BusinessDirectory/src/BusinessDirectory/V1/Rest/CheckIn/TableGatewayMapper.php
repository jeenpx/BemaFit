<?php

namespace BusinessDirectory\V1\Rest\CheckIn;

use Zend\Mvc\Controller\AbstractActionController;
use DomainException;
use InvalidArgumentException;
use Traversable;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Stdlib\ArrayUtils;
use ZF\ApiProblem\ApiProblem;

class TableGatewayMapper extends AbstractActionController
{
    /**
     * @var TableGateway
     */
    protected $table;

    /**
     * @param TableGateway $table
     */
    public function __construct(TableGateway $table)
    {
        $this->table = $table;
    }

    public function getAdapter()
    {
        $sm = $this->getServiceLocator();
        $this->adapter = $sm->get('Db\Adapter\Adapter');
        return $this->adapter;
    }

    public function getBusinessDirectoryTable()
    {
        $sm = $this->getServiceLocator();
        $this->BusinessDirectoryTable = $sm->get('BusinessDirectory\V1\Rest\BusinessDirectoryMapperTableGateway');
        return $this->BusinessDirectoryTable;
    }

    public function getFeedMapper()
    {
        $sm = $this->getServiceLocator();
        $this->Table = $sm->get('Feeds\V1\Rest\FeedMapperTableGateway');
        return $this->Table;
    }
    
    /**
     * @param array|Traversable|\stdClass $data
     * @return Entity
     */
    public function create($data)
    {
        $result = $this->getBusinessDirectoryTable()->isExistByGuid($data->business);
        
        if ($result) {
            $apiData['user_id']      = $data->userId;
            $apiData['business_id']  = $result->id;
            $apiData['status_id']    = 1;
            $apiData['created_date']   = gmdate('Y-m-d H:i:s')    ;

            $this->table->insert($apiData);
            $this->getFeedMapper()->insertCustomFeedData('checkin', $this->table->lastInsertValue, $apiData['user_id']);
        }
    }
  
    /**
     * @param string $id
     * @return Entity
     */
    public function fetchByName($name)
    {
        $resultSet = $this->table->select(array('name' => $name));
        if (0 === count($resultSet)) {
            throw new DomainException('Exercise not found', 404);
        }
        return $resultSet->current()->id;
    }

    /**
     * @param string $id
     * @return Entity
     */
    public function isValidMeal($id)
    {
        $resultSet = $this->table->select(array('id' => $id));
        if (0 === count($resultSet)) {
            return false;
        }
        return true;
    }
}
