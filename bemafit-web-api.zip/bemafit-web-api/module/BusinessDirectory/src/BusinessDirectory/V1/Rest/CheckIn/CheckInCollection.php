<?php
namespace BusinessDirectory\V1\Rest\CheckIn;

use Zend\Paginator\Paginator;

class CheckInCollection extends Paginator
{
}
