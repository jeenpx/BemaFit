<?php
namespace BusinessDirectory\V1\Rest\BusinessDirectory;

class BusinessDirectoryResourceFactory
{
    public function __invoke($services)
    {
        $mapper = $services->get('BusinessDirectory\V1\Rest\BusinessDirectoryMapperTableGateway');
        return new BusinessDirectoryResource($mapper);
    }
}
