<?php
namespace BusinessDirectory;

use ZF\Apigility\Provider\ApigilityProviderInterface;

class Module implements ApigilityProviderInterface
{
    public function getConfig()
    {
        return include __DIR__ . '/../../config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'ZF\Apigility\Autoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__,
                ),
            ),
        );
    }

    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'Business\V1\Rest\Album\BusinessMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\Business\BusinessMapper($adapter);
                },
                'Business\V1\Rest\Album\BusinessMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\Business\TableGateway('business', $adapter);
                    return new V1\Rest\Business\TableGatewayMapper($tableGateway);
                },

                'BusinessDirectory\V1\Rest\BusinessDirectoryMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\BusinessDirectory\BusinessDirectoryMapper($adapter);
                },
                'BusinessDirectory\V1\Rest\BusinessDirectoryMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\BusinessDirectory\TableGateway('business', $adapter);
                    return new V1\Rest\BusinessDirectory\TableGatewayMapper($tableGateway);
                },

                'BusinessDirectory\V1\Rest\CheckInMapperOnly' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    return new V1\Rest\BusinessDirectory\CheckInMapper($adapter);
                },
                'BusinessDirectory\V1\Rest\CheckInMapperTableGateway' =>  function ($services) {
                    $adapter = $services->get('Db\Adapter\Adapter');
                    $tableGateway = new V1\Rest\CheckIn\TableGateway('user_check_in', $adapter);
                    return new V1\Rest\CheckIn\TableGatewayMapper($tableGateway);
                },
            ),
        );
    }
}
