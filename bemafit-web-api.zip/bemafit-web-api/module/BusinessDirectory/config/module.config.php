<?php
return array(
    'router' => array(
        'routes' => array(
            'business-directory.rest.business-directory' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/business-directory[/:business_directory_id]',
                    'defaults' => array(
                        'controller' => 'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\Controller',
                    ),
                ),
            ),
            'business-directory.rest.check-in' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/check-in[/:check_in_id]',
                    'defaults' => array(
                        'controller' => 'BusinessDirectory\\V1\\Rest\\CheckIn\\Controller',
                    ),
                ),
            ),
        ),
    ),
    'zf-versioning' => array(
        'uri' => array(
            1 => 'business-directory.rest.business-directory',
            2 => 'business-directory.rest.check-in',
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\BusinessDirectoryResource' => 'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\BusinessDirectoryResourceFactory',
            'BusinessDirectory\\V1\\Rest\\CheckIn\\CheckInResource' => 'BusinessDirectory\\V1\\Rest\\CheckIn\\CheckInResourceFactory',
        ),
    ),
    'zf-rest' => array(
        'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\Controller' => array(
            'listener' => 'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\BusinessDirectoryResource',
            'route_name' => 'business-directory.rest.business-directory',
            'route_identifier_name' => 'business_directory_id',
            'collection_name' => 'business_directory',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(
                0 => 'type',
            ),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\BusinessDirectoryEntity',
            'collection_class' => 'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\BusinessDirectoryCollection',
            'service_name' => 'BusinessDirectory',
        ),
        'BusinessDirectory\\V1\\Rest\\CheckIn\\Controller' => array(
            'listener' => 'BusinessDirectory\\V1\\Rest\\CheckIn\\CheckInResource',
            'route_name' => 'business-directory.rest.check-in',
            'route_identifier_name' => 'check_in_id',
            'collection_name' => 'check_in',
            'entity_http_methods' => array(
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ),
            'collection_http_methods' => array(
                0 => 'GET',
                1 => 'POST',
            ),
            'collection_query_whitelist' => array(),
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => 'BusinessDirectory\\V1\\Rest\\CheckIn\\CheckInEntity',
            'collection_class' => 'BusinessDirectory\\V1\\Rest\\CheckIn\\CheckInCollection',
            'service_name' => 'CheckIn',
        ),
    ),
    'zf-content-negotiation' => array(
        'controllers' => array(
            'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\Controller' => 'Json',
            'BusinessDirectory\\V1\\Rest\\CheckIn\\Controller' => 'Json',
        ),
        'accept_whitelist' => array(
            'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\Controller' => array(
                0 => 'application/json',
            ),
            'BusinessDirectory\\V1\\Rest\\CheckIn\\Controller' => array(
                0 => 'application/vnd.business-directory.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ),
        ),
        'content_type_whitelist' => array(
            'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\Controller' => array(
                0 => 'application/json',
            ),
            'BusinessDirectory\\V1\\Rest\\CheckIn\\Controller' => array(
                0 => 'application/vnd.business-directory.v1+json',
                1 => 'application/json',
            ),
        ),
    ),
    'zf-hal' => array(
        'metadata_map' => array(
            'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\BusinessDirectoryEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'business-directory.rest.business-directory',
                'route_identifier_name' => 'business_directory_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\BusinessDirectoryCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'business-directory.rest.business-directory',
                'route_identifier_name' => 'business_directory_id',
                'is_collection' => true,
            ),
            'BusinessDirectory\\V1\\Rest\\CheckIn\\CheckInEntity' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'business-directory.rest.check-in',
                'route_identifier_name' => 'check_in_id',
                'hydrator' => 'Zend\\Stdlib\\Hydrator\\ArraySerializable',
            ),
            'BusinessDirectory\\V1\\Rest\\CheckIn\\CheckInCollection' => array(
                'entity_identifier_name' => 'id',
                'route_name' => 'business-directory.rest.check-in',
                'route_identifier_name' => 'check_in_id',
                'is_collection' => true,
            ),
        ),
    ),
    'zf-content-validation' => array(
        'BusinessDirectory\\V1\\Rest\\CheckIn\\Controller' => array(
            'input_filter' => 'BusinessDirectory\\V1\\Rest\\CheckIn\\Validator',
        ),
    ),
    'input_filter_specs' => array(
        'BusinessDirectory\\V1\\Rest\\Business\\Validator' => array(
            0 => array(
                'name' => 'name',
                'required' => true,
                'filters' => array(
                    0 => array(
                        'name' => 'Zend\\Filter\\StringTrim',
                        'options' => array(),
                    ),
                ),
                'validators' => array(),
                'error_message' => 'required',
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            1 => array(
                'name' => 'address1',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'error_message' => 'required',
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            2 => array(
                'name' => 'address2',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
                'allow_empty' => true,
                'continue_if_empty' => true,
            ),
            3 => array(
                'name' => 'state',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'error_message' => 'required',
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            4 => array(
                'name' => 'city',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'error_message' => 'required',
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            5 => array(
                'name' => 'phone',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'error_message' => 'required',
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
            6 => array(
                'name' => 'url',
                'required' => false,
                'filters' => array(),
                'validators' => array(),
                'file_upload' => false,
                'allow_empty' => true,
                'continue_if_empty' => true,
            ),
            7 => array(
                'name' => 'description',
                'required' => true,
                'filters' => array(),
                'validators' => array(),
                'error_message' => 'required',
                'allow_empty' => false,
                'continue_if_empty' => false,
            ),
        ),
        'BusinessDirectory\\V1\\Rest\\CheckIn\\Validator' => array(
            0 => array(
                'name' => 'business',
                'required' => true,
                'filters' => array(),
                'validators' => array(
                    0 => array(
                        'name' => 'ZF\\ContentValidation\\Validator\\DbRecordExists',
                        'options' => array(
                            'adapter' => 'API_DB',
                            'table' => 'business',
                            'field' => 'guid',
                        ),
                    ),
                ),
            ),
        ),
    ),
    'zf-mvc-auth' => array(
        'authorization' => array(
            'BusinessDirectory\\V1\\Rest\\BusinessDirectory\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => false,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
            'BusinessDirectory\\V1\\Rest\\CheckIn\\Controller' => array(
                'entity' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => true,
                    'PUT' => true,
                    'DELETE' => true,
                ),
                'collection' => array(
                    'GET' => true,
                    'POST' => true,
                    'PATCH' => false,
                    'PUT' => false,
                    'DELETE' => false,
                ),
            ),
        ),
    ),
    'zf-mvc-auth-user' => array(
        'authorization' => array(
            'BusinessDirectory\\V1\\Rest\\Business\\Controller' => array(
                'user' => array(
                    'entity' => 'all',
                    'collection' => 'all',
                ),
                'application' => array(
                    'entity' => 'all',
                    'collection' => 'all',
                ),
            ),
        ),
    ),
);
