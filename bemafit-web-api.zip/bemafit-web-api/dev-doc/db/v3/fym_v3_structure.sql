/*Table structure for table `status` */

CREATE TABLE `status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(16) DEFAULT NULL,
  `slug` varchar(32) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


/*Table structure for table `user` */

CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(32) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `first_name` varchar(32) DEFAULT NULL,
  `last_name` varchar(32) DEFAULT NULL,
  `role` enum('Admin','User') DEFAULT NULL,
  `password` varchar(256) DEFAULT NULL,
  `profile_photo` varchar(128) DEFAULT NULL,
  `type` enum('Public','Private') DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `website` varchar(64) DEFAULT NULL,
  `remember_token` varchar(256) DEFAULT NULL,
  `gender` enum('F','M') DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `facebook_user_id` varchar(32) DEFAULT NULL,
  `facebook_access_token` varchar(512) DEFAULT NULL,
  `date_last_login` datetime DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `added_by` int(10) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_user` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


/*Table structure for table `unit` */

CREATE TABLE `unit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_unit_updated_by` (`updated_by`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_unit` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_unit_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;




/*Table structure for table `goal` */

CREATE TABLE `goal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(32) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_goal` (`created_by`),
  KEY `FK_goal_updated_by` (`updated_by`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_goal` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_goal_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_goal_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;


/*Table structure for table `goal_option` */

CREATE TABLE `goal_option` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goal_id` int(10) unsigned DEFAULT NULL,
  `value` varchar(128) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `goal_id` (`goal_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_goal_option` FOREIGN KEY (`goal_id`) REFERENCES `goal` (`id`),
  CONSTRAINT `FK_goal_option_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;


/*Table structure for table `activity_level_master` */

CREATE TABLE `activity_level_master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_activity_level_master` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;


/*Table structure for table `nutrition_fact` */

CREATE TABLE `nutrition_fact` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(32) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `unit_id` int(10) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_nutrition_fact_created_by` (`created_by`),
  KEY `FK_nutrition_fact_updated_by` (`updated_by`),
  KEY `unit_id` (`unit_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_nutrition_fact_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_nutrition_fact` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_nutrition_fact_created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;


/*Table structure for table `nutritional_plan` */

CREATE TABLE `nutritional_plan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_nutritional_plan_status_id` (`created_by`),
  KEY `FK_nutritional_plan_updated_by` (`updated_by`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_nutritional_plan_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_nutritional_plan_status_id` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_nutritional_plan_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;


/*Table structure for table `user_details` */

CREATE TABLE `user_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `height` float DEFAULT NULL COMMENT 'Store feet converted to inch',
  `weight` float DEFAULT NULL,
  `weight_unit_id` int(10) unsigned DEFAULT NULL,
  `body_fat` float DEFAULT NULL,
  `activity_level_id` int(10) unsigned DEFAULT NULL,
  `goal_option_id` int(10) unsigned DEFAULT NULL,
  `protein` float DEFAULT NULL,
  `fat` float DEFAULT NULL,
  `carbs` float DEFAULT NULL,
  `fiber` float DEFAULT NULL,
  `calories` float DEFAULT NULL,
  `meals_per_day` int(4) DEFAULT NULL,
  `neutirition_plan_id` int(10) unsigned DEFAULT NULL,
  `recovery_password` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `weight_unit_id` (`weight_unit_id`),
  KEY `activity_level_id` (`activity_level_id`),
  KEY `goal_option_id` (`goal_option_id`),
  KEY `neutirition_plan_id` (`neutirition_plan_id`),
  CONSTRAINT `FK_user_details` FOREIGN KEY (`id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_user_details_activity_level` FOREIGN KEY (`activity_level_id`) REFERENCES `activity_level_master` (`id`),
  CONSTRAINT `FK_user_details_goal_option` FOREIGN KEY (`goal_option_id`) REFERENCES `goal_option` (`id`),
  CONSTRAINT `FK_user_details_n_plan_id` FOREIGN KEY (`neutirition_plan_id`) REFERENCES `nutritional_plan` (`id`),
  CONSTRAINT `FK_user_details_weight_unit` FOREIGN KEY (`weight_unit_id`) REFERENCES `unit` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



/*Table structure for table `language` */

CREATE TABLE `language` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `encoding` varchar(16) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_language` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;




/*Table structure for table `macro` */

CREATE TABLE `macro` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(32) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_macro_created_by` (`created_by`),
  KEY `FK_macro_updated_by` (`updated_by`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_macro_created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_macro_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_macro_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;


/*Table structure for table `meal_type` */

CREATE TABLE `meal_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_meal_type` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;



/*Table structure for table `meal` */

CREATE TABLE `meal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(16) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `meal_type_id` int(10) unsigned DEFAULT NULL,
  `language_id` int(10) unsigned DEFAULT NULL,
  `brand_name` varchar(128) DEFAULT NULL,
  `serving_size` float DEFAULT NULL,
  `serving_size_unit` int(10) unsigned DEFAULT NULL,
  `saving_per_container` varchar(128) DEFAULT NULL,
  `description` varchar(2048) DEFAULT NULL,
  `vendor_verified` enum('Yes','No') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meal_type_id` (`meal_type_id`),
  KEY `language_id` (`language_id`),
  CONSTRAINT `FK_meal` FOREIGN KEY (`meal_type_id`) REFERENCES `meal_type` (`id`),
  CONSTRAINT `FK_meal_language_id` FOREIGN KEY (`language_id`) REFERENCES `language` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



/*Table structure for table `meal_category_master` */

CREATE TABLE `meal_category_master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_meal_category_master` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;



/*Table structure for table `meal_category` */

CREATE TABLE `meal_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meal_id` int(10) unsigned DEFAULT NULL,
  `meal_category_master_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meal_id` (`meal_id`),
  KEY `meal_category_master_id` (`meal_category_master_id`),
  CONSTRAINT `FK_meal_category` FOREIGN KEY (`meal_category_master_id`) REFERENCES `meal_category_master` (`id`),
  CONSTRAINT `FK_meal_category_meal` FOREIGN KEY (`meal_id`) REFERENCES `meal` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




/*Table structure for table `meal_image` */

CREATE TABLE `meal_image` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meal_id` int(10) unsigned DEFAULT NULL,
  `file` varchar(256) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_meal_image_created_by` (`created_by`),
  KEY `FK_meal_image_updated_by` (`updated_by`),
  KEY `meal_id` (`meal_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_meal_image_created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_meal_image_meal_id` FOREIGN KEY (`meal_id`) REFERENCES `meal` (`id`),
  CONSTRAINT `FK_meal_image_status_id` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_meal_image_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `meal_macro` */

CREATE TABLE `meal_macro` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meal_id` int(10) unsigned DEFAULT NULL,
  `macro_id` int(10) unsigned DEFAULT NULL,
  `value` varchar(128) DEFAULT NULL,
  `unit_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meal_id` (`meal_id`),
  KEY `macro_id` (`macro_id`),
  KEY `unit_id` (`unit_id`),
  CONSTRAINT `FK_meal_macro` FOREIGN KEY (`macro_id`) REFERENCES `macro` (`id`),
  CONSTRAINT `FK_meal_macro_meal` FOREIGN KEY (`meal_id`) REFERENCES `meal` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `user_meal_log` */

CREATE TABLE `user_meal_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `meal_id` int(10) unsigned DEFAULT NULL,
  `meal_type_id` int(10) unsigned DEFAULT NULL,
  `serving_size` float DEFAULT NULL,
  `number_of_serving` float DEFAULT NULL,
  `meal_date` date DEFAULT NULL,
  `method` enum('Add','Copy','Sent','Split') DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_user_meal_log_created_by` (`created_by`),
  KEY `FK_user_meal_log_updated_by` (`updated_by`),
  KEY `user_id` (`user_id`),
  KEY `meal_id` (`meal_id`),
  KEY `meal_type_id` (`meal_type_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_user_meal_log` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_user_meal_log_created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_user_meal_log_meal_id` FOREIGN KEY (`meal_id`) REFERENCES `meal` (`id`),
  CONSTRAINT `FK_user_meal_log_meal_type_id` FOREIGN KEY (`meal_type_id`) REFERENCES `meal_type` (`id`),
  CONSTRAINT `FK_user_meal_log_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_user_meal_log_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `user_meal_macro` */

CREATE TABLE `user_meal_macro` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_meal_id` int(10) unsigned DEFAULT NULL,
  `macro_id` int(10) unsigned DEFAULT NULL,
  `value` float DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_meal_id` (`user_meal_id`),
  KEY `macro_id` (`macro_id`),
  KEY `unit_id` (`unit_id`),
  CONSTRAINT `FK_user_meal_macro` FOREIGN KEY (`macro_id`) REFERENCES `macro` (`id`),
  CONSTRAINT `FK_user_meal_macro_unit` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`),
  CONSTRAINT `FK_user_meal_macro_user_meal` FOREIGN KEY (`user_meal_id`) REFERENCES `user_meal_log` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*Table structure for table `exercise_type` */

CREATE TABLE `exercise_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_exercise_type` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;


/*Table structure for table `exercise` */

CREATE TABLE `exercise` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(16) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `exercise_type_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_exercise_created_by` (`created_by`),
  KEY `FK_exercise_updated_by` (`updated_by`),
  KEY `exercise_type_id` (`exercise_type_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_exercise` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_exercise_created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_exercise_excercise_type_id` FOREIGN KEY (`exercise_type_id`) REFERENCES `exercise_type` (`id`),
  CONSTRAINT `FK_exercise_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




/*Table structure for table `exercise_type_option` */

CREATE TABLE `exercise_type_option` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `exercise_type_id` int(10) unsigned DEFAULT NULL,
  `option` varchar(128) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_exercise_type_option` (`exercise_type_id`),
  KEY `FK_exercise_type_option_status_id` (`status_id`),
  CONSTRAINT `FK_exercise_type_option` FOREIGN KEY (`exercise_type_id`) REFERENCES `exercise_type` (`id`),
  CONSTRAINT `FK_exercise_type_option_status_id` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;


/*Table structure for table `user_exercise_log` */

CREATE TABLE `user_exercise_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `exercise_id` int(10) unsigned DEFAULT NULL,
  `exercise_type_option_id` int(10) unsigned DEFAULT NULL,
  `value` varchar(64) DEFAULT NULL,
  `unit` float DEFAULT NULL,
  `method` enum('Add','Copy','Sent') DEFAULT NULL,
  `exercise_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `exercise_id` (`exercise_id`),
  KEY `exercise_type_option_id` (`exercise_type_option_id`),
  CONSTRAINT `FK_user_exercise_log` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_user_exercise_log_eo_id` FOREIGN KEY (`exercise_type_option_id`) REFERENCES `exercise_type_option` (`id`),
  CONSTRAINT `FK_user_exercise_log_exercise_id` FOREIGN KEY (`exercise_id`) REFERENCES `exercise` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*Table structure for table `ad_location_master` */

CREATE TABLE `ad_location_master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('App','Web') DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ad_location_master` (`status_id`),
  KEY `FK_ad_location_master_created_by` (`created_by`),
  KEY `FK_ad_location_master_updated_by` (`updated_by`),
  CONSTRAINT `FK_ad_location_master` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_ad_location_master_created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_ad_location_master_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;


/*Table structure for table `ad` */

CREATE TABLE `ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(16) DEFAULT NULL,
  `ad_type_id` int(10) DEFAULT NULL,
  `content` text,
  `time_from` datetime DEFAULT NULL,
  `time_to` datetime DEFAULT NULL,
  `business_name` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ad_type_id` (`ad_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*Table structure for table `ad_image` */

CREATE TABLE `ad_image` (
   `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
   `ad_id` int(10) unsigned DEFAULT NULL,
   `file` varchar(256) DEFAULT NULL,
   `description` varchar(1024) DEFAULT NULL,
   `status_id` int(10) DEFAULT NULL,
   `created_by` int(10) unsigned DEFAULT NULL,
   `created_date` datetime DEFAULT NULL,
   `updated_by` int(10) unsigned DEFAULT NULL,
   `updated_date` datetime DEFAULT NULL,
   PRIMARY KEY (`id`),
   KEY `ad_id` (`ad_id`),
   KEY `status_id` (`status_id`),
   KEY `FK_ad_image_created_by` (`created_by`),
   KEY `FK_ad_image_updated_by` (`updated_by`),
   CONSTRAINT `FK_ad_image_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`),
   CONSTRAINT `FK_ad_image` FOREIGN KEY (`ad_id`) REFERENCES `ad` (`id`),
   CONSTRAINT `FK_ad_image_created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1;



/*Table structure for table `ad_location` */

CREATE TABLE `ad_location` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ad_id` int(10) unsigned DEFAULT NULL,
  `ad_location_master_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ad_id` (`ad_id`),
  KEY `ad_id_2` (`ad_id`),
  KEY `ad_location_master_id` (`ad_location_master_id`),
  CONSTRAINT `FK_ad_location` FOREIGN KEY (`ad_location_master_id`) REFERENCES `ad_location_master` (`id`),
  CONSTRAINT `FK_ad_location_ad` FOREIGN KEY (`ad_id`) REFERENCES `ad` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;





/*Table structure for table `business_category_master` */

CREATE TABLE `business_category_master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_business_category_master_created_by` (`created_by`),
  KEY `FK_business_category_master_updated_by` (`updated_by`),
  KEY `FK_business_category_master` (`status_id`),
  CONSTRAINT `FK_business_category_master` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_business_category_master_created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_business_category_master_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;


/*Table structure for table `business` */

CREATE TABLE `business` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(16) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `address1` varchar(256) DEFAULT NULL,
  `address2` varchar(256) DEFAULT NULL,
  `state` int(10) unsigned DEFAULT NULL,
  `city` varchar(128) DEFAULT NULL,
  `phone` varchar(128) DEFAULT NULL,
  `url` varchar(256) DEFAULT NULL,
  `language_id` int(10) unsigned DEFAULT NULL,
  `description` varchar(4096) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_business_created_by` (`created_by`),
  KEY `FK_business_updated_by` (`updated_by`),
  KEY `status_id` (`status_id`),
  KEY `language_id` (`language_id`),
  CONSTRAINT `FK_business` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_business_created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_business_language_id` FOREIGN KEY (`language_id`) REFERENCES `language` (`id`),
  CONSTRAINT `FK_business_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




/*Table structure for table `business_category` */

CREATE TABLE `business_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned DEFAULT NULL,
  `business_category_master_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `business_id` (`business_id`),
  KEY `business_category_master_id` (`business_category_master_id`),
  CONSTRAINT `FK_business_category` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`),
  CONSTRAINT `FK_business_category_category_id` FOREIGN KEY (`business_category_master_id`) REFERENCES `business_category_master` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*Table structure for table `business_image` */

CREATE TABLE `business_image` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned DEFAULT NULL,
  `file` varchar(256) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_business_image` (`business_id`),
  KEY `FK_business_image_status` (`status_id`),
  KEY `FK_business_image_created_by` (`created_by`),
  KEY `FK_business_image_updated_by` (`updated_by`),
  CONSTRAINT `FK_business_image` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`),
  CONSTRAINT `FK_business_image_created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_business_image_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_business_image_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `business_working_hours` */

CREATE TABLE `business_working_hours` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned DEFAULT NULL,
  `day` enum('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') DEFAULT NULL,
  `open` time DEFAULT NULL,
  `close` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_business_working_hours` (`business_id`),
  CONSTRAINT `FK_business_working_hours` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*Table structure for table `settings` */

CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(128) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `type` enum('AutoSinc','Feed','Social') DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_settings` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;



/*Table structure for table `user_settings` */

CREATE TABLE `user_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `setting_id` int(10) unsigned DEFAULT NULL,
  `value` enum('Yes','No') DEFAULT 'Yes',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `setting_id` (`setting_id`),
  CONSTRAINT `FK_user_settings` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_user_settings_setting_id` FOREIGN KEY (`setting_id`) REFERENCES `settings` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*Table structure for table `user_weight_log` */

CREATE TABLE `user_weight_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `weight_unit_id` int(10) unsigned DEFAULT NULL,
  `body_fat` float DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `weight_unit_id` (`weight_unit_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_user_weight_log` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_user_weight_log_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_user_weight_log_unit_id` FOREIGN KEY (`weight_unit_id`) REFERENCES `unit` (`id`),
  CONSTRAINT `FK_user_weight_log_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



/*Table structure for table `user_check_in` */

CREATE TABLE `user_check_in` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `business_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `business_id` (`business_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_user_check_in` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_user_check_in_business_id` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`),
  CONSTRAINT `FK_user_check_in_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;





/*Table structure for table `meal_unit_nutrition_fact` */

CREATE TABLE `meal_unit_nutrition_fact` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meal_id` int(10) unsigned DEFAULT NULL,
  `nutrition_fact_id` int(10) unsigned DEFAULT NULL,
  `value` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meal_id` (`meal_id`),
  KEY `nutrition_fact_id` (`nutrition_fact_id`),
  CONSTRAINT `FK_meal_unit_nutrition_fact_meal_id` FOREIGN KEY (`meal_id`) REFERENCES `meal` (`id`),
  CONSTRAINT `FK_meal_unit_nutrition_fact` FOREIGN KEY (`nutrition_fact_id`) REFERENCES `nutrition_fact` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*Table structure for table `feed_type` */

CREATE TABLE `feed_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_feed_type_status_id` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*Table structure for table `feed` */

CREATE TABLE `feed` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(16) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_feed_status_id` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_feed_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*Table structure for table `feed_data` */

CREATE TABLE `feed_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `feed_id` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `feed_type_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `data` varchar(4096) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `feed_id` (`feed_id`),
  KEY `feed_type_id` (`feed_type_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_feed_data` FOREIGN KEY (`feed_type_id`) REFERENCES `feed_type` (`id`),
  CONSTRAINT `FK_feed_data_status_id` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_feed_data_user_id` FOREIGN KEY (`feed_id`) REFERENCES `feed` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



/*Table structure for table `friends` */

CREATE TABLE `friends` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(16) DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `friend_id` int(10) unsigned NOT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `friend_id` (`friend_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_friends` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_friends_friend_id` FOREIGN KEY (`friend_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_friends_status_id` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



/*Table structure for table `friend_request` */

CREATE TABLE `friend_request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `friend_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `friend_id` (`friend_id`),
  KEY `user_id` (`user_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `FK_friend_request` FOREIGN KEY (`friend_id`) REFERENCES `friends` (`id`),
  CONSTRAINT `FK_friend_request_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;





/*Table structure for table `message` */

CREATE TABLE `message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(16) DEFAULT NULL,
  `message` varchar(4096) DEFAULT NULL,
  `sender_id` int(10) unsigned DEFAULT NULL,
  `receiver_id` int(10) unsigned DEFAULT NULL,
  `sender_message_status_id` int(10) unsigned DEFAULT NULL,
  `receiver_message_status_id` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `receiver_id` (`receiver_id`),
  KEY `sender_message_status_id` (`sender_message_status_id`),
  KEY `receiver_message_status_id` (`receiver_message_status_id`),
  CONSTRAINT `FK_message_receiver_id` FOREIGN KEY (`receiver_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_message_receiver_status` FOREIGN KEY (`receiver_message_status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `FK_message_sender_id` FOREIGN KEY (`sender_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_message_sender_status` FOREIGN KEY (`sender_message_status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;







