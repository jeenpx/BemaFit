

CREATE TABLE `activity_level_master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `activity_level_master` */

/*Table structure for table `ad` */

CREATE TABLE `ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ad_type_id` int(10) DEFAULT NULL,
  `content` varchar(2048) DEFAULT NULL,
  `time_from` datetime DEFAULT NULL,
  `time_to` datetime DEFAULT NULL,
  `business_name` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ad` */

/*Table structure for table `ad_image` */

CREATE TABLE `ad_image` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ad_id` int(10) unsigned DEFAULT NULL,
  `file` varchar(256) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `status_id` int(10) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ad_image` */

/*Table structure for table `ad_location` */

CREATE TABLE `ad_location` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ad_id` int(10) unsigned DEFAULT NULL,
  `ad_location_master_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ad_location` */

/*Table structure for table `ad_location_master` */

CREATE TABLE `ad_location_master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ad_location_master` */

/*Table structure for table `business` */

CREATE TABLE `business` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `address1` varchar(256) DEFAULT NULL,
  `address2` varchar(256) DEFAULT NULL,
  `state` int(10) unsigned DEFAULT NULL,
  `city` varchar(128) DEFAULT NULL,
  `phone` varchar(128) DEFAULT NULL,
  `url` varchar(256) DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `language_id` int(10) unsigned DEFAULT NULL,
  `description` varchar(4096) DEFAULT NULL,
  `status_id` int(10) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `business` */

/*Table structure for table `business_category` */

CREATE TABLE `business_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned DEFAULT NULL,
  `business_category_master_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `business_category` */

/*Table structure for table `business_category_master` */

CREATE TABLE `business_category_master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `business_category_master` */

/*Table structure for table `business_image` */

CREATE TABLE `business_image` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned DEFAULT NULL,
  `file` varchar(256) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `status_id` int(10) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `business_image` */

/*Table structure for table `business_working_hours` */

CREATE TABLE `business_working_hours` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned DEFAULT NULL,
  `day` enum('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') DEFAULT NULL,
  `open` time DEFAULT NULL,
  `close` time DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `business_working_hours` */

/*Table structure for table `cms_category` */

CREATE TABLE `cms_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(512) DEFAULT NULL,
  `slug` varchar(512) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cms_category` */

/*Table structure for table `cms_content` */

CREATE TABLE `cms_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `slug` varchar(256) DEFAULT NULL,
  `title` varchar(256) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cms_content` */

/*Table structure for table `exercise` */

CREATE TABLE `exercise` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `exercise_type_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `exercise` */

/*Table structure for table `exercise_type` */

CREATE TABLE `exercise_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `status_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `exercise_type` */

/*Table structure for table `exercise_type_option` */

CREATE TABLE `exercise_type_option` (
  `id` int(10) DEFAULT NULL,
  `exercise_type_id` int(10) DEFAULT NULL,
  `option` varchar(128) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `exercise_type_option` */

/*Table structure for table `favourite_recipe` */

CREATE TABLE `favourite_recipe` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` tinyint(3) unsigned DEFAULT NULL,
  `recipe_id` tinyint(3) unsigned DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  `created_by` int(10) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `favourite_recipe` */

/*Table structure for table `feed` */

CREATE TABLE `feed` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `feed` */

/*Table structure for table `feed_data` */

CREATE TABLE `feed_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `feed_id` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `feed_type_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `data` varchar(4096) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `feed_data` */

/*Table structure for table `feed_type` */

CREATE TABLE `feed_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `feed_type` */

/*Table structure for table `forum` */

CREATE TABLE `forum` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `description` varchar(2048) DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `forum` */

/*Table structure for table `forum_topic` */

CREATE TABLE `forum_topic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `forum_id` int(10) unsigned DEFAULT NULL,
  `topic` varchar(1024) DEFAULT NULL,
  `status_id` int(10) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `forum_topic` */

/*Table structure for table `forum_topic_posts` */

CREATE TABLE `forum_topic_posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `forum_topic_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(1024) DEFAULT NULL,
  `post` text,
  `status_id` int(10) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `forum_topic_posts` */

/*Table structure for table `friend_request` */

CREATE TABLE `friend_request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `friend_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `friend_request` */

/*Table structure for table `friends` */

CREATE TABLE `friends` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `friend_id` int(10) unsigned NOT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `friends` */

/*Table structure for table `goal` */

CREATE TABLE `goal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `goal` */

/*Table structure for table `goal_option` */

CREATE TABLE `goal_option` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goal_id` int(10) DEFAULT NULL,
  `value` varchar(128) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `goal_option` */

/*Table structure for table `language` */

CREATE TABLE `language` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `encoding` varchar(16) DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `language` */

/*Table structure for table `macro` */

CREATE TABLE `macro` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `macro` */

/*Table structure for table `meal` */

CREATE TABLE `meal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `meal_type_id` int(10) unsigned DEFAULT NULL,
  `language_id` int(10) unsigned DEFAULT NULL,
  `brand_name` varchar(128) DEFAULT NULL,
  `serving_size` float DEFAULT NULL,
  `serving_size_unit` int(10) unsigned DEFAULT NULL,
  `saving_per_container` varchar(128) DEFAULT NULL,
  `description` varchar(2048) DEFAULT NULL,
  `vendor_verified` enum('Yes','No') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `meal` */

/*Table structure for table `meal_category` */

CREATE TABLE `meal_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meal_id` int(10) unsigned DEFAULT NULL,
  `meal_category_master_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `meal_category` */

/*Table structure for table `meal_category_master` */

CREATE TABLE `meal_category_master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `meal_category_master` */

/*Table structure for table `meal_image` */

CREATE TABLE `meal_image` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meal_id` int(10) unsigned DEFAULT NULL,
  `file` varchar(256) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `status_id` int(10) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `meal_image` */

/*Table structure for table `meal_macro` */

CREATE TABLE `meal_macro` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meal_id` int(10) DEFAULT NULL,
  `macro_id` int(10) DEFAULT NULL,
  `value` varchar(128) DEFAULT NULL,
  `unit_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `meal_macro` */

/*Table structure for table `meal_type` */

CREATE TABLE `meal_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `meal_type` */

/*Table structure for table `message` */

CREATE TABLE `message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message` varchar(4096) DEFAULT NULL,
  `sender_id` int(10) unsigned DEFAULT NULL,
  `receiver_id` int(10) unsigned DEFAULT NULL,
  `sender_message_status_id` int(10) unsigned DEFAULT NULL,
  `receiver_message_status_id` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `message` */

/*Table structure for table `nutritional_plan` */

CREATE TABLE `nutritional_plan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `nutritional_plan` */

/*Table structure for table `recipe` */

CREATE TABLE `recipe` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `description` varchar(2048) DEFAULT NULL,
  `serve_count` float DEFAULT NULL,
  `serving_size` float DEFAULT NULL,
  `serving_size_unit_id` int(10) unsigned DEFAULT NULL,
  `number_of_serving` float DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `recipe` */

/*Table structure for table `recipe_category` */

CREATE TABLE `recipe_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recipe_id` int(10) unsigned DEFAULT NULL,
  `recipe_category_master_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `recipe_category` */

/*Table structure for table `recipe_category_master` */

CREATE TABLE `recipe_category_master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `user_id` tinyint(3) unsigned DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `recipe_category_master` */

/*Table structure for table `recipe_direction` */

CREATE TABLE `recipe_direction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recipe_id` int(10) unsigned DEFAULT NULL,
  `direction` varchar(512) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `recipe_direction` */

/*Table structure for table `recipe_ingredient` */

CREATE TABLE `recipe_ingredient` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recipe_id` int(10) unsigned DEFAULT NULL,
  `ingredient` varchar(512) DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `recipe_ingredient` */

/*Table structure for table `recipe_macro` */

CREATE TABLE `recipe_macro` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recipe_id` int(10) DEFAULT NULL,
  `macro_id` int(10) DEFAULT NULL,
  `value` varchar(128) DEFAULT NULL,
  `unit_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `recipe_macro` */

/*Table structure for table `settings` */

CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(32) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `type` enum('Feed','Social') DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `settings` */

/*Table structure for table `unit` */

CREATE TABLE `unit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `unit` */

/*Table structure for table `user` */

CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(32) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `first_name` varchar(32) NOT NULL,
  `last_name` varchar(32) DEFAULT NULL,
  `role` enum('Admin','User') DEFAULT NULL,
  `password` varchar(256) DEFAULT NULL,
  `profile_photo` varchar(128) DEFAULT NULL,
  `type` enum('Public','Private') DEFAULT NULL,
  `status_id` tinyint(3) unsigned DEFAULT NULL,
  `website` varchar(64) DEFAULT NULL,
  `remember_token` varchar(256) DEFAULT NULL,
  `gender` enum('F','M') DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `facebook_user_id` varchar(32) NOT NULL,
  `facebook_access_token` varchar(512) DEFAULT NULL,
  `date_last_login` datetime DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `added_by` int(10) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`,`first_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user` */

/*Table structure for table `user_check_in` */

CREATE TABLE `user_check_in` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `business_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_check_in` */

/*Table structure for table `user_details` */

CREATE TABLE `user_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `height` float DEFAULT NULL COMMENT 'Store feet converted to inch',
  `weight` float DEFAULT NULL,
  `weight_unit_id` int(10) DEFAULT NULL,
  `body_fat` float DEFAULT NULL,
  `activity_level_id` int(10) DEFAULT NULL,
  `goal_option_id` int(10) DEFAULT NULL,
  `protein` float DEFAULT NULL,
  `fat` float DEFAULT NULL,
  `carbs` float DEFAULT NULL,
  `fiber` float DEFAULT NULL,
  `calories` float DEFAULT NULL,
  `meals_per_day` int(4) DEFAULT NULL,
  `neutirition_plan_id` int(10) unsigned DEFAULT NULL,
  `recovery_password` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_details` */

/*Table structure for table `user_exercise_log` */

CREATE TABLE `user_exercise_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `exercise_id` int(10) unsigned DEFAULT NULL,
  `exercise_type_option_id` int(10) unsigned DEFAULT NULL,
  `value` varchar(64) DEFAULT NULL,
  `unit` float DEFAULT NULL,
  `method` enum('Add','Copy','Sent') DEFAULT NULL,
  `exercise_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_exercise_log` */



/*Table structure for table `user_meal_log` */

CREATE TABLE `user_meal_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `meal_id` int(10) unsigned DEFAULT NULL,
  `meal_type_id` int(10) unsigned DEFAULT NULL,
  `serving_size` float DEFAULT NULL,
  `number_of_serving` float DEFAULT NULL,
  `meal_date` date DEFAULT NULL,
  `method` enum('Add','Copy','Sent','Split') DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_meal_log` */

/*Table structure for table `user_meal_macro` */

CREATE TABLE `user_meal_macro` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_meal_id` int(10) unsigned DEFAULT NULL,
  `macro_id` int(10) unsigned DEFAULT NULL,
  `value` float DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_meal_macro` */

/*Table structure for table `user_settings` */

CREATE TABLE `user_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `setting_id` int(10) DEFAULT NULL,
  `value` enum('Yes','No') DEFAULT 'Yes',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_settings` */

/*Table structure for table `user_weight_log` */

CREATE TABLE `user_weight_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `weight_unit_id` int(10) unsigned DEFAULT NULL,
  `body_fat` float DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_weight_log` */


