/*
SQLyog Enterprise - MySQL GUI v8.14 
MySQL - 5.5.37-0ubuntu0.13.10.1 : Database - st_2014
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`st_2014` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `st_2014`;

/*Data for the table `states` */

insert  into `states`(`id`,`state_code`,`state_name`,`country_iso`,`country_id`,`congressional_districts`) values (1,'AL','Alabama','US',223,7),(2,'AK','Alaska','US',223,1),(3,'AB','Alberta','CA',36,0),(4,'AZ','Arizona','US',223,8),(5,'AR','Arkansas','US',223,4),(6,'BC','British Columbia','CA',36,0),(7,'CA','California','US',223,53),(8,'CO','Colorado','US',223,7),(9,'CT','Connecticut','US',223,5),(10,'DE','Delaware','US',223,1),(11,'DC','District of Columbia','US',223,0),(12,'FL','Florida','US',223,25),(13,'GA','Georgia','US',223,13),(14,'HI','Hawaii','US',223,2),(15,'ID','Idaho','US',223,2),(16,'IL','Illinois','US',223,19),(17,'IN','Indiana','US',223,9),(18,'IA','Iowa','US',223,5),(19,'KS','Kansas','US',223,4),(20,'KY','Kentucky','US',223,6),(21,'LA','Louisiana','US',223,7),(22,'ME','Maine','US',223,2),(23,'MB','Manitoba','CA',36,0),(24,'MD','Maryland','US',223,8),(25,'MA','Massachusetts','US',223,10),(26,'MI','Michigan','US',223,15),(27,'MN','Minnesota','US',223,8),(28,'MS','Mississippi','US',223,4),(29,'MO','Missouri','US',223,9),(30,'MT','Montana','US',223,1),(31,'NE','Nebraska','US',223,3),(32,'NV','Nevada','US',223,3),(33,'NB','New Brunswick','CA',36,0),(34,'NF','Newfoundland','CA',36,0),(35,'NH','New Hampshire','US',223,2),(36,'NJ','New Jersey','US',223,13),(37,'NM','New Mexico','US',223,3),(38,'NY','New York','US',223,29),(39,'NC','North Carolina','US',223,13),(40,'ND','North Dakota','US',223,1),(41,'NT','Northwest Territories','CA',36,0),(42,'NS','Nova Scotia','CA',36,0),(43,'NU','Nunavut','CA',36,0),(44,'OH','Ohio','US',223,18),(45,'OK','Oklahoma','US',223,5),(46,'ON','Ontario','CA',36,0),(47,'OR','Oregon','US',223,5),(48,'PA','Pennsylvania','US',223,19),(49,'PE','Prince Edward Island','CA',36,0),(50,'QC','Quebec','CA',36,0),(51,'RI','Rhode Island','US',223,2),(52,'SK','Saskatchewan','CA',36,0),(53,'SC','South Carolina','US',223,6),(54,'SD','South Dakota','US',223,1),(55,'TN','Tennessee','US',223,9),(56,'TX','Texas','US',223,32),(57,'UT','Utah','US',223,3),(58,'VT','Vermont','US',223,1),(59,'VA','Virginia','US',223,11),(60,'WA','Washington','US',223,9),(61,'WV','West Virginia','US',223,3),(62,'WI','Wisconsin','US',223,8),(63,'WY','Wyoming','US',223,1),(64,'YT','Yukon','CA',36,0),(65,'BCN','Baja California','MX',150,0),(66,'N/A','No State','',0,0),(67,'NSW','New South Wales','AU',14,0),(68,'QLD','Queensland','AU',14,0),(69,'SA','South Australia','AU',14,0),(70,'TAS','Tasmania','AU',14,0),(71,'VIC','Victoria','AU',14,0),(72,'WA','Western Australia','AU',14,0),(100,'AGU','Aguascalientes','MX',150,0),(101,'BCS','Baja California Sur','MX',150,0),(102,'CAM','Campeche','MX',150,0),(103,'CHP','Chiapas','MX',150,0),(104,'CHH','Chihuahua','MX',150,0),(105,'COA','Coahuila','MX',150,0),(106,'COL','Colima','MX',150,0),(107,'DUR','Durango','MX',150,0),(108,'GUA','Guanajuato','MX',150,0),(109,'GRO','Guerrero','MX',150,0),(110,'HID','Hidalgo','MX',150,0),(111,'JAL','Jalisco','MX',150,0),(112,'MEX','MÃ©xico','MX',150,0),(113,'MIC','MichoacÃ¡n','MX',150,0),(114,'MOR','Morelos','MX',150,0),(115,'NAY','Nayarit','MX',150,0),(116,'NLE','Nuevo LeÃ³n','MX',150,0),(117,'OAX','Oaxaca','MX',150,0),(118,'PUE','Puebla','MX',150,0),(119,'QUE','QuerÃ©taro','MX',150,0),(120,'ROO','Quintana Roo','MX',150,0),(121,'SLP','San Luis PotosÃ­','MX',150,0),(122,'SIN','Sinaloa','MX',150,0),(123,'SON','Sonora','MX',150,0),(124,'TAB','Tabasco','MX',150,0),(125,'TAM','Tamaulipas','MX',150,0),(126,'TLA','Tlaxcala','MX',150,0),(127,'VER','Veracruz','MX',150,0),(128,'YUC','YucatÃ¡n','MX',150,0),(129,'ZAC','Zacatecas','MX',150,0),(130,'GU','Guam','MX',223,0),(131,'NL','Newfoundland & Labrador','CA',36,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
