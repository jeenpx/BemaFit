<?php
/**
 * Development Configuration Override
 *
 * You can use this file for overriding configuration values from modules, etc. for the development environment.
 * You would place values in here that are agnostic to the environment.
 *
 *
 */

return array(
    
);