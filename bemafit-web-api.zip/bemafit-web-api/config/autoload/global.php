<?php
/**
 * Global Configuration Override
 *
 * You can use this file for overriding configuration values from modules, etc.
 * You would place values in here that are agnostic to the environment and not
 * sensitive to security.
 *
 * @NOTE: In practice, this file will typically be INCLUDED in your source
 * control, so do not include passwords or other sensitive information in this
 * file.
 */
if (!function_exists('getallheaders')) 
{ 
    function getallheaders() 
    { 
           $headers = ''; 
       foreach ($_SERVER as $name => $value) 
       { 
           if (substr($name, 0, 5) == 'HTTP_') 
           { 
               $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value; 
           } 
       } 
       return $headers; 
    } 
} 
return array(
    'zf-oauth2' => array(
        'storage_settings' => array(
            'user_table' => 'user'
        )
    ),
    'view_helpers' => array(
        'factories' => array(
            'linkCdn' => 'AppBase\View\Helper\Service\AppBaseCdnFactory',
        )
    ),
    'service_manager' => array(
        'factories' => array(
            'Application\Service\ContentValidationListener' => 'Application\Service\ContentValidationListenerFactory',
        ),
        'invokables' => array(
            'ZF\Apigility\MvcAuth\UnauthenticatedListener' => 'Application\MvcAuth\UnauthenticatedListener',
            'ZF\Apigility\MvcAuth\UnauthorizedListener' => 'Application\MvcAuth\UnauthorizedListener',
        ),
    ),
);