<?php
return array(
	'db'          => array(
		'driver'     => 'Pdo',
		'dsn'        => 'mysql:dbname=fym_api;host=localhost',
		'username'   => 'root',
		'password'   => 'root',
		'adapters'   => array(
			'API_DB'    => array(
				'driver'   => 'Mysqli',
				'database' => 'fym_api',
				'username' => 'root',
				'password' => 'root',
				'hostname' => 'localhost',
			),
		),
	),
	'zf-oauth2'  => array(
		'db'        => array(
			'dsn_type' => 'PDO',
			'dsn'      => 'mysql:dbname=fym_api;host=localhost',
			'username' => 'root',
			'password' => 'root',
		),
	),
	'service_manager'        => array(
		'factories'             => array(
			'Db\\Adapter\\Adapter' => 'Zend\\Db\\Adapter\\AdapterServiceFactory',
		),
	),
	'appCdn'   => array(
		'css'     => array(
			'scheme' => 'http',
			'host'   => 'fym-web-api.lh',
		),
		'js'      => array(
			'scheme' => 'http',
			'host'   => 'fym-web-api.lh',
		),
		'images'  => array(
			'scheme' => 'http',
			'host'   => 'fym-web-api.lh',
		),
	),
	'zf-mvc-auth'     => array(
		'authentication' => array(
			'adapters'      => array(
				'oauth2_pdo'   => array(
					'adapter'     => 'ZF\\MvcAuth\\Authentication\\OAuth2Adapter',
					'storage'     => array(
						'adapter'    => 'pdo',
						'dsn'        => 'mysql:dbname=fym;host=localhost',
						'route'      => '/oauth',
						'username'   => 'root',
						'password'   => 'root',
					),
				),
			),
		),
	),
);
