<?php
/**
 *
 * Local Configuration Override
 *
 * You can use this file for overriding configuration values from modules, etc. for your local environment.
 * You would place values in here that are agnostic to the environment.
 *
 * @NOTE: In practice, this file will typically not be INCLUDED in your source control.
 *
 */
if($_SERVER['SERVER_PORT'] == '443') {
    $protocol = 'https';
} else {
    $protocol = 'http';
}
return array(
    'db' => array(
        'driver'         => 'Pdo',
        'dsn'            => 'mysql:dbname=fym_core;host=fymdb.c59jgus5q6nm.us-west-2.rds.amazonaws.com',
        'username' => 'fymDBUser',
        'password' => 'EMjmEVYVL6vn',
        'driver_options' => array(
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES UTF8"
        ),
        'adapters' => array(
            'API_DB' => array(
                'driver' => 'Mysqli',
                'database' => 'fym_core',
                'username' => 'fymDBUser',
                'password' => 'EMjmEVYVL6vn',
                'hostname' => 'fymdb.c59jgus5q6nm.us-west-2.rds.amazonaws.com',
            ),
        ),
    ),
    'view_manager' => array(
    'display_not_found_reason' => true,
    'display_exceptions'       => true,
),
    'zf-oauth2' => array(
        'db' => array(
            'dsn_type' => 'PDO',
            'dsn' => 'mysql:dbname=fym_core;host=fymdb.c59jgus5q6nm.us-west-2.rds.amazonaws.com',
            'username' => 'fymDBUser',
            'password' => 'EMjmEVYVL6vn',
        ),
        'options' => array(
            'always_issue_new_refresh_token'=>true,
        ),
    
    ),
    'service_manager' => array(
        'factories' => array(
             'Db\Adapter\Adapter' => function ($serviceManager) {
                $adapterFactory = new \Zend\Db\Adapter\AdapterServiceFactory();
               $adapter = $adapterFactory->createService($serviceManager);

               Zend\Db\TableGateway\Feature\GlobalAdapterFeature::setStaticAdapter($adapter);

               return $adapter;
         }
        ),
    ),
    'appCdn' => array(
        'css' => array(
            'scheme' => $protocol,
            'host' => 'http://bemafit.com',
        ),
        'js' => array(
            'scheme' => $protocol,
            'host' => 'http://bemafit.com',
        ),
        'images' => array(
            'scheme' => $protocol,
            'host' => 'http://bemafit.com',
        ),
    ),
    'smtp' => array(
        'host' => 'smtp.office365.com',
        'user' => 'arun.ss@digitalbrandgroup.com',
        'password' => '123@arun',
    ),
    'mail' => array(
        'default_sender_id' => 'info@bemafit.com',
        'default_sender_name' => 'Team BemaFit',
    ),
    'amazon_ses' => array(
        'key' => 'AKIAJXZA5BCZGVQOSRHA',
        'secret' => '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',
        'region' => 'us-west-2',
    ),
    'amazon_s3' => array(
        'key' => 'AKIAJXZA5BCZGVQOSRHA',
        'secret' => '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',
        'region' => 'us-east-1',
    ),
    'amazon_dynamo' => array(
       'key' => 'AKIAIUM2TKXQ5KLQORTA',
       'secret' => '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',
       'region' => 'us-west-2', 
       'endpoint' => 'https://dynamodb.us-west-2.amazonaws.com'
    ),
    'emailVerificationUrl' => 'http://flexyourmacros.com/verify.php?code=',
    'oauthUrl' => 'http://api.flexyourmacros.com/oauth',
    'site_url'=>'http://flexyourmacros.com',
    'fym_email_source' => 'FYM <info@flexyourmacros.com>',
    'conactfym_mailto' => 'info@flexyourmacros.com',
    'apple_pushnotifications' => array(
        'apnsHost' => 'gateway.sandbox.push.apple.com',
        'apnsPort' => 2195,
        'apnsCert' => 'apple_settings/bemafit_staging.pem',
        'passphrase' => '',
    ),
);
