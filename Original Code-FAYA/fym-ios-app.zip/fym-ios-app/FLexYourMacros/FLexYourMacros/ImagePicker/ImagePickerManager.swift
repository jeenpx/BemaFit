//
//  ImagePickerManager.swift
//  ImagePicker
//
//  Created by Deepu S Nath on 10/03/15.
//  Copyright (c) 2015 DBG. All rights reserved.
//

import Foundation
import UIKit
import AssetsLibrary
import AVFoundation

typealias ImagePickerManagerCallback = (image: UIImage, source: UIImagePickerControllerSourceType) -> ()

class ImagePickerManager: NSObject, UIActionSheetDelegate, UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    // singleton manager
    class var sharedManager :ImagePickerManager {
        struct Singleton {
            static let instance = ImagePickerManager()
        }
        return Singleton.instance
    }
    
    // the view controller that presents the Image picker
    private var parentViewController: UIViewController?
    
    // completion handler
    private var completionHandler: ImagePickerManagerCallback?
    
    // action sheet for Image Picker
    private let actionSheet = UIActionSheet(title: nil, delegate: nil, cancelButtonTitle: &&"cancel", destructiveButtonTitle: nil, otherButtonTitles: &&"take_photo", &&"choose_existing")
    
   
    func presentImagePicker(viewController: UIViewController, completionHandler: ImagePickerManagerCallback) -> () {
        
        //check whether both camera and photolibrary are not accesible
        let mediaStatus = AVCaptureDevice.authorizationStatusForMediaType(AVMediaTypeVideo)
        let photoLibstatus = ALAssetsLibrary.authorizationStatus()
        
        if !(mediaStatus == .NotDetermined || mediaStatus == .Authorized || photoLibstatus == .NotDetermined || photoLibstatus == .Authorized) {
            
            UIAlertView(title: &&"access_denied_title", message: "Please enable gallery or camera permissions", delegate: nil, cancelButtonTitle: &&"cancel").show()
            return
        }
        
        // save the completion handler
        self.completionHandler = completionHandler
        
        // save the parent view controller
        parentViewController = viewController
        
        // present the action sheet
        actionSheet.delegate = self
        actionSheet.showInView((parentViewController?.view)!)
    }
    
    func actionSheet(actionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int) {
        
        // get the source type for image picker controller
        var sourceType: UIImagePickerControllerSourceType
        switch buttonIndex {
        case 2: sourceType = .PhotoLibrary
        case 1: sourceType = .Camera
        default: return
        }
        
        
        // check for permissions
        // splitting up because the status classes doesnt match
        if sourceType == .PhotoLibrary {
            let status = ALAssetsLibrary.authorizationStatus()
            if !(status == .NotDetermined || status == .Authorized) {
                
                UIAlertView(title: &&"access_denied_title", message: &&"access_denied_message_photo", delegate: nil, cancelButtonTitle: &&"cancel").show()

                // go out
                return
            }
        }
        else if sourceType == .Camera {
            let status = AVCaptureDevice.authorizationStatusForMediaType(AVMediaTypeVideo)
            if !(status == .NotDetermined || status == .Authorized) {
                
                UIAlertView(title: &&"access_denied_title", message: &&"access_denied_message_camera", delegate: nil, cancelButtonTitle: &&"cancel").show()
                
                // go out
                return
            }
        }
        
        // configure image picker controller
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.allowsEditing = true
        imagePickerController.sourceType = sourceType
        
        // present the image picker controller
        parentViewController?.presentViewController(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        // fire completion handler
        completionHandler?(image: info[UIImagePickerControllerEditedImage] as! UIImage, source: picker.sourceType)
        
        // dismiss the image picker
        dismissImagePicker()
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissImagePicker()
    }
    
    func dismissImagePicker() {
        parentViewController?.dismissViewControllerAnimated(true, completion: nil)
    }
    
}


