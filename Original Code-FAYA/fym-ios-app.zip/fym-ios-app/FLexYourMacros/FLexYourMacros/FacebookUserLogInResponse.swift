//
//  FacebookUserLogIn.swift
//  FlexYourMacros
//
//  Created by mini on 24/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//
import Foundation

private let _FacebookUserLogInResponse = FacebookUserLogInResponse()

class FacebookUserLogInResponse: NSObject {
    
    var accessTokenModel: AccessTokenModel?
    var userDietModel: UserDietModel?
    var userDetailModel: UserDetailModel?
    var metaModel: MetaModel?
    
    class var sharedFacebookUserLogInResponse: FacebookUserLogInResponse {
        return _FacebookUserLogInResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(FacebookUserLogInResponse.metaModelKeyMapping)
        
        // give reference to accesstoken mapping
        responseMapping.addPropertyMapping(FacebookUserLogInResponse.accessTokenModelKeyMapping)
        
        // give reference to diet mapping
        responseMapping.addPropertyMapping(FacebookUserLogInResponse.userDietModelKeyMapping)
        
        // give reference to user credential mapping
        responseMapping.addPropertyMapping(FacebookUserLogInResponse.userDetailModelKeyMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.logInFacebookUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var accessTokenModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathAccessToken, toKeyPath: "accessTokenModel", withMapping: AccessTokenModel.objectMapping)
    }
    
    private class var userDietModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDiet, toKeyPath: "userDietModel", withMapping: UserDietModel.objectMapping)
    }
    
    private class var userDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDetail, toKeyPath: "userDetailModel", withMapping: UserDetailModel.objectMapping)
    }
    
    
    
    class func logInFacebookUser(viewController: UIViewController, facebookAccessToken: String, completionHandler: (accessCredential: AccessTokenModel, userDiet: UserDietModel, userDetails: UserDetailModel) -> (), failedWithError: (error: String) -> ()) {
        
        // add loading indicator
        SVProgressHUD.show()

        RestKitManager.setupBasicAuth()
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["facebook_access_token":facebookAccessToken, "grant_type":"password"]
        }
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(nil, method: .POST, path: Constants.ServiceConstants.logInFacebookUrl, parameters: parameterDictionary, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
        let userDefaults = NSUserDefaults.standardUserDefaults()
        
        let deviceAccessToken = userDefaults.objectForKey("token") as? String ?? ""
        
        RKObjectManager.sharedManager().HTTPClient.setDefaultHeader("Device-Token", value: deviceAccessToken)
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            // remove loading indicator
//            MBProgressHUD.hideHUDForView(viewController.view, animated: true)
            SVProgressHUD.dismiss()

            
            let userLogInResponse = mappingResult.firstObject as! FacebookUserLogInResponse
            
            // check for success
            if userLogInResponse.metaModel?.responseCode != 200 {
                
                var errorMessage = userLogInResponse.metaModel?.message ?? ""
                let errorMessages = userLogInResponse.metaModel?.errormessages
                if errorMessages!.isEmpty {
                    
                } else {
                    
                    errorMessage = errorMessages?.first?.fieldMessage ?? ""
                }
                failedWithError(error: errorMessage)
                return
            }
            
            // set up the completion handler with response
            completionHandler(accessCredential: userLogInResponse.accessTokenModel!, userDiet: userLogInResponse.userDietModel!, userDetails: userLogInResponse.userDetailModel!)
            
            //print("accessTokenModel in \(userLogInResponse.accessTokenModel?.accessToken)")

            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                // remove loading indicator
//                MBProgressHUD.hideHUDForView(viewController.view, animated: true)
                SVProgressHUD.dismiss()

                
                failedWithError(error: error.localizedDescription)
                //print("failed to load user verification with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
    
    
}
