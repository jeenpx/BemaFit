//
//  FacebookManager.m
//  FacebookSample
//
//  Created by Aromal S on 18/05/15.
//  Copyright (c) 2015 Codebase. All rights reserved.
//

#import "FacebookManager.h"


@implementation FacebookShareModel
@synthesize description,pictureLink,link,name,message;



@end

@interface  FacebookManager()

@property(strong,nonatomic) FbShareCallBack fbShareCallBack;
@property(strong,nonatomic)  FBSDKGraphRequest* fbrequest;
@end

@implementation FacebookManager
@synthesize fbShareCallBack,fbrequest;
+ (id)sharedManager {
    static FacebookManager *sharedMyManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedMyManager = [[self alloc] init];
    });
    return sharedMyManager;
}

-(void)openSessionWithReadPermissions:(NSArray*)permissions withHandler:(FBSDKLoginManagerRequestTokenHandler)handler
{
    
    FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
    
    // permissions = @ [@"email", @"user_location",@"user_friends",@"public_profile"];
    [login logInWithReadPermissions:permissions handler:handler];
    
}

-(void)openSessionWithWritePermissions:(NSArray*)permissions withHandler:(FBSDKLoginManagerRequestTokenHandler)handler
{
    FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
    
    //  permissions = @[@"publish_actions"];
    [FBSDKAccessToken currentAccessToken];
    [login logInWithPublishPermissions:permissions handler:handler];
}
+(void)openSessionWithWritePermissions:(NSArray*)permissions withHandler:(FBSDKLoginManagerRequestTokenHandler)handler
{
    FacebookManager* fbmanger = [FacebookManager sharedManager];
    
    [fbmanger openSessionWithWritePermissions:permissions withHandler:handler];
}

+(void)openSessionWithReadPermissionsWithHandler:(FBSDKLoginManagerRequestTokenHandler)handler
{
    
    FacebookManager* fbmanger = [FacebookManager sharedManager];
    NSArray* permissionss = @[@"public_profile",@"email"];
    [fbmanger openSessionWithReadPermissions:permissionss withHandler:handler];
}
+(void)handleDidFinish:(UIApplication*) application andLaunchOptions:(NSDictionary *)launchOptions
{
    [[FBSDKApplicationDelegate sharedInstance] application:application
                             didFinishLaunchingWithOptions:launchOptions];
}

+(void)logout{
    
    FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
    [login logOut];
}

+(void)activateApp
{
    
    //should be called in applicationDidBecomeActive
    [FBSDKAppEvents activateApp];
}
+ (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    return [[FBSDKApplicationDelegate sharedInstance] application:application
                                                          openURL:url
                                                sourceApplication:sourceApplication
                                                       annotation:annotation];
}
+(BOOL) hasPermisssion:(NSString*) permission
{
    return [[FBSDKAccessToken currentAccessToken] hasGranted:@"publish_actions"];
    // TODO: publish content.
    
}

+(BOOL)isLoginedToFacebook
{
    BOOL isLoginedToFacebook =  [FBSDKAccessToken currentAccessToken];
    
    NSLog(@"isLogined to facebook %@",((isLoginedToFacebook)?@"YES":@"NO"));
    
    return isLoginedToFacebook;
    
}
+(void)showShareDialogWithShareModel:(UIViewController*) parentViewController andModel:(FacebookShareModel*)fbsharemodel andCallback:(FbShareCallBack) fbshareCallback
{
    FacebookManager* fbmanger = [FacebookManager sharedManager];
    
    [fbmanger showShareDialogWithShareModel:parentViewController andModel:fbsharemodel andCallback:fbshareCallback];
}
-(void)showShareDialogWithShareModel:(UIViewController*) parentViewController andModel:(FacebookShareModel*)fbsharemodel andCallback:(FbShareCallBack) fbshareCallback
{
    
    self.fbShareCallBack = fbshareCallback;
    FBSDKShareLinkContent* content = [[FBSDKShareLinkContent alloc] init];
    content.contentURL = [NSURL URLWithString: fbsharemodel.link];
    content.contentTitle = fbsharemodel.name;
    //    content.quote = @"FYM";
    content.contentDescription = fbsharemodel.description;
    if (fbsharemodel.pictureLink!=nil && [fbsharemodel.pictureLink length]>0) {
        content.imageURL = [NSURL URLWithString:fbsharemodel.pictureLink];
    }
    
    
    
    //    [FBSDKShareDialog showFromViewController:parentViewController withContent:content delegate:self];
    
    FBSDKShareDialog *dialog = [[FBSDKShareDialog alloc] init];
    
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"fbauth2://"]]){
        dialog.mode = FBSDKShareDialogModeNative;
    }
    else {
        dialog.mode = FBSDKShareDialogModeAutomatic; //or FBSDKShareDialogModeAutomatic
    }
    
    
    //    dialog.mode = FBSDKShareDialogModeBrowser; //or FBSDKShareDialogModeAutomatic
    
    dialog.shareContent = content;
    dialog.delegate = self;
    dialog.fromViewController = parentViewController;
    [dialog show];
    
    
}


/*!
 @abstract Sent to the delegate when the share completes without error or cancellation.
 @param sharer The FBSDKSharing that completed.
 @param results The results from the sharer.  This may be nil or empty.
 */
- (void)sharer:(id<FBSDKSharing>)sharer didCompleteWithResults:(NSDictionary *)results
{
    
    NSLog(@"Share results %@",results);
    
    if(results!=nil&&[results objectForKey:@"postId"])
    {
        self.fbShareCallBack(SUCCESS,results,nil);
    }
    else{
        self.fbShareCallBack(ERROR,nil,[NSError errorWithDomain:@"com.fym.fym" code:1002 userInfo:nil]);
    }
    
    
}

+(void)getUserDetail:(FBGetUserDetailCallBack)fbUserDetailCallBack
{
    FacebookManager* fbmanger = [FacebookManager sharedManager];
    [fbmanger getUserDetail:fbUserDetailCallBack];
}
-(void)getUserDetail:(FBGetUserDetailCallBack)fbUserDetailCallBack
{
    
    self.fbrequest =  [[FBSDKGraphRequest alloc]initWithGraphPath:@"/me" parameters:@{@"fields": @"id, name,email,first_name,last_name,gender"} HTTPMethod:@"GET"];
    [fbrequest startWithCompletionHandler:^(FBSDKGraphRequestConnection* connection, id result, NSError *error) {
        
        NSLog(@"Result %@ Error %@",result,error);
        if(error==nil)
        {
            fbUserDetailCallBack(result);
        }
        
    }];
    
}
/*!
 @abstract Sent to the delegate when the sharer encounters an error.
 @param sharer The FBSDKSharing that completed.
 @param error The error.
 */
- (void)sharer:(id<FBSDKSharing>)sharer didFailWithError:(NSError *)error
{
    self.fbShareCallBack(ERROR,nil,error);
}

/*!
 @abstract Sent to the delegate when the sharer is cancelled.
 @param sharer The FBSDKSharing that completed.
 */
- (void)sharerDidCancel:(id<FBSDKSharing>)sharer
{
    self.fbShareCallBack(CANCELLED,nil,[NSError errorWithDomain:@"com.fym.fym" code:1001 userInfo:nil]);
}
@end
