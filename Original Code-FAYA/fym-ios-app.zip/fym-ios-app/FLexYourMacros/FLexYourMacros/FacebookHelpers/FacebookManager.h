//
//  FacebookManager.h
//  FacebookSample
//
//  Created by Aromal S on 18/05/15.
//  Copyright (c) 2015 Codebase. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginManager.h>
#import <FBSDKLoginKit/FBSDKLoginManagerLoginResult.h>
#import <FBSDKShareKit/FBSDKShareDialog.h>
#import <FBSDKShareKit/FBSDKShareLinkContent.h>


typedef enum FBShareCallBackStatus
{
    
    SUCCESS,
    CANCELLED,
    ERROR
    
    
}FBShareCallBackStatus;
typedef void (^FBGetUserDetailCallBack) (NSDictionary *userDetails);
typedef void (^FbShareCallBack)(FBShareCallBackStatus fbShareCallBackStatus, NSDictionary* results, NSError* error);

@interface FacebookShareModel:NSObject
@property(strong,nonatomic) NSString* name;
@property(strong,nonatomic) NSString* description;
@property(strong,nonatomic) NSString* message;
@property(strong,nonatomic) NSString* link;
@property(strong,nonatomic) NSString* pictureLink;

@end

@interface FacebookManager : NSObject<FBSDKSharingDelegate>

+ (id)sharedManager;
+(void)getUserDetail:(FBGetUserDetailCallBack)fbUserDetailCallBack;


+(void)handleDidFinish:(UIApplication*) application andLaunchOptions:(NSDictionary *)launchOptions;
+(void)activateApp;
+ (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

+(void)openSessionWithWritePermissions:(NSArray*)permissions withHandler:(FBSDKLoginManagerRequestTokenHandler)handler;
+(void)openSessionWithReadPermissionsWithHandler:(FBSDKLoginManagerRequestTokenHandler)handler;
+(void)logout;
+(BOOL) hasPermisssion:(NSString*) permission;
+(BOOL)isLoginedToFacebook;
+(void)showShareDialogWithShareModel:(UIViewController*) parentViewController andModel:(FacebookShareModel*)fbsharemodel andCallback:(FbShareCallBack) fbshareCallback;


@end
