//
//  NewMessageCell.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/6/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class NewMessageCell: UITableViewCell {
    
    @IBOutlet weak var labelMessage: UILabel!
    
    // set value for labelMessage
    var messageData: MessageItemModel? {
        didSet {
            labelMessage.text = messageData!.message!
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
