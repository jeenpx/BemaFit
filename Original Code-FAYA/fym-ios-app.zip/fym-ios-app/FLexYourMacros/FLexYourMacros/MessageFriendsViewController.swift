//
//  MessageFriendsViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 3/31/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class MessageFriendsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITableViewDragLoadDelegate, UISearchBarDelegate, UITextFieldDelegate, UserProfileDelegate {
    
    // array to hold friends
    var friends: [FriendModel]?
    
    // temporary variable to store offset
    var tempOffset = 0
    
    // temporary array to store friends
    var arrayTempFriends: [FriendModel]?
    
    // temporary variable to store friends count
    var tempFriendsCount = ""
    
    // offset value for friends list
    var offset = 0
    
    // limit value for friends list
    var limit = 10
    
    // friends count
    var friendsCount = ""
    
    // keyword for search
    var stringKeyword = ""
    
    // posted message
    var postedMessage = MessageItemModel()
    
    
    struct MessageFriendsConstants {
        
        // cell identifier for friends list
        static let cellIdentifierFriendsList = "kMessageFriendsCell"
        
        // cell identifier for the  section header
        static let cellIdentifierFriendsSection = "kMessageFriendsSectionCell"
        
        // segue identifier for new message
        static let segueIdentifierNewMessage = "kSegueNewMessage"
        
        // segue identifier for user profile
        static let segueIdentifierMessageProfile = "kSegueMessageProfile"
        
        // empty records
        static let emptyMessage = &&"empty_tableview_message"
    }
    
    // tableview for friends list
    @IBOutlet weak var tableViewMessageFriends: UITableView!
    
    // searchbar for for friends list
    @IBOutlet weak var searchBarMessageFriends: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchBarMessageFriends.delegate = self
        
        // configure the tableview
        configureTableView()
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        // list the friends
        listFriends(offset, andLimit: limit, andKeyword: stringKeyword, doLoadMore: false, andProgressHUD: true)
    }
    
    func configureTableView() {
        
        // hide empty tableview cells
        tableViewMessageFriends.tableFooterView = UIView(frame: CGRectZero)
        
        // set delegate for pull to refresh and load more
        tableViewMessageFriends.setDragDelegate(self, refreshDatePermanentKey: "kMessageFriends")
        
        // hide pull to refresh
        tableViewMessageFriends.showRefreshView = false
        
        // show load more
        tableViewMessageFriends.showLoadMoreView = true
        
        // tableview footer release text
        tableViewMessageFriends.footerReleaseText = NSLocalizedString("release_to_load_more_status", comment: "")
        
        // tableview footer pull up text
        tableViewMessageFriends.footerPullUpText = NSLocalizedString("pull_down_to_load_more_status", comment: "")
        
        //tableview footer loading text
        tableViewMessageFriends.footerLoadingText = NSLocalizedString("loading_status", comment: "")
        
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let count = self.friends?.count {
            
            if count == 0 {
                // show empty record message
                
                tableViewMessageFriends.showEmptyTableViewMessage(MessageFriendsConstants.emptyMessage)
            }
            else {
                tableViewMessageFriends.backgroundView = UIView()
                tableViewMessageFriends.separatorStyle = .SingleLine
            }
            
            return count
        }
        return 0
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let messageFriendsCell = tableView.dequeueReusableCellWithIdentifier(MessageFriendsConstants.cellIdentifierFriendsList, forIndexPath: indexPath) as! MessageFriendsCell
        if let friendModel: FriendModel  = self.friends?[indexPath.row] {
            
            // save the friend
            messageFriendsCell.friend = friendModel
            messageFriendsCell.userProfileDelegate = self
        }
        return messageFriendsCell
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        // view for section
        
        let messageFriendsSectionCell = tableView.dequeueReusableCellWithIdentifier(MessageFriendsConstants.cellIdentifierFriendsSection) as! MessageFriendsSectionCell
        
        // set the friends count
        messageFriendsSectionCell.friendsCount = self.friendsCount
        return messageFriendsSectionCell as UIView
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let selectedCell: MessageFriendsCell  = tableView.cellForRowAtIndexPath(indexPath) as! MessageFriendsCell
        self.performSegueWithIdentifier(MessageFriendsConstants.segueIdentifierNewMessage, sender: selectedCell.friend)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == MessageFriendsConstants.segueIdentifierNewMessage {
            // navigate to new message
            
            let newMessageViewController = segue.destinationViewController as! NewMessageViewController
            newMessageViewController.friend = sender as? FriendModel
        }
        else if segue.identifier == MessageFriendsConstants.segueIdentifierMessageProfile {
            let profileViewController = segue.destinationViewController as! ProfileViewController
            profileViewController.userId = sender as? String ?? ""
        }
    }
    
    
    
    
    func dragTableDidTriggerLoadMore(tableView: UITableView!) {
        // called when the load more is selected
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            
            // finish the load more
            NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: "finishLoadMore", userInfo: nil, repeats: false)
            return
        }
        
        if let count = self.friends?.count {
            // save messages count to offset
            
            offset = count
        }
        else {
            // set offset to zero
            
            offset = 0
        }
        
        // list friends
        listFriends(offset, andLimit: limit, andKeyword: stringKeyword, doLoadMore: true, andProgressHUD: false)
    }
    
    func dragTableLoadMoreCanceled(tableView: UITableView!) {
        // called when the load more is cancelled
        
        NSObject.cancelPreviousPerformRequestsWithTarget(self, selector: Selector("finishLoadMore"), object: nil)
    }
    
    func finishLoadMore() {
        // to stop the load more and populate the tableview with new items
        tableViewMessageFriends.finishLoadMore()
    }
    
    func listFriends(offset: Int, andLimit limit: Int, andKeyword keyword: String, doLoadMore loadMore: Bool, andProgressHUD showLoader: Bool) {
        // list friends based on offset, limit and loadmore status
        
        GetFriendsResponse.getTypeFriends(offset, andLimit: limit, keywords: keyword, andProgressHUD: showLoader) { (typeFriends) -> () in
            
            if self.friends?.isEmpty == false  {
                for friend in typeFriends {
                    self.friends?.append(friend)
                }
            }
            else {
                self.friends = typeFriends
            }
            
            if let friendMessages = self.friends {
                
                // save friends count
                self.friendsCount = String(friendMessages.count)
            }
            
            if loadMore {
                
                // finish the load more
                self.finishLoadMore()
            }
            
            // reload the tableview
            self.tableViewMessageFriends.reloadData()
        }
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        
        searchBar.setShowsCancelButton(false, animated: true)
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            searchBar.resignFirstResponder()
            return
        }
        
        // save search bar text
        stringKeyword = searchBar.text!
        
        // store offset to tempoary offset variable
        tempOffset = offset
        
        // store friends to tempoary friends array
        arrayTempFriends = friends
        
        // store friends count to temporary friends count
        tempFriendsCount = friendsCount
        
        // set offset 0
        offset = 0
        
        // friends array set to empty
        friends?.removeAll()
        
        // set friends count zero
        friendsCount = ""
        
        // list friends
        listFriends(offset, andLimit: limit, andKeyword: stringKeyword, doLoadMore: false, andProgressHUD: true)
        searchBar.resignFirstResponder()
    }
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        
        if(searchText.isEmpty) {
            
            // show previous data
            searchBarTextEmpty()
        }
    }
    
    func searchBarShouldBeginEditing(searchBar: UISearchBar) -> Bool {
        searchBar.setShowsCancelButton(true, animated: true)
        return true
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchBar.text!.removeAll(keepCapacity: true)
        searchBar.setShowsCancelButton(false, animated: true)
        searchBar.resignFirstResponder()
        
        // show previous data
        searchBarTextEmpty()
    }
    
    func searchBarTextEmpty() {
        
        // set keyword empty
        stringKeyword = ""
        
        if (arrayTempFriends != nil) {
            
            // store temporary offset value back to offset variable
            offset = tempOffset
            
            // store temporary array friends value back to friends array
            friends = arrayTempFriends
            
            // store temporary friends count value back to friends count
            friendsCount = tempFriendsCount
            
            // to reload tableview data
            tableViewMessageFriends.reloadData()
        }
    }
    
    @IBAction func unwindToMessageFriendsViewController(segue: UIStoryboardSegue) {
        if let newMessageViewController = segue.sourceViewController as? NewMessageViewController {
            
            // save posted message
            self.postedMessage = newMessageViewController.postedMessage
        }
    }
    
    // delegate function to navigate user to user profile
    func userProfile(userId: String) {
        performSegueWithIdentifier(MessageFriendsConstants.segueIdentifierMessageProfile, sender: userId)
    }
    
    
    
    
}
