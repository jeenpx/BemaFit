//
//  MealTypeCreateResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 03/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class MealTypeCreateResponse: NSObject {
    
    var meta = MetaModel()
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
        responseMapping.addPropertyMapping(metaModelMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let mealTypeCreateResponseDescriptor = RKResponseDescriptor(mapping: MealTypeCreateResponse.responseMapping, method: .POST, pathPattern: Constants.ServiceConstants.kMealTypeListUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return mealTypeCreateResponseDescriptor
    }
    
    class func createMealType(params: [String: AnyObject], completionHandler: (error: NSError?) -> ()) {
        
        RestKitManager.setToken(true)
        
        // create a post request
        let request = RestKitManager.sharedManager().requestWithObject(nil, method: .POST, path: Constants.ServiceConstants.kMealTypeListUrl, parameters: nil)
        
        // set params as body
        request.HTTPBody = try? NSJSONSerialization.dataWithJSONObject(params, options: NSJSONWritingOptions())
        
        // create an operation with the request
        let operation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation, mappingResult) in
            
            let mealTypeCreateResponse = mappingResult.firstObject as! MealTypeCreateResponse
            
            // check for success
            if mealTypeCreateResponse.meta.responseCode == 200 {
                completionHandler(error: nil)
                return
            }
            
            // configure error messages
            var message = ""
            if mealTypeCreateResponse.meta.responseCode == 500 {
                if mealTypeCreateResponse.meta.message == "Meal Type already exist" {
                    message = "create_meal_type_validation_message"
                }
                else {
                    message = "create_meal_type_limit_error_message"
                }
            }
            else {
                message = "create_meal_type_error_message"
            }
            
            completionHandler(error: NSError(domain: "FYM.MealType", code: 1002, userInfo: ["title": "error", "message": message]))
            
            }, failure: { (operation, error) in
                //print("XXX failed to create mealtype with error \(error)")
                completionHandler(error: NSError(domain: "FYM.MealType", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"]))
        })
        
        // enque request operation
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
    
}
