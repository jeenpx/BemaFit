//
//  AdsModel.swift
//  FlexYourMacros
//
//  Created by DBG on 24/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class Advertisement: NSObject {

    var id = ""
    var content: String?
    var imageUrlString: String?
    var type: String?
    var name: String?
    
    var imageURL: NSURL? {
        return NSURL(string: imageUrlString ?? "")
    }
    
    var shouldShowAdvertisement: Bool {
        return imageURL != nil
    }
    
    var shouldDisplayAdvertisement: Bool {
        
        if let adsUrlString = imageUrlString {
            if adsUrlString.isEmpty {
                return false
            }else {
                return true
            }
        }
        return false
    }
    
    
    class var objectMapping: RKObjectMapping {
        let adsMapping = RKObjectMapping(forClass: self)
        adsMapping.addAttributeMappingsFromDictionary(mappingDictionary)
        return adsMapping
    }
    
    class var mappingDictionary: [String: String] {
        return ["id": "id","content":"content","image_url":"imageUrlString","type":"type","name":"name"]
    }

    class func latestAdvertisement(location: String, completionHandler: Advertisement -> ()) {
        let params: Dictionary<String, AnyObject>  = ["location":location, "type": "App"]
        AdsResponse.getAvailableAds(params) { (getAds) -> () in
            let getAdsResponse = getAds
            
            if getAdsResponse.metaModel?.responseCode == 200 {
                if let arrayAds: [Advertisement] = getAdsResponse.adsModel as [Advertisement]? {
                    // chk the count
                    "".isEmpty
                    
                    if arrayAds.count > 0 {
                        
                        let ad = arrayAds[0] as Advertisement
                        completionHandler(ad)
                       /* if let adsUrlString = ad.imageUrlString {
                            
                            // image url is empty
                            if adsUrlString.isEmpty {
                                //println("empty")
                            }else{
                                completionHandler(ad)
                                
                            }
                            
                        }
                        */
                    }
                }
            }
        }
    }
    
}
