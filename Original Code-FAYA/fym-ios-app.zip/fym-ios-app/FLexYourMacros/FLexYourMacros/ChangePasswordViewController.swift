//
//  ChangePasswordViewController.swift
//  FlexYourMacros
//
//  Created by Vineeth Edwin on 10/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ChangePasswordViewController: UITableViewController, UITextFieldDelegate {
    
    @IBOutlet private weak var textFieldCurrentPassword: UITextField!
    @IBOutlet private weak var textFieldNewPassword: UITextField!
    @IBOutlet private weak var textFieldConfirmPassword: UITextField!
    
    func validateFields(completion: (success: Bool, error: NSError?) -> ()) {
       // "empty_text_currentPassword"    = "Please enter current password";
       // "empty_text_NewPassword"        = "Please enter new password";
        //"empty_text_ConfirmPassword"    = "Please enter confirm password";
        
//        "password_message_current_password" = "Mínimo 6 caracteres se requiere para la contraseña actual";
//        "password_message_new_password"     = "Mínimo 6 caracteres se requiere para la nueva contraseña";
//        "password_message_confirm_password" = "Mínimo 6 caracteres se requiere para confirmar la contraseña";
        
        // check if current password empty
        if textFieldCurrentPassword.isEmpty {
            // current password is empty
            completion(success: false, error: NSError(domain: "FYM.Validation", code: 0, userInfo: ["title": &&"notice", "message": &&"empty_text_currentPassword" ]))
            return
            
        } else if textFieldCurrentPassword.text!.characters.count<6  {
            // current password mini 6
            completion(success: false, error: NSError(domain: "FYM.Validation", code: 0, userInfo: ["title": &&"notice", "message": &&"password_message_current_password"]))
            return
            
            
        } else if textFieldNewPassword.isEmpty {
            // new password is empty
            completion(success: false, error: NSError(domain: "FYM.Validation", code: 0, userInfo: ["title": &&"notice", "message": &&"empty_text_NewPassword"]))
            return
            
            
        } else if textFieldNewPassword.text!.characters.count<6 {
            // newpassword is 6
            completion(success: false, error: NSError(domain: "FYM.Validation", code: 0, userInfo: ["title": &&"notice", "message": &&"password_message_new_password"]))
            return
            
            
        } else if textFieldConfirmPassword.isEmpty {
            // empty
            completion(success: false, error: NSError(domain: "FYM.Validation", code: 0, userInfo: ["title": &&"notice", "message": &&"empty_text_ConfirmPassword"]))
            return
            
            
        } else if textFieldConfirmPassword.text!.characters.count<6 {
            // confirm password minimum 6
            completion(success: false, error: NSError(domain: "FYM.Validation", code: 0, userInfo: ["title": &&"notice", "message": &&"password_message_confirm_password"]))
            return
            
        }
        
       // validate textfields

        // check if new password and confirm passwords match
        let isSame = textFieldNewPassword.text == textFieldConfirmPassword.text
        if !isSame {
            completion(success: false, error: NSError(domain: "FYM.Validation", code: 1, userInfo: ["title": &&"notice", "message": &&"password_mismatch_message"]))
            return
        }
        
        // success
        completion(success:true, error: nil)
    }
   
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        // hide keyboard on return
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func buttonActionChangePassword(sender: UIButton) {
   
        // validate fields
        validateFields { (success, error) -> () in
            
            if let error = error {
                if let alertInfo = error.userInfo as? [String: String] {
                    self.showAlert(alertInfo["title"]!, message: alertInfo["message"]!)
                }
            }else {
            //api for change password
                ChangePasswordResponse.userChangePassword(self.textFieldCurrentPassword.text!,newPassword:self.textFieldNewPassword.text!,completionHandler: { (userChangePasswordResponse) -> () in
                    
                    let userChangepasswordResonse = userChangePasswordResponse
                    //print("respone code :\(userChangepasswordResonse.metaModel?.responseCode)")
                    //print("respone status :\(userChangepasswordResonse.metaModel?.responseStatus)")
              
                 
                    // check for success
                    if userChangepasswordResonse.metaModel?.responseCode == 200 {
                        // Successsfully changed password
                        //print("respone code :\(userChangepasswordResonse.metaModel?.responseCode)")
                        //print("respone status :\(userChangepasswordResonse.metaModel?.responseStatus)")
                       //print("Status is \(userChangePasswordResponse.changePasswordModel?.status)")
                        self.showAlert(&&"Password", message: &&"Succcessfully_Changed")

                        
                    } else if userChangepasswordResonse.metaModel?.responseCode == 422 {
                        
                        // Invalid old password
                        //print("respone code :\(userChangepasswordResonse.metaModel?.responseCode)")
                        //print("respone status :\(userChangepasswordResonse.metaModel?.responseStatus)")
                        self.showAlert(&&"Password", message: &&"Invalid_Old_Password")

                        
                    } else if userChangepasswordResonse.metaModel?.responseCode == 404 {
                        
                        // User doen't exist
                        //print("respone code :\(userChangepasswordResonse.metaModel?.responseCode)")
                        //print("respone status :\(userChangepasswordResonse.metaModel?.responseStatus)")
                        self.showAlert(&&"Password", message: &&"user_doesnot_exist")
                    }
                  
                });
                

                
            }
        }
    }
    
    @IBAction func buttonActionBack(sender: UIBarButtonItem) {
        // checks if the settings needed to be updated
        self.navigationController?.popViewControllerAnimated(true)
        
    }
    func showAlert(title: String, message: String) {
    
        UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"ok").show()
        
    }
}
