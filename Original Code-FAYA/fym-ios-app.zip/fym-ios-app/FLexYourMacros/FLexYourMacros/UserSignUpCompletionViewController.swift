//
//  UserSignUpCompletionViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 05/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UserSignUpCompletionViewController: UITableViewController, UITextFieldDelegate, SignUpCompleteTableViewCellDelegate {
    
    struct StoryBoard {
        
        struct CellIdentifiers {
            static let UpdateCell =  "kUpdateCell"
            static let HeaderCell    =  "kHeaderCell"
            static let CalorieCell      =  "kCalorieCell"
            static let FiberCell  =  "kFibreCell"
            static let MacroCell = "kMacroCell"
            static let CustomCell       = "kCustomCell"
        }
        
        struct SegueIdentifiers {
            static let CompleteSignUp = "kSignUpComplete"
        }
        
        struct ViewControllerIdentifiers {
            static let LogInVC = "kEmailVC"
        }
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    @IBOutlet var tabelView: UITableView!
    var didEdit: Bool = false
    let FYMUserModel = FymUser.sharedFymUser
    var currentTextField = UITextField()
    var customCarbPercentage: Double = 0.0
    var customFatPercentage: Double = 0.0
    var customProteinPercentage: Double = 0.0
    var isUpdateButtonPresent = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.rightBarButtonItem?.setTitleTextAttributes([NSFontAttributeName: UIFont(name: "Helvetica", size: 13.0)!], forState: UIControlState.Normal)
        
        customCarbPercentage = FYMUserModel.userCustomCarbsPercentage
        customFatPercentage = FYMUserModel.userCustomFatPercentage
        customProteinPercentage = FYMUserModel.userCustomProteinPercentage
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 5
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        if section == 4 {
            return 1
        } else if section == 2 {
            return 3
        }
        return 1
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 4 {
            return 0
        }
        return 40.0
    }
    
    override func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        //        // section four of the table contains the update button
        if section == 4 {
            return UIView(frame: CGRectZero)
        }
        let headerView = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.HeaderCell) as! SignUpCompleteTableViewCell
        headerView.labelHeaderTitle.text = setSectionHeaderTitles(section)
        return headerView
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.section == 4 {
            return 120.0
        }
        return 60.0
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var cell = SignUpCompleteTableViewCell()
        if indexPath.section == 0 {
            // section zero holds the calorie prototype cell
            cell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.CalorieCell, forIndexPath: indexPath) as! SignUpCompleteTableViewCell
            cell.configureCell()
        } else if indexPath.section == 1 {
            // section one holds the fibre prototype cell
            cell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.FiberCell, forIndexPath: indexPath) as! SignUpCompleteTableViewCell
            cell.textFieldFiber.delegate = self
            cell.textFieldFiber.tag = 120
            cell.textFieldFiber.userInteractionEnabled = FYMUserModel.userNutritionType == "5" ? true : false
            cell.configureCell()
            return cell
        } else if indexPath.section == 2 {
            // section two holds the macro prototype cell
            cell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.MacroCell, forIndexPath: indexPath) as! SignUpCompleteTableViewCell
            cell.textFieldMacroValue.delegate = self
            cell.textFieldMacroValue.tag = indexPath.row
            //  based on the selected nutrition type user interaction for the macro breakdown cells are managed
            cell.textFieldMacroValue.userInteractionEnabled = FYMUserModel.userNutritionType == "5" ? true : false
            cell.tag = indexPath.row
            cell.configureCell()
            return cell
        } else if indexPath.section == 3 {
            // custom cell for entering meal number
            cell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.CustomCell, forIndexPath: indexPath) as! SignUpCompleteTableViewCell
            cell.textFieldMealNumber.delegate = self
            cell.textFieldMealNumber.tag = 110;
            cell.configureCell()
        } else if indexPath.section == 4 {
            // custom cell for entering meal number
            cell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.UpdateCell) as! SignUpCompleteTableViewCell
            // if in editing mode update button is visible
            //            if didEdit {
            cell.buttonUpdate.hidden = FYMUserModel.userNutritionType != "5"
            isUpdateButtonPresent = true
            //            } else {
            //                cell.buttonUpdate.hidden = true
            //                isUpdateButtonPresent = false
            //            }
            
            cell.signUpCompleteTableViewCellDelegate = self
        }
        
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if tableView.cellForRowAtIndexPath(indexPath)?.reuseIdentifier == StoryBoard.CellIdentifiers.MacroCell  {
            
            let cell = tableView.cellForRowAtIndexPath(indexPath) as! SignUpCompleteTableViewCell
            
            cell.textFieldMacroValue.becomeFirstResponder()
        }
        
    }
    
    func setSectionHeaderTitles(sectionIndex: Int) -> String {
        
        // manage the header titles for the sections in the table view
        var headerTitle: String
        
        switch sectionIndex {
        case 0:
            headerTitle = &&"calculate_calories"
        case 1:
            headerTitle = &&"fiber_goal"
        case 2:
            headerTitle = &&"calculate_macros"
        case 3:
            headerTitle = &&"no_of_meals"
        default :
            headerTitle = ""
        }
        
        return headerTitle
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        //print("string ---\(string)")
        // managing the textfield input: limit the characters to only of numeric type
        
        if string == " " {
            return false
        }
        
        if string.isEmpty {
            return true
        }
        
        var isValid = true
        let text = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        
        // check for unwanted characters
        let replacementStringIsLegal = string.rangeOfCharacterFromSet(NSCharacterSet(charactersInString: "0123456789.").invertedSet) == nil
        
        
        if textField.tag == 120 {
            // textfield fiber
            
            // check for string count
            let resultingStringLengthIsLegal = text.characters.count <= 7
            
            
            // check if the number is valid
            let scanner = NSScanner(string: text)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
            
            let isLowNumber = text.doubleValue < 100000
            
            isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber
        }
        else if textField.tag == 110 {
            // number of meals
            
            var result = true
            let prospectiveText = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
            if string.characters.count > 0 {
                let disallowedCharacterSet = NSCharacterSet(charactersInString: "0123456789").invertedSet
                let replacementStringIsLegal = string.rangeOfCharacterFromSet(disallowedCharacterSet) == nil
                let resultingStringLengthIsLegal = prospectiveText.characters.count <= 10
                let scanner = NSScanner(string: prospectiveText)
                let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
                result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
            }
            return result
        }
        else {
            
            // check for string count
            let resultingStringLengthIsLegal = text.characters.count <= 5
            
            
            // check if the number is valid
            let scanner = NSScanner(string: text)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
            
            let isLowNumber = text.doubleValue <= 100
            
            isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber
            
        }
        
        return isValid
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        
        //        if textField.tag != 110 {
        //            textField.text = ""
        //        }
        currentTextField = textField
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        // on return of text field editing update the user model with macro values
        if textField.tag == 0 {
            customFatPercentage  = textField.text!.doubleValue
            if checkTheMacroTotal() {
            }
        } else if textField.tag == 1 {
            customCarbPercentage  = textField.text!.doubleValue
            if checkTheMacroTotal() {
            }
        } else if textField.tag == 2 {
            customProteinPercentage  = textField.text!.doubleValue
            if checkTheMacroTotal() {
            }
        } else if textField.tag == 110 {
            FYMUserModel.userNumberOfMeals  = textField.text!.intValue
            currentTextField.resignFirstResponder()
        } else if textField.tag == 120 {
            //fiber value entered
            FYMUserModel.userCustomFiberValue = textField.text!
            currentTextField.resignFirstResponder()
        }
        
        return true
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        
        // on ending of text field editing update the user model with macro values
        //print("//print tag----\(textField.tag)")
        if textField.tag == 0 {
            customFatPercentage  = textField.text!.doubleValue
            if checkTheMacroTotal() {
            }
        } else if textField.tag == 1 {
            customCarbPercentage  = textField.text!.doubleValue
            if checkTheMacroTotal() {
            }
        } else if textField.tag == 2 {
            customProteinPercentage  = textField.text!.doubleValue
            if checkTheMacroTotal() {
            }
        } else if textField.tag == 110 {
            FYMUserModel.userNumberOfMeals  = textField.text!.intValue
        } else if textField.tag == 120 {
            //fiber value entered
            FYMUserModel.userCustomFiberValue = textField.text!
            currentTextField.resignFirstResponder()
            
        }
        
    }
    
    func checkTheMacroTotal() -> Bool {
        
        currentTextField.resignFirstResponder()
        
        // check macro total : show alert when it is not equal to 100%
        var checkMacro = true
        let totalMacroPercentage = customFatPercentage + customCarbPercentage + customProteinPercentage
        if  totalMacroPercentage.roundPlaces(3) > 99.994 && totalMacroPercentage.roundPlaces(3) <= 100.0 {
            didEdit = true
            
            //            self.tableView .reloadSections(NSIndexSet(indexesInRange: NSMakeRange(4, 1)), withRowAnimation: UITableViewRowAnimation.Left)
            
            
        } else {
            checkMacro = false
            didEdit = false
            
            //            self.tableView .reloadSections(NSIndexSet(indexesInRange: NSMakeRange(4, 1)), withRowAnimation: UITableViewRowAnimation.Left)
        }
        return checkMacro
    }
    
    @IBAction func unwindToUserSignUpCompletionViewController(segue: UIStoryboardSegue) {
        // close the side menu if its open
    }
    
    @IBAction func buttonActionSignUpCompletion(sender: UIBarButtonItem) {
        
        
        currentTextField.resignFirstResponder()
        
        if FYMUserModel.userNutritionType == "5" {
            
            
            if(!self.validateCustomEntry())
            {
                return
            }
            
            
        }
        
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        UserSignUpResponse.signUpUser(self, completionHandler: { (userDetails, userDiet) -> () in
            
            if userDetails.userFacebookId != "" {
                
                // the current user is a facebook user
                FacebookUserLogInResponse.logInFacebookUser(self, facebookAccessToken: UserFacebookCredentialModel.sharedUserFacebookCredentialModel.userFbAccessToken!, completionHandler: { (accessCredential, userDiet, userDetails) -> () in
                    
                    AppConfiguration.sharedAppConfiguration.userDetails = userDetails
                    
                    AppConfiguration.sharedAppConfiguration.userDiet = userDiet
                    
                    AppConfiguration.sharedAppConfiguration.userCredential = accessCredential
                    
                    //print("accesstoken:\(AppConfiguration.sharedAppConfiguration.userCredential?.accessToken)")
                    //print("userid:\(AppConfiguration.sharedAppConfiguration.userDetails?.userId)")
                    
                    // load dashboard
                    self.appDelegate?.loadDashboard()
                    
                    }, failedWithError: { (error) -> () in
                        self.showAlert(&&"notice", message: error)
                        
                })
                
                return
                
            }
            
            if !reachability {
                
                self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                return
            }
            
            UserLogInResponse.logInUser(self, username: self.FYMUserModel.userEmail, password: self.FYMUserModel.userPassword, completionHandler: { (accessCredential, userDiet, userDetails) -> () in
                
                FymUser.resetSharedInstance()
                
                //save user sign up time
                let userDefaults = NSUserDefaults.standardUserDefaults()
                userDefaults.setObject(NSDate(), forKey: "created_date")
                userDefaults.synchronize()
                
                AppConfiguration.sharedAppConfiguration.userDetails = userDetails
                
                AppConfiguration.sharedAppConfiguration.userDiet = userDiet
                
                AppConfiguration.sharedAppConfiguration.userCredential = accessCredential
                
                //print("accesstoken:\(AppConfiguration.sharedAppConfiguration.userCredential?.accessToken)")
                
                //                self.showAlert(&&"notice", message: &&"user_registration_completed_alert_message")
                
                // load dashboard
                self.appDelegate?.loadDashboard()
                
                
                }, failedWithError: { (error) -> () in
                    self.showAlert(&&"notice", message: error)
            })
            
            }) { (failed) -> () in
                self.showAlert(&&"notice", message: failed)
                
        }
        
    }
    
    func showAlert(title: String, message: String) {
        
        if #available(iOS 8.0, *) {
            
            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
            alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            return
            
        } else {
            // Fallback on earlier versions
            
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"ok").show()
            return
        }
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        cell.setSeparatorInsetZero()
    }
    
    func buttonActionUpdate(signUpCompleteTableViewCell: SignUpCompleteTableViewCell) {
        
        currentTextField.resignFirstResponder()
        
        didEdit = false
        FYMUserModel.userCustomFatPercentage = customFatPercentage
        FYMUserModel.userCustomCarbsPercentage = customCarbPercentage
        FYMUserModel.userCustomProteinPercentage = customProteinPercentage
        
        self.tableView.reloadData()
        self.validateCustomEntry()
        
    }
    
    func validateCustomEntry() -> Bool{
        if FYMUserModel.userNutritionType == "5" {
            
            let totalMacroPercentage = customFatPercentage + customCarbPercentage + customProteinPercentage
            
            if FYMUserModel.userCustomFiberValue.doubleValue <= 0.0 {
                
                if #available(iOS 8.0, *) {
                    let alert = UIAlertController(title: &&"notice", message: &&"custom_fiber_greater_zero", preferredStyle: .Alert)
                    alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
                    self.presentViewController(alert, animated: true, completion: nil)
                    
                } else {
                    // Fallback on earlier versions
                    
                    UIAlertView(title: &&"notice", message: &&"custom_fiber_greater_zero", delegate: nil, cancelButtonTitle: &&"ok").show()
                }
                
                return false
            }
            
            if Int(totalMacroPercentage) != 100 {
                
                // show alert controller if possible else show alert view
                if #available(iOS 8.0, *) {
                    
                    let alert = UIAlertController(title: &&"notice", message: &&"macro_percentage_add_upto_100", preferredStyle: .Alert)
                    alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
                    self.presentViewController(alert, animated: true, completion: nil)
                    
                } else {
                    // Fallback on earlier versions
                    
                    UIAlertView(title: &&"notice", message: &&"macro_percentage_add_upto_100", delegate: nil, cancelButtonTitle: &&"ok").show()
                }
                return false
            }
            
            FYMUserModel.userCustomFatPercentage = customFatPercentage
            FYMUserModel.userCustomCarbsPercentage = customCarbPercentage
            FYMUserModel.userCustomProteinPercentage = customProteinPercentage
            return true
        }
        else
        {
            return true
        }
    }
    
    @IBAction func buttonActionBack(sender: UIBarButtonItem) {
        
        self.navigationController?.popViewControllerAnimated(false)
    }
    
    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool {
        
        if (identifier == StoryBoard.SegueIdentifiers.CompleteSignUp) {
            
            let signInViewController = self.storyboard?.instantiateViewControllerWithIdentifier(StoryBoard.ViewControllerIdentifiers.LogInVC) as! UserEmailLogInViewController
        }
        return true
    }
}