//
//  Food.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 27/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

enum LogType: String {
    case Log = "Log"
    case Copy = "Copy"
    case Send = "Send"
    case Split = "Share"
}

protocol HeightCalculating {
    var expectedHeight: CGFloat { get }
}

class Food: Equatable, HeightCalculating {
    
    private let nameLogByMacro = &&"log_by_macro"
    
    var id = ""
    var guid = ""
    var genre = ""
    var name = ""
    var name_es = ""
    var brandName = ""
    var description = ""
    var unit = ""
    var method = ""
    var approve = ""
    var mealType = MealType(name: "")
    
    var logDate = ""
    var image = ""
    var imageLarge = ""
    var vendorVerified = ""
    
    //meal plan specific
    var foodType = ""
    var foodRowId = ""
    var foodParentId = ""
    var foodFocus = ""
    var dependentIds = ""
    var servingSizeFixed = ""
    var dmpMealType = ""
    var foodAddedMethod = ""
    var isRefreshed = false
    var locaLGeneratedId : String?
    var foodCategories = Set<FoodCategory>()
    var dailyMealType = DailyMealType(dailyMealTypeName: "")
    var uniqueID : String = ""
    var isLoggedByMacro = false {
        didSet {
            name = nameLogByMacro
        }
    }
    
    var numberOfServings = 1.0
    var calories = 0.0
    var fiber = 0.0
    
    var servingSize = 0.0
    var carbohydrates = 0.0
    var protein = 0.0
    var fat = 0.0
    var saturated = 0.0
    var polyunsaturated = 0.0
    var monosaturated = 0.0
    var trans = 0.0
    var cholesterol = 0.0
    var sodium = 0.0
    var sugar = 0.0
    var potassium = 0.0
    var vitaminA = 0.0
    var vitaminC = 0.0
    var calcium = 0.0
    var iron = 0.0
    var createdDate: String = ""
    var statusId: String = ""
    var addedDate: NSDate?
    
    
    init(name: String = "") {
        self.name = name
    }
    init(foodToBeCopied : Food){
        self.id = foodToBeCopied.id
        self.guid = foodToBeCopied.guid
        self.genre = foodToBeCopied.genre
        self.name = foodToBeCopied.name
        self.brandName = foodToBeCopied.brandName
        self.description = foodToBeCopied.description
        self.unit = foodToBeCopied.unit
        self.method = foodToBeCopied.method
        self.approve = foodToBeCopied.approve
        self.mealType = foodToBeCopied.mealType
        
        self.logDate = foodToBeCopied.logDate
        self.image = foodToBeCopied.image
        self.imageLarge = foodToBeCopied.imageLarge
        self.vendorVerified = foodToBeCopied.vendorVerified
        
        //meal plan specific
        self.foodType = foodToBeCopied.foodType
        self.foodRowId = foodToBeCopied.foodRowId
        self.foodParentId = foodToBeCopied.foodParentId
        self.foodFocus = foodToBeCopied.foodFocus
        self.dependentIds = foodToBeCopied.dependentIds
        self.servingSizeFixed = foodToBeCopied.servingSizeFixed
        self.dmpMealType = foodToBeCopied.dmpMealType
        self.foodAddedMethod = foodToBeCopied.foodAddedMethod
        self.isRefreshed = foodToBeCopied.isRefreshed
        
        self.foodCategories = foodToBeCopied.foodCategories
        self.dailyMealType = foodToBeCopied.dailyMealType
        self.uniqueID = foodToBeCopied.uniqueID
        
        
        
        self.isLoggedByMacro = foodToBeCopied.isLoggedByMacro
        self.numberOfServings = foodToBeCopied.numberOfServings
        self.calories = foodToBeCopied.calories
        self.fiber = foodToBeCopied.fiber
        
        self.servingSize = foodToBeCopied.servingSize
        self.carbohydrates = foodToBeCopied.carbohydrates
        self.protein = foodToBeCopied.protein
        self.fat = foodToBeCopied.fat
        self.saturated = foodToBeCopied.saturated
        self.polyunsaturated = foodToBeCopied.polyunsaturated
        self.monosaturated = foodToBeCopied.monosaturated
        self.trans = foodToBeCopied.trans
        self.cholesterol = foodToBeCopied.cholesterol
        self.sodium = foodToBeCopied.sodium
        self.sugar = foodToBeCopied.sugar
        self.potassium = foodToBeCopied.potassium
        self.vitaminA = foodToBeCopied.vitaminA
        self.vitaminC = foodToBeCopied.vitaminC
        self.calcium = foodToBeCopied.calcium
        self.iron = foodToBeCopied.iron
        self.createdDate = foodToBeCopied.createdDate
        self.statusId = foodToBeCopied.statusId
        self.addedDate = foodToBeCopied.addedDate
    }
    /// Used to initialize an empty food for logging by macro
    init(isLoggedByMacro: Bool) {
        self.isLoggedByMacro = isLoggedByMacro
    }
    
    init(foodListModel: FoodListModel) {
        
        id = foodListModel.id
        guid = foodListModel.guid
        name = foodListModel.name
        servingSize = foodListModel.servingSize
        unit = foodListModel.unit
        brandName = foodListModel.brandName
        image = foodListModel.image
        imageLarge = foodListModel.imageLarge
        vendorVerified = foodListModel.vendorVerified
        
        
        calories = foodListModel.nutritionalFacts.calories
        carbohydrates = foodListModel.nutritionalFacts.carbohydrates
        protein = foodListModel.nutritionalFacts.protien
        fat = foodListModel.nutritionalFacts.fat
        fiber = foodListModel.nutritionalFacts.fiber
        saturated = foodListModel.nutritionalFacts.saturated
        polyunsaturated = foodListModel.nutritionalFacts.polyUnsaturated
        monosaturated = foodListModel.nutritionalFacts.monoSaturated
        trans = foodListModel.nutritionalFacts.trans
        cholesterol = foodListModel.nutritionalFacts.cholesterol
        sodium = foodListModel.nutritionalFacts.sodium
        potassium = foodListModel.nutritionalFacts.potassium
    }
    
    init(foodLogModel: FoodLogModel) {
        
        id = foodLogModel.foodLogId
        name = foodLogModel.foodName
        mealType = MealType(name: foodLogModel.mealType)
        numberOfServings = foodLogModel.noOfServing.doubleValue
        unit = foodLogModel.foodUnit
        
        calories = foodLogModel.nutritionalFacts.calories
        carbohydrates = foodLogModel.nutritionalFacts.carbohydrates
        protein = foodLogModel.nutritionalFacts.protien
        fat = foodLogModel.nutritionalFacts.fat
        fiber = foodLogModel.nutritionalFacts.fiber
        saturated = foodLogModel.nutritionalFacts.saturated
        polyunsaturated = foodLogModel.nutritionalFacts.polyUnsaturated
        monosaturated = foodLogModel.nutritionalFacts.monoSaturated
        trans = foodLogModel.nutritionalFacts.trans
        cholesterol = foodLogModel.nutritionalFacts.cholesterol
        sodium = foodLogModel.nutritionalFacts.sodium
        potassium = foodLogModel.nutritionalFacts.potassium
        
        servingSize = foodLogModel.servingSize.doubleValue
        brandName = foodLogModel.brandName
        
        approve = foodLogModel.approve
        logDate = foodLogModel.foodDate
        method = foodLogModel.method
        
    }
    
    init(dailyMealFoodModel: DailyMealFoodModel) {
        
        id = dailyMealFoodModel.foodId
        uniqueID = dailyMealFoodModel.uniqueID
        name = dailyMealFoodModel.foodName
        name_es = dailyMealFoodModel.foodNameSpanish
        foodFocus = dailyMealFoodModel.foodFocus
        mealType = MealType(name: dailyMealFoodModel.mealType)
        unit = dailyMealFoodModel.unit
        foodAddedMethod = "Server"
        
        calories = dailyMealFoodModel.calorie.doubleValue
        carbohydrates = dailyMealFoodModel.carbs.doubleValue
        protein = dailyMealFoodModel.protien.doubleValue
        fat = dailyMealFoodModel.fat.doubleValue
        fiber = dailyMealFoodModel.fiber.doubleValue
        saturated = dailyMealFoodModel.saturated.doubleValue
        polyunsaturated = dailyMealFoodModel.polyunsaturated.doubleValue
        monosaturated = dailyMealFoodModel.monounsaturated.doubleValue
        trans = dailyMealFoodModel.trans.doubleValue
        cholesterol = dailyMealFoodModel.cholesterol.doubleValue
        sodium = dailyMealFoodModel.sodium.doubleValue
        sugar = dailyMealFoodModel.sugar.doubleValue
        potassium = dailyMealFoodModel.potassium.doubleValue
        vitaminA = dailyMealFoodModel.vitaminA.doubleValue
        vitaminC = dailyMealFoodModel.vitaminC.doubleValue
        calcium = dailyMealFoodModel.calcium.doubleValue
        iron = dailyMealFoodModel.iron.doubleValue
        createdDate = dailyMealFoodModel.createdDate
        statusId = dailyMealFoodModel.statusId
        
        servingSize = dailyMealFoodModel.servingSize.doubleValue
        numberOfServings = dailyMealFoodModel.servingSize.doubleValue// TODO:to be changed when webservice  will get changed
        brandName = dailyMealFoodModel.brandName
        foodType = dailyMealFoodModel.foodType
        foodRowId = dailyMealFoodModel.rowId
        foodParentId = dailyMealFoodModel.parentId
        dependentIds = dailyMealFoodModel.dependentIds
        servingSizeFixed = dailyMealFoodModel.servingSizeFixed
        //        dmpMealType = dailyMealFoodModel.dmpMealType
        dailyMealType = DailyMealType(dailyMealTypeName: dailyMealFoodModel.dmpMealType)
    }
    
    
    
    
    var hasImage: Bool {
        return !image.isEmpty
    }
    
    var expectedHeight: CGFloat {
        
        let heightName = name.expectedHeight(kMainScreenWidth - 122.0 + (hasImage ? 0.0 : 74.0), font: UIFont.helveticaBold())
        
        let totalCellHeight = 75.0
        let singleLineHeight = 17.25
        
        return CGFloat(totalCellHeight - singleLineHeight + heightName)
    }
    
    func convertUnitsFood(selectedUnit: WeightUnits, cellMode: ConvertUnitsCellMode, completionHandler: (status: String) -> ()) {
        
        switch cellMode {
            
        case .Carbohydrates:
            let value = carbohydrates * selectedUnit.conversionValue
            if value.roundPlaces() < 100000 {
                carbohydrates = value.roundPlaces(2)
                completionHandler(status: "success")
            }
            else {
                completionHandler(status: "failure")
            }
            
        case .Protein:
            let value = protein * selectedUnit.conversionValue
            if value.roundPlaces() < 100000 {
                protein = value.roundPlaces(2)
                completionHandler(status: "success")
            }
            else {
                completionHandler(status: "failure")
            }
            
        case .Fats:
            let value = fat * selectedUnit.conversionValue
            if value.roundPlaces() < 100000 {
                fat = value.roundPlaces(2)
                completionHandler(status: "success")
            }
            else {
                completionHandler(status: "failure")
            }
            
        case .SaturatedFat:
            let value = saturated * selectedUnit.conversionValue
            if value.roundPlaces() < 100000 {
                saturated = value.roundPlaces(2)
                completionHandler(status: "success")
            }
            else {
                completionHandler(status: "failure")
            }
            
        case .Monosaturated:
            let value = monosaturated * selectedUnit.conversionValue
            if value.roundPlaces() < 100000 {
                monosaturated = value.roundPlaces(2)
                completionHandler(status: "success")
            }
            else {
                completionHandler(status: "failure")
            }
            
        case .Polyunsaturated:
            let value = polyunsaturated * selectedUnit.conversionValue
            if value.roundPlaces() < 100000 {
                polyunsaturated = value.roundPlaces(2)
                completionHandler(status: "success")
            }
            else {
                completionHandler(status: "failure")
            }
            
        case .TransFat:
            let value = trans * selectedUnit.conversionValue
            if value.roundPlaces() < 100000 {
                trans = value.roundPlaces(2)
                completionHandler(status: "success")
            }
            else {
                completionHandler(status: "failure")
            }
            
        case .Cholestreol:
            let value = cholesterol * selectedUnit.conversionValue
            if value.roundPlaces() < 100000 {
                cholesterol = value.roundPlaces(2)
                completionHandler(status: "success")
            }
            else {
                completionHandler(status: "failure")
            }
            
        case .Sodium:
            let value = sodium * selectedUnit.conversionValue
            if value.roundPlaces() < 100000 {
                sodium = value.roundPlaces(2)
                completionHandler(status: "success")
            }
            else {
                completionHandler(status: "failure")
            }
            
        case .Fiber:
            let value = fiber * selectedUnit.conversionValue
            if value.roundPlaces() < 100000 {
                fiber = value.roundPlaces(2)
                completionHandler(status: "success")
            }
            else {
                completionHandler(status: "failure")
            }
            
        default: break
            
        }
        
        escapeNaNs()
    }
    
    func updateServingSize(value: Double) {
        
        if value <= 0 { return }
        
        let ratio = value / servingSize
        
        protein = protein * ratio
        carbohydrates = carbohydrates * ratio
        fat = fat * ratio
        
        calories = (protein * 4) + (fat * 9) + (carbohydrates * 4)
        fiber = (14 / 1000) * calories
        
        servingSize = value
        
        escapeNaNs()
    }
    
    
    func resetNutritionToDefualtServings(oldServing : Double) {
        
        
        
        let ratio =  numberOfServings
        
        calories = calories * ratio
        carbohydrates = carbohydrates * ratio
        protein = protein * ratio
        fat = fat * ratio
        fiber = fiber * ratio
        saturated = saturated * ratio
        polyunsaturated = polyunsaturated * ratio
        monosaturated = monosaturated * ratio
        trans = trans * ratio
        cholesterol = cholesterol * ratio
        sodium = sodium * ratio
        potassium = potassium * ratio
        
        
        
        escapeNaNs()
    }
    
    
    func updateNumberOfServings(value: Double) {
        
        if value <= 0 { return }
        
        let ratio = value / numberOfServings
        
        calories = calories * ratio
        carbohydrates = carbohydrates * ratio
        protein = protein * ratio
        fat = fat * ratio
        fiber = fiber * ratio
        saturated = saturated * ratio
        polyunsaturated = polyunsaturated * ratio
        monosaturated = monosaturated * ratio
        trans = trans * ratio
        cholesterol = cholesterol * ratio
        sodium = sodium * ratio
        potassium = potassium * ratio
        
        numberOfServings = value
        
        escapeNaNs()
    }
    
    
    
    
    
    
    func updateCalories(value: Double, shouldUpdateMacros: Bool = true) {
        
        if value <= 0 { return }
        
        let ratio = value / calories
        
        if shouldUpdateMacros {
            protein = protein * ratio
            fat = fat * ratio
            carbohydrates = carbohydrates * ratio
        }
        
        fiber = (14 / 1000) * value
        
        servingSize = servingSize * ratio
        
        calories = value
        
        escapeNaNs()
    }
    
    func updateCarbohydrates(value: Double) {
        
        if value <= 0 { return }
        
        carbohydrates = value
        updateCalories((protein * 4) + (fat * 9) + (carbohydrates * 4), shouldUpdateMacros: false)
        
        escapeNaNs()
    }
    
    func updateProteins(value: Double) {
        
        if value <= 0 { return }
        
        protein = value
        updateCalories((protein * 4) + (fat * 9) + (carbohydrates * 4), shouldUpdateMacros: false)
        
        escapeNaNs()
    }
    
    func updateFats(value: Double) {
        
        if value <= 0 { return }
        
        fat = value
        updateCalories((protein * 4) + (fat * 9) + (carbohydrates * 4), shouldUpdateMacros: false)
        
        escapeNaNs()
    }
    
    func updateFiber(value: Double) {
        updateCalories((1000 / 14) * value)
    }
    
    func escapeNaNs() {
        
        servingSize = servingSize.isFinite ? servingSize : 0
        
        calories = calories.isFinite ? calories : 0
        fiber = fiber.isFinite ? fiber : 0
        
        carbohydrates = carbohydrates.isFinite ? carbohydrates : 0
        protein = protein.isFinite ? protein : 0
        fat = fat.isFinite ? fat : 0
        
        saturated = saturated.isFinite ? saturated : 0
        polyunsaturated = polyunsaturated.isFinite ? polyunsaturated : 0
        monosaturated = monosaturated.isFinite ? monosaturated : 0
        trans = trans.isFinite ? trans : 0
        cholesterol = cholesterol.isFinite ? cholesterol : 0
        sodium = sodium.isFinite ? sodium : 0
        potassium = potassium.isFinite ? potassium : 0
    }
    
    func toDictionary() -> [String: String] {
        return ["food_id": guid,
                "food_name": name,
                "food_brand_name": brandName,
                "food_serving_size": "\(servingSize)",
                "food_serving_no": "\(numberOfServings)",
                "food_unit": unit,
                "food_calorie": "\(calories)",
                "food_fibre": "\(fiber)",
                "food_fat": "\(fat)",
                "food_carb": "\(carbohydrates)",
                "food_protein": "\(protein)",
                "food_saturated": "\(saturated)",
                "food_polyunsaturated": "\(polyunsaturated)",
                "food_monosaturated": "\(monosaturated)",
                "food_trans": "\(trans)",
                "food_cholestrol": "\(cholesterol)",
                "food_sodium": "\(sodium)",
                "food_pottassium": "\(potassium)"]
    }
    
    func toDailyMealPlanFoodDictionary() -> [String: String] {
        return ["food_id": guid,
                "food_name": name,
                "food_brand_name": brandName,
                "food_meal_type": "\(mealType.id)",
                "fym_dmp_type": dailyMealType.dailyMealTypeName,
                "food_serving_size": "\(servingSize)",
                "food_serving_no": "\(numberOfServings)",
                "food_unit": unit,
                "food_calorie": "\(calories * servingSize)",
                "food_fibre": "\(fiber * servingSize)",
                "food_fat": "\(fat * servingSize)",
                "food_carb": "\(carbohydrates * servingSize)",
                "food_protein": "\(protein * servingSize)",
                "food_saturated": "\(saturated)",
                "food_polyunsaturated": "\(polyunsaturated)",
                "food_monosaturated": "\(monosaturated)",
                "food_trans": "\(trans)",
                "food_cholestrol": "\(cholesterol * servingSize)",
                "food_sodium": "\(sodium * servingSize)",
                "food_pottassium": "\(potassium * servingSize)"]
    }
    
    class func showAlert(error: NSError?) {
        
        // no need to handle errors if we dont have any :)
        if error == nil { return }
        
        // get the tile and message for the alert
        if let userInfo = error?.userInfo {
            let title = userInfo["title"] as! String
            let message = userInfo["message"] as! String
            
            // show alert
            UIAlertView(title: &&title, message: &&message, delegate: nil, cancelButtonTitle: &&"cancel").show()
        }
    }
    
    func split(percentage: Int) -> Food {
        let splittedFood = Food()
        
        splittedFood.id = id
        splittedFood.guid = guid
        splittedFood.name = name
        splittedFood.brandName = brandName
        
        splittedFood.servingSize = servingSize
        splittedFood.unit = unit
        
        splittedFood.calories = calories
        splittedFood.carbohydrates = carbohydrates
        splittedFood.protein = protein
        splittedFood.fat = fat
        splittedFood.fiber = fiber
        splittedFood.saturated = saturated
        splittedFood.polyunsaturated = polyunsaturated
        splittedFood.monosaturated = monosaturated
        splittedFood.trans = trans
        splittedFood.cholesterol = cholesterol
        splittedFood.sodium = sodium
        splittedFood.potassium = potassium
        
        splittedFood.numberOfServings = numberOfServings
        
        splittedFood.updateNumberOfServings(numberOfServings * (Double(percentage) / 100.0))
        
        return splittedFood
    }
    
    class func fetchFoods(searchKey: String = "", foodType: String = "", mealType: Int = -1,searchType: String = "meal_search", offset: Int? = nil, limit: Int? = nil, shouldShowHUD: Bool = true, completionHandler: (foods: [Food]) -> ()) {
        
        // prepare params
        var params = [String: String]()
        params["search_type"] = searchType
        if !searchKey.isEmpty {
            params["keyword"] = searchKey
        }
        if !foodType.isEmpty {
            params["meal_category"] = foodType
        }
        if mealType >= 0 {
            params["meal_type"] = "\(mealType)"
        }
        if offset != nil {
            params["offset"] = "\(offset!)"
        }
        if limit != nil {
            params["limit"] = "\(limit!)"
        }
        
        // append language
        params["locale"] = "\(NSLocale.currentLocale().objectForKey(NSLocaleLanguageCode)!)"
        
        if shouldShowHUD { SVProgressHUD.show() }
        
        FoodListResponse.fetchFoodList(params) { (foods, error) in
            
            if shouldShowHUD { SVProgressHUD.dismiss() }
            
            Food.showAlert(error)
            
            completionHandler(foods: foods)
        }
    }
    
    func logFood(mealType: Int = -1, mealDate: NSDate = NSDate(), userGuid: String = "", completionHandler:(error: NSError?) -> ()) {
        
        // food (put the food inside an array for the sake of api)
        let food = [toDictionary()]
        
        // user (only one user here, there may be multiple users for split food)
        let user = ["user_id": userGuid,
                    "approve": "Yes",
                    "food_details": food]
        
        // users (put the user inside an array for the sake of api)
        let users = [user]
        
        // prepare params to post
        let params = ["log_type": LogType.Log.rawValue,
                      "meal_type": mealType,
                      "meal_date": mealDate.stringValue("yyyy-MM-dd"),
                      "users": users]
        
        SVProgressHUD.show()
        
        LogFoodResponse.logFood(params as! [String : AnyObject]) { (error) in
            
            SVProgressHUD.dismiss()
            
            // handle errors
            Food.showAlert(error)
            
            // fire completion handler
            completionHandler(error: error)
        }
    }
    
    func logDailyMealPlanFood(mealType: Int = 1, mealDate: NSDate = NSDate(), mealFoods: [Food] = [Food](), userGuid: String = "", completionHandler:(error: NSError?) -> ()) {
        
        // food (put the food inside an array for the sake of api)
        let food = mealFoods.map {$0.toDailyMealPlanFoodDictionary()}//[toDailyMealPlanFoodDictionary()]
        
        // user (only one user here, there may be multiple users for split food)
        //        let user = ["user_id": userGuid,
        //            "approve": "Yes",
        //            "food_details": food]
        
        let users = food.map() {
            return ["user_id": userGuid,
                "approve": "Yes",
                "food_details": [$0]]
        }
        
        
        // users (put the user inside an array for the sake of api)
        //        let users = [user]
        
        // prepare params to post
        let params = ["log_type": LogType.Log.rawValue,
                      "meal_type": mealType,
                      "meal_date": mealDate.stringValue("yyyy-MM-dd"),
                      "users": users]
        
        SVProgressHUD.show()
        
        LogFoodResponse.logFood(params as! [String : AnyObject]) { (error) in
            
            SVProgressHUD.dismiss()
            
            // handle errors
            Food.showAlert(error)
            
            // fire completion handler
            completionHandler(error: error)
        }
    }
    
    
    func copyFood(mealType: Int = -1, mealDate: NSDate = NSDate(), userGuid: String = "", completionHandler:(error: NSError?) -> ()) {
        
        // food (put the food inside an array for the sake of api)
        let food = [toDictionary()]
        
        // user (only one user here, there may be multiple users for split food)
        let user = ["user_id": userGuid,
                    "approve": "Yes",
                    "food_details": food]
        
        // users (put the user inside an array for the sake of api)
        let users = [user]
        
        // prepare params to post
        let params = ["log_type": LogType.Copy.rawValue,
                      "meal_type": mealType,
                      "meal_date": mealDate.stringValue("yyyy-MM-dd"),
                      "users": users]
        
        SVProgressHUD.show()
        
        LogFoodResponse.logFood(params as! [String : AnyObject]) { (error) in
            
            SVProgressHUD.dismiss()
            
            // handle errors
            Food.showAlert(error)
            
            // fire completion handler
            completionHandler(error: error)
        }
    }
    
    func sendDetails(shouldLog: Bool = false, mealType: Int = -1, mealDate: NSDate = NSDate(), userGuid: String = "", users: [String] = [], completionHandler:(error: NSError?) -> ()) {
        
        // food (put the food inside an array for the sake of api)
        let food = [toDictionary()]
        
        // current user
        let currentUser = ["user_id": userGuid,
                           "approve": "Yes",
                           "food_details": food]
        
        // create user dictionaries
        var otherUsers = users.map { ["user_id": $0, "approve": "No", "food_details": food] }
        
        // add current user if log and send
        if shouldLog { otherUsers += [currentUser] }
        
        // prepare params to post
        let params = ["log_type": LogType.Send.rawValue,
                      "meal_type": mealType,
                      "meal_date": mealDate.stringValue("yyyy-MM-dd"),
                      "users": otherUsers]
        
        SVProgressHUD.show()
        
        LogFoodResponse.logFood(params as! [String : AnyObject]) { (error) in
            
            SVProgressHUD.dismiss()
            
            // handle errors
            Food.showAlert(error)
            
            // fire completion handler
            completionHandler(error: error)
        }
    }
    
    func split(mealType: Int = -1, mealDate: NSDate = NSDate(), userGuid: String = "", splittedUsers: [User: Int], completionHandler:(error: NSError?) -> ()) {
        
        // create user dictionaries
        let splittedUserData = Array(splittedUsers.keys).map { ["user_id": $0.userId, "approve": $0.userId == userGuid ? "Yes" : "No", "food_details": [self.split(splittedUsers[$0]!).toDictionary()]] }
        
        // prepare params to post
        let params = ["log_type": LogType.Split.rawValue,
                      "meal_type": mealType,
                      "meal_date": mealDate.stringValue("yyyy-MM-dd"),
                      "users": splittedUserData]
        
        SVProgressHUD.show()
        
        LogFoodResponse.logFood(params as! [String : AnyObject]) { (error) in
            
            SVProgressHUD.dismiss()
            
            // handle errors
            Food.showAlert(error)
            
            // fire completion handler
            completionHandler(error: error)
        }
    }
    
    class func fetchFoodLogs(offset: String,date: NSDate, showHUD: Bool = false, completionHandler: (loggedFoods: [Food]) -> ()) {
        
        if showHUD {
            SVProgressHUD.show()
        }
        
        ListLogFoodResponse.fetchFoodLogList(offset, date: date) { (foodLogList, error) -> () in
            
            if showHUD {
                
                SVProgressHUD.dismiss()
                
            }
            Food.showAlert(error)
            
            
            if error == nil {
                completionHandler(loggedFoods: foodLogList)
            }
        }
        
    }
    
    class func fetchBarcodeFood(barcode: String = "4113", completionHandler: (food: Food?, error: String?) -> ()) {
        
        SVProgressHUD.show()
        
        FoodDetailResponse.fetchBarcodeFood(barcode) { (food, error) -> () in
            
            SVProgressHUD.dismiss()
            
            completionHandler(food: food, error: error)
        }
    }
    
    func updateFoodLog(mealType: Int = -1, completionHandler: (error: NSError?) -> ()) {
        
        let params = mealType < 0 ? toDictionary() : ["meal_type": "\(mealType)"]
        
        UpdateFoodLogResponse.updateFoodLog(id, params: params) { (error) -> () in
            completionHandler(error: error)
        }
    }
    
    func deleteFood(completionHandler: (deletedStatus: Bool) -> ()) {
        //delete the food
        DeletFoodLogResponse.deleteFood(id, completionHandler: { (deletedStatus) -> () in
            completionHandler(deletedStatus: deletedStatus)
        })
    }
    
    func changeShareStatus(completionHandler: (changedStatus: Bool) -> ()) {
        ChangeShareStatusFoodLogResponse.changeStatus(id, status: approve) { (changedStatus) -> () in
            completionHandler(changedStatus: changedStatus)
        }
    }
    
    func createFood(completionHandler: (food: Food, meta: MetaModel) -> ()) {
        
        var category = [[String: String]]()
        
        for foodCategory in foodCategories {
            if let id = foodCategory.id {
                category.append(["id": id])
            }
        }
        
        let params = ["brand_name": brandName,
                      "name": name,
                      "serving_size": "\(servingSize)",
                      "serving_size_unit": unit,
                      "serving_per_container": "1",
                      "calories": "\(calories)",
                      "fat": "\(fat)",
                      "saturated": "\(saturated)",
                      "polyunsaturated": "\(polyunsaturated)",
                      "monosaturated": "\(monosaturated)",
                      "trans": "\(trans)",
                      "cholestrol": "\(cholesterol)",
                      "sodium": "\(sodium)",
                      "pottassium": "\(potassium)",
                      "carbohydrates": "\(carbohydrates)",
                      "fiber": "\(fiber)",
                      "protien": "\(protein)",
                      "locale": "\(NSLocale.currentLocale().objectForKey(NSLocaleLanguageCode)!)",
                      "category": category
        ]
        
        SVProgressHUD.show()
        
        CreateMealPostResponse.createFood(params as! [String : AnyObject]) { (food,meta) -> () in
            
            SVProgressHUD.dismiss()
            
            completionHandler(food: food, meta: meta)
        }
    }
    //    
    //    //daily meal plan
    //    class func fetchFoodDailyMeal(coremealNo: String, snackNo: String, calories: String, carbs: String, proteins: String, fats: String, showHUD: Bool = false, completionHandler: (loggedFoods: [Food]) -> ()) {
    //        
    //        if showHUD {
    //            SVProgressHUD.show()
    //        }
    //        
    //        DailyMealPlanAutoSuggestResponse.fetchSuggestedFoodList(coremealNo, snackNo: snackNo, calories: calories, carbs: carbs, proteins: proteins, fats: fats) { (foodLogList, error) -> () in
    //            
    //            if showHUD {
    //                
    //                SVProgressHUD.dismiss()
    //                
    //            }
    //            Food.showAlert(error)
    //            
    //            
    //            if error == nil {
    //                completionHandler(loggedFoods: foodLogList)
    //            }
    //        }
    //    }
    //    
    //    class func fetchRefreshedItemInMealPlan(mealType: String, genre: String, calories: String, carbs: String, proteins: String, fats: String, showHUD: Bool = false, completionHandler: (loggedFoods: [Food]) -> ()) {
    //        
    //        if showHUD {
    //            SVProgressHUD.show()
    //        }
    //        
    //        
    //        DailyMealPlanItemRefreshResponse.fetchRefreshFoodItem(mealType, genre: genre, calories: calories, carbs: carbs, proteins: proteins, fats: fats) { (foodLogList, error) -> () in
    //            
    //            if showHUD {
    //                
    //                SVProgressHUD.dismiss()
    //                
    //            }
    //            Food.showAlert(error)
    //            
    //            
    //            if error == nil {
    //                completionHandler(loggedFoods: foodLogList)
    //            }
    //
    //        }
    //    }
    
    
}

func ==(lhs: Food, rhs: Food) -> Bool {
    return (lhs.id == rhs.id)
}

