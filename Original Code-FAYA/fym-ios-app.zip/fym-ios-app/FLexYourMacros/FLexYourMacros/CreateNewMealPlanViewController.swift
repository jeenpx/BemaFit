//
//  CreateNewMealPlanViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 11/17/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class CreateNewMealPlanViewController: UIViewController, UITextFieldDelegate {
    
    
    @IBOutlet weak var buttonSave: UIBarButtonItem!
    var mealPlanId: String?
    var dailyMealPlan =  DailyMealPlan.sharedDailyMealPlan
    var pageMode = mealPlanDetailPageMode.newMealPlan
    
    @IBOutlet weak var textFieldTitleMealPlan: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        if pageMode == mealPlanDetailPageMode.editingMealPlan {
            textFieldTitleMealPlan.text = dailyMealPlan.dailyMealPlanName
           
        }
        
         self.buttonSave.enabled = textFieldTitleMealPlan.text != ""
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @IBAction func textFieldEdited(sender: UITextField) {
        
        self.buttonSave.enabled = sender.text != ""
    }
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        let newLength = textField.text!.utf16.count + string.utf16.count - range.length
        return newLength <= 20 // Bool
    }
    
    
    func textFieldDidBeginEditing(textField: UITextField) {
        
    }
    
    @IBAction func buttonActionSaveMealPlan(sender: UIBarButtonItem) {
        
        if textFieldTitleMealPlan.isEmpty {
            
            return
        }
        
        
        dailyMealPlan.dailyMealPlanName = textFieldTitleMealPlan.text!
        
        
        if pageMode == mealPlanDetailPageMode.editingMealPlan {
            
            // update meal plan
            //print("update meal plan---\( dailyMealPlan.dailyMealPlanName)")
            dailyMealPlan.updateMealPlan(dailyMealPlan.dailyMealPlanId, completionHandler: { (error) -> () in
                
                DailyMealPlan.resetSharedInstance()
                let notification = NSNotification(name: Constants.updateDailyMealList, object: nil)
                NSNotificationCenter.defaultCenter().postNotification(notification)
                
                self.refreshControllers()
            })
            return;
        }
        
        
        dailyMealPlan.createNewMealPlan({ (error) -> () in
            
            DailyMealPlan.resetSharedInstance()
            let notification = NSNotification(name: Constants.updateDailyMealList, object: nil)
            NSNotificationCenter.defaultCenter().postNotification(notification)
            self.refreshControllers()
            
        })
        
        
    }
    
    func refreshControllers(){
        if let viewControllers = self.navigationController?.viewControllers {
            for viewController in viewControllers {
                // some process
                if viewController.isKindOfClass(DailyMealPlanViewController) {
                    self.navigationController?.popToViewController(viewController, animated: true)
                    
                }
            }
        }
    }
    
}
