//
//  MacroPerReportingPeriod.swift
//  FlexYourMacros
//
//  Created by mini on 20/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import CoreData
@objc(MacroPerReportingPeriod)

class MacroPerReportingPeriod: NSManagedObject {

    @NSManaged var calories_total: String
    @NSManaged var carbs_total: String
    @NSManaged var fat_total: String
    @NSManaged var fiber_total: String
    @NSManaged var protein_total: String
    @NSManaged var progress_type_reporting_period: Progress

    class var entityMapping : RKEntityMapping {
        
        var progressLogMapping: RKEntityMapping = RKEntityMapping(forEntityForName: Constants.Tables.MacroPerReportingPeriod, inManagedObjectStore: RestKitManager.sharedManager().managedObjectStore)
        progressLogMapping .addAttributeMappingsFromDictionary(progressMappingDictionary)
        
        return progressLogMapping
    }
    
    private class var progressMappingDictionary: [String : String] {
        
        return(["protein_total":"protein_total", "fat_total":"fat_total", "carbs_total":"carbs_total", "fiber_total":"fiber_total", "calories_total":"calories_total"])
    }
    
    class func fetchMacroPerReportingPeriod(progressType: String, completionHandler:(macroDetails: [AnyObject])->()) {
        
        var error: NSError?
        let fetchRequest = NSFetchRequest()
        let entity = NSEntityDescription.entityForName(Constants.Tables.MacroPerReportingPeriod, inManagedObjectContext: RKObjectManager.sharedManager().managedObjectStore.persistentStoreManagedObjectContext)
        fetchRequest.returnsObjectsAsFaults = false
        fetchRequest.entity = entity
//        fetchRequest.fetchLimit = 1
        
        // set the predicate
        let progressPredicate = NSPredicate(format: "progress_type_reporting_period.type = %@",progressType)
        fetchRequest.predicate = progressPredicate
        
        
        let fetchedObjects: [AnyObject]?
        do {
            fetchedObjects = try RKObjectManager.sharedManager().managedObjectStore.persistentStoreManagedObjectContext .executeFetchRequest(fetchRequest)
        } catch var error1 as NSError {
            error = error1
            fetchedObjects = nil
        }
        completionHandler(macroDetails: fetchedObjects!)
    }
}
