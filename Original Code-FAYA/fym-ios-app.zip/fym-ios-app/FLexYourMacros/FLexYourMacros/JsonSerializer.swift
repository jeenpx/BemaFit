//
//  JsonSerializer.swift
//  FlexYourMacros
//
//  Created by mini on 29/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation


public class JsonSerializer : NSObject{
    // http://stackoverflow.com/questions/27989094/how-to-unwrap-an-optional-value-from-any-type
    func unwrap(any:Any) -> Any? {
        let mi = Mirror(reflecting: any)
        if mi.displayStyle != .Optional {
            return any
        }
        
        // Optional.None
        if mi.children.count == 0 {
            return nil
        }
        
        let (_,some) = mi.children.first!
        return some
    }
    
    public func toDictionary() -> NSDictionary {
        let propertiesDictionary = NSMutableDictionary()
        let mirror = Mirror(reflecting: self)
        for object in mirror.children {
            let (propName, childMirror) = object
            if let propValue:AnyObject = unwrap(childMirror) as? AnyObject {
                if let serializeablePropValue = propValue as? JsonSerializer {
                    propertiesDictionary.setValue(serializeablePropValue.toDictionary(), forKey: propName!)
                } else if let arrayPropValue = propValue as? Array<JsonSerializer> {
                    var subArray = Array<NSDictionary>()
                    for item in arrayPropValue {
                        subArray.append(item.toDictionary())
                    }
                    propertiesDictionary.setValue(subArray, forKey: propName!)
                } else if propValue is Int || propValue is Double || propValue is Float {
                    propertiesDictionary.setValue(propValue, forKey: propName!)
                } else if let dataPropValue = propValue as? NSData {
                    propertiesDictionary.setValue(dataPropValue.base64EncodedStringWithOptions([]), forKey: propName!)
                } else if let boolPropValue = propValue as? Bool {
                    propertiesDictionary.setValue(boolPropValue.boolValue, forKey: propName!)
                } else {
                    propertiesDictionary.setValue(propValue, forKey: propName!)
                }
            }
        }
        
        return propertiesDictionary
    }
    
    public func toJson() -> NSData {
        var dictionary = self.toDictionary()
        
        var err: NSError?
        do {
            let json = try NSJSONSerialization.dataWithJSONObject(dictionary, options:NSJSONWritingOptions(rawValue: 0))
            return json
        } catch var error1 as NSError {
            err = error1
            let error = err?.description ?? "nil"
            NSLog("ERROR: Unable to serialize json, error: %@", error)
            NSNotificationCenter.defaultCenter().postNotificationName("CrashlyticsLogNotification", object: self, userInfo: ["string": "unable to serialize json, error: \(error)"])
            abort()
        }
    }
    
    public func toJsonString() -> NSString! {
        return NSString(data: self.toJson(), encoding: NSUTF8StringEncoding)
    }
    
}
