//
//  PdfManager1.swift
//  SuccessHtmlToPdf
//
//  Created by DBG on 03/12/15.
//  Copyright © 2015 dbg. All rights reserved.

import Foundation


class PdfManager:NSObject{
    
    var PDFCreator: NDHTMLtoPDF = NDHTMLtoPDF()
    
    var vw:UIViewController = UIViewController()
    var html = "<html><body style=\" font-family:'arial'; \"><Center><H3>FYM Daily Meal Plan </H3></Center>"
    var body:String = "<table border='0' cellpadding='1' cellspacing='1' style='width:100% ;background-color: #eee';>"
    // var body:NSString = "<html><body><table border='1' style='width:100%'>"
    
    // set caption
    func setCaption(title:String)->String{
        self.body = body + "<caption>"
        self.body = body + title
        self.body = body + "</caption>"
        return self.body
    }
    func addText(title:String)->String{
        self.html = html + title
        
        return self.html
    }
    
    //Table header formation
    func createHeaderTags(headers:[String])->(String){
        body = body + "<tr style = 'background-color: darkgrey; color: black; text-align:left;' >"
        for (var i:Int=0; i<headers.count ; i++) {
            self.body = body + "<th>"
            self.body = body + headers[i]
            self.body = body + "</th>"
        }
        return self.body
    }
    
    func drawLine()->(String){
        //colspan:  here 9 columns
        var s:String = "<tr><td colspan='9' ><hr style='color:darkgrey'></td></tr>"
        self.body = self.body + s
        return self.body
    }
    
    
    
    // creates the row
    func createSingleRowItem(rowArray:[String])->(String){
        var rowItem:String = "<tr>"
        // rows
        for (var i=0;i<rowArray.count;i++) {
            rowItem = rowItem + self.addRowItem(rowArray[i])
        }
        self.body = self.body + rowItem
        self.body = self.body + "</tr>"
        // self.toHtml()
        return self.body
    }
    
    func createSingleRowItemWithStyle(rowArray:[String],cssStyle : String = "")->(String){
        var rowItem:String = "<tr style='\(cssStyle)'>"
        // rows
        for (var i=0;i<rowArray.count;i++) {
            rowItem = rowItem + self.addRowItem(rowArray[i])
        }
        self.body = self.body + rowItem
        self.body = self.body + "</tr>"
        // self.toHtml()
        return self.body
    }
    
    
    
    
    // add each items in the row
    func addRowItem(item :String)->String {
        var str: String = " "
        str = str + "<td>\(item)</td>"
        return str
    }
    
    // //print the html string
    func toHtml() -> String{
        let fullHtml  = self.html + self.body + "</tr></table>" + "</body></html>"
        
        return fullHtml
    }
    
    // create pdf file
    func createPdfWithFileName(fileName:String ,completion: (pdfManager : PdfManager,result: String) -> Void)-> () {
        
        // var s = EmailManager(vController: vw)
        let pdfContent  = self.toHtml()
        let file = fileName //this is the file. we will write to and read from it
        
        if let dir : NSString = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.AllDomainsMask, true).first {
            let path = dir.stringByAppendingPathComponent(file);
            //(595.2,841.8)
            //(1751.0,2479.0)
            self.PDFCreator = NDHTMLtoPDF.createPDFWithHTML(pdfContent, pathForPDF: path, pageSize: CGSizeMake(595.2,841.8), margins: UIEdgeInsetsMake(10, 5, 10, 5), successBlock: { (NDHTMLtoPDF) -> Void in
                
                completion(pdfManager: self,result: "success")
                //print("\(NDHTMLtoPDF.PDFpath)")
                }, errorBlock: { (NDHTMLtoPDF) -> Void in
                    //print("error")
                    completion(pdfManager: self,result: "error")
            })as! NDHTMLtoPDF
        }
        
    }
    
}