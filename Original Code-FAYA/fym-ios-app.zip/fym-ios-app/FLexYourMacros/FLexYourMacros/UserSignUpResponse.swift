//
//  UserSignUpResponse.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 14/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _UserSignUpResponse = UserSignUpResponse()

class UserSignUpResponse: NSObject {
    
    var accessTokenModel: AccessTokenModel?
    var userDetailModel: UserDetailModel?
    var userDietModel: UserDietModel?
    var metaModel: MetaModel?
    
    class var sharedUserSignUpResponse: UserSignUpResponse {
        return _UserSignUpResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(UserSignUpResponse.metaModelKeyMapping)
        
        // give reference to diet mapping
        responseMapping.addPropertyMapping(UserSignUpResponse.userDietModelKeyMapping)
        
        // give reference to user credential mapping
        responseMapping.addPropertyMapping(UserSignUpResponse.userDetailModelKeyMapping)
        
        // give reference to accesstoken mapping
//        responseMapping.addPropertyMapping(UserSignUpResponse.accessTokenModelKeyMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.signUpUserUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var userDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDetail, toKeyPath: "userDetailModel", withMapping: UserDetailModel.objectMapping)
    }
    
    private class var userDietModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDiet, toKeyPath: "userDietModel", withMapping: UserDietModel.objectMapping)
    }
    
    private class var accessTokenModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathAccessToken, toKeyPath: "accessTokenModel", withMapping: AccessTokenModel.objectMapping)
    }
    
    class var parameterDictionary: [String:String] {
        
        let fymUserModel = FymUser.sharedFymUser
        
        var dictionary = [String:String]()
        dictionary["user_name"] = fymUserModel.userUserName
        dictionary["first_name"] = fymUserModel.userFirstName
        dictionary["last_name"] = fymUserModel.userLastName
        dictionary["email"] = fymUserModel.userEmail
        dictionary["password"] = fymUserModel.userPassword
        dictionary["website"] = fymUserModel.userWebsite
        dictionary["gender"] = fymUserModel.userGender
        dictionary["dob"] = fymUserModel.userDobString
        dictionary["facebook_access_token"] = AppConfiguration.sharedAppConfiguration.isFacebookUser == true ? UserFacebookCredentialModel.sharedUserFacebookCredentialModel.userFbAccessToken : ""
        dictionary["height"] = fymUserModel.userHeightinCm
        dictionary["weight"] = fymUserModel.userWeight
        dictionary["fat"] = fymUserModel.userFatLoss
        dictionary["diet_activity_level"] = fymUserModel.userActivityLevelId
        dictionary["diet_goal_calories"] = String(format: "%.2f", fymUserModel.getTheSelectedGoalCalorie()) as String
        dictionary["diet_nutritional_plan"] = fymUserModel.userNutritionType
        dictionary["diet_formula"] = fymUserModel.formulaType
        dictionary["diet_calory_type"] = fymUserModel.userSelectedGoal?.goalId == "4" ? "custom" : "calculated"
        dictionary["diet_goal_option"] = fymUserModel.userGoalOptionId
        dictionary["diet_macro_type"] = fymUserModel.userNutritionType == "5" ? "custom" : "calculated"
        dictionary["diet_macro_fiber"] = getTheOptimizedString(fymUserModel.userFiberValue)
        dictionary["diet_macro_fat"] = getTheOptimizedString(fymUserModel.userFat)
        dictionary["diet_macro_carbs"] = getTheOptimizedString(fymUserModel.userCarbs)
        dictionary["diet_macro_protein"] = getTheOptimizedString(fymUserModel.userProtein)
        dictionary["no_of_meals"]   = String(fymUserModel.userNumberOfMeals)
        return dictionary
    }
    
    
    class func getTheOptimizedString(objectString: String) -> (String) {
        
        return objectString.stringByReplacingOccurrencesOfString("g", withString: "", options: NSStringCompareOptions.LiteralSearch, range: nil) as String
    }
    
    class func signUpUser(viewController: UIViewController,completionHandler: (userDetails: UserDetailModel, userDiet: UserDietModel) -> (), failure: (failed: String) -> ()) {

        // add loading indicator
//        MBProgressHUD.showHUDAddedTo(viewController.view, animated: true)
        SVProgressHUD.show()

        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(nil, method: .POST, path: Constants.ServiceConstants.signUpUserUrl, parameters: parameterDictionary, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            if FymUser.sharedFymUser.userImage != nil {
                formData.appendPartWithFileData(UIImageJPEGRepresentation(FymUser.sharedFymUser.userImage!, 0.0), name :"photo", fileName :"photo.jpg", mimeType :"image/jpeg") }
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            // remove loading indicator
//            MBProgressHUD.hideHUDForView(viewController.view, animated: true)
            SVProgressHUD.dismiss()

            
            let userSignUpResponse = mappingResult.firstObject as! UserSignUpResponse

            if userSignUpResponse.metaModel?.responseCode != 200 || userSignUpResponse.metaModel?.responseStatus == "failed" {
               
                var errorMessage = userSignUpResponse.metaModel?.message ?? ""
                let errorMessages = userSignUpResponse.metaModel?.errormessages ?? []
                if errorMessages.isEmpty {
                    
                } else {
                    
                    errorMessage = errorMessages.first?.fieldMessage ?? ""
                }
                failure(failed: errorMessage)
                return 
            }

            completionHandler(userDetails: userSignUpResponse.userDetailModel!, userDiet: userSignUpResponse.userDietModel!)
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                // remove loading indicator
//                MBProgressHUD.hideHUDForView(viewController.view, animated: true)
                SVProgressHUD.dismiss()


             //print("failed to load signup with error \(error)")
                failure(failed: error.localizedDescription)
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
    
    
}