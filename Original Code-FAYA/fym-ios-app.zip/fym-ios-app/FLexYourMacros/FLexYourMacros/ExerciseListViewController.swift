//
//  ExerciseListViewController.swift
//  FlexYourMacros
//
//  Created by mini on 25/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

//import Foundation
import UIKit

class ExerciseTableViewCell: UITableViewCell {
    
    @IBOutlet weak var labelExerciseAmount: UILabel!
    @IBOutlet weak var labelExerciseName: UILabel!
    
    @IBOutlet weak var labelTimeHeight: NSLayoutConstraint!
    var exercise: Exercise = Exercise(name: "") {
        didSet {
            labelExerciseName.text = exercise.name
            if exercise.caloriesPerMinute.doubleValue == 0.0 {
                labelExerciseAmount.hidden = true
                labelTimeHeight.constant = 0
            } else {
                labelExerciseAmount.hidden = false
                labelTimeHeight.constant = 19

                labelExerciseAmount.text = exercise.caloriesPerMinute + " " + &&"calories_burned_per_minute"

            }
        }
    }
}

// MARK: empty tableview cell
protocol ExerciseTableViewFooterCellDelegate {
    func exerciseTableViewFooterCell(exerciseTableViewFooterCell: ExerciseTableViewFooterCell, didTappedOnLoadMore selected: Bool)
}
class ExerciseTableViewFooterCell: UITableViewCell {

    @IBOutlet weak var labelLoadMore: UILabel!
    
    var exerciseTableViewFooterCellDelegate: ExerciseTableViewFooterCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        // to configure the view
        configureView()
    }
    
    func configureView() {
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "loadMoreTapped:")
        labelLoadMore.userInteractionEnabled = true
        labelLoadMore.addGestureRecognizer(tapGesture)
    }
    
    func loadMoreTapped(tapGestureRecognizer: UITapGestureRecognizer) {
        
        exerciseTableViewFooterCellDelegate?.exerciseTableViewFooterCell(self, didTappedOnLoadMore: true)
    }
}

// MARK: empty tableview cell
protocol EmptyExerciseTableViewCellDelegate {
    func emptyExerciseTableViewCell(emptyExerciseTableViewCell: EmptyExerciseTableViewCell, didSelectCreateCustom selected: Bool)
}

class EmptyExerciseTableViewCell: UITableViewCell {
    
    var emptyExerciseTableViewCellDelegate: EmptyExerciseTableViewCellDelegate?
    
    @IBAction func buttonActionCreateCustom(sender: UIButton) {
        emptyExerciseTableViewCellDelegate?.emptyExerciseTableViewCell(self, didSelectCreateCustom: true)
    }
}


// MARK: exercise type listing view controller

class ExerciseListViewController: UITableViewController, UISearchBarDelegate, EmptyExerciseTableViewCellDelegate, UITableViewDragLoadDelegate, UIGestureRecognizerDelegate {
    
    @IBOutlet weak var searchTextBar: UISearchBar!
    var offscreenCells = [String: ExerciseTableViewCell]()

    struct StoryBoard {
        
        struct CellIdentifiers {
            static let ExerciseTableViewCell = "kExerciseCell"
            static let EmptyExerciseTableViewCell = "kEmptyExerciseCell"
            static let FooterTableViewCell = "kFooterCell"
            
        }
        
        struct SegueIdentifiers {
            static let Cardiovascular = "kCardiovascular"
            static let Strength = "kStrength"
            static let Custom = "kCustom"
        }
    }
    
    var isFromDashboard = true
    var exerciseTypes = [Exercise]()
    var selectedExercise = Exercise(name: "")
    var showLoader = true
    var shouldClear = true
    
    var selectedExerciseType: String = "" {
        didSet {
            configureData()
        }
    }
    
    let segueMapper = [
        "cardiovascular" : StoryBoard.SegueIdentifiers.Cardiovascular,
        "strength" : StoryBoard.SegueIdentifiers.Strength
    ]
    
    var logDate: NSDate = NSDate()
    
    var firstTime: Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView()
    }
    
    var offSet: String {
        
        return self.exerciseTypes.isEmpty ? "0" : String(self.exerciseTypes.count)
    }
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        selectedExercise = Exercise(name: "")
        // reload tableview
        tableView.reloadData()
    }
    
    func configureTableView() {
        
        // hide empty tableview cells
        tableView.tableFooterView = UIView(frame: CGRectZero)
        tableView.estimatedRowHeight = UITableViewAutomaticDimension
        
        // set delegate for pull to refresh and load more
        tableView.setDragDelegate(self, refreshDatePermanentKey: "kExercises")
        
        // hide pull to refresh
        tableView.showRefreshView = false
        
        // show load more
        tableView.showLoadMoreView = true
        
        // tableview footer release text
        tableView.footerReleaseText = NSLocalizedString("release_to_load_more_status", comment: "")
        
        // tableview footer pull up text
        tableView.footerPullUpText = NSLocalizedString("pull_down_to_load_more_status", comment: "")
        
        //tableview footer loading text
        tableView.footerLoadingText = NSLocalizedString("loading_status", comment: "")
    }
    
    func configureData() {
        
        if showLoader {
//            MBProgressHUD.showHUDAddedTo(self.view, animated: true)
            SVProgressHUD.show()
        }
        
        if selectedExerciseType == "1" {
            
            if self.shouldClear {
                self.exerciseTypes.removeAll()
            }
            Exercise.fetchCardioExercises(offSet,name: searchTextBar?.text ?? "", type: selectedExerciseType, completionHandler: { (cardioExercises) -> () in
                
                if self.showLoader {
//                    MBProgressHUD.hideHUDForView(self.view, animated: true)
                    SVProgressHUD.dismiss()
                    self.showLoader = false
                }
                
                if self.exerciseTypes.count == 0 {
                    self.exerciseTypes = cardioExercises as [Exercise]
                } else  {
                    self.exerciseTypes  += cardioExercises as [Exercise]
                    self.tableView.finishLoadMore()
                }
                self.firstTime = false
                self.tableView.reloadData()
            })
            
        } else if selectedExerciseType == "2" {
            
            if self.shouldClear {
                self.exerciseTypes.removeAll()
            }
            Exercise.fetchStrengthExercises(offSet,name: searchTextBar?.text ?? "", type: selectedExerciseType, completionHandler: { (strengthExercises) -> () in
                
                if self.showLoader {
                    
                    SVProgressHUD.dismiss()

                    self.showLoader = false
                }
                
                if self.exerciseTypes.count == 0 {
                    self.exerciseTypes = strengthExercises as [Exercise]
                } else  {
                    self.exerciseTypes  += strengthExercises as [Exercise]
                    self.tableView.finishLoadMore()
                }
                self.firstTime = false
                self.tableView.reloadData()
            })
        }
        
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        searchTextBar.resignFirstResponder()
//        self.exerciseTypes.removeAll()
        firstTime = true
//        tableView.reloadData()
        shouldClear = true
        self.showLoader = true
        configureData()
    }
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchBar.showsCancelButton = true
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchTextBar.text = ""
        searchTextBar.resignFirstResponder()
//        self.exerciseTypes.removeAll()
//        tableView.reloadData()
        shouldClear = true
        self.showLoader = true
        configureData()
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        searchBar.showsCancelButton = false
    }
    
    func searchResults() {
        
        firstTime = false
        // search locally
        var searchResults = [Exercise]()
        searchResults = exerciseTypes.filter {
            $0.name.contains(self.searchTextBar.text!)
        }
        
        self.exerciseTypes = searchResults
        tableView.reloadData()
    }
    
    //empty cell create custom exercise clicked
    func emptyExerciseTableViewCell(emptyExerciseTableViewCell: EmptyExerciseTableViewCell, didSelectCreateCustom selected: Bool) {
        
        searchBarCancelButtonClicked(searchTextBar)
        
        if selectedExerciseType == ExerciseTypeId.CardioVascular.rawValue {
            
            self.performSegueWithIdentifier(StoryBoard.SegueIdentifiers.Cardiovascular, sender: self)
            
        } else if selectedExerciseType == ExerciseTypeId.Strength.rawValue {
            
            self.performSegueWithIdentifier(StoryBoard.SegueIdentifiers.Strength, sender: self)
        }
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == StoryBoard.SegueIdentifiers.Cardiovascular {
            let exerciseLogViewController = segue.destinationViewController as! ExerciseCardioLogViewController
            exerciseLogViewController.logDate = logDate
            exerciseLogViewController.isFromDashboard = isFromDashboard
            exerciseLogViewController.selectedExerciseType = selectedExerciseType
            exerciseLogViewController.exercise = selectedExercise.name == "" ? CardioVascularExercise(name: "") : (selectedExercise as! CardioVascularExercise).copy()
        } else if segue.identifier == StoryBoard.SegueIdentifiers.Strength {
            let exerciseLogViewController = segue.destinationViewController as! ExerciseStrengthLogViewController
            exerciseLogViewController.logDate = logDate
            exerciseLogViewController.isFromDashboard = isFromDashboard
            exerciseLogViewController.selectedExerciseType = selectedExerciseType
            exerciseLogViewController.exercise = selectedExercise.name == "" ? StrengthExercise(name: "") : (selectedExercise as!StrengthExercise).copy()
        } else if segue.identifier == StoryBoard.SegueIdentifiers.Custom {
            let exerciseLogViewController = segue.destinationViewController as! ExerciseCustomLogViewController
            exerciseLogViewController.selectedExerciseType = selectedExerciseType
        }
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return exerciseTypes.count == 0 ? 0 : exerciseTypes.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.ExerciseTableViewCell, forIndexPath: indexPath) as! ExerciseTableViewCell
        cell.exercise = exerciseTypes[indexPath.row]
        cell.setNeedsUpdateConstraints()
        cell.updateConstraintsIfNeeded()
        return cell
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        var cell = offscreenCells[StoryBoard.CellIdentifiers.ExerciseTableViewCell]
        if cell == nil {
            cell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.ExerciseTableViewCell) as? ExerciseTableViewCell
            offscreenCells[StoryBoard.CellIdentifiers.ExerciseTableViewCell] = cell
        }
        
        cell?.exercise = exerciseTypes[indexPath.row]
        
        cell?.setNeedsUpdateConstraints()
        cell?.updateConstraintsIfNeeded()
        cell?.bounds = CGRectMake(0.0, 0.0, CGRectGetWidth(tableView.bounds), CGRectGetHeight(cell!.bounds))
        
        cell?.setNeedsLayout()
        cell?.layoutIfNeeded()
        
        cell?.labelExerciseName.preferredMaxLayoutWidth = CGRectGetWidth(cell!.labelExerciseName.bounds)
        cell?.labelExerciseName.setNeedsUpdateConstraints()
        
        // Get the actual height required for the cell's contentView
        var height = cell?.contentView.systemLayoutSizeFittingSize(UILayoutFittingCompressedSize).height
        
        // Add an extra point to the height to account for the cell separator, which is added between the bottom
        // of the cell's contentView and the bottom of the table view cell.
        height = height! + 1
        
        return height!
        
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if exerciseTypes.count == 0 {
            return
        }
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! ExerciseTableViewCell
        selectedExercise = cell.exercise
        self.performSegueWithIdentifier(segueMapper[selectedExercise.exerciseType.rawValue]!, sender: self)
    }
    
    override func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if exerciseTypes.count != 0 || firstTime {
            return UIView(frame: CGRectZero)
        }
        let cell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.EmptyExerciseTableViewCell) as! EmptyExerciseTableViewCell
        cell.emptyExerciseTableViewCellDelegate = self
        return cell
    }
    
    override func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView(frame: CGRectZero)
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if exerciseTypes.count != 0 || firstTime {
            return 0
        }
        
        return 250
    }
    
    func dragTableDidTriggerLoadMore(tableView: UITableView!) {
        // called when the load more is selected
        shouldClear = false
        configureData()
    }
    @IBAction func buttonActionCreateNewCustomExercise(sender: UIBarButtonItem) {
        
        searchBarCancelButtonClicked(searchTextBar)
        
        if selectedExerciseType == ExerciseTypeId.CardioVascular.rawValue {
            
            self.performSegueWithIdentifier(StoryBoard.SegueIdentifiers.Cardiovascular, sender: self)
            
        } else if selectedExerciseType == ExerciseTypeId.Strength.rawValue {
            
            self.performSegueWithIdentifier(StoryBoard.SegueIdentifiers.Strength, sender: self)
        }
    }
    
    @IBAction func unwindToExerciseListViewController(segue: UIStoryboardSegue) {
        
    }
}