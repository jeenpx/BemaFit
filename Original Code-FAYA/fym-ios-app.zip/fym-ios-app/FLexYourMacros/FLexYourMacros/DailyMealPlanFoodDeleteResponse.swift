//
//  DailyMealPlanFoodDeleteResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 12/11/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class DailyMealPlanFoodDeleteResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var dailyMealPlanId: String?
    var foodId: String?
    
    // daily meal plan food delete response mapping
    class var dailyMealPlanFoodDeleteResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(DailyMealPlanFoodDeleteResponse.metaModelKeyMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: dailyMealPlanFoodDeleteResponseMapping, method: .DELETE, pathPattern: Constants.ServiceConstants.kDailyMealPlanFoodDeleteUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    class func deleteDailyMealPlanFood(dailyMealPlanId: String, foodId: String, completionHandler: (responseStatus: String) -> ()) {
        // delete the message thread
        
        // set access token
        RestKitManager.setToken(true)
        
        let dailyMealPlanFoodDeleteResponse = DailyMealPlanFoodDeleteResponse()
        dailyMealPlanFoodDeleteResponse.dailyMealPlanId = dailyMealPlanId
        dailyMealPlanFoodDeleteResponse.foodId = foodId
        
        RestKitManager.sharedManager().deleteObject(dailyMealPlanFoodDeleteResponse, path: nil, parameters: nil, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            
            //print("Success")
            let deleteResponseObject = mappingResult.firstObject as! DailyMealPlanFoodDeleteResponse
            
            if let responseMeta = deleteResponseObject.meta {
                
                // completion handler
                completionHandler(responseStatus: responseMeta.responseStatus!)
            }
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                //print("error \(error)");
                
        })
        
    }
}
