//
//  EmptyBackgroundView.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/14/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import UIKit

enum EmptyBackgroundViewMode {
    case Food
    case Exercise
}

protocol EmptyBackgroundViewDelegate {
    func buttonActionCreateNew(emptyBackgroundViewMode: EmptyBackgroundView)
}

class EmptyBackgroundView: UIView {
    
    var emptyBackgroundViewDelegate: EmptyBackgroundViewDelegate?
    
    // mode defaults to Food
    var emptyBackgroundViewMode = EmptyBackgroundViewMode.Food {
        didSet {
            configureView()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func configureView() {
        
        // set the background color of the view
        self.backgroundColor = UIColor.defaultGrayColor()
        
        // configure the imageview custom meal
        let imageViewCustomMeal = UIImageView(image: UIImage(named: emptyBackgroundViewMode == .Food ? "NoResultMeal":"NoResultExercise"))
        
        // add tap gesture to the imageview custom meal
        imageViewCustomMeal.userInteractionEnabled = true
        let tapImageViewCustomMeal = UITapGestureRecognizer(target: self, action: "didTapCreateCustomMeal:")
        imageViewCustomMeal.addGestureRecognizer(tapImageViewCustomMeal)
        
        // add the subview imageview custom meal
        self.addSubview(imageViewCustomMeal)
        
        // configure the label custom meal
        let labelCustomMeal = UILabel()
        labelCustomMeal.text = emptyBackgroundViewMode == .Food ? &&"create_custom_meal":&&"create_custom_exercise"
        labelCustomMeal.font = UIFont(name: "Helvetica-Bold", size: 12)!
        labelCustomMeal.textColor = UIColor(red: 40.0/255.0, green: 141.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        
        // add tap gesture to the label custom meal
        labelCustomMeal.userInteractionEnabled = true
        let taplabelCustomMeal = UITapGestureRecognizer(target: self, action: "didTapCreateCustomMeal:")
        labelCustomMeal.addGestureRecognizer(taplabelCustomMeal)
        
        // add the subview label custom meal
        self.addSubview(labelCustomMeal)
        
        // configure the label no results
        let labelNoResults = UILabel()
        labelNoResults.text = &&"no_results_found"
        labelNoResults.font = UIFont(name: "Helvetica-Bold", size: 16)!
        labelNoResults.textColor = UIColor(red: 114.0/255.0, green: 114.0/255.0, blue: 114.0/255.0, alpha: 1.0)
        
        // add the subview label no results
        self.addSubview(labelNoResults)

        // set constraints for the subviews
        setConstraintsViewCustomMeal(imageViewCustomMeal, andLabel: labelCustomMeal, andLabelNoResults: labelNoResults)
        
    }
    
    func setConstraintsViewCustomMeal(imageViewCustomMeal: UIImageView, andLabel labelCustomMeal: UILabel, andLabelNoResults labelNoResults: UILabel) {
        
        // set constraints for the imageview
        imageViewCustomMeal.translatesAutoresizingMaskIntoConstraints = false
        self.addConstraints([NSLayoutConstraint(item: imageViewCustomMeal, attribute: NSLayoutAttribute.CenterX, relatedBy: .Equal,
            toItem: self, attribute: NSLayoutAttribute.CenterX, multiplier: 1.0, constant: 0.0),
            NSLayoutConstraint(item: imageViewCustomMeal, attribute: NSLayoutAttribute.CenterY, relatedBy: .Equal,
                toItem: self, attribute: NSLayoutAttribute.CenterY, multiplier: 1.0, constant: 0.0)])
        
        self.addConstraints([NSLayoutConstraint(item: imageViewCustomMeal, attribute: NSLayoutAttribute.Height, relatedBy: .Equal,
            toItem: nil, attribute: NSLayoutAttribute.NotAnAttribute, multiplier: 1.0, constant: 75.0),
            NSLayoutConstraint(item: imageViewCustomMeal, attribute: NSLayoutAttribute.Width, relatedBy: .Equal,
                toItem: nil, attribute: NSLayoutAttribute.NotAnAttribute, multiplier: 1.0, constant: 75.0)])
        
        // set constraints for the label custom meal
        labelCustomMeal.translatesAutoresizingMaskIntoConstraints = false
        self.addConstraints([NSLayoutConstraint(item: labelCustomMeal, attribute: NSLayoutAttribute.Top, relatedBy: .Equal,
            toItem: imageViewCustomMeal, attribute: NSLayoutAttribute.Bottom, multiplier: 1.0, constant: 15.0),
            NSLayoutConstraint(item: labelCustomMeal, attribute: NSLayoutAttribute.CenterX, relatedBy: .Equal,
                toItem: self, attribute: NSLayoutAttribute.CenterX, multiplier: 1.0, constant: 0.0)])
        
        // set constraints for the label no results
        labelNoResults.translatesAutoresizingMaskIntoConstraints = false
        self.addConstraints([NSLayoutConstraint(item: labelNoResults, attribute: NSLayoutAttribute.Bottom, relatedBy: .Equal,
            toItem: imageViewCustomMeal, attribute: NSLayoutAttribute.Top, multiplier: 1.0, constant: -15.0),
            NSLayoutConstraint(item: labelNoResults, attribute: NSLayoutAttribute.CenterX, relatedBy: .Equal,
                toItem: self, attribute: NSLayoutAttribute.CenterX, multiplier: 1.0, constant: 0.0)])

    }
    
    func didTapCreateCustomMeal(tapGesture: UITapGestureRecognizer) {
        //print("didTapCreateCustomMeal entered...")
        emptyBackgroundViewDelegate?.buttonActionCreateNew(self)
    }
    
}
