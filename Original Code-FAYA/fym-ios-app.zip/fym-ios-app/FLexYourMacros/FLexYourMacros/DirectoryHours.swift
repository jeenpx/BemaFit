//
//  DirectoryHours.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/26/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class DirectoryHours: NSObject {
    
    // model instance variable
    var day: String?
    var open: String?
    var close: String?
    
    func getNormalTimeFromRailway(openTime: Bool) -> String {
        // convert railway time to normal time
        
        let time = openTime ? open : close
        if let normalTime = time {
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateStyle = NSDateFormatterStyle.MediumStyle
            dateFormatter.dateFormat = "HH:mm:ss"
            let date = dateFormatter.dateFromString(normalTime)
            
            let formatter = NSDateFormatter()
            formatter.dateFormat = "hh:mm a"
            return formatter.stringFromDate(date!).stringByReplacingOccurrencesOfString("AM", withString: "am").stringByReplacingOccurrencesOfString("PM", withString: "pm")
        }
        return "00:00"
    }
    
    class var objectMapping: RKObjectMapping {
        // object mapping
        
        let directoryCategoryMapping = RKObjectMapping(forClass: self)
        directoryCategoryMapping.addAttributeMappingsFromDictionary(mappingDictionary)
        return directoryCategoryMapping
    }
    
    class var mappingDictionary: [String : String] {
        return(["day":"day", "open":"open", "close":"close"])
    }
    
    func acceptsDay(day: String) -> Bool {
        // return current date
        
        return self.day == day
    }
    
}