//
//  ProgressReport.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 27/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class ProgressResult: NSObject {
    
    var report : [ProgressReport]?
    class var objectMapping: RKObjectMapping {
        
        let progressReportMapping = RKObjectMapping(forClass: ProgressResult.self)
        progressReportMapping.addRelationshipMappingWithSourceKeyPath("report", mapping:ProgressReport.entityMapping)
        return progressReportMapping
    }
}
