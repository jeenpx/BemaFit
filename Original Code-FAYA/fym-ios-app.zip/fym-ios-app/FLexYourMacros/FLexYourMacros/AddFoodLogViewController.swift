//
//  AddFoodLogViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 23/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class AddFoodLogViewController: UITableViewController {
    
    var mealType: MealType?
    
    var logDate = NSDate()
    
    var isDailyMealPlan = false
    
    var dailyMealType = DailyMealType(dailyMealTypeName: "")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    struct Storyboard {
        struct Segues {
            static let SearchFoodSegue = "kSearchFoodSegue"
            static let CreateFromServingSizeSegue = "kCreateFromServingSizeSegue"
            static let LogByMacroSegue = "kLogByMacrosSegue"
            
            static let FoodRecommendationSegue = "kFoodRecommendationSegue"
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == Storyboard.Segues.SearchFoodSegue {
            let foodListViewController = segue.destinationViewController as! FoodListViewController
            foodListViewController.foodListMode = FoodListMode.SearchFood
            foodListViewController.dailyMealType = dailyMealType
            foodListViewController.mealType = mealType
            foodListViewController.isDailyMealPlan = isDailyMealPlan
            foodListViewController.logDate = logDate
        }
        else if segue.identifier == Storyboard.Segues.CreateFromServingSizeSegue {
            let foodListViewController = segue.destinationViewController as! FoodListViewController
            foodListViewController.foodListMode = FoodListMode.LogByServingSize
            foodListViewController.dailyMealType = dailyMealType
            foodListViewController.mealType = mealType
            foodListViewController.isDailyMealPlan = isDailyMealPlan
            foodListViewController.logDate = logDate
        }
        else if segue.identifier == Storyboard.Segues.LogByMacroSegue {
            let convertUnitsViewController = segue.destinationViewController as! ConvertUnitsViewController
            convertUnitsViewController.food = Food(isLoggedByMacro: true)
            convertUnitsViewController.controllerMode = ControllerMode.LogMacro
            convertUnitsViewController.dailyMealType = dailyMealType
            convertUnitsViewController.mealType = mealType
            convertUnitsViewController.isDailyMealPlan = isDailyMealPlan
            convertUnitsViewController.logDate = logDate
        }
        else if segue.identifier == Storyboard.Segues.FoodRecommendationSegue {
            let mealTypeListViewController = segue.destinationViewController as! MealTypeListViewController
            mealTypeListViewController.mealTypeListInitiator = MealTypeListInitiator.FoodRecommendations
            mealTypeListViewController.dailyMealType = dailyMealType
            mealTypeListViewController.mealType = mealType
            mealTypeListViewController.isDailyMealPlan = isDailyMealPlan
            mealTypeListViewController.logDate = logDate
        }
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        cell.setSeparatorInsetZero()
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        // food recommendation
        if indexPath.section == 1 {
            if indexPath.row == 1 {
                if mealType != nil {
                    let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let foodListViewController = mainStoryboard.instantiateViewControllerWithIdentifier("kFoodListViewController") as? FoodListViewController
                    foodListViewController!.logDate = logDate
                    foodListViewController!.foodListMode = FoodListMode.FoodRecommendation
                    foodListViewController!.foodRecommendationMealType = mealType
                    foodListViewController!.isDailyMealPlan = isDailyMealPlan
                    foodListViewController!.mealType = mealType
                    self.navigationController?.pushViewController(foodListViewController!, animated: true)
                }
                else {
                    performSegueWithIdentifier(Storyboard.Segues.FoodRecommendationSegue, sender: nil)
                }
            }
        }
    }
}
