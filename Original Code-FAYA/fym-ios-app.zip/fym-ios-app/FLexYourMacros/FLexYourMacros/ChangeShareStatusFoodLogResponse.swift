//
//  ChangeShareStatusFoodLogResponse.swift
//  FlexYourMacros
//
//  Created by mini on 10/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class ChangeShareStatusFoodLogResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var foodlog_id: String?
    
    // message delete response mapping
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(ChangeShareStatusFoodLogResponse.metaModelKeyMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: responseMapping, method: .PATCH, pathPattern: Constants.ServiceConstants.kUrlFood, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    class func changeStatus(foodId: String, status: String, completionHandler: (changedStatus: Bool) -> ()) {
        // delete the food
        
        // set access token
        RestKitManager.setToken(true)
        
        let changeShareStatusFoodLogResponse = ChangeShareStatusFoodLogResponse()
        changeShareStatusFoodLogResponse.foodlog_id = foodId
        
        
        var err: NSError?
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(changeShareStatusFoodLogResponse, method: .PATCH, path: nil, parameters: nil, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
        do {
            request.HTTPBody =  try NSJSONSerialization.dataWithJSONObject(["approve": status], options: [])
        } catch var error as NSError {
            err = error
            request.HTTPBody = nil
        }
        
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            //print("Success")
            let responseObject = mappingResult.firstObject as! ChangeShareStatusFoodLogResponse
            
            if let responseMeta = responseObject.meta {
                
                // completion handler
                completionHandler(changedStatus: true)
            }
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                //print("error \(error)");
                
                completionHandler(changedStatus: false)
                
                //print("failed to update status with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
        
    }
}
