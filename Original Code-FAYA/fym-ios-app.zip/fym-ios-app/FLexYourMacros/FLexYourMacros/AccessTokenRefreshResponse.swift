//
//  AccessTokenRefreshResponse.swift
//  FlexYourMacros
//
//  Created by mini on 05/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//
import Foundation

private let _AccessTokenRefreshResponse = AccessTokenRefreshResponse()

class AccessTokenRefreshResponse: NSObject {
    
    var accessTokenModel: AccessTokenModel?
    var metaModel: MetaModel?
    
    class var sharedAccessTokenRefreshResponse: AccessTokenRefreshResponse {
        return _AccessTokenRefreshResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        // give reference to accesstoken mapping
        responseMapping.addPropertyMapping(AccessTokenRefreshResponse.metaModelKeyMapping)

        responseMapping.addPropertyMapping(AccessTokenRefreshResponse.accessTokenModelKeyMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.refreshTokenUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var accessTokenModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathAccessToken, toKeyPath: "accessTokenModel", withMapping: AccessTokenModel.objectMapping)
    }
    
    class func refreshToken(refreshToken: String, completionHandler: (accessCredential: AccessTokenModel?) -> ()) {
        
        RestKitManager.setupBasicAuth()

        var parameterDictionary: [String:String] {
            
            // create the parameter dictionary
            return ["refresh_token":refreshToken]
        }
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(nil, method: .POST, path: Constants.ServiceConstants.refreshTokenUrl, parameters: parameterDictionary, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let response = mappingResult.firstObject as! AccessTokenRefreshResponse
            
            if response.metaModel?.responseCode != 200 {
                
                completionHandler(accessCredential: nil)

                return;
            }

            completionHandler(accessCredential: response.accessTokenModel!)
            
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                //print("failed to load contact us with error \(error)")
                
                completionHandler(accessCredential: nil)
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
        
    }
    
    
}
