//
//  DirectoryCheckInResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/28/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class DirectoryCheckInResponse: NSObject {
    var meta: MetaModel?
    
    // directory checkin response response mapping
    class var objectMapping: RKObjectMapping {
        
        let checkInResponseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        checkInResponseMapping.addPropertyMapping(DirectoryCheckInResponse.metaModelKeyMapping)
        
        return checkInResponseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: objectMapping, method: .POST, pathPattern: Constants.ServiceConstants.kUrlPostBusiness, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }

    class func directoryCheckIn(id: String, completionHandler: (status: String) -> ()) {
        
        SVProgressHUD.show()
        
        // set access token
        RestKitManager.setToken(true)
        
        // input parameter
        let param: Dictionary = ["business": id]
        
        
        // check in api
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(nil, method: .POST, path: Constants.ServiceConstants.kUrlPostBusiness, parameters: param, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let directoryCheckInResponse = mappingResult.firstObject as! DirectoryCheckInResponse
            //print("directoryCheckInResponse:\(directoryCheckInResponse.meta?.responseCode)")
            //print("respone status :\(directoryCheckInResponse.meta?.responseStatus)")
            
            
            // check for success
            if directoryCheckInResponse.meta?.responseCode != 200 {
                //print("postMessage: failure")
                completionHandler(status: &&"failed_to_checkin_alert_message")

                return
            }
            else {
                
                SVProgressHUD.dismiss()
                
                // completion handler to return success
                completionHandler(status: &&"checked_in_successfully_alert_message")
            }
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                SVProgressHUD.dismiss()
                //print("failed to load postMessage with error \(error)")
                completionHandler(status: &&"failed_to_checkin_alert_message")

        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
        
    }
    
}
