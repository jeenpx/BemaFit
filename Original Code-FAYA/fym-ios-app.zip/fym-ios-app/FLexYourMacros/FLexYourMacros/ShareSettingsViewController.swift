//
//  ShareSettingsViewController.swift
//  FlexYourMacros
//
//  Created by Vineeth Edwin on 10/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ShareSettingsViewController: UITableViewController, UIAlertViewDelegate {
    
    
    @IBOutlet weak var buttonConnect: UIButton!
    var autoSyncArray:[SettingsModel] = []
    
    // disable if any background task is in progress
    var isBackClickedEnabled = true
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    var alert: UIAlertView?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.title = &&"Share_Settings"
    /*   var storage : NSHTTPCookieStorage = NSHTTPCookieStorage.sharedHTTPCookieStorage()
        for cookie in storage.cookies  as! [NSHTTPCookie]
        {
            storage.deleteCookie(cookie)
            
            //println("Success---\(cookie)")
        }
        NSUserDefaults.standardUserDefaults()
       
    */
     
        if AppConfiguration.sharedAppConfiguration.userDetails?.userFacebookId == ""{
            buttonConnect.setTitle(&&"Connect", forState: UIControlState.Normal)
            
        } else {
            buttonConnect.setTitle(&&"Disconnect", forState: UIControlState.Normal)
            //buttonConnect.enabled = false
            
        }
        
       }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if indexPath.section == 1 {
            if indexPath.row == 0 {
                // self.performSegueWithIdentifier("kAutoSyncSettingsSegue", sender: self)
            }
        }
    }
    

    override func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView :UIView  = UIView(frame: CGRectMake(0,200,300,100))
        headerView.backgroundColor = UIColor.color(44, green: 44, blue: 44, alpha: 1)
        let label : UILabel = UILabel(frame: CGRectMake(15,0,300,44))
        if(section == 0){
            label.text = &&"Connect_Social"
            label.textColor = UIColor.whiteColor()
            label.font = UIFont (name: "Helvetica-Bold", size: 15)
            
        } else if (section == 1){
            label.textColor = UIColor.whiteColor()
            label.text = &&"Auto_Sync"
            label.font = UIFont (name: "Helvetica-Bold", size: 15)
        }
        headerView.addSubview(label)
        return headerView
    }
   
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40.0
    }

    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "kAutoSyncSettingsSegue" {
            //let syncSettingsViewController = segue.destinationViewController as SyncSettingsViewController
        }
    }
    
    @IBAction func buttonActionFbConnect(sender: UIButton) {
        // connect facebook
    
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }

        
       if AppConfiguration.sharedAppConfiguration.userDetails?.userFacebookId == "" {
            
        // connect to fb session and logIn with facebook
        
        // check internet
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        // open fb session
        FacebookManager.openSessionWithReadPermissionsWithHandler { (result, error) -> Void in
            
            if error != nil {
                //print("Facebook login failed \(error)");
            }
                
            else
            {
                if result.isCancelled || result.declinedPermissions.count>0 {
                    //print("permissions declined \(result.declinedPermissions)")
                } else {
                    
                    if !reachability {
                        
                        self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                        return
                    }
                    self.connectfb(["facebook_access_token":FBSDKAccessToken.currentAccessToken().tokenString,"action":"connect"])

                   /*
                    FacebookManager.getUserDetail({ (userDetails) -> Void in
                        //print("Access Token from Facebook is \(FBSDKAccessToken.currentAccessToken().tokenString)")
                        let userDictionary = userDetails as! Dictionary <String, AnyObject>
                        var name = userDictionary["first_name"] as? String
                        //print("Currently logged as:  \(FBSDKAccessToken.currentAccessToken().tokenString)")
                        self.connectfb(["facebook_access_token":FBSDKAccessToken.currentAccessToken().tokenString,"action":"connect"])
                        
                    })
                 */
                    
                    
                }
                
            }
        }}
        else {
        // disconnect facebook api call
        var params: [String:String] {
            // create the parameter dictionary
            return ["action":"disconnect"]
        }
        
        
        self.connectfb(params)
        }
        
    }
    
    func connectfb(params: [String:String]) {
        
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        // disable the back button
        isBackClickedEnabled =  false
        SVProgressHUD.show()
        FacebookConnectResponse.connectwithfb(params, completionHandler: { (response) -> () in
            let userfbResponse = response
            //print("respone status :\(userfbResponse.metaModel?.responseStatus)")

            // check for success
            if userfbResponse.metaModel?.responseCode == 200 {
                // update the button status
                self.updateFbconnectStatus()
                
            } else if userfbResponse.metaModel?.responseCode == 425 {
                
                SVProgressHUD.dismiss()
                self.showAlert(&&"notice", message: &&"fbconnect_error_425")
                
                // enable the back button
                self.isBackClickedEnabled = true
                
            } else if userfbResponse.metaModel?.responseCode == 426 {
                
                SVProgressHUD.dismiss()
                self.showAlert(&&"notice", message: &&"fbconnect_error_425")
                
                // enable the back button
                self.isBackClickedEnabled = true

            } else {
                SVProgressHUD.dismiss()
                if let d = userfbResponse.metaModel?.message {
                    self.showAlert(&&"notice",message: "\(d)")
                }
                // enable the back button
                self.isBackClickedEnabled = true
            }
        })
    }
    
    
    
    @IBAction func buttonActionBack(sender: UIBarButtonItem) {
        
        let reachability = appDelegate!.internetReachable
        
        if isBackClickedEnabled || !reachability {
            self.navigationController?.popViewControllerAnimated(true)
        } else {
            //print("progress in background please wait")
        }
    }
    
    func showAlert(title: String, message: String) {
        // configure alert
        // show alert controller if possible else show alert view
        if #available(iOS 8.0, *) {
            
            let alert = UIAlertController(title: title, message: message , preferredStyle: .Alert)
            alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        } else {
            // Fallback on earlier versions
            
            alert = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok")
            alert?.show()
        }
        
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if alertView == alert {
            if buttonIndex == 0 {
                // cancel button
                
            } else {
               
            }
        }
    }
    
    
    
    // call this function to update the fbconnect button status
    func updateFbconnectStatus() {
        
        // refresh user details
        AppConfiguration.refreshUserDetails { (refreshedUserDetails) -> () in
            
            if refreshedUserDetails {
                
                // enable the back button 
                self.isBackClickedEnabled = true
                SVProgressHUD.dismiss()
                if AppConfiguration.sharedAppConfiguration.userDetails?.userFacebookId == ""{
                    self.buttonConnect.setTitle(&&"Connect", forState: UIControlState.Normal)
                    
                } else {
                    self.buttonConnect.setTitle(&&"Disconnect", forState: UIControlState.Normal)
                    //buttonConnect.enabled = false
                    
                }
                
            }
        }
    }
    
}
