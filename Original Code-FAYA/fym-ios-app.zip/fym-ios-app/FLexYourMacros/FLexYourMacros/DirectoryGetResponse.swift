//
//  DirectoryGetResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/26/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class DirectoryGetResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    var business: [DirectoryModel]?
    
    // directory response mapping
    class var directoryResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(DirectoryGetResponse.metaModelKeyMapping)
        
        // give reference to message item model
        responseMapping.addPropertyMapping(DirectoryGetResponse.directoryModelKeyMapping)
        
        return responseMapping
    }
    
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
    }
    
    private class var directoryModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathBusiness, toKeyPath: "business", withMapping: DirectoryModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: directoryResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kUrlGetBusiness, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    //    class func getBusiness() {
    //        // get messages
    //
    //        // set access token
    //        RestKitManager.setToken(true)
    //
    //        // input parameters
    //        //let params: Dictionary = ["offset": 0, "limit": 10]
    //        RestKitManager.sharedManager().getObjectsAtPath(Constants.ServiceConstants.kUrlGetBusiness, parameters: nil, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
    //
    //            //println("success")
    //
    //            let directoryResponse = mappingResult.firstObject as! DirectoryGetResponse
    //
    //            // check for success
    //            if directoryResponse.meta?.responseCode != 200 {
    //                //println("failure data\(directoryResponse.meta?.responseCode)")
    //                return;
    //            }
    //
    ////            if let obj = directoryResponse.business {
    ////                //println("count:\(obj.count)")
    ////            }
    //
    //
    //            if let arrayBusiness = directoryResponse.business as [DirectoryModel]? {
    //                for businessModel: DirectoryModel in arrayBusiness {
    //                    //println("**************************")
    //                    //println(businessModel.name)
    //                    //println(businessModel.phone)
    //                    //println(businessModel.address1)
    //                    //println(businessModel.address2)
    //                    //println(businessModel.premiumListing)
    //                    //println(businessModel.phone)
    //                    //println(businessModel.website)
    //                    //println(businessModel.distance)
    //                    if let arrayCategory = businessModel.category as [DirectoryCategory]? {
    //                        for category: DirectoryCategory in arrayCategory {
    //                        //println(category.name)
    //                        }
    //                    }
    //                    if let arrayImages = businessModel.images as [DirectoryImages]? {
    //                        for image: DirectoryImages in arrayImages {
    //                            //println(image.file)
    //                            //println(image.directoryDescription)
    //                        }
    //                    }
    //
    //                    if let arrayHours = businessModel.workingHours as [DirectoryHours]? {
    //                        for hour: DirectoryHours in arrayHours {
    //                            //println(hour.day)
    //                            //println(hour.open)
    //                            //println(hour.close)
    //                        }
    //                    }
    //
    //                    //println("**************************")
    //                }
    //            }
    //
    //            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
    //                //println("error: \(error)");
    //
    //        })
    //
    //    }
    
    class func getDirectory(offset: Int, andLimit limit: Int, andLocation location: String, andType type: String, andLatitude latitude: Double, andLongitude longitude: Double, andProgressHUD showProgressHUD: Bool, completionHandler: (directoryGetResponse: DirectoryGetResponse, status: String) -> ()) {
        
        if showProgressHUD {
            SVProgressHUD.show()
        }
        
        RestKitManager.setToken(true)
        
        // input parameters
        //  let params: Dictionary<String, AnyObject>  = ["offset": offset, "limit": limit ,"location": location, "type": type]
        
        // prepare params
        var params = [String: AnyObject]()
        params["offset"] = offset
        params["limit"] = limit
        
        if !type.isEmpty {
            params["type"] = type
        }
        
        if latitude == 0 && longitude == 0 {
            if !location.isEmpty {
                params["location"] = location
            }
        }
        else {
            if !location.isEmpty {
                params["location"] = location
            }
                params["latitude"] = latitude
                params["longitude"] = longitude
        }
        
        // don't call api
        if latitude == 0 && longitude == 0 && location == "" {
            completionHandler(directoryGetResponse: DirectoryGetResponse(), status: "failure")
            SVProgressHUD.dismiss()
            return
        }
        
        
        RestKitManager.sharedManager().getObjectsAtPath(Constants.ServiceConstants.kUrlGetBusiness, parameters: params, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            
            //print("success")
            let directoryResponse = mappingResult.firstObject as! DirectoryGetResponse
            
            // check for success
            if directoryResponse.meta?.responseCode != 200 {
                //print("failure data\(directoryResponse.meta?.responseCode)")
                return
            }
            SVProgressHUD.dismiss()
            completionHandler(directoryGetResponse: directoryResponse, status: "success")
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                SVProgressHUD.dismiss()
                //print("error: \(error)");
                
        })
    }
    
    class func getBusinessDirectory(params: [String: AnyObject], completionHandler: (businessDirectory: DirectoryModel?, error: NSError?) -> ()) {
        
        RestKitManager.setToken(true)
        
        RestKitManager.sharedManager().getObjectsAtPath(Constants.ServiceConstants.kUrlGetBusiness, parameters: params, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            
            let response = mappingResult.firstObject as! DirectoryGetResponse
            
            if response.meta?.responseCode != 200 {
                // failed
                let error = NSError(domain: "FYM.BusinessDirectory", code: 1003, userInfo: ["title": "error", "message": "alert_message_directory_detail"])
                
                // fire completion handler
                completionHandler(businessDirectory: nil, error: error)
            }
            else {
                // success
                completionHandler(businessDirectory: response.business?.first, error: nil)
            }
                        
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                // failed
                let networkError = NSError(domain: "FYM.BusinessDirectory", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
                
                // fire completion handler
                completionHandler(businessDirectory: nil, error: networkError)
        })
    }
    
}