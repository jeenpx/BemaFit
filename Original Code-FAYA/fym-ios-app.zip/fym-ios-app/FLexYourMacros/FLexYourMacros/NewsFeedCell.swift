//
//  NewsFeedCell.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 24/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol EnlargeImageNewsFeedDelegate {
    func enlargeImageView(selectedCell: NewsFeedCell, imageViewNewsFeed: UIImageView)
}

protocol NewsFeedCellDelegate {
    /// Fired when a hashtag is selected
    func newsFeedCell(newsFeedCell: NewsFeedCell, didSelectHashTag hashTag: String)
    
    /// Fired when a user is selected
    func newsFeedCell(newsFeedCell: NewsFeedCell, didSelectUser userId: String)
    
    /// Fired when a business directory is selected
    func newsFeedCell(newsFeedCell: NewsFeedCell, didSelectBusinessDirectory businessDirectoryId: String)
    
    /// Fired when a newsfeed like is successfull
    func newsFeedCell(newsFeedCell: NewsFeedCell, didLikeNewsFeed like: Bool)
    
    /// Fired when a newsfeed delete is selected
    func newsFeedCell(newsFeedCell: NewsFeedCell, didDeleteNewsFeed delete: Bool)
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didInspireNewsFeed inspire: Bool)
    
    func buttonShare(shareContent: FacebookShareModel)
    
    func buttonActionComments(newsFeed: NewsFeed)
}

class NewsFeedCell: UITableViewCell, HashTagTextViewDelegate {
    
    
    var enlargeImageNewsFeedDelegate: EnlargeImageNewsFeedDelegate?

    // header outlets
    @IBOutlet weak var viewNewsFeedHeader: UIView!
    @IBOutlet weak var imageViewProfilePic: UIImageView!
    @IBOutlet weak var textViewHeading: HashTagTextView!
    @IBOutlet weak var labelTime: UILabel!
    
    @IBOutlet weak var cellTopView: UIImageView!
    @IBOutlet weak var cellBottomView: UIImageView!
    // body outlets
    @IBOutlet weak var viewNewsFeedBody: UIView!
    @IBOutlet weak var imageViewNewsFeedImage: UIImageView!
    @IBOutlet weak var hashTagTextView: HashTagTextView!
    
    @IBOutlet weak var layoutBodyHeight: NSLayoutConstraint!
    @IBOutlet weak var layoutImageViewWidth: NSLayoutConstraint!
    @IBOutlet weak var layoutImageViewHeight: NSLayoutConstraint!
    @IBOutlet weak var buttonLike: UIButton!
    @IBOutlet weak var buttonComments: UIButton!
    @IBOutlet weak var buttonInspire: UIButton!
    
    @IBOutlet weak var buttonDelete: UIButton!
    @IBOutlet weak var shareButton: UIButton!
    var layoutTextViewBodyHeight: [NSLayoutConstraint]?
    
    // footer outlets
    @IBOutlet weak var viewNewsFeedFooter: UIView!
    
    var newsFeedCellDelegate: NewsFeedCellDelegate?
    
    var currentUserId = ""
    
    var isNetworkReachable: Bool {
        let reachability = (UIApplication.sharedApplication().delegate as! AppDelegate).internetReachable
        
        if !reachability {
            
            // no internet
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
        }
        
        return reachability
    }
    
    var newsFeedType: NewsFeedType? {
        didSet {
            
            if newsFeedType == nil {
                //print("XXX no type for newsfeed")
                return
            }
            else {
                //print("YYY newsfeed type = \(newsFeedType)")
            }
            
            switch newsFeedType! {
            case .GoalReached:
                textViewHeading.attributedText = NSAttributedString(string: &&"goal_heading", attributes: [NSFontAttributeName: UIFont.helvetica(12), NSForegroundColorAttributeName: UIColor.darkTextGrayColor()])
                textViewHeading.configureForHashTagDetection(true)
                textViewHeading.prependSender(newsFeed.userName, senderId: "\(newsFeed.userId)")
                currentUserId = "\(newsFeed.userId)"
                imageViewProfilePic.setImageWithURL(NSURL(string: newsFeed.userProfilePic), placeholderImage: UIImage(named: "PlaceHolderProfilePic"))
               
            case .ExerciseLog:
                textViewHeading.attributedText = NSAttributedString(string: &&"exercise_heading", attributes: [NSFontAttributeName: UIFont.helvetica(12), NSForegroundColorAttributeName: UIColor.darkTextGrayColor()])
                textViewHeading.configureForHashTagDetection(true)
                textViewHeading.prependSender(newsFeed.exerciseUserName, senderId: "\(newsFeed.exerciseUserId)")
                currentUserId = "\(newsFeed.exerciseUserId)"
                imageViewProfilePic.setImageWithURL(NSURL(string: newsFeed.exerciseProfilePic), placeholderImage: UIImage(named: "PlaceHolderProfilePic"))
               
            case .FriendRequestAccepted:
                textViewHeading.attributedText = NSAttributedString(string: &&"friend_accepted_heading", attributes: [NSFontAttributeName: UIFont.helvetica(12), NSForegroundColorAttributeName: UIColor.darkTextGrayColor()])
                textViewHeading.configureForHashTagDetection(true)
                textViewHeading.prependSender(newsFeed.friendName1, senderId: "\(newsFeed.friendId1)")
                currentUserId = "\(newsFeed.friendId1)"
                textViewHeading.appendSender(newsFeed.friendName2, senderId: "\(newsFeed.friendId2)")
                imageViewProfilePic.setImageWithURL(NSURL(string: newsFeed.friendProfilePic1), placeholderImage: UIImage(named: "PlaceHolderProfilePic"))
            case .CheckinStatusPost:
                    textViewHeading.attributedText = NSAttributedString(string: &&"checkin_heading", attributes: [NSFontAttributeName: UIFont.helvetica(12), NSForegroundColorAttributeName: UIColor.darkTextGrayColor()])
                    textViewHeading.configureForHashTagDetection(true)
                    textViewHeading.prependSender(newsFeed.checkinUserName, senderId: "\(newsFeed.checkinUserId)")
                    textViewHeading.appendBusinessDirectory(newsFeed.checkinBusinessDirectoryName, senderId: newsFeed.checkinBusinessDirectoryId)
                    currentUserId = "\(newsFeed.checkinUserId)"
                    imageViewProfilePic.setImageWithURL(NSURL(string: newsFeed.checkinUserProfilePic), placeholderImage: UIImage(named: "PlaceHolderProfilePic"))
            case .StatusPost:
                textViewHeading.text = ""
                textViewHeading.configureForHashTagDetection(true)
                textViewHeading.prependSender(newsFeed.userName, senderId: "\(newsFeed.userId)")
                currentUserId = "\(newsFeed.userId)"
                imageViewProfilePic.setImageWithURL(NSURL(string: newsFeed.userProfilePic), placeholderImage: UIImage(named: "PlaceHolderProfilePic"))
          
            case .GuestPost:
                textViewHeading.text = ""
                textViewHeading.configureForHashTagDetection(true)
                textViewHeading.prependSender("FYM", senderId: "FYM")
                imageViewProfilePic.image = UIImage(named: "FymAdminLogo")
            }
            textViewHeading.hashTagTextViewDelegate = self
            
            if let layoutTextViewBodyHeight = layoutTextViewBodyHeight {
                viewNewsFeedHeader.removeConstraints(layoutTextViewBodyHeight)
            }
            
            // allows 2 lines now
            textViewHeading.sizeToFit()
            textViewHeading.layoutIfNeeded()
            
            // clip of more than 2 lines
            if textViewHeading.bounds.height > 53 {
                layoutTextViewBodyHeight = NSLayoutConstraint.constraintsWithVisualFormat("V:[textView(53)]", options: NSLayoutFormatOptions(), metrics: nil, views: ["textView": textViewHeading])
                
                if let layoutTextViewBodyHeight = layoutTextViewBodyHeight {
                    viewNewsFeedHeader.addConstraints(layoutTextViewBodyHeight)
                }
            }
        }
    }
    
    @IBAction func buttonShareClicked(sender: UIButton) {
        newsFeedCellDelegate?.buttonShare(newsFeed.getShareContent())
    }
    
    func didTapImageViewNewsFeedWithGesture(tapGesture: UITapGestureRecognizer) {
        enlargeImageNewsFeedDelegate?.enlargeImageView(self, imageViewNewsFeed: imageViewNewsFeedImage)
    }
    
    var newsFeedContent: NewsFeedContent! = .None {
        didSet {
            
            layoutBodyHeight.constant = 110
            layoutImageViewHeight.constant = 110
            imageViewNewsFeedImage.backgroundColor = UIColor.clearColor()
            viewNewsFeedBody.hidden = false
            
            // update cell header
            cellTopView.image = UIImage(named: "DashboardCellTop")
            
          
            let tapGesture = UITapGestureRecognizer(target: self, action: "didTapImageViewNewsFeedWithGesture:")
            tapGesture.delegate = self
            
            // add tap gesture to the food imageview
            imageViewNewsFeedImage.addGestureRecognizer(tapGesture)
            imageViewNewsFeedImage.userInteractionEnabled = true

            // no specific content
            if newsFeedContent == nil || !newsFeedContent.boolValue {
                // setup cell header and footer
                // no need for the middle portion
                // mainly for non news feed posts
                
                layoutBodyHeight.constant = 0
                layoutImageViewHeight.constant = 0
                imageViewNewsFeedImage.backgroundColor =  UIColor.clearColor()
                viewNewsFeedBody.hidden = true
                setNeedsUpdateConstraints()
                return
            }
            
            // both image and text
            if (newsFeedContent.contains(.Text)) && (newsFeedContent.contains(.Image)) {
                layoutImageViewWidth.constant = 110
                imageViewNewsFeedImage.backgroundColor = UIColor.blackColor()
                
                // text
                if newsFeedType == NewsFeedType.CheckinStatusPost {
                    hashTagTextView.setBusinessDirectoryData(newsFeed.checkinBusinessDirectoryName, businessDirectoryId: newsFeed.checkinBusinessDirectoryId)
                }
                else {
                    hashTagTextView.attributedText = NSAttributedString(string: newsFeed.data, attributes: [NSFontAttributeName: UIFont.helvetica(13)])
                    hashTagTextView.configureForHashTagDetection()
                }
                
                hashTagTextView.hashTagTextViewDelegate = self
                
                // image
                imageViewNewsFeedImage.setImageWithURL(NSURL(string: newsFeed.feedImage))
            }
                // text only
            else if (newsFeedContent.contains(.Text)) {
                
                // update cell header to remove line
                cellTopView.image = UIImage(named: "DashboardCellTopWithoutLine")
                
                layoutImageViewWidth.constant = 0
                imageViewNewsFeedImage.backgroundColor = UIColor.clearColor()
                
                // text
                hashTagTextView.attributedText = NSAttributedString(string: newsFeed.data, attributes: [NSFontAttributeName: UIFont.helvetica(13)])
                hashTagTextView.configureForHashTagDetection()
                hashTagTextView.hashTagTextViewDelegate = self
                
                // allows 2 lines now
                hashTagTextView.sizeToFit()
                hashTagTextView.layoutIfNeeded()
                
                // clip of more than 2 lines
                if hashTagTextView.bounds.height >= 110 {
                    layoutBodyHeight.constant = 110
                }
                else {
                    layoutBodyHeight.constant = hashTagTextView.bounds.height
                }
                
            }
                // image only
            else if (newsFeedContent.contains(.Image)) {
                layoutImageViewWidth.constant = 110
                imageViewNewsFeedImage.backgroundColor = UIColor.blackColor()
                
                // image
                imageViewNewsFeedImage.setImageWithURL(NSURL(string: newsFeed.feedImage))
            }
            else {
                //print("XXX invalid news feed content type")
            }
        }
    }
    
    var newsFeed = NewsFeed() {
        didSet {
            
            // check whether the feed is posted by the user
            buttonDelete.hidden = newsFeed.userId != AppConfiguration.sharedAppConfiguration.userDetails?.userId
            
            backgroundColor = UIColor.clearColor()
            
            imageViewProfilePic.layer.cornerRadius = imageViewProfilePic.frame.width / 2
            imageViewProfilePic.clipsToBounds = true
            
            if newsFeedType == NewsFeedType.CheckinStatusPost {
                newsFeed.feedImage = newsFeed.checkinBusinessDirectoryImage
            }
            
            // set content mode
            newsFeedContent = .None
            newsFeedContent = newsFeed.newsFeedContent
            
            // set newsfeed type
            newsFeedType = newsFeed.newsFeedType
            
            labelTime.text = newsFeed.created.timeAgo()
            
            buttonLike.selected = newsFeed.isLiked
            buttonInspire.selected = newsFeed.isInspired
            
            buttonLike.setAttributedTitle(newsFeed.stringLikeCount, forState: UIControlState.Normal)
            buttonInspire.setAttributedTitle(newsFeed.stringInspireCount, forState: UIControlState.Normal)
            buttonComments.setAttributedTitle(newsFeed.stringCommentCount, forState: UIControlState.Normal)
            
            imageViewProfilePic.gestureRecognizers = [UITapGestureRecognizer(target: self, action: "imageViewProfilePicTapped:")]
        }
    }
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func configureCellHeader() {
        
    }
    
    func configureCellFooter() {
        
    }
    
    func configureCellBody() {
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        textViewHeading.text = ""
        hashTagTextView.text = ""
        imageViewNewsFeedImage.image = nil
        newsFeedType = nil
    }
    
    func hashTagTextView(hashTagTextView: HashTagTextView, didSelectHashTag hashTag: String) {
        
        // abort if no network
        if !isNetworkReachable { return }
        
        newsFeedCellDelegate?.newsFeedCell(self, didSelectHashTag: hashTag)
    }
    
    func hashTagTextView(hashTagTextView: HashTagTextView, didSelectUser user: String) {
        
        // abort if no network
        if !isNetworkReachable { return }
        
        // dont forward user selection for guest posts
        if newsFeed.newsFeedType == .GuestPost { return }
        
        // forward the user selection
        newsFeedCellDelegate?.newsFeedCell(self, didSelectUser: user)
    }
    
    func hashTagTextView(hashTagTextView: HashTagTextView, didSelectBusinessDirectory businessDirectory: String) {
        
        // abort if no network
        if !isNetworkReachable { return }
        
        newsFeedCellDelegate?.newsFeedCell(self, didSelectBusinessDirectory: businessDirectory)
    }
    
    func imageViewProfilePicTapped(sender: UITapGestureRecognizer) {
        
        // abort if no network
        if !isNetworkReachable { return }
        
        // dont forward user selection for guest posts
        if newsFeed.newsFeedType == .GuestPost { return }
        
        // forward the user selection
        newsFeedCellDelegate?.newsFeedCell(self, didSelectUser: currentUserId)
    }
    
    @IBAction func buttonActionLike(sender: UIButton) {
        
        // abort if no network
        if !isNetworkReachable { return }
        
        // invert selection
        sender.selected = !sender.selected
        buttonLike.setAttributedTitle(newsFeed.likeText(sender.selected ? newsFeed.likeCount + 1 : newsFeed.likeCount - 1), forState: UIControlState.Normal)
        
        // disable the button until the request expires
        sender.userInteractionEnabled = false
        
        newsFeed.like(sender.selected) { (newsFeed, error) -> () in
            
            // reenable the button
            sender.userInteractionEnabled = true
            
            self.newsFeed = newsFeed
            if error == nil {
                self.newsFeedCellDelegate?.newsFeedCell(self, didLikeNewsFeed: sender.selected)
            }
        }
    }
    
    @IBAction func buttonActionInspire(sender: UIButton) {
        
        // abort if no network
        if !isNetworkReachable { return }
        
        // invert selection
        sender.selected = !sender.selected
        buttonInspire.setAttributedTitle(newsFeed.inspireText(sender.selected ? newsFeed.inspireCount + 1 : newsFeed.inspireCount - 1), forState: UIControlState.Normal)
        
        // disable the button until the request expires
        sender.userInteractionEnabled = false
        
        newsFeed.inspire(sender.selected) { (newsFeed, error) -> () in
            
            // reenable the button
            sender.userInteractionEnabled = true
            
            self.newsFeed = newsFeed
            if error == nil {
                self.newsFeedCellDelegate?.newsFeedCell(self, didInspireNewsFeed: sender.selected)
            }
        }
    }
    
    @IBAction func buttonActionComments(sender: UIButton) {
        
        // abort if no network
        if !isNetworkReachable { return }
        
        newsFeedCellDelegate?.buttonActionComments(newsFeed)
    }
    
    @IBAction func buttonActionDelete(sender: AnyObject) {
        newsFeedCellDelegate?.newsFeedCell(self, didDeleteNewsFeed: true)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    
}
