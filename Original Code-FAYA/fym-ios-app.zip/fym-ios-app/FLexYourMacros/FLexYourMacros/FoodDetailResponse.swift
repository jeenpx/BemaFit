//
//  FoodDetailResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 09/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FoodDetailResponse: NSObject {
    
    var metaModel = MetaModel()
    var food = FoodListModel()
    var barcode = ""
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
        responseMapping.addPropertyMapping(metaModelMapping)
        
        // foods mapping
        let foodModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathFood, toKeyPath: "food", withMapping: FoodListModel.objectMapping)
        responseMapping.addPropertyMapping(foodModelMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let foodDetailResponseDescriptor = RKResponseDescriptor(mapping: FoodDetailResponse.responseMapping, method: .Any, pathPattern: Constants.ServiceConstants.kFoodDetailUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return foodDetailResponseDescriptor
    }
    
    class func fetchBarcodeFood(barcode: String, completionHandler: (food: Food?, error: String?) -> ()) {
        
        RestKitManager.setToken(true)
        
        let foodDetailResponse = FoodDetailResponse()
        foodDetailResponse.barcode = barcode
        
        RestKitManager.sharedManager().getObject(foodDetailResponse, path: nil, parameters: nil, success: { (operation, mappingResult) in
            
            // map to correct datamodel
            let response = mappingResult.firstObject as! FoodDetailResponse
            
            if response.metaModel.responseCode != 200 {
                
                completionHandler(food: nil, error: &&"no_barcode")
                return
            }
            
            // fire completion handler
            completionHandler(food: Food(foodListModel: response.food), error: nil)
            
            }) { (operation, error) -> Void in
                // error
               // completionHandler(food: nil, error: error)
        }
    }
}
