//
//  DailyMealPlanSelectNutritionViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 11/19/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class SelectNutritionPlanCell: UITableViewCell {
    
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelDescription: UILabel!
    
    var nutritionPlan: NutritionPlanModel? {
        didSet {
            labelTitle.text = nutritionPlan?.nutritionName
            labelDescription.text = nutritionPlan?.nutritionDescription
        }
    }
    
    var isNutritionSelected = false {
        didSet {
            accessoryType = isNutritionSelected ? .Checkmark : .None
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}

class DailyMealPlanSelectNutritionViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    struct StoryBoard {
        struct CellIdentifiers {
            static let SelectNutritionPlanCellIdentifier = "kSelectNutritionPlanCell"
        }
    }
    
    var nutritionPlans: [NutritionPlanModel]? {
        didSet {
            selectedNutritionPlan = nutritionPlans?.filter { $0.nutritionId == FymUser.sharedFymUser.userNutritionType }.first
        }
    }
    
    var selectedNutritionPlan: NutritionPlanModel? {
        didSet {
            FymUser.sharedFymUser.userNutritionType  = selectedNutritionPlan!.nutritionId!
            DailyMealPlan.sharedDailyMealPlan.nutrionalPlanId = selectedNutritionPlan!.nutritionId!.intValue
            //print(FymUser.sharedFymUser.userNutritionType)
        }
    }
    
    var offscreenCells = [String: SelectNutritionPlanCell]()
    
    @IBOutlet weak var tableViewSelectNutrition: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // save user Nutrition Type
        if FymUser.sharedFymUser.userNutritionType == "" {
            if let nutritionId = AppConfiguration.sharedAppConfiguration.userDiet?.dietNutritionalPlan {
                FymUser.sharedFymUser.userNutritionType = nutritionId
            }
        }
        
        // save nutrition plans
        nutritionPlans = AppConfiguration.sharedAppConfiguration.nutritionPlans
        configureTableView()
        
    }
    
    func configureTableView() {
        
        // hide empty tableview cells
        tableViewSelectNutrition.tableFooterView = UIView(frame: CGRectZero)
        tableViewSelectNutrition.rowHeight = UITableViewAutomaticDimension
        tableViewSelectNutrition.estimatedRowHeight = 60
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let selectNutritionPlanCell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.SelectNutritionPlanCellIdentifier) as! SelectNutritionPlanCell
        
        selectNutritionPlanCell.nutritionPlan = nutritionPlans?[indexPath.row]
        selectNutritionPlanCell.isNutritionSelected = nutritionPlans?[indexPath.row] == selectedNutritionPlan
        
        selectNutritionPlanCell.setNeedsUpdateConstraints()
        selectNutritionPlanCell.updateConstraintsIfNeeded()

        return selectNutritionPlanCell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        selectedNutritionPlan = nutritionPlans?[indexPath.row]
        NSNotificationCenter.defaultCenter().postNotificationName("RefreshNutritionPlan", object: nil, userInfo: nil)

        tableView.reloadData()
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return AppConfiguration.sharedAppConfiguration.nutritionPlans.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        var cell = offscreenCells[StoryBoard.CellIdentifiers.SelectNutritionPlanCellIdentifier]
        if cell == nil {
            cell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.SelectNutritionPlanCellIdentifier) as? SelectNutritionPlanCell
            offscreenCells[StoryBoard.CellIdentifiers.SelectNutritionPlanCellIdentifier] = cell
        }
        
        cell?.nutritionPlan = nutritionPlans?[indexPath.row]
        
        cell?.setNeedsUpdateConstraints()
        cell?.updateConstraintsIfNeeded()
        cell?.bounds = CGRectMake(0.0, 0.0, CGRectGetWidth(tableViewSelectNutrition.bounds), CGRectGetHeight(cell!.bounds))
        
        cell?.setNeedsLayout()
        cell?.layoutIfNeeded()
        
        cell?.labelDescription.preferredMaxLayoutWidth = CGRectGetWidth(cell!.labelDescription.bounds)
        cell?.labelDescription.setNeedsUpdateConstraints()
        
        // Get the actual height required for the cell's contentView
        var height = cell?.contentView.systemLayoutSizeFittingSize(UILayoutFittingCompressedSize).height
        
        // Add an extra point to the height to account for the cell separator, which is added between the bottom
        // of the cell's contentView and the bottom of the table view cell.
        height = height! + 1
        return height!
    }
}
