//
//  DashboardViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 18/02/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

let kEnableDashboardNotification = "kEnableDashboardNotification"

class DashboardViewController: SLKTextViewController, MacroStatsViewDelegate, DashboardViewLogHeaderViewDelegate, NewsFeedCellDelegate , UITableViewDragLoadDelegate ,AdvertisementCellDelegate, EnlargeImageNewsFeedDelegate {
    
    // XXX fetch the hasttags here
    let hashTags = [String]()
    let users = [String]()
    
    // selected hashtag
    var hashTag = ""
    
    // list of news feeds
    var newsFeeds = [NewsFeed]() {
        didSet {
            tableView.reloadData()
        }
    }
    
    var advertisement = Advertisement() {
        didSet {
            tableView.reloadData()
        }
    }
    
    var macroDetails = MacroModel()
    
    // search results which is optional
    private var searchResults: [String]?
    
    // refresh control
    let refreshControl = UIRefreshControl()
    
    var isGesturePopEnabled = true
    
    var pageMeta = PageMetaModel()
    
    @IBOutlet private var macroStatsView: MacroStatsView!
    
    @IBOutlet weak var barButtonProgress: UIBarButtonItem!
    @IBOutlet weak var barButtonFriends: UIBarButtonItem!
    @IBOutlet weak var barButtonMessages: UIBarButtonItem!
    @IBOutlet weak var barButtonDirectory: UIBarButtonItem!
    
    @IBOutlet weak var barButtonDailyLog: UIBarButtonItem!
    
    @IBOutlet weak var barButtonMealPlan: UIBarButtonItem!
    
    var messageBadge: Int = 0 {
        didSet {
            barButtonMessages.shouldAnimateBadge = true
            barButtonMessages.shouldHideBadgeAtZero = true
            barButtonMessages.badgeOriginX = 25.0
            barButtonMessages.badgeOriginY = 0
            barButtonMessages.badgeValue = String(messageBadge)
            
        }
    }
    
    // reload confirmation status
    // will be false during image post navigation
    var shouldReload = true
    
    // handle push notification
    var shouldNavigateMessageDetails = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // localize tool bar images
        barButtonProgress.image = UIImage(named: &&"tab_progress")
        barButtonFriends.image = UIImage(named: &&"tab_friends")
        barButtonMessages.image = UIImage(named: &&"tab_messages")
        barButtonMealPlan.image = UIImage(named:&&"tab_mealPlan")
        barButtonDailyLog.image = UIImage(named: &&"tab_dailyLog")
        
        // configure the chat view
        configureView()
        
        // observe for dashboard enable notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "handleEnableDashboardNotification:", name: kEnableDashboardNotification, object: nil)
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        
        
        // enable dashboard
        enableDashboard()
        
        // we need a light status bar
        UIApplication.sharedApplication().statusBarStyle = .LightContent
        
        // configure toolbar
        configureToolBar()
        
        // configure macro stats view
        configureMacroStatsView()
        
        // fetch news feeds and reload table
        if shouldReload {
            
            // reset page meta data
            pageMeta = PageMetaModel()
            
            NewsFeed.fetchPublicNewsFeeds(pageMeta: pageMeta) { (newsFeeds, pageMeta) -> () in
                self.newsFeeds = newsFeeds
                self.pageMeta = pageMeta
                self.tableView.reloadData()
            }
        }
        else { shouldReload = true }
        
        // fetch advertisement
        Advertisement.latestAdvertisement("Newsfeed") { (advertisement) -> () in
            self.advertisement = advertisement
        }
        
        // get unread messages count
        MessageResponse.getMessages(0, andLimit: 1, andProgressHUD: false) { (messages, unreadCount) -> () in
            
            dispatch_async(dispatch_get_main_queue()) {
                
                if let count = unreadCount {
                    
                    // save unread count
                    self.messageBadge = count.intValue
                    self.barButtonMessages.badgePadding = 5
                    
                }
            }
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        dismissKeyboard(true)
        
        // hide toolbar
        hideToolBar()
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        // activate sliding gestures
        activateSlidingGesture()
        
        //        self.messageBadge = 20
        
    }
    
    func handleEnableDashboardNotification(sender: NSNotification) {
        enableDashboard()
    }
    
    func enableDashboard() {
        tableView.userInteractionEnabled = true
        textInputbar.userInteractionEnabled = true
        dashboardNavigationController?.toolbar.userInteractionEnabled = true
    }
    
    private func configureToolBar() {
        
        // show toolbar
        showToolbar()
    }
    
    private func configureMacroStatsView() {
        
        // setup macro stats view delegate
        macroStatsView.macroStatsViewDelegate = self
        
        MacroModel.refreshUserMacros(NSDate(), completionHnadler: { (achievedMacroGoal) -> () in
            self.macroStatsView.macroDetails = achievedMacroGoal
            self.macroDetails = achievedMacroGoal
        })
        
        // update the macrostats view transform
        macroStatsView.transform = tableView.transform
        
        // set macro stats view as the table header
        tableView.tableHeaderView = macroStatsView
    }
    
    func configureView() {
        
        // set basic properties for the view
        // XXX double check this
        bounces = true
        shakeToClearEnabled = true
        keyboardPanningEnabled = true
        shouldScrollToBottomAfterKeyboardShows = false
        inverted = false
        
        // setup tableview
        tableView.backgroundColor = UIColor.defaultGrayColor()
        tableView.separatorStyle = UITableViewCellSeparatorStyle.None
        tableView.registerNib(UINib(nibName: Storyboard.Nibs.NewsFeedCell, bundle: nil), forCellReuseIdentifier: Storyboard.CellIdentifiers.NewsFeedCellIdentifier)
        tableView.registerClass(AdvertisementCell.self, forCellReuseIdentifier: Storyboard.CellIdentifiers.AdvertisementCellIdentifier)
        
        // set estimated row height
        // XXX setting the lowest height now, recheck
        //        tableView.rowHeight = UITableViewAutomaticDimension
        
        // setup refresh control
        refreshControl.addTarget(self, action: "pullToRefresh:", forControlEvents: UIControlEvents.ValueChanged)
        refreshControl.tintColor = UIColor.grayColor()
        
        // add refresh control to the tableview
        tableView.addSubview(refreshControl)
        
        // set delegate for pull to refresh and load more
        tableView.setDragDelegate(self, refreshDatePermanentKey: "nil")
        
        // hide pull to refresh
        tableView.showRefreshView = false
        
        // show load more
        tableView.showLoadMoreView = true
        
        // tableview footer release text
        tableView.footerReleaseText = &&"release_to_load_more_status"
        
        // tableview footer pull up text
        tableView.footerPullUpText = &&"pull_down_to_load_more_status"
        
        //tableview footer loading text
        tableView.footerLoadingText = &&"loading_status"
        
        // setup textview
        textView.placeholder = &&"post_placeholder_text"
        textView.pastableMediaTypes = .None
        textView.refreshFirstResponder()
        textView.refreshInputViews()
        
        // setup buttons
        leftButton.setImage(UIImage(named: "CameraIcon"), forState: .Normal)
        rightButton.setTitle(&&"post_button_title", forState: .Normal)
        
        // setup textinputbar
        textInputbar.editorTitle.textColor = UIColor.darkGrayColor()
        
        textInputbar.editorLeftButton.tintColor = UIColor(red: 0, green: 122.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        textInputbar.editorRightButton.tintColor = UIColor(red: 0, green: 122.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        
        textInputbar.autoHideRightButton = false
        textInputbar.counterStyle = .Split
        textInputbar.counterPosition = SLKCounterPosition.Top
        textInputbar.maxCharCount = 160
        
        textView.text = "A really looooong textA really looooong textA really looooong textA really looooong textA really looooong textA really looooong textA really looooong text"
        
        textInputbar.setNeedsLayout()
        textInputbar.layoutIfNeeded()
        
        textView.text = ""
        
        textInputbar.setNeedsLayout()
        textInputbar.layoutIfNeeded()
        
        typingIndicatorView.canResignByTouch = true
        
        autoCompletionView.registerClass(NewsFeedCell.self, forCellReuseIdentifier: Storyboard.CellIdentifiers.AutoCompletionCellIdentifier)
        registerPrefixesForAutoCompletion(["#", "@"])
    }
    
    override func canPressRightButton() -> Bool {
        return super.canPressRightButton()
    }
    
    override func canShowAutoCompletion() -> Bool {
        
        // clear the search results array
        let autoCompletionList = foundPrefix == "#" ? hashTags : users
        searchResults = autoCompletionList
        
        // filter hashtags
        let predicate = NSPredicate(format: "SELF BEGINSWITH[C] %@", foundWord)
        if foundWord.characters.count > 0 {
            searchResults = autoCompletionList.filter {
                predicate.evaluateWithObject($0)
            }
        }
        
        // sort the search results
        if let _ = searchResults {
            (searchResults!).sortInPlace(<)
        }
        
        return searchResults?.count > 0
    }
    
    override func didPressLeftButton(sender: AnyObject!) {
        super.didPressLeftButton(sender)
        
        // hide keyboard to show actionsheet on top
        view.endEditing(true)
        
        // no need to reload data after picking image
        shouldReload = false
        
        // fetch image from image picker
        ImagePickerManager.sharedManager.presentImagePicker(self) { (image, source) -> () in
            self.textView.insertImage(image)
            dispatch_async(dispatch_get_main_queue()) {
                self.textView.becomeFirstResponder()
                self.textView.selectedRange = NSMakeRange(self.textView.text.characters.count, 0)
            }
        }
    }
    
    override func didPressRightButton(sender: AnyObject!) {
        
        // validate any pending auto-correction or auto-spelling
        textView.refreshFirstResponder()
        
        // create a new newsfeed
        textView.getInsertedImage { image in
            NewsFeed.create(self.textView.text, image: image) { (newsFeed, error) -> () in
                if error != nil {
                    // XXX handler error
                    return
                }
                
                // reload tableview with the new newsfeed
                dispatch_async(dispatch_get_main_queue()) {
                    
                    // update tableview
                    if let newsFeed = newsFeed {
                        self.tableView.beginUpdates()
                        self.newsFeeds = [newsFeed] + self.newsFeeds
                        self.tableView.insertRowsAtIndexPaths([NSIndexPath(forRow: 0, inSection: 0)], withRowAnimation: .Bottom)
                        self.tableView.endUpdates()
                        self.dismissKeyboard(true)
                    }
                }
            }
            
            // cleanup the textview (weird huh?)
            dispatch_async(dispatch_get_main_queue()) {
                self.textView.attributedText = nil
                self.textView.text = "   "
                self.textView.font = UIFont.systemFontOfSize(16)
                self.textView.slk_clearText(true)
            }
        }
        
        tableView.slk_scrollToTopAnimated(true)
        
        // call the super method in the end with some
        // additional cleanup to handle image insertions
        // super method will do the cleanup
        super.didPressRightButton(sender)
    }
    
    override func didPasteMediaContent(userInfo: [NSObject : AnyObject]!) {
        super.didPasteMediaContent(userInfo)
        
        // XXX do something related to image upload here
    }
    
    override func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if (tableView == self.tableView) {
            
            return CGFloat((newsFeeds[indexPath.row] as NewsFeed).contentHeight)
        }
        else {
            return 0.0
        }
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if (tableView == self.tableView) {
            return CGFloat((newsFeeds[indexPath.row] as NewsFeed).contentHeight)
        }
        else {
            return 0.0
        }
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == autoCompletionView {
            return searchResults?.count ?? 0
        }
        else {
            return newsFeeds.count //+ 1
        }
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell
        
        if tableView == self.tableView {
            cell = self.tableView(tableView, newsFeedCellForRowAtIndexPath: indexPath)
        } else {
            cell = self.tableView(tableView, autoCompletionCellForRowAtIndexPath: indexPath)
        }
        
        // update the cell transform
        cell.transform = tableView.transform
        
        return cell
    }
    
    func tableView(tableView:UITableView, adverstimentCellForRowAtIndexPath indexPath: NSIndexPath) -> AdvertisementCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifiers.AdvertisementCellIdentifier) as! AdvertisementCell
        // configure cell
        cell.advertisement = advertisement
        cell.advertisementCellDelegate = self;
        return cell
    }
    
    func tableView(tableView: UITableView, newsFeedCellForRowAtIndexPath indexPath: NSIndexPath) -> NewsFeedCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifiers.NewsFeedCellIdentifier) as! NewsFeedCell
        
        // configure cell
        cell.newsFeed = newsFeeds[indexPath.row]
        cell.newsFeedCellDelegate = self
        cell.enlargeImageNewsFeedDelegate = self
        
        return cell
    }
    
    func tableView(tableView: UITableView, autoCompletionCellForRowAtIndexPath indexPath: NSIndexPath) -> NewsFeedCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifiers.AutoCompletionCellIdentifier) as! NewsFeedCell
        
        // XXX configure cell here
        cell.textLabel?.text = searchResults![indexPath.row]
        
        return cell
    }
    
    override func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        // auto completion view header
        if tableView == autoCompletionView {
            let headerView = UIView()
            headerView.backgroundColor = autoCompletionView.separatorColor
            return headerView
        } else if tableView == self.tableView {
            // view log button header
            return DashboardViewLogHeaderView(delegate: self, advertisement: advertisement)
        } else {
            return nil
        }
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if tableView == autoCompletionView {
            return  0.5
        } else {
            return advertisement.shouldDisplayAdvertisement ? 100 : 30
        }
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        (cell as? NewsFeedCell)?.newsFeed = newsFeeds[indexPath.row]
        
        //        cell.layoutIfNeeded()
    }
    
    override func heightForAutoCompletionView() -> CGFloat {
        let cellHeight = CGFloat(44.0)
        let cellCount = CGFloat(searchResults?.count ?? 0)
        return cellHeight * cellCount
    }
    
    func pullToRefresh(sender: UIRefreshControl) {
        
        // reset page meta data
        pageMeta = PageMetaModel()
        
        // fetch news feeds and reload table
        NewsFeed.fetchPublicNewsFeeds(false, pageMeta: pageMeta) { (newsFeeds, pageMeta) -> () in
            self.newsFeeds = newsFeeds
            self.pageMeta = pageMeta
            self.refreshControl.endRefreshing()
            self.tableView.reloadData()
        }
    }
    
    // load more funcationality
    func dragTableDidTriggerLoadMore(tableView: UITableView!) {
        
        if !pageMeta.isValid {
            NSTimer.scheduledTimerWithTimeInterval(0.5, target: self, selector: "finishLoadMore", userInfo: nil, repeats: false)
            return
        }
        
        // fetch news feeds and reload table
        NewsFeed.fetchPublicNewsFeeds(offset: newsFeeds.count, pageMeta: pageMeta) { (newsFeeds, pageMeta) -> () in
            self.pageMeta = pageMeta
            self.newsFeeds += newsFeeds
            self.tableView.finishLoadMore()
        }
    }
    
    func dragTableLoadMoreCanceled(tableView: UITableView!) {
        // called when the load more is cancelled
        NSObject.cancelPreviousPerformRequestsWithTarget(self, selector: Selector("finishLoadMore"), object: nil)
    }
    
    func finishLoadMore() {
        tableView.finishLoadMore()
        tableView.reloadData()
    }
    
    func clickedOnAdHeader(urlString:String) {
        TermsViewController.openAdsInEmbedBrowser(self.navigationController, withUrl: urlString)
    }
    
    func buttonActionSideMenu(_: UIButton) {
        performSegueWithIdentifier(Storyboard.Segues.UnwindSideMenu, sender: self)
    }
    
    func infoButtonClicked(macroStatsView: MacroStatsView) {
        
        // present macro chart view
        let macroChartVC = self.storyboard?.instantiateViewControllerWithIdentifier("kMacroChartVC") as! MacroChartViewController
        macroChartVC.modalPresentationStyle = UIModalPresentationStyle.FormSheet
        macroChartVC.modalTransitionStyle = UIModalTransitionStyle.CoverVertical
        self.presentViewController(macroChartVC, animated: false, completion: nil)
        
        self.presentViewController(macroChartVC, animated: true, completion: nil)
    }
    
    func buttonActionViewLog(sender: DashboardViewLogHeaderView) {
        performSegueWithIdentifier(Storyboard.Segues.ViewLogSegue, sender: self)
    }
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didSelectHashTag hashTag: String) {
        self.hashTag = hashTag
        performSegueWithIdentifier(Storyboard.Segues.HashTagSegue, sender: self)
    }
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didSelectUser userId: String) {
        performSegueWithIdentifier(Storyboard.Segues.ProfileSegue, sender: userId)
    }
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didSelectBusinessDirectory businessDirectoryId: String) {
        DirectoryDetailViewController.loadDirectoryDetail(businessDirectoryId, fromViewcontroller: self)
    }
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didLikeNewsFeed like: Bool) {
        // do something after liking
    }
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didInspireNewsFeed inspire: Bool) {
        // do something after inspiring
    }
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didDeleteNewsFeed delete: Bool) {
        
        if delete {
            let cellIndexPath = tableView.indexPathForCell(newsFeedCell)
            let feedId = newsFeeds[cellIndexPath!.row].id
            
            let reachability = appDelegate!.internetReachable
            if !reachability {
                // no internet
                
                // alert
                AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                return
            }
            
            UIAlertView.showWithTitle(&&"delete_confirmation_title", message: &&"delete_confirmation_message", cancelButtonTitle: &&"ok_button_title", otherButtonTitles: [&&"cancel_button_title"], tapBlock: { (alertview : UIAlertView, buttonIndex : Int) in
                
                
                if buttonIndex == alertview.cancelButtonIndex{
                    
                    NewsFeedDeleteResponse.deleteNewsFeed(feedId, completionHandler: { (responseStatus) -> () in
                        if responseStatus == "OK" {
                            let feed = self.newsFeeds.filter({$0.id == feedId})
                            
                            // remove the feed
                            self.newsFeeds.remove(feed[0])
                            
                            // reload tableview
                            self.tableView.reloadData()
                        }
                    })
                    
                }
            })
            
            
            // delete the feed
        }
    }
    
    func buttonActionComments(newsFeed: NewsFeed) {
        performSegueWithIdentifier(Storyboard.Segues.NewsFeedCommentsSegue, sender: newsFeed)
    }
    
    func displayNewAd() -> () {
        Advertisement.latestAdvertisement("Newsfeed") { (advertisement) -> () in
            self.advertisement = advertisement
        }
    }
    
    func showAd(urlString: String) {
        TermsViewController.openAdsInEmbedBrowser(self.navigationController, withUrl: urlString)
    }
    
    func buttonShare(shareContent: FacebookShareModel) {
        NewsFeedShare.sharedManager.showActionSheet(true, fromViewController: self) { () -> (FacebookShareModel) in
            return shareContent;
        }
    }
    
    func clickedOnAd(urlString: String) {
        TermsViewController.openAdsInEmbedBrowser(self.navigationController, withUrl: urlString)
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        let userInteractionEnabled = slidingViewController?.currentTopViewPosition == ECSlidingViewControllerTopViewPosition.Centered
        
        tableView.userInteractionEnabled = userInteractionEnabled
        textInputbar.userInteractionEnabled = userInteractionEnabled
        dashboardNavigationController?.toolbar.userInteractionEnabled = userInteractionEnabled
    }
    
    override func gestureRecognizerShouldBegin(gestureRecognizer: UIGestureRecognizer) -> Bool {
        return isGesturePopEnabled
    }
    
    struct Storyboard {
        struct CellIdentifiers {
            static let NewsFeedCellIdentifier = "kNewsFeedCell"
            static let AutoCompletionCellIdentifier = "kAutoCompletionCell"
            static let AdvertisementCellIdentifier = "kAdvertisementCell"
        }
        struct Segues {
            static let ProfileSegue = "kMyProfileSlideSegue"
            static let MacroChartSegue = "kMacroChartSegue"
            static let NewsFeedCommentsSegue = "kNewsFeedCommentsSegue"
            static let HashTagSegue = "kHashTagSegue"
            static let ViewLogSegue = "kViewLogSegue"
            static let UnwindSideMenu = "kUnwindToSideMenu"
            static let MessagesSegue = "kDashboardMessagesSegue"
        }
        struct Nibs {
            static let NewsFeedCell = "NewsFeedCell"
        }
        struct Sections {
            static let AdvertisementSection = 0
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == Storyboard.Segues.HashTagSegue {
            let hashTagViewController = segue.destinationViewController as! HashTagViewController
            hashTagViewController.hashTag = hashTag
        }
        else  if segue.identifier == Storyboard.Segues.MacroChartSegue {
            let macroChartViewController = segue.destinationViewController as! MacroChartViewController
            macroChartViewController.macroDetails = macroDetails
        }
        else if segue.identifier == Storyboard.Segues.ProfileSegue {
            let profileViewController = segue.destinationViewController as! ProfileViewController
            profileViewController.userId = sender as? String ?? ""
        }
        else if segue.identifier == Storyboard.Segues.NewsFeedCommentsSegue {
            let newsFeedCommentsViewController = segue.destinationViewController as! NewsFeedCommentsViewController
            newsFeedCommentsViewController.newsFeed = sender as! NewsFeed
        }
        else if segue.identifier == Storyboard.Segues.ViewLogSegue {
            
            // check if sender is from exercise log screens
            let isFoodLogMode = !(sender is ExerciseStrengthLogViewController || sender is ExerciseCardioLogViewController || sender is SendDetailsViewController)
            
            let viewLogViewController = segue.destinationViewController as? ViewLogViewController
            viewLogViewController?.isFoodLogMode = isFoodLogMode
        }
        else if segue.identifier == Storyboard.Segues.MessagesSegue {
            let messagesViewController = segue.destinationViewController as! MessagesViewController
            
            if shouldNavigateMessageDetails {
                shouldNavigateMessageDetails = false
                messagesViewController.navigateMessageDetailsFriendId = sender as? String ?? ""
                messagesViewController.navigateMessageDetails = true
            }
        }
    }
    
    func enlargeImageView(selectedCell: NewsFeedCell, imageViewNewsFeed: UIImageView) {
        
        let imageInfo = JTSImageInfo()
        imageInfo.image = imageViewNewsFeed.image
        
        // imageInfo.imageURL = NSURL(string: food.image)
        imageInfo.referenceRect = imageViewNewsFeed.frame
        imageInfo.referenceView = imageViewNewsFeed.superview
        let imageViewController = JTSImageViewController(imageInfo: imageInfo, mode: .Image, backgroundStyle: .Scaled)
        
        // present the view controller.
        imageViewController.showFromViewController(self, transition: .FromOriginalPosition)
    }
    
    @IBAction func unwindToDashboardViewController(segue: UIStoryboardSegue) {
        // close the side menu if its open
    }
    
    @IBAction func barButtonActionMealPlan(sender: AnyObject) {
        let manageStoryboard = UIStoryboard(name: "DailyMealPlan", bundle: NSBundle.mainBundle())
        
        // instantiate the initial view controller
        let initialViewController = manageStoryboard.instantiateViewControllerWithIdentifier("kDailyMealPlanList") as! DailyMealPlanViewController
        
        dashboard?.navigationController?.pushViewController(initialViewController, animated: true)
        
    }
    
    @IBAction func barButtonActionDailyLog(sender: AnyObject) {
        
        let manageStoryboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        
        // instantiate the view controller
        let viewLogViewController = manageStoryboard.instantiateViewControllerWithIdentifier("kViewLog") as! ViewLogViewController
        viewLogViewController.isFoodLogMode = true
        dashboard?.navigationController?.pushViewController(viewLogViewController, animated: true)
    }
    
}
