//
//  ExerciseCreateResponse.swift
//  FlexYourMacros
//
//  Created by mini on 29/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _ExerciseCreateResponse = ExerciseCreateResponse()

class ExerciseCreateResponse: NSObject {
    
    var metaModel: MetaModel?
    var createdExercise: ExerciseTypeModel?
    
    class var sharedExerciseCreateResponse: ExerciseCreateResponse {
        return _ExerciseCreateResponse
    }
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(ExerciseCreateResponse.metaModelKeyMapping)
        
        //give reference to exercise model mapping
        responseMapping.addPropertyMapping(ExerciseCreateResponse.exerciseTypeModelKeyMapping)
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var exerciseTypeModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathExerciseTypeResult, toKeyPath: "createdExercise", withMapping: ExerciseTypeModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: responseMapping, method: .POST, pathPattern: Constants.ServiceConstants.ExerciseUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    
    class func createExercise(exercise: [String: String], completionHandler: (createdExerciseId: String, successful: Bool, message: String) -> ()) {
        
        RestKitManager.setToken(true)
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(nil, method: .POST, path: Constants.ServiceConstants.ExerciseUrl, parameters: exercise, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
        SVProgressHUD.show()

        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            SVProgressHUD.dismiss()

            let logResponse = mappingResult.firstObject as! ExerciseCreateResponse
            // check for success
            if logResponse.metaModel?.responseCode != 200 {
                
                completionHandler(createdExerciseId: "", successful: false, message: logResponse.metaModel!.message)
                return;
            }
            
            let returnedExercise = logResponse.createdExercise!
            
            completionHandler(createdExerciseId: returnedExercise.exerciseId, successful: true, message: logResponse.metaModel!.message)
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                SVProgressHUD.dismiss()

                completionHandler(createdExerciseId: "", successful: false, message: &&"failed_to_log_exercise_alert_message")

                //print("failed to create exercise with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
        
        
    }
    
}