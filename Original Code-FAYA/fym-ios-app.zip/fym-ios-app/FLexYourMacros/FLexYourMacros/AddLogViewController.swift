//
//  AddLogViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 07/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class AddLogViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        cell.setSeparatorInsetZero()
    }
    
}
