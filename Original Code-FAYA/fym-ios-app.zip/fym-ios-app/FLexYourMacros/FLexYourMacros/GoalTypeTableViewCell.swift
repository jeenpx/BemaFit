//
//  GoalTypeTableViewCell.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 18/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol GoalTypeCellDelegate {
    func goalTypeCell(goalTypeCell: GoalTypeTableViewCell, didSelectGoal goal: GoalModel)
}

class GoalTypeTableViewCell: UITableViewCell {

    @IBOutlet weak var buttonGoalType: UIButton!
    @IBOutlet weak var labelGoalValue: UILabel!
    let FYMUserModel = FymUser.sharedFymUser
    
    var goalTypeCellDelegate: GoalTypeCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    var itemIndex: Int = 0 {
        didSet {
        }
    }
    @IBAction func buttonActionGoal(sender: UIButton) {
        goalTypeCellDelegate?.goalTypeCell(self, didSelectGoal: goal)
    }
    
    var goal: GoalModel = GoalModel() {
        didSet {
            
            buttonGoalType.setTitle(goal.goalName, forState: .Normal)
            labelGoalValue.text = goal.goalCalorie > 0.0 ? NSString(format: "%.1f %@", goal.goalCalorie,&&"calorie_per_day") as String :  NSString(format: "-- %@",&&"calorie_per_day") as String
        }
    }
}
