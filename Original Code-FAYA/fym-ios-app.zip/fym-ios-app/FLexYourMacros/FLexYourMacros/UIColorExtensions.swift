//
//  UIColorExtensions.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 14/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

extension UIColor {
    
    class func blueColorForDMP() -> UIColor {
        // this color for the daily meal plan details page .code: #007afc
        return UIColor(red: 0.0/255.0, green: 122.0/255.0, blue: 252.0/255.0, alpha: 1.0)
    }
    
    class func defaultThemeBlueColor() -> UIColor {
        return UIColor(red: 40.0/255.0, green: 141.0/255.0, blue: 1.0, alpha: 1.0)
    }
    
    class func defaultThemeDarkBlueColor() -> UIColor {
        return UIColor(red: 79.0/255.0, green: 132.0/255.0, blue: 196.0/255.0, alpha: 1.0)
    }
    
    class func defaultGrayColor() -> UIColor {
        return UIColor(red: 220.0/255.0, green: 220.0/255.0, blue: 220.0/255.0, alpha: 1.0)
    }
    
    class func pickerGrayColor() -> UIColor {
        return UIColor(red: 114.0/255.0, green: 114.0/255.0, blue: 114.0/255.0, alpha: 1.0)
    }
    
    class func lightTextGrayColor() -> UIColor {
        return UIColor(red: 175.0/255.0, green: 175.0/255.0, blue: 175.0/255.0, alpha: 1.0)
    }
    
    class func darkTextGrayColor() -> UIColor {
        return UIColor(red: 114.0/255.0, green: 114.0/255.0, blue: 114.0/255.0, alpha: 1.0)
    }
    
    class func grayColorDirectory() -> UIColor {
        return UIColor(red: 224.0/255.0, green: 224.0/255.0, blue: 224.0/255.0, alpha: 1.0)
    }
    
    class func lightBlackColor() -> UIColor {
        return UIColor.color(44, green: 44, blue: 44, alpha: 1)
    }
    class func lightGrayColorButtonRefersh() -> UIColor{
        return UIColor.hx_colorWithHexString("#D9D9D9")!
    }
    
    class func color(red: Int, green: Int, blue: Int, alpha: Float = 1.0) -> UIColor {
        return UIColor(red: CGFloat(Double(red)/255.0), green: CGFloat(Double(green)/255.0), blue: CGFloat(Double(blue)/255.0), alpha: CGFloat(alpha))
    }
}