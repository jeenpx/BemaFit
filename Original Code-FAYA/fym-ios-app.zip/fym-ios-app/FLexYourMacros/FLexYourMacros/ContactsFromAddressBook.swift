//
//  SearchFromAddressBook.swift
//  FlexYourMacros
//
//  Created by DBG on 27/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit
import AddressBook
class ContactsFromAddressBook: NSObject {
    
    var contactList: [String: String] = [:]
    
    var addressBook: ABAddressBookRef!
    
    func extractABAddressBookRef(abRef: Unmanaged<ABAddressBookRef>!) -> ABAddressBookRef? {
        if let ab = abRef {
            return Unmanaged<NSObject>.fromOpaque(ab.toOpaque()).takeUnretainedValue()
        }
        return nil
    }
    
    func fetchDetailsFromContacts() {
        if (ABAddressBookGetAuthorizationStatus() == ABAuthorizationStatus.NotDetermined) {
            //print("requesting access...")
            var errorRef: Unmanaged<CFError>? = nil
            let   addressBook: ABAddressBookRef? = extractABAddressBookRef(ABAddressBookCreateWithOptions(nil, &errorRef))
            ABAddressBookRequestAccessWithCompletion(addressBook, { success, error in
                if success {
                    
                    self.processContactNames();
                    
                    
                }
                else {
                    //print("error")
                }
            })
        }
        else if (ABAddressBookGetAuthorizationStatus() == ABAuthorizationStatus.Denied || ABAddressBookGetAuthorizationStatus() == ABAuthorizationStatus.Restricted) {
            //print("access denied")
        }
        else if (ABAddressBookGetAuthorizationStatus() == ABAuthorizationStatus.Authorized) {
            //print("access granted")
            //self.getContactNames()
            self.processContactNames();
        }
    }
    
    
    
    func processContactNames()
    {
        var errorRef: Unmanaged<CFError>?
        let addressBook: ABAddressBookRef? = extractABAddressBookRef(ABAddressBookCreateWithOptions(nil, &errorRef))
        
        let contactList: NSArray = ABAddressBookCopyArrayOfAllPeople(addressBook).takeRetainedValue()
        //print("records in the array \(contactList.count)")
        
        for record:ABRecordRef in contactList {
            processAddressbookRecord(record)
        }
    }
    
    
    
    
    
    func processAddressbookRecord(addressBookRecord: ABRecordRef) {
        let contactName: String = ABRecordCopyCompositeName(addressBookRecord).takeRetainedValue() as NSString as String
        NSLog("contactName: \(contactName)")
        processEmail(addressBookRecord,name: contactName)
    }
    
    func processEmail(addressBookRecord: ABRecordRef,name:String) {
        
        let emailArray:ABMultiValueRef = extractABEmailRef(ABRecordCopyValue(addressBookRecord, kABPersonEmailProperty))!
        /*   for (var j = 0; j < ABMultiValueGetCount(emailArray); ++j) {
        var emailAdd = ABMultiValueCopyValueAtIndex(emailArray, j)
        myString = extractABEmailAddress(emailAdd)
        
        contactList[name] = myString
        
        NSLog("email: \(myString!)")
        }
        */
        if(ABMultiValueGetCount(emailArray)>0)
        {
            let emailAdd = ABMultiValueCopyValueAtIndex(emailArray, 0)
            let  myString = extractABEmailAddress(emailAdd)
            contactList[name] = myString
            NSLog("email: \(myString!)")
        }
        
        
        
    }
    
    
    
    func extractABEmailRef (abEmailRef: Unmanaged<ABMultiValueRef>!) -> ABMultiValueRef? {
        if let ab = abEmailRef {
            return Unmanaged<NSObject>.fromOpaque(ab.toOpaque()).takeUnretainedValue()
        }
        return nil
    }
    
    func extractABEmailAddress (abEmailAddress: Unmanaged<AnyObject>!) -> String? {
        return Unmanaged.fromOpaque(abEmailAddress.toOpaque()).takeUnretainedValue() as CFStringRef as String
    }
    
    
}
