//
//  LogProgressViewController.swift
//  FlexYourMacros
//
//  Created by mini on 18/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//
import UIKit
import Foundation

class LogProgressViewController: UITableViewController, UITextFieldDelegate{

    
    
    @IBOutlet weak var textFieldWeight: UITextField!
    @IBOutlet weak var textFieldBodyFat: UITextField!
    var currentTextfield: UITextField!
    var logDate = NSDate()
    
    @IBOutlet weak var labelLastLoggedDate: UILabel!
    
    struct Storyboard {
        
        struct Segues {
            static let Progress  = "kUnwindProgress"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textFieldWeight.becomeFirstResponder()
        //load the last log date
        loadProgressLastLogDetails()
        
        let titleDictionary: NSDictionary = [NSForegroundColorAttributeName: UIColor.whiteColor()]
        self.navigationController?.navigationBar.titleTextAttributes = titleDictionary as? [String : AnyObject]
    }
    
    var progressType: ProgressType = ProgressType.Weight
    
    func loadProgressLastLogDetails() {
        
        ProgressLastLog.fetchProgressLastLogDetails(progressType.description, completionHandler: { (lastLogDetails) -> () in
            
            if lastLogDetails.isEmpty {
                return
            }
            let lastLogArray: [ProgressLastLog] = lastLogDetails.map({
                return $0 as! ProgressLastLog
            })
            
            if lastLogArray.isEmpty {
                
                return
            }
            let currentLog = lastLogArray.first
            
            if currentLog?.log_date == "" {
                self.labelLastLoggedDate.text = ""
                return
            }
            
            let dateString = currentLog!.log_date.dateValue("yyyy-MM-dd", dateStyle: nil)!.stringValue("dd/MM/yy", dateStyle: nil, showToday: false)
            self.labelLastLoggedDate.text = &&"last_logged" + " " + "\(dateString)"
            self.textFieldBodyFat.text = currentLog?.body_fat
            self.textFieldWeight.text = currentLog?.weight
        })
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    //log weight and fat
    @IBAction func logAction(sender: UIBarButtonItem) {
       
        currentTextfield?.resignFirstResponder()
        
        if textFieldWeight.text!.isEmpty || textFieldWeight.text?.doubleValue <=  0.0{
            
            if #available(iOS 8.0, *) {
                
                let alert = UIAlertController(title: &&"notice", message: &&"enter_weight_request", preferredStyle: .Alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
                self.presentViewController(alert, animated: true, completion: nil)
            } else {
                // Fallback on earlier versions
                
                UIAlertView(title: &&"notice", message: &&"enter_weight_request", delegate: nil, cancelButtonTitle: "ok").show()
            }
        }else if textFieldBodyFat.text!.isEmpty || textFieldBodyFat.text?.doubleValue <=  0.0 {
            
            if #available(iOS 8.0, *) {
                
                let alert = UIAlertController(title: &&"notice", message: &&"enter_bodyfat_request", preferredStyle: .Alert)
                
                alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
                
                self.presentViewController(alert, animated: true, completion: nil)
            } else {
                // Fallback on earlier versions
                
                UIAlertView(title: &&"notice", message: &&"enter_bodyfat_request", delegate: nil, cancelButtonTitle: "ok").show()
            }
            return;
        }  else {
            
            let reachability = appDelegate!.internetReachable
            
            if !reachability {
                
                UIAlertView(title: &&"alert_network_title", message: &&"alert_network_message", delegate: nil, cancelButtonTitle: "ok").show()
                return
            }
            
            ProgressLogWeightAndFatResponse.postWeightandBodyFat(requestDate, weight: textFieldWeight.text!, bodyFat: textFieldBodyFat.text!, completionHandler: { (successful) -> () in
                self.textFieldBodyFat.text = ""
                self.textFieldWeight.text = ""
              
                self.performSegueWithIdentifier(Storyboard.Segues.Progress, sender: nil)
                
        
            })
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        
        if segue.identifier == Storyboard.Segues.Progress {
            
            let progressViewController = segue.destinationViewController as! ProgressViewController
            progressViewController.progressType = progressType
        }
    }
    
    var requestDate: String {
        
        //webcall prepare the request date in for yyyy-mm-dd from the current date
        let components = NSCalendar.currentCalendar().components([.Day, .Month, .Year], fromDate: NSDate())
        return "\(components.year)"+"-"+"\(components.month)"+"-"+"\(components.day)"
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        currentTextfield = textField
    }
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField .resignFirstResponder()
        return true
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        var result = true
        let prospectiveText = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        if string.characters.count > 0 {
            let disallowedCharacterSet = NSCharacterSet(charactersInString: "0123456789.").invertedSet
            let replacementStringIsLegal = string.rangeOfCharacterFromSet(disallowedCharacterSet) == nil
            let resultingStringLengthIsLegal = prospectiveText.characters.count <= 6
            let scanner = NSScanner(string: prospectiveText)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
            result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
        }
        return result
    }

    @IBAction func backAction(sender: UIButton) {
        //dismiss view controller
        self.navigationController?.popViewControllerAnimated(true)    }
}