//
//  AdvertisementCell.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 10/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol AdvertisementCellDelegate {
   
    func clickedOnAd(urlString:String)
    
}

class AdvertisementCell: UITableViewCell {
    
    var advertisementCellDelegate:AdvertisementCellDelegate?
    
    var advertisement: Advertisement! {
        didSet {
            configureView()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func configureView() {
        var activityIndicator = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 25, height: 25)
        activityIndicator.startAnimating()
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.color = UIColor.clearColor()
        addSubview(activityIndicator)
  
        backgroundColor = UIColor.clearColor()
        
        // constrain for the activity indicator
        let constX:NSLayoutConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.CenterX, relatedBy: NSLayoutRelation.Equal, toItem: self, attribute: NSLayoutAttribute.CenterX, multiplier: 1.0, constant: 0.0);
        self.addConstraint(constX);
        
        let constY:NSLayoutConstraint = NSLayoutConstraint(item: activityIndicator, attribute: NSLayoutAttribute.CenterY, relatedBy: NSLayoutRelation.Equal, toItem: self, attribute: NSLayoutAttribute.CenterY, multiplier: 1.0, constant: 0.0);
        self.addConstraint(constY);
        
        // check if ad image is empty
        if advertisement.shouldDisplayAdvertisement {
            activityIndicator.color = UIColor.whiteColor()
        }else {
            activityIndicator.color = UIColor.clearColor()
        }
        
        // add advertisement image
        if let imageURL = advertisement.imageURL {
            
            let imageView = UIImageView(frame: frame)
            imageView.setImageWithURL(imageURL, placeholderImage: nil)
            imageView.contentMode = UIViewContentMode.ScaleToFill

            //imageView.image = UIImage(named: "DashboardCellTop")
            
            addSubview(imageView)
            
            // set constraints for the imageview
            imageView.translatesAutoresizingMaskIntoConstraints = false
            self.addConstraints([NSLayoutConstraint(item: imageView, attribute: .Left, relatedBy: .Equal,
                toItem: self, attribute: .Left, multiplier: 1.0, constant: 5.0),
                NSLayoutConstraint(item: imageView, attribute: .Right, relatedBy: .Equal,
                    toItem: self, attribute: .Right, multiplier: 1.0, constant: -5.0), NSLayoutConstraint(item: imageView, attribute: .Bottom, relatedBy: .Equal,
                        toItem: self, attribute: .Bottom, multiplier: 1.0, constant: -5.0), NSLayoutConstraint(item: imageView, attribute: .Top, relatedBy: .Equal,
                            toItem: self, attribute: .Top, multiplier: 1.0, constant: 10.0)])
            
            imageView.layer.masksToBounds = true
            imageView.layer.cornerRadius = 10
            
            // add tap gesture
            let tapGesture = UITapGestureRecognizer(target: self, action: "imageViewTapped:")
            imageView.userInteractionEnabled = true
            imageView.addGestureRecognizer(tapGesture)
        }

    }
    
    func imageViewTapped(tapGestureRecognizer: UITapGestureRecognizer) {
        // append http and open the url
        
        self.advertisementCellDelegate?.clickedOnAd(advertisement.content!)
    }
}
