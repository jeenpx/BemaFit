//
//  UserMacroFormulaeViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 05/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

enum MacroFormula: String {
    case Physique = "physique"
    case LeanMass = "lean_mass"
    
    static var types = [Physique, LeanMass]
}

class UserMacroFormulaeViewController: UITableViewController, UIAlertViewDelegate {
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    struct StoryBoard {
        
        struct CellIdentifiers {
            static let HeaderCell       =  "kHeaderCell"
            static let ActivityCell     =  "kActivityCell"
        }
    }
    
    @IBOutlet weak var buttonFitPhysique: UIButton!
    @IBOutlet weak var buttonLeanMass: UIButton!
    @IBOutlet weak var buttonChooseFormula: UIButton!
    @IBOutlet var formulaInfoView: UIView!
    
    var currentIndexPath: NSIndexPath?
    let FymUserModel = FymUser.sharedFymUser
    var activityLevels = [ActivityLevelModel]()
    
    private var macroFormula = MacroFormula.Physique {
        didSet {
            
            //print("macro raw value ----\(macroFormula.rawValue)")
            FymUserModel.formulaType = macroFormula.rawValue
        }
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        buttonLeanMass.layer.borderWidth = 1.0
        buttonFitPhysique.layer.borderWidth = 1.0
        
        activityLevels = AppConfiguration.sharedAppConfiguration.activityLevels
        
        // set default user values
        if FymUserModel.formulaType == "" {
            macroFormula = MacroFormula.Physique
        }
        if (FymUserModel.userActivityLevelId == "") {
            FymUserModel.userActivityLevelId = activityLevels[0].activityId!
        }
        
        let selectedButton = FymUserModel.formulaType == MacroFormula.Physique.rawValue ? buttonFitPhysique : buttonLeanMass
        buttonActionFormulaSelection(selectedButton)
        
        if UIScreen.mainScreen().bounds.width <= 320 {
            
            formulaInfoView.frame = CGRectMake(formulaInfoView.frame.origin.x, formulaInfoView.frame.origin.y, formulaInfoView.frame.size.width, 305)
        } else if UIScreen.mainScreen().bounds.width == 375 {
            formulaInfoView.frame = CGRectMake(formulaInfoView.frame.origin.x, formulaInfoView.frame.origin.y, formulaInfoView.frame.size.width, 280)
        } else {
            formulaInfoView.frame = CGRectMake(formulaInfoView.frame.origin.x, formulaInfoView.frame.origin.y, formulaInfoView.frame.size.width, 250)
        }
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        if (segue.identifier == "kGoalSet") {
        }
    }
    
    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool {
        return checkAllFields()
    }
    
    func checkAllFields() -> Bool {
        return true
    }
    
    @IBAction func buttonActionPopUpClosed(sender: AnyObject) {
        // dismiss all popups
        KLCPopup.dismissAllPopups()
    }
    
    @IBAction func buttonActionFormulaDetails(sender: UIButton) {
        
        // set frame for the popup content view
        formulaInfoView.frame = CGRectMake(0, 0, CGRectGetWidth(view.bounds) - 20, CGRectGetHeight(formulaInfoView.frame))
        // set layout of the popup
        let layout = KLCPopupLayoutMake(.Center, .Center)
        // set contentview for the popup
        let popup = KLCPopup(contentView: formulaInfoView)
        popup.showWithLayout(layout)
    }
    
    func textFieldShouldReturn(textField: UITextField!) -> Bool {
        // resign keyboard
        textField.resignFirstResponder()
        return false
    }
    
    @IBAction func unwindToUserMacroFormulaeViewController(segue: UIStoryboardSegue) {
        self.navigationController?.navigationBarHidden = false
        
    }
    
    //MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return activityLevels.count
    }
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40.0
    }
    override func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView: UIView = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.HeaderCell)!
        return headerView
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell: ActivityLevelTableViewCell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.ActivityCell, forIndexPath: indexPath) as! ActivityLevelTableViewCell
        
        let currentActivity = activityLevels[indexPath.row] as ActivityLevelModel
        
        if currentActivity.activityId == FymUserModel.userActivityLevelId {
            // set the first row selected
            cell.accessoryType = UITableViewCellAccessoryType.Checkmark
        } else {
            cell.accessoryType = UITableViewCellAccessoryType.None
        }
        
        cell.labelActivityTitle.text = currentActivity.activityName
        cell.labelActivityDescription.text = currentActivity.activityDescription
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        // assign the activity level value to the user model
        let currentActivity = activityLevels[indexPath.row] as ActivityLevelModel
        FymUserModel.userActivityLevelId = currentActivity.activityId!
        self.tableView .reloadData()
    }
    
    @IBAction func buttonActionFormulaSelection(sender: UIButton) {
        
        switch sender.tag {
        case 20:
            
            macroFormula = MacroFormula.Physique
            buttonLeanMass.backgroundColor = UIColor.clearColor()
            buttonLeanMass.layer.borderColor = UIColor.darkGrayColor().CGColor
            buttonLeanMass.setTitleColor(UIColor.darkGrayColor(), forState: .Normal)
            
        case 21:
            
            // check whether user entered the fat loss percentage
            if FymUserModel.userFatLoss == "" {
                // if not entered pops up alert and make user navigate to that page to enter the details
                if #available(iOS 8.0, *) {
                    let alert = UIAlertController(title: &&"notice", message: &&"enter_bodyfat_percent_alert_message", preferredStyle: .Alert)
                    alert.addAction(UIAlertAction(title: &&"cancel", style: .Cancel, handler: nil))
                    alert.addAction(UIAlertAction(title: &&"go_back_alert_button_title", style: .Default) {
                        _ in
                        // pop the view controller
                        self.navigationController!.popViewControllerAnimated(true)
                        })
                    self.presentViewController(alert, animated: true, completion: nil)
                    return
                } else {
                    // Fallback on earlier versions
                    UIAlertView(title: &&"notice", message: &&"enter_bodyfat_percent_alert_message", delegate: self, cancelButtonTitle: &&"cancel", otherButtonTitles: &&"go_back_alert_button_title").show()
                    return
                }
                
                
            }
            
            macroFormula = MacroFormula.LeanMass
            buttonFitPhysique.backgroundColor = UIColor.clearColor()
            buttonFitPhysique.layer.borderColor = UIColor.darkGrayColor().CGColor
            buttonFitPhysique.setTitleColor(UIColor.darkGrayColor(), forState: .Normal)
        default :
            break
        }
        sender.backgroundColor = UIColor.defaultThemeBlueColor()
        sender.layer.borderColor = UIColor.defaultThemeBlueColor().CGColor
        sender.setTitleColor(UIColor.whiteColor(), forState: .Normal)
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    @IBAction func buttonActionBack(sender: UIBarButtonItem) {
        self.navigationController?.popViewControllerAnimated(false)
        
    }
    // alert view delegate methods
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        if buttonIndex == 1 {
            self.navigationController!.popViewControllerAnimated(true)
        }
    }
    
}
