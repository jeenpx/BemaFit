//
//  ExerciseCategoryResponse.swift
//  FlexYourMacros
//
//  Created by mini on 05/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

//exercise category model
class ExerciseCategoryModel: NSObject {
    
    var exerciseCategoryId: String = ""
    var exerciseCategoryName: String = ""
    var statusId: String = ""
    
    class var objectMapping: RKObjectMapping {
        let exerciseMapping = RKObjectMapping(forClass: self)
        exerciseMapping.addAttributeMappingsFromDictionary(mappingDictionary)
        return exerciseMapping
    }
    
    class var mappingDictionary: [String : String] {
        return(["id":"exerciseCategoryId", "name":"exerciseCategoryName", "status_id":"statusId"])
    }
    
    class func getExerciseCategories(completionHandler:(exerciseCategories: [ExerciseCategoryModel])->()) {
        
        //get exercise categories
        ExerciseCategoryResponse.fetchExerciseCategories { (exerciseCategories) -> () in
            completionHandler(exerciseCategories: exerciseCategories)
        }
    }
    
}

private let _ExerciseCategoryResponse = ExerciseCategoryResponse()

class ExerciseCategoryResponse: NSObject {
    
    var metaModel: MetaModel?
    var exerciseCategories: [ExerciseCategoryModel]?
    
    class var sharedExerciseCategoryResponse: ExerciseCategoryResponse {
        return _ExerciseCategoryResponse
    }
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(ExerciseCategoryResponse.metaModelKeyMapping)
        
        // give reference to ProgressTypeMapping
        responseMapping.addPropertyMapping(ExerciseCategoryResponse.exerciseCategoryModelKeyMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var exerciseCategoryModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathExerciseTypeResult, toKeyPath: "exerciseCategories", withMapping: ExerciseCategoryModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: responseMapping, method: .GET, pathPattern: Constants.ServiceConstants.ExerciseCategoryUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    class func fetchExerciseCategories(completionHandler:(exerciseCategories: [ExerciseCategoryModel])->()) {
        
        RestKitManager.setToken(true)
        // get the objects from the path login
        RestKitManager.sharedManager().getObjectsAtPath(Constants.ServiceConstants.ExerciseCategoryUrl, parameters: ["locale" : "\(NSLocale.currentLocale().objectForKey(NSLocaleLanguageCode)!)"], success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            
            // get the user response
            let response = mappingResult.firstObject as! ExerciseCategoryResponse
            
            //check for success
            if response.metaModel?.responseCode != 200 {
                return;
            }
            let exercisecategories = response.exerciseCategories!
            
           completionHandler(exerciseCategories: exercisecategories)
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                //print("failed to load masterdata with error \(error)")
        })
    }
    
}