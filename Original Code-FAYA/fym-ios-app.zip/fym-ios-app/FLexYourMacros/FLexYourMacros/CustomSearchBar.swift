//
//  CustomSearchBar.swift
//  FlexYourMacros
//
//  Created by mini on 09/07/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class CustomSearchBar: UISearchBar {

    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        let arrayTextFields = self.subviews.first?.subviews.filter { $0.isKindOfClass(UITextField) }
        
        if arrayTextFields!.isEmpty { return }
        
        let textField = arrayTextFields!.first as? UITextField
        textField?.layer.borderColor = UIColor.lightGrayColor().CGColor
        textField?.layer.borderWidth = 1.0
        textField?.layer.cornerRadius = 10.0
        textField?.textColor = UIColor.blackColor()
        
    }
}
