//
//  GetUserProfileresponse.swift
//  FlexYourMacros
//
//  Created by mini on 05/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _UserProfileresponse = UserProfileresponse()

class UserProfileresponse: NSObject {
    
    var userDietModel: UserDietModel?
    var userDetailModel: UserDetailModel?
    var metaModel: MetaModel?
    var userid: String?
    
    class var sharedUserProfileresponse: UserProfileresponse {
        return _UserProfileresponse
    }
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(UserProfileresponse.metaModelKeyMapping)
        
        // give reference to diet mapping
        responseMapping.addPropertyMapping(UserProfileresponse.userDietModelKeyMapping)
        
        // give reference to user credential mapping
        responseMapping.addPropertyMapping(UserProfileresponse.userDetailModelKeyMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: responseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kUrlGetUserDetailResponse, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
   
    private class var userDietModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDiet, toKeyPath: "userDietModel", withMapping: UserDietModel.objectMapping)
    }
    
    private class var userDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDetail, toKeyPath: "userDetailModel", withMapping: UserDetailModel.objectMapping)
    }
    
    
    
    class func getUserProfileDetails(userId: String,showHUD: Bool = false,  completionHandler: (userDiet: UserDietModel, userDetails: UserDetailModel) -> ()) {
            
        RestKitManager.setToken(true)
        
        let userProfileResponse = UserProfileresponse()
        userProfileResponse.userid = userId
        if showHUD {
            SVProgressHUD.show() }
        
        // api call with instance of message model class
        RestKitManager.sharedManager().getObject(userProfileResponse, path: nil, parameters: nil, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            
            if showHUD {

            SVProgressHUD.dismiss()
            }
            
            // get the user response
            let userProfileresponse = mappingResult.firstObject as! UserProfileresponse
            
            // check for success
            if userProfileresponse.metaModel?.responseCode != 200 {
                return;
            }
            
            // set up the completion handler with response
            completionHandler(userDiet: userProfileresponse.userDietModel!, userDetails: userProfileresponse.userDetailModel!)
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                if showHUD {

                SVProgressHUD.dismiss()
                }
                //print("failed to load login with error \(error)")
        })
    }
    
    
}