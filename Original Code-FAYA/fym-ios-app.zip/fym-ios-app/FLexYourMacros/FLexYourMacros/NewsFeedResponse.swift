//
//  NewsFeedResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 01/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class NewsFeedResponse: NSObject {
    
    var user_id = ""
    
    var metaModel = MetaModel()
    var newsFeeds = [NewsFeed]()
    var pageMetaModel = PageMetaModel()
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
        responseMapping.addPropertyMapping(metaModelMapping)
        
        // newsfeeds mapping
        let newsFeedModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathNewsFeeds, toKeyPath: "newsFeeds", withMapping: NewsFeed.objectMapping)
        responseMapping.addPropertyMapping(newsFeedModelMapping)
        
        // page meta model mapping
        let pageMetaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathPageMeta, toKeyPath: "pageMetaModel", withMapping: PageMetaModel.objectMapping)
        responseMapping.addPropertyMapping(pageMetaModelMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let newFeedsesponseDescriptor = RKResponseDescriptor(mapping: NewsFeedResponse.responseMapping, method: .Any, pathPattern: Constants.ServiceConstants.kNewsFeedUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return newFeedsesponseDescriptor
    }
    
    class func fetchPublicNewsFeeds(params: [String: String], completionHandler: (newsFeeds: [NewsFeed], pageMeta: PageMetaModel, error: NSError?) -> ()) {
        
        RestKitManager.setToken(true)
        
        let newsFeedResponse = NewsFeedResponse()
        newsFeedResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId ?? ""
        
        RestKitManager.sharedManager().getObject(newsFeedResponse, path: nil, parameters: params, success: { (operation, mappingResult) in
            
            // map to correct datamodel
            let response = mappingResult.firstObject as! NewsFeedResponse
            
            if response.metaModel.responseCode != 200 {
                let error = NSError(domain: "FYM.NewsFeed", code: 1001, userInfo: ["title": "error", "message": "alert_feed_list_message"])
                
                // fire completion handler
                completionHandler(newsFeeds: [], pageMeta: newsFeedResponse.pageMetaModel, error: error)
 
            }
            else {
                // fire completion handler
                completionHandler(newsFeeds: response.newsFeeds, pageMeta: newsFeedResponse.pageMetaModel, error: nil)
            }
            
            }) { (operation, error) -> Void in
                // error                
                let networkError = NSError(domain: "FYM.NewsFeed", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
                
                // fire completion handler
                completionHandler(newsFeeds: [], pageMeta: newsFeedResponse.pageMetaModel, error: networkError)
        }
    }
  
}