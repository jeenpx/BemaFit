//
//  ExerciseResponse.swift
//  FlexYourMacros
//
//  Created by mini on 25/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _ExerciseResponse = ExerciseResponse()

//exercise model
class ExerciseModel: NSObject {
    
    var exerciseLogId: String = ""
    var exerciseId: String = ""
    var exerciseDate: String = ""
    var exerciseName: String = ""
    var exerciseCalorieBurned: String = ""
    var exerciseType: String = ""
    var exerciseTypeId: String = ""
    var exerciseMethod: String = ""
    var exerciseDetails: ExerciseDetails = ExerciseDetails()

    class var objectMapping: RKObjectMapping {
        let exerciseMapping = RKObjectMapping(forClass: self)
        exerciseMapping.addAttributeMappingsFromDictionary(mappingDictionary)
        exerciseMapping.addPropertyMapping(ExerciseModel.exerciseDetailModelKeyMapping)

        return exerciseMapping
    }
    
    class var mappingDictionary: [String : String] {
        return(["id":"exerciseLogId", "exercise_id":"exerciseId", "exercise_date":"exerciseDate", "exercise_name":"exerciseName", "calorie_burned":"exerciseCalorieBurned", "type":"exerciseType", "type_id" : "exerciseTypeId", "method": "exerciseMethod"])
    }
    
    private class var exerciseDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathDetail, toKeyPath: "exerciseDetails", withMapping: ExerciseDetails.objectMapping)
    }
    
}

class ExerciseResponse: NSObject {
    
    var metaModel: MetaModel?
    var exerciseResults: [ExerciseModel]?
    
    class var sharedExerciseResponse: ExerciseResponse {
        return _ExerciseResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(ExerciseResponse.metaModelKeyMapping)
        
        // give reference to ProgressTypeMapping
        responseMapping.addPropertyMapping(ExerciseResponse.exerciseListModelKeyMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var exerciseListModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathExerciseLog, toKeyPath: "exerciseResults", withMapping: ExerciseModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.ExerciseLogUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }

    class func fetchExerciseList(offset: String, date: NSDate, completionHandler:(exerciseList: [Exercise], error:NSError?)->()) {
        
        RestKitManager.setToken(true)
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["date": date.stringValue("yyyy-MM-dd"), "offset": offset, "limit": "30"]
        }
        
        // get the objects from the path login
        RestKitManager.sharedManager().getObjectsAtPath(Constants.ServiceConstants.ExerciseLogUrl, parameters: parameterDictionary, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            
            // get the user response
            let progressResponse = mappingResult.firstObject as! ExerciseResponse
            
            //check for success
            if progressResponse.metaModel?.responseCode != 200 {
                
                let error = NSError(domain: "FYM.FoodLog", code: 1001, userInfo: ["title": "error", "message": "alert_log_list_message"])
                
                // fire completion handler
                completionHandler(exerciseList: [], error: error)
                return;
            }
            
            var exerciseList = [Exercise]()
            exerciseList = progressResponse.exerciseResults!.map { (anExercise: ExerciseModel) in

                var exercise = Exercise(name: "")
                if anExercise.exerciseTypeId == ExerciseTypeId.Strength.rawValue {
                    
                    let strengthExercise: StrengthExercise = StrengthExercise(name: anExercise.exerciseName)
                    strengthExercise.date = anExercise.exerciseDate.dateValue("yyyy-MM-dd")!
                    strengthExercise.sets = anExercise.exerciseDetails.exerciseSets.doubleValue
                    strengthExercise.reps = anExercise.exerciseDetails.exerciseReps.doubleValue
                    strengthExercise.weight = anExercise.exerciseDetails.exerciseWeight.doubleValue
                    strengthExercise.caloriesBurned = anExercise.exerciseDetails.exerciseCalorieBurned.doubleValue
                    strengthExercise.exerciseAmount = anExercise.exerciseDetails.exerciseAmount.doubleValue
                    strengthExercise.exerciseId = anExercise.exerciseId
                    strengthExercise.exerciseLogId = anExercise.exerciseLogId
                    strengthExercise.exerciseMethod = anExercise.exerciseMethod
                    strengthExercise.exerciseTypeId = ExerciseTypeId.Strength

                    exercise = strengthExercise as Exercise
                    
                }
                else if anExercise.exerciseTypeId == ExerciseTypeId.CardioVascular.rawValue {
                    
                    let cardioExercise: CardioVascularExercise = CardioVascularExercise(name: anExercise.exerciseName)
                    cardioExercise.date = anExercise.exerciseDate.dateValue("yyyy-MM-dd")!
                    cardioExercise.distance = anExercise.exerciseDetails.exerciseDistance.doubleValue
                    cardioExercise.caloriesBurned = anExercise.exerciseDetails.exerciseCalorieBurned.doubleValue
                    cardioExercise.exerciseAmount = anExercise.exerciseDetails.exerciseAmount.doubleValue
                    cardioExercise.exerciseId = anExercise.exerciseId
                    cardioExercise.exerciseLogId = anExercise.exerciseLogId
                    cardioExercise.exerciseMethod = anExercise.exerciseMethod
                    cardioExercise.exerciseTypeId = ExerciseTypeId.CardioVascular

                    exercise = cardioExercise as Exercise
                    
                }
                else {
                    // invalid exercise
                    //print("XXX invalid exercise type \(anExercise.exerciseType)")
                    exercise = Exercise(name: "")
                }
                return exercise
            }

            completionHandler(exerciseList :exerciseList,error :nil)
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                //print("failed to load masterdata with error \(error)")
                completionHandler(exerciseList:[], error :error)
        })
    }

}