//
//  MasterDataModel.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 10/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class MasterDataModel: NSObject {
    
    var activityLevels: [ActivityLevelModel]?
    var nutritionPlans: [NutritionPlanModel]?
    var goals: [GoalModel]?
    var businessCategory: [BusinessCategoryModel]?
    var mealCategory: [FoodCategory]?

    
    class var objectMapping: RKObjectMapping {
        
        let masterdataMapping = RKObjectMapping(forClass: self)
        // map  to activity model
        masterdataMapping.addPropertyMapping(MasterDataModel.activityLevelModelKeyMapping)

        // map to nutrition plan model
        masterdataMapping.addPropertyMapping(MasterDataModel.nutritionPlanModelKeyMapping)
        
        // map to goal model
        masterdataMapping.addPropertyMapping(MasterDataModel.goalModelKeyMapping)
        
        // map to business category model
        masterdataMapping.addPropertyMapping(MasterDataModel.businessCategoryKeyMapping)
        
        // map to meal category model
        masterdataMapping.addPropertyMapping(MasterDataModel.mealCategoryKeyMapping)


        return masterdataMapping
    }
    
    private class var activityLevelModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathActivityLevel, toKeyPath: "activityLevels", withMapping: ActivityLevelModel.objectMapping)
    }
    
    private class var nutritionPlanModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathNutritionPlan, toKeyPath: "nutritionPlans", withMapping: NutritionPlanModel.objectMapping)
    }
    
    private class var goalModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathGoal, toKeyPath: "goals", withMapping: GoalModel.objectMapping)
    }
    
    private class var businessCategoryKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMasterBusiness, toKeyPath: "businessCategory", withMapping: BusinessCategoryModel.objectMapping)
    }
    
    private class var mealCategoryKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMasterCreateMeal, toKeyPath: "mealCategory", withMapping: FoodCategory.objectMapping)
    }
    
//    private class var userDietOptionModelKeyMapping : RKRelationshipMapping {
//        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDietOption, toKeyPath: "userDietOptionModel", withMapping: UserDietOptionModel.objectMapping)
//    }
//    
//    private class var userDietOptionModelKeyMapping : RKRelationshipMapping {
//        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDietOption, toKeyPath: "userDietOptionModel", withMapping: UserDietOptionModel.objectMapping)
//    }
//    
//    private class var userDietOptionModelKeyMapping : RKRelationshipMapping {
//        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDietOption, toKeyPath: "userDietOptionModel", withMapping: UserDietOptionModel.objectMapping)
//    }
//    
//    private class var userDietOptionModelKeyMapping : RKRelationshipMapping {
//        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDietOption, toKeyPath: "userDietOptionModel", withMapping: UserDietOptionModel.objectMapping)
//    }
}