//
//  ConvertUnitsViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/20/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol ConvertUnitsCellDelegate {
    func convertUnitsCell(tableViewCell: ConvertUnitsCell)
}

enum ConvertUnitsCellMode: String {
    
    case Calories = "calories"
    case Carbohydrates = "total_carbohydrates"
    case Protein = "protein"
    case Fats = "total_fats"
    case SaturatedFat = "saturated_fat"
    case Polyunsaturated = "poly_unsaturated"
    case Monosaturated = "mono_saturated"
    case TransFat = "trans_fat"
    case Cholestreol = "cholestreol"
    case Sodium = "sodium"
    case Fiber = "fiber"
    static var createMealModes = [Calories, Carbohydrates, Protein, Fats, Fiber, SaturatedFat, Polyunsaturated, Monosaturated, TransFat, Cholestreol, Sodium]
    static var macroModes = [Calories, Carbohydrates, Protein, Fats, Fiber]
}

class ConvertUnitsCell: UITableViewCell, UITextFieldDelegate {
    
    @IBOutlet weak var labelNutritionFact: UILabel!
    @IBOutlet weak var textFieldNutritionFact: UITextField!
    
    //
    var convertUnitsCellDelegate: ConvertUnitsCellDelegate?
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    var food = Food() {
        didSet {
            configureView()
        }
    }
    
    // cell mode instance
    var convertUnitsCellMode = ConvertUnitsCellMode.Calories {
        didSet {
            configureView()
        }
    }
    
    func configureView() {
        // configure cell
        
        labelNutritionFact.text = convertUnitsCellMode != ConvertUnitsCellMode.Calories ?
            &&convertUnitsCellMode.rawValue + " (g)" : &&convertUnitsCellMode.rawValue
        
        switch convertUnitsCellMode {
        case .Calories:
            textFieldNutritionFact.text = food.calories == 0.0 || food.calories == 0 ? "" : food.calories.stringValue
        case .Carbohydrates:
                textFieldNutritionFact.text = food.carbohydrates == 0.0 || food.carbohydrates == 0 ? "" : food.carbohydrates.stringValue
        case .Protein:
            textFieldNutritionFact.text = food.protein == 0.0 || food.protein == 0 ? "" : food.protein.stringValue
        case .Fats:
            textFieldNutritionFact.text = food.fat == 0.0 || food.fat == 0 ? "" : food.fat.stringValue
        case .SaturatedFat:
            textFieldNutritionFact.text = food.saturated == 0.0 || food.saturated == 0 ? "" : food.saturated.stringValue
        case .Monosaturated:
            textFieldNutritionFact.text = food.monosaturated == 0.0 || food.monosaturated == 0 ? "" : food.monosaturated.stringValue
        case .Polyunsaturated:
            textFieldNutritionFact.text = food.polyunsaturated == 0.0 || food.polyunsaturated == 0 ? "" : food.polyunsaturated.stringValue
        case .TransFat:
            textFieldNutritionFact.text = food.trans == 0.0 || food.trans == 0 ? "" : food.trans.stringValue
        case .Cholestreol:
            textFieldNutritionFact.text = food.cholesterol == 0.0 || food.cholesterol == 0 ? "" : food.cholesterol.stringValue
        case .Sodium:
            textFieldNutritionFact.text = food.sodium == 0.0 || food.sodium == 0 ? "" : food.sodium.stringValue
        case .Fiber:
            textFieldNutritionFact.text = food.fiber == 0.0 || food.fiber == 0 ? "" : food.fiber.stringValue
        }
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        
        switch convertUnitsCellMode {
        case .Calories: food.calories = (textField.text! as NSString).doubleValue
        case .Carbohydrates: food.carbohydrates = (textField.text! as NSString).doubleValue
        case .Protein: food.protein = (textField.text! as NSString).doubleValue
        case .Fats: food.fat = (textField.text! as NSString).doubleValue
        case .SaturatedFat: food.saturated = (textField.text! as NSString).doubleValue
        case .Monosaturated: food.monosaturated = (textField.text! as NSString).doubleValue
        case .Polyunsaturated: food.polyunsaturated = (textField.text! as NSString).doubleValue
        case .TransFat: food.trans = (textField.text! as NSString).doubleValue
        case .Cholestreol: food.cholesterol = (textField.text! as NSString).doubleValue
        case .Sodium: food.sodium = (textField.text! as NSString).doubleValue
        case .Fiber: food.fiber = (textField.text! as NSString).doubleValue
        
        }
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        // managing the textfield input: limit the characters to only of numeric type
        
        // avoid entering spaces
        if string == " " {
            return false
        }
        
        // string empty then return true
        if string.isEmpty { return true }
        
        var isValid = true
        let text = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        
        // check for unwanted characters
        let replacementStringIsLegal = string.rangeOfCharacterFromSet(NSCharacterSet(charactersInString: "0123456789.").invertedSet) == nil
        
        // check for string count
        let resultingStringLengthIsLegal = text.characters.count <= 7
        
        
        // check if the number is valid
        let scanner = NSScanner(string: text)
        let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
        
        let isLowNumber = text.doubleValue < 100000
        
        // seperate strings after and before decimal point
        let arrayString = text.componentsSeparatedByString(".")
        
        // number of characters after decimal status
        var limitAfterDecimalNotExceeded = true
        
        if arrayString.count > 1 {
            let trailingDigits: NSString = arrayString[1]
            
            // save character count after decimal point
            limitAfterDecimalNotExceeded = trailingDigits.length <= 2
            
        }
        
        isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber && limitAfterDecimalNotExceeded
        
        return isValid
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        convertUnitsCellDelegate?.convertUnitsCell(self)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}

// mode to check the screen flow
enum ControllerMode {
    case CreateMeal
    case LogMacro
}

class ConvertUnitsSectionCell: UITableViewCell {
    
    @IBOutlet weak var labelNutritionFacts: UILabel!
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}

class ConvertUnitsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UIPickerViewDataSource, UIPickerViewDelegate, UIAlertViewDelegate, ConvertUnitsCellDelegate {
    
    @IBOutlet weak var tableViewConvertUnits: UITableView!
    @IBOutlet var pickerView: UIPickerView!
    @IBOutlet var toolbar: UIToolbar!
    @IBOutlet weak var convertUnitsTextField: UITextField!
    @IBOutlet var keyBoardToolbar: UIToolbar!
    @IBOutlet weak var pickerToolbarItemConvertGrams: UIBarButtonItem!
    @IBOutlet weak var pickerToolbarItemConvert: UIBarButtonItem!
    @IBOutlet weak var keyBoardToolbarItemConvertUnits: UIBarButtonItem!
    
    // current selected textfield
    var currentTextField = UITextField()
    
    // current cell mode
    var currentCellMode = ConvertUnitsCellMode.Calories
    
    var mealType: MealType?
    
    var logDate: NSDate?
    
    var isDailyMealPlan = false
    
    var dailyMealType = DailyMealType(dailyMealTypeName: "")

    // view controller mode
    var controllerMode: ControllerMode = .CreateMeal
    
    // picker elements
    // let arrayPicker: [String] = ["Micrograms", "Kilograms", "Ounces", "Pound"]
    var food = Food()
    
    // animate to show hidden textfield when picker appears
    var viewAnimatedForPicker = false
    
    // animate distance for picker
    var animatedDistance: CGFloat?
    
    // identifiers
    struct  Storyboard {
        
        // cell identifiers
        struct CellIdentifier {
            static let ConvertUnitsCellIdentifier = "kConvertUnitsCell"
            static let ConvertUnitsSectionCell = "kConvertUnitsSectionCell"
        }
        
        struct Segues {
            static let SegueConvertToMealType = "kSegueConvertToMealType"
            static let UnWindMealLogViewSegue = "kUnWindMealLogViewSegue"
        }
    }
    
    func saveConvertedValue() {
        // save the unit converted value
        
        switch currentCellMode {
        case .Carbohydrates: currentTextField.text = "\(food.carbohydrates)"
        case .Protein: currentTextField.text = "\(food.protein)"
        case .Fats: currentTextField.text = "\(food.fat)"
        case .SaturatedFat: currentTextField.text = "\(food.saturated)"
        case .Monosaturated: currentTextField.text = "\(food.monosaturated)"
        case .Polyunsaturated: currentTextField.text = "\(food.polyunsaturated)"
        case .TransFat: currentTextField.text = "\(food.trans)"
        case .Cholestreol: currentTextField.text = "\(food.cholesterol)"
        case .Sodium: currentTextField.text = "\(food.sodium)"
        case .Fiber: currentTextField.text = "\(food.fiber)"
            
        default: break
            
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set toolbar values
        keyBoardToolbarItemConvertUnits.title = &&"convert_units"
        pickerToolbarItemConvert.title = &&"convert"
        pickerToolbarItemConvertGrams.title = &&"convert_to_grams"
        
        food.servingSize = 1.0
        // set navigation item title
        navigationItem.title = controllerMode != ControllerMode.CreateMeal ? &&"log_by_macro" : &&"create_new"
        
        if mealType != nil {
            //print("from add food")
            //self.navigationItem.leftBarButtonItem.enabled=NO
            navigationItem.rightBarButtonItem?.title = "Log"
        }
        else {
            navigationItem.rightBarButtonItem?.image = UIImage(named: "RightArrowIcon")
        }
        
        //print(food.name)
        //print(food.calories)
        
        // hide empty tableview cells
        tableViewConvertUnits.tableFooterView = UIView()
        
        //        // configure textfield of pickerview
        //        convertUnitsTextField.inputView = pickerView
        //        convertUnitsTextField.inputAccessoryView = toolbar
    }
    
    func logFood() {
        // log food
        food.logFood(mealType!.id, mealDate: logDate ?? NSDate(), userGuid: AppConfiguration.sharedAppConfiguration.userDetails!.userId!) { (error) -> () in
            //print("logged food")
            self.performSegueWithIdentifier(Storyboard.Segues.UnWindMealLogViewSegue, sender: nil)
            
            //            // show alert controller if possible else show alert view
            //            if (NSClassFromString("UIAlertController") != nil) {
            //
            //                let alert = UIAlertController(title: &&"alert_title_log", message: &&"alert_message_log", preferredStyle: .Alert)
            //
            //                alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
            //
            //                self.presentViewController(alert, animated: true) {
            //                    self.performSegueWithIdentifier(Storyboard.Segues.UnWindMealLogViewSegue, sender: nil)
            //                }
            //            }
            //            else {
            //
            //                UIAlertView(title: &&"alert_title_log", message: &&"alert_message_log", delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok").show()
            //                self.performSegueWithIdentifier(Storyboard.Segues.UnWindMealLogViewSegue, sender: nil)
            //            }
        }
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let convertUnitsCell: ConvertUnitsCell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifier.ConvertUnitsCellIdentifier, forIndexPath: indexPath) as! ConvertUnitsCell
        convertUnitsCell.textFieldNutritionFact.placeholder = indexPath.row == 0 ? &&"required" : &&"optional"
        convertUnitsCell.food = food
        
        // cell mode
        convertUnitsCell.convertUnitsCellMode = controllerMode != ControllerMode.CreateMeal ?
            ConvertUnitsCellMode.macroModes[indexPath.row] : ConvertUnitsCellMode.createMealModes[indexPath.row]
        
        // set delegate
        convertUnitsCell.convertUnitsCellDelegate = self
        
        return convertUnitsCell
    }
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return controllerMode != ControllerMode.CreateMeal ? ConvertUnitsCellMode.macroModes.count : ConvertUnitsCellMode.createMealModes.count
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return controllerMode == ControllerMode.CreateMeal ? 30 : 0
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        // view for section
        
        let convertUnitsSectionCell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifier.ConvertUnitsSectionCell) as! ConvertUnitsSectionCell
        convertUnitsSectionCell.labelNutritionFacts.text = &&"nutrition_facts"
        return convertUnitsSectionCell as UIView
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! ConvertUnitsCell
        cell.textFieldNutritionFact.becomeFirstResponder()
    }
    
    
    // picker view delegates and datasource
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return WeightUnits.allUnits.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return &&WeightUnits.allUnits[row].rawValue
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
    }
    
    @IBAction func buttonActionPicker(sender: AnyObject) {
        // picker convert units button action
        
        // if view animated upwards for picker then bring it to normal state
        animateBackView()
        
        //print("buttonActionPicker entered")
        convertUnitsTextField.resignFirstResponder()
        
        // convert from selected unit to gram
        // food.convertUnits(WeightUnits.allUnits[pickerView.selectedRowInComponent(0)])
        
        // convert to gram for selected field
        //        food.convertUnitsFood(WeightUnits.allUnits[pickerView.selectedRowInComponent(0)], cellMode: currentCellMode)
        
        // convert to gram for selected field
        food.convertUnitsFood(WeightUnits.allUnits[pickerView.selectedRowInComponent(0)], cellMode: currentCellMode) { (status) -> () in
            
            if status == "success" {
                
                // save unit converted value to textfield
                self.saveConvertedValue()
            }
            else {
                self.showAlert(&&"notice", message: &&"enter_small_value")
            }
        }
        
        //        // save unit converted value to textfield
        //        saveConvertedValue()
        
        
        
        //tableViewConvertUnits.reloadData()
    }
    
    @IBAction func buttonActionRightNavBar(sender: AnyObject) {
        
        // resign the textfield to set value to food property
        currentTextField.resignFirstResponder()
        
        convertUnitsTextField.resignFirstResponder()
        
        // if view animated upwards for picker then bring it to normal state
        animateBackView()
        
        
        if food.calories < 1 {
            // show alert if calorie value less than 1
            
            showAlert(&&"error", message: &&"calorie_empty_message")
        }
            
        else {
            // food calories minimum value is greater than 1
            
            if controllerMode == .LogMacro {
                // log by macro
                
                if food.carbohydrates < 0 || food.protein < 0 || food.fat < 0 || food.fiber < 0 {
                    // check negative values entered for log by macro fields
                    
                    // alert for negative value
                    showAlert(&&"error", message: &&"food_property_negative_message")
                }
                else {
                    
                    if isDailyMealPlan {
                        
                        food.dailyMealType = dailyMealType
                        food.mealType = mealType!
                        food.name = "Logged by macro" //set to this since there is no name for logged by macro food
                        food.addedDate = NSDate()
                        NSNotificationCenter.defaultCenter().postNotificationName("RefreshMealPlanIdentifier", object: nil, userInfo: ["newFood": food, "method": "Read"])
                        
                        //resign to the daily meal plan viewcontroller
                        if let viewControllers = navigationController?.viewControllers {
                            for viewController in viewControllers {
                                // some process
                                if viewController.isKindOfClass(DailyMealPlanDetailViewController) {
                                    self.navigationController?.popToViewController(viewController, animated: true)
                                }
                            }
                        }
                        return
                    }
                    
                    // set log by macro name
                    food.isLoggedByMacro = true
                    
                    if self.mealType != nil {
                        // clicked post button
                        
                        // log food
                        self.logFood()
                    }
                    else {
                        // clicked right arrow icon
                        self.performSegueWithIdentifier(Storyboard.Segues.SegueConvertToMealType, sender: self)
                    }
                    
                    // exit
                    return
                }
            }
            
            // create meal
            
            if food.carbohydrates < 0 || food.protein < 0 || food.fat < 0 || food.saturated < 0 || food.monosaturated < 0 || food.polyunsaturated < 0 || food.trans < 0 || food.cholesterol < 0 || food.sodium < 0  {
                // check negative values entered for create meal
                
                // alert for negative value
                showAlert(&&"error", message: &&"food_property_negative_message")
            }
                
            else {
                
                if self.mealType != nil {
                    // create food in case of create meal
                    food.createFood { (food,meta) in
                        
                        
                        // meal already exists
                        if meta.responseCode != 200 {
                            self.showAlert(&&"notice", message: &&"meal_already_exist")
                            return
                        }
                        
                        // replace the local food with the created one
                        self.food = food
                        
                        // log food
                        self.logFood()
                    }
                }
                else {
                    
                    // clicked right arrow icon
                    self.performSegueWithIdentifier(Storyboard.Segues.SegueConvertToMealType, sender: self)
                }
                
                
                //                // create food in case of create meal
                //                food.createFood { (food,meta) in
                //
                //
                //                    // meal already exists
                //                    if meta.responseCode != 200 {
                //                        self.showAlert(&&"notice", message: meta.message)
                //                        return
                //                    }
                //
                //                    // replace the local food with the created one
                //                    self.food = food
                //
                //                    if self.mealType != nil {
                //                        // clicked post button
                //
                //                        // log food
                //                        self.logFood()
                //                    }
                //                    else {
                //                        // clicked right arrow icon
                //                        self.performSegueWithIdentifier(Storyboard.Segues.SegueConvertToMealType, sender: self)
                //                    }
                //                    }
            }
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == Storyboard.Segues.SegueConvertToMealType {
            let mealTypeListViewController = segue.destinationViewController as! MealTypeListViewController
            mealTypeListViewController.shouldCreateFood = controllerMode == .CreateMeal
            mealTypeListViewController.food = food
        }
    }
    
    func showAlert(title: String, message: String) {
        UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok").show()
    }
    
    func convertUnitsCell(tableViewCell: ConvertUnitsCell) {
        
        animateBackView()
        
        // save current textfield
        currentTextField = tableViewCell.textFieldNutritionFact
        
        // save current cell mode
        currentCellMode = tableViewCell.convertUnitsCellMode
        
        if currentCellMode == ConvertUnitsCellMode.Calories {
            currentTextField.inputAccessoryView = UIView()
            return
        }
        
        currentTextField.inputAccessoryView = keyBoardToolbar
    }
    
    @IBAction func actionkeyBoardConvertUnits(sender: AnyObject) {
        
        // configure textfield of pickerview
        convertUnitsTextField.inputView = pickerView
        convertUnitsTextField.inputAccessoryView = toolbar
        convertUnitsTextField.becomeFirstResponder()
        
        // animate to avoid hidden textfields when picker appears
        animateviewForParticularCells()
    }
    
    func animateviewForParticularCells() {
        
        if controllerMode == .CreateMeal {
            switch currentCellMode {
            case .SaturatedFat, .Monosaturated, .Polyunsaturated, .TransFat, .Cholestreol, .Sodium:
                
                // view animating for picker
                viewAnimatedForPicker = true
                var viewFrame = self.view.frame
                animatedDistance = pickerView.frame.size.height + toolbar.frame.size.height
                viewFrame.origin.y -= animatedDistance!
                UIView.setAnimationBeginsFromCurrentState(true)
                UIView.setAnimationDuration(0.3)
                self.view.frame = viewFrame
                UIView.commitAnimations()
            default:
                break
            }
        }
    }
    
    func animateBackView() {
        
        // check view animated upwards
        if viewAnimatedForPicker {
            viewAnimatedForPicker = false
            var viewFrame = self.view.frame
            viewFrame.origin.y += animatedDistance!
            UIView.setAnimationBeginsFromCurrentState(true)
            UIView.setAnimationDuration(0.3)
            self.view.frame = viewFrame
            UIView.commitAnimations()
        }
    }
    
    @IBAction func buttonActionBack(sender: AnyObject) {
        navigationController?.popViewControllerAnimated(true)
    }
}
