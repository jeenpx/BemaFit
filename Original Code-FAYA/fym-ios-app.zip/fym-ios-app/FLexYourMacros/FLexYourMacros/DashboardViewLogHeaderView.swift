//
//  DashboardViewLogHeaderView.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 23/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol DashboardViewLogHeaderViewDelegate {
    func buttonActionViewLog(sender: DashboardViewLogHeaderView)
    func clickedOnAdHeader(urlString:String)
}

class DashboardViewLogHeaderView: UIView {
    
    var dashboardViewLogHeaderViewDelegate: DashboardViewLogHeaderViewDelegate?
    var imageViewAd = UIImageView()
    
    var advertisementDetail = Advertisement()
    var adHeight = 0.0
    
    init() {
        super.init(frame: CGRectMake(0, 0, 500, 100))
        
        addSubViewsToView()
        //        configureHeaderView()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubViewsToView()
        //        configureHeaderView()
    }
    
    override func layoutIfNeeded() {
        super.layoutIfNeeded()
        
    }
    
    convenience init(delegate: DashboardViewLogHeaderViewDelegate, advertisement: Advertisement) {
        self.init()
        
        // setup delegate
        dashboardViewLogHeaderViewDelegate = delegate
        advertisementDetail = advertisement
        
        if let imageURL = advertisementDetail.imageURL {
            
            imageViewAd.setImageWithURL(imageURL, placeholderImage: nil)
            imageViewAd.contentMode = UIViewContentMode.ScaleToFill
            imageViewAd.layer.masksToBounds = true
            imageViewAd.layer.cornerRadius = 10
            
            // add tap gesture
            let tapGesture = UITapGestureRecognizer(target: self, action: "imageViewTapped:")
            imageViewAd.userInteractionEnabled = true
            imageViewAd.addGestureRecognizer(tapGesture)
            adHeight = Double(CGRectGetHeight(self.frame)) - 45.0
            configureHeaderView(advertisement)
            
        }
        
        //self.layoutSubviews()
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        addSubViewsToView()
        //        configureHeaderView()
    }
    
    var labelBgView = UIView()
    var label =  UILabel()
    var button =
    UIButton()
    
    func addSubViewsToView() {
        
        // set background
        layer.backgroundColor = UIColor.defaultGrayColor().CGColor
        labelBgView = UIView(frame: CGRectMake(0, 0, CGRectGetWidth(self.bounds), 30))
        labelBgView.backgroundColor = UIColor(red: 44.0/255.0, green: 44.0/255.0, blue: 44.0/255.0, alpha: 1.0)
        addSubview(labelBgView)
        
        
        label = UILabel()
        label.font = UIFont.helveticaBold(13)
        label.textColor = UIColor.defaultThemeBlueColor()
        label.text = &&"view_log"
        labelBgView.addSubview(label)
        
        
        button = UIButton(type: .Custom)
        button.setImage(UIImage(named: "RightArrowIconBlue"), forState: .Normal)
        button.tintColor = UIColor.defaultThemeBlueColor()
        labelBgView.addSubview(button)
        
        imageViewAd = UIImageView()
        imageViewAd.backgroundColor = UIColor.clearColor()
        addSubview(imageViewAd)
        
    }
    
    func configureHeaderView(advertisement: Advertisement) {
        
        // setup constraints
        label.translatesAutoresizingMaskIntoConstraints = false
        button.translatesAutoresizingMaskIntoConstraints = false
        imageViewAd.translatesAutoresizingMaskIntoConstraints = false
        
        self.layoutIfNeeded()
        
        self.imageViewAd.setNeedsUpdateConstraints()
        self.imageViewAd.updateConstraintsIfNeeded()
        self.layoutIfNeeded()
        
        labelBgView.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("H:|-(15)-[label]-[button]", options: NSLayoutFormatOptions.AlignAllCenterY, metrics: nil, views: ["label": label, "button": button]))
        labelBgView.addConstraint(NSLayoutConstraint(item: labelBgView, attribute: .CenterY, relatedBy: .Equal, toItem: label, attribute: .CenterY, multiplier: 1, constant: 0))
        labelBgView.addConstraint(NSLayoutConstraint(item: labelBgView, attribute: .CenterY, relatedBy: .Equal, toItem: button, attribute: .CenterY, multiplier: 1, constant: 0))
        
        addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("H:|-5-[imageViewAd]-5-|", options: [], metrics: nil, views: ["imageViewAd": imageViewAd]))
        
        addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("V:|-15-[labelBgView]-[imageViewAd(imageHeight)]-|", options: [], metrics: ["imageHeight": advertisement.shouldDisplayAdvertisement ? CGRectGetHeight(self.frame)-45 : 0], views: ["labelBgView": labelBgView, "imageViewAd": imageViewAd]))
        
        //print("ad height -----\(advertisement.shouldDisplayAdvertisement ? CGRectGetHeight(self.frame)-45 : 0)")
        
        gestureRecognizers = [UITapGestureRecognizer(target: self, action: "showViewLog:")]
    }
    
    
    func imageViewTapped(tapGestureRecognizer: UITapGestureRecognizer) {
        // append http and open the url
        dashboardViewLogHeaderViewDelegate?.clickedOnAdHeader(advertisementDetail.content!)
    }
    
    func showViewLog(sender: UITapGestureRecognizer) {
        dashboardViewLogHeaderViewDelegate?.buttonActionViewLog(self)
    }
}
