//
//  GetFriendsResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 30/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class GetFriendsResponse: NSObject {
    
    var metaModel: MetaModel?
    var friends:[FriendModel]?
    var totalFriends:String?
    var user_id: String?
    
    // save type friend
    var typeFriends = [FriendModel]()
    
    class var getFriendsResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        responseMapping.addAttributeMappingsFromDictionary(mappingDictionary)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(GetFriendsResponse.metaModelKeyMapping)
        
        // give reference to message item model
        responseMapping.addPropertyMapping(GetFriendsResponse.friendModelMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    
    private class var friendModelMapping :RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathGetFriends, toKeyPath: "friends", withMapping: FriendModel.objectMapping)
    }
    
    class var mappingDictionary: [String : String] {
        return(["total_friends":"totalFriends"])
    }
    
    
    class var userResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: getFriendsResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.getFriendsUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }

    class func getFriendsList(offset: Int, excludeRequests: Bool = false, andLimit limit: Int, keywords: String, shouldShowHUD: Bool = true, completionHandler: (getFriendsResponse:GetFriendsResponse) -> ()) {
        
        if shouldShowHUD {
            SVProgressHUD.show()
        }
        RestKitManager.setToken(true)
        let friendResponse = GetFriendsResponse()
        friendResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
        
        // input parameters
        var params: Dictionary<String, AnyObject>  = ["offset": offset, "limit": limit ,"keyword": keywords]
        
        if excludeRequests {
            params["type"] = "friends"
        }
        
        //print("params == \(params)")
        
        // get the objects from the path login
        RestKitManager.sharedManager().getObject(friendResponse, path:nil, parameters: params, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            let getFriendResponse = mappingResult.firstObject as! GetFriendsResponse
            
            //print("respone code :\(getFriendResponse.metaModel?.responseCode)")
            //print("respone status :\(getFriendResponse.metaModel?.responseStatus)")
            //print("count :\(getFriendResponse.totalFriends)")
            if shouldShowHUD {
                SVProgressHUD.dismiss()
            }
            completionHandler(getFriendsResponse: getFriendResponse)
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                if shouldShowHUD {
                    SVProgressHUD.dismiss()
                }
                //print("failed to load masterdata with error \(error)")
        })
        
        
    }
    

    class func getTypeFriends(offset: Int, andLimit limit: Int, keywords: String, andProgressHUD showLoader: Bool, completionHandler: (typeFriends:[FriendModel]) -> ()) {
        // get the friends of type - friend
        
        getFriendsList(offset, andLimit: limit, keywords: keywords, shouldShowHUD: showLoader) { (friendsResponse) -> () in
            
            let getFriendResponse = GetFriendsResponse()
            if let friends: [FriendModel] = friendsResponse.friends {
                for friend in friends {
                    
                    if getFriendResponse.typeFriends.isEmpty {
                        
                        // empty array
                        if friend.type == "Friend" {
                            getFriendResponse.typeFriends.insert(friend, atIndex: 0)
                        }
                    }
                    else {
                        
                        // non empty array
                        if friend.type == "Friend" {
                            getFriendResponse.typeFriends.append(friend)
                        }
                    }
                }
            }
            
            completionHandler(typeFriends: getFriendResponse.typeFriends)
        }
    }
    
    
    
}
