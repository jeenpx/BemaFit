//
//  InstagramManager.swift
//  InstagramSDK
//
//  Created by Deepu S Nath on 23/02/15.
//  Copyright (c) 2015 DBG. All rights reserved.
//

import Foundation
import UIKit

class InstagramManager: NSObject, UIDocumentInteractionControllerDelegate {
    
    private let kInstagramURL = "instagram://"
    private let kUTI = "com.instagram.exclusivegram"
    private let kfileNameExtension = "instagram.igo"
    private let kAlertViewTitle = "Error"
    private let kAlertViewMessage = "Please install the Instagram application"
    var documentInteractionController: UIDocumentInteractionController?
    
    // singleton manager
    class var sharedManager: InstagramManager {
        struct Singleton {
            static let instance = InstagramManager()
        }
        return Singleton.instance
    }
    
    func postImageToInstagramWithCaption(imageInstagram: UIImage, instagramCaption: String, view: UIView) {
        // called to post image with caption to the instagram application
        
        let instagramURL = NSURL(string: kInstagramURL)
        if UIApplication.sharedApplication().canOpenURL(instagramURL!) {
            
            let jpgPath = (NSTemporaryDirectory() as NSString).stringByAppendingPathComponent(kfileNameExtension)
            UIImageJPEGRepresentation(imageInstagram, 0.0)!.writeToFile(jpgPath, atomically: true)
            let rect = CGRectZero
            
            let fileURL = NSURL(fileURLWithPath: jpgPath)
             documentInteractionController = UIDocumentInteractionController(URL: fileURL)
            documentInteractionController!.URL = fileURL
            documentInteractionController!.delegate = self
            documentInteractionController!.UTI = kUTI
            // adding caption for the image
            documentInteractionController!.annotation = ["InstagramCaption": instagramCaption]
            documentInteractionController!.presentOpenInMenuFromRect(rect, inView: view, animated: true)
        }
        else {
            // alert displayed when the instagram application is not available in the device
            UIAlertView(title: kAlertViewTitle, message: kAlertViewMessage, delegate:nil, cancelButtonTitle:"Ok").show()
        }
        
        //fun1(imageInstagram, instagramCaption: instagramCaption, view: view)
    }
    
//    func fun1(imageInstagram: UIImage, instagramCaption: String, view: UIView) {
//        var docController = UIDocumentInteractionController()
//        let instagramURL = NSURL(string: "instagram://")
//        
//        if(UIApplication.sharedApplication().canOpenURL(instagramURL!)) {
////            var imagePost = cropped
//            let fullPath = (NSTemporaryDirectory() as NSString).stringByAppendingPathComponent(kfileNameExtension)
//            UIImagePNGRepresentation(imageInstagram)!.writeToFile(fullPath, atomically: true)
//            let rect = CGRectMake(0, 0, 0, 0)
//            docController.UTI = "com.instagram.exclusivegram"
//            let igImageHookFile = NSURL(string: "file://\(fullPath)")
//            docController = UIDocumentInteractionController(URL: igImageHookFile!)
//            
//            docController.presentOpenInMenuFromRect(rect, inView: view, animated: true)
//            
//        }
//        
//    }
//    
//    func documentsDirectory() -> String {
//        let documentsFolderPath = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true)[0]
//        return documentsFolderPath
//    }
}


