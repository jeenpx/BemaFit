//
//  UIFontExtensions.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 06/07/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

extension UIFont {
    
    class func helvetica(size: Int = 15) -> UIFont {
        return UIFont(name: "Helvetica", size: CGFloat(size)) ?? UIFont.systemFontOfSize(CGFloat(size))
    }
    
    class func helveticaBold(size: Int = 15) -> UIFont {
        return UIFont(name: "Helvetica-Bold", size: CGFloat(size)) ?? UIFont.boldSystemFontOfSize(CGFloat(size))
    }
}
