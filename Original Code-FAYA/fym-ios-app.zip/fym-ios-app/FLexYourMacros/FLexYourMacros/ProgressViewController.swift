//
//  ProgressViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 18/02/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

enum ProgressType: String {
    case Weight = "weight"
    case Bodyfat = "bodyfat"
    case Macros = "macros"
    case Exercise = "exercise"
    
    static var types = [Weight, Bodyfat, Macros, Exercise]
    
    var sections: Int {
        var value = 0
        switch self {
        case .Weight, .Bodyfat, .Macros: value = 1
        case .Exercise: value = 2
        }
        return value
    }
    
    var description: String {
        var value = ""
        switch self {
        case .Weight:    value = "Weight"
        case .Bodyfat:   value = "Bodyfat"
        case .Macros:    value = "Macro"
        case .Exercise:  value = "Exercise"
        }
        return value
    }
    
}

enum MonthsTypes: String {
    
    case January = "january"
    case February = "february"
    case March = "march"
    case April = "april"
    case May = "may"
    case June = "june"
    case July = "july"
    case August = "august"
    case September = "september"
    case October = "october"
    case November = "november"
    case December = "december"
    
    static var types = [January, February, March, April, May, June, July, August, September, October, November, December]
}

enum TableHeader: String {
    
    case Strength = "Strength"
    case CardioVascular = "Cardiovascular"
    case Default = ""
}

enum SwitchDirection:String {
    
    case Backward = "Backward"
    case Forward = "Forward"
    case None = "None"
}

enum MacroTableRows: String {
    
    case Calories = "calories"
    case Protein = "protein"
    case Carb = "carbs"
    case Fat = "fat"
    case Fiber = "fiber"
}

class ProgressViewController: UIViewController , AKPickerViewDataSource, AKPickerViewDelegate, UITableViewDelegate, CollapsableTableViewDelegate {
    
    @IBOutlet weak var labelDate: UILabel!
    @IBOutlet weak var tableViewProgress: CollapsableTableView!
    @IBOutlet private weak var pickerViewHorizontalListItem: AKPickerView!
    @IBOutlet weak var dateSuperview: UIView!
    @IBOutlet weak var buttonNext: UIButton!
    @IBOutlet weak var buttonPrevious: UIButton!
    var currentSelectedButton = UIButton()
    var activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.Gray)
    @IBOutlet weak var dateSuperView: UIView!
    
    struct StoryBoard {
        
        struct SegueIdentifiers {
            static let LogProgress = "kProgressLog"
        }
    }
    
    let themeBlueColor = UIColor(red: 30.0/255.0, green: 144.0/255.0, blue: 255.0/255.0, alpha: 1.0)
    let titles = ["Weight", "Body Fat", "Macros", "Exercise"]
    let dates = [&&MonthsTypes.January.rawValue, &&MonthsTypes.February.rawValue, &&MonthsTypes.March.rawValue, &&MonthsTypes.April.rawValue, &&MonthsTypes.May.rawValue, &&MonthsTypes.June.rawValue, &&MonthsTypes.July.rawValue, &&MonthsTypes.August.rawValue, &&MonthsTypes.September.rawValue, &&MonthsTypes.October.rawValue, &&MonthsTypes.November.rawValue, &&MonthsTypes.December.rawValue]
    
    private var currentDate = NSDate() {
        didSet {
            
            switch progressType {
                
            case .Weight, .Bodyfat, .Exercise:
                dateText = dates[currentDate.dateComponents().month - 1] + " \(currentDate.dateComponents().year)"

            case .Macros:
                dateText = &&"weekly" + weekStartDate.stringValue("dd/MM/yy") + " - " + weekEndDate.stringValue("dd/MM/yy")
            }
            _theWeekSortedArray = nil
            _currentWeekArray = nil
            loadData()
        }
    }
        
    var selectedTitle: String = "Weight"
    private var lastContentOffset: Float?
    var arrayData = [[ProgressReport]]()

    //array for the exercise types
    var strengthArrayData = [[ProgressReport]]()
    var cardioarrayData = [[ProgressReport]]()
    
    var progressReports = [ProgressReport]()
    var cardioProgressReports = [ProgressReport]()
    var strengthProgressReports = [ProgressReport]()
    
    var macroDailyRequirement = [DailyRequirement]()
    var macroTableData = [[String:String]]()
    
    required init?(coder aDecoder: NSCoder) {
        
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        currentSelectedButton.frame = buttonNext.frame
//        currentDate = NSDate()
        //configure activity indicator view
        activityIndicator.hidesWhenStopped = true
        dateSuperView.addSubview(activityIndicator)
        activityIndicator.hidden = true
        
        // configure the view
        configurePickerView()
        
        //set the table uncollapsed when first time opening the screen
        tableViewProgress.setIsCollapsed(false, forHeaderWithTitle: "")
        tableViewProgress.reloadData()
        tableViewProgress.tableFooterView = UIView(frame: CGRectZero)
        progressType = ProgressType.Weight
    }
    
    override func viewWillAppear(animated: Bool) {
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
    }
    
    func configurePickerView() {
        
        // horizontal picker for data
        pickerViewHorizontalListItem.delegate = self
        pickerViewHorizontalListItem.dataSource = self
        pickerViewHorizontalListItem.font = UIFont.boldSystemFontOfSize(15)
        pickerViewHorizontalListItem.highlightedFont = UIFont.boldSystemFontOfSize(15)
        pickerViewHorizontalListItem.interitemSpacing = 25
        pickerViewHorizontalListItem.viewDepth = 0.0
        pickerViewHorizontalListItem.pickerViewStyle = .Flat
        pickerViewHorizontalListItem.maskDisabled = true
        pickerViewHorizontalListItem.reloadData()
    }
    
    var dateText: String = ""{
        
        didSet {
            labelDate.text = dateText
        }
    }
    
    var progressType = ProgressType.Weight {
        
        didSet {
            progressReports.removeAll()
            cardioProgressReports.removeAll()
            strengthProgressReports.removeAll()
            arrayData.removeAll()
            strengthArrayData.removeAll()
            cardioarrayData.removeAll()
            macroTableData.removeAll()
            _theWeekSortedArray = nil
            
            switch progressType {
                
            case .Weight:
                tableViewProgress.setIsCollapsed(false, forHeaderWithTitle: "")
            case .Bodyfat:
                tableViewProgress.setIsCollapsed(false, forHeaderWithTitle: "")
            case .Macros:
                tableViewProgress.setIsCollapsed(false, forHeaderWithTitle: "")
            default: break
            }
//            tableViewProgress.reloadData()
            
            switch progressType {
                
            case .Weight, .Bodyfat, .Exercise:
//                var dateComponents = currentDate.dateComponents()
//                dateComponents.day = NSDate().dateComponents().day
                currentDate = NSDate()//NSCalendar.currentCalendar().dateFromComponents(dateComponents)!
            case .Macros:
                currentDate = NSDate()//monthStartDate
            }
            
        }
    }
    
    
    func loadData() {
        //check for internet
        let reachability = appDelegate!.internetReachable
        if reachability {
            
            let startDate =  self.progressType == ProgressType.Macros ? weekStartDate : monthStartDate
            let endDate =  self.progressType == ProgressType.Macros ? weekEndDate : monthEndDate
            
            Progress.deleteProgressData(self.progressType.description, progressStartDate: self.getDbFormattedDate(startDate), progressEndDate: self.getDbFormattedDate(endDate), completionHandler: { (fetchedArray) -> () in
                
                self.fetchProgressFromServer()
                
            })
        } else {
            
            self.fetchDataFromDatabase()
        }

    }
    
    private var _theWeekSortedArray: [[String : NSDate]]? = nil
    var theWeekSortedArray: [[String : NSDate]] {
        
        if _theWeekSortedArray != nil {
            return _theWeekSortedArray!
        }
        
        _theWeekSortedArray = NSDate.weekArrayForMonthOfDate(currentDate)()
        return _theWeekSortedArray!
    }
    
    var requestDate: String {
        
        //webcall prepare the request date in for yyyy-mm-dd from the current date
        let components = NSDate.dateComponents(monthStartDate)()
        return "\(components.year)"+"-"+"\(components.month)"+"-"+"\(components.day)"
    }
    
    private var xAxisLabels: [String] {
        
        // prepare the xlabels for the graph
        var tempAxisLabels = [String]()
        
        func getTheDateFormatted(date: NSDate) -> String {
            
            let components = NSDate.dateComponents(date)()
            return "\(components.day)"+"/"+"\(components.month)"
            
        }
        if progressType == ProgressType.Weight || progressType == ProgressType.Bodyfat  {
            tempAxisLabels = theWeekSortedArray.map() {
                
                let formattedStartDate = getTheDateFormatted($0["startDate"]!)
                let formattedEndDate = getTheDateFormatted($0["endDate"]!)
                
                return "\(formattedStartDate)"+"-"+"\(formattedEndDate)"
            }
        } else if progressType == ProgressType.Exercise {
            
            tempAxisLabels = theWeekSortedArray.map() {
                
                let formattedStartDate = getTheDateFormatted($0["startDate"]!)
                
                return "\(formattedStartDate)"
            }
        } else if progressType == ProgressType.Macros {
            
            tempAxisLabels = currentWeekArray.map({
                return getTheDateFormatted($0)
            })
            
        }
        
        return tempAxisLabels
    }
    
    private var _currentWeekArray: [NSDate]? = nil
    var currentWeekArray: [NSDate] {
        
        if _currentWeekArray != nil {
            return _currentWeekArray!
        }
        let startDate = weekStartDate
        let endDate  = weekEndDate
        let dateComponents = NSCalendar.currentCalendar().components(NSCalendarUnit.Day, fromDate: startDate, toDate: endDate, options: NSCalendarOptions())
        
        var dateArray = [NSDate]()
        dateArray.append(startDate)
        
        var lastDate = startDate
        let numberOfDays = dateComponents.day
        
        for var i = 0; i < numberOfDays; i++ {
            
            dateComponents.day = 1
            let nextDate = NSCalendar.currentCalendar().dateByAddingComponents(dateComponents, toDate: lastDate, options: NSCalendarOptions())
            dateArray.append(nextDate!)
            lastDate = nextDate!
        }
        
        _currentWeekArray = dateArray
        return _currentWeekArray!
    }
    
    // picker view delegate methods
    func numberOfItemsInPickerView(pickerView: AKPickerView) -> Int {
        return  ProgressType.types.count
    }
    
    func pickerView(pickerView: AKPickerView, titleForItem item: Int) -> String {
        return &&ProgressType.types[item].rawValue
    }
    
    func pickerView(pickerView: AKPickerView, didSelectItem item: Int) {
        progressType = ProgressType.types[item]
    }
    
    func pickerView(pickerView: AKPickerView, configureLabel label: UILabel, forItem item: Int) {
        label.textColor = UIColor.darkGrayColor()
        label.highlightedTextColor = themeBlueColor
        
    }
    
    func fetchProgressFromServer() {
        
        activityIndicator.frame = currentSelectedButton.frame
        currentSelectedButton.userInteractionEnabled = false
        activityIndicator.hidden = false
        activityIndicator.startAnimating()
        
        //print("request date ----\(self.requestDate)")
        // fetch data from server and load that in database
        Progress.fetchProgressDataFromUrl(self.progressType.description, date: self.requestDate, dateType: "Month", numberOfPages: "2", completionHandler: { (done) -> () in
            
            //unhide the button
            self.currentSelectedButton.userInteractionEnabled = true
            //stop the activity indicator from animating
            self.activityIndicator.stopAnimating()
            
            //fetch the newly stored value from database
            self.fetchDataFromDatabase()
            
            }) { (error) -> () in
                
                //unhide the button
                self.currentSelectedButton.userInteractionEnabled = true
                //stop the activity indicator from animating
                self.activityIndicator.stopAnimating()
                
                if error.code == -1009 {
                    // found network error and data fetched from database
                    self.fetchDataFromDatabase()
                }
        }
    }
    
    func getDbFormattedDate(date: NSDate)-> String {
        return date.stringValue("yyyy-MM-dd")
    }
    
    func fetchDataFromDatabase() {
        
        // get the start date
        let startDate =  progressType == ProgressType.Macros ? weekStartDate : monthStartDate
        let endDate =  progressType == ProgressType.Macros ? weekEndDate : monthEndDate
        
        //print("getDbFormattedDate(startDate!)----\(getDbFormattedDate(startDate))")
        //print("getDbFormattedDate(endDate!)----\(getDbFormattedDate(endDate))")
        
        Progress.fetchProgressData(progressType.description, progressStartDate: getDbFormattedDate(startDate), progressEndDate: getDbFormattedDate(endDate)) { (fetchedArray) -> () in
            
            let progressArray = fetchedArray as! [ProgressReport];
            if progressArray.isEmpty {
                self.tableViewProgress.reloadData()

                return
            }
            
            if progressArray.count > 0 {
                
                let unsortedArray = progressArray
                if unsortedArray.isEmpty {
                    self.tableViewProgress.reloadData()

                    return
                }
                var filteredAray = [ProgressReport]()
                
                for progressReport in unsortedArray {
                    
                    if self.progressType != ProgressType.Exercise {
                        
                        let checkArray = filteredAray.filter({
                            $0.log_date == progressReport.log_date
                        })
                        if checkArray.count == 0 {
                            
                            filteredAray.append(progressReport)
                        }
                    
                    } else {
                        
                        let checkArray = filteredAray.filter({
                            $0.log_date == progressReport.log_date  && $0.exercise_type ==  progressReport.exercise_type
                        })
                        if checkArray.count == 0 {
                            
                            filteredAray.append(progressReport)
                        }
                    }
                   
                }
                let sortedArray = filteredAray.sort {$0.log_date > $1.log_date}
                self.reloadTheTableViewwithArray(sortedArray)
                
            }
        }
    }
    
    func reloadTheTableViewwithArray(progressArray: [ProgressReport]) {
        
        if progressType == ProgressType.Macros {
            
            self.sortTheMacroArray(progressArray, completionHandler: { (sortedArray) -> () in
                self.arrayData = sortedArray
                self.tableViewProgress.reloadData()
            })
        } else if progressType == ProgressType.Exercise {
            
            //seperate the cardio and strength types from the exercise array
            cardioProgressReports = progressArray.filter() {
                return $0.exercise_type == ExerciseCategory.CardioVascular.rawValue
            }
            
            strengthProgressReports = progressArray.filter() {
                return $0.exercise_type == ExerciseCategory.Strength.rawValue
            }
            
            //sort the cardio array and strength array based on the date
            self.sortTheArray(cardioProgressReports, completionHandler: { (sortedArray) -> () in
                self.cardioarrayData = sortedArray
                self.tableViewProgress.reloadData()
            })
            
            self.sortTheArray(strengthProgressReports, completionHandler: { (sortedArray) -> () in
                self.strengthArrayData = sortedArray
                self.tableViewProgress.reloadData()
            })
            
        } else {
            
            self.sortTheArray(progressArray, completionHandler: { (sortedArray) -> () in
                self.arrayData = sortedArray
                self.tableViewProgress.reloadData()
            })
        }
    }
    
    func sortTheMacroArray(progressArray: [ProgressReport],
        completionHandler:(sortedArray: [[ProgressReport]])->()) {
            
            var sortArray = [[ProgressReport]]()
            
            // date formatter
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            
            // group data weekly
            for date in currentWeekArray {
                
                // filter out progress reports for the day
                sortArray.append(progressArray.filter() { progressReport in
                    return dateFormatter.dateFromString(progressReport.log_date)?.isEqualToDate(date) ?? false
                    })
            }
            
            DailyRequirement.fetchDailyMacroRequirements(progressType.description, completionHandler: { (dailyRequirement) -> () in
                let macroDaily: [DailyRequirement] = dailyRequirement.map({
                    return $0 as! DailyRequirement
                })
                //print("first object ----\(macroDaily.first)")
                self.macroDailyRequirement = macroDaily
                
                self.macroCalculation(progressArray)
                completionHandler(sortedArray: sortArray)
                
            })
    }
    
    func macroCalculation(progressArray: [ProgressReport]) {
        
        //calculate total for a week
        let calorieArray: [Double] = progressArray.map { return $0.calorie.doubleValue }
        let calorieTotal: Double   = calorieArray.reduce(0) { return $0 + $1 }
        let proteinArray: [Double] = progressArray.map { return $0.protein.doubleValue }
        let proteinTotal: Double   = proteinArray.reduce(0) { return $0 + $1 }
        let carbArray: [Double] = progressArray.map { return $0.carb.doubleValue }
        let carbTotal: Double   = carbArray.reduce(0) { return $0 + $1 }
        let fatArray: [Double] = progressArray.map { return $0.fat.doubleValue }
        let fatTotal: Double   = fatArray.reduce(0) { return $0 + $1 }
        let fibreArray: [Double] = progressArray.map { return $0.fibre.doubleValue }
        let fibreTotal: Double   = fibreArray.reduce(0) { return $0 + $1 }
        
        //calculate percentage over a week
        let macroRequired = self.macroDailyRequirement.first
        
        let caloriePercentage = calorieTotal > (macroRequired!.calories_total.doubleValue*7) ? 100.0 :calorieTotal/(macroRequired!.calories_total.doubleValue*7)
        let proteinPercentage = proteinTotal > (macroRequired!.protein_total.doubleValue*7) ? 100.0 : proteinTotal/(macroRequired!.protein_total.doubleValue*7)
        let carbsPercentage = carbTotal > (macroRequired!.carbs_total.doubleValue*7) ? 100.0 : carbTotal/(macroRequired!.carbs_total.doubleValue*7)
        let fatPercentage = fatTotal > (macroRequired!.fat_total.doubleValue*7) ? 100.0 : fatTotal/(macroRequired!.fat_total.doubleValue*7)
        let fiberPercentage = fibreTotal > (macroRequired!.fiber_total.doubleValue*7) ? 100.0 : fibreTotal/(macroRequired!.fiber_total.doubleValue*7)
        
        //make this to an array of dictionaries
        macroTableData.removeAll()
        macroTableData.append(["type":&&MacroTableRows.Calories.rawValue, "total":calorieTotal.stringValue, "percentage":caloriePercentage.stringValue ])
        macroTableData.append(["type":&&MacroTableRows.Protein.rawValue, "total":proteinTotal.stringValue, "percentage":proteinPercentage.stringValue ])
        macroTableData.append(["type":&&MacroTableRows.Carb.rawValue, "total":carbTotal.stringValue, "percentage":carbsPercentage.stringValue ])
        macroTableData.append(["type":&&MacroTableRows.Fat.rawValue, "total":fatTotal.stringValue, "percentage":fatPercentage.stringValue ])
        macroTableData.append(["type":&&MacroTableRows.Fiber.rawValue, "total":fibreTotal.stringValue, "percentage":fiberPercentage.stringValue])
    }
    
    func sortTheArray(progressArray: [ProgressReport],
        completionHandler:(sortedArray: [[ProgressReport]])->()) {
            
            // sort the result array week wise for exercise/bodyfat/weight
            self.progressReports = progressArray.map({
                return $0 as ProgressReport
            })
            var sortArray = [[ProgressReport]]()
            
            // date formatter
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            
            // group data weekly
            for weekDictionary in theWeekSortedArray {
                
                // filter out progress reports for the week
                sortArray.append(progressArray.filter() { progressReport in
                    return dateFormatter.dateFromString(progressReport.log_date)?.isInRange(weekDictionary["startDate"]!, endDate: weekDictionary["endDate"]!) ?? false
                    })
            }
            
            completionHandler(sortedArray: sortArray)
    }
    
    // table view delegate and datasource methods
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return progressType.sections
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var noOfRows = 0
        
        switch progressType {
        case .Macros:
            noOfRows = 1+macroTableData.count
        case .Weight, .Bodyfat:
            noOfRows = 3+progressReports.count
        case .Exercise:
            if section == 0 {
                noOfRows = 3+strengthProgressReports.count
            } else {
                noOfRows = 3+cardioProgressReports.count
            }
        }
        return noOfRows
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell: UITableViewCell?
        // Configure the cell...
        
        switch progressType {
            
        case .Macros :
            
            if indexPath.row == 0 {
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("kChartCell") as! ProgressChartTableViewCell
                cellGoalInfo.labelNoDataGroupedChart.hidden = true
                cellGoalInfo.progressType = progressType
                cellGoalInfo.macroDailyRequirement = macroDailyRequirement
                cellGoalInfo.xAxisData = xAxisLabels
                cellGoalInfo.chartData = arrayData
                cell = cellGoalInfo
                
            } else {
                // populate MacroItemsCell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("kMacroItemsCell") as! MacroListCell
                cellGoalInfo.itemDetails = macroTableData[indexPath.row-1]
                cell = cellGoalInfo
            }
            
        case .Bodyfat:
            
            if indexPath.row == 0 {
                // populate goal cell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("kGoalInfoCell") as! GoalInfoTableViewCell
                cellGoalInfo.exerciseType = ExerciseCategory.None
                cellGoalInfo.progressType = progressType
                cell = cellGoalInfo
            } else if indexPath.row ==  1 {
                
                // populate chart cell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("kChartCell") as! ProgressChartTableViewCell
                cellGoalInfo.labelNoDataScatterPlot.hidden = true
                cellGoalInfo.progressType = progressType
                cellGoalInfo.xAxisData = xAxisLabels
                cellGoalInfo.chartData = arrayData
                cell = cellGoalInfo
            } else if indexPath.row ==  2 {
                // populate Entries cell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("KEntriesCell") as! EntriesTableViewCell
                cellGoalInfo.buttonLogProgress.hidden = false
                cell = cellGoalInfo
                
            } else {
                // populate date cell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("KDataCell") as! DataTableViewCell
                cellGoalInfo.progressType = progressType
                cellGoalInfo.progressReport = progressReports[indexPath.row - 3] as ProgressReport
                cell = cellGoalInfo
            }
            
        case .Exercise:
            
            if indexPath.row == 0 {
                // populate goal cell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("kGoalInfoCell") as! GoalInfoTableViewCell
                if indexPath.section == 0 {
                    cellGoalInfo.exerciseType = ExerciseCategory.Strength
                    cellGoalInfo.progressType = ProgressType.Weight
                    
                } else {
                    cellGoalInfo.exerciseType = ExerciseCategory.CardioVascular
                    cellGoalInfo.progressType = ProgressType.Exercise
                    
                }
                cell = cellGoalInfo
            } else if  indexPath.row == 1 {
                // populate chart cell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("kChartCell") as! ProgressChartTableViewCell
//                cellGoalInfo.labelNoDataScatterPlot.hidden = true
                cellGoalInfo.progressType = progressType
                cellGoalInfo.xAxisData = xAxisLabels
                
                // for 0 index pass the strength array data
                if indexPath.section == 0 {
                    cellGoalInfo.exerciseType = ExerciseCategory.Strength
                    cellGoalInfo.chartData = strengthArrayData
                } else if indexPath.section == 1 {
                    cellGoalInfo.exerciseType = ExerciseCategory.CardioVascular
                    cellGoalInfo.chartData = cardioarrayData
                }
                cell = cellGoalInfo
            } else if  indexPath.row == 2 {
                // populate Entries cell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("KEntriesCell") as! EntriesTableViewCell
                cellGoalInfo.buttonLogProgress.hidden = true
                cell = cellGoalInfo
            } else {
                
                // populate date cell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("KDataCell") as! DataTableViewCell
                cellGoalInfo.progressType = progressType
                if indexPath.section == 0 {
                    cellGoalInfo.progressReport = strengthProgressReports[indexPath.row - 3] as ProgressReport
                    
                } else if indexPath.section == 1 {
                    cellGoalInfo.progressReport = cardioProgressReports[indexPath.row - 3] as ProgressReport
                }
                cell = cellGoalInfo
            }
            
        case .Weight:
            
            if indexPath.row == 0 {
                // populate goal cell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("kGoalInfoCell") as! GoalInfoTableViewCell
                cellGoalInfo.exerciseType = ExerciseCategory.None
                cellGoalInfo.progressType = progressType
                cell = cellGoalInfo
            } else if indexPath.row == 1 {
                // populate chart cell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("kChartCell") as! ProgressChartTableViewCell
                cellGoalInfo.labelNoDataScatterPlot.hidden = true
                cellGoalInfo.progressType = progressType
                cellGoalInfo.xAxisData = xAxisLabels
                cellGoalInfo.chartData = arrayData
                cell = cellGoalInfo
            } else if indexPath.row == 2 {
                // populate Entries cell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("KEntriesCell") as! EntriesTableViewCell
                cellGoalInfo.buttonLogProgress.hidden = false
                cell = cellGoalInfo
            } else {
                // populate date cell
                let cellGoalInfo =  tableView.dequeueReusableCellWithIdentifier("KDataCell") as! DataTableViewCell
                cellGoalInfo.progressType = progressType
                cellGoalInfo.progressReport = progressReports[indexPath.row - 3] as ProgressReport
                cell = cellGoalInfo
            }
        }
        cell?.selectionStyle = UITableViewCellSelectionStyle.None
        return cell!
    }
    
    func titleForHeaderForSection(section:Int)->NSString
    {
        switch (section)
        {
        case 0 : return &&"strength"
        case 1 : return &&"cardiovascular"
        case 2 : return "Third Section"
        case 3 : return "Fourth Section"
        case 4 : return "Fifth Section"
        default : return "Last Section"
            
        }
    }
    
    func tableView(tableView: UITableView, editingStyleForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCellEditingStyle {
        return UITableViewCellEditingStyle.None
    }
    
    func tableView( tableView : UITableView,  titleForHeaderInSection section: Int)->String {
        return progressType == ProgressType.Exercise ? titleForHeaderForSection(section) as String : ""
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        if progressType == ProgressType.Exercise{
            return 45.0
        }else if progressType == ProgressType.Weight {
            if section == 1 {
                return 30
            }
            
        }else if progressType == ProgressType.Bodyfat {
            if section == 1 {
                return 30
            }
            
        }
        return 0.0
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        var height: CGFloat?
        switch progressType {
        case ProgressType.Macros :
            if indexPath.row == 0 {
                height = 300.0
            } else {
                height = 40.0
            }
            
        case ProgressType.Bodyfat:
            
            if indexPath.row == 0 {
                return 74.0
            } else if indexPath.row == 1 {
                return 300.0
            } else if indexPath.row == 2 {
                return 40.0
            } else {
                return 50.0
            }
            
        case ProgressType.Exercise:
            
            if indexPath.row == 0 {
                height = 72.0
                
            } else if indexPath.row == 1{
                height = 300.0
                
            } else if indexPath.row == 2{
                height = 40.0
            } else {
                height = 50.0
            }
            
        default :
            if indexPath.row == 0 {
                return 74.0
            } else if indexPath.row == 1 {
                return 300.0
            } else if indexPath.row == 2 {
                return 40.0
            } else {
                return 50.0
            }
            
        }
        return height!
    }
    
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView(frame: CGRectZero)
    }
    
    var weekStartDate: NSDate {
        
        var startDate = NSDate()
        
        let dayofweek = currentDate.dateComponents().weekday
        let dateComponents = currentDate.dateComponents()
        dateComponents.day = dateComponents.day - (dayofweek - 2)
        startDate = NSCalendar.currentCalendar().dateFromComponents(dateComponents)!
        return startDate
    }
    
    var weekEndDate: NSDate {
        
        var endDate = NSDate()
        
        let dayofweek = currentDate.dateComponents().weekday
        let dateComponents = currentDate.dateComponents()
        dateComponents.day = dateComponents.day + (7 - dayofweek) + 1
        endDate = NSCalendar.currentCalendar().dateFromComponents(dateComponents)!
        return endDate
    }
    
    var monthStartDate: NSDate {
        
        return currentDate.startOfMonth()!
    }
    
    var monthEndDate: NSDate {
        
        return currentDate.endOfMonth()!
    }
    
    //switch between months and between weeks
    @IBAction func switchTheDatePickerValue(sender: UIButton) {
        
        currentSelectedButton.userInteractionEnabled = true
        currentSelectedButton = sender
        progressReports.removeAll()
        cardioProgressReports.removeAll()
        strengthProgressReports.removeAll()
        arrayData.removeAll()
        strengthArrayData.removeAll()
        cardioarrayData.removeAll()
        macroTableData.removeAll()
        self.tableViewProgress .reloadData()
        
        let components = NSDateComponents()
        if progressType == ProgressType.Macros {
            // increase or decrease date by a week
            components.day = sender.tag == 1 ?  -7 : 7
            
        } else {
            components.month = sender.tag == 1 ?  -1 : 1
            
        }
        let newCurrentDate = NSCalendar.currentCalendar().dateByAddingComponents(components, toDate: currentDate, options: NSCalendarOptions(rawValue: 0))
        
        currentDate = newCurrentDate!
    }
    
    @IBAction func buttonActionManageGoals(sender: UIBarButtonItem) {
        
        // instantiate the main storyboard
        let manageStoryboard = UIStoryboard(name: "ManageGoalsStoryboard", bundle: NSBundle.mainBundle())
        
        // instantiate the initial view controller
        let initialViewController = manageStoryboard.instantiateViewControllerWithIdentifier("kManageGoalsList") as! ManageGoalsListViewController
        
        self.navigationController?.pushViewController(initialViewController, animated: true)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        
        if segue.identifier == StoryBoard.SegueIdentifiers.LogProgress {
            
            let logProgressViewController = segue.destinationViewController as! LogProgressViewController
            logProgressViewController.progressType = progressType
        }
    }
    
    @IBAction func unwindToProgressViewController(segue: UIStoryboardSegue) {
        
    }
    
}
