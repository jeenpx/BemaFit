//
//  ActivityLevelCell.swift
//  FlexYourMacros
//
//  Created by dbgattila on 6/1/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol ActivityLevelCellDelegate {
    func activityLevelCell(textField: UITextField, activityLevels: [ActivityLevelModel], cellForSelectedTextField: ActivityLevelCell)
}

class ActivityLevelCell: UITableViewCell, UITextFieldDelegate {
    
    @IBOutlet weak var labelActivityDescription: UILabel!
    @IBOutlet weak var textFieldActivityName: UITextField!
    
    var activityLevelCellDelegate: ActivityLevelCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    var activityLevel: ActivityLevelModel? {
        didSet {
            
            
            textFieldActivityName.text = activityLevel?.activityName
            labelActivityDescription.text = activityLevel?.activityDescription
        }
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        activityLevelCellDelegate?.activityLevelCell(textField, activityLevels: AppConfiguration.sharedAppConfiguration.activityLevels, cellForSelectedTextField: self)
    }
    
    func getActivityLevels() -> [String] {
        var activityLevelNames = [String]()
        let activityLevels = AppConfiguration.sharedAppConfiguration.activityLevels// {
        for activityLevel in activityLevels {
            activityLevelNames.append(activityLevel.activityName!)
        }
        //        }
        return activityLevelNames
    }
    
}
