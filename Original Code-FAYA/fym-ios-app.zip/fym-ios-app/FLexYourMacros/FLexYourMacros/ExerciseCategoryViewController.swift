//
//  ExerciseCategoryViewController.swift
//  FlexYourMacros
//
//  Created by mini on 26/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

enum ExerciseCategory: String {
    case CardioVascular = "Cardiovascular"
    case Strength = "Strength"
    case None = ""

    
    static var Types = [CardioVascular, Strength]
}

class ExerciseCategoryTableViewCell: UITableViewCell {
    
    @IBOutlet weak var labelExerciseCategoryName: UILabel!
    
    var exercise:ExerciseCategoryModel? {
        didSet {
            labelExerciseCategoryName.text = exercise?.exerciseCategoryName
        }
    }
}

class ExerciseCategoryViewController: UITableViewController, UIAlertViewDelegate {
    
    var exerciseCategories = [ExerciseCategoryModel]()
    var logDate: NSDate = NSDate()
    var isFromDashboard = true
    var selectedType: String = ""
    
    var alert1: UIAlertView?
    
    struct StoryBoard {
        
        struct CellIdentifiers {
            static let Exercise = "kExercise"
        }
        
        struct SegueIdentifiers {
            
            static let Exercise = "kExercise"
            static let ViewLog  = "kViewLogExercise"
        }
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // internet check
        //  internet check
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        //configureData
        configureData()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    func configureData() {
        
//        MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        SVProgressHUD.show()

        
        ExerciseCategoryModel.getExerciseCategories { (exerciseCategories) -> () in
        
            SVProgressHUD.dismiss()

//        MBProgressHUD.hideHUDForView(self.view, animated: true)
        self.exerciseCategories = exerciseCategories
        self.tableView.reloadData()
        }
    }
    
   
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return exerciseCategories.count == 0 ? 0 : exerciseCategories.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.Exercise, forIndexPath: indexPath) as! ExerciseCategoryTableViewCell
        cell.exercise = exerciseCategories[indexPath.row]
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
      
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! ExerciseCategoryTableViewCell

        selectedType = cell.exercise!.exerciseCategoryId
        self.performSegueWithIdentifier(StoryBoard.SegueIdentifiers.Exercise, sender: self)
    }
    
    override func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView(frame: CGRectZero)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == StoryBoard.SegueIdentifiers.Exercise {
            let exerciseListViewController = segue.destinationViewController as! ExerciseListViewController
            exerciseListViewController.logDate = logDate
            exerciseListViewController.selectedExerciseType = selectedType
            exerciseListViewController.isFromDashboard = isFromDashboard
        }
    }
    
    func showAlert(title:String,message:String) {
        if #available(iOS 8.0, *) {
            
            let alertView = UIAlertController(title: title,
                message: message, preferredStyle: .Alert)
            alertView.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
            presentViewController(alertView, animated: true, completion: nil)
            
        } else {
            // Fallback on earlier versions
            
            alert1 = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"OK")
            alert1?.show()
        }
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if alertView == alert1 {
            
        }
    }
    
    @IBAction func buttonActionBack(sender: UIBarButtonItem) {
        
        if isFromDashboard {
            self.navigationController?.popViewControllerAnimated(true)

        } else {
            self.performSegueWithIdentifier(StoryBoard.SegueIdentifiers.ViewLog, sender: self)
  
        }

    }
    
    @IBAction func unwindToExerciseCategoryViewController(segue: UIStoryboardSegue) {
        
    }
}