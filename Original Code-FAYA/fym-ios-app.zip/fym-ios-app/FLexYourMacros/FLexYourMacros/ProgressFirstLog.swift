//
//  ProgressFirstLog.swift
//  FlexYourMacros
//
//  Created by mini on 20/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import CoreData
@objc(ProgressFirstLog)

class ProgressFirstLog: NSManagedObject {

    @NSManaged var body_fat: String
    @NSManaged var weight: String
    @NSManaged var log_date: String
    @NSManaged var calorie: String
    @NSManaged var amount: String
    @NSManaged var progressFirstLogType: NSSet

    class var entityMapping : RKEntityMapping {
        
        var progressFirstLogMapping: RKEntityMapping = RKEntityMapping(forEntityForName: Constants.Tables.ProgressFirstLog, inManagedObjectStore: RestKitManager.sharedManager().managedObjectStore)
        progressFirstLogMapping .addAttributeMappingsFromDictionary(mappingDictionary)
//        progressFirstLogMapping.identificationAttributes = ["log_date"]

        return progressFirstLogMapping
    }
    
    private class var mappingDictionary: [String : String] {
        
        return(["body_fat":"body_fat", "weight":"weight", "log_date":"log_date", "calorie": "calorie", "amount" : "amount"])
    }
    
    class func fetchProgressFirstLogDetails(progressType: String, completionHandler:(firstLogDetails: [AnyObject])->()) {
        
        var error: NSError?
        let fetchRequest = NSFetchRequest()
        let entity = NSEntityDescription.entityForName(Constants.Tables.ProgressFirstLog, inManagedObjectContext: RKObjectManager.sharedManager().managedObjectStore.persistentStoreManagedObjectContext)
        fetchRequest.returnsObjectsAsFaults = false
        fetchRequest.entity = entity
//        fetchRequest.fetchLimit = 1
        
        let progressPredicate = NSPredicate(format: "SUBQUERY(progressFirstLogType, $x, $x.type = %@).@count == progressFirstLogType.@count",progressType)

        fetchRequest.predicate = progressPredicate
        
        var count = 1
        count = RKObjectManager.sharedManager().managedObjectStore.persistentStoreManagedObjectContext.countForFetchRequest(fetchRequest, error: &error)
        fetchRequest.fetchLimit = count
        
        let sortDescriptor = NSSortDescriptor(key: "log_date", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        let fetchedObjects: [AnyObject]?
        do {
            fetchedObjects = try RKObjectManager.sharedManager().managedObjectStore.persistentStoreManagedObjectContext .executeFetchRequest(fetchRequest)
        } catch var error1 as NSError {
            error = error1
            fetchedObjects = nil
        }
        completionHandler(firstLogDetails: fetchedObjects!)
    }

}
