//
//  AddressBookContact.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 31/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit
import AddressBook

class AddressBookContact: NSObject {
    
    var contactName = ""
    var contactEmail: String?
    
    // section to help tableview indexing
    var section: Int?
    
    typealias AddressBookContactCallback = (contacts: [AddressBookContact]?) -> Void
    
    convenience init(reference: ABAddressBookRef) {
        self.init()
        contactName = processContactName(reference)
        contactEmail = processContactEmail(reference)
    }
    
    // address book reference
    class func extractAddressBookReference(reference: Unmanaged<ABAddressBookRef>!) -> ABAddressBookRef? {
        if let reference = reference {
            return Unmanaged<NSObject>.fromOpaque(reference.toOpaque()).takeUnretainedValue()
        }
        return nil
    }
    
    // address book email reference
    private func extractEmailReference(reference: Unmanaged<ABMultiValueRef>!) -> ABMultiValueRef? {
        if let reference = reference {
            return Unmanaged<NSObject>.fromOpaque(reference.toOpaque()).takeUnretainedValue()
        }
        return nil
    }
    
    // address book email string
    private func extractEmailString(email: Unmanaged<AnyObject>!) -> String? {
        if let email = email {
            return Unmanaged.fromOpaque(email.toOpaque()).takeUnretainedValue() as CFStringRef as String
        }
        return nil
    }
    
    // extracts a contact name from a contact reference
    private func processContactName(reference: ABAddressBookRef) -> String {
       
        
        if let firstName = ABRecordCopyCompositeName(reference)?.takeRetainedValue() as String? {
            //print("FIRST NAME: \(firstName)")
            return firstName
        } 
        return ""
   
    }
    
    // extracts a contact email from a contact reference
    private func processContactEmail(reference: ABAddressBookRef) -> String? {
        
        // fetch email references for the contact
        let emails: ABMultiValueRef? = extractEmailReference(ABRecordCopyValue(reference, kABPersonEmailProperty))
        
        // return if the user doesn't have any emails
        if ABMultiValueGetCount(emails) <= 0 {
            return nil
        }
        
        // return the first email
        return extractEmailString(ABMultiValueCopyValueAtIndex(emails, 0))
    }
    
    class func processContacts() -> [AddressBookContact] {
        var errorRef: Unmanaged<CFError>?
        let addressBook: ABAddressBookRef? = extractAddressBookReference(ABAddressBookCreateWithOptions(nil, &errorRef))
        
        let contactList: NSArray = ABAddressBookCopyArrayOfAllPeople(addressBook).takeRetainedValue()
        
        var contacts: [AddressBookContact] = []
        for contact in contactList {
            
            if AddressBookContact(reference: contact).contactName != "" {
                contacts.append(AddressBookContact(reference: contact))
            }
        }
        
        return contacts
    }
    
    class func fetchAllContacts(completionHandler: AddressBookContactCallback?) {
        
        // check authorization status
        if ABAddressBookGetAuthorizationStatus() == .Denied || ABAddressBookGetAuthorizationStatus() == .Restricted {
            // XXX permission denied
            // handle this
            completionHandler?(contacts: nil)
            return
        }
        
        else if ABAddressBookGetAuthorizationStatus() == .Authorized {
            
            // fetch all contacts and fire completion handler
            completionHandler?(contacts: processContacts())
            return
        }
        
        else {
            
            var errorRef: Unmanaged<CFError>? = nil
            
            let addressBook: ABAddressBookRef? = extractAddressBookReference(ABAddressBookCreateWithOptions(nil, &errorRef))
            ABAddressBookRequestAccessWithCompletion(addressBook) { (success, error) in
                if error != nil {
                    // XXX handle errors
                    completionHandler?(contacts: nil)
                    return
                }
                
                // if user pressed dont allow
                if !success{
                    completionHandler?(contacts: nil)
                    return
                }
                
                // fetch names with a valid email
                completionHandler?(contacts: self.processContacts())
            }
        }
    }
    
    class func fetchAllContactsWithEmail(completionHandler: AddressBookContactCallback?) {
        
        fetchAllContacts { (contacts) in
            
            // handle errors
            if contacts == nil {
                completionHandler?(contacts: nil)
                return
            }
            
            // filter out contacts with a valid email
            completionHandler?(contacts: contacts?.filter { $0.contactEmail != nil })
        }
    }
}
