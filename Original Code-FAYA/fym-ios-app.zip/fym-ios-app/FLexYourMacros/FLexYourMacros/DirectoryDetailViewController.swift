//
//  DirectoryDetailViewController.swift
//  FlexYourMacros
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

public enum DirectoryCellMode: String {
    case Monday = "Mon"
    case Tuesday = "Tue"
    case Wednesday = "Wed"
    case Thursday = "Thu"
    case Friday = "Fri"
    case Saturday = "Sat"
    case Sunday = "Sun"
    static var modes = [Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday]
}

class DescriptionCell: UITableViewCell {
    
    @IBOutlet weak var labelDescription: UILabel!
    @IBOutlet weak var viewVerified: UIView!
    
    @IBOutlet weak var viewVerifiedHeight: NSLayoutConstraint!
    var  directory = DirectoryModel() {
        didSet {
            
            if directory.directoryDescription == "" {
                labelDescription.hidden = true
                showEmptyTableViewCellMessage(&&"no_description")
            }
            else {
                // set value for company's description
                labelDescription.text = directory.directoryDescription
            }
            
            if directory.premiumListing == "0" {
                viewVerifiedHeight.constant = 0
                
                // hide verified view if premium listing is 0
                viewVerified.hidden = true
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}


class DirectoryDetailViewController: UIViewController, UIAlertViewDelegate, ShareSocialMediaDelegate, UITableViewDataSource, UITableViewDelegate {
    
    var businessDirectory = DirectoryModel()
    
    var businessDirectoryId = ""
    
    // tells whether to load the model from businessDirectoryId
    var shouldLoadFromId: Bool = false
    
    @IBOutlet weak var imageViewCompany: UIImageView!
    @IBOutlet weak var tableViewDirectoryDetails: UITableView!
    
    @IBOutlet weak var constraintViewNoRecordsHeight: NSLayoutConstraint!
    
    @IBOutlet weak var viewHeader: UIView!
    @IBOutlet weak var viewNoRecords: UIView!
    @IBOutlet weak var buttonItemShare: UIBarButtonItem!
    
    var offscreenCells = [String: DescriptionCell]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // load placeholder model
        configureView()
        
        if shouldLoadFromId {
            DirectoryModel.getBusinessDirectory(businessDirectoryId) { (businessDirectory) in
                
                self.businessDirectory = businessDirectory
                
                dispatch_async(dispatch_get_main_queue()) {
                    self.configureView()
                }
            }
        }
        else {
            configureView()
        }
    }
    
    func configureView() {
        
        //print("kMainScreenWidth:\(kMainScreenWidth)")
        
        // set navigation bar title
        navigationItem.title = businessDirectory.name
        
        buttonItemShare.image = UIImage(named: &&"directory_button_share")
        
        // set value for company's image
        if let imagePath = businessDirectory.images?[0].file {
            imageViewCompany.setImageWithURL(NSURL(string: imagePath), placeholderImage: UIImage(named: "PlaceHolderDirectory"))
            
        }
        
        tableViewDirectoryDetails.rowHeight = UITableViewAutomaticDimension
        tableViewDirectoryDetails.estimatedRowHeight = 32.0
        tableViewDirectoryDetails.tableFooterView = UIView(frame: CGRectZero)
        
        tableViewDirectoryDetails.reloadData()
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        switch indexPath.row {
            
        case 0:
            let cell = tableView.dequeueReusableCellWithIdentifier("kDescriptionCell") as! DescriptionCell
            cell.directory = businessDirectory
            cell.setNeedsUpdateConstraints()
            cell.updateConstraintsIfNeeded()
            return cell
            
        case 1:
            let cell = tableView.dequeueReusableCellWithIdentifier("kCompanyDetailsCell") as! CompanyDetailsTableCell
            cell.directory = businessDirectory
            return cell
            
        case 2, 3, 4, 5, 6, 7, 8:
            let cell = tableView.dequeueReusableCellWithIdentifier("kCompanyTimingsCell") as! CompanyTimingsCell
            cell.directoryCellMode = DirectoryCellMode.modes[indexPath.row - 2]
            cell.directory = businessDirectory
            return cell
        default:
            break
        }
        return UITableViewCell()
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return businessDirectory.workingHours?.count > 0 ? 9 : 3
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.row == 0 {
            
            var cell = offscreenCells["kDescriptionCell"]
            if cell == nil {
                cell = tableView.dequeueReusableCellWithIdentifier("kDescriptionCell") as? DescriptionCell
                offscreenCells["kDescriptionCell"] = cell
            }
            
            cell?.directory = businessDirectory
            
            cell?.setNeedsUpdateConstraints()
            cell?.updateConstraintsIfNeeded()
            cell?.bounds = CGRectMake(0.0, 0.0, CGRectGetWidth(tableViewDirectoryDetails.bounds), CGRectGetHeight(cell!.bounds))
            
            cell?.setNeedsLayout()
            cell?.layoutIfNeeded()
            
            cell?.labelDescription.preferredMaxLayoutWidth = CGRectGetWidth(cell!.labelDescription.bounds)
            cell?.labelDescription.setNeedsUpdateConstraints()
            
            // Get the actual height required for the cell's contentView
            var height = cell?.contentView.systemLayoutSizeFittingSize(UILayoutFittingCompressedSize).height
            
            // Add an extra point to the height to account for the cell separator, which is added between the bottom
            // of the cell's contentView and the bottom of the table view cell.
            height = height! + 1
            
            return height!
            
        }
        else if indexPath.row == 1 {
            return 62
        }
        else {
            
            if businessDirectory.workingHours?.count == 0 {
                // no working hours
                
                let height = tableViewDirectoryDetails.frame.height - tableViewDirectoryDetails.contentSize.height
                
                if height <= 0 {
                    return 32
                }
                else {
                    return height
                }
            }
            else {
                // working hours available
                
                return 32
            }
        }
    }
    
    @IBAction func buttonActionCheckIn(sender: AnyObject) {
        //check in button is pressed
        
        var checkInName = " "
        if let name = businessDirectory.name {
            checkInName = " " + name
        }
        if #available(iOS 8.0, *) {
            
            let alertView = UIAlertController(title: NSLocalizedString("directory_detail_alert_title", comment: ""),
                
                message: NSLocalizedString("directory_detail_alert_message", comment: "") + checkInName + "?", preferredStyle: .Alert)
            alertView.addAction(UIAlertAction(title: NSLocalizedString("directory_detail__cancel", comment: ""), style: .Cancel, handler: nil))
            alertView.addAction(UIAlertAction(title: NSLocalizedString("directory_detail_check_in", comment: ""), style: .Default){ action -> Void in
                self.checkIn()
                })
            presentViewController(alertView, animated: true, completion: nil)
            
        } else {
            // Fallback on earlier versions
            
            UIAlertView(title: NSLocalizedString("directory_detail_alert_title", comment: ""), message: NSLocalizedString("directory_detail_alert_message", comment: "") + checkInName, delegate: self, cancelButtonTitle: NSLocalizedString("directory_detail__cancel", comment: ""), otherButtonTitles: NSLocalizedString("directory_detail_check_in", comment: "")).show()
        }
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        if buttonIndex == 1 {
            checkIn()
        }
    }
    
    func checkIn() {
        // check in api call
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        if let id = businessDirectory.id {
            DirectoryCheckInResponse.directoryCheckIn(id) { (status) -> () in
                //print(status)
                self.showAlert(&&"notice", message: status)
            }
        }
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    func showAlert(title: String, message: String) {
        
        if #available(iOS 8.0, *) {
            
            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
            
            alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
            
            self.presentViewController(alert, animated: true, completion: nil)
            return
        } else {
            // Fallback on earlier versions
            
            
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"ok").show()
            return
        }
    }
    
    @IBAction func shareButtonClicked(sender: AnyObject) {
        // share button clicked
        
        //print("shareButtonClicked:")
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        let businessName = businessDirectory.name ?? ""
        let businessDescription = businessDirectory.directoryDescription ?? ""
        let businessImageUrl = businessDirectory.images?[0].file
        let businessWebsiteUrl = businessDirectory.website
        
        ShareSocialMedia.sharedManager.shareSocialMediaDelegate = self
        ShareSocialMedia.sharedManager.shareOnSocialMedia(self, image: imageViewCompany.image, name: businessName, message: businessDescription, view: self.view, imageUrl: businessImageUrl!, websiteUrl: businessWebsiteUrl!)
    }
    
    func shareSocialMedia(sharedStatus: String) {
        
        showAlert(&&"notice", message: sharedStatus)
    }
    
    class func loadDirectoryDetail(id: String, fromViewcontroller: UIViewController) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let directoryDetailViewController = storyBoard.instantiateViewControllerWithIdentifier("kDirectoryDetailView") as! DirectoryDetailViewController
        directoryDetailViewController.businessDirectoryId = id
        directoryDetailViewController.shouldLoadFromId = true
        fromViewcontroller.navigationController?.pushViewController(directoryDetailViewController, animated: true)
    }
}



