//
//  DailyMealPlanUpdateResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 24/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import Foundation
class DailyMealPlanUpdateResponse:NSObject {
    
    var meta: MetaModel?
    var dailyMealPlanId: String?
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
        responseMapping.addPropertyMapping(metaModelMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let dailyMealPlanUpdateResponseDescriptor = RKResponseDescriptor(mapping: DailyMealPlanUpdateResponse.responseMapping, method: .PUT, pathPattern: Constants.ServiceConstants.kDailyMealPlanUpdate, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return dailyMealPlanUpdateResponseDescriptor
    }
    
    class func updateDailyMealPlan(dailyMealPlanId: String,params: [String: AnyObject], completionHandler: (error: NSError?) -> ()) {
        
        SVProgressHUD.show()
        
        RestKitManager.setToken(true)
        
        let dailyMealPlanUpdateResponse = DailyMealPlanUpdateResponse()
        dailyMealPlanUpdateResponse.dailyMealPlanId = dailyMealPlanId
        
        
        // create a post request
        let request = RestKitManager.sharedManager().requestWithObject(dailyMealPlanUpdateResponse, method: .PUT, path:nil, parameters: nil)
        
        // set params as body
        request.HTTPBody = try? NSJSONSerialization.dataWithJSONObject(params, options: NSJSONWritingOptions())
        
        // create an operation with the request
        let operation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation, mappingResult) in
            
            let dailyMealPlanCreateResponse = mappingResult.firstObject as! DailyMealPlanUpdateResponse
            
            // check for success
            if dailyMealPlanCreateResponse.meta?.responseCode != 200 {
                
                SVProgressHUD.dismiss()
                
                // configure alert message
                let message = "alert_log_daily_meal_plan_message"
                
                
                completionHandler(error: NSError(domain: "FYM.DailyMealPlan", code: 99, userInfo: ["title": "error", "message": message]))
            }
            else {
                SVProgressHUD.dismiss()
                completionHandler(error: nil)
            }
            }, failure: { (operation, error) in
                //print("XXX failed to log food with error \(error)")
                SVProgressHUD.dismiss()
                completionHandler(error: NSError(domain: "FYM.DailyMealPlan", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"]))
        })
        
        // enque request operation
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
}