//
//  ResendEmailResponse.swift
//  FlexYourMacros
//
//  Created by mini on 05/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//
import Foundation

private let _ResendEmailResponse = ResendEmailResponse()

class ResendEmailModel: NSObject {
    
    var status: String = ""
    
    class var objectMapping: RKObjectMapping {
        let tokenMapping = RKObjectMapping(forClass: self)
        tokenMapping.addAttributeMappingsFromDictionary(ResendEmailModel.mappingDictionary)
        return tokenMapping
    }
    
    class var mappingDictionary: [String : String] {
        return(["status":"status"])
    }
    
}

class ResendEmailResponse: NSObject {
    
    var resendEmailModel: ResendEmailModel?
    var metaModel: MetaModel?
    
    class var sharedResendEmailResponse: ResendEmailResponse {
        return _ResendEmailResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        // give reference to resend email model mapping
        responseMapping.addPropertyMapping(ResendEmailResponse.metaModelKeyMapping)

        responseMapping.addPropertyMapping(ResendEmailResponse.resendEmailModellKeyMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.resenEmailUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var resendEmailModellKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathResendEmail, toKeyPath: "resendEmailModel", withMapping: ResendEmailModel.objectMapping)
    }
    
    class func resendEmail(user_email: String, completionHandler: (resendEmailResponse: ResendEmailModel?) -> ()) {
        
        RestKitManager.setupBasicAuth()

        var parameterDictionary: [String:String] {
            
            // create the parameter dictionary
            return ["email":user_email]
        }
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(nil, method: .POST, path: Constants.ServiceConstants.resenEmailUrl, parameters: parameterDictionary, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let response = mappingResult.firstObject as! ResendEmailResponse
            
            if response.metaModel?.responseCode != 200 {
                
                completionHandler(resendEmailResponse: nil)

                return;
            }

            completionHandler(resendEmailResponse: response.resendEmailModel!)
            
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                //print("failed to load contact us with error \(error)")
                
                completionHandler(resendEmailResponse: nil)
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
        
    }
    
    
}
