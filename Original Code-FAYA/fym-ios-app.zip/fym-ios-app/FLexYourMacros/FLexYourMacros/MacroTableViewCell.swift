//
//  MacroTableViewCell.swift
//  ChartViews
//
//  Created by DBG-39 on 25/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

import UIKit

class MacroTableViewCell: UITableViewCell {

    var macroColor: UIColor = UIColor.clearColor() {
        didSet {
            viewBullet.backgroundColor = macroColor
        }
    }

    func configure(macroName: String, macroTotal: String, macroAchieved: String) {
        
        labelMacroName.text = macroName
        
        let macroTotalValue = macroTotal.doubleValue
        
        let macroAchievedValue = macroAchieved.doubleValue
        
        let macroPercentage = (macroAchievedValue/macroTotalValue)*100
        
        labelMacroGoal.text = "\(macroTotal.singleDecimalValue) g"
        
        labelMacroTotal.text = "\(macroPercentage.stringValue.singleDecimalValue)%"

    }

    @IBOutlet private weak var viewBullet: UIView!
    @IBOutlet private weak var labelMacroName: UILabel!
    @IBOutlet private weak var labelMacroTotal: UILabel!
    @IBOutlet private weak var labelMacroGoal: UILabel!
    @IBOutlet private weak var constraintTextMargin: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // adjust text margin
        constraintTextMargin.constant = macroColor == UIColor.clearColor() ? -10 : 8
    }
}
