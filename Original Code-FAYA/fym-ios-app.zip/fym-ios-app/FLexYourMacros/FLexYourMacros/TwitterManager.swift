//
//  TwitterManager.swift
//  SWTShareTwitter
//
//  Created by DBG on 23/03/15.
//  Copyright (c) 2015 dbg. All rights reserved.
//

import Foundation
import Social
import Accounts

class TwitterManager {
    
    class var ErrorCodeAccountNotSetUp: Int {
        return 404
    }
    
    let requestUrl = "https://upload.twitter.com/1/statuses/update_with_media.json"
    
    typealias FailureBlock = (error: NSError) -> ()
    typealias SuccessBlock = (data: NSData, urlResponse: NSHTTPURLResponse) -> ()
    typealias SuccessBlock1 = (data: String) -> ()
    
    // singleton manager
    class var sharedManager: TwitterManager {
        struct Singleton {
            static let instance = TwitterManager()
        }
        return Singleton.instance
    }
    
    func shareTweetsUsingUI(viewController: UIViewController,messages: String, andImage image: UIImage, withSuccessBlock successBlock: SuccessBlock1, andFailureBlock failureBlock: FailureBlock) {
        
        let viewController = viewController
        if SLComposeViewController.isAvailableForServiceType(SLServiceTypeTwitter) {
            let tweetSheet:SLComposeViewController = SLComposeViewController(forServiceType: SLServiceTypeTwitter)
            tweetSheet.setInitialText(messages)
            tweetSheet.addImage(image)
            
            tweetSheet.completionHandler = {
                result -> Void in
                let getResult = result as SLComposeViewControllerResult;
                switch(getResult.rawValue) {
                case SLComposeViewControllerResult.Cancelled.rawValue:
                    print("Cancelled")
                case SLComposeViewControllerResult.Done.rawValue:
                    print("It's Work!")
                default:
                    print("Error!")
                }
                successBlock(data: "Success")
                viewController.dismissViewControllerAnimated(true, completion: nil)
            }
            
            
            viewController.presentViewController(tweetSheet, animated: true, completion: nil)
            
        } else {
            failureBlock(error:NSError(domain: "",
                code: TwitterManager.ErrorCodeAccountNotSetUp,
                userInfo: [NSLocalizedDescriptionKey: "Twitter Account not setup"]));
        }
        
        
        
    }
    func shareMessage(messages: NSDictionary, andImage image: UIImage, withSuccessBlock successBlock: SuccessBlock, andFailureBlock failureBlock: FailureBlock) {
        // called to share text and image in twitter
        SVProgressHUD.show()
        // get the twitter account type
        let account = ACAccountStore()
        let accountType = account.accountTypeWithAccountTypeIdentifier(ACAccountTypeIdentifierTwitter)
        
        // fetch twitter accounts
        account.requestAccessToAccountsWithType(accountType, options: nil) { (status: Bool, error: NSError!) in
            
            // get accounts
            let arrayAccounts = status ? account.accountsWithAccountType(accountType) : []
            
            // twitter account not set up
            if arrayAccounts.count <= 0 {
                SVProgressHUD.dismiss()
                failureBlock(error:NSError(domain: "",
                    code: TwitterManager.ErrorCodeAccountNotSetUp,
                    userInfo: [NSLocalizedDescriptionKey: "Twitter Account not setup"]));
                return
            }
            
            // get the twitter account
            let twitterAccount = arrayAccounts.last as! ACAccount
            
            // post to twitter
            let requestURL = NSURL(string: self.requestUrl)!
            let postRequest = SLRequest(forServiceType:SLServiceTypeTwitter, requestMethod: SLRequestMethod.POST, URL: requestURL, parameters: messages as [NSObject : AnyObject])
            let imageData = UIImagePNGRepresentation(image)
            postRequest.account = twitterAccount
            postRequest.addMultipartData(imageData, withName: "media", type: "image/jpg", filename: "TwitterImage")
            postRequest.performRequestWithHandler() { (responseData: NSData!, urlResponse: NSHTTPURLResponse!, error: NSError!) in
                
                // on failure to upload the image
                if error != nil {
                    SVProgressHUD.dismiss()
                    failureBlock(error: error)
                    return
                }
                SVProgressHUD.dismiss()
                // on successfully uploaded
                successBlock(data: responseData, urlResponse: urlResponse)
            }
        }
    }
}
