//
//  CPTBarPlot+SwiftCompat.m
//  ChartViews
//
//  Created by DBG-39 on 23/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

#import "CPTBarPlot+SwiftCompat.h"

@implementation CPTBarPlot (SwiftCompat)

- (void)setBarWidthNumber:(NSNumber *)barWidthNumber {
    
    self.barWidth = barWidthNumber.decimalValue;
}

- (NSNumber *)barWidthNumber {
    return @([NSDecimalNumber decimalNumberWithDecimal:self.barWidth].doubleValue);
}

- (void)setBarOffSetNumber:(NSNumber *)barOffSetNumber {
    
    self.barOffset = barOffSetNumber.decimalValue;
}

- (NSNumber *)barOffSetNumber {
    return @([NSDecimalNumber decimalNumberWithDecimal:self.barOffset].doubleValue);
}

@end
