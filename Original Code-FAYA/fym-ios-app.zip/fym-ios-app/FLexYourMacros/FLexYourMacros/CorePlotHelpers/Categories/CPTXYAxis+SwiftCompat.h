//
//  CPTXYAxis+SwiftCompat.h
//  ChartViews
//
//  Created by DBG-39 on 20/02/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "CPTXYAxis.h"

@interface CPTXYAxis (SwiftCompat)

@property (strong, nonatomic) NSNumber *orthogonalCoordinateDecimalNumber;

@end
