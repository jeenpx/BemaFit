
//
//  DailyMealPlanAutoSuggestResponse.swift
//  FlexYourMacros
//
//  Created by Minimol BI on 08/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import Foundation

//foodlog model
class DailyMealFoodModel: NSObject {
    
    var foodId: String = ""
    var foodGuid: String = ""
    var foodName: String = ""
    var foodFocus: String = ""
    var foodBrand: String = ""
    var foodType: String = ""
    var mealType: String = ""
    var brandName: String = ""
    var servingSize: String = ""
    var calorie: String = ""
    var fat: String = ""
    var saturated: String = ""
    var polyunsaturated: String = ""
    var monounsaturated: String = ""
    var trans: String = ""
    var cholesterol: String = ""
    var sodium: String = ""
    var potassium: String = ""
    var carbs: String = ""
    var fiber: String = ""
    var sugar: String = ""
    var protien: String = ""
    var vitaminA: String = ""
    var vitaminC: String = ""
    var calcium: String = ""
    var iron: String = ""
    var createdDate: String = ""
    var statusId: String = ""
    var unit: String = ""
    var rowId: String = ""
    var parentId: String = ""
    var dependentIds: String = ""
    var servingSizeFixed: String = ""
    var foodNameSpanish = ""
    var dmpMealType: String = ""
    var uniqueID:String = ""
    class var objectMapping: RKObjectMapping {
        let foodLogMapping = RKObjectMapping(forClass: self)
        foodLogMapping.addAttributeMappingsFromDictionary(mappingDictionary)
        return foodLogMapping
    }
    
    class var mappingDictionary: [String : String] {
        return(["id":"foodId", "guid":"foodGuid", "name":"foodName", "name_es":"foodNameSpanish", "focus":"foodFocus", "type": "foodType", "meal_type": "mealType", "brand":"brandName", "serving_size": "servingSize", "calorie":"calorie", "fat": "fat", "saturated" : "saturated", "polyunsaturated": "polyunsaturated", "monounsaturated": "monounsaturated", "trans": "trans", "cholesterol": "cholesterol", "sodium": "sodium", "potassium": "potassium", "carbs": "carbs", "fiber": "fiber", "sugar": "sugar", "protien": "protien", "vitamin_a": "vitaminA", "vitamin_c": "vitaminC", "calcium": "calcium", "iron": "iron", "created_date": "createdDate", "statusId": "status_id", "unit": "unit", "row_id":"rowId", "parent":"parentId", "when_delete":"dependentIds", "serving_size_fixed":"servingSizeFixed", "fym_dmp_type":"dmpMealType","unique_id":"uniqueID"])
    }
}

private let _DailyMealPlanAutoSuggestResponse = DailyMealPlanAutoSuggestResponse()

class DailyMealPlanAutoSuggestResponse: NSObject {
    
    var metaModel = MetaModel()
    var foodSuggestedResults = [DailyMealFoodModel]()
    
    class var sharedDailyMealPlanAutoSuggestResponse: DailyMealPlanAutoSuggestResponse {
        return _DailyMealPlanAutoSuggestResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(DailyMealPlanAutoSuggestResponse.metaModelKeyMapping)
        
        // give reference to FoodListMapping
        responseMapping.addPropertyMapping(DailyMealPlanAutoSuggestResponse.autoSuggestFoodListModelKeyMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var autoSuggestFoodListModelKeyMapping : RKRelationshipMapping {
        
        //food log model is used since both auto suggested food and logged food are of same model
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathSuggestedFoodResult, toKeyPath: "foodSuggestedResults", withMapping: DailyMealFoodModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kFoodAutoSuggest, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    class func fetchSuggestedFoodList(coremealNo: String, snackNo: String, calories: String, carbs: String, proteins: String, fats: String, nutritionPlan: String, completionHandler:(foodLogList: [Food], error: NSError?)->()) {
        
        RestKitManager.setToken(true)
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            var nutritionPlanNew : String
            if nutritionPlan == "5" //if custom -> flexible
            {
                nutritionPlanNew = "1"
            }
            else if nutritionPlan == "2" //if vegetarian -> vegan
            {
                nutritionPlanNew = "3"
            }
            else
            {
                nutritionPlanNew = nutritionPlan
            }
            
            return ["coremeal": coremealNo, "snacks": snackNo, "calories": calories, "carbs": carbs, "proteins": proteins, "fats": fats, "nutritional_plan":nutritionPlanNew,"locale" : "\(NSLocale.currentLocale().objectForKey(NSLocaleLanguageCode)!)"]
        }
        
        // get the objects from the path login
        RestKitManager.sharedManager().getObjectsAtPath(Constants.ServiceConstants.kFoodAutoSuggest, parameters: parameterDictionary, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            
            // map to correct datamodel
            let response = mappingResult.firstObject as! DailyMealPlanAutoSuggestResponse
            
            let foodLogs = (response.foodSuggestedResults as [DailyMealFoodModel]).map { Food(dailyMealFoodModel: $0) }
            
            if response.metaModel.responseCode != 200 {
                let error = NSError(domain: "FYM.DailyMealPlan", code: 1001, userInfo: ["title": "error", "message": "alert_auto_suggest_list_message"])
                
                // fire completion handler
                completionHandler(foodLogList: [], error: error)
                
            }
            else {
                // fire completion handler
                completionHandler(foodLogList: foodLogs, error: nil)
            }
            
        }) { (operation, error) -> Void in
            // error
            let networkError = NSError(domain: "FYM.AutoSuggestFood", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
            
            // fire completion handler
            completionHandler(foodLogList: [], error: networkError)
        }
    }
}
