//
//  SplitFoodViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 11/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class SplitFoodCell: UITableViewCell {
    
    var user = User() {
        didSet {
            configureView()
        }
    }
    
    var value = 100 {
        didSet {
            labelValue.text = "\(value)%"
        }
    }
    
    @IBOutlet weak var labelUserName: UILabel!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelValue: UILabel!
    
    func configureView() {
        labelUserName?.text = user.userName
        labelName?.text = "\(user.firstName) \(user.lastName)"
    }
    
}

protocol SplitFoodFriendCellDelegate {
    func splitFoodFriendCell(splitFoodFriendCell: SplitFoodFriendCell, updatedValue value: Int)
}

class SplitFoodFriendCell: UITableViewCell {
    
    var user = User() {
        didSet {
            configureView()
        }
    }
    
    var splitFoodFriendCellDelegate: SplitFoodFriendCellDelegate?
    
    var value = 0 {
        didSet {
            labelValue.text = "\(value)%"
            slider.value = Float(value) / 100.0
            
            // notify delegate about the change 
            splitFoodFriendCellDelegate?.splitFoodFriendCell(self, updatedValue: value)
        }
    }
    
    @IBOutlet weak var labelUserName: UILabel!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelValue: UILabel!
    @IBOutlet weak var slider: UISlider!
    
    func configureView() {
        
        slider.setThumbImage(UIImage(named: "SliderThumb"), forState: UIControlState.Normal)
        slider.setThumbImage(UIImage(named: "SliderThumb"), forState: UIControlState.Highlighted)
        
        let minTrackImage = UIImage(named: "SliderSelected")!.stretchableImageWithLeftCapWidth(4, topCapHeight: 0)
        let maxTrackImage = UIImage(named: "SliderDeselected")!.stretchableImageWithLeftCapWidth(1, topCapHeight: 0)
        
        
        slider.setMinimumTrackImage(minTrackImage, forState: UIControlState.Normal)
        slider.setMaximumTrackImage(maxTrackImage, forState: UIControlState.Normal)
        
        slider.setMinimumTrackImage(minTrackImage, forState: UIControlState.Highlighted)
        slider.setMaximumTrackImage(maxTrackImage, forState: UIControlState.Highlighted)
        
        labelUserName.text = user.userName
        labelName.text = "\(user.firstName) \(user.lastName)"
    }
    
    @IBAction func sliderValueChanged(sender: UISlider) {
        
        // update value with percentage slider value
        value = Int(sender.value * 100)
    }
}

class SplitFoodViewController: UITableViewController, SplitFoodFriendCellDelegate, UIGestureRecognizerDelegate {
    
    var selectedUsers = [User]()
    
    var food = Food()
    
    var userCell = SplitFoodCell()
    var friendCells = [User: SplitFoodFriendCell]()
    
    var isFromDashboard = false
    
    var logDate = NSDate()
    
    var gestureDelegate: UIGestureRecognizerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
//        self.navigationController?.interactivePopGestureRecognizer.enabled = false
        
        // save the delegate
//        gestureDelegate = self.navigationController?.interactivePopGestureRecognizer.delegate
        self.navigationController?.interactivePopGestureRecognizer!.delegate = dashboard
        dashboard?.isGesturePopEnabled = false
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.navigationController?.interactivePopGestureRecognizer!.delegate = dashboard
        dashboard?.isGesturePopEnabled = true
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // return the number of sections.
        return 2
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return the number of rows in the section.
        return section == Storyboard.Sections.User ? 1 : selectedUsers.count
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return indexPath.section == Storyboard.Sections.User ? 70.0 : 100.0
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        // user cell
        if indexPath.section == Storyboard.Sections.User {
            let cell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifiers.SplitFoodCell, forIndexPath: indexPath) as! SplitFoodCell
            
            cell.user = User(userModel: AppConfiguration.sharedAppConfiguration.userDetails!)

            // save user cell
            userCell = cell
            
            return cell
        }
        
        // friends cells
        let cell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifiers.SplitFoodFriendCell, forIndexPath: indexPath) as! SplitFoodFriendCell
        cell.user = selectedUsers[indexPath.row]
        cell.splitFoodFriendCellDelegate = self
        
        // save friend cell
        friendCells[cell.user] = cell
        
        return cell
    }
    
    func splitFoodFriendCell(splitFoodFriendCell: SplitFoodFriendCell, updatedValue value: Int) {

        // find the cumulative friend values
        var totalFriendsValue = 0
        for (user, cell) in friendCells {
            totalFriendsValue += cell.value
        }
        
        // dont update if the value exceeds 100
        if totalFriendsValue > 100 {
            splitFoodFriendCell.value = value - 1
        }
        
        // update the user cell 
        let userValue = 100 - totalFriendsValue
        userCell.value = userValue < 0 ? 0 : userValue
    }
    
    struct Storyboard {
        struct Sections {
            static let User     = 0
            static let Friends  = 1
        }
        struct CellIdentifiers {
            static let SplitFoodCell        = "kSplitFoodCell"
            static let SplitFoodFriendCell  = "kSplitFoodFriendCell"
        }
        struct Segues {
            static let MealTypeSegue = "kMealTypeSegue"
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == Storyboard.Segues.MealTypeSegue {
            let mealTypeListViewController = segue.destinationViewController as! MealTypeListViewController
            mealTypeListViewController.food = food
            mealTypeListViewController.logDate = logDate
            
            var splittedUsers = [User: Int]()
            splittedUsers[userCell.user] = userCell.value
            for (user, cell) in friendCells {
                splittedUsers[user] = cell.value
            }
            
            mealTypeListViewController.splittedUsers = splittedUsers
            mealTypeListViewController.mealTypeListInitiator = .SplitFood
        }
    }
}
