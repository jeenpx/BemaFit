//
//  SideMenuViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 18/02/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class SideMenuViewController: UITableViewController, UIAlertViewDelegate {
    
    @IBOutlet weak var footerView: UIView!
    @IBOutlet weak var indicatorViewProfileIcon: UIActivityIndicatorView!
    @IBOutlet weak var imageViewUserImage: UIImageView!
    @IBOutlet weak var imageViewAds: UIImageView!
    @IBOutlet weak var labelUserName: UILabel!
    @IBOutlet weak var buttonAds: UIButton!
    @IBOutlet weak var indicatorAds: UIActivityIndicatorView!
    
    var adsUrlContent: String = ""
    
    // store device token
    var deviceToken = ""
    
    // mapping cellidentifier -> segue
    let segueMapper = [
        "kMyProfileCell": "kMyProfileSlideSegue",
        "kSettingsCell": "kSettingsSlideSegue"
    ]
    
    var enableDashboard = false {
        didSet {
            dashboard?.tableView.userInteractionEnabled = enableDashboard
            dashboard?.textInputbar.userInteractionEnabled = enableDashboard
            dashboardNavigationController?.toolbar.userInteractionEnabled = enableDashboard
        }
    }
    
    func closeSideMenu() {
        // close the side menu if its open
        if let slidingViewController = slidingViewController {
            if slidingViewController.currentTopViewPosition == .AnchoredRight {
                slidingViewController.resetTopViewAnimated(true) {
                    self.enableDashboard = true
                }
            }
        }
    }
    
    override func viewDidLoad() {
        
        let height = UIScreen.mainScreen().bounds.height ?? 667.0//CGRectGetWidth(superview!.bounds)
        
        footerView.frame = CGRectMake(footerView.frame.origin.x, footerView.frame.origin.y, footerView.frame.size.width, height - 285.0)
        
        indicatorAds.hidden = true

    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        // set the alpha value to zero
        self.imageViewAds.alpha = 0
        indicatorViewProfileIcon.hidden = false
        indicatorAds.hidden = true
        
        // disable dashboard
        enableDashboard = false
        
        labelUserName.text = AppConfiguration.sharedAppConfiguration.userDetails?.userUserName!
        if let profilePhoto = AppConfiguration.sharedAppConfiguration.userDetails?.userProfilePhoto {
            loadImage(profilePhoto as? String ?? "")
        }
        else {
            //print("NO PROFILE PIC")
        }
        
        // load advertisement
        Advertisement.latestAdvertisement("Sidebar") { (advertisement) -> () in
            
            if advertisement.shouldDisplayAdvertisement {
                
                //   self.imageViewAds.setImageWithURL(advertisement.imageURL)
                let request = NSURLRequest(URL: advertisement.imageURL!)
                
                // settings the image 
                self.imageViewAds.setImageWithURLRequest(request, placeholderImage: nil, success: { (request: NSURLRequest!, response: NSHTTPURLResponse!, image: UIImage!) -> Void in
                    
                    // set the image
                    self.imageViewAds.image = image
                    
                    // animation
                    self.animateAdvertisement()
                    
                    // hide the activity indicator
                    self.indicatorAds.hidden = true
                    
                    }, failure: { (request: NSURLRequest!, response: NSHTTPURLResponse!, error: NSError!) -> Void in
                        
                        // hide the activity indicator
                        self.indicatorAds.hidden = true
                        
                })
                
                // self.animateAdvertisement()
                
                self.buttonAds.setTitle(advertisement.content, forState: UIControlState.Normal)
                
                self.adsUrlContent = advertisement.content!
                self.buttonAds.addTarget(self, action: "buttonAdClicked:",forControlEvents: UIControlEvents.TouchUpInside)
            } else {
                self.indicatorAds.hidden = true
            }
        }
        
        slidingViewController?.anchorRightPeekAmount = 60
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        // enable dashboard
        enableDashboard = true
        
        dashboard?.displayNewAd()
        
        // post notification about enabling dashboard
        NSNotificationCenter.defaultCenter().postNotificationName(kEnableDashboardNotification, object: nil)
    }
    
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(animated)
        
        // enable dashboard
        enableDashboard = true
        
        // post notification about enabling dashboard
        NSNotificationCenter.defaultCenter().postNotificationName(kEnableDashboardNotification, object: nil)
    }
    
    func animateAdvertisement () {
        // slow animation fade in fade out to avoid flashing
        UIView.animateWithDuration(0.5, delay: 0.0, options: UIViewAnimationOptions.TransitionCrossDissolve, animations:{
            self.imageViewAds.alpha = 0.25
            }, completion: {(value: Bool) in
                UIView.animateWithDuration(1.0, animations: {
                    self.imageViewAds.alpha = 1.0
                })
        })
        
    }
    
    func loadImage(urlString:String) {
        let imgURL: NSURL = NSURL(string: urlString)!
        let request: NSURLRequest = NSURLRequest(URL: imgURL)
        
        // settings the image
        self.imageViewUserImage.setImageWithURLRequest(request, placeholderImage: nil, success: { (request: NSURLRequest!, response: NSHTTPURLResponse!, image: UIImage!) -> Void in
            
            // set the image
           self.imageViewUserImage.image = image
           self.indicatorViewProfileIcon.hidden = true
            
            }, failure: { (request: NSURLRequest!, response: NSHTTPURLResponse!, error: NSError!) -> Void in
                
                // hide the activity indicator
               self.indicatorViewProfileIcon.hidden = true
                
        })
        
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        // remove highlight
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        // get the selected cell
        let cell = tableView.cellForRowAtIndexPath(indexPath)
        
        // sign out
        if cell?.reuseIdentifier == "kSignOutCell" {
           
            let userDefaults = NSUserDefaults.standardUserDefaults()
            deviceToken = userDefaults.objectForKey("token") as? String ?? ""
            
            // logout api
            logout(deviceToken)
            
            return
        } else if cell?.reuseIdentifier == "kManageMacroCell" {
            
            // instantiate the main storyboard
            let manageStoryboard = UIStoryboard(name: "ManageGoalsStoryboard", bundle: NSBundle.mainBundle())
            
            // instantiate the initial view controller
            let initialViewController = manageStoryboard.instantiateViewControllerWithIdentifier("kManageGoalsList") as! ManageGoalsListViewController
            
            dashboard?.navigationController?.pushViewController(initialViewController, animated: true)
            closeSideMenu()
            return;
        }
        
        // perform segues from dashboard using the segue mapper
        dashboard?.performSegueWithIdentifier(segueMapper[cell!.reuseIdentifier!]!, sender: AppConfiguration.sharedAppConfiguration.userDetails!.userId!)
        
        // close the side menu
        closeSideMenu()
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if alertView.title == &&"sign_out" {
            
            if buttonIndex == 1 {
                
                appDelegate?.loadLogin()
            }
        }
    }
    
    func buttonAdClicked(sender:UIButton) {
        
        self.dashboard?.showAd(adsUrlContent);
        self.closeSideMenu()
    }
    
    @IBAction func unwindToMenuViewController(segue: UIStoryboardSegue) {
        // close the side menu if its open
        closeSideMenu()
    }
    
    func logout(deviceToken: String) {
        
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        LogoutResponse.logoutUser(deviceToken, completionHandler: { (metaModel) -> () in
            if let meta = metaModel {
                if meta.responseCode != 200 {
                    AlertManager.showAlert(&&"notice", message: &&"failed_logout")
                    return
                }
               self.appDelegate?.loadLogin()
            }
        })
    }
}
