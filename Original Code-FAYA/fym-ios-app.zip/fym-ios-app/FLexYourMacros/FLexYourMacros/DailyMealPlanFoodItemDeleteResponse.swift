//
//  DailyMealPlanFoodItemDeleteResponse.swift
//  FlexYourMacros
//
//  Created by Minimol BI on 15/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class DailyMealPlanFoodItemDeleteResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var dailyMealPlanId: String?
    
    // route instance variables
    var dailyMealPlanFoodId: String?
    
    // daily meal plan delete response mapping
    class var dailyMealPlanFoodItemDeleteResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(DailyMealPlanFoodItemDeleteResponse.metaModelKeyMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: dailyMealPlanFoodItemDeleteResponseMapping, method: .DELETE, pathPattern: Constants.ServiceConstants.kDailyMealPlanFoodItemDeleteUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    class func deleteDailyMealPlan(dailyMealPlanId: String,foodId: String, completionHandler: (responseStatus: String) -> ()) {
        // delete the message thread
        
        // set access token
        RestKitManager.setToken(true)
        
        let dailyMealPlanFoodItemDeleteResponse = DailyMealPlanFoodItemDeleteResponse()
        dailyMealPlanFoodItemDeleteResponse.dailyMealPlanId = dailyMealPlanId
        dailyMealPlanFoodItemDeleteResponse.dailyMealPlanFoodId = foodId

        
        RestKitManager.sharedManager().deleteObject(dailyMealPlanFoodItemDeleteResponse, path: nil, parameters: nil, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            
            //print("Success")
            let deleteResponseObject = mappingResult.firstObject as! DailyMealPlanFoodItemDeleteResponse
            
            if let responseMeta = deleteResponseObject.meta {
                
                // completion handler
                completionHandler(responseStatus: responseMeta.responseStatus!)
            }
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                //print("error \(error)");
                
        })
        
    }
}
