//
//  FoodDetailViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 27/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FoodDetailHeader: UITableViewHeaderFooterView {
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // set text
        textLabel!.text = &&"nutrition_facts"
        
        
        // set label text color
        textLabel!.textColor = UIColor.whiteColor()
        
        // set background color
        contentView.backgroundColor = UIColor(red: 44.0/255.0, green: 44.0/255.0, blue: 44.0/255.0, alpha: 1.0)//UIColor.blackColor()
    }
}

class FoodDetailViewController: UITableViewController, UITextFieldDelegate, UIAlertViewDelegate {
    @IBOutlet weak var cellSplitFood: UITableViewCell!
    
    enum FromController{
        
        
        case dailyMealPlan
        case viewLog
        
        
    }
    @IBOutlet private weak var textFieldServingSize: UITextField!
    @IBOutlet weak var cellSendFood: UITableViewCell!
    @IBOutlet private weak var textFieldNumberOfServings: UITextField!
    @IBOutlet private weak var textFieldCalories: UITextField!
    @IBOutlet private weak var textFieldFat: UITextField!
    @IBOutlet private weak var textFieldSaturated: UITextField!
    @IBOutlet private weak var textFieldPolyunsaturated: UITextField!
    @IBOutlet private weak var textFieldMonosaturated: UITextField!
    @IBOutlet private weak var textFieldTrans: UITextField!
    @IBOutlet private weak var textFieldCholesterol: UITextField!
    @IBOutlet private weak var textFieldSodium: UITextField!
    @IBOutlet private weak var textFieldPotassium: UITextField!
    @IBOutlet weak var labelBrandName: UILabel!
    
    @IBOutlet weak var textFieldCarbohydrate: UITextField!
    @IBOutlet weak var textFieldProtein: UITextField!
    @IBOutlet weak var textFieldFiber: UITextField!
    @IBOutlet weak var barButtonLog: UIBarButtonItem!
    
    
    typealias FoodUpdateCallBack = (food:Food,fromController : FromController) -> (Void)
    var food: Food = Food(name: "")
    
    // the mealtype if it has one already selected
    var mealType: MealType?
    
    var logDate =  NSDate()
    
    var isDailyMealPlan = false
    
    var dailyMealType = DailyMealType(dailyMealTypeName: "")
    
    // tells whether the food can be updated
    var canUpdate = false
    
    // tells whether the values entered are valid and can be processed
    var canProcess = true
    
    // tells whether to abort validity checks
    var canAbort = false
    
    var foodUpdateCallback : FoodUpdateCallBack?
    
    var isMealTypeSelected: Bool {
        return mealType != nil
    }
    var fromController : FromController?
    var isComingFromViewLog = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // configure view
        configureView()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        // cant abort checks when the view is visible
        canAbort = false
        
        // configure navigation button
        
        
        configureNavigationButton()
        reloadData()
        // reload data
        
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        
        
        
        
        
        super.viewWillDisappear(animated)
        
        
        
        // can abort checks now
        canAbort = true
        
        tableView.endEditing(true)
    }
    
    //    -(void) viewWillDisappear:(BOOL)animated {
    //    if ([self.navigationController.viewControllers indexOfObject:self]==NSNotFound) {
    //    // back button was pressed.  We know this is true because self is no longer
    //    // in the navigation stack.
    //    }
    //    [super viewWillDisappear:animated];
    //    }
    
    func configureNavigationButton() {
        
        
        
        if fromController == FromController.dailyMealPlan{
            barButtonLog.image = nil
            barButtonLog.title = &&"update"
            barButtonLog.enabled = self.canUpdate
            textFieldNumberOfServings.enabled = self.canUpdate
            self.navigationController?.navigationItem.rightBarButtonItem = nil
            self.cellSendFood.hidden = true
            self.cellSplitFood.hidden = true
            self.cellSplitFood.frame.size.height = 0.0
            self.cellSendFood.frame.size.height = 0.0
        }
        if isMealTypeSelected {
            barButtonLog.title = &&"log"
            barButtonLog.image = nil
        }
        else if canUpdate {
            barButtonLog.title = &&"update"
            barButtonLog.image = nil
        }
    }
    
    func configureView() {
        
        // set title
        title = food.name
        
        // register table header
        tableView.registerClass(FoodDetailHeader.self, forHeaderFooterViewReuseIdentifier: Storyboard.FoodDetailHeader)
    }
    
    func reloadData() {
        
        // populate textfields with new values
        textFieldServingSize.text = "\(food.servingSize.roundedString()) \(food.unit)"
        if fromController == FromController.dailyMealPlan{
            
            textFieldServingSize.text = "\(food.unit)"
        }
        
        
        textFieldNumberOfServings.text = "\(food.numberOfServings.roundedString())"
        textFieldCalories.text = "\((food.calories).roundedString())"
        textFieldFat.text = "\((food.fat).roundedString())"
        textFieldSaturated.text = "\((food.saturated).roundedString())"
        textFieldPolyunsaturated.text = "\((food.polyunsaturated).roundedString())"
        textFieldMonosaturated.text = "\((food.monosaturated).roundedString())"
        textFieldTrans.text = "\((food.trans).roundedString())"
        textFieldCholesterol.text = "\((food.cholesterol).roundedString())"
        textFieldSodium.text = "\((food.sodium).roundedString())"
        textFieldPotassium.text = "\((food.potassium).roundedString())"
        labelBrandName.text = food.brandName
        textFieldCarbohydrate.text = "\(food.carbohydrates.roundedString())"
        textFieldFiber.text = "\(food.fiber.roundedString())"
        textFieldProtein.text = "\(food.protein.roundedString())"
        
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == Storyboard.NutritionFactsSectionId ? 32 : 0
    }
    
    override func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return tableView.dequeueReusableHeaderFooterViewWithIdentifier(Storyboard.FoodDetailHeader) as! FoodDetailHeader
    }
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        // get the cell for indexpath using super method for static table view
        let cell = super.tableView(tableView, cellForRowAtIndexPath: indexPath)
        
        return cell.hidden == true ? 0 : cell.frame.size.height ?? 0
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        // get the selected cell
        let cell = tableView.cellForRowAtIndexPath(indexPath)
        
        if cell?.reuseIdentifier == Storyboard.CellIdentifiers.SplitFoodCell {
            //print("Split Food")
        }
        else if cell?.reuseIdentifier == Storyboard.CellIdentifiers.SendFoodDetailsCell {
            //print("Food Details")
        }
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        cell.setSeparatorInsetZero()
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        if string.isEmpty { return true }
        
        var isValid = true
        let text = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        
        // check for unwanted characters
        let replacementStringIsLegal = string.rangeOfCharacterFromSet(NSCharacterSet(charactersInString: "0123456789.").invertedSet) == nil
        
        // check for string count
        let resultingStringLengthIsLegal = text.characters.count <= 5
        
        
        // check if the number is valid
        let scanner = NSScanner(string: text)
        let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
        
        let isLowNumber = text.doubleValue < 100
        
        isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber
        
        return isValid
    }
    
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        
        // no checks if aborting
        if canAbort { return true }
        
        let shouldEndEditing = textField.text!.doubleValue > 0
        if shouldEndEditing {
            
            // update lock
            canProcess = true
            
            if textField == textFieldNumberOfServings {
                // update number of servings
                food.updateNumberOfServings((textField.text! as NSString).doubleValue)
            } else if textField == textFieldServingSize {
                // update number of servings
                food.servingSize = (textField.text! as NSString).doubleValue
            }
            
            // reload values
            reloadData()
        }
        else {
            
            // update lock
            canProcess = false
            
            // show alert
            UIAlertView(title: &&"error", message: &&"serving_size_validation_alert_message", delegate: nil, cancelButtonTitle: &&"cancel").show()
        }
        
        return shouldEndEditing
    }
    
    struct Storyboard {
        struct Segues {
            static let SplitFood = "kSplitFoodSegue"
            static let SendFoodDetail = "kSendFoodDetailSegue"
            static let MealTypeListSegue = "kMealTypeListSegue"
            static let UnwindViewLogSegue = "kUnwindViewLogSegue"
        }
        
        struct CellIdentifiers {
            static let SplitFoodCell = "kSplitFoodCell"
            static let SendFoodDetailsCell = "kSendFoodDetailsCell"
        }
        static let NutritionFactsSectionId = 1
        static let FoodDetailHeader = "kFoodDetailHeader"
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == Storyboard.Segues.SplitFood {
            let sendDetailsViewController = segue.destinationViewController as! SendDetailsViewController
            sendDetailsViewController.sendDetailsViewMode = .SplitFood
            sendDetailsViewController.food = food
            sendDetailsViewController.logDate = logDate
            sendDetailsViewController.isFromDashboard = !isComingFromViewLog
        }
        else if segue.identifier == Storyboard.Segues.SendFoodDetail {
            let sendDetailsViewController = segue.destinationViewController as! SendDetailsViewController
            sendDetailsViewController.sendDetailsViewMode = .FoodDetail
            sendDetailsViewController.food = food
            sendDetailsViewController.logDate = logDate
            sendDetailsViewController.isFromDashboard = !isComingFromViewLog
        }
        else if segue.identifier == Storyboard.Segues.MealTypeListSegue {
            let mealTypeListViewController = segue.destinationViewController as! MealTypeListViewController
            
            mealTypeListViewController.logDate = logDate
            mealTypeListViewController.food = sender as! Food
        }
    }
    
    @IBAction func babButtonActionLog(sender: UIBarButtonItem) {
        
        tableView.endEditing(true)
        
        if fromController == FromController.dailyMealPlan{
            
            food.updateNumberOfServings((textFieldNumberOfServings.text! as NSString).doubleValue)
            
            self.foodUpdateCallback?(food: self.food,fromController: self.fromController!)
            self.navigationController?.popViewControllerAnimated(true)
            
            return
        }
        
        
        if isDailyMealPlan {
            
            food.dailyMealType = dailyMealType
            food.mealType = mealType!
            food.addedDate = NSDate()
            NSNotificationCenter.defaultCenter().postNotificationName("RefreshMealPlanIdentifier", object: nil, userInfo: ["newFood": food, "method": "Read"])
            
            //resign to the daily meal plan viewcontroller
            if let viewControllers = navigationController?.viewControllers {
                for viewController in viewControllers {
                    // some process
                    if viewController.isKindOfClass(DailyMealPlanDetailViewController) {
                        self.navigationController?.popToViewController(viewController, animated: true)
                    }
                } 
            }
            return
        }
        
        if !canProcess { return }
        
        // update if possible
        
        
        if canUpdate {
            
            food.servingSize = (textFieldServingSize.text! as NSString).doubleValue
            food.numberOfServings = (textFieldNumberOfServings.text! as NSString).doubleValue
            food.updateFoodLog { (error) -> () in
                // show alert controller if possible else show alert view
                
                if #available(iOS 8.0, *) {
                    let alert = UIAlertController(title: &&"alert_title_update", message: &&"alert_message_update", preferredStyle: .Alert)
                    
                    alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
                    
                    self.presentViewController(alert, animated: true, completion: nil)
                } else {
                    // Fallback on earlier versions
                    UIAlertView(title: &&"alert_title_update", message: &&"alert_message_update", delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok").show()
                }
                
            }
        }
            // log if the meal type is selected
        else if isMealTypeSelected {
            // log food
            food.logFood(mealType!.id, mealDate: logDate ?? NSDate(), userGuid: AppConfiguration.sharedAppConfiguration.userDetails!.userId!) { (error) -> () in
                //print("logged food")
                
                // load view log
                self.loadViewLog()
            }
        }
            // show meal type list screen
        else {
            performSegueWithIdentifier(Storyboard.Segues.MealTypeListSegue, sender: food)
        }
    }
    
    
    class func openFromViewController(fromViewcontroller:UINavigationController?, withFood food : Food, fromController: FromController,openForEdit : Bool, foodUpdateCallBack : FoodUpdateCallBack) -> () {
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let foodDetailViewController = storyBoard.instantiateViewControllerWithIdentifier("FoodDetailViewControllerID") as! FoodDetailViewController
        
        foodDetailViewController.food = food
        foodDetailViewController.fromController = fromController
        foodDetailViewController.foodUpdateCallback = foodUpdateCallBack
        foodDetailViewController.canUpdate = openForEdit
        fromViewcontroller!.pushViewController(foodDetailViewController, animated: true)
        
        
    }
    func barButtonBack() {
        
        
    }
    
}
