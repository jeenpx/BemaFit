//
//  SettingsModel.swift
//  FlexYourMacros
//
//  Created by DBG on 29/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit
@objc(SettingsModel)

class SettingsModel: NSObject{
   
    var settingsId: String?
    var settingSlug: String?
    var title: String?
    var type: String?
    var status: String?
    

    class var objectMapping: RKObjectMapping {
        let settingsMapping = RKObjectMapping(forClass: SettingsModel.self)
        settingsMapping.addAttributeMappingsFromDictionary(mappingDictionary)
        return settingsMapping
        
    }
    
    class var mappingDictionary: [String : String] {
        return(["setting_id":"settingsId", "setting_slug":"settingSlug", "title":"title", "type":"type", "status":"status"])
    }
  
}
