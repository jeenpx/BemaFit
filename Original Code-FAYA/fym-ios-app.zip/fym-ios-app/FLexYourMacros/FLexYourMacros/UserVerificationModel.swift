//
//  UserFacebookModel.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 13/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class UserVerificationModel: NSObject {
    
    var emailVerified: AnyObject?
    var userValid: AnyObject?
    var verificationDaysRemaining: NSNumber?
    var userExists: AnyObject?
    var userNameExists: AnyObject?
    var facebookIdExists: AnyObject?
    var emailExists: AnyObject?
    
    var isVerified: Bool {
        return userValid as? Bool ?? false
    }
    
    class var objectMapping: RKObjectMapping {
        let dietMapping = RKObjectMapping(forClass: self)
        dietMapping.addAttributeMappingsFromDictionary(mappingDictionary)
        return dietMapping
    }
    
    class var mappingDictionary: [String : String] {
        return(["user_exists": "userExists", "email_verified":"emailVerified", "user_valid":"userValid", "verification_days_remaining":"verificationDaysRemaining", "username_exists":"userNameExists", "facebook_exists": "facebookIdExists", "email_exists": "emailExists"])
    }
  
}