//
//  UserForgotPasswordViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 11/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UserForgotPasswordViewController: UITableViewController, UIAlertViewDelegate {
    
    @IBOutlet weak var textFieldEmailId: UITextField!
    var currentTextField = UITextField()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // hides navigation bar
        navigationController?.navigationBarHidden = false
        let titleDictionary: NSDictionary = [NSForegroundColorAttributeName: UIColor.whiteColor()]
        self.navigationController?.navigationBar.titleTextAttributes = titleDictionary as? [String : AnyObject]
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    @IBAction func unwindToUserForgotPasswordViewController(segue: UIStoryboardSegue) {
        
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        
        currentTextField = textField
    }
    
    func textFieldShouldReturn(textField: UITextField!) -> Bool {
        // resign keyboard
        textField.resignFirstResponder()
        return false
    }
    
    func showAlert(title: String, message: String, tag: Int) {
        // configure alert
        let alert = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"OK")
        alert.tag = tag
        alert.show()
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        if(alertView.tag == 1) {
           self.navigationController?.popViewControllerAnimated(true)
        }
    }
    
        
        @IBAction func buttonActionSubmit(sender: UIButton) {
            
            currentTextField.resignFirstResponder()
            // validates the email id
            if !textFieldEmailId.isValidEmailAddress {
                self.showAlert(&&"notice", message: &&"enter_valid_email_alert_message", tag: 0)
                return
            }
            
            let reachability = appDelegate!.internetReachable
            
            if !reachability {
                
                self.showAlert(&&"alert_network_title", message: &&"alert_network_message", tag: 10)
                return
            }
            
            // calls the api if valid email id
            ForgotPasswordResponse.requestForPassword(textFieldEmailId.text!) { (response) -> () in
                if response == "Success" {
                    self.showAlert(&&"notice", message: &&"reset_password", tag: 1)
                }else {
                    self.showAlert(&&"notice", message: response, tag: 0)
                }
                
            }
        }
        
        
}
