
//
//  FoodListViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 13/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FoodType {
    var id = ""
    var name = ""
    
    init(name: String = "") {
        self.name = name
    }
    
    init(foodCategory: FoodCategory) {
        self.id = foodCategory.id ?? ""
        self.name = foodCategory.name ?? ""
    }
}

// delegate to enlarge the imageview
protocol EnlargeImageDelegate {
    func enlargeImageView(selectedCell: FoodListCell, food: Food)
}

class FoodListCell: UITableViewCell {
    
    @IBOutlet weak var imageViewFood: UIImageView!
    @IBOutlet weak var labelFoodName: UILabel!
    @IBOutlet weak var labelFoodDetails: UILabel!
    
    @IBOutlet weak var layoutConstraintImageWidth: NSLayoutConstraint!
    
    var enlargeImageDelegate: EnlargeImageDelegate?
    
    var food = Food(name: "") {
        didSet {
            configureView()
        }
    }
    
    private(set) var isShowingImage: Bool = false
    var vendorVerified = ""
    
    func configureView() {
        
        // food verification
        vendorVerified = food.vendorVerified
        labelFoodName?.text = food.name
        labelFoodDetails?.text = "\(food.servingSize.roundedString()) " + food.unit + ", " + "\(food.calories.roundedString()) " + &&"calories"
        
        if !food.image.isEmpty {
            isShowingImage = true
            imageViewFood?.setImageWithURL(NSURL(string: food.image), placeholderImage: UIImage(named: "Placeholder"))
            layoutConstraintImageWidth?.constant = 74
            
            let tapGesture = UITapGestureRecognizer(target: self, action: "didTapImageViewFoodWithGesture:")
            tapGesture.delegate = self
            
            // add tap gesture to the food imageview
            imageViewFood.addGestureRecognizer(tapGesture)
            imageViewFood.userInteractionEnabled = true
        }
        else {
            layoutConstraintImageWidth?.constant = 0
        }
        
        labelFoodName.sizeToFit()
        labelFoodName.layoutIfNeeded()
    }
    
    override func prepareForReuse() {
        labelFoodName.text = ""
        labelFoodDetails.text = ""
        imageViewFood.image = nil
        isShowingImage = false
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layoutConstraintImageWidth?.constant = isShowingImage ? 74 : 0
    }
    
    func didTapImageViewFoodWithGesture(tapGesture: UITapGestureRecognizer) {
        enlargeImageDelegate?.enlargeImageView(self, food: food)
    }
}

enum FoodListMode {
    case SearchFood
    case LogByServingSize
    case LogByMacro
    case FoodRecommendation
}

class FoodListHeader: UITableViewHeaderFooterView {
    
    var header = "" {
        didSet {
            textLabel!.text = header
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        textLabel!.font = UIFont.helveticaBold()
        textLabel!.textColor = UIColor.whiteColor()
        
        contentView.backgroundColor = UIColor.blackColor()
    }
    
}

class FoodListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, AKPickerViewDataSource, AKPickerViewDelegate, EmptyBackgroundViewDelegate, BarcodeScannerDelegate, UITableViewDragLoadDelegate, UIAlertViewDelegate, EnlargeImageDelegate {
    
    // meal type for the view
    var mealType: MealType?
    
    var logDate = NSDate()
    
    var isDailyMealPlan = false
    
    var dailyMealType = DailyMealType(dailyMealTypeName: "")

    
    // meal type for food recommendation
    var foodRecommendationMealType: MealType?
    
    // the selected food type
    var selectedFoodType = FoodType()
    var arrayFoodTypes = [FoodType]() {
        didSet {
            if foodListMode != FoodListMode.LogByServingSize {
                selectedFoodType = arrayFoodTypes[0]
            }
        }
    }
    
    var arrayFood = [Food]() {
        didSet {
            
            // hide empty background if we have data
            emptyBackgroundView.hidden = arrayFood.count > 0
            
            // reload tableview
            self.tableView?.reloadData()
        }
    }
    
    var foodListMode = FoodListMode.SearchFood {
        didSet {
            configureViewForMode()
        }
    }
    
    var foodListSearchType: String {
        var searchType = "meal_search"
        
        if foodListMode == .LogByServingSize { searchType = "serving_size" }
        else if foodListMode == .FoodRecommendation { searchType = "food_recommendation" }
        
        return searchType
    }
    
    struct Storyboard {
        struct Segues {
            static let FoodListSegue = "kFoodListSegue"
            static let FoodBarcodeSegue = "kSegueFoodBarcode"
            static let SegueFoodConvert = "kSegueFoodConvert"
            static let LogServingSizeSegue = "kLogServingSizeSegue"
            static let CreateMealSegue = "kCreateMeal"
            static let FoodDetailsSegue = "kFoodDetailsSegue"
        }
        struct CellIdentifiers {
            static let FoodListCell = "kFoodListCell"
        }
    }
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var horizontalPicker: AKPickerView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var macroStatsView: MacroStatsView!
    
    @IBOutlet weak var constraintPickerViewHeight: NSLayoutConstraint!
    @IBOutlet weak var constraintBarcodeViewHeight: NSLayoutConstraint!
    @IBOutlet weak var constraintMacroStatsViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var emptyBackgroundView: EmptyBackgroundView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureView()
        
        MasterDataResponse.updateFoodCategories {
            self.arrayFoodTypes = self.fetchFoodTypes()
            self.horizontalPicker.reloadData()
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        // show navigation bar if hidden
        if (navigationController?.navigationBarHidden != nil) {
            navigationController?.navigationBarHidden = false
        }
        
        // refresh foods
        Food.fetchFoods(searchBar.text!, foodType: selectedFoodType.id, mealType: foodRecommendationMealType?.id ?? -1, searchType: isDailyMealPlan ? "daily_meal_plan" : foodListSearchType) { (foods) in
            self.arrayFood = foods
        }
        
        // refresh macro stats view
        refreshMacroStatsView()
        
    }
    
    func configureView() {
        
        // empty under table
        tableView.tableFooterView = UIView(frame: CGRectZero)
        
        tableView.estimatedRowHeight = 75.0
        
        // configure view for mode
        configureViewForMode()
        
        // set delegate for pull to refresh and load more
        tableView.setDragDelegate(self, refreshDatePermanentKey: "nil")
        
        // hide pull to refresh
        tableView.showRefreshView = false
        
        // show load more
        tableView.showLoadMoreView = true
        
        // tableview footer release text
        tableView.footerReleaseText = &&"release_to_load_more_status"
        
        // tableview footer pull up text
        tableView.footerPullUpText = &&"pull_down_to_load_more_status"
        
        //tableview footer loading text
        tableView.footerLoadingText = &&"loading_status"
        
        // fetch food types
        arrayFoodTypes = fetchFoodTypes()
        
        // set mode for empty background view
        emptyBackgroundView.emptyBackgroundViewMode = .Food
        
        // set delegate for empty background view
        emptyBackgroundView.emptyBackgroundViewDelegate = self
        
        // reload picker
        configureHorizontalPicker()
        
        Food.fetchFoods(searchBar.text!, foodType: selectedFoodType.id, mealType: foodRecommendationMealType?.id ?? -1, searchType: isDailyMealPlan ? "daily_meal_plan" : foodListSearchType) { (foods) in
            self.arrayFood = foods
        }
        
        // refresh macro stats view
        refreshMacroStatsView()
    }
    
    func configureHorizontalPicker() {
        horizontalPicker.delegate = self
        horizontalPicker.dataSource = self
        
        horizontalPicker.font = UIFont.helveticaBold()
        horizontalPicker.highlightedFont = UIFont.helveticaBold()
        horizontalPicker.interitemSpacing = 30.0
        horizontalPicker.viewDepth = 1000.0
        horizontalPicker.pickerViewStyle = .Flat
        horizontalPicker.maskDisabled = true
        horizontalPicker.reloadData()
    }
    
    func configureViewForMode() {
        
        // set view title
        if foodListMode == .FoodRecommendation {
            if let mealTypeName = foodRecommendationMealType?.name {
                title = mealTypeName
            }
            else {
                title = &&"food_recommendations"
            }
        }
        else if foodListMode == .LogByServingSize {
            title = &&"serving_size"
        }
        
        // we only need macro stats view for food recommendations
        if foodListMode != FoodListMode.FoodRecommendation {
            constraintMacroStatsViewHeight?.constant = 0
        }
        else {
            // we dont need barcode view for food recommendations
            constraintBarcodeViewHeight?.constant = 0
        }
        
        // hide the picker when logging by serving size
        if foodListMode == .LogByServingSize {
            horizontalPicker?.removeFromSuperview()
            constraintPickerViewHeight?.constant = 0
        }
    }
    
    func refreshMacroStatsView() {
        
        // refresh macro stats view
        MacroModel.refreshUserMacros { (macroDetails) in
            self.macroStatsView.macroDetails = macroDetails
        }
    }
    
    func fetchFoodTypes() -> [FoodType] {
        let foodTypes = AppConfiguration.sharedAppConfiguration.mealCategories?.map { FoodType(foodCategory: $0) } ?? []
        return [FoodType(name: &&"all")] + foodTypes
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayFood.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return arrayFood[indexPath.row].expectedHeight
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return foodListMode == .FoodRecommendation ? 32.0 : 0.0
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = FoodListHeader()
        header.header = title ?? ""
        return header
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifiers.FoodListCell, forIndexPath: indexPath) as! FoodListCell
        cell.enlargeImageDelegate = self
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        // remove highlight
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        if foodListMode == FoodListMode.LogByServingSize {
            performSegueWithIdentifier(Storyboard.Segues.LogServingSizeSegue, sender: arrayFood[indexPath.row])
        }
        else if (foodListMode == FoodListMode.SearchFood) || (foodListMode == FoodListMode.FoodRecommendation) {
            performSegueWithIdentifier(Storyboard.Segues.FoodDetailsSegue, sender: arrayFood[indexPath.row])
        }
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        (cell as! FoodListCell).food = arrayFood[indexPath.row]
        cell.setSeparatorInsetZero()
    }
    
    // load more funcationality
    func dragTableDidTriggerLoadMore(tableView: UITableView!) {
        
        // fetch foods and reload table
        Food.fetchFoods(searchBar.text!, foodType: selectedFoodType.id, mealType: foodRecommendationMealType?.id ?? -1, searchType: isDailyMealPlan ? "daily_meal_plan" : foodListSearchType, offset: arrayFood.count, shouldShowHUD: false) { (foods) -> () in
            self.arrayFood += foods
            self.tableView.finishLoadMore()
        }
    }
    
    func dragTableLoadMoreCanceled(tableView: UITableView!) {
        // called when the load more is cancelled
        NSObject.cancelPreviousPerformRequestsWithTarget(self, selector: Selector("finishLoadMore"), object: nil)
    }
    
    func numberOfItemsInPickerView(pickerView: AKPickerView) -> Int {
        return arrayFoodTypes.count
    }
    
    func pickerView(pickerView: AKPickerView, titleForItem item: Int) -> String {
        return arrayFoodTypes[item].name
    }
    
    func pickerView(pickerView: AKPickerView, didSelectItem item: Int) {
        
        // fetch new foods based on the selected type
        selectedFoodType = arrayFoodTypes[item]
        Food.fetchFoods(searchBar.text!, foodType: selectedFoodType.id, mealType: foodRecommendationMealType?.id ?? -1, searchType: isDailyMealPlan ? "daily_meal_plan" : foodListSearchType) { (foods) in
            self.arrayFood = foods
        }
    }
    
    func pickerView(pickerView: AKPickerView, configureLabel label: UILabel, forItem item: Int) {
        label.textColor = UIColor.darkGrayColor()
        label.highlightedTextColor = UIColor.defaultThemeBlueColor()
    }
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(true, animated: true)
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(false, animated: true)
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        
        // clear the search text
        searchBar.text = ""
        
        // update foods
        Food.fetchFoods(searchBar.text!, foodType: selectedFoodType.id, mealType: foodRecommendationMealType?.id ?? -1, searchType: isDailyMealPlan ? "daily_meal_plan" : foodListSearchType) { (foods) in
            
            self.arrayFood = foods
        }
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        
        // do search
        Food.fetchFoods(searchBar.text!, foodType: selectedFoodType.id, mealType: foodRecommendationMealType?.id ?? -1, searchType: isDailyMealPlan ? "daily_meal_plan" : foodListSearchType) { (foods) in
            self.arrayFood = foods
        }
    }
    
    func buttonActionCreateNew(emptyBackgroundViewMode: EmptyBackgroundView) {
        self.performSegueWithIdentifier(Storyboard.Segues.CreateMealSegue, sender: self)
    }
    
    @IBAction func buttonActionScanBarcode(sender: UIButton) {
        performSegueWithIdentifier(Storyboard.Segues.FoodBarcodeSegue, sender: self)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == Storyboard.Segues.FoodBarcodeSegue {
            let barcodeViewController = segue.destinationViewController as! BarcodeViewController
            barcodeViewController.barcodeScannerDelegate = self
        }
        else if segue.identifier == Storyboard.Segues.CreateMealSegue {
            let createMealViewController = segue.destinationViewController as! CreateMealViewController
            createMealViewController.isDailyMealPlan = isDailyMealPlan
            createMealViewController.dailyMealType = dailyMealType
            createMealViewController.mealType = mealType
        }
        else if segue.identifier == Storyboard.Segues.LogServingSizeSegue {
            let logServingSizeViewController = segue.destinationViewController as! LogServingSizeViewController
            logServingSizeViewController.dailyMealType = dailyMealType
            logServingSizeViewController.mealType = mealType
            logServingSizeViewController.food = sender as! Food
            logServingSizeViewController.isDailyMealPlan = isDailyMealPlan
            logServingSizeViewController.logDate = logDate
        }
        else if segue.identifier == Storyboard.Segues.FoodDetailsSegue {
            let foodDetailsViewController = segue.destinationViewController as! FoodDetailViewController
            foodDetailsViewController.dailyMealType = dailyMealType
            foodDetailsViewController.mealType = mealType
            foodDetailsViewController.food = sender as! Food
            foodDetailsViewController.isDailyMealPlan = isDailyMealPlan
            foodDetailsViewController.logDate = logDate
        }
    }
    
    func barcodeScanner(barcodeScanner: BarcodeViewController, didScanBarcode barcode: Barcode) {
        // fetch food based on barcode if we have a valid barcode
        if let barcodeData = barcode.barcodeData {
            Food.fetchBarcodeFood(barcodeData) { (food, error) -> () in
                
                if error != nil {
                    if let showError = error {
                        self.showAlert(&&"notice", message: showError)
                    }
                    return
                }
                
                self.performSegueWithIdentifier(Storyboard.Segues.FoodDetailsSegue, sender: food)
            }
        }
    }
    
    func showAlert(title: String, message: String) {
        
        UIAlertView(title:title, message: message, delegate: self, cancelButtonTitle: &&"cancel", otherButtonTitles: &&"ok").show()
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        if alertView.buttonTitleAtIndex(buttonIndex) == &&"ok" {
            
            // navigate to create custom meal
            let createMealViewController = storyboard?.instantiateViewControllerWithIdentifier("kCreateMealViewController") as? CreateMealViewController
            navigationController?.pushViewController(createMealViewController!, animated: true)
        }
    }
    
    
    func enlargeImageView(selectedCell: FoodListCell, food: Food) {
        // enlarge the imageview
        
        if selectedCell.vendorVerified == "Yes" {
            let imageInfo = JTSImageInfo()
            // imageInfo.image = imageViewFood.image
            
            imageInfo.imageURL = NSURL(string: food.imageLarge)
            imageInfo.referenceRect = selectedCell.imageViewFood.frame
            imageInfo.referenceView = selectedCell.imageViewFood.superview
            let imageViewController = JTSImageViewController(imageInfo: imageInfo, mode: .Image, backgroundStyle: .Scaled)
            
            // present the view controller.
            imageViewController.showFromViewController(self, transition: .FromOriginalPosition)
        }
        
    }
}

