//
//  FriendsRequestResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 07/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FriendsRequestResponse: NSObject {
    var metaModel: MetaModel?
    var friendRequest:FriendRequestModel?
    var friend_id: String?

    class var friendsRequestResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(FriendsRequestResponse.metaModelKeyMapping)
        
        // give reference to message item model
        responseMapping.addPropertyMapping(FriendsRequestResponse.friendRequestModelMapping)
        
        return responseMapping
    }

    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }    
    
    private class var friendRequestModelMapping :RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathSendFriendRequest, toKeyPath: "friendRequest", withMapping: FriendRequestModel.objectMapping)
    }
    
    
    class var userResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: friendsRequestResponseMapping, method: .PUT, pathPattern: Constants.ServiceConstants.sendFriendRequestUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
  
    class func sendFriendRequest(friendId:String,status:String,completionHandler: (friendRequestresponse:FriendsRequestResponse) -> () ) {
        
        RestKitManager.setToken(true)
        
        let friendRequestresponse = FriendsRequestResponse()
        
        friendRequestresponse.friend_id = friendId
        
        var params = ["response_status": status] as Dictionary<String, String>
        
         var err: NSError?
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(friendRequestresponse, method: .PUT, path: nil, parameters: nil, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
        
        do {
            request.HTTPBody =  try NSJSONSerialization.dataWithJSONObject(params, options: [])
        } catch var error as NSError {
            err = error
            request.HTTPBody = nil
        }
        
    
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let response = mappingResult.firstObject as! FriendsRequestResponse
            //print("respone code :\(response.metaModel?.responseCode)")
            //print("respone status :\(response.metaModel?.responseStatus)")
            
            // check for success
         /*   if response.metaModel?.responseCode != 200 {
              return
           }
            
           */ 
            completionHandler(friendRequestresponse: response)
               //print("Success ")
            
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                //print("failed to load change password with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    
    
    }
    
  }
