//
//  DailyRequirement.swift
//  FlexYourMacros
//
//  Created by mini on 14/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import CoreData
@objc(DailyRequirement)

class DailyRequirement: NSManagedObject {

    @NSManaged var protein_total: String
    @NSManaged var fat_total: String
    @NSManaged var carbs_total: String
    @NSManaged var fiber_total: String
    @NSManaged var calories_total: String
    @NSManaged var progressDailyType: Progress

    class var entityMapping : RKEntityMapping {
        
        var progressLogMapping: RKEntityMapping = RKEntityMapping(forEntityForName: Constants.Tables.dailyRequirement, inManagedObjectStore: RestKitManager.sharedManager().managedObjectStore)
        progressLogMapping .addAttributeMappingsFromDictionary(progressMappingDictionary)
        
        return progressLogMapping
    }
    
    private class var progressMappingDictionary: [String : String] {
        
        return(["protein_total":"protein_total", "fat_total":"fat_total", "carbs_total":"carbs_total", "fiber_total":"fiber_total", "calories_total":"calories_total"])
    }
    
    class func fetchDailyMacroRequirements(progressType: String, completionHandler:(dailyRequirement: [AnyObject])->()) {
        
        var error: NSError?
        let fetchRequest = NSFetchRequest()
        let entity = NSEntityDescription.entityForName(Constants.Tables.dailyRequirement, inManagedObjectContext: RKObjectManager.sharedManager().managedObjectStore.persistentStoreManagedObjectContext)
        fetchRequest.returnsObjectsAsFaults = false
        fetchRequest.entity = entity
//        fetchRequest.fetchLimit = 1
        
        // set the predicate
        let progressPredicate = NSPredicate(format: "SUBQUERY(progressDailyType, $x, $x.type = %@).@count == progressDailyType.@count",progressType)
        fetchRequest.predicate = progressPredicate
        
        let fetchedObjects: [AnyObject]?
        do {
            fetchedObjects = try RKObjectManager.sharedManager().managedObjectStore.persistentStoreManagedObjectContext .executeFetchRequest(fetchRequest)
        } catch var error1 as NSError {
            error = error1
            fetchedObjects = nil
        }
        completionHandler(dailyRequirement: fetchedObjects!)
    }

}
