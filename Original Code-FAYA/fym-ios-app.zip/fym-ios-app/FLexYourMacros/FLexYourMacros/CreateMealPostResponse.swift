//
//  CreateMealPostResponse.swift
//  FlexYourMacros
//
//  Created by Attila Roy on 23/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class CreateMealPostResponse: NSObject {
    
    // model instance variables
    var meta = MetaModel()
    var food = FoodListModel()
    
    
    // message response mapping
    class var createMealResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(CreateMealPostResponse.metaModelKeyMapping)
        
        // give reference to food list model
        responseMapping.addPropertyMapping(CreateMealPostResponse.foodListKeyMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
    }
    
    private class var foodListKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMealFoodList, toKeyPath: "food", withMapping: FoodListModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: createMealResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.kUrlPostCreateMeal, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    class func createFood(params: [String: AnyObject], completionHandler: (food: Food, meta: MetaModel) -> ()) {
        
        RestKitManager.setToken(true)
        
        // create a post request
        let request = RestKitManager.sharedManager().requestWithObject(nil, method: .POST, path: Constants.ServiceConstants.kUrlPostCreateMeal, parameters: nil)
        
        // set params as body
        request.HTTPBody = try? NSJSONSerialization.dataWithJSONObject(params, options: NSJSONWritingOptions())
        
        // create an operation with the request
        let operation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation, mappingResult) in
            
            let createMealPostResponse = mappingResult.firstObject as! CreateMealPostResponse
            
            // check for success
            if createMealPostResponse.meta.responseCode != 200 {
                //print("XXX failed to create a food \(params)")
            }
            
            // fire completion handler
            //completionHandler(food: Food(foodListModel: createMealPostResponse.food))
            completionHandler(food: Food(foodListModel: createMealPostResponse.food), meta: createMealPostResponse.meta)
            
            }, failure: { (operation, error) in
                //print("XXX failed to log food with error \(error)")
        })
        
        // enque request operation
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
    
}
