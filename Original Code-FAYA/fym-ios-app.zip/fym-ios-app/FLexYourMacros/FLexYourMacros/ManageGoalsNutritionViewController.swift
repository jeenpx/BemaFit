//
//  ManageGoalsNutritionViewControllerTableViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 6/4/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class GoalsSelectNutritionCell: UITableViewCell {
    
    @IBOutlet weak var labelNutritionTitle: UILabel!
    @IBOutlet weak var labelNutritionDescription: UILabel!
    @IBOutlet weak var imageViewBlueIcon: UIImageView!
    
    var nutritionPlan: NutritionPlanModel? {
        didSet {
            labelNutritionTitle.text = nutritionPlan?.nutritionName
            labelNutritionDescription.text = nutritionPlan?.nutritionDescription
        }
    }
    
    var isNutritionSelected = false {
        didSet {
            accessoryType = isNutritionSelected ? .Checkmark : .None
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
}


class ManageGoalsNutritionViewController: UITableViewController {
    
    var nutritionPlans: [NutritionPlanModel]? {
        didSet {
            selectedNutritionPlan = nutritionPlans?.filter { $0.nutritionId == FymUser.sharedFymUser.userNutritionType }.first
        }
    }
    
    var selectedNutritionPlan: NutritionPlanModel? {
        didSet {
            FymUser.sharedFymUser.userNutritionType  = selectedNutritionPlan!.nutritionId!
            //print(FymUser.sharedFymUser.userNutritionType)
            tableView.reloadData()

        }
    }
    
    @IBOutlet var tableViewManageGoalsNutrition: UITableView!
    
    struct Storyboard {
        struct CellIdentifiers {
            static let GoalsSelectNutritionHeader = "kGoalsSelectNutritionHeader"
            static let GoalsSelectNutrition = "kGoalsSelectNutritionCell"
        }
        struct Segue {
        static let GoalsMacroUpdate = "kGoalsMacroUpdate"
        }
    }
    
    var offscreenCells = [String: GoalsSelectNutritionCell]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // save nutrition plans
        
        tableView.tableFooterView = UIView(frame: CGRectZero)
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        nutritionPlans = AppConfiguration.sharedAppConfiguration.nutritionPlans
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(true)
        
       
    }
    
    func configureTableView() {
        
        // hide empty tableview cells
        tableViewManageGoalsNutrition.tableFooterView = UIView(frame: CGRectZero)
        tableViewManageGoalsNutrition.rowHeight = UITableViewAutomaticDimension
        tableViewManageGoalsNutrition.estimatedRowHeight = 73
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let plan = AppConfiguration.sharedAppConfiguration.nutritionPlans // {
        
        return plan.count
//        }
//        return 0
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifiers.GoalsSelectNutrition) as! GoalsSelectNutritionCell
        cell.nutritionPlan = nutritionPlans?[indexPath.row]
        cell.isNutritionSelected = nutritionPlans?[indexPath.row] == selectedNutritionPlan
        
        cell.setNeedsUpdateConstraints()
        cell.updateConstraintsIfNeeded()
        
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
        selectedNutritionPlan = nutritionPlans?[indexPath.row]
        tableView.reloadData()
    }
    
    override func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let selectNutritionHeader: UITableViewCell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifiers.GoalsSelectNutritionHeader)!
        return selectNutritionHeader as UIView
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        var cell = offscreenCells[Storyboard.CellIdentifiers.GoalsSelectNutrition]
        if cell == nil {
            cell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifiers.GoalsSelectNutrition) as? GoalsSelectNutritionCell
            offscreenCells[Storyboard.CellIdentifiers.GoalsSelectNutrition] = cell
        }
        
        cell?.nutritionPlan = nutritionPlans?[indexPath.row]
        
        cell?.setNeedsUpdateConstraints()
        cell?.updateConstraintsIfNeeded()
        cell?.bounds = CGRectMake(0.0, 0.0, CGRectGetWidth(tableViewManageGoalsNutrition.bounds), CGRectGetHeight(cell!.bounds))
        
        cell?.setNeedsLayout()
        cell?.layoutIfNeeded()
        
        cell?.labelNutritionDescription.preferredMaxLayoutWidth = CGRectGetWidth(cell!.labelNutritionDescription.bounds)
        cell?.labelNutritionDescription.setNeedsUpdateConstraints()
        
        // Get the actual height required for the cell's contentView
        var height = cell?.contentView.systemLayoutSizeFittingSize(UILayoutFittingCompressedSize).height
        
        // Add an extra point to the height to account for the cell separator, which is added between the bottom
        // of the cell's contentView and the bottom of the table view cell.
        height = height! + 1
        return height!
    }
    
    @IBAction func buttonActionRight(sender: AnyObject) {
       performSegueWithIdentifier(Storyboard.Segue.GoalsMacroUpdate, sender: self)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == Storyboard.Segue.GoalsMacroUpdate {

            let manageGoalsCompletionController = segue.destinationViewController as! ManageGoalsCompletionController
        }
    }
    
    @IBAction func unwindToManageGoalsNutritionViewController(segue: UIStoryboardSegue) {
        
    }
    
}
