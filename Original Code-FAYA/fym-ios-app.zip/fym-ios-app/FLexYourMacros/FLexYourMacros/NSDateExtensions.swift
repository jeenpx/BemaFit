//
//  NSDate+Extensions.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/6/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let kMinute = 60
private let kDay = kMinute * 24

extension NSDate {
    
    func stringFromFormat(format: String, withValue value: Int) -> String {
        // get the string value from format
        
        // XXX - how to avoid getLocaleFormatUnderscoresWithValue
        let localeFormat = String(format: format, getLocaleFormatUnderscoresWithValue(Double(value)))
        return String(format: NSLocalizedString(localeFormat, comment: ""), value)
    }
    
    func getLocaleFormatUnderscoresWithValue(value: Double) -> String {
        // get the locale format
        
        // country code
        let localeCode = NSLocale.preferredLanguages().first! 
        
        if localeCode == "ru" {
            let XY = Int(floor(value)) % 100
            let Y = Int(floor(value)) % 10
            
            if Y == 0 || Y > 4 || (XY > 10 && XY < 15) {
                return ""
            }
            
            if Y > 1 && Y < 5 && (XY < 10 || XY > 20) {
                return "_"
            }
            
            if Y == 1 && XY != 11 {
                return "__"
            }
        }
    
        return ""
    }
        
    // dateFormat has precedence over dateStyle
    // date style defaults to LongStyle
    func stringValue(dateFormat: String? = nil, dateStyle: NSDateFormatterStyle? = nil, showToday: Bool = false) -> String {
        
        // return today text if its today
        if showToday {
            if self.isToday() {
                return &&"today"
            }
        }
        
        // get a date formatter
        let dateFormatter = NSDateFormatter()
        
        // set appropriate date styles/formats
        if let dateFormat = dateFormat {
            dateFormatter.dateFormat = dateFormat
        }
        else if let dateStyle = dateStyle {
            dateFormatter.dateStyle = dateStyle
        }
        else {
            dateFormatter.dateStyle = NSDateFormatterStyle.LongStyle
        }
        
        dateFormatter.locale = NSLocale.currentLocale()
        
        // return the string after formatting
        return dateFormatter.stringFromDate(self)
    }
    
    func isToday() -> Bool {
        
        // get a calendar
        let calendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)
        
        // get today calendar components (emit time or normalize to midnight)
        let requiredTodayCalendarComponents: NSCalendarUnit = [NSCalendarUnit.NSYearCalendarUnit, NSCalendarUnit.NSMonthCalendarUnit, NSCalendarUnit.NSDayCalendarUnit]
        let todayCalendarComponents = calendar?.components(requiredTodayCalendarComponents, fromDate: NSDate())
        let currentCalendarComponents = calendar?.components(requiredTodayCalendarComponents, fromDate: self)
        
        return todayCalendarComponents == currentCalendarComponents
    }
    
    func nextDay() -> NSDate {
        
        // get a calendar
        let calendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)
        
        // get the date components for next day
        let dateComponents = NSDateComponents()
        dateComponents.day = 1
        
        // return next day
        return calendar!.dateByAddingComponents(dateComponents, toDate: self, options: [])!
    }
    
    func previousDay() -> NSDate {
        
        // get a calendar
        let calendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)
        
        // get the date components for next day
        let dateComponents = NSDateComponents()
        dateComponents.day = -1
        
        // return next day
        return calendar!.dateByAddingComponents(dateComponents, toDate: self, options: [])!
    }
    
    func numberOfDaysInMonth() -> Int {
        // get the number of days in a month
        let calendar = NSCalendar.currentCalendar()
        let days = calendar.rangeOfUnit(.NSDayCalendarUnit, inUnit: .NSMonthCalendarUnit, forDate: self)
        return days.length

    }
    
    func numberOfDaysInFirstWeek() -> Int {
        let calendar = NSCalendar.currentCalendar()
        // calculate day of the first date
        let component = calendar.components(NSCalendarUnit.NSWeekdayCalendarUnit, fromDate: firstDateOftheMonth())
        let weekDay = component.weekday
        return 7 - weekDay
    }
    
    func firstDateOftheMonth() -> NSDate {
        // calculate the first date of the month
        let calendar = NSCalendar.currentCalendar()
        let firstDateComponents = calendar.components([.NSYearCalendarUnit, .NSMonthCalendarUnit, .NSDayCalendarUnit], fromDate: self)
        firstDateComponents.day = 1
        firstDateComponents.hour = 0
        firstDateComponents.minute = 0
        firstDateComponents.second = 0
        return calendar.dateFromComponents(firstDateComponents)!
    }
    
    func dateComponents() -> NSDateComponents {
       // get the date componenets for the date
        let calendar = NSCalendar.currentCalendar()
        let components = calendar.components([.Month, .Day, .Year, .WeekOfMonth, .Weekday], fromDate: self)
        return components
    }
    
    func numberOfWeeks() -> Int {
        
        // calculate the number of weeks
        let calendar = NSCalendar.currentCalendar()
        let weekRange = calendar.rangeOfUnit(NSCalendarUnit.NSWeekCalendarUnit, inUnit: NSCalendarUnit.NSMonthCalendarUnit, forDate: self)
        let weeksCount=weekRange.length
        return weeksCount
    }
    
    func startOfMonth() -> NSDate? {
        
        let calendar = NSCalendar.currentCalendar()
        let currentDateComponents = calendar.components([.Year, .Month], fromDate: self)
        let startOfMonth = calendar.dateFromComponents(currentDateComponents)
        
        return startOfMonth
    }
    
    func dateByAddingMonths(monthsToAdd: Int) -> NSDate? {
        
        let calendar = NSCalendar.currentCalendar()
        let months = NSDateComponents()
        months.month = monthsToAdd
        
        return calendar.dateByAddingComponents(months, toDate: self, options: [])
    }
    
    func endOfMonth() -> NSDate? {
        
        let calendar = NSCalendar.currentCalendar()
        if let plusOneMonthDate = dateByAddingMonths(1) {
            let plusOneMonthDateComponents = calendar.components([.Year, .Month], fromDate: plusOneMonthDate)
            
            let endOfMonth = calendar.dateFromComponents(plusOneMonthDateComponents)?.dateByAddingTimeInterval(-1)
            
            return endOfMonth
        }
        
        return nil
    }
    
    func weekArrayForMonthOfDate() -> [[String : NSDate]] {
        
        // get the week array for the month: every week start & end date
        var weekArray =  [[String:NSDate]]()
        var lastDate: NSDate?
        for var i = 0; i < numberOfWeeks(); i++ {
            
            let dayComponent = NSDateComponents()
            let calendar = NSCalendar.currentCalendar()
            var itemDictionary = [String:NSDate]()
            
            // for the first index of the number of weeks find out how many days are there and make the start&end date based on that
            if i == 0 {
                dayComponent.day = numberOfDaysInFirstWeek()
                let endDate = calendar.dateByAddingComponents(dayComponent, toDate: firstDateOftheMonth(), options: NSCalendarOptions())
                var startDate = firstDateOftheMonth()
                if numberOfDaysInFirstWeek() != 7 {
                   
                    dayComponent.day = -1*(6-numberOfDaysInFirstWeek())
                    startDate = calendar.dateByAddingComponents(dayComponent, toDate: firstDateOftheMonth(), options: NSCalendarOptions())!
                }
                itemDictionary = ["startDate" : startDate, "endDate" : endDate!]
                weekArray.append(itemDictionary)
                lastDate = endDate
                
            } else {
                
                //for all other indices except the last index
                if i < numberOfWeeks() - 1  {
                    dayComponent.day = 1;
                    let startDate = calendar.dateByAddingComponents(dayComponent, toDate: lastDate!, options: NSCalendarOptions())
                    dayComponent.day = 6;
                    let endDate = calendar.dateByAddingComponents(dayComponent, toDate: startDate!, options: NSCalendarOptions())
                    itemDictionary = ["startDate" : startDate!, "endDate" : endDate!]
                    weekArray.append(itemDictionary)
                    lastDate = endDate
                    
                } else {
                    
                    //for the last index of the number of weeks
                    dayComponent.day = 1;
                    let startDate = calendar.dateByAddingComponents(dayComponent, toDate: lastDate!, options: NSCalendarOptions())
                    dayComponent.day = (numberOfDaysInMonth() - numberOfDaysInFirstWeek()) % 7 == 0 ? 6 : (numberOfDaysInMonth() - numberOfDaysInFirstWeek()) % 7 + (6-((numberOfDaysInMonth() - numberOfDaysInFirstWeek()) % 7))
//                    dayComponent.month = (numberOfDaysInMonth() - numberOfDaysInFirstWeek()) % 7 == 0 ? 0 :1

                    let endDate = calendar.dateByAddingComponents(dayComponent, toDate: startDate!, options: NSCalendarOptions())
                    itemDictionary = ["startDate" : startDate!, "endDate" : endDate!]
                    weekArray.append(itemDictionary)
                    lastDate = endDate
                }
            }
        }
        
        return weekArray
    }
    
    // returns true if date is within the start and end date or equal to the start or end date
    func isInRange(startDate: NSDate, endDate: NSDate) -> Bool {
        return (self.compare(startDate) == .OrderedDescending && self.compare(endDate) == .OrderedAscending) || self.compare(startDate) == .OrderedSame || self.compare(endDate) == .OrderedSame
    }
}

