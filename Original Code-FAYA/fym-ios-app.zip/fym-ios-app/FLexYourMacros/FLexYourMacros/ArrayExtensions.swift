//
//  ArrayExtensions.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 24/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

extension Array {
    mutating func remove <T: Equatable> (object: T) -> Bool {
        for (index, objectToCompare) in self.enumerate() {
            if let objectToCompare = objectToCompare as? T {
                if object == objectToCompare {
                    self.removeAtIndex(index)
                    return true
                }
            }
        }
        return false
    }
    
    mutating func contains <T: Equatable> (object: T) -> Bool {
        for (index, objectToCompare) in self.enumerate() {
            if let objectToCompare = objectToCompare as? T {
                if object == objectToCompare {
                    return true
                }
            }
        }
        return false
    }
}

extension NSMutableArray {
    
    func addUtilityButtonWithBackgroundColor(backGroundColor: UIColor, andTitleColor titleColor: UIColor, andTitle title: String) {
        // add  an utility button with background and title color
        
        let button = UIButton(type: .Custom)
        button.backgroundColor = backGroundColor
        button.setTitle(title, forState: .Normal)
        button.setTitleColor(titleColor, forState: .Normal)
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        addObject(button)
    }
    
    
    func addUtilityButtonWithCustomImage(normalImage: UIImage, andHiglightedImage higlightedImage: UIImage, andSelectedImage selectedImage: UIImage, andBackGroundColor backGroundColor: UIColor = UIColor.defaultGrayColor(), andTitleColor titleColor: UIColor = UIColor.whiteColor(), andTitle title: String = "") {
        // add  an utility button with background and title color
        
        let button = UIButton(type: .Custom)
        button.backgroundColor = backGroundColor
        button.setImage(normalImage, forState: UIControlState.Normal)
        button.setImage(higlightedImage, forState: UIControlState.Highlighted)
        button.setImage(selectedImage, forState: UIControlState.Selected)
        button.setTitle(title, forState: .Normal)
        button.setTitleColor(titleColor, forState: .Normal)
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        addObject(button)
    }
}
