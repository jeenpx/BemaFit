//
//  FlexYourMacros-Bridging-Header.h
//  FlexYourMacros
//
//  Created by Thahir Maheen on 18/02/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

#ifndef FlexYourMacros_FlexYourMacros_Bridging_Header_h
#define FlexYourMacros_FlexYourMacros_Bridging_Header_h


#import <SystemConfiguration/SystemConfiguration.h>

#import "CorePlot-CocoaTouch.h"
#import "CPTAxis+SwiftCompat.h"
#import "CPTXYAxis+SwiftCompat.h"
#import "CPTScatterPlot+SwiftCompat.h"
#import "CPTMutablePlotRange+SwiftCompat.h"
#import "CPTPlotRange+SwiftCompat.h"
#import "CPTBarPlot+SwiftCompat.h"
#import "CPTAxisLabel+SwiftCompat.h"

#import "FacebookManager.h"
#import "UITableView+DragLoad.h"

#import "KLCPopup.h"
#import "SLKTextViewController.h"
#import "SWTableViewCell.h"
#import "MGSwipeTableCell.h"
#import "MGSwipeButton.h"
#import "UITableView+DragLoad.h"
#import "DragAndDropTableView.h"
#import <RestKit/CoreData.h>

#import <RestKit/RestKit.h>
#import "CollapsableTableViewDelegate.h"
#import "CollapsableTableViewFooterViewController.h"
#import "CollapsableTableView.h"
#import "CollapsableTableViewHeaderViewController.h"
#import "TapDelegate.h"
#import "CollapsableTableViewTapRecognizer.h"
#import "UIBarButtonItem+Badge.h"
#import "KLCPopup.h"
#import "UIView+Toast.h"

#import "TPKeyboardAvoidingTableView.h"
#import "UIScrollView+TPKeyboardAvoidingAdditions.h"
#import "TPKeyboardAvoidingScrollView.h"
#import "RKLog.h"
#import "RKObjectManager+Logging.h"
#import "AFOAuth2Client.h"
#import <AFNetworking/AFNetworking.h>
#import "Hexcolors.h"
#import "Reachability.h"

// sdwebimageview
#import "SDWebImageManager.h"
#import "UIButton+WebCache.h"

//progressview
#import <MBProgressHUD/MBProgressHUD.h>
#import "SVProgressHUD.h"

// time ago
#import "NSDate+TimeAgo.h"

#import "GeolocationServiceUpdater.h"
#import "TestFairy.h"
#import <ECSlidingViewController/ECSlidingViewController.h>
#import <FBSDKShareKit/FBSDKShareKit.h>
#import "JTSImageViewController.h"

// pdf generation
#import<NDHTMLtoPDF.h>
#import "UIAlertView+Blocks.h"

#endif
