//
//  MessageSendResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/6/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class MessageSendResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    var message: MessageItemModel?
    
   // route instance variables
    var user_id: String?
    var friend_id: String?
    
    // message response mapping
    class var messageSendResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(MessageSendResponse.metaModelKeyMapping)
        
        // give reference to message item model
        responseMapping.addPropertyMapping(MessageSendResponse.messageSendKeyMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
    }
    
    private class var messageSendKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMessage, toKeyPath: "message", withMapping: MessageItemModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: messageSendResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.kUrlPostMessage, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    
    class func postMessage(message: String, andFriendId friendId: String, completionHandler: (sendMessage: MessageItemModel, meta: MetaModel) -> ()) {
        
        SVProgressHUD.show()
        
        // set access token
        RestKitManager.setToken(true)
        
        // input parameter
        let param: Dictionary = ["message": message]
        
        // instance of message model class
        let messageSendResponse = MessageSendResponse()
        
        // set user id
        messageSendResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId
        
        // set friend id
        messageSendResponse.friend_id = friendId
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(messageSendResponse, method: .POST, path: nil, parameters: param, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let messageSendResponse = mappingResult.firstObject as! MessageSendResponse
            //print("respone code :\(messageSendResponse.meta?.responseCode)")
            //print("respone status :\(messageSendResponse.meta?.responseStatus)")
            
            SVProgressHUD.dismiss()
            
            completionHandler(sendMessage: messageSendResponse.message ?? MessageItemModel(), meta: messageSendResponse.meta ?? MetaModel())
            
//                if let postMessage: MessageItemModel = messageSendResponse.message {
//                    completionHandler(sendMessage: postMessage)
//                }
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                SVProgressHUD.dismiss()
                
                //print("failed to load postMessage with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
    
    
    
}

