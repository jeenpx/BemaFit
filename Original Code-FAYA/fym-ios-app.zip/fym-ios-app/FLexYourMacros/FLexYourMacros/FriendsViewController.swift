//
//  FriendsViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 18/02/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

// Friend request cell
protocol FriendRequestCellDelegate {
    func friendRequestCell(friendRequestCell: FriendsRequestCell, didIgnoreFriend friend: FriendModel ,status :String)
    func friendRequestCellUserProfile(userId: String)
    
}
class FriendsRequestCell: SWTableViewCell, SWTableViewCellDelegate {
    @IBOutlet weak var labelUsername: UILabel!
    @IBOutlet weak var labelFullname: UILabel!
    @IBOutlet weak var imageViewUser: UIImageView!
    @IBOutlet weak var buttonAccept: UIButton!
    
    var friendDetails : FriendModel! {
        didSet{
            labelUsername.text = friendDetails.userName
            labelFullname.text = "\(friendDetails.firstName!) \(friendDetails.lastName!)"
            let imageURL = NSURL(string: friendDetails.profilePhoto!)!
            imageViewUser.setImageWithURL(imageURL, placeholderImage:  UIImage(named:"FacebookIcon")!)
            
        }
    }
    
    var friendRequestCellDelegate: FriendRequestCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        configureCell()
    }
    
    func configureCell() {
        // Add right utility buttons
        rightUtilityButtons = configureRightUtilityButtons() as [AnyObject]
        delegate = self
        labelUsername.userInteractionEnabled = true
        imageViewUser.userInteractionEnabled = true
        let tapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
        tapGesture.delegate = self
        
        
        let userImageTapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
        userImageTapGesture.delegate = self
        imageViewUser.addGestureRecognizer(userImageTapGesture)
        
        // add tap gesture to the username label
        labelUsername.addGestureRecognizer(tapGesture)
        
    }
    
    func didTaplabelUserNameWithGesture(tapGesture: UITapGestureRecognizer) {
        //////print("didTaplabelUserNameWithGesture entered...")
        friendRequestCellDelegate?.friendRequestCellUserProfile(friendDetails!.user_id!)
    }
    
    @IBAction func buttonActionAccept(sender: AnyObject) {
        //API call
        friendRequestCellDelegate?.friendRequestCell(self, didIgnoreFriend: friendDetails,status: "Accepted")
        
    }
    func configureRightUtilityButtons() -> NSArray {
        let rightUtilityButtons = NSMutableArray()
        rightUtilityButtons.addUtilityButtonWithBackgroundColor(UIColor(red: 224.0/255.0, green: 224.0/255.0, blue: 224.0/255.0, alpha: 1.0),
            andTitleColor: UIColor.redColor(), andTitle: "Ignore")
        return rightUtilityButtons
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func swipeableTableViewCell(cell: SWTableViewCell!, didTriggerRightUtilityButtonWithIndex index: Int) {
        friendRequestCellDelegate?.friendRequestCell(self, didIgnoreFriend: friendDetails, status: "Rejected")
        
    }
}



// FriendCell

protocol FriendListCellDelegate {
    func friendListCell(friendListCell: FriendListCell, didUnfollowFriend friend: FriendModel)
    func friendListCellUserProfile(userId: String)
}


class FriendListCell: SWTableViewCell, SWTableViewCellDelegate {
    
    @IBOutlet weak var lableUsername: UILabel!
    @IBOutlet weak var userImageview: UIImageView!
    @IBOutlet weak var labelUserFullName: UILabel!
    @IBOutlet weak var labelFollowing: UILabel!
    @IBOutlet weak var labelFollowers: UILabel!
    
    var friend: FriendModel! {
        didSet{
            lableUsername.text = friend.userName
            labelUserFullName.text = "\(friend.firstName!) \(friend.lastName!)"
            labelFollowers.text = "\(friend.followers!) " + &&"followers"
            labelFollowing.text = "\(friend.following!) " + &&"following"
            let imageURL = NSURL(string: friend.profilePhoto!)!
            userImageview.setImageWithURL(imageURL, placeholderImage: UIImage(named: "PlaceHolderProfilePic")!)
        }
    }
    
    var friendListCellDelegate: FriendListCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        configureCell()
    }
    
    func configureCell() {
        
        // add right utility buttons
        rightUtilityButtons = configureRightUtilityButtons() as [AnyObject]
        
        // set delegate
        delegate = self
        lableUsername.userInteractionEnabled = true
        let tapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
        tapGesture.delegate = self
        
        userImageview.userInteractionEnabled = true
        let userImageviewTapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
        userImageviewTapGesture.delegate = self
        
        userImageview.addGestureRecognizer(userImageviewTapGesture)
        lableUsername.addGestureRecognizer(tapGesture)
        
    }
    
    func configureRightUtilityButtons() -> NSArray {
        let rightUtilityButtons = NSMutableArray()
        rightUtilityButtons.addUtilityButtonWithBackgroundColor(UIColor(red: 224.0/255.0, green: 224.0/255.0, blue: 224.0/255.0, alpha: 1.0),
            andTitleColor: UIColor.redColor(), andTitle: "Unfriend")
        return rightUtilityButtons
    }
    
    func didTaplabelUserNameWithGesture(tapGesture: UITapGestureRecognizer) {
        ////print("didTap")
        friendListCellDelegate?.friendListCellUserProfile(friend!.user_id!)
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func swipeableTableViewCell(cell: SWTableViewCell!, didTriggerRightUtilityButtonWithIndex index: Int) {
        friendListCellDelegate?.friendListCell(self, didUnfollowFriend: friend)
    }
    
}

// FriendsViewController

class FriendsViewController: UIViewController, FriendListCellDelegate, FriendRequestCellDelegate,SWTableViewCellDelegate, UISearchBarDelegate, UITableViewDragLoadDelegate, UIAlertViewDelegate {
    @IBOutlet weak var tableViewFriends: UITableView!
    
    var alert1: UIAlertView?
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    var loadMore : Bool = false
    
    // variable for pull to refresh
    var refreshControl: UIRefreshControl!
    
    
    // FriendsRequest Array
    var friendRequestArray : [FriendModel] = []
    
    // FriendsList Array
    var friendListArray : [FriendModel] = []
    
    // Friendsmodel Array including both request and accepted friends .
    var friendModelArray : [FriendModel] = []
    
    // offset
    var offsetValue:Int!
    
    // search keyword
    var searchText : String = ""
    
    // temp array holding all friends list
    var tempFriendModelArray : [FriendModel] = []
    
    // total friends count
    var friendCount = " "
    
    // empty message status
    var showEmptyTableViewMessage = false
    
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // refresh tableview
        configureRefreshControl()
        
        // configure friends tableview
        configureTableViewFriends()
        
        // setting the offset count
        // offsetValue = friendModelArray.count
        
        // request for the friends list
        // getFriendsList(offsetValue, limit: 10, searchKeyword: searchText,doLoadMore: false)
        
    }
    
    override func viewWillAppear(animated: Bool) {
        getUserList(true)
    }
    
    func configureRefreshControl() {
        refreshControl = UIRefreshControl()
        
        // add the target
        refreshControl.addTarget(self, action: "pullToRefresh:", forControlEvents: UIControlEvents.ValueChanged)
        refreshControl.tintColor = UIColor.grayColor()
        
        // add refresh control to the tableview
        tableViewFriends.addSubview(refreshControl)
    }
    
    func pullToRefresh(sender: AnyObject) {
        
        getUserList(false)
        
    }
    func getUserList(shouldShowHUD: Bool) {
        // reset all the values
        
        // FriendsRequest Array
        friendRequestArray = []
        
        // FriendsList Array
        friendListArray  = []
        
        // Friendsmodel Array including both request and accepted friends .
        friendModelArray = []
        
        // offset
        offsetValue = 0
        
        // search keyword
        searchText  = ""
        
        // temp array holding all friends list
        tempFriendModelArray  = []
        
        // total friends count
        friendCount = " "
        
        searchBar.text?.removeAll()
        
        tableViewFriends.reloadData()
        
        getFriendsList(offsetValue, limit: 10, searchKeyword: searchText,doLoadMore: false,shouldShowHUD: shouldShowHUD)
        
        
    }
    
    func configureTableViewFriends() {
        
        // set delegate for pull to refresh and load more
        tableViewFriends.setDragDelegate(self, refreshDatePermanentKey: "kFriend")
        
        // hide pull to refresh
        tableViewFriends.showRefreshView = false
        
        // show load more
        tableViewFriends.showLoadMoreView = true
        
        // tableview footer release text
        tableViewFriends.footerReleaseText = NSLocalizedString("release_to_load_more_status", comment: "")
        
        // tableview footer pull up text
        tableViewFriends.footerPullUpText = NSLocalizedString("pull_down_to_load_more_status", comment: "")
        
        //tableview footer loading text
        tableViewFriends.footerLoadingText = NSLocalizedString("loading_status", comment: "")
        
        // register the header view cell
        tableViewFriends.registerClass(HeaderView.self, forHeaderFooterViewReuseIdentifier: "kHeaderFriendsCell")
        
        // register the header view cell
        tableViewFriends.registerClass(HeaderView.self, forHeaderFooterViewReuseIdentifier: "kFriendRequestSectionCell")
        
        
    }
    
    
    // MARK: - Table View
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        //  return searchText.isEmpty ? 2 : 1
        tableViewFriends.showEmptyTableViewMessage("")
        
        // set show emty table view message false
        // showEmptyTableViewMessage = false
        
        
        if friendModelArray.count == 0 && friendRequestArray.count == 0 && friendListArray.count == 0 && showEmptyTableViewMessage {
            // show empty tableview message if friendslist empty
            tableViewFriends.showEmptyTableViewMessage(&&"empty_tableview_message")
            
            // set show emty table view message false
            showEmptyTableViewMessage = false
            return 0
            
        } else if searchText.isEmpty {
            tableViewFriends.backgroundView = UIView()
            tableViewFriends.separatorStyle = .SingleLine
            
            return 2
        } else {
            tableViewFriends.backgroundView = UIView()
            tableViewFriends.separatorStyle = .SingleLine
            return 1
        }
        
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchText.isEmpty {
            
            if section == 1 {
                return friendListArray.count
            }else  {
                return friendRequestArray.count
            }
            
        } else {
            return friendModelArray.count
        }
    }
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        ////print("here")
        if(searchText.isEmpty) {
            if(section==1) {
                let  headerCell = tableView.dequeueReusableHeaderFooterViewWithIdentifier("kHeaderFriendsCell") as! HeaderView
                headerCell.title = &&"Friends"
                headerCell.friendsCount = self.friendCount
                return headerCell
                
            } else {
                let  headerCell = tableView.dequeueReusableHeaderFooterViewWithIdentifier("kFriendRequestSectionCell") as! HeaderView
                headerCell.title = &&"friendRequest"
                
                return headerCell
            }
        } else {
            ////print("search text available")
            let  headerCell = tableView.dequeueReusableHeaderFooterViewWithIdentifier("kHeaderFriendsCell") as! HeaderView
            return headerCell
            
        }
        
        
        
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        if searchText.isEmpty && friendRequestArray.count<=0 && section == 0{
            return 0
        }
        return searchText.isEmpty ? 32 : 0
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if searchText.isEmpty {
            
            if indexPath.section == 1 {
                let cell = tableView.dequeueReusableCellWithIdentifier("kFriendCell", forIndexPath: indexPath) as! FriendListCell
                cell.tag=1
                cell.friendListCellDelegate = self
                cell.friend = friendListArray[indexPath.row]
                return cell
            }
            else {
                let cell = tableView.dequeueReusableCellWithIdentifier("kFriendRequestCell", forIndexPath: indexPath) as! FriendsRequestCell
                cell.tag=2
                cell.friendRequestCellDelegate = self
                cell.friendDetails = friendRequestArray[indexPath.row]
                return cell
            }
            
        } else {
            
            if friendModelArray[indexPath.row].type == "FriendRequest" {
                
                let cell = tableView.dequeueReusableCellWithIdentifier("kFriendRequestCell", forIndexPath: indexPath) as! FriendsRequestCell
                cell.tag=1
                cell.friendRequestCellDelegate = self
                cell.friendDetails = friendModelArray[indexPath.row]
                return cell
                
                
            } else {
                
                let cell = tableView.dequeueReusableCellWithIdentifier("kFriendCell", forIndexPath: indexPath) as! FriendListCell
                cell.tag=1
                cell.friendListCellDelegate = self
                cell.friend = friendModelArray[indexPath.row]
                return cell
                
            }
            
        }
    }
    
    //  FriendListCellDelegate method
    func friendListCell(friendListCell: FriendListCell, didUnfollowFriend friend: FriendModel) {
        // delete the friendship
        deleteFriendship(friend,cell: friendListCell)
    }
    
    
    // FriendRequestCellDelegate
    func friendRequestCell(friendRequestCell: FriendsRequestCell, didIgnoreFriend friend: FriendModel, status:String) {
        
        // send the response for Accepting /Rejecting the request
        respondToFriendRequest(friend, status: status, friendRequestCell: friendRequestCell)
    }
    
    
    func friendRequestCellUserProfile(userId: String) {
        performSegueWithIdentifier("kFriendsProfileSegue",sender: userId)
    }
    
    
    func friendListCellUserProfile(userId: String) {
        performSegueWithIdentifier("kFriendsProfileSegue",sender: userId)
        
    }
    
    func swipeableTableViewCellShouldHideUtilityButtonsOnSwipe(cell: SWTableViewCell!) -> Bool {
        // prevent multiple cells from showing utilty buttons simultaneously
        return true
    }
    
    // load more funcationality
    
    func dragTableDidTriggerLoadMore(tableView: UITableView!) {
        // called when the load more is selected
        //  NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("finishLoadMore"), userInfo: nil, repeats: false)
        offsetValue = self.friendModelArray.count
        getFriendsList(offsetValue!, limit: 10, searchKeyword: searchText,doLoadMore: true)
        
    }
    
    func dragTableLoadMoreCanceled(tableView: UITableView!) {
        // called when the load more is cancelled
        NSObject.cancelPreviousPerformRequestsWithTarget(self, selector: Selector("finishLoadMore"), object: nil)
    }
    
    func finishLoadMore() {
        // to stop the load more and populate the tableview with new items
        //   getFriendsList(friendModelArray.count, limit: 5, searchKeyword: "",)
        tableViewFriends.finishLoadMore()
        tableViewFriends.reloadData()
        
    }
    
    func getFriendsList(offset:Int,limit:Int,searchKeyword:String,doLoadMore:Bool,shouldShowHUD: Bool = true){
        
        //  internet check
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        GetFriendsResponse.getFriendsList(offset, andLimit: limit, keywords:searchKeyword, shouldShowHUD: shouldShowHUD, completionHandler: { (getFriendsResponse:GetFriendsResponse) -> () in
            let response = getFriendsResponse
            
            // save friends count
            self.friendCount = response.totalFriends!
            
            if response.friends!.count == 0 {
                
                // set show emty table view message false
                self.showEmptyTableViewMessage = true
                
            } else {
                
                // set show emty table view message false
                self.showEmptyTableViewMessage = false
            }
            
            if let set  = response.friends as [FriendModel]? {
                // adding all the  friend Array
                for obj in set {
                    self.friendModelArray.append(obj)
                }
                // check if search text is empty , then split the array
                if self.searchText.isEmpty {
                    self.splitArray(set)
                }
                
            }
            
            if doLoadMore {
                // finish the load more
                self.tableViewFriends.finishLoadMore()
                
            }
            
            if self.refreshControl != nil {
                
                // stop pull to refresh
                self.refreshControl?.endRefreshing()
            }
            
            self.tableViewFriends.reloadData()
            
        })
        
        
    }
    
    
    // SEARCH BAR
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        ////print("searchBarTextDidBeginEditing")
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        //print("searchBarTextDidEndEditing")
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchBar.text?.removeAll()
        searchBar.setShowsCancelButton(false, animated: true)
        searchBar.resignFirstResponder()
        //  tableView.reloadData()
        //print("searchBarCancelButtonClicked")
        // load the previous data
        searchBarTextEmpty()
        
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        
        // save the search text
        let s = searchBar.text
        
        // searchBar.text.removeAll(keepCapacity: true)
        searchBar.setShowsCancelButton(false, animated: true)
        //print("searchBarSearchButtonClicked")
        searchBar.resignFirstResponder()
        
        // store friends to tempoary friends array
        // check whether the tempoary array contains value then values already exit
        if tempFriendModelArray.count == 0 {
            tempFriendModelArray = friendModelArray
        }
        // set offset 0
        offsetValue = 0
        
        // friends array set to empty
        friendModelArray = []
        friendRequestArray = []
        friendListArray = []
        
        // get the list of friends with search keyword
        getFriendsList(offsetValue, limit: 10, searchKeyword: s!, doLoadMore: false)
        
    }
    // show the cancel button in the searchbar
    func searchBarShouldBeginEditing(searchBar: UISearchBar) -> Bool {
        searchBar.setShowsCancelButton(true, animated: true)
        return true
    }
    
    
    func searchBarShouldEndEditing(searchBar: UISearchBar) -> Bool {
        //  searchBar.setShowsCancelButton(false, animated: true)
        return true
    }
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        self.searchText = searchText
        //print(self.searchText)
        
        if searchText.isEmpty {
            // load with previous data
            searchBarTextEmpty()
        }
        
    }
    
    // split the array into frd request and friends
    func splitArray(friendsArray:[FriendModel]) {
        
        for obj in friendsArray {
            if obj.type == "FriendRequest" {
                self.friendRequestArray.append(obj)
                
            } else if obj.type == "Friend" {
                self.friendListArray.append(obj)
            }
            
        }
        
    }
    
    func searchBarTextEmpty() {
        
        // set keyword empty
        searchText = ""
        
        if (tempFriendModelArray.count > 0) {
            
            // store temporary offset value back to offset variable
            offsetValue = tempFriendModelArray.count
            
            // store temporary array friends value back to friends array
            friendModelArray = self.tempFriendModelArray
            
            //print("tempArray\(tempFriendModelArray.count)")
            
            splitArray(friendModelArray)
            
            tempFriendModelArray = []
            
            
            //print("resetting the temporary array")
            
            // to reload tableview data
            self.tableViewFriends.reloadData()
            
        }
    }
    
    
    // Header View
    
    class HeaderView: UITableViewHeaderFooterView {
        
        //  var logHeaderViewDelegate: LogHeaderViewDelegate?
        // set friends count
        let labelFriendCount  = UILabel()
        
        var title :String = "" {
            
            didSet {
                textLabel!.text = title
                
            }
            
        }
        var friendsCount: String = " " {
            didSet {
                
                labelFriendCount.text = friendsCount
                
            }
        }
        
      /*  convenience init(frame: CGRect) {
            self.init(frame: frame)
            configureView()
        }
        */
        override init(reuseIdentifier: String?) {
            super.init(reuseIdentifier: reuseIdentifier)
            configureView()
        }

        required init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
            
            configureView()
        }
        
        func configureView() {
            
            contentView.addSubview(labelFriendCount)
            
            labelFriendCount.textColor = UIColor.whiteColor()
            // right margin for button info
            labelFriendCount.setRightMargin()
            
            // centerify button info
            labelFriendCount.centerVerticallyInSuperview()
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            
            // set label text color
            textLabel!.textColor = UIColor.whiteColor()
            
            // set background color
            contentView.backgroundColor = UIColor(red: 44.0/255.0, green: 44.0/255.0, blue: 44.0/255.0, alpha: 1.0)//UIColor.lightBlackColor()
        }
        
        func buttonActionInfo(sender: UIButton) {
            // logHeaderViewDelegate?.logHeader(self, infoButtonClickedForMealType: mealType)
        }
    }
    
    
    
    // Delete friendship
    func deleteFriendship(friendModel:FriendModel ,cell:FriendListCell) {
        
        
        UnfriendResponse.deleteFriendship(friendModel.user_id!, completionHandler: { (response) -> () in
            
            let response = response
            //print("delete respone code :\(response.metaModel?.responseCode)")
            //print("respone status :\(response.metaModel?.responseStatus)")
            
            //check for success
            if response.metaModel?.responseCode == 200 {
                
                // delete friendship successful
                // removing the element from the array and reloading the tableview
                
                self.friendModelArray = self.removeArrayElement(self.friendModelArray, removeItem: friendModel)
                
                self.friendListArray = self.removeArrayElement(self.friendListArray, removeItem: friendModel)
                
                // also remove details from temporary array
                
                self.tempFriendModelArray = self.removeArrayElement(self.tempFriendModelArray, removeItem: friendModel)
                
                if let count = Int(self.friendCount) {
                    self.friendCount = "\(count - 1)"
                }
                
                // self.pullToRefresh("refresh")
                
                let cellIndexPath = self.tableViewFriends.indexPathForCell(cell)
                
                self.tableViewFriends.deleteRowsAtIndexPaths([cellIndexPath!], withRowAnimation: UITableViewRowAnimation.Automatic)
                
                self.tableViewFriends.reloadData()
                
                
            } else {
                
                //print("Unfavourable --response code  \(response.metaModel?.responseCode)")
                
            }
            
            
            
        })
        
        
        
    }
    
    func removeArrayElement(var s :[FriendModel],removeItem:FriendModel )-> ([FriendModel]) {
        
        var index:Int = -1
        
        for (var i=0;i<s.count;i++) {
            if s[i].user_id == removeItem.user_id {
                index = i
                //print("found index ")
            }
            
        }
        if(index != -1){
            s.removeAtIndex(index)
        }
        
        return s
    }
    
    
    
    // Respond to friend request - Accept or reject
    func respondToFriendRequest(friendModel:FriendModel ,status:String, friendRequestCell: FriendsRequestCell) {
        
        if status == "Accepted" {
            friendRequestCell.buttonAccept.alpha = 0.5
            friendRequestCell.buttonAccept.userInteractionEnabled = false
        }
        FriendsRequestResponse.sendFriendRequest(friendModel.user_id!,status: status, completionHandler: { (response) -> () in
            
            let response = response
            
            //check for success
            if response.metaModel?.responseCode == 200 {
                
                // response successful
                // removing the element from the array and reloading the tableview
                
                self.friendModelArray = self.removeArrayElement(self.friendModelArray, removeItem: friendModel)
                
                self.friendRequestArray = self.removeArrayElement(self.friendRequestArray, removeItem: friendModel)
                
                // also remove details from temporary array
                
                self.tempFriendModelArray = self.removeArrayElement(self.tempFriendModelArray, removeItem: friendModel)
                
                //print("count is -\(self.tempFriendModelArray.count)")
                
                // add the user to friends list up on accepting the friend request
                
                if status == "Accepted" {
                    
                    self.friendListArray.append(friendModel)
                    self.tempFriendModelArray.append(friendModel)
                    friendRequestCell.buttonAccept.userInteractionEnabled = true
                    friendRequestCell.buttonAccept.alpha = 1
                    
                    // sort the list
                    self.friendListArray.sortInPlace{  String(stringInterpolationSegment: $0.userName).uppercaseString  < String(stringInterpolationSegment: $1.userName).uppercaseString }
                    self.tempFriendModelArray.sortInPlace{  String(stringInterpolationSegment: $0.userName).uppercaseString  < String(stringInterpolationSegment: $1.userName).uppercaseString }
                    
                    if let count = Int(self.friendCount) {
                        self.friendCount = "\(count + 1)"
                    }
                    
                }
                self.tableViewFriends.reloadData()
                
            } else {
                if status == "Accepted" {
                    friendRequestCell.buttonAccept.userInteractionEnabled = true
                    friendRequestCell.buttonAccept.alpha = 1
                }
                //print("Unfavourable --response code  \(response.metaModel?.responseCode)")
                
            }
            
        })
        
        
    }
    
    @IBAction func buttonActionAddFriend(sender: UIBarButtonItem) {
        searchBar.text?.removeAll(keepCapacity: true)
        searchBar.resignFirstResponder()
        self.performSegueWithIdentifier("kSegueAddFriendScreen", sender: nil)
        
    }
    @IBAction func buttonActionBack(sender: UIBarButtonItem) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "kFriendsProfileSegue" {
            let profileViewController = segue.destinationViewController as! ProfileViewController
            profileViewController.userId = sender as? String ?? ""
        }
        
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if alertView == alert1 {
            
        }
    }
    
    func showAlert(title: String, message: String) {
        // show alert controller if possible else show alert view
        
        if #available(iOS 8.0, *) {
            let alert = UIAlertController(title:title, message: message, preferredStyle: .Alert)
            alert.addAction(UIAlertAction(title: &&"ok", style: .Default) { action -> Void in
                
                })
            
            // show alert
            presentViewController(alert, animated: true, completion: nil)
            
        } else {
            // Fallback on earlier versions
            alert1 =  UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok")
            alert1?.show()
        }
        
    }
    
}
