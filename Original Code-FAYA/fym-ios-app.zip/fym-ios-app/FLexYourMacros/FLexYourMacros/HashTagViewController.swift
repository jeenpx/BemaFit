//
//  HashTagViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 06/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class HashTagViewController: UITableViewController, NewsFeedCellDelegate, UITableViewDragLoadDelegate, UIAlertViewDelegate {
    
    struct StoryBoard {
        struct CellIdentifiers {
            static let NewsFeedCellIdentifier = "kNewsFeedCell"
        }
        struct Segues {
            static let HashTagToProfileSegue = "khasTagToProfileSegue"
            static let HashTagCommentsSegue = "kHashTagCommentsSegue"
            static let HashTagSegue = "kHashTagSegue"
        }
        struct ViewControllerId {
            static let HashTagViewController = "kHashTagViewController"
        }
    }
    
    // limit value for messages
    var limitValue: Int = 10
    
    // Offset value for messages
    var offsetValue: Int = 0
    
    // store page meta
    var pageMetaModel = PageMetaModel()
    
    var hashTag: String = "" {
        didSet {
            // configure view with the hashtag
            configureView()
        }
    }
    
    var newsFeeds = [NewsFeed]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(animated: Bool) {
        
        pageMetaModel = PageMetaModel()
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            
            // clear news feeds
            self.newsFeeds.removeAll()
            
            tableView.reloadData()
            
            // show empty record message
            tableView.showEmptyTableViewMessage(&&"empty_tableview_message")
            return
        }
        
        // set value 0
        offsetValue = 0
        
        // clear news feeds
        self.newsFeeds.removeAll()
        
        // list feeds
        listFeeds(offsetValue, andLimit: limitValue, doLoadMore: false, pageMetaModel: pageMetaModel)
    }
    
    func configureView() {
        
        // set view title
        navigationItem.title = "#" + hashTag
        
        // set tableview cell classes
        tableView.registerNib(UINib(nibName: "NewsFeedCell", bundle: nil), forCellReuseIdentifier: StoryBoard.CellIdentifiers.NewsFeedCellIdentifier)
        
        // set estimated row height
        // XXX setting the lowest height now, recheck
        tableView.estimatedRowHeight = 230.0
        tableView.rowHeight = UITableViewAutomaticDimension
        
        // set delegate for pull to refresh and load more
        tableView.setDragDelegate(self, refreshDatePermanentKey: "kHashTag")
        
        // hide pull to refresh
        tableView.showRefreshView = false
        
        // show load more
        tableView.showLoadMoreView = true
        
        // tableview footer release text
        tableView.footerReleaseText = NSLocalizedString("release_to_load_more_status", comment: "")
        
        // tableview footer pull up text
        tableView.footerPullUpText = NSLocalizedString("pull_down_to_load_more_status", comment: "")
        
        //tableview footer loading text
        tableView.footerLoadingText = NSLocalizedString("loading_status", comment: "")
        
        
        // XXX fetch newsfeeds based on the hashtag and populate the tableview
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return newsFeeds.count
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return CGFloat((newsFeeds[indexPath.row] as NewsFeed).contentHeight)
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.NewsFeedCellIdentifier) as! NewsFeedCell
        
        // configure cell
        cell.newsFeed = newsFeeds[indexPath.row]
        cell.newsFeedCellDelegate = self
        cell.shareButton.hidden = true
        
        return cell
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        (cell as? NewsFeedCell)?.newsFeed = newsFeeds[indexPath.row]
        
        cell.layoutIfNeeded()
    }
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didSelectHashTag hashTag: String) {
        
        if self.hashTag == hashTag {
            showAlert(&&"notice", message: hashTag + " " + &&"already_shown_hashtag_message")
            return
        }
        // navigate to subhash screens
        let hashTagViewController = storyboard?.instantiateViewControllerWithIdentifier(StoryBoard.ViewControllerId.HashTagViewController) as! HashTagViewController
        hashTagViewController.hashTag = hashTag
        navigationController?.pushViewController(hashTagViewController, animated: true)
    }
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didSelectUser userId: String) {
        //print(userId)
        performSegueWithIdentifier(StoryBoard.Segues.HashTagToProfileSegue, sender: userId)
    }
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didSelectBusinessDirectory businessDirectoryId: String) {
        DirectoryDetailViewController.loadDirectoryDetail(businessDirectoryId, fromViewcontroller: self)
    }
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didLikeNewsFeed like: Bool) {
        //
    }
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didInspireNewsFeed inspire: Bool) {
        //
    }
    
    func newsFeedCell(newsFeedCell: NewsFeedCell, didDeleteNewsFeed delete: Bool) {
        if delete {
            let cellIndexPath = tableView.indexPathForCell(newsFeedCell)
            let feedId = newsFeeds[cellIndexPath!.row].id
            
            let reachability = appDelegate!.internetReachable
            if !reachability {
                // no internet
                
                // alert
                AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                return
            }
            
            // delete the feed
            
            
            UIAlertView.showWithTitle(&&"delete_confirmation_title", message: &&"delete_confirmation_message", cancelButtonTitle: &&"ok_button_title", otherButtonTitles: [&&"cancel_button_title"], tapBlock: { (alertview : UIAlertView, buttonIndex : Int) in
                
                
                if buttonIndex == alertview.cancelButtonIndex{
                    NewsFeedDeleteResponse.deleteNewsFeed(feedId, completionHandler: { (responseStatus) -> () in
                        if responseStatus == "OK" {
                            let feed = self.newsFeeds.filter({$0.id == feedId})
                            
                            // remove the feed
                            self.newsFeeds.remove(feed[0])
                            
                            // reload tableview
                            self.tableView.reloadData()
                        }
                    })
                    
                    
                }
            })
            
        }
    }
    
    func buttonActionComments(newsFeed: NewsFeed) {
        performSegueWithIdentifier(StoryBoard.Segues.HashTagCommentsSegue, sender: newsFeed)
    }
    
    func dragTableDidTriggerLoadMore(tableView: UITableView!) {
        // called when the load more is selected
        
        if !pageMetaModel.isValid {
            
            // cancel load more
            cancelLoadMoreWithInterval()
            return
        }
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            
            // cancel load more
            cancelLoadMoreWithInterval()
            return
        }
        
        if newsFeeds.count > 0 {
            // save messages count to offset
            
            offsetValue = newsFeeds.count
        }
        else {
            
            // set offset to zero
            offsetValue = 0
        }
        
        listFeeds(offsetValue, andLimit: limitValue, doLoadMore: true, pageMetaModel: pageMetaModel)
    }
    
    func cancelLoadMoreWithInterval() {
        
        // finish the load more
        NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: "finishLoadMore", userInfo: nil, repeats: false)
    }
    
    
    func dragTableLoadMoreCanceled(tableView: UITableView!) {
        // called when the load more is cancelled
        
        NSObject.cancelPreviousPerformRequestsWithTarget(self, selector: Selector("finishLoadMore"), object: nil)
    }
    
    func listFeeds(offset: Int, andLimit limit: Int, doLoadMore loadMore: Bool, pageMetaModel pageMeta: PageMetaModel) {
        // list news feeds based on offset, limit and load more status
        
        // extra security when passing hashtags
        let safeHashTag = hashTag.stringByReplacingOccurrencesOfString("#", withString: "")
        
        // get news feeds
        HashTagGetResponse.getHashTagFeedPosts(offset, andLimit: limit, hashTag: safeHashTag, pageMetaModel: pageMeta) { (newsFeeds, pageMeta) -> () in
            
            self.pageMetaModel = pageMeta
            if let feeds = newsFeeds as [NewsFeed]? {
                if self.newsFeeds.isEmpty == false {
                    
                    // append new values to the existing array
                    for feed in feeds {
                        self.newsFeeds.append(feed)
                    }
                    
                } else {
                    
                    // empty array
                    self.newsFeeds = feeds
                }
                
                if loadMore {
                    
                    // finish the load more
                    self.tableView.finishLoadMore()
                }
                // reload tableview
                self.tableView.reloadData()
            }
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        // navigate to profile
        if segue.identifier == StoryBoard.Segues.HashTagToProfileSegue {
            let profileViewController = segue.destinationViewController as! ProfileViewController
            profileViewController.userId = sender as? String ?? ""
        }
        else if segue.identifier == StoryBoard.Segues.HashTagCommentsSegue {
            let newsFeedCommentsViewController = segue.destinationViewController as! NewsFeedCommentsViewController
            newsFeedCommentsViewController.newsFeed = sender as! NewsFeed
        }
    }
    
    func showAlert(title: String, message: String) {
        
        if #available(iOS 8.0, *) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
            alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            
        } else {
            // Fallback on earlier versions
            UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok").show()
        }
    }
    
    func buttonShare(shareContent: FacebookShareModel) {
        
    }
    
    func finishLoadMore() {
        // to stop the load more and populate the tableview with new items
        
        tableView.finishLoadMore()
        tableView.reloadData()
    }
}
