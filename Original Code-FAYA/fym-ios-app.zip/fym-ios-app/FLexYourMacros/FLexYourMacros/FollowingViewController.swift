//
//  FollowingViewController.swift
//  FlexYourMacros
//
//  Created by DBG on 01/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol FollowingCellDelegate {
    func followFriend(followingcell: FollowingCell, user: UserDetailModel,status:Mode)
    func navigateToProfile( user: UserDetailModel)
    
}

// private, follow ,unfollow
enum Mode: String {
    case Private = "private"
    case Follow = "follow"
    case Unfollow = "unfollow"
    case SameUser = "sameUser"
    }

// header cell
class FollowingCell: UITableViewCell {
    
    @IBOutlet weak var imageViewUserIcon: UIImageView!
    @IBOutlet weak var labelUsername: UILabel!
    @IBOutlet weak var labelFullName: UILabel!
    @IBOutlet weak var buttonUnfollow: UIButton!
    @IBOutlet weak var buttonFollow: UIButton!
    @IBOutlet weak var buttonPrivate: UIButton!
    
    var statusMode: Mode = .Private{
        didSet{
            
            switch statusMode {
            case .Private:
                buttonPrivate.hidden = false
            case .Follow:
                buttonFollow.hidden = false
            case .Unfollow:
                buttonUnfollow.hidden = false
            case .SameUser:
                buttonUnfollow.hidden = true
                buttonFollow.hidden = true
                buttonPrivate.hidden = true
            }
            
        }
    }
    
    enum userType: String {
        case Follower = "follower"
        case Following = "following"
    }
    
    var followingCellDelegate : FollowingCellDelegate?
  
    var userDetails: UserDetailModel! {
        didSet{
            labelUsername.text = userDetails.userUserName
            labelFullName.text = "\(userDetails.userFirstName!) \(userDetails.userLastName!)"
            let imageURL = NSURL(string: userDetails.userProfilePhoto! as String)
            imageViewUserIcon.setImageWithURL(imageURL, placeholderImage:  UIImage(named:"FacebookIcon")!)
            buttonUnfollow.hidden = true
            buttonFollow.hidden = true
            buttonPrivate.hidden = true
            
            
            // current user
            if userDetails.userId == AppConfiguration.sharedAppConfiguration.userDetails?.userId {
                statusMode = .SameUser
            }else if userDetails.followStatus == "Yes" {
                statusMode = .Unfollow
            } else {
                
                if userDetails.userType == "Private" {
                    statusMode = .Private
                } else {
                    statusMode = .Follow
                }
            }
            
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        configureView()
    }
    
    func configureView() {
        
        labelUsername.userInteractionEnabled = true
        let tapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
        tapGesture.delegate = self
        labelUsername.addGestureRecognizer(tapGesture)
        
        imageViewUserIcon.userInteractionEnabled = true
        let userImageTapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
        userImageTapGesture.delegate = self
        imageViewUserIcon.addGestureRecognizer(userImageTapGesture)
        
    }

func didTaplabelUserNameWithGesture(tapGesture: UITapGestureRecognizer) {
    //print("didTaplabelUserNameWithGesture entered...")
    followingCellDelegate?.navigateToProfile(userDetails)
}

    @IBAction func buttonActionUnfollow(sender: UIButton) {
        //print("unfollow")
        followingCellDelegate?.followFriend(self, user: userDetails,status: statusMode)
    }
    @IBAction func buttonActionFollow(sender: UIButton) {
          //print("follow")
        followingCellDelegate?.followFriend(self, user: userDetails,status: statusMode)
    }
    @IBAction func buttonActionPrivate(sender: UIButton) {
        followingCellDelegate?.followFriend(self, user: userDetails,status: statusMode)
    }
    
}

class FollowingViewController: UITableViewController , UITableViewDragLoadDelegate , FollowingCellDelegate{
    
    var isFollow = false
    var arrayUser = [UserDetailModel]()
    var userId = " "
    var selectedUserId = ""
    
    // show empty tableview message
    var tableViewShowEmptyMessage = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView()
        if isFollow {
            getUsersList(0, limit: 20,type:"followers", doLoadMore: false)
        } else {
            getUsersList(0, limit: 20,type:"following", doLoadMore: false)
        }
       
    }
    
    
    func configureTableView() {
        
        // hide empty tableview cells
        tableView.tableFooterView = UIView(frame: CGRectZero)
        
        // set delegate for pull to refresh and load more
        tableView.setDragDelegate(self, refreshDatePermanentKey: "kMessageFriends")
        
        // hide pull to refresh
        tableView.showRefreshView = false
        
        // show load more
        tableView.showLoadMoreView = true
        
        // tableview footer release text
        tableView.footerReleaseText = NSLocalizedString("release_to_load_more_status", comment: "")
        
        // tableview footer pull up text
        tableView.footerPullUpText = NSLocalizedString("pull_down_to_load_more_status", comment: "")
        
        //tableview footer loading text
        tableView.footerLoadingText = NSLocalizedString("loading_status", comment: "")
        
    }
    
    
    
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.

        if arrayUser.count == 0 && tableViewShowEmptyMessage {
            // show empty record message
            
            tableView.showEmptyTableViewMessage()
        }
        else {
            tableView.backgroundView = UIView()
            tableView.separatorStyle = .SingleLine
        }
        return arrayUser.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifiers.FollowCell, forIndexPath: indexPath) as! FollowingCell
      //  cell.type = isFollow
        cell.userDetails = arrayUser[indexPath.row]
        cell.followingCellDelegate = self
        return cell
    }
    
    struct Storyboard {
        struct CellIdentifiers {
            static let FollowCell = "kFollowCell"
        }
    }
    
    func getUsersList(offset:Int,limit:Int,type:String,doLoadMore:Bool) {
        // API CALL FOR FOLLOWERS/FOLLOWING
        GetFollowingFollowerUserResponse.getUsersList(userId, offset: offset, type: type ,andLimit: 15, keywords: "", completionHandler: { (response:GetFollowingFollowerUserResponse) -> () in
            let res = response
            //print("respone code :\(res.metaModel?.responseCode)")
            //print("respone status :\(res.metaModel?.responseStatus)")
            
            // set true
            self.tableViewShowEmptyMessage = true
            
            if res.metaModel?.responseCode == 200 {
                if doLoadMore {
                self.arrayUser += res.user_list!
                self.finishLoadMore()
                }else{
                self.arrayUser = res.user_list!
                }
                self.tableView.reloadData()
            }
        })
    }
    // load more funcationality
    func dragTableDidTriggerLoadMore(tableView: UITableView!) {
        // called when the load more is selected
        
        if isFollow {
            getUsersList(arrayUser.count,limit: 20,type:"followers", doLoadMore: true)
        } else {
             getUsersList(arrayUser.count,limit: 20,type:"following", doLoadMore: true)
        }
    }
    func dragTableLoadMoreCanceled(tableView: UITableView!) {
        // called when the load more is cancelled
        NSObject.cancelPreviousPerformRequestsWithTarget(self, selector: Selector("finishLoadMore"), object: nil)
    }
    
    func finishLoadMore() {
        // to stop the load more and populate the tableview with new items
        tableView.finishLoadMore()
        tableView.reloadData()
    }
    
    func removeArrayElement(var s :[UserDetailModel],removeItem:UserDetailModel )-> ([UserDetailModel]) {
        
        var index:Int = -1
        
        for (var i=0;i<s.count;i++) {
            if s[i].userId == removeItem.userId {
                index = i
                //print("found index ")
            }
            
        }
        if(index != -1){
            s.removeAtIndex(index)
        }
        
        return s
    }
    
    func followFriend(followingcell: FollowingCell, user: UserDetailModel,status mode:Mode) {
        // posting the notification
        
        switch(mode) {
        case Mode.Private :
            //print("private\(user.userId)")
            //performSegueWithIdentifier("kFollowingProfileSegue", sender: user.userId)
            selectedUserId = user.userId!
        case Mode.Follow:
            FollowUserResponse.followUser(user.userId!, completionHandler: { (response) -> () in
                let followUserResponse = response
                //print("respone code :\(followUserResponse.metaModel?.responseCode)")
                //print("respone status :\(followUserResponse.metaModel?.responseStatus)")
                if followUserResponse.metaModel?.responseCode == 200 {
                  //  followingcell.buttonFollow.hidden = true
                  //  followingcell.buttonUnfollow.hidden = false                    
                    if self.isFollow {
                        self.getUsersList(0, limit: 20,type:"followers", doLoadMore: false)
                    } else {
                        self.getUsersList(0, limit: 20,type:"following", doLoadMore: false)
                    }
                    
                    let notification = NSNotification(name: Constants.updateUserProfile,
                        object: nil)
                    NSNotificationCenter.defaultCenter().postNotification(notification)
                    
                }
                
            })
        
        case Mode.Unfollow:
            UnfollowUserResponse.unfollowUser(user.userId!, completionHandler: { (response) -> () in
                let unFollowUserResponse = response
                //print("respone code :\(unFollowUserResponse.metaModel?.responseCode)")
                //print("respone status :\(unFollowUserResponse.metaModel?.responseStatus)")
                if unFollowUserResponse.metaModel?.responseCode == 200 {
                  /*  if self.userId == AppConfiguration.sharedAppConfiguration.userDetails?.userId {
                        self.arrayUser = self.removeArrayElement(self.arrayUser, removeItem: user)
                        self.tableView.reloadData()
                    }else{
                        followingcell.buttonFollow.hidden = false
                        followingcell.buttonUnfollow.hidden = true
                    }*/
                    
                    // refresh the list again
                    if self.isFollow {
                        self.getUsersList(0, limit: 20,type:"followers", doLoadMore: false)
                    } else {
                        self.getUsersList(0, limit: 20,type:"following", doLoadMore: false)
                    }
                    
                    let notification = NSNotification(name: Constants.updateUserProfile,
                        object: nil)
                    NSNotificationCenter.defaultCenter().postNotification(notification)
                    
                }
            })
            
        case Mode.SameUser :
              print("same user")
        }
        
       }
    
    // navigation to user profile
    func navigateToProfile(user: UserDetailModel) {
        selectedUserId = user.userId!
        performSegueWithIdentifier("kFollowingProfileSegue", sender: user.userId)

    }
    
    override func  prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "kFollowingProfileSegue" {
            let profileViewController = segue.destinationViewController as! ProfileViewController
            profileViewController.userId = selectedUserId//sender as? String ?? ""
        }
    }

}
