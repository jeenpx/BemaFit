//
//  GetUsersResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 21/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class GetUsersResponse: NSObject {

    var userDetailModel: [UserDetailModel]?
    var metaModel: MetaModel?
    var totalUsers: String?
    
    class var getUserResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)        
        // give referece to meta model
        responseMapping.addPropertyMapping(GetUsersResponse.metaModelKeyMapping)
        
        // give reference to user credential mapping
        responseMapping.addPropertyMapping(GetUsersResponse.userDetailModelKeyMapping)
        
        responseMapping.addAttributeMappingsFromDictionary(mappingDictionary)
        
        return responseMapping
    }
    
    class var userResponseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: getUserResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.signUpUserUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var userDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathGetFriends, toKeyPath: "userDetailModel", withMapping: UserDetailModel.objectMapping)
    }
    
    class var mappingDictionary: [String : String] {
        return(["total_users":"totalUsers"])
    }
    
    
    class func getFymUsers(isProgressbarEnabled:Bool, offset: Int, andLimit limit: Int, keywords: String, completionHandler: (getUserResponse:GetUsersResponse) -> ()) {
        
        if isProgressbarEnabled {
            SVProgressHUD.show()
        }
        RestKitManager.setToken(true)
        // let friendResponse = GetFriendsResponse()
        // friendResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
        
        // input parameters
        let params: Dictionary<String, AnyObject>  = ["offset": offset, "limit": limit ,"keyword": keywords , "exclude": "friendsAndRequestReceived"]
        
        
        // get the objects from the path login
        RestKitManager.sharedManager().getObject(nil, path:Constants.ServiceConstants.signUpUserUrl, parameters: params, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            let getUserResponse = mappingResult.firstObject as! GetUsersResponse
            
            //print("respone code :\(getUserResponse.metaModel?.responseCode)")
            //print("respone status :\(getUserResponse.metaModel?.responseStatus)")
            
            completionHandler(getUserResponse: getUserResponse)
            if isProgressbarEnabled {
                SVProgressHUD.dismiss()
            }
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                if isProgressbarEnabled {
                    SVProgressHUD.dismiss()
                }
                //print("failed to load masterdata with error \(error)")
        })
        
        
    }
}
