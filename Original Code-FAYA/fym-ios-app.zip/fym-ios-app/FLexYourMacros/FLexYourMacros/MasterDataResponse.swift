//
//  MasterDataResponse.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 10/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _MasterDataResponse = MasterDataResponse()

class MasterDataResponse: NSObject {
    
    var masterDataModelEnglish: MasterDataModel?
    var masterDataModelSpanish: MasterDataModel?
    var metaModel: MetaModel?
    
    class var sharedMasterDataResponse: MasterDataResponse {
        return _MasterDataResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(MasterDataResponse.metaModelKeyMapping)
        
        // give reference to accesstoken mapping
        responseMapping.addPropertyMapping(MasterDataResponse.masterDataModelEnglishKeyMapping)
        responseMapping.addPropertyMapping(MasterDataResponse.masterDataModelSpanishKeyMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.masterdataUrlString, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    class var foodCategoryResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kFoodCategoryUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var masterDataModelEnglishKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMasterData, toKeyPath: "masterDataModelEnglish", withMapping: MasterDataModel.objectMapping)
    }
    private class var masterDataModelSpanishKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMasterDataES, toKeyPath: "masterDataModelSpanish", withMapping: MasterDataModel.objectMapping)
    }
    
    class func fetchMasterData(completionHandler: (masterDataModelEnglish: MasterDataModel, masterDataModelSpanish: MasterDataModel) -> ()) {
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["grant_type":"password"]
        }
        
        // get the objects from the path login
        RestKitManager.sharedManager().getObjectsAtPath(Constants.ServiceConstants.masterdataUrlString, parameters: nil, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            
            // get the user response
            let masterDataResponse = mappingResult.firstObject as! MasterDataResponse
            
            
            //check for success
            if masterDataResponse.metaModel?.responseCode != 200 {
                return;
            }
            
            completionHandler(masterDataModelEnglish: masterDataResponse.masterDataModelEnglish!, masterDataModelSpanish: masterDataResponse.masterDataModelSpanish!)
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                //print("failed to load masterdata with error \(error)")
        })
    }
    
    class func updateFoodCategories(completionHandler: () -> ()) {
        
        RestKitManager.sharedManager().getObjectsAtPath(Constants.ServiceConstants.kFoodCategoryUrl, parameters: nil, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            
            // get the user response
            let masterDataResponse = mappingResult.firstObject as? MasterDataResponse
            
            // check for success
            if masterDataResponse?.metaModel?.responseCode != 200 {
                completionHandler()
                return
            }
            
            if let foodCategories = masterDataResponse?.masterDataModelEnglish?.mealCategory {
                AppConfiguration.sharedAppConfiguration.mealCategories_english = foodCategories
            }
            
            if let foodCategories = masterDataResponse?.masterDataModelSpanish?.mealCategory {
                AppConfiguration.sharedAppConfiguration.mealCategories_spanish = foodCategories
            }
            
            completionHandler()
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                //print("failed to load food categories with error \(error)")
        })
    }
}
