//
//  ManageGoalsListViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 5/29/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class GoalDetails {
    
    class func getGoal(goals: [GoalModel]?) -> (goal: GoalModel, goalOption: GoalOptionModel) {
        // tuple returns goal name and goal option name
        
        if let userDiet: UserDietModel = AppConfiguration.sharedAppConfiguration.userDiet {
            if let goalModels: [GoalModel] = goals {
                for goal in goalModels {
                    if let arrayOption = goal.goalOptions {
                        
                        let optionId = FymUser.sharedFymUser.userGoalOptionId == "" ?  userDiet.dietGoalOptionId : FymUser.sharedFymUser.userGoalOptionId
                        
                        // filter user selected goal option from masterdata
                        var goalOption: [GoalOptionModel] = arrayOption.filter {
                            $0.goalOptionId == optionId }//userDiet.dietGoalOptionId }
                        
                        if goalOption.count > 0 {
                            
                            // return user selected goal name and goal option name
                            return (goal ,goalOption[0])
                        }
                    }
                }
            }
        }
        
        // returns empty strings if no matching found
        return (GoalModel(), GoalOptionModel())
    }
    
    class func getGoalOptions(goalModel: GoalModel) -> (goalOptions: [GoalOptionModel], defaultGoalOption: GoalOptionModel) {
        var arrayGoalOptions = [GoalOptionModel]()
        
        // save goal name
        FymUser.sharedFymUser.userSelectedGoal = goalModel
        
        let userGoals = AppConfiguration.sharedAppConfiguration.goals
        var goals = userGoals.filter{$0.goalId == FymUser.sharedFymUser.userSelectedGoal?.goalId}
        let goalOptions = goals[0].goalOptions
        if let goalOptions = goalOptions {
            
            // save default goal option id for the selected goal in picker
            //            FymUser.sharedFymUser.userGoalOptionId = goalOptions[0].goalOptionId!
            
            for goalOption in goalOptions {
                arrayGoalOptions.append(goalOption)
            }
        }
        
        return (arrayGoalOptions, arrayGoalOptions[0])
    }
    
    class func getGoalOptionIdFromNameInPicker(goalOptionName: String) -> String {
        //print("goalOptionName: \(goalOptionName)")
        let userGoals = AppConfiguration.sharedAppConfiguration.goals
        var goals = userGoals.filter{$0.goalId == FymUser.sharedFymUser.userSelectedGoal?.goalId}
        let goalOptions = goals[0].goalOptions
        let goalOption = goalOptions?.filter { $0.goalOptionName == goalOptionName}
        if let goalOptionvalue = goalOption {
            return goalOptionvalue[0].goalOptionId!
        }
        //        }
        return " "
    }
}

enum PickerMode {
    case Goal
    case GoalOption
    case Activity
}

private var _ManageGoalsAlert = ManageGoalsAlert()

class ManageGoalsAlert: NSObject {
    
    // show save alert
    var showAlert = false
    
    class var sharedManageGoalsAlert: ManageGoalsAlert {
        return _ManageGoalsAlert
    }
}

class ManageGoalsListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, GoalCellDelegate, UIPickerViewDataSource, UIPickerViewDelegate, ActivityLevelCellDelegate, UIAlertViewDelegate, NumberOfMealsCellDelegate, UITextFieldDelegate {
    
    var cellToReturn: UITableViewCell?
    
    // tableview instance
    @IBOutlet weak var manageGoalsTableView: UITableView!
    
    // picker components
    @IBOutlet var picker: UIPickerView!
    @IBOutlet var toolbar: UIToolbar!
    
    // picker elements
    var arrayPickerGoals = [GoalModel]() {
        didSet {
            picker?.reloadAllComponents()
        }
    }
    
    // picker elements
    var arrayPickerGoalOptions = [GoalOptionModel]() {
        didSet {
            picker?.reloadAllComponents()
        }
    }
    
    // picker elements
    var arrayPickerActivityLevels = [ActivityLevelModel]() {
        didSet {
            picker?.reloadAllComponents()
        }
    }
    
    var pickerMode: PickerMode = PickerMode.Goal
    var selectedTextFieldPicker: UITextField?
    var textFieldOption: UITextField?
    var textFieldActivityLevel: UITextField?
    var labelActivityDescription: UILabel?
    var selectedGoal = GoalModel()
    var selectedGoalOption = GoalOptionModel()
    var selectedActivity = ActivityLevelModel()
    var pickerViewSelectedItem = ""
    var numberOfMealsField = UITextField()
    
    // fym user instance
    var fymUser = FymUser()
    var offscreenCells = [String: ActivityLevelCell]()
    
    struct Storyboard {
        struct cellIdentifiers {
            static let FormulaCellIdentifier = "kFormulaCell"
            static let GoalCellIdentifier = "kGoalCell"
            static let ActivityCellIdentifier = "kActivityCell"
            static let NutritionCellIdentifier = "kNutritionCell"
            static let MealsCellIdentifier = "kMealsCell"
            static let FormulaSectionCellIdentifier = "kFormulaSectionCell"
            static let GoalSectionCellIdentifier = "kGoalSectionCell"
            static let ActivitySectionCellIdentifier = "kActivitySectionCell"
            static let NutritionSectionCellIdentifier = "kNutritionSectionCell"
            static let MealsSectionCellIdentifier = "kMealsSectionCell"
        }
        struct Segue {
            static let ManageGoalsNutrition = "kManageGoalsNutrition"
        }
    }
    
    struct cellFormulaConstants {
        static let athletesFormula = &&"athelete_formula"
        static let leanMassFormula = &&"lean_mass_formula"
        static let physique = "physique"
        static let leanMass = "lean_mass"
    }
    
    let cellSectionIdentifiers = [Storyboard.cellIdentifiers.FormulaSectionCellIdentifier, Storyboard.cellIdentifiers.GoalSectionCellIdentifier, Storyboard.cellIdentifiers.ActivitySectionCellIdentifier, Storyboard.cellIdentifiers.NutritionSectionCellIdentifier, Storyboard.cellIdentifiers.MealsSectionCellIdentifier]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // by default false
        ManageGoalsAlert.sharedManageGoalsAlert.showAlert = false
        
        // refresh data
        // AppConfiguration.refresh()
        
        //store current values
        storeFymUserValues()
        
        // configure the tableview
        configureTableView()
        
        //call to refresh user details
        refreshUserDetails()
        
    }
    
    func refreshUserDetails() {
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        AppConfiguration.refreshUserDetails { (refreshedUserDetails) -> () in
            if refreshedUserDetails {
                
                //store new values
                self.storeFymUserValues()
            }
        }
        
    }
    
    func configureTableView() {
        
        // hide empty tableview cells
        manageGoalsTableView.tableFooterView = UIView(frame: CGRectZero)
        
        manageGoalsTableView.rowHeight = UITableViewAutomaticDimension
        manageGoalsTableView.estimatedRowHeight = 60
    }
    
    
    func conversionMetricUnits(ht:Double)->(String) {
        
        let heightInCentimeters = ht
        
        // calculate feet
        var feet = Double(heightInCentimeters)/30.48
        feet = floor(feet)
        
        // calculate total inches
        let inchesTotal = Double(heightInCentimeters)/2.54
        
        // remaining inches
        var inchesRemaing = inchesTotal - (feet*12)
        inchesRemaing = round(inchesRemaing)
        
        // converted string
        let converted = "\(Int(feet)).\(Int(inchesRemaing))"
        return converted
        
    }
    
    func storeFymUserValues() {
        
        //-XXX call refresh app configuration api
        
        // save formula
        if let formula = AppConfiguration.sharedAppConfiguration.userDiet?.dietFormula {
            FymUser.sharedFymUser.formulaType = formula
        }
        
        // save activity level id
        if let activityLevelId = AppConfiguration.sharedAppConfiguration.userDiet?.dietActivityLevel {
            FymUser.sharedFymUser.userActivityLevelId = activityLevelId
        }
        
        // save nutrition id
        if let nutritionId = AppConfiguration.sharedAppConfiguration.userDiet?.dietNutritionalPlan {
            FymUser.sharedFymUser.userNutritionType = nutritionId
            
            if let fiberValue = AppConfiguration.sharedAppConfiguration.userDiet?.dietFiber {
                FymUser.sharedFymUser.userCustomFiberValue = fiberValue
            }
            FymUser.sharedFymUser.userCustomCalorie = AppConfiguration.sharedAppConfiguration.userDiet!.dietCalories!.doubleValue
            
            FymUser.sharedFymUser.userCustomProteinPercentage = calculateUserMacroPercentages().proteinPercentage//
            FymUser.sharedFymUser.userCustomFatPercentage = calculateUserMacroPercentages().fatPercentage
            FymUser.sharedFymUser.userCustomCarbsPercentage = calculateUserMacroPercentages().carbsPercentage
        }
        
        // save number of meals
        if let numberOfMeals = AppConfiguration.sharedAppConfiguration.userDiet?.numberOfMeals {
            FymUser.sharedFymUser.userNumberOfMeals = numberOfMeals.intValue
        }
        
        // save user selected goal option id and goal name
        let userSelectedGoalOptionId = GoalDetails.getGoal(AppConfiguration.sharedAppConfiguration.goals).goalOption.goalOptionId
        let userSelectedGoal = GoalDetails.getGoal(AppConfiguration.sharedAppConfiguration.goals).goal
        
        // save goal option id
        if userSelectedGoalOptionId != nil{
            FymUser.sharedFymUser.userGoalOptionId = userSelectedGoalOptionId!
        }
        //save user calorie and goal type selected
        FymUser.sharedFymUser.userSelectedGoal = userSelectedGoal
        
        if userSelectedGoal.goalId == "4" {
            
            if let calories = AppConfiguration.sharedAppConfiguration.userDiet?.dietCalories {
                
                FymUser.sharedFymUser.userCustomCalorie = calories.doubleValue
            }
        }
        
        // save user details
        
        if let gender = AppConfiguration.sharedAppConfiguration.userDetails?.userGender {
            FymUser.sharedFymUser.userGender = gender
        }
        
        if let weight = AppConfiguration.sharedAppConfiguration.userDetails?.userWeight {
            FymUser.sharedFymUser.userWeight = weight
        }
        
        if let height = AppConfiguration.sharedAppConfiguration.userDetails?.userHeight {
            FymUser.sharedFymUser.userHeight = conversionMetricUnits(height.doubleValue)
        }
        
        
        if let dob = AppConfiguration.sharedAppConfiguration.userDetails?.userDob {
            //print("dob:\(dob)")
            FymUser.sharedFymUser.userDob = dob.dateValue("yyyy-MM-dd")!
        }
        
        if let userDobString = AppConfiguration.sharedAppConfiguration.userDetails?.userDob {
            //print("dob:\(userDobString)")
            FymUser.sharedFymUser.userDobString = userDobString
        }
        
        
        if let firstName = AppConfiguration.sharedAppConfiguration.userDetails?.userFirstName {
            FymUser.sharedFymUser.userFirstName = firstName
        }
        
        if let lastName = AppConfiguration.sharedAppConfiguration.userDetails?.userLastName {
            FymUser.sharedFymUser.userLastName = lastName
        }
        
        if let email = AppConfiguration.sharedAppConfiguration.userDetails?.userEmail {
            FymUser.sharedFymUser.userEmail = email
        }
        
        if let website = AppConfiguration.sharedAppConfiguration.userDetails?.userWebsite {
            FymUser.sharedFymUser.userWebsite = website
        }
        
        if let fat = AppConfiguration.sharedAppConfiguration.userDetails?.userFat {
            FymUser.sharedFymUser.userFatLoss = fat
        }
        
        fymUser = FymUser.sharedFymUser
        
        manageGoalsTableView.reloadData()
    }
    
    func getFloatRoundedValue(currentValue: String) -> Float {
        
        
        return 0.0//78777//round (0.01999996 * 100.0) / 100.0
        
    }
    
    func calculateUserMacroPercentages() -> (proteinPercentage: Double, fatPercentage: Double, carbsPercentage: Double) {
        
        let calories = FymUser.sharedFymUser.getTheSelectedGoalCalorie()
        var protein: Double = 0.0
        if let proteinValue = AppConfiguration.sharedAppConfiguration.userDiet?.userDietMacroModel?.dietMacroProtein {
            protein = proteinValue.doubleValue//.roundPlaces(decimalPlaces: 2)
        }
        
        var fat: Double = 0.0
        if let fatValue = AppConfiguration.sharedAppConfiguration.userDiet?.userDietMacroModel?.dietMacroFat {
            fat = fatValue.doubleValue//.roundPlaces(decimalPlaces: 2)
        }
        
        var carb: Double = 0.0
        if let carbValue = AppConfiguration.sharedAppConfiguration.userDiet?.userDietMacroModel?.dietMacroCarbs {
            carb = carbValue.doubleValue//.roundPlaces(decimalPlaces: 2)
        }
        
        protein = FymUser.sharedFymUser.userNutritionType == "5" ? protein : calculateUserMacros().proteinValue
        fat = FymUser.sharedFymUser.userNutritionType == "5" ? fat : calculateUserMacros().fatValue
        carb = FymUser.sharedFymUser.userNutritionType == "5" ? carb : calculateUserMacros().carbsValue
        
        
        var userProteinPercentage: Double = 0.0
        var userFatPercentage: Double = 0.0
        var userCarbsPercentage: Double = 0.0
        // calculate macro percentage : if custom - give the custom value entered; else calculate based on formulae
        userProteinPercentage = ((protein*4)/calories)*100
        userFatPercentage = ((fat*9)/calories)*100
        userCarbsPercentage = ((carb*4)/calories)*100
        return (userProteinPercentage, userFatPercentage, userCarbsPercentage)
    }
    
    func calculateUserMacros() -> (proteinValue: Double, fatValue: Double, carbsValue: Double) {
        
        var userProtein: Double = 0.0
        var userFat: Double = 0.0
        var userCarbs: Double = 0.0
        
        let calories = FymUser.sharedFymUser.getTheSelectedGoalCalorie()//FymUser.sharedFymUser.userCustomCalorie
        
        let weightInLb =  2.20462 * FymUser.sharedFymUser.userWeightinKg.doubleValue
        // calculate macro values : if custom - give the custom value entered; else calculate based on formulae
        userProtein = weightInLb * 1.0
        userFat = weightInLb * 0.35
        userCarbs = (calories-(userProtein*4 + userFat*9))/4
        
        return (userProtein, userFat, userCarbs)
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        switch indexPath.section {
            
        case 0:
            let formulaCell = tableView.dequeueReusableCellWithIdentifier(Storyboard.cellIdentifiers.FormulaCellIdentifier) as! FormulaCell
            
            if indexPath.row == 0 {
                formulaCell.labelFormula.text = cellFormulaConstants.athletesFormula
                if FymUser.sharedFymUser.formulaType == cellFormulaConstants.physique {
                    formulaCell.imageViewtickGreen.hidden = false
                }
            }
            else {
                formulaCell.labelFormula.text = cellFormulaConstants.leanMassFormula
                if FymUser.sharedFymUser.formulaType == cellFormulaConstants.leanMass {
                    formulaCell.imageViewtickGreen.hidden = false
                }
            }
            
            cellToReturn = formulaCell
            
        case 1:
            let goalCell: GoalCell = tableView.dequeueReusableCellWithIdentifier(Storyboard.cellIdentifiers.GoalCellIdentifier) as! GoalCell
            
            // save goals
            goalCell.goals = AppConfiguration.sharedAppConfiguration.goals
            goalCell.goalCellDelegate = self
            
            cellToReturn = goalCell
            
        case 2:
            let activityCell: ActivityLevelCell = tableView.dequeueReusableCellWithIdentifier(Storyboard.cellIdentifiers.ActivityCellIdentifier) as! ActivityLevelCell
            
            let activityLevels = AppConfiguration.sharedAppConfiguration.activityLevels
            
            // returns the user selected activity level
            var activities: [ActivityLevelModel] = activityLevels.filter { $0.activityId == FymUser.sharedFymUser.userActivityLevelId }
            
            // save activity level
            activityCell.activityLevel = activities[0]
            activityCell.activityLevelCellDelegate = self
            
            activityCell.setNeedsUpdateConstraints()
            activityCell.updateConstraintsIfNeeded()
            
            cellToReturn = activityCell
            
        case 3:
            let nutritionCell: NutritionCell = tableView.dequeueReusableCellWithIdentifier(Storyboard.cellIdentifiers.NutritionCellIdentifier) as! NutritionCell
            
            let nutritionPlans = AppConfiguration.sharedAppConfiguration.nutritionPlans
            
            // returns the user selected nutrition plan
            var plans: [NutritionPlanModel] = nutritionPlans.filter { $0.nutritionId == FymUser.sharedFymUser.userNutritionType }
            
            // save nutrition
            nutritionCell.nutrition = plans[0]
            
            cellToReturn = nutritionCell
            
        case 4:
            let mealsCell: NumberOfMealsCell = tableView.dequeueReusableCellWithIdentifier(Storyboard.cellIdentifiers.MealsCellIdentifier) as! NumberOfMealsCell
            mealsCell.numberOfMeals = String(FymUser.sharedFymUser.userNumberOfMeals)
            mealsCell.numberOfMealsCellDelegate = self
            cellToReturn = mealsCell
        default:
            break
        }
        
        return cellToReturn!
    }
    
    var firstCell: FormulaCell?
    var secondCell: FormulaCell?
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if indexPath.section == 0 {
            
            // get the first cell of tableview
            firstCell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: 0, inSection: 0)) as? FormulaCell
            
            // get the second cell of tableview
            secondCell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: 1, inSection: 0)) as? FormulaCell
            
            if indexPath.row == 0 {
                // show the tick for Athlete’s Formula
                
                firstCell!.imageViewtickGreen.hidden = false
                secondCell!.imageViewtickGreen.hidden = true
                FymUser.sharedFymUser.formulaType = cellFormulaConstants.physique
                
                // alert message to save data
                ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
            }
            else if indexPath.row == 1 {
                // show the tick for Lean Mass Formula
                
                if FymUser.sharedFymUser.userFatLoss == "0" {
                    
                    let alert = UIAlertView(title: &&"notice", message: &&"manage_enter_body_fat", delegate: self, cancelButtonTitle:  &&"cancel", otherButtonTitles: &&"ok")
                    alert.alertViewStyle = UIAlertViewStyle.PlainTextInput
                    alert.tag = 2
                    alert.textFieldAtIndex(0)?.delegate = self
                    alert.textFieldAtIndex(0)!.tag = 120
                    alert.show()
                    return
                }
                
                firstCell!.imageViewtickGreen.hidden = true
                secondCell!.imageViewtickGreen.hidden = false
                FymUser.sharedFymUser.formulaType = cellFormulaConstants.leanMass
                
                // alert message to save data
                ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
            }
        }
            
        else if indexPath.section == 3 {
            
            textFieldOption?.resignFirstResponder()
            
            if FymUser.sharedFymUser.userSelectedGoal?.goalId == "4" {
                
                if  FymUser.sharedFymUser.userCustomCalorie <= 0.0 {
                    showAlert(&&"notice", message: &&"calorie_empty_message")
                    return
                }
            }
            
            if FymUser.sharedFymUser.userCustomProteinPercentage == 0.0 && FymUser.sharedFymUser.userCustomFatPercentage == 0.0 &&
                FymUser.sharedFymUser.userCustomCarbsPercentage == 0.0 {
                    
                    FymUser.sharedFymUser.userCustomProteinPercentage = calculateUserMacroPercentages().proteinPercentage//
                    FymUser.sharedFymUser.userCustomFatPercentage =
                        calculateUserMacroPercentages().fatPercentage
                    FymUser.sharedFymUser.userCustomCarbsPercentage = calculateUserMacroPercentages().carbsPercentage
            }
            
            performSegueWithIdentifier(Storyboard.Segue.ManageGoalsNutrition, sender: self)
        }
        
        let cell = tableView.cellForRowAtIndexPath(indexPath)
        if cell?.reuseIdentifier == Storyboard.cellIdentifiers.ActivityCellIdentifier {
            
            let activityCell: ActivityLevelCell  = tableView.cellForRowAtIndexPath(indexPath) as! ActivityLevelCell
            activityCell.textFieldActivityName.becomeFirstResponder()
        }
    }
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        switch section {
        case 0:
            return 2
        case 1, 2, 3, 4:
            return 1
        default:
            return 0
        }
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cell: UITableViewCell = tableView.dequeueReusableCellWithIdentifier(cellSectionIdentifiers[section])!
        return cell as UIView
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 5
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.section == 2 {
            
            var cell = offscreenCells[Storyboard.cellIdentifiers.ActivityCellIdentifier]
            if cell == nil {
                cell = tableView.dequeueReusableCellWithIdentifier(Storyboard.cellIdentifiers.ActivityCellIdentifier) as? ActivityLevelCell
                offscreenCells[Storyboard.cellIdentifiers.ActivityCellIdentifier] = cell
            }
            
            let activityLevels = AppConfiguration.sharedAppConfiguration.activityLevels
            
            // returns the user selected activity level
            var activities: [ActivityLevelModel] = activityLevels.filter { $0.activityId == FymUser.sharedFymUser.userActivityLevelId }
            
            // save activity level
            cell?.activityLevel = activities[0]
            
            cell?.setNeedsUpdateConstraints()
            cell?.updateConstraintsIfNeeded()
            cell?.bounds = CGRectMake(0.0, 0.0, CGRectGetWidth(manageGoalsTableView.bounds), CGRectGetHeight(cell!.bounds))
            
            cell?.setNeedsLayout()
            cell?.layoutIfNeeded()
            
            cell?.labelActivityDescription.preferredMaxLayoutWidth = CGRectGetWidth(cell!.labelActivityDescription.bounds)
            cell?.labelActivityDescription.setNeedsUpdateConstraints()
            
            // Get the actual height required for the cell's contentView
            var height = cell?.contentView.systemLayoutSizeFittingSize(UILayoutFittingCompressedSize).height
            
            // Add an extra point to the height to account for the cell separator, which is added between the bottom
            // of the cell's contentView and the bottom of the table view cell.
            height = height! + 1
            return height!
        }
        if indexPath.section == 3 {
            return 60
        }
        return 45
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == Storyboard.Segue.ManageGoalsNutrition {
            let manageGoalsNutritionViewController = segue.destinationViewController as! ManageGoalsNutritionViewController
            //manageGoalsNutritionViewController.fymUser = FymUser.sharedFymUser
        }
    }
    
    // goals delegate methods
    func manageGoalCellGoalName(textFieldGoalName: UITextField, textFieldGoalOption: UITextField, goals: [GoalModel], cellForSelectedTextField tableViewCell: UITableViewCell) {
        
        // set picker mode
        
        pickerMode = PickerMode.Goal
        
        // configure pickerview for goal name textfield
        arrayPickerGoals = goals
        selectedGoal = arrayPickerGoals[0]
        
        selectedGoal = FymUser.sharedFymUser.userSelectedGoal!
        
        let index = arrayPickerGoals.indexOf(selectedGoal)
        picker.selectRow(index!, inComponent: 0, animated: false)
        
        
        textFieldGoalName.inputView = picker
        textFieldGoalName.inputAccessoryView = toolbar
        
        textFieldOption = textFieldGoalOption
        selectedTextFieldPicker = textFieldGoalName
        if FymUser.sharedFymUser.userSelectedGoal?.goalId == "4" {
            textFieldOption?.inputView = nil
            textFieldOption?.inputAccessoryView = nil
            return
        }
        // save selected textfield
        
    }
    
    func manageGoalCellGoalOption(textFieldGoalOption: UITextField, textFieldGoalName: UITextField, cellForSelectedTextField tableViewCell: UITableViewCell) {
        
        pickerMode = PickerMode.GoalOption
        
        // configure pickerview for goal name textfield
        arrayPickerGoalOptions = GoalDetails.getGoalOptions(FymUser.sharedFymUser.userSelectedGoal!).goalOptions
        selectedGoalOption = arrayPickerGoalOptions[0]
        if FymUser.sharedFymUser.userSelectedGoal?.goalId == "4" {
            textFieldOption = textFieldGoalOption
            
            // custom calorie value case
            //textFieldOption?.keyboardType = UIKeyboardType.DecimalPad
            return
        }
        
        var goalOption = arrayPickerGoalOptions.filter { $0.goalOptionId == FymUser.sharedFymUser.userGoalOptionId }
        
        selectedGoalOption = goalOption[0]
        
        let index = arrayPickerGoalOptions.indexOf(goalOption[0])
        picker.selectRow(index!, inComponent: 0, animated: false)
        
        textFieldGoalOption.inputView = picker
        textFieldGoalOption.inputAccessoryView = toolbar
        
        // save selected textfield
        selectedTextFieldPicker = textFieldGoalOption
        textFieldOption = textFieldGoalOption
        
    }
    
    // activity level delegate methods
    func activityLevelCell(textField: UITextField, activityLevels: [ActivityLevelModel], cellForSelectedTextField: ActivityLevelCell) {
        // configure pickerview for activity level
        
        pickerMode = PickerMode.Activity
        
        arrayPickerActivityLevels = activityLevels
        selectedActivity = arrayPickerActivityLevels[0]
        
        var activityLevelModel = arrayPickerActivityLevels.filter { $0.activityId == FymUser.sharedFymUser.userActivityLevelId }
        
        selectedActivity = activityLevelModel[0]
        
        let index = arrayPickerActivityLevels.indexOf(activityLevelModel[0])
        picker.selectRow(index!, inComponent: 0, animated: false)
        
        textField.inputView = picker
        textField.inputAccessoryView = toolbar
        
        // save selected textfield
        selectedTextFieldPicker = textField
        textFieldActivityLevel = textField
        labelActivityDescription = cellForSelectedTextField.labelActivityDescription
    }
    
    
    
    // picker view delegates and datasource
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        var count = 0
        switch pickerMode {
            
        case .Goal:
            count = arrayPickerGoals.count
        case .GoalOption:
            count = arrayPickerGoalOptions.count
        case .Activity:
            count = arrayPickerActivityLevels.count
        }
        return count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        var value = ""
        switch pickerMode {
            
        case .Goal:
            value = arrayPickerGoals[row].goalName!
        case .GoalOption:
            value = arrayPickerGoalOptions[row].goalOptionName!
        case .Activity:
            value = arrayPickerActivityLevels[row].activityName!
        }
        
        return value
    }
    
    func getActivityLevelDetails(activityLevelName: String) -> ActivityLevelModel {
        let activityLevels = AppConfiguration.sharedAppConfiguration.activityLevels //{
        var activityLevel = activityLevels.filter{ $0.activityName == activityLevelName }
        return activityLevel[0]
    }
    
    @IBAction func buttonActionDone(sender: AnyObject) {
        switch pickerMode {
            
        case .Goal:
            selectedGoal = arrayPickerGoals[picker.selectedRowInComponent(0)]
            
            // if user chooses new item and pressed done button without clicking on picker
            if FymUser.sharedFymUser.userSelectedGoal?.goalId != selectedGoal.goalId {
                
                // alert message to save data
                ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
            }
            
            FymUser.sharedFymUser.userSelectedGoal = selectedGoal
            selectedTextFieldPicker!.text = selectedGoal.goalName
            
            // if custom then place custom calorie value
            if FymUser.sharedFymUser.userSelectedGoal?.goalId == "4" {
                textFieldOption?.text = "\(FymUser.sharedFymUser.userCustomCalorie)"
                FymUser.sharedFymUser.userGoalOptionId = "8"
                selectedTextFieldPicker?.resignFirstResponder()
                selectedTextFieldPicker?.inputView = nil
                selectedTextFieldPicker?.inputAccessoryView = nil
                return
            }
            FymUser.sharedFymUser.userGoalOptionId = GoalDetails.getGoalOptions(selectedGoal).defaultGoalOption.goalOptionId!
            
            if FymUser.sharedFymUser.userSelectedGoal?.goalId == "2" {
                
                FymUser.sharedFymUser.userFatlossIntensityValue = GoalDetails.getGoalOptions(selectedGoal).defaultGoalOption.goalPercentage!
            } else if FymUser.sharedFymUser.userSelectedGoal?.goalId == "3" {
                FymUser.sharedFymUser.userBulkingIntensityValue = GoalDetails.getGoalOptions(selectedGoal).defaultGoalOption.goalPercentage!
            }
            
            textFieldOption?.text = GoalDetails.getGoalOptions(selectedGoal).defaultGoalOption.goalOptionName
            
        case .GoalOption:
            selectedGoalOption = arrayPickerGoalOptions[picker.selectedRowInComponent(0)]
            
            // if user chooses new item and pressed done button without clicking on picker
            if FymUser.sharedFymUser.userGoalOptionId != selectedGoalOption.goalOptionId! {
                
                // alert message to save data
                ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
            }
            
            if FymUser.sharedFymUser.userSelectedGoal?.goalId == "4" {
                
                textFieldOption?.text = "\(FymUser.sharedFymUser.userCustomCalorie)"
                FymUser.sharedFymUser.userGoalOptionId = "8"
            } else {
                
                if FymUser.sharedFymUser.userSelectedGoal?.goalId == "2" {
                    
                    FymUser.sharedFymUser.userFatlossIntensityValue = selectedGoalOption.goalPercentage!
                } else if FymUser.sharedFymUser.userSelectedGoal?.goalId == "3" {
                    FymUser.sharedFymUser.userBulkingIntensityValue = selectedGoalOption.goalPercentage!
                }
                FymUser.sharedFymUser.userGoalOptionId = selectedGoalOption.goalOptionId!
                textFieldOption?.text = selectedGoalOption.goalOptionName
            }
            
        case .Activity:
            selectedActivity = arrayPickerActivityLevels[picker.selectedRowInComponent(0)]
            
            // if user chooses new item and pressed done button without clicking on picker
            if FymUser.sharedFymUser.userActivityLevelId != selectedActivity.activityId! {
                
                // alert message to save data
                ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
            }
            
            FymUser.sharedFymUser.userActivityLevelId = selectedActivity.activityId!
            textFieldActivityLevel?.text = selectedActivity.activityName
            labelActivityDescription?.text = selectedActivity.activityDescription!
        }
        
        selectedTextFieldPicker?.resignFirstResponder()
        selectedTextFieldPicker?.inputView = nil
        selectedTextFieldPicker?.inputAccessoryView = nil
        if pickerMode == .Activity {
            // manageGoalsTableView.beginUpdates()
            //            manageGoalsTableView.reloadRowsAtIndexPaths([NSIndexPath(forRow: 0, inSection: 2)], withRowAnimation: UITableViewRowAnimation.None)
            // manageGoalsTableView.reloadSections(NSIndexSet(indexesInRange: NSMakeRange(2, 3)), withRowAnimation: UITableViewRowAnimation.None)
            //            manageGoalsTableView.reloadSections(NSIndexSet(indexesInRange: NSMakeRange(2, 1)), withRowAnimation: UITableViewRowAnimation.None)
            //            manageGoalsTableView.reloadSections(NSIndexSet(indexesInRange: NSMakeRange(0, 4)), withRowAnimation: UITableViewRowAnimation.None)
            //manageGoalsTableView.reloadSections(NSIndexSet(indexesInRange: NSMakeRange(0, 2)), withRowAnimation: UITableViewRowAnimation.None)
            //manageGoalsTableView.endUpdates()
            manageGoalsTableView.reloadData()
        }
    }
    
    @IBAction func unwindToManageGoalsListViewController(segue: UIStoryboardSegue) {
        
        // reload nutrition plan row
        let rowToReload = NSIndexPath(forRow: 0, inSection: 3)
        let rowsToReload = [rowToReload]
        manageGoalsTableView.reloadRowsAtIndexPaths(rowsToReload, withRowAnimation: UITableViewRowAnimation.None)
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        //print("string ---\(string)")
        // managing the textfield input: limit the characters to only of numeric type
        
        if string == " " {
            return false
        }
        
        if string.isEmpty {
            return true
        }
        
        var isValid = true
        let text = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        
        // check for unwanted characters
        let replacementStringIsLegal = string.rangeOfCharacterFromSet(NSCharacterSet(charactersInString: "0123456789.").invertedSet) == nil
        
        
        if textField.tag == 120 {
            
            // check for string count
            let resultingStringLengthIsLegal = text.characters.count <= 5
            
            // check if the number is valid
            let scanner = NSScanner(string: text)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
            
            let isLowNumber = text.doubleValue <= 100
            
            isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber
            
        }
        
        return isValid
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        if(alertView.tag == 1) {
            
            if alertView.buttonTitleAtIndex(buttonIndex) == &&"ok" {
                
                let reachability = appDelegate!.internetReachable
                if !reachability {
                    // no internet
                    
                    // alert
                    AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                    return
                }
                
                ManageGoalsUpdateUserResponse.manageGoalsUpdateUser { (completed) -> () in
                    
                    if completed {
                        //navigate to progressview controller
                        self.navigationController?.popViewControllerAnimated(true)
                        
                    } else {
                        //print("failed")
                    }
                }
            }
            else {
                
                // pop view controller
                self.navigationController?.popViewControllerAnimated(true)
            }
        } else if alertView.tag == 2{
            
            if alertView.buttonTitleAtIndex(buttonIndex) == &&"ok" {
                firstCell!.imageViewtickGreen.hidden = true
                secondCell!.imageViewtickGreen.hidden = false
                FymUser.sharedFymUser.userFatLoss = alertView.textFieldAtIndex(0)!.text!
                ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
                FymUser.sharedFymUser.formulaType = cellFormulaConstants.leanMass
            }
            else {
                
                // pop view controller
            }
            
        }
    }
    
    func numberOfMeals(cell: NumberOfMealsCell) {
        numberOfMealsField = cell.textFieldNumberOfMeals
    }
    
    @IBAction func buttonActionSave(sender: AnyObject) {
        
        textFieldOption?.resignFirstResponder()
        // resign number of meals textfield if active
        numberOfMealsField.resignFirstResponder()
        
        // custom goal
        if FymUser.sharedFymUser.userSelectedGoal?.goalId == "4" {
            if  FymUser.sharedFymUser.userCustomCalorie <= 0.0 {
                showAlert(&&"notice", message: &&"calorie_empty_message")
                return
            }
        }
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        ManageGoalsUpdateUserResponse.manageGoalsUpdateUser { (completed) -> () in
            
            if completed {
                
                //navigate to progressview controller
                //self.navigationController?.popViewControllerAnimated(true)
                
                ManageGoalsAlert.sharedManageGoalsAlert.showAlert = false
                
            } else {
                //print("failed")
            }
        }
    }
    
    func showAlert(title: String, message: String) {
        
        UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"OK").show()
        
    }
    
    
    @IBAction func backButtonClicked(sender: AnyObject) {
        textFieldOption?.resignFirstResponder()
        numberOfMealsField.resignFirstResponder()
        
        // custom goal
        if FymUser.sharedFymUser.userSelectedGoal?.goalId == "4" {
            if FymUser.sharedFymUser.userCustomCalorie <= 0.0 {
                showAlert(&&"notice", message: &&"calorie_empty_message")
                return
            }
        }
        
        if ManageGoalsAlert.sharedManageGoalsAlert.showAlert {
            if #available(iOS 8.0, *) {
                
                let alertView = UIAlertController(title: &&"notice",
                    message: &&"manage_save_changes", preferredStyle: .Alert)
                alertView.addAction(UIAlertAction(title: &&"cancel", style: .Cancel){ action -> Void in
                    
                    // pop view controller
                    self.navigationController?.popViewControllerAnimated(true)
                    })
                alertView.addAction(UIAlertAction(title: &&"ok", style: .Default){ action -> Void in
                    
                    let reachability = self.appDelegate!.internetReachable
                    if !reachability {
                        // no internet
                        
                        // alert
                        AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                        return
                    }
                    
                    ManageGoalsUpdateUserResponse.manageGoalsUpdateUser { (completed) -> () in
                        
                        if completed {
                            //navigate to progressview controller
                            self.navigationController?.popViewControllerAnimated(true)
                            
                        } else {
                            //print("failed")
                        }
                    }
                    
                    })
                presentViewController(alertView, animated: true, completion: nil)
                
                
            } else {
                // Fallback on earlier versions
                
                let alert = UIAlertView(title: &&"notice", message:  &&"manage_save_changes", delegate: self, cancelButtonTitle:  &&"cancel", otherButtonTitles: &&"ok")
                alert.tag = 1
                alert.show()
            }
        }
        else {
            self.navigationController?.popViewControllerAnimated(true)
        }
        
    }
    
}
