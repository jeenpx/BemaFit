//
//  EmailManager1.swift
//  FlexYourMacros
//
//  Created by DBG on 29/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import MessageUI


typealias onMailFinished = (controller: MFMailComposeViewController, result: MFMailComposeResult, error: NSError?) -> ()

class EmailManager :NSObject, MFMailComposeViewControllerDelegate {
    
    var finishBlock: onMailFinished?
    
    class var sharedInstance: EmailManager {
        struct Static {
            static let instance = EmailManager()
        }
        return Static.instance
    }
    //sending email
    private func sendMail(attachmentName : String,fileName : String, mailSubject : String = "Daily-Meal-Plan", mailContent : String = "Hey ,Checkout my daily meal plan.", vController:UIViewController, withCompletionblock  finishBlock:onMailFinished) {
        
        self.finishBlock = finishBlock
        
        let nsDocumentDirectory = NSSearchPathDirectory.DocumentDirectory
        let nsUserDomainMask = NSSearchPathDomainMask.UserDomainMask
        let arrayPaths:NSArray = NSSearchPathForDirectoriesInDomains(nsDocumentDirectory,nsUserDomainMask, true)
        let path:NSString = arrayPaths.objectAtIndex(0) as! NSString
        let pdfFileName = path.stringByAppendingPathComponent(fileName as String)
        let fileData = NSData(contentsOfFile: pdfFileName)
        let picker = MFMailComposeViewController()
        picker.mailComposeDelegate = self
        picker.setSubject(mailSubject)
        picker.setMessageBody(mailContent, isHTML: false)
        picker.addAttachmentData(fileData!, mimeType:"application/pdf",fileName:attachmentName)
        vController.presentViewController(picker, animated: true, completion: nil)
    }
    
    
    
    
    class func send1Mail(attachmentName : String,fileName : String, mailSubject : String = "Daily-Meal-Plan", mailContent : String = "Hey ,Checkout my daily meal plan.", vController:UIViewController, withCompletionblock  finishBlock:onMailFinished){
        EmailManager.sharedInstance.sendMail(attachmentName, fileName: fileName, mailSubject: mailSubject, mailContent: mailContent, vController: vController, withCompletionblock: finishBlock)
    }
    
    func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        self.finishBlock?(controller: controller, result: result, error: error)
        controller.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    
}