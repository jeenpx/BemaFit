//
//  SendDetailsViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 08/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class User: Equatable, Hashable {
    
    var userId = ""
    var userName = ""
    var firstName = ""
    var lastName = ""
    var following = ""
    var followers = ""
    var profilePhoto = ""
    var type = ""
    
    // hashable
    var hashValue: Int {
        return userId.hashValue
    }
    
    init(userName: String = "", firstName: String = "", lastName: String = "") {
        self.userName = userName
        self.firstName = firstName
        self.lastName = lastName
    }
    
    init(friendModel: FriendModel) {
        userId = friendModel.user_id ?? ""
        userName = friendModel.userName ?? ""
        firstName = friendModel.firstName ?? ""
        lastName = friendModel.lastName ?? ""
        following = friendModel.following ?? ""
        followers = friendModel.followers ?? ""
        profilePhoto = friendModel.profilePhoto ?? ""
        type = friendModel.type ?? ""
    }
    
    init(userModel: UserDetailModel) {
        userId = userModel.userId ?? ""
        userName = userModel.userUserName ?? ""
        firstName = userModel.userFirstName ?? ""
        lastName = userModel.userLastName ?? ""
        following = userModel.following ?? ""
        followers = userModel.followers ?? ""
        profilePhoto = (userModel.userProfilePhoto ?? "") as String
        type = userModel.userType ?? ""
    }
    
    class func fetchAllFriends(excludeRequests: Bool = false, offset: Int = 0, completionHandler: (friends:[User]) -> ()) {
        
        GetFriendsResponse.getFriendsList(offset, excludeRequests: excludeRequests,  andLimit: 30, keywords: "") { (getFriendsResponse) -> () in
            
            let users = getFriendsResponse.friends?.map { User(friendModel: $0) }
            completionHandler(friends: users!)
        }
    }
}

func ==(lhs: User, rhs: User) -> Bool {
    return (lhs.userId == rhs.userId)
}

protocol SendDetailsCellDelegate {
    func sendDetailsCell(sendDetailsCell: SendDetailsCell, didSelectUser user: User)
    func sendDetailsCell(sendDetailsCell: SendDetailsCell, didDeselectUser user: User)
}



typealias SelectedFriends = (friendids:[String])->()
class SendDetailsCell: UITableViewCell {
    
    @IBOutlet weak var labelUserName: UILabel!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var imageViewProfilePic: UIImageView!
    @IBOutlet weak var buttonSelect: UIButton!
    @IBOutlet weak var kImageWidth: NSLayoutConstraint!
    
    @IBOutlet weak var kImageHeight: NSLayoutConstraint!
    var sendDetailsCellDelegate: SendDetailsCellDelegate?

    var isUserSelected: Bool {
        get {
            return buttonSelect?.selected ?? false
        }
        set {
            buttonSelect?.selected = isUserSelected
        }
    }
    
    var user = User() {
        didSet {
            configureView()
        }
    }
    
    func configureView() {
        labelUserName.text = user.userName
        labelName.text = "\(user.firstName) \(user.lastName)"
        
        imageViewProfilePic.setImageWithURL(NSURL(string: user.profilePhoto))
        
        gestureRecognizers = [UITapGestureRecognizer(target: self, action: "toggleSelection:")]
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // set corner radius to make a round profile pic
        imageViewProfilePic?.layer.cornerRadius = CGRectGetWidth(imageViewProfilePic.frame) / 2
        imageViewProfilePic?.clipsToBounds = true
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        imageViewProfilePic.image = nil
    }
    
    @IBAction func buttonActionSelect(sender: UIButton) {
        toggleSelection(nil)
    }
    
    func toggleSelection(sender: UITapGestureRecognizer?) {
        buttonSelect.selected = !buttonSelect.selected
        
        if isUserSelected {
            sendDetailsCellDelegate?.sendDetailsCell(self, didSelectUser: user)
        }
        else {
            sendDetailsCellDelegate?.sendDetailsCell(self, didDeselectUser: user)
        }
    }
}

enum SendDetailsViewMode {
    case FoodDetail
    case ExerciseDetail
    case SplitFood
    case ShareDailyMeal
    
}

class SendDetailsViewController: UITableViewController, SendDetailsCellDelegate, UIAlertViewDelegate, UITableViewDragLoadDelegate {
    
    // to avoid the empty message first time
    var avoidEmptyMessage = true
    
    // can be food or exercise detail screen
    var sendDetailsViewMode: SendDetailsViewMode = .FoodDetail
    
    // detail data to send
    var exercise: Exercise?
    var food: Food?
    
    // entire table data
    var tableData = [User]()
    
    // selected users
    var selectedUsers = [User]()
    
    var shouldSelectMealType = false
    var selectedFriends:SelectedFriends?
    var isFromDashboard = true
    
    var logDate = NSDate()
    var dailyMealPlanFoodId:String?
    struct StoryBoard {
        struct CellIdentifiers {
            static let SendDetailsCell = "kSendDetailsCell"
        }
        struct Segues {
            static let SplitFood    = "kSplitFoodSegue"
            static let MealType     = "kMealTypeSegue"
            static let DashBoard    = "kUnwindDashboard"
            static let ViewLog      = "kUnwindViewLog"
            static let AddFriends   = "kShareAddFriend"
            static let LogFood      = "kLogFoodMealType"
            
        }
        struct AlertActions {
            static let SendOnly = 0
            static let LogAndSend = 1
            static let AddFriends = 0
            static let LogOnly = 1
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        


        // set view title and right navigation button
        switch sendDetailsViewMode {
        case .FoodDetail:
            title = &&"send_food_details"
            navigationItem.rightBarButtonItem?.title = nil
            navigationItem.rightBarButtonItem?.image = UIImage(named: "RightArrowIcon")
            
            navigationItem.rightBarButtonItem?.tintColor = UIColor.whiteColor()
        case .ExerciseDetail:
            title = &&"send_exercise_details"
            navigationItem.rightBarButtonItem?.tintColor = UIColor.whiteColor()
        case .ShareDailyMeal:
            title = &&"send_meal_plan"
            navigationItem.rightBarButtonItem?.title = "Send"
            navigationItem.rightBarButtonItem?.image = nil
            navigationItem.rightBarButtonItem?.tintColor = UIColor.defaultThemeBlueColor()
        case .SplitFood:
            title = &&"split_food"
            navigationItem.rightBarButtonItem?.title = nil
            navigationItem.rightBarButtonItem?.image = UIImage(named: "RightArrowIcon")
            navigationItem.rightBarButtonItem?.tintColor = UIColor.whiteColor()
        }
        
        configureTableView()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        // fetch users
        fetchUsers()
        // set table row height
        tableView.estimatedRowHeight = 70.0
    }
    
    func fetchUsers() {
        User.fetchAllFriends(true, offset: tableData.count) { (friends) -> () in
            self.avoidEmptyMessage = false
            
            if self.tableData.isEmpty {
                self.tableData = friends
            } else {
                self.tableData += friends
                self.tableView.finishLoadMore()
            }
            self.tableView.reloadData()
        }
    }
    
    var offSet: Int {
        return tableData.isEmpty ? 0 : tableData.count
    }
    
    func configureTableView() {
        
        // hide empty tableview cells
        tableView.tableFooterView = UIView(frame: CGRectZero)
        
        // set delegate for pull to refresh and load more
        tableView.setDragDelegate(self, refreshDatePermanentKey: "kFriends")
        
        // hide pull to refresh
        tableView.showRefreshView = false
        
        // show load more
        tableView.showLoadMoreView = true
        
        // tableview footer release text
        tableView.footerReleaseText = NSLocalizedString("release_to_load_more_status", comment: "")
        
        // tableview footer pull up text
        tableView.footerPullUpText = NSLocalizedString("pull_down_to_load_more_status", comment: "")
        
        //tableview footer loading text
        tableView.footerLoadingText = NSLocalizedString("loading_status", comment: "")
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return the number of rows in the section.
        
        if tableData.count == 0 && !avoidEmptyMessage {
            
            // show empty record message
            tableView.showEmptyTableViewMessage()
            
            let alert = UIAlertView(title: &&"notice", message: &&"alert_no_friends_yet", delegate: self, cancelButtonTitle: &&"add", otherButtonTitles: &&"log_only")
            alert.tag = 150
            alert.show()
            
        }
        else {
            tableView.backgroundView = UIView()
            tableView.separatorStyle = .SingleLine
        }
        
        return tableData.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.SendDetailsCell, forIndexPath: indexPath) as! SendDetailsCell
        cell.sendDetailsCellDelegate = self
        cell.user = tableData[indexPath.row]
        cell.isUserSelected = selectedUsers.contains(cell.user)
        return cell
    }
    
    func dragTableDidTriggerLoadMore(tableView: UITableView!) {
        // called when the load more is selected
        fetchUsers()
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        if buttonIndex == StoryBoard.AlertActions.SendOnly {
            //print("sent only")
        }
        else if buttonIndex == StoryBoard.AlertActions.LogAndSend {
            //print("log and send")
        }
        
        if alertView.tag == 150 {
            
            if buttonIndex == 0 {
                performSegueWithIdentifier(StoryBoard.Segues.AddFriends, sender: self)
            } else if buttonIndex == 1 {
                
                // set view title and right navigation button
                switch sendDetailsViewMode {
                case .FoodDetail:
                    performSegueWithIdentifier(StoryBoard.Segues.LogFood, sender: food)
                case .ExerciseDetail:
                    logExercise()
                case .ShareDailyMeal:
                    shareDailyMealPlan()
                case .SplitFood:
                    performSegueWithIdentifier(StoryBoard.Segues.LogFood, sender: food)
                }
                
            }
            
        }
    }
    
    func shareDailyMealPlan() -> () {
        
        let friendsIDs = selectedUsers.map{$0.userId}
        //print("Selected friends are \(friendsIDs) and food id is \(self.dailyMealPlanFoodId)")
        self.selectedFriends?(friendids: friendsIDs)
        self.navigationController?.popViewControllerAnimated(false)
        
        //        DailyMealPlanShare.shareDialyMealPlan(self.dailyMealPlanFoodId!, friendsID: friendsIDs);
        
    }
    
    
    func sendDetailsCell(sendDetailsCell: SendDetailsCell, didSelectUser user: User) {
        selectedUsers.append(user)
    }
    
    func sendDetailsCell(sendDetailsCell: SendDetailsCell, didDeselectUser user: User) {
        selectedUsers.remove(user)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == StoryBoard.Segues.SplitFood {
            let splitFoodViewController = segue.destinationViewController as! SplitFoodViewController
            splitFoodViewController.selectedUsers = selectedUsers
            splitFoodViewController.isFromDashboard = isFromDashboard
            splitFoodViewController.logDate = logDate
            if let food = food {
                splitFoodViewController.food = food
            }
            self.tableData.removeAll()
        }
        else if segue.identifier == StoryBoard.Segues.MealType {
            let mealTypeListViewController = segue.destinationViewController as! MealTypeListViewController
            if let food = food { mealTypeListViewController.food = food }
            mealTypeListViewController.selectedUsers = selectedUsers
            mealTypeListViewController.mealTypeListInitiator = .SendDetails
            mealTypeListViewController.logDate = logDate
            self.tableData.removeAll()
        }else if segue.identifier == StoryBoard.Segues.LogFood {
            let mealTypeListViewController = segue.destinationViewController as! MealTypeListViewController
            mealTypeListViewController.logDate = logDate
            mealTypeListViewController.food = sender as! Food
        }
    }
    
    @IBAction func barButtonActionSend(sender: UIBarButtonItem) {
        
        if tableData.count == 0 {
            
            let alert = UIAlertView(title: &&"notice", message: &&"alert_no_friends_yet", delegate: self, cancelButtonTitle: &&"add", otherButtonTitles: &&"log_only")
            alert.tag = 150
            alert.show()
            
            // abort
            return
        }
        
        if selectedUsers.count < 1 {
            
            let alert = UIAlertView(title: &&"error", message: &&"please_select_a_friend", delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok")
            alert.show()
            
            // abort
            return
        }
        
        // show split food screen for splitfood mode
        if sendDetailsViewMode == .SplitFood {
            performSegueWithIdentifier(StoryBoard.Segues.SplitFood, sender: self)
        }
        else if sendDetailsViewMode == .FoodDetail {
            performSegueWithIdentifier(StoryBoard.Segues.MealType, sender: self)
        }
        else if sendDetailsViewMode == .ExerciseDetail {
            //print("Exercise detail")
            sendExerciseDetailsToFriend()
        }
            
        else if sendDetailsViewMode == .ShareDailyMeal {
            //print("Share Daily Meal Plan")
            shareDailyMealPlan()
        }
    }
    
    func logExercise() {
        
        var logExercises = [LogExercise]()
        if exercise!.exerciseType == ExerciseType.CardioVascular {
            logExercises.append(LogExercise(cardioVascularExercise: exercise as! CardioVascularExercise))
            
        } else {
            logExercises.append(LogExercise(strengthExercise: exercise as! StrengthExercise))
            
        }
        
        var userExercises = [UserExercise]()
        userExercises.append(UserExercise(userID: AppConfiguration.sharedAppConfiguration.userDetails!.userId!, exerciseDetails: logExercises))
        
        let exerciseModel = ExerciseLogModel(logType: "Log", exerciseType: exercise!.exerciseType == ExerciseType.CardioVascular ? ExerciseTypeId.CardioVascular.rawValue : ExerciseTypeId.Strength.rawValue, exerciseDate: logDate.stringValue("yyyy-MM-dd"))
        exerciseModel.users = userExercises
        
        //print("exerciselog-----\(exerciseModel.toJsonString())")
        
        ExerciseLogModel.logExercise(exerciseModel, completionHandler: { (successful, messsage) -> () in
            if successful {
                
                // load view log
                self.loadViewLog()
                
            } else {
                
                //print("failed logged")
                
            }
        })
    }
    
    func sendExerciseDetailsToFriend() {
        
        var logExercises = [LogExercise]()
        
        if exercise!.exerciseType == ExerciseType.CardioVascular {
            logExercises.append(LogExercise(cardioVascularExercise: exercise as! CardioVascularExercise))
            
        } else {
            logExercises.append(LogExercise(strengthExercise: exercise as! StrengthExercise))
            
        }
        
        var userExercises = [UserExercise]()
        userExercises = selectedUsers.map {
            return UserExercise(userID: $0.userId, exerciseDetails: logExercises)
        }
        
        userExercises.append(UserExercise(userID: AppConfiguration.sharedAppConfiguration.userDetails!.userId!, exerciseDetails: logExercises))
        
        let exerciseModel = ExerciseLogModel(logType: "Send", exerciseType: exercise!.exerciseTypeId == ExerciseTypeId.CardioVascular ? ExerciseTypeId.CardioVascular.rawValue : ExerciseTypeId.Strength.rawValue, exerciseDate: logDate.stringValue("yyyy-MM-dd"))
        
        exerciseModel.users = userExercises
        
        //print("exerciselog-----\(exerciseModel.toJsonString())")
        
        ExerciseLogModel.sendExercise(exerciseModel, completionHandler: { (successful, messsage) -> () in
            if successful {
                
                // load view log
                self.loadViewLog()
                
            } else {
                
                //print("failed sending")
                
            }
        })
    }
    
    class func viewController() -> (SendDetailsViewController) {
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewControllerWithIdentifier("sendDetailsViewController") as! SendDetailsViewController
        
        return viewController
        
        
    }
    class func shareDailyMealPlan(dailyMealPlanId : String, fromViewController : UIViewController)
    {
        let sendDetailsViewController  = SendDetailsViewController.viewController() as SendDetailsViewController
        sendDetailsViewController.sendDetailsViewMode = SendDetailsViewMode.ShareDailyMeal
        sendDetailsViewController.selectedFriends = { friends in
            
            
            
            DailyMealPlanShare.shareDialyMealPlan(dailyMealPlanId, friendsID: friends, withBlock: { (error) -> () in
                
                if (error != nil){
                    
                    
                    UIAlertView(title: &&"message_failed", message: &&"message_failed_general", delegate: nil, cancelButtonTitle: "Ok").show()
                    
                }
                else{
                    UIAlertView(title: &&"message_success", message: &&"daily_meal_plan_whole_share", delegate: nil, cancelButtonTitle: "Ok").show()
                
                }
                
            })
        }
        
        fromViewController.navigationController?.pushViewController(sendDetailsViewController, animated: true)
        

    }
    
}
