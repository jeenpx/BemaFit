//
//  NSString.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 27/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

// MARK: Localization
prefix operator && {}

prefix func && (string: String) -> String {
    return NSLocalizedString(string, comment: "")
}

// MARK: Filtering
extension String {
    
    func filterWordsWithPrefix(prefix: String, shouldStripPrefix: Bool) -> [String] {
        
        // the regular expression to filter out words
        let regularExpression = try! NSRegularExpression(pattern: "\(prefix)(\\w+)", options: .CaseInsensitive)
        
        // filter out results using the regular expression
        let arrayMatches = regularExpression.matchesInString(self, options: .WithTransparentBounds, range: NSMakeRange(0, self.characters.count))
        
        // return words from results
        return arrayMatches.map() {
            (self as NSString).substringWithRange($0.rangeAtIndex(shouldStripPrefix ? 1 : 0))
        }
    }
    
    func filterHashTags() -> [String] {
        return filterWordsWithPrefix("#", shouldStripPrefix: false)
    }
    
    func contains(find: String) -> Bool {
        return self.rangeOfString(find, options: NSStringCompareOptions.CaseInsensitiveSearch) != nil
    }
    
    func trimmedString() -> String {
        
        // trim white spaces and new lines
        var trimmedText = stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        
        // remove new lines throughout the text
        trimmedText = trimmedText.stringByReplacingOccurrencesOfString("\n", withString: "")
        
        return trimmedText
    }
    
    var isEmpty: Bool {
        return self.trimmedString().characters.count <= 0
    }
    
}

//MARK: Email
extension String{
    func isValidEmail() -> Bool {
        // //println("validate calendar: \(testStr)")
        let emailRegEx = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluateWithObject(self)
    }
    
}

// MARK: Date
extension String {
    
    // dateFormat has precedence over dateStyle
    // date style defaults to LongStyle
    func dateValue(dateFormat: String? = nil, dateStyle: NSDateFormatterStyle? = nil) -> NSDate? {
        
        // get a date formatter
        let dateFormatter = NSDateFormatter()
        
        // set appropriate date styles/formats
        if let dateFormat = dateFormat {
            dateFormatter.dateFormat = dateFormat
        }
        else if let dateStyle = dateStyle {
            dateFormatter.dateStyle = dateStyle
        }
        else {
            dateFormatter.dateStyle = NSDateFormatterStyle.LongStyle
        }
        
        // return the date after formatting
        return dateFormatter.dateFromString(self)
    }
    
    func utcDateValue(dateFormat: String? = nil, dateStyle: NSDateFormatterStyle? = nil) -> NSDate? {
        
        // get a date formatter
        let dateFormatter = NSDateFormatter()
        
        // set appropriate date styles/formats
        if let dateFormat = dateFormat {
            dateFormatter.dateFormat = dateFormat
        }
        else if let dateStyle = dateStyle {
            dateFormatter.dateStyle = dateStyle
        }
        else {
            dateFormatter.dateStyle = NSDateFormatterStyle.LongStyle
        }
        
        // set gmt 0
        dateFormatter.timeZone = NSTimeZone(forSecondsFromGMT: 0)
        
        // return the date after formatting
        return dateFormatter.dateFromString(self)
    }
    
    func  websiteString() ->  (valid: Bool, urlString: String){
        
        var isValid = false //urlTestWithPrefix.evaluateWithObject(self)
        var urlString = self
        
        
        if self.lowercaseString.rangeOfString("https://") == nil {
            
            urlString = (self.lowercaseString.rangeOfString("http://") == nil) ? "http://"+self : self
        }
        
        
        let urlRegEx = "^^(http|https)://((?!-)[A-Za-z0-9-]{1,63}(?<!-)\\.)+[A-Za-z]{2,6}$"
        let urlTest = NSPredicate(format: "SELF MATCHES %@",urlRegEx)
        isValid = urlTest.evaluateWithObject(urlString)
        
        return (isValid, urlString)
    }
    
}

extension String {
    
    var FloatValue: Double {
        
        return round(self.doubleValue * 100) / 100
        //        return (self as NSString).floatValue
        //        return round ((self as NSString).floatValue * 100.0) / 100.0
    }
    
    var intValue: Int {
        return (self as NSString).integerValue
    }
    
    var doubleValue: Double {
        return (self as NSString).doubleValue
    }
    
    var singleDecimalValue: String {
        return NSString(format: "%.1f", (self as NSString).floatValue) as String
    }
    
}

// dynamic height
extension String {
    
    func expectedHeight(width: Double, font: UIFont) -> Double {
        return Double((self as NSString).boundingRectWithSize(CGSizeMake(CGFloat(width), 9999.0), options: .UsesLineFragmentOrigin, attributes: [NSFontAttributeName: font], context: nil).height)
    }
    
    func expectedNumberOfLines(width: Double, font: UIFont) -> Int {
        
        //print("lien \(font.lineHeight)")
        return Int(expectedHeight(width, font: font) / Double(font.lineHeight))
    }
    
}

// truncate string
extension String {
    /// Truncates the string to length number of characters and
    /// appends optional trailing string if longer
    func truncate(length: Int, trailing: String? = nil) -> String {
        if self.characters.count > length {
            return self.substringToIndex(self.startIndex.advancedBy(length)) + (trailing ?? "")
        } else {
            return self
        }
    }
}

// Unique ID Generation
extension String{
    
    static func generateUniqueID (len : Int) -> NSString {
        
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        
        var randomString : NSMutableString = NSMutableString(capacity: len)
        
        for (var i=0; i < len; i++){
            var length = UInt32 (letters.length)
            var rand = arc4random_uniform(length)
            randomString.appendFormat("%C", letters.characterAtIndex(Int(rand)))
        }
        
        return randomString
    }
    
    
}

