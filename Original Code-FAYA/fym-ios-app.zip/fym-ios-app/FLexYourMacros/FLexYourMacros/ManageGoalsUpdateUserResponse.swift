//
//  ManageGoalsUpdateUserModel.swift
//  FlexYourMacros
//
//  Created by dbgattila on 6/11/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ManageGoalsUpdateUserResponse: NSObject {
    
    // model instances
    var userDetailModel: UserDetailModel?
    var userDietModel: UserDietModel?
    var metaModel: MetaModel?
    
    // route instances
    var user_id = ""
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(ManageGoalsUpdateUserResponse.metaModelKeyMapping)
        
        // give reference to diet mapping
        responseMapping.addPropertyMapping(ManageGoalsUpdateUserResponse.userDietModelKeyMapping)
        
        // give reference to user credential mapping
        responseMapping.addPropertyMapping(ManageGoalsUpdateUserResponse.userDetailModelKeyMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .PUT, pathPattern: Constants.ServiceConstants.kManageGoalsUpdateUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var userDetailModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDetail, toKeyPath: "userDetailModel", withMapping: UserDetailModel.objectMapping)
    }
    
    private class var userDietModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserDiet, toKeyPath: "userDietModel", withMapping: UserDietModel.objectMapping)
    }
    
    
    class var parameterDictionary: [String:String] {
        
        let fymUserModel = FymUser.sharedFymUser
        var dictionary = [String:String]()
        let userDetails = AppConfiguration.sharedAppConfiguration.userDetails!
        dictionary["first_name"] = userDetails.userFirstName ?? ""//fymUserModel.userFirstName
        dictionary["last_name"] = userDetails.userLastName ?? "" //fymUserModel.userLastName
        dictionary["email"] = userDetails.userEmail ?? ""//fymUserModel.userEmail
        dictionary["website"] = userDetails.userWebsite ?? ""//fymUserModel.userWebsite
        dictionary["gender"] = userDetails.userGender ?? ""//fymUserModel.userGender
        dictionary["dob"] = userDetails.userDob ?? ""//fymUserModel.userDobString
        dictionary["facebook_id"] = userDetails.userFacebookId ?? ""//AppConfiguration.sharedAppConfiguration.isFacebookUser == true ? UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserId : ""
        dictionary["height"] = fymUserModel.userHeightinCm
        dictionary["weight"] = fymUserModel.userWeight
        dictionary["fat"] = fymUserModel.userFatLoss
        dictionary["diet_activity_level"] = fymUserModel.userActivityLevelId
        dictionary["diet_goal_calories"] = String(format: "%.2f", fymUserModel.getTheSelectedGoalCalorie()) as String
        dictionary["diet_nutritional_plan"] = fymUserModel.userNutritionType
        dictionary["diet_formula"] = fymUserModel.formulaType
        dictionary["diet_calory_type"] = fymUserModel.userSelectedGoal?.goalId == "4" ? "custom" : "calculated"
        dictionary["diet_goal_option"] = fymUserModel.userGoalOptionId
        dictionary["diet_macro_type"] = fymUserModel.userNutritionType == "5" ? "custom" : "calculated"
        dictionary["diet_macro_fiber"] = getTheOptimizedString(fymUserModel.userFiberValue)
        dictionary["diet_macro_fat"] = String(stringInterpolationSegment: fymUserModel.calculateUserMacros().fatValue)//getTheOptimizedString(fymUserModel.userFat)
        dictionary["diet_macro_carbs"] = String(stringInterpolationSegment: fymUserModel.calculateUserMacros().carbsValue)//getTheOptimizedString(fymUserModel.userCarbs)
        dictionary["diet_macro_protein"] = String(stringInterpolationSegment: fymUserModel.calculateUserMacros().proteinValue)//getTheOptimizedString(fymUserModel.userProtein)
        dictionary["no_of_meals"] = String(fymUserModel.userNumberOfMeals)
        return dictionary
    }
    
    class func getTheOptimizedString(objectString: String) -> (String) {
        
        return objectString.stringByReplacingOccurrencesOfString("g", withString: "", options: NSStringCompareOptions.LiteralSearch, range: nil) as String
    }
    
    class func manageGoalsUpdateUser(completionHandler: (completed: Bool) -> ()) {
        
        SVProgressHUD.show()
        RestKitManager.setToken(true)
        
        var paramdictionary = parameterDictionary
        
        let manageGoalsUpdateUserResponse = ManageGoalsUpdateUserResponse()
        if let userId = AppConfiguration.sharedAppConfiguration.userDetails?.userId {
            manageGoalsUpdateUserResponse.user_id = userId
        }
        
        var err: NSError?
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(manageGoalsUpdateUserResponse, method: .PUT, path: nil, parameters: nil, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
        
        do {
            request.HTTPBody =  try NSJSONSerialization.dataWithJSONObject(paramdictionary, options: [])
        } catch var error as NSError {
            err = error
            request.HTTPBody = nil
        }
        
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            //print("success")
            let response = mappingResult.firstObject as! ManageGoalsUpdateUserResponse
            //print("respone code :\(response.metaModel?.responseCode)")
            //print("respone status :\(response.metaModel?.responseStatus)")
            if response.metaModel?.responseCode != 200 {
                SVProgressHUD.dismiss()
                completionHandler(completed: false)
                return
            }
            
            AppConfiguration.sharedAppConfiguration.userDetails = response.userDetailModel
            AppConfiguration.sharedAppConfiguration.userDiet = response.userDietModel
            
            SVProgressHUD.dismiss()
            completionHandler(completed: true)
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                SVProgressHUD.dismiss()
                completionHandler(completed: false)

                //print("failed to update user with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
    
    
}
