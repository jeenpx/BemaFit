//
//  MotivateResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 09/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class MotivateResponse: NSObject {    
    var user_id = ""
    var feed_id = ""
    var metaModel = MetaModel()

    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
        responseMapping.addPropertyMapping(metaModelMapping)
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let motivateResponseDescriptor = RKResponseDescriptor(mapping: MotivateResponse.responseMapping, method: .Any, pathPattern: Constants.ServiceConstants.motivateUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return motivateResponseDescriptor
    }
    
    class func updateLikeInspire(params: [String: String], feedId : String, completionHandler: (error: NSError?)-> ()) {
        
        RestKitManager.setToken(true)
        
        let motivateResponse = MotivateResponse()
        motivateResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails!.userId!
        motivateResponse.feed_id = feedId
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(motivateResponse, method: .POST, path: nil, parameters: params, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let response = mappingResult.firstObject as! MotivateResponse
            if response.metaModel.responseCode != 200 {
                //print("XXX failed to update")
                completionHandler(error: NSError(domain: "FYM.status", code: 99, userInfo: ["description": "Failed to update status"]))
            } else {
                 completionHandler(error: nil)
            }
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                completionHandler(error: error)
                //print("failed to load with error \(error)")
        })
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
}
