//
//  BarcodeScannerView.swift
//  BarcodeMainPjt
//
//  Created by Deepu S Nath on 24/02/15.
//  Copyright (c) 2015 DBG. All rights reserved.
//

import Foundation
import AVFoundation
import UIKit

class Barcode: NSObject {
    
    var barcodeType: String? {
        return metaData?.type
    }
    var barcodeData: String? {
        return metaData?.stringValue
    }
    var metaData: AVMetadataMachineReadableCodeObject? = nil
    
    convenience init(metaData: AVMetadataMachineReadableCodeObject) {
        self.init()
        
        self.metaData = metaData
    }
}

class BarcodeScannerView: UIView, AVCaptureMetadataOutputObjectsDelegate, UITableViewDelegate {
    
    // call back for barcode
    var barcodeCallback:((barcodeScannerView: BarcodeScannerView, barcode: Barcode?) -> ())?
    
    let buttonSubmit = UIButton()
    let imageViewScanIcon = UIImageView()
    
    var barcode: Barcode?
    
    // boolean to check whether barcode scanned or not
    var isBarCodeScanned = false
    
    var mCaptureSession: AVCaptureSession!
    
    // barcode types for barcode scanning
    let barCodeTypes = [AVMetadataObjectTypeUPCECode,
        AVMetadataObjectTypeCode39Code,
        AVMetadataObjectTypeCode39Mod43Code,
        AVMetadataObjectTypeEAN13Code,
        AVMetadataObjectTypeEAN8Code,
        AVMetadataObjectTypeCode93Code,
        AVMetadataObjectTypeCode128Code,
        AVMetadataObjectTypePDF417Code,
        AVMetadataObjectTypeAztecCode
    ]
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        
    }
    
    func showAlert(title: String, message: String) {
        // show alert controller if possible else show alert view
        UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"OK").show()
     
    }
    
    func startScan() {
        // start barcode scanning
        
        mCaptureSession.startRunning()
    }
    
    func stopScan() {
        // stop barcode scanning
        
        buttonSubmit.setBackgroundImage(UIImage(named: "SubmitButton") as UIImage!, forState: .Normal)
        buttonSubmit.userInteractionEnabled = true
        imageViewScanIcon.hidden = true
        mCaptureSession.stopRunning()
    }
    
    func reScan() {
        // to rescan the barcode
        
        isBarCodeScanned = false
        mCaptureSession.startRunning()
        imageViewScanIcon.hidden = false
        buttonSubmit.userInteractionEnabled = false
        buttonSubmit.setBackgroundImage(UIImage(named: "SubmitGreyButton") as UIImage!, forState: .Normal)
    }
    
    func readBarcode(barcodeCallback:(barcodeScannerView: BarcodeScannerView, barcode: Barcode?) -> ()) {
        // save the call back
        
        self.barcodeCallback = barcodeCallback
        
        if configureSession(){
            startScan()
            addUIElementsWithConstraints()
        }
        else {
            showAlert(&&"access_denied_title", message: &&"access_denied_message_camera")
            barcodeCallback(barcodeScannerView: self, barcode: nil)
        }

    }
    
    func configureSession() -> Bool {
        // configure session
        
        mCaptureSession = AVCaptureSession()
        let videoCaptureDevice = AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)
        var error: NSError? = nil
        let videoInput: AnyObject!
        do {
            videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
        } catch let error1 as NSError {
            error = error1
            videoInput = nil
        }
        
        if videoInput == nil{
            return false
        }
        
        if  !mCaptureSession.canAddInput(videoInput as! AVCaptureInput) {
            //print("Could not add metadata output.")
            return false
        }
        
        mCaptureSession.addInput(videoInput as! AVCaptureInput)
        let metadataOutput = AVCaptureMetadataOutput()
        
        if  !mCaptureSession.canAddOutput(metadataOutput) {
            //print("Could not add video input:\(error.debugDescription)")
            return false
        }
        
        mCaptureSession.addOutput(metadataOutput)
        metadataOutput.setMetadataObjectsDelegate(self, queue: dispatch_get_main_queue())
        metadataOutput.metadataObjectTypes = barCodeTypes
        let previewLayer = AVCaptureVideoPreviewLayer(session: mCaptureSession)
        previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
        previewLayer.frame = CGRectMake(layer.frame.origin.x, layer.frame.origin.y, CGRectGetWidth(UIScreen.mainScreen().bounds), layer.frame.height+20)
        layer.addSublayer(previewLayer)
        
        return true
    }
    
    func captureOutput(captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [AnyObject]!, fromConnection connection: AVCaptureConnection!) {
        // called when the barcode is scanned
        
        if !isBarCodeScanned && metadataObjects.count != 0 {
            isBarCodeScanned = true
            barcode = Barcode(metaData: metadataObjects[0] as! AVMetadataMachineReadableCodeObject)
            stopScan()
        }
    }
    
    func addUIElementsWithConstraints() {
        
        let buttonFlash = UIButton()
        let buttonBack = UIButton()
        let labelScan = UILabel()
        let buttonRescan = UIButton()
        
        // add flash button to the scanner view
        buttonFlash.setImage(UIImage(named: "FlashIcon") as UIImage!, forState: .Normal)
        buttonFlash.addTarget(self, action: "buttonActionFlash:", forControlEvents: .TouchUpInside)
        self.addSubview(buttonFlash)
        
        // add back button to scanner view
        buttonBack.setImage(UIImage(named: "LeftArrowIcon") as UIImage!, forState: .Normal)
        buttonBack.addTarget(self, action: "buttonActionBack:", forControlEvents: .TouchUpInside)
        self.addSubview(buttonBack)
        
        // add scanner label to scanner view
        labelScan.text = &&"scan_product_barcode"
        labelScan.textColor = UIColor.whiteColor()
        self.addSubview(labelScan)
        
        // add scanner icon imageview to scanner view
        imageViewScanIcon.image = UIImage(named: "ScannerIcon") as UIImage!
        self.addSubview(imageViewScanIcon)
        
        // add submit button to scanner view
        buttonSubmit.userInteractionEnabled = false
        buttonSubmit.setBackgroundImage(UIImage(named: "SubmitGreyButton") as UIImage!, forState: .Normal)
        buttonSubmit.setTitle(&&"submit", forState: .Normal)
        buttonSubmit.addTarget(self, action: "buttonActionSubmit:", forControlEvents: .TouchUpInside)
        self.addSubview(buttonSubmit)
        
        //add rescan button
        buttonRescan.setTitle(&&"refresh", forState: .Normal)
        buttonRescan.addTarget(self, action: "buttonActionRescan:", forControlEvents: .TouchUpInside)
        self.addSubview(buttonRescan)
        
        // set constraints for the flash button
        buttonFlash.translatesAutoresizingMaskIntoConstraints = false
        self.addConstraints([NSLayoutConstraint(item: buttonFlash, attribute: .Right, relatedBy: .Equal,
            toItem: self, attribute: .Right, multiplier: 1.0, constant: -20.0),
            NSLayoutConstraint(item: buttonFlash, attribute: .Top, relatedBy: .Equal,
                toItem: self, attribute: .Top, multiplier: 1.0, constant: 40.0)
            ])
        
        // set constraints for the back button
        buttonBack.translatesAutoresizingMaskIntoConstraints = false
        self.addConstraints([NSLayoutConstraint(item: buttonBack, attribute: .Left, relatedBy: .Equal,
            toItem: self, attribute: .Left, multiplier: 1.0, constant: 20.0),
            NSLayoutConstraint(item: buttonBack, attribute: .Top, relatedBy: .Equal,
                toItem: self, attribute: .Top, multiplier: 1.0, constant: 40.0)])
        
        // set constraints for the scanner icon imageview
        imageViewScanIcon.translatesAutoresizingMaskIntoConstraints = false
        self.addConstraints([NSLayoutConstraint(item: imageViewScanIcon, attribute: NSLayoutAttribute.CenterX, relatedBy: .Equal,
            toItem: self, attribute: NSLayoutAttribute.CenterX, multiplier: 1.0, constant: 0.0),
            NSLayoutConstraint(item: imageViewScanIcon, attribute: NSLayoutAttribute.CenterY, relatedBy: .Equal,
                toItem: self, attribute: NSLayoutAttribute.CenterY, multiplier: 1.0, constant: 0.0)])
        
        // set constraints for the scanner label
        labelScan.translatesAutoresizingMaskIntoConstraints = false
        self.addConstraints([NSLayoutConstraint(item: labelScan, attribute: NSLayoutAttribute.Top, relatedBy: .Equal,
            toItem: imageViewScanIcon, attribute: NSLayoutAttribute.Bottom, multiplier: 1.0, constant: 20.0),
            NSLayoutConstraint(item: labelScan, attribute: NSLayoutAttribute.CenterX, relatedBy: .Equal,
                toItem: self, attribute: NSLayoutAttribute.CenterX, multiplier: 1.0, constant: 0.0)])
        
        // set constraints for the submit button
        buttonSubmit.translatesAutoresizingMaskIntoConstraints = false
        self.addConstraints([NSLayoutConstraint(item: buttonSubmit, attribute: NSLayoutAttribute.Bottom, relatedBy: .Equal,
            toItem: self, attribute: NSLayoutAttribute.Bottom, multiplier: 1.0, constant: 0.0), NSLayoutConstraint(item: buttonSubmit, attribute: NSLayoutAttribute.Left, relatedBy: .Equal,
                toItem: self, attribute: NSLayoutAttribute.Left, multiplier: 1.0, constant: 0.0),
            NSLayoutConstraint(item: buttonSubmit, attribute: NSLayoutAttribute.Right, relatedBy: .Equal,
                toItem: self, attribute: NSLayoutAttribute.Right, multiplier: 1.0, constant: 0.0)])
        
        // set constraints for the rescan button
        buttonRescan.translatesAutoresizingMaskIntoConstraints = false
        self.addConstraints([NSLayoutConstraint(item: buttonRescan, attribute: NSLayoutAttribute.Bottom, relatedBy: .Equal,
            toItem: buttonSubmit, attribute: NSLayoutAttribute.Top, multiplier: 1.0, constant: -20.0),
            NSLayoutConstraint(item: buttonRescan, attribute: NSLayoutAttribute.Right, relatedBy: .Equal,
                toItem: self, attribute: NSLayoutAttribute.Right, multiplier: 1.0, constant: -20.0)])
    }
    
    func buttonActionFlash(sender: UIButton!) {
        // called when the flash button is clicked
        
        let device = AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)
        if device.hasTorch {
            do {
                try device.lockForConfiguration()
            } catch _ {
            }
            let torchOn = !device.torchActive
            do {
                try device.setTorchModeOnWithLevel(1.0)
            } catch _ {
            }
            device.torchMode = torchOn ? AVCaptureTorchMode.On : AVCaptureTorchMode.Off
            device.unlockForConfiguration()
        }
    }
    
    func buttonActionSubmit(sender: UIButton!) {
        // called when the submit button is clicked
        
        barcodeCallback?(barcodeScannerView: self, barcode: barcode)
    }
    
    func buttonActionBack(sender: UIButton!) {
        // called when the back button is clicked
        
        barcodeCallback?(barcodeScannerView: self, barcode: nil)
    }
    
    func buttonActionRescan(sender: UIButton!) {
        // called when the rescan button is clicked
        
        reScan()
    }
    
}
