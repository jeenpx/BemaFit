//
//  UpdateFoodLogResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 10/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UpdateFoodLogResponse: NSObject {
   
    var meta: MetaModel?
    var foodLogId = ""
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
        responseMapping.addPropertyMapping(metaModelMapping)
        
        return responseMapping
    }
    
    class func updateFoodLog(foodLogId: String, params: [String: AnyObject], completionHandler: (error: NSError?) -> ()) {
        
        RestKitManager.setToken(true)
        
        // configure path
        let path = Constants.ServiceConstants.kFoodLogUrl + "/\(foodLogId)"
        
        let updateFoodLogResponseDescriptor = RKResponseDescriptor(mapping: UpdateFoodLogResponse.responseMapping, method: .PATCH, pathPattern: path, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        
        RestKitManager.sharedManager().addResponseDescriptor(updateFoodLogResponseDescriptor)
        
        // create a patch request
        let request = RestKitManager.sharedManager().requestWithObject(nil, method: .PATCH, path: path, parameters: nil)
        
        // set params as body
        request.HTTPBody = try? NSJSONSerialization.dataWithJSONObject(params, options: NSJSONWritingOptions())
        
        // create an operation with the request
        let operation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation, mappingResult) in
            
            let updateFoodLogResponse = mappingResult.firstObject as! UpdateFoodLogResponse
            
            // check for success
            if updateFoodLogResponse.meta?.responseCode != 200 {
                //print("XXX failed to udpate food log")
                completionHandler(error: NSError(domain: "FYM.FoodLog", code: 99, userInfo: ["description": "Failed to udpate food log"]))
            }
            else {
                completionHandler(error: nil)
            }
            }, failure: { (operation, error) in
                //print("XXX failed to log food with error \(error)")
                completionHandler(error: error)
        })
        
        // enque request operation
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
}