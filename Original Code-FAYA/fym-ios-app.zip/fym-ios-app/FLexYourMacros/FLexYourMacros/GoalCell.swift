//
//  GoalCell.swift
//  FlexYourMacros
//
//  Created by dbgattila on 6/3/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol GoalCellDelegate {
    func manageGoalCellGoalName(textFieldGoalName: UITextField, textFieldGoalOption: UITextField, goals: [GoalModel], cellForSelectedTextField tableViewCell: UITableViewCell)
    func manageGoalCellGoalOption(textFieldGoalOption: UITextField, textFieldGoalName: UITextField, cellForSelectedTextField tableViewCell: UITableViewCell)
}

class GoalCell: UITableViewCell, UITextFieldDelegate {
    
    @IBOutlet weak var textFieldGoalName: UITextField!
    @IBOutlet weak var textFieldOption: UITextField!
    var goalCellDelegate: GoalCellDelegate?
    var goalNames = [String]()
    
    // save goals
    var goals: [GoalModel]? {
        didSet {
            let goal = GoalDetails.getGoal(goals).goal
            let goalOptionName = GoalDetails.getGoal(goals).goalOption.goalOptionName
            
            // set goal name
            textFieldGoalName.text = goal.goalName
            
            // Custom
            if FymUser.sharedFymUser.userSelectedGoal?.goalId == "4" {
                
                // set goal option name
                textFieldOption.text = "\(FymUser.sharedFymUser.userCustomCalorie)"
                return
            }
            
            // set goal option name
            textFieldOption.text = goalOptionName
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        textFieldOption.keyboardType = UIKeyboardType.DecimalPad
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        if textField == textFieldGoalName {
            
            textFieldOption.resignFirstResponder()
            goalCellDelegate?.manageGoalCellGoalName(textField, textFieldGoalOption: textFieldOption, goals: AppConfiguration.sharedAppConfiguration.goals, cellForSelectedTextField: self)
        }
        else {
            if textField == textFieldOption {
                textFieldGoalName.resignFirstResponder()
                // not custom
                if FymUser.sharedFymUser.userSelectedGoal?.goalId != "4" {
                    
                    goalCellDelegate?.manageGoalCellGoalOption(textField, textFieldGoalName: textFieldGoalName, cellForSelectedTextField: self)
                }
                else {
                    
                    // if user clicks only in textfield option in the case of custom goal
                    goalCellDelegate?.manageGoalCellGoalName(textFieldGoalName, textFieldGoalOption: textFieldOption, goals: AppConfiguration.sharedAppConfiguration.goals, cellForSelectedTextField: self)
                }
            }
        }
    }
    func textFieldDidEndEditing(textField: UITextField) {
        
        if textField == textFieldOption && FymUser.sharedFymUser.userSelectedGoal?.goalId == "4" {
            FymUser.sharedFymUser.userCustomCalorie = textField.text!.doubleValue
            ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
        }
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        // hide keyboard on return
        textField.resignFirstResponder()
        return true
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        // managing the textfield input: limit the characters to only of numeric type
        if string.isEmpty { return true }
        
        var isValid = true
        let text = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        
        // check for unwanted characters
        let replacementStringIsLegal = string.rangeOfCharacterFromSet(NSCharacterSet(charactersInString: "0123456789.").invertedSet) == nil
        
        // check for string count
        let resultingStringLengthIsLegal = text.characters.count <= 7
        
        
        // check if the number is valid
        let scanner = NSScanner(string: text)
        let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
        
        let isLowNumber = text.doubleValue < 100000
        
        isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber
        
        return isValid
    }
    
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func getGoalNames() -> [String] {
        
        goalNames.removeAll()
        let goals = AppConfiguration.sharedAppConfiguration.goals //{
        for goal in goals {
            goalNames.append(goal.goalName!)
        }
        //        }
        return goalNames
    }
}

