//
//  DailyMealPlanItemRefreshResponse.swift
//  FlexYourMacros
//
//  Created by Minimol BI on 08/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _DailyMealPlanItemRefreshResponse = DailyMealPlanItemRefreshResponse()

class DailyMealPlanItemRefreshResponse: NSObject {
    
    var metaModel = MetaModel()
    var foodSuggestedResults = [DailyMealFoodModel]()
    
    class var sharedDailyMealPlanItemRefreshResponse: DailyMealPlanItemRefreshResponse {
        return _DailyMealPlanItemRefreshResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(DailyMealPlanItemRefreshResponse.metaModelKeyMapping)
        
        // give reference to FoodListMapping
        responseMapping.addPropertyMapping(DailyMealPlanItemRefreshResponse.autoSuggestFoodListModelKeyMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var autoSuggestFoodListModelKeyMapping : RKRelationshipMapping {
        
        //food log model is used since both auto suggested food and logged food are of same model
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathSuggestedFoodResult, toKeyPath: "foodSuggestedResults", withMapping: DailyMealFoodModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kFoodRefreshItem, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    class func fetchRefreshFoodItem(mealType: String, mealId: String, parentId: String, rowId: String, type: String, dmpMealType: String, nutritionPlan: String, completionHandler:(foodLogList: [Food], error: NSError?)->()) {
        
        RestKitManager.setToken(true)
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            var nutritionPlanNew : String
            if nutritionPlan == "5" //if custom -> flexible
            {
                nutritionPlanNew = "1"
            }
            else if nutritionPlan == "2" //if vegetarian -> vegan
            {
                nutritionPlanNew = "3"
            }
            else
            {
                nutritionPlanNew = nutritionPlan
            }
           
            
                return ["meal_type": mealType, "meal_id": mealId, "parent_id": parentId, "row_id": rowId, "dmp_meal_type": dmpMealType, "type": type, "nutritional_plan":nutritionPlanNew, "locale" : "\(NSLocale.currentLocale().objectForKey(NSLocaleLanguageCode)!)"]
        }
        
        // get the objects from the path login
        RestKitManager.sharedManager().getObjectsAtPath(Constants.ServiceConstants.kFoodRefreshItem, parameters: parameterDictionary, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            
            // map to correct datamodel
            let response = mappingResult.firstObject as! DailyMealPlanItemRefreshResponse
            
            let foodLogs = (response.foodSuggestedResults as [DailyMealFoodModel]).map { Food(dailyMealFoodModel: $0) }
            
            if response.metaModel.responseCode != 200 {
                let error = NSError(domain: "FYM.DailyMealPlan", code: 1001, userInfo: ["title": "error", "message": "alert_auto_suggest_list_message"])
                
                // fire completion handler
                completionHandler(foodLogList: [], error: error)
                
            }
            else {
                // fire completion handler
                completionHandler(foodLogList: foodLogs, error: nil)
            }
            
            }) { (operation, error) -> Void in
                // error
                let networkError = NSError(domain: "FYM.AutoSuggestFood", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
                
                // fire completion handler
                completionHandler(foodLogList: [], error: networkError)
        }
    }
}
