//
//  FriendListCell.swift
//  FlexYourMacros
//
//  Created by DBG on 06/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit


