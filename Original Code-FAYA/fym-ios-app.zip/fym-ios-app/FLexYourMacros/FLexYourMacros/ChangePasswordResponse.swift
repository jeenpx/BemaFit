//
//  ChangePasswordResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 24/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

private let _ChangePasswordResponse = ChangePasswordResponse()

class ChangePasswordResponse: NSObject {
   
    var changePasswordModel: ChangePasswordModel?
    var metaModel: MetaModel?
    var user_id: String?
    
    
    class var sharedUserSignUpResponse: ChangePasswordResponse {
        return _ChangePasswordResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(ChangePasswordResponse.metaModelKeyMapping)
        
        // give reference to changePassword mapping
        responseMapping.addPropertyMapping(ChangePasswordResponse.changePasswordModelMapping)
        
        return responseMapping
    }
    
    
    class var userResponseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.changePasswordUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    
    private class var changePasswordModelMapping :RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathChangePassword, toKeyPath: "changePasswordModel", withMapping: ChangePasswordModel.objectMapping)
    }
    
    
    class func userChangePassword(oldPassword:String,newPassword:String,completionHandler: (userChangePasswordResponse:ChangePasswordResponse) -> ()) {
        SVProgressHUD.show()

        RestKitManager.setToken(true)
 
        let changePasswordResponse = ChangePasswordResponse()
        changePasswordResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["old_password":oldPassword, "new_password":newPassword]
        }
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(changePasswordResponse, method: .POST, path: nil, parameters: parameterDictionary, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in

        })
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let userChangepasswordResonse = mappingResult.firstObject as! ChangePasswordResponse
            //print("respone code :\(userChangepasswordResonse.metaModel?.responseCode)")
            //print("respone status :\(userChangepasswordResonse.metaModel?.responseStatus)")
            
            // check for success
            if userChangepasswordResonse.metaModel?.responseCode == 200 {
               // success password changed
                completionHandler(userChangePasswordResponse: userChangepasswordResonse)
                
            } else if userChangepasswordResonse.metaModel?.responseCode == 422{
                // Invalid old password
                completionHandler(userChangePasswordResponse: userChangepasswordResonse)
                
            } else if userChangepasswordResonse.metaModel?.responseCode == 404 {
                
                 completionHandler(userChangePasswordResponse: userChangepasswordResonse)
                
                
            } else {
                return
            }
            SVProgressHUD.dismiss()

            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
            SVProgressHUD.dismiss()
            //print("failed to load change password with error \(error)")
        })

        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }

    
    
    
}





