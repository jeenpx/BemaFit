//
//  ShareSocialMedia.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/10/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import UIKit
import Social
import Accounts

protocol ShareSocialMediaDelegate {
    func shareSocialMedia(sharedStatus: String)
}

class ShareSocialMedia: NSObject, UIActionSheetDelegate {
    
    var shareSocialMediaDelegate: ShareSocialMediaDelegate?
    
    // singleton manager
    class var sharedManager: ShareSocialMedia {
        struct Singleton {
            static let instance = ShareSocialMedia()
        }
        return Singleton.instance
    }
    
    var currentViewController: UIViewController?
    
    
    // image to share
    private var shareImage: UIImage?
    
    // message to share
    private var shareMessage: String?
    
    // view for  document interaction controller in instagram
    private var shareView: UIView?
    
    // picture url
    private var sharedImageUrl: String?
    
    // website url
    private var shareWebsiteUrl: String?
    
    // name
    private var shareName: String?
    
    // action sheet to share on social media
    private let actionSheet = UIActionSheet(title: nil, delegate: nil, cancelButtonTitle: &&"cancel", destructiveButtonTitle: nil, otherButtonTitles: "Newsfeed", "Instagram",
        "Facebook", "Twitter")
    
    func shareOnSocialMedia(viewController: UIViewController, image: UIImage?, name: String, message: String, view: UIView, imageUrl: String, websiteUrl: String) {
        
        
        if image != nil {
            shareImage = image
        }
        else {
            // XXX- default image
            shareImage = UIImage(named: "LocationButton")
        }
        
        // save the message to share
        shareMessage = message
        
        // save the view for  document interaction controller in instagram
        shareView = view
        
        // save the parent view controller
        currentViewController = viewController
        
        // save image url
        sharedImageUrl = imageUrl
        
        // save website url
        shareWebsiteUrl = websiteUrl
        
        // save name
        shareName = name
        
        // present the action sheet
        actionSheet.delegate = self
        actionSheet.showInView(viewController.view)
    }
    
    
    func actionSheet(actionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int) {
        
        // get the selected social media
        switch actionSheet.buttonTitleAtIndex(buttonIndex)! {
            
        case "Newsfeed":
            
            // XXX - need to implement
            //print("Newsfeed")
            NewsFeed.create(shareMessage!, image: shareImage!) { (newsFeed, error) -> () in
                // handle errors
                if error == nil  {
                    self.shareSocialMediaDelegate?.shareSocialMedia(&&"successfully_shared_on_news_feed")
                }
            }
            
        case "Instagram":
            
            // share to instagram
            InstagramManager.sharedManager.postImageToInstagramWithCaption(shareImage!, instagramCaption: shareMessage!, view: shareView!)
            
        case "Facebook":
            
            let shareModel = FacebookShareModel()
            shareModel.description = shareMessage
            shareModel.name = shareName
            shareModel.pictureLink = sharedImageUrl
            shareModel.link = shareWebsiteUrl
            
            FacebookManager.showShareDialogWithShareModel(currentViewController!, andModel: shareModel, andCallback: { (status, results, error) -> Void in
                if error != nil {
                    //print(error)
                }
                else {
                    //print("success")
                    
                }
            })
            
        case "Twitter":
            //  share to twitter
            
            //  twitter without UI
            //  limit the characters to 140
            /* var shareMessage1 = shareMessage!.truncate(120, trailing: "...")
            TwitterManager.sharedManager.shareMessage(["status": shareMessage1], andImage: shareImage!, withSuccessBlock: { (data, urlResponse) -> () in
            
            // success
            // MARK: twitter
            self.showAlert(&&"notice", andMessage: &&"posted", andButtonTitle: "ok")
            
            }, andFailureBlock: { (error) -> () in
            // failure
            
            if error.localizedDescription == "Twitter Account not setup" {
            self.showAlert(&&"notice", andMessage: &&"setup_twitter_account", andButtonTitle: "ok")
            }
            else {
            self.showAlert(&&"notice",andMessage: &&"posted_failed" , andButtonTitle: "ok")
            }
            })
            */
            
            //  twitter with UI
            TwitterManager.sharedManager.shareTweetsUsingUI(currentViewController!, messages: shareMessage!, andImage: shareImage!, withSuccessBlock: { (data) -> () in
                //print("shared item ")
                }, andFailureBlock: { (error) -> () in
                    if error.localizedDescription == "Twitter Account not setup" {
                        self.showAlert(&&"notice", andMessage: &&"setup_twitter_account", andButtonTitle: "ok")
                    }
                    else {
                        self.showAlert(&&"notice",andMessage: &&"posted_failed" , andButtonTitle: "ok")
                    }
            })
            
            
        default: return
        }
    }
    
    func showAlert(title: String, andMessage message: String, andButtonTitle buttonTitle: String) {
        // show the alert
        
        if #available(iOS 8.0, *) {
            let alert: UIAlertController = UIAlertController(title: title,
                message: message, preferredStyle: .Alert)
            alert.addAction(UIAlertAction(title: buttonTitle, style: .Default, handler: nil))
            self.currentViewController?.presentViewController(alert, animated: true, completion: nil)
        } else {
            // Fallback on earlier versions
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: buttonTitle).show()
        }
    }
    
}