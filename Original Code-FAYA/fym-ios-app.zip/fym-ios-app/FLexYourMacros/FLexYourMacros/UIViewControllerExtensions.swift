//
//  UIViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 18/02/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

extension UIViewController {
    
    var appDelegate: AppDelegate? {
        get {
            return UIApplication.sharedApplication().delegate as? AppDelegate
        }
    }
    
    var slidingViewController: ECSlidingViewController? {
        get {
            return appDelegate?.slidingViewController
        }
    }

    var dashboardNavigationController: UINavigationController? {
        get {
            return slidingViewController?.topViewController as? UINavigationController
        }
    }

    var dashboard: DashboardViewController? {
        get {
            return dashboardNavigationController?.viewControllers[0] as? DashboardViewController
        }
    }
    
    func activateSlidingGesture() {
//        // activate gesture if we have a sliding view controller
//        if let slidingViewController = slidingViewController {
//            view.addGestureRecognizer(slidingViewController.panGesture)
//            view.addGestureRecognizer(slidingViewController.resetTapGesture)
//        }
    }
    
    func showToolbar() {
        navigationController?.setToolbarHidden(false, animated: false)
    }
    
    func hideToolBar() {
        navigationController?.setToolbarHidden(true, animated: false)
    }
    
    func loadViewLog() {
        
        // get a view log view controller if there is one in the navigation stack
        let navigationStack = dashboardNavigationController?.viewControllers
        let viewLogViewController = navigationStack?.filter { $0 is ViewLogViewController }.first as? ViewLogViewController
        
        // pop to view log if we have a view log view controller
        if let viewLogViewController = viewLogViewController {
            navigationController?.popToViewController(viewLogViewController, animated: true)
            return
        }
        
        // if we dont have a view log view controller in the stack,
        // pop quickly to dashboard and load view log view controller
        
        // save the dashboard object
        // weird that it get lost when we pop
        let backupDashboard = dashboard!
        
        // pop to root view controller which will be the dashboard
        dashboardNavigationController?.popToRootViewControllerAnimated(false)
        
        // load view log view controller from the dashboard
        backupDashboard.performSegueWithIdentifier(DashboardViewController.Storyboard.Segues.ViewLogSegue, sender: self)
    }
}