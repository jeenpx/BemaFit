//
//  ExerciseUpdateResponse.swift
//  FlexYourMacros
//
//  Created by mini on 26/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class ExerciseUpdateResponse: NSObject {
    
    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var exerciselog_id: String?
    
    // message delete response mapping
    class var exerciseUpdateResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(ExerciseUpdateResponse.metaModelKeyMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: exerciseUpdateResponseMapping, method: .PATCH, pathPattern: Constants.ServiceConstants.kUrlExercise, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    class func updateExercise(date: NSDate,exerciseId: String, completionHandler: (updatedStatus: Bool) -> ()) {
        // delete the exercise
        
        // set access token
        RestKitManager.setToken(true)
        
        let exerciseUpdateResponse = ExerciseUpdateResponse()
        exerciseUpdateResponse.exerciselog_id = exerciseId
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().requestWithObject(exerciseUpdateResponse, method: .PATCH, path: nil, parameters: nil)
        
        var err: NSError?
        let parameterDictionary = ["exercise_date" : date.stringValue("yyyy-MM-dd")]
        do {
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(parameterDictionary, options: NSJSONWritingOptions(rawValue: 0))
        } catch let error as NSError {
            err = error
            request.HTTPBody = nil
        }
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let exerciseUpdateResponse = mappingResult.firstObject as! ExerciseUpdateResponse
            
            //print("respone status :\(exerciseUpdateResponse.meta?.responseStatus)")
            
            // check for success
            if exerciseUpdateResponse.meta?.responseCode != 200 {
                return;
            }
            
            // set up the completion handler with response
            completionHandler(updatedStatus: true)
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                completionHandler(updatedStatus: false)
                
                //print("failed to log exercise with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
      
        
    }
}