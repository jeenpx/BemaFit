//
//  SendMealPlanViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 11/18/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class SendMealPlanCell: UITableViewCell {
    
 @IBOutlet weak var imageViewTick: UIImageView!
 @IBOutlet weak var imageViewProfilePic: UIImageView!
 @IBOutlet weak var labelUsername: UILabel!
 @IBOutlet weak var labelName: UILabel!
    
    
}

class SendMealPlanViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    struct StoryBoard {
        struct CellIdentifiers {
            static let sendMealPlanCellIdentifier = "kSendMealPlanCell"
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let sendMealPlanCell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.sendMealPlanCellIdentifier)
        return sendMealPlanCell!
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 85.0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func buttonActionDismissViewController(sender: UIBarButtonItem) {
        
        self.navigationController?.popViewControllerAnimated(true)
    }
}
