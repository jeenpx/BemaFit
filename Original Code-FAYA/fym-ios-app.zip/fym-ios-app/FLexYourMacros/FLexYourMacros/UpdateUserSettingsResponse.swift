//
//  UpdateUserSettingsResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 05/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UpdateUserSettingsResponse: NSObject {
    var metaModel: MetaModel?
    var updateSettings: UpdateUserSettingsModel?
    var user_id: String?
    
    class var UpdateUserSettingsResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        // give referece to meta model
        responseMapping.addPropertyMapping(UpdateUserSettingsResponse.metaModelKeyMapping)
        // give reference to changePassword mapping
        responseMapping.addPropertyMapping(UpdateUserSettingsResponse.updateUserSettingModelMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var updateUserSettingModelMapping :RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUpdateSettings, toKeyPath: "updateSettings", withMapping: UpdateUserSettingsModel.objectMapping)
    }
    
    class var userResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: UpdateUserSettingsResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.userSettingsUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    
    class func updateUserSettings(parameters: Array<Dictionary<String, String>>,completionHandler: (updateUserSettingsResponse:UpdateUserSettingsResponse) -> ()){
     
        RestKitManager.setToken(true)
        let updateResponse = UpdateUserSettingsResponse()
        updateResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
    
      //  var e = ["setting_id":id,"status":status]
        
       // var parameters: Array<Dictionary<String, String>> = [["setting_id":"3","status":"No"],["setting_id":"1","status":"No"]]
       // parameters.append(e)
        
   
        let jsonData = try? NSJSONSerialization.dataWithJSONObject(parameters,options:NSJSONWritingOptions());
        let jsonString = NSString(data: jsonData!, encoding:NSUTF8StringEncoding);
        
        //print("Converted json string \(jsonString)");
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(updateResponse, method: .POST, path: nil, parameters: ["settings" :
            
            jsonString as! String], constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
       let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let updateUserSettingsResponse = mappingResult.firstObject as! UpdateUserSettingsResponse
            //print("respone code :\(updateUserSettingsResponse.metaModel?.responseCode)")
            //print("respone status :\(updateUserSettingsResponse.metaModel?.responseStatus)")
            
            // check for success
            if updateUserSettingsResponse.metaModel?.responseCode != 200 {
                return;
            }
            
            // set up the completion handler with response
            completionHandler(updateUserSettingsResponse: updateUserSettingsResponse)
            
            //print("Status is \(updateUserSettingsResponse.updateSettings?.status)")
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                //print("failed to load change password with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    
    }
    


}
