//
//  DailyMealPlanResponseModel.swift
//  FlexYourMacros
//
//  Created by Minimol BI on 14/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import Foundation


//foodlog model
class DailyMealPlanResponseModel: NSObject {
    
    var mealPlanId: String = ""
    var mealPlanGuid: String = ""
    var mealPlanName: String = ""
    var mealPlanUserId: String = ""
    var mealPlanUserName: String = ""
    var mealPlanUserProfilePhoto: String = ""
    var mealPlanAddedById: String = ""
    var mealPlanAddedByUsername: String = ""
    var mealPlanAddedByProfilePhoto: String = ""
    var mealNutritionId: String = ""
    var mealCoreNo: String = ""
    var mealSnackNo: String = ""
    var mealCalorie: String = ""
    var mealCarb: String = ""
    var mealFat: String = ""
    var mealProtein: String = ""
    var mealFibre: String = ""
    var mealAddedDate: String = ""
    var mealUpdatedDate: String = ""
    var mealStatusId: String = ""
    
    var mealPlanFoods = [DailyMealFoodModel]()
    
    
    var mealNutritionPlanName:String = ""
    
    
    
    
    class var objectMapping: RKObjectMapping {
        let mealPlanLogMapping = RKObjectMapping(forClass: self)
        mealPlanLogMapping.addAttributeMappingsFromDictionary(mappingDictionary)
        mealPlanLogMapping.addPropertyMapping(DailyMealPlanResponseModel.mealPlanFoodListModelKeyMapping)
        return mealPlanLogMapping
    }
    
    class var mappingDictionary: [String : String] {
        return(["id":"mealPlanId", "guid":"mealPlanGuid", "name":"mealPlanName", "userid":"mealPlanUserId", "username": "mealPlanUserName", "user_profile_photo": "mealPlanUserProfilePhoto", "added_userid":"mealPlanAddedById", "added_username": "mealPlanAddedByUsername", "added_profile_photo":"mealPlanAddedByProfilePhoto", "nutrition_plan_id": "mealNutritionId", "coremeal" : "mealCoreNo", "snacks": "mealSnackNo", "calorie": "mealCalorie", "carb": "mealCarb", "fat": "mealFat", "protien": "mealProtein", "fiber": "mealFibre", "added_date": "mealAddedDate", "updated_date": "mealUpdatedDate", "status_id": "mealStatusId","nutrition_plan":"mealNutritionPlanName",
            ])
    }
    
    private class var mealPlanFoodListModelKeyMapping : RKRelationshipMapping {
        
        //food log model is used since both auto suggested food and logged food are of same model
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathDailyMealPlanFoodDetails, toKeyPath: "mealPlanFoods", withMapping: DailyMealFoodModel.objectMapping)
    }
}
