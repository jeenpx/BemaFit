//
//  MealType.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 02/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit



class MealType: NSObject {
    
    var id = 0
    var name = ""
    var isDefault = false
    
    var foods = [Food]() {
        didSet {
            
            // set meal types
            foods.map { $0.mealType = self }
        }
    }
    
    override var description: String { get { return "\n meal name \(self.name) meal id \(self.id)" } }
    override init() { }
    
    init(name: String = "") {
        self.name = name
    }
    
    func addFood(food: Food) {
        food.mealType = self
        foods.append(food)
    }
    
    func deleteFood(food: Food, shouldUpdateServer: Bool = true) {
        
        // remove locally if it asks for it
        if !shouldUpdateServer {
            foods.remove(food)
            return
        }
        
        // delete foodlog from server
        food.deleteFood { (deletedStatus) -> () in
            self.foods.remove(food)
        }
    }
    
    func toDictionary() -> [String: String] {
        return ["meal_type": name,"locale":NSLocale.currentLocale().objectForKey(NSLocaleLanguageCode)! as! String]
    }
    
    class var objectMapping: RKObjectMapping {
        
        let mappingDictionary = ["id": "id", "name": "name", "is_default": "isDefault"]
        
        let mapping = RKObjectMapping(forClass: self)
        mapping.addAttributeMappingsFromDictionary(mappingDictionary)
        return mapping
    }
    
    class func showAlert(error: NSError?) {
        
        // no need to handle errors if we dont have any :)
        if error == nil { return }
        
        // get the tile and message for the alert
        if let userInfo = error?.userInfo {
            let title = userInfo["title"] as! String
            let message = userInfo["message"] as! String
            
            // show alert
            UIAlertView(title: &&title, message: &&message, delegate: nil, cancelButtonTitle: &&"cancel").show()
        }
    }
    
    class func fetchMealTypeList(completionHandler: (mealTypes: [MealType]) -> ()) {
        MealTypeListResponse.fetchMealTypeList { (mealTypes) in
            completionHandler(mealTypes: mealTypes)
        }
    }
    
    func createMealType(completionHandler: (error: NSError?) -> ()) {
        MealTypeCreateResponse.createMealType(toDictionary()) { (error) -> () in
            
            // handle errors
            MealType.showAlert(error)
            
            completionHandler(error: error)
        }
    }
}

func ==(lhs: MealType, rhs: MealType) -> Bool {
    return (lhs.id == rhs.id)
}