//
//  AutoSyncTableViewCell.swift
//  FlexYourMacros
//
//  Created by DBG on 04/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol AutoSyncTableViewCellDelegate {
    func settingsSelected(settingsId:String,status:String)
}

class AutoSyncTableViewCell: UITableViewCell {

    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var switchStatus: UISwitch!
    
    var delegate:AutoSyncTableViewCellDelegate! = nil
    
    var settings:SettingsModel! {
        didSet{
            labelTitle.text = settings.title
            if settings.status == "No" {
            switchStatus.setOn(false, animated: true)
            }else {
            switchStatus.setOn(true, animated: true)
            }
        }
    }
 
    @IBAction func switchAction(sender: UISwitch) {
        
        if switchStatus.on {
            //print("Switch is on")
             //print(settings.settingsId)
           // switchStatus.setOn(false, animated:true);
           //  setSettings(settings.settingsId!, status: "No")
            delegate.settingsSelected(settings.settingsId!, status: "Yes")
            
            
        } else {
            //print("Switch is off")
            //print(settings.settingsId)
          //   switchStatus.setOn(true, animated:true)
          //  setSettings(settings.settingsId!, status: "Yes")
            delegate.settingsSelected(settings.settingsId!, status: "No")
            
        }
        
    }

   /* func setSettings(id:String,status:String) {
        UpdateUserSettingsResponse.updateUserSettings(id, status: status ,completionHandler: { (updateUserSettingsResponse) -> () in
            //println("Success")
        })
        

    }
    */

}
