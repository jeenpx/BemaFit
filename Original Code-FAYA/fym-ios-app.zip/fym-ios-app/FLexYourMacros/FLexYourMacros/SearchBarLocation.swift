//
//  SearchBarLocation.swift
//  FlexYourMacros
//
//  Created by Thahir on 17/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class SearchBarLocation: CustomSearchBar, UISearchBarDelegate {
    
    var searchBarLocationDelegate: UISearchBarDelegate?
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        // configure searchbar
        configureSearchBar()
    }
    
    func configureSearchBar() {
        
        // set the searchbar delegate
        delegate = self
        
        // set the location button as the bookmark button
        showsBookmarkButton = true
        setImage(UIImage(named: "LocationButton"), forSearchBarIcon: .Bookmark, state: .Normal)
    }
    
    // return NO to not become first responder
    func searchBarShouldBeginEditing(searchBar: UISearchBar) -> Bool {
        return searchBarLocationDelegate?.searchBarShouldBeginEditing?(searchBar) ?? true
    }
    
    // called when text starts editing
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchBarLocationDelegate?.searchBarTextDidBeginEditing?(searchBar)
    }
    
    // return NO to not resign first responder
    func searchBarShouldEndEditing(searchBar: UISearchBar) -> Bool {
        return searchBarLocationDelegate?.searchBarShouldEndEditing?(searchBar) ?? true
    }
    
    // called when text ends editing
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        searchBarLocationDelegate?.searchBarTextDidEndEditing?(searchBar)
    }
    
    // called when text changes (including clear)
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        searchBarLocationDelegate?.searchBar?(searchBar, textDidChange: searchText)
    }
    
    // called before text changes
    func searchBar(searchBar: UISearchBar, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        return searchBarLocationDelegate?.searchBar?(searchBar, shouldChangeTextInRange: range, replacementText: text) ?? true
    }
    
    // called when keyboard search button pressed
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        searchBarLocationDelegate?.searchBarSearchButtonClicked?(searchBar)
    }
    
    // called when bookmark button pressed
    func searchBarBookmarkButtonClicked(searchBar: UISearchBar) {
        
        // XXX set location text from location manager
       // text = "current location from location manager"
        searchBarLocationDelegate?.searchBarBookmarkButtonClicked?(searchBar)
    }
    
    // called when cancel button pressed
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchBarLocationDelegate?.searchBarCancelButtonClicked?(searchBar)
    }
    
    // called when search results button pressed
    func searchBarResultsListButtonClicked(searchBar: UISearchBar) {
        searchBarLocationDelegate?.searchBarResultsListButtonClicked?(searchBar)
    }
    
    func searchBar(searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        searchBarLocationDelegate?.searchBar?(searchBar, selectedScopeButtonIndexDidChange: selectedScope)
    }
}
