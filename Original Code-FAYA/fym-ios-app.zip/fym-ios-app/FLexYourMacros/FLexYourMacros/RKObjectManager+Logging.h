//
//  RKObjectManager+Logging.h
//  SampleRestKit
//
//  Created by Thahir on 20/02/15.
//  Copyright (c) 2015 Thahir. All rights reserved.
//

#import "RKObjectManager.h"
#import "RKLog.h"

@interface RKObjectManager (Logging)

+ (void)initLogging;

@end
