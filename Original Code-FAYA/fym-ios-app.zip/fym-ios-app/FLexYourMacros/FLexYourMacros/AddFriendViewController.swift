//
//  AddFriendViewController.swift
//  FlexYourMacros
//
//  Created by DBG on 26/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

// table cell for the contact
protocol AddressBookContactCellDelegate {
    func triggerAlert(title: String, message: String)
}

class AddressBookContactCell : UITableViewCell {
    
    @IBOutlet weak var labelContactName : UILabel!
    
    var addressBookContactCellDelegate: AddressBookContactCellDelegate?
    
    // initialising the contact and setting the username
    var contact : AddressBookContact! {
        didSet {
            
            // split up the name
            var arrayNames = contact.contactName.componentsSeparatedByString(" ")
            
            // get the first name
            let firstName = NSMutableAttributedString(string: arrayNames[0], attributes: [NSFontAttributeName: UIFont.helveticaBold(16)])
            
            // get the last name
            arrayNames.remove(arrayNames[0])
            let lastName = NSMutableAttributedString(string: " " + arrayNames.joinWithSeparator(" "))
            
            // join the names
            firstName.appendAttributedString(lastName)
            
            // set the attributed text
            labelContactName.attributedText = firstName
        }
    }
    
    // invite the friends
    @IBAction func buttonActionInvite(sender: AnyObject) {
        //////print("buttonActionInvite:\(contact.contactName)--\(contact.contactEmail)")
        let button = sender as! UIButton
        button.userInteractionEnabled = false
        button.alpha = 0.5
        InviteFriendResponse.sendInvitationFriendViaEmail(contact.contactEmail!, completionHandler: { (response) -> () in
            let inviteFriendResponse = response
            
            if inviteFriendResponse.metaModel?.responseCode == 200 {
                button.userInteractionEnabled = true
                button.alpha = 1.0
                self.addressBookContactCellDelegate?.triggerAlert(&&"notice", message: &&"invite_success")
            }else {
                button.userInteractionEnabled = true
                button.alpha = 1.0
                //print("respone code :\(inviteFriendResponse.metaModel?.responseCode)")
                //print("respone status :\(inviteFriendResponse.metaModel?.responseStatus!)")
                //print("respone status :\(inviteFriendResponse.metaModel?.message)")
                self.addressBookContactCellDelegate?.triggerAlert(&&"notice", message: &&"invite_failed")
                
            }
            
        })
        
    }
    
}

// table cell for the FYM users

protocol UserListCellDelegate {
    func userListCellUserProfile(userId: String)
    func userDetailUpdate(userId: String)
}

class UserListCell: UITableViewCell {
    
    @IBOutlet weak var lableUsername: UILabel!
    @IBOutlet weak var imageViewUser: UIImageView!
    @IBOutlet weak var labelUserFullName: UILabel!
    @IBOutlet weak var labelFollowing: UILabel!
    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var buttonAdd: UIButton!
    
    var user : UserDetailModel! {
        didSet{
            
            labelStatus.hidden = true
            buttonAdd.hidden = true
            buttonAdd.userInteractionEnabled = true
            buttonAdd.alpha = 1.0
            lableUsername.text = user.userUserName!
            labelUserFullName.text = "\(user.userFirstName!) \(user.userLastName!)"
            labelFollowing.text = "\(user.followers!) " + &&"followers" + " \(user.following!) " + &&"following"
            let imageURL = NSURL(string: user.userProfilePhoto as? String ?? "")
            imageViewUser.setImageWithURL(imageURL, placeholderImage: UIImage(named: "PlaceHolderProfilePic")!)
            
            // if friends then do not show any labels or button , else if nonfriend then show add button else show the request sent label
            if user.status == "friends" {
                labelStatus.hidden = true
                buttonAdd.hidden = true
            } else if user.status == "nonFriend" {
                buttonAdd.hidden = false
            } else {
                labelStatus.hidden = false
            }
            
            
        }
        
    }
    
    var userListCellDelegate: UserListCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        configureCell()
    }
    
    func configureCell() {
        
        lableUsername.userInteractionEnabled = true
        let tapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
        tapGesture.delegate = self
        lableUsername.addGestureRecognizer(tapGesture)
        
        imageViewUser.userInteractionEnabled = true
        let imageViewUserTapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
        imageViewUserTapGesture.delegate = self
        imageViewUser.addGestureRecognizer(imageViewUserTapGesture)
        
        
    }
    
    func didTaplabelUserNameWithGesture(tapGesture: UITapGestureRecognizer) {
        userListCellDelegate?.userListCellUserProfile(user.userId!)
        
    }
    
    @IBAction func buttonActionAdd(sender: AnyObject) {
        
        let button = sender as! UIButton
        button.userInteractionEnabled = false
        button.alpha = 0.5
        InviteFriendResponse.sendInvitationFriend(user.userId!, completionHandler: { (response) -> () in
            let inviteFriendResponse = response
            // success code = 200 , Invitation send
            if inviteFriendResponse.metaModel?.responseCode == 200 {
                // success password changed
                // hide the button and make the label visible
                //print("received success response for user \(inviteFriendResponse.friendRequestResponseModel!.userId!)")
                self.labelStatus.hidden = false
                button.hidden = true
                button.userInteractionEnabled = true
                button.alpha = 1.0
                self.userListCellDelegate?.userDetailUpdate(inviteFriendResponse.friendRequestResponseModel!.userId!)
            } else {
                button.userInteractionEnabled = true
                button.alpha = 1.0
            }
            
        })
        
    }
    
    
}

// view controller
class AddFriendViewController: UIViewController, UISearchBarDelegate , UITableViewDragLoadDelegate , AddressBookContactCellDelegate, UserListCellDelegate , UIAlertViewDelegate {
    
    @IBOutlet weak var labelNoData: UILabel!
    @IBOutlet var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var buttonSearchFYM: UIButton!
    @IBOutlet weak var buttonAddFromContacts: UIButton!
    
    var alert1: UIAlertView?
    var alert2: UIAlertView?
    
    // setting the font and color for the tabs
    let selectedFont = UIFont.helveticaBold(17)
    
    let deSelectFont = UIFont.helvetica(17)
    
    // let selectedFontColor = UIColor(red: 95.0/255.0, green: 95.0/255.0, blue: 95.0/255.0, alpha: 1.0)
    let selectedFontColor = UIColor(red: 114.0/255.0, green: 114.0/255.0, blue: 114.0/255.0, alpha: 1.0)
    
    let deSelectFontColor = UIColor(red: 175.0/255.0, green: 175.0/255.0, blue: 175.0/255.0, alpha: 1.0)
    
    // variable for contact permission isallowed
    var isAllowed = false
    
    
    // variable for pull to refresh
    var refreshControl: UIRefreshControl!
    
    // user array
    var arrayFymUsers :[UserDetailModel] = []
    var arrayFymUsertemp :[UserDetailModel] = []
    var searchActive : Bool = false
    // search keyword
    var searchKeyword : String = ""
    
    struct TabIdentifiers {
        static let tabFYM = 0
        static let tabContacts = 1
    }
    
    struct  cellIndentifiers {
        static let cellContact = "kAddressBookContactCell"
        static let cellFym = "kFYMContactCell"
    }
    
    // offset
    var offsetValue:Int!
    //  var isFirstTime = true
    
    var selectedTab: Int {
        
        // default is FYM
        if buttonSearchFYM.backgroundColor == nil {
            return TabIdentifiers.tabFYM
        }
        
        return buttonSearchFYM.backgroundColor!.isEqual(UIColor.whiteColor()) ? TabIdentifiers.tabFYM : TabIdentifiers.tabContacts
    }
    
    // custom type to represent table sections
    class Section {
        var contacts: [AddressBookContact] = []
        
        func addContact(contact: AddressBookContact) {
            contacts.append(contact)
        }
    }
    
    var arrayFYMContacts: [String]?
    
    var arrayAddressBookContacts: [AddressBookContact]?
    
    // temp variable for storing fetched contacts
    var temparrayAddressBookContacts: [AddressBookContact]?
    
    // filteredArray for filtering the contacts
    var filteredArray : [AddressBookContact] = []
    
    var arrayTableViewData: [Section]? {
        didSet {
            tableView.reloadData()
        }
    }
    
    let collation = UILocalizedIndexedCollation.currentCollation() 
    
    
    func fetchAddressBookContacts() {
        AddressBookContact.fetchAllContactsWithEmail { contacts in
            
            // configuring the sections with the fetched contacts
            self.configureSections(contacts)
            
            // storing all the fetched contacts in temp variable ,for filtering the contacts/ for checking contact count/ for resetting the contact
            self.temparrayAddressBookContacts = contacts
        }
    }
    
    
    func resetAddressBookContacts() {
        // reset contact details
        self.configureSections(self.temparrayAddressBookContacts)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // placeholder text for search
        searchBar.placeholder = &&"SearchFym"
        
        labelNoData.hidden = true
        
        // fetch the contacts
        fetchAddressBookContacts()
        
        // setting the offset value
        offsetValue = arrayFymUsers.count
        
        // fetching the fym users list
        getFymUsersList(offset: offsetValue, limit: 15, searchKeyword: searchKeyword, doLoadMore: false)
        
        // search delegate
        searchBar.delegate=self
        
        //
        configureTableViewAddFriends()
        configureRefreshControl()
        
        tableView.hidden = true
    }
    
    
    func configureRefreshControl() {
        refreshControl = UIRefreshControl()
        
        // add the target
        refreshControl.addTarget(self, action: "pullToRefresh:", forControlEvents: UIControlEvents.ValueChanged)
        refreshControl.tintColor = UIColor.grayColor()
        
        // add refresh control to the tableview
        tableView.addSubview(refreshControl)
    }
    
    func configureSections(contacts: [AddressBookContact]?) {
        if contacts == nil {
            // handle errors
            //print("contacts permission is denied")
            self.isAllowed = false
            return
        }
        
        self.isAllowed = true
        
        // add section values for contatcs
        self.arrayAddressBookContacts = contacts?.map() { contact in
            contact.section = self.collation.sectionForObject(contact, collationStringSelector: "contactName")
            return contact
        }
        
        // configure sections
        // create empty sections
        var sections = [Section]()
        for i in 0..<self.collation.sectionIndexTitles.count {
            sections.append(Section())
        }
        
        // put each contact in a section
        for contact in self.arrayAddressBookContacts! {
            sections[contact.section!].addContact(contact)
        }
        
        // sort each section
        for section in sections {
            section.contacts = self.collation.sortedArrayFromArray(section.contacts, collationStringSelector: "contactName") as! [AddressBookContact]
        }
        
        // save sections and reload
        self.arrayTableViewData = sections
        
    }
    
    
    func configureTableViewAddFriends() {
        
        // set delegate for pull to refresh and load more
        tableView.setDragDelegate(self, refreshDatePermanentKey: "kFriend")
        
        // hide pull to refresh
        tableView.showRefreshView = false
        
        // show load more
        tableView.showLoadMoreView = true
        
        // tableview footer release text
        tableView.footerReleaseText = &&"release_to_load_more_status"
        
        // tableview footer pull up text
        tableView.footerPullUpText = &&"pull_down_to_load_more_status"
        
        //tableview footer loading text
        tableView.footerLoadingText = &&"loading_status"
    }
    
    func pullToRefresh(sender: AnyObject) {
        // reset all the values
        //tableView.hidden = true
        arrayFymUsers = []
        arrayFymUsertemp = []
        searchActive  = false
        // search keyword
        searchKeyword = ""
        searchBar.text!.removeAll(keepCapacity: true)
        arrayAddressBookContacts = []
        filteredArray = []
        arrayTableViewData = []
        labelNoData.hidden = true
        fetchAddressBookContacts()
        offsetValue = arrayFymUsers.count
        getFymUsersList(false,offset: offsetValue, limit: 15, searchKeyword: searchKeyword, doLoadMore: false)
        
    }
    
    
    
    func updateTabs(selectedFYMContacts: Bool) {
        
        // update button backgrounds
        buttonSearchFYM.backgroundColor = selectedFYMContacts ? UIColor.whiteColor() : UIColor(red: 224.0/255.0, green: 224.0/255.0, blue: 224.0/255.0, alpha: 1.0)
        buttonAddFromContacts.backgroundColor = selectedFYMContacts ? UIColor(red: 224.0/255.0, green: 224.0/255.0, blue: 224.0/255.0, alpha: 1.0) : UIColor.whiteColor()
        searchBar.text!.removeAll(keepCapacity: true)
        
        // reload data
        tableView.hidden = false
        searchActive = false
        
        searchBar.setShowsCancelButton(false, animated: true)
        tableView.reloadData()
        
    }
    
    @IBAction func buttonActionSearchOnFYM(sender: UIButton) {
        
        // setting the font and color
        buttonSearchFYM.titleLabel?.font = selectedFont
        buttonSearchFYM.setTitleColor(selectedFontColor, forState:  UIControlState.Normal)
        buttonAddFromContacts.titleLabel?.font = deSelectFont
        buttonAddFromContacts.setTitleColor(deSelectFontColor, forState:  UIControlState.Normal)
        
        // setting the placeholder text
        searchBar.placeholder = &&"SearchFym"
        
        
        updateTabs(true)
        searchBar.resignFirstResponder()
    }
    
    @IBAction func buttonActionAddFromContacts(sender: UIButton) {
        
        // check the contact is permitted the permission
        if !self.isAllowed {
            triggerAlert(&&"notice", message: &&"contact_settings_alert")
            return
            
        }
        
        // setting placeholder text
        searchBar.placeholder = &&"SearchContacts"
        
        updateTabs(false)
        searchBar.resignFirstResponder()
        buttonSearchFYM.titleLabel?.font = deSelectFont
        buttonSearchFYM.setTitleColor(deSelectFontColor, forState: UIControlState.Normal)
        buttonAddFromContacts.titleLabel?.font = selectedFont
        buttonAddFromContacts.setTitleColor(selectedFontColor, forState: UIControlState.Normal)
        
        // check if the temp array(arrayFymUsertemp) contains user data then resetting the data
        if (arrayFymUsertemp.count > 0) {
            
            // store temporary offset value back to offset variable
            offsetValue = arrayFymUsertemp.count
            
            // store temporary array friends value back to friends array
            arrayFymUsers = self.arrayFymUsertemp
            
            // emptying the temp array-Fymusers
            arrayFymUsertemp = []
            
        }
        
        // check if the temp contact array contains value then reset
        
        if(self.temparrayAddressBookContacts?.count > 0) {
            resetAddressBookContacts()
        }
        
    }
    
    func sectionIndexTitlesForTableView(tableView: UITableView) -> [AnyObject]! {
        
        // return index titles for address book contacts
        if selectedTab == TabIdentifiers.tabContacts && !searchActive && temparrayAddressBookContacts?.count > 0 {
            return self.collation.sectionIndexTitles
        }
        
        // no index for FYM contacts
        return nil
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        
        if selectedTab == TabIdentifiers.tabFYM {
            
            //reset the table view empty message
            tableView.showEmptyTableViewMessage(" ")
            
            //check for the arrayFymUsers.count
            if arrayFymUsers.count == 0 {
                
                tableView.showEmptyTableViewMessage(&&"empty_tableview_message")
                
                return 0
            }
            tableView.backgroundView = UIView()
            tableView.separatorStyle = .SingleLine
            return 1
            
        } else {
            
            //reset the table view empty message
            tableView.showEmptyTableViewMessage(" ")
            
            // case 1 : search in contact is active  check for the filteredArray count
            if searchActive {
                
                // check for the filteredArray.count , if count is 0 then show empty message
                if filteredArray.count == 0 {
                    
                    tableView.showEmptyTableViewMessage(&&"empty_tableview_message")
                    
                    return 0
                }
                tableView.backgroundView = UIView()
                tableView.separatorStyle = .SingleLine
                // section count is arrayTableViewData.count
                return arrayTableViewData?.count ?? 0
            } else {
                // case 2 : listing the contact
                // check if the contact details available in the temparrayAddressBookContacts array , if count >0 then section is arrayTableViewData.count
                if temparrayAddressBookContacts?.count > 0 {
                    tableView.backgroundView = UIView()
                    tableView.separatorStyle = .SingleLine
                    return arrayTableViewData?.count ?? 0
                }
                
                // if there is no contact details show empty message
                tableView.showEmptyTableViewMessage(&&"empty_tableview_message")
                return 0
                
            }
        }
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if selectedTab == TabIdentifiers.tabFYM {
            return arrayFymUsers.count
        } else {
            return arrayTableViewData?[section].contacts.count ?? 0
        }
        
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return selectedTab == TabIdentifiers.tabFYM ? 100.0 : 54.0
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if selectedTab == TabIdentifiers.tabFYM {
            
            // fym user cell
            let cell = tableView.dequeueReusableCellWithIdentifier(cellIndentifiers.cellFym, forIndexPath: indexPath) as! UserListCell
            cell.user = arrayFymUsers[indexPath.row]
            cell.userListCellDelegate = self
            return cell
        }else  {
            
            // contact user cell
            let cell = tableView.dequeueReusableCellWithIdentifier(cellIndentifiers.cellContact, forIndexPath: indexPath) as! AddressBookContactCell
            let contactData=arrayTableViewData?[indexPath.section].contacts[indexPath.row]
            cell.contact=contactData
            cell.addressBookContactCellDelegate = self
            return cell
        }
        
    }
    
    // updates the status of the each object
    func userDetailUpdate(userId: String) {
        
        self.arrayFymUsers = updateArrayElement(arrayFymUsers, removeItem:userId)
        self.arrayFymUsertemp = updateArrayElement(arrayFymUsertemp, removeItem:userId)
        self.tableView.reloadData()
        
    }
    
    func updateArrayElement(var s :[UserDetailModel],removeItem:String )-> ([UserDetailModel]) {
        
        for (var i=0;i<s.count;i++) {
            if s[i].userId == removeItem {
                let newObject = s[i]
                newObject.status = "friendRequestSent"
                s[i] = newObject
                //                s[i].status = "friendRequestSent"
                //print("received success replaced user \(newObject.userUserName)")
                
            }
        }
        
        return s
    }
    
    /* section headers
     appear above each `UITableView` section */
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String {
        
        //  if selectedTab == TabIdentifiers.tabContacts && searchActive { return "" }
        
        if selectedTab == TabIdentifiers.tabFYM { return "" }
        
        if !arrayTableViewData![section].contacts.isEmpty {
            return collation.sectionTitles[section] 
        }
        
        return ""
    }
    
    func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header:UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView
        header.textLabel!.textColor = UIColor.blackColor()
        header.textLabel!.font = UIFont.helveticaBold(16)
        header.textLabel!.frame = header.frame
        header.textLabel!.textAlignment = NSTextAlignment.Left
    }
    
    
    /* section index titles
     displayed to the right of the `UITableView` */
    func tableView(tableView: UITableView, sectionForSectionIndexTitle title: String, atIndex index: Int) -> Int {
        
        // show the right side index if the tab selected is contacts
        if selectedTab == TabIdentifiers.tabContacts  {
            return collation.sectionForSectionIndexTitleAtIndex(index)
        } else {
            return 0
        }
        
        
        
    }
    
    // delegate method : userListCell
    func userListCellUserProfile(userId: String) {
        performSegueWithIdentifier("kAddFriendProfileSegue",sender: userId)
    }
    
    
    // SEARCH BAR
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        
        if(searchBar.text!.isEmpty) {
            // setting the searchActive to false
            searchActive = false
            
        }else {
            
            // setting the searchActive to true
            searchActive = true;
        }
        
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        searchActive = false
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        
        searchActive = false;
        
        // resetting the search text
        searchKeyword = ""
        
        // tableView.reloadData()
        if selectedTab == TabIdentifiers.tabFYM {
            searchBarTextEmpty()
        }
        
        if selectedTab == TabIdentifiers.tabContacts {
            
            // fetch the contact details if the cancel button clicked
            // fetchAddressBookContacts()
            resetAddressBookContacts()
        }
        
        searchBar.text!.removeAll(keepCapacity: true)
        searchBar.setShowsCancelButton(false, animated: true)
        searchBar.resignFirstResponder()
        
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        
        searchActive = true;
        let s = searchBar.text
        
        //  searchBar.text.removeAll(keepCapacity: true)
        searchBar.setShowsCancelButton(false, animated: true)
        searchBar.resignFirstResponder()
        
        // for fym users
        if selectedTab ==  TabIdentifiers.tabFYM {
            
            // store users to tempoary user array
            // check whether the tempoary array contains value then values already exit
            if arrayFymUsertemp.count == 0 {
                arrayFymUsertemp = arrayFymUsers
            }
            
            // set offset 0
            offsetValue = 0
            
            // friends array set to empty
            arrayFymUsers = []
            
            // setting the search keyword
            searchKeyword = s!
            
            // get the list of users with search keyword
            getFymUsersList(offset: offsetValue, limit: 15, searchKeyword: searchKeyword, doLoadMore: false)
            
        }
        
        
    }
    // show the cancel button in the searchbar
    func searchBarShouldBeginEditing(searchBar: UISearchBar) -> Bool {
        searchBar.setShowsCancelButton(true, animated: true)
        return true
    }
    
    
    func searchBarShouldEndEditing(searchBar: UISearchBar) -> Bool {
        return true
    }
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        searchActive = true
        if searchText.isEmpty && selectedTab == TabIdentifiers.tabFYM {
            
            // load with previous data
            searchBarTextEmpty()
        }
        
        if(selectedTab == TabIdentifiers.tabContacts ) {
            
            // if search bar is empty ,reset the contacts details
            if searchBar.text!.isEmpty {
                searchActive = false;
                // fetchAddressBookContacts()
                resetAddressBookContacts()
                tableView.reloadData()
                
            }else {
                
                filterContentForSearchText(searchText)
                searchActive = true;
                
            }
        }
        
    }
    
    func filterContentForSearchText(searchText: String) {
        // filter the array using the filter method
        if arrayAddressBookContacts == nil {
            return
        }
        
        // refresh all the filtered array.
        filteredArray.removeAll(keepCapacity: true)
        filteredArray = temparrayAddressBookContacts!.filter({ (contact) -> Bool in
            let stringMatch = contact.contactName.lowercaseString.rangeOfString(searchText.lowercaseString)
            return (stringMatch != nil)
        })
        //print("\(filteredArray.count)")
        arrayAddressBookContacts = []
        arrayTableViewData = []
        
        self.configureSections(filteredArray)
    }
    
    // load more funcationality
    func dragTableDidTriggerLoadMore(tableView: UITableView!) {
        // called when the load more is selected
        if selectedTab == TabIdentifiers.tabFYM {
            offsetValue = self.arrayFymUsers.count
            getFymUsersList(false,offset: offsetValue!, limit:  5, searchKeyword: searchKeyword, doLoadMore: true)
        }else {
            finishLoadMore()
        }
        
    }
    
    func dragTableLoadMoreCanceled(tableView: UITableView!) {
        // called when the load more is cancelled
        NSObject.cancelPreviousPerformRequestsWithTarget(self, selector: Selector("finishLoadMore"), object: nil)
    }
    
    func finishLoadMore() {
        // to stop the load more and populate the tableview with new items
        tableView.finishLoadMore()
        tableView.reloadData()
    }
    
    // fetch the user details
    func getFymUsersList(shouldShowHUD: Bool = true,offset:Int,limit:Int,searchKeyword:String,doLoadMore:Bool){
        
        //  internet check
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        GetUsersResponse.getFymUsers(shouldShowHUD,offset: offset, andLimit:limit, keywords: searchKeyword
            , completionHandler: { (getUserResponse:GetUsersResponse) -> () in
                
                let response = getUserResponse
                if response.metaModel?.responseCode == 200 {
                    
                    if let set  = response.userDetailModel as [UserDetailModel]? {
                        for obj in set {
                            
                            //avoiding same userid in the list
                            if obj.userId == AppConfiguration.sharedAppConfiguration.userDetails?.userId {
                                //print("avoiding same userid")
                            }else {
                                self.arrayFymUsers.append(obj)
                            }
                        }
                    }
                    
                    if doLoadMore {
                        // finish the load more
                        self.tableView.finishLoadMore()
                        
                    }
                    if self.refreshControl != nil {
                        
                        // stop pull to refresh
                        self.refreshControl?.endRefreshing()
                    }
                    
                    self.tableView.reloadData()
                    self.tableView.hidden = false
                }
                
        })
    }
    
    // empty the search text and reset the values
    func searchBarTextEmpty() {
        
        // set keyword empty
        searchKeyword = ""
        
        if (arrayFymUsertemp.count > 0) {
            
            // store temporary offset value back to offset variable
            offsetValue = arrayFymUsertemp.count
            
            // store temporary array friends value back to friends array
            arrayFymUsers = self.arrayFymUsertemp
            
            // emptying the array-Fymusers
            arrayFymUsertemp = []
            
            // to reload tableview data
            self.tableView.reloadData()
            
        }
    }
    
    func triggerAlert(t: String,message m: String) {
        showAlert(t, message: m)
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if alertView == alert1 {
            
        } else if alertView == alert2 {
            
        }
    }
    func showAlert(title: String, message: String) {
        // show alert controller if possible else show alert view
        // configure alert
        if #available(iOS 8.0, *) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
            alert.addAction(UIAlertAction(title: &&"OK", style: .Cancel,  handler: { action in
                
                
            }))
            // show alert
            presentViewController(alert, animated: true, completion: nil)
            
        } else {
            // Fallback on earlier versions
            alert1 = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"OK")
            alert1?.show()
        }
        
    }
    
    @IBAction func buttonActionBack(sender: UIBarButtonItem) {
        self.navigationController?.popViewControllerAnimated(true)
        
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "kAddFriendProfileSegue" {
            let profileViewController = segue.destinationViewController as! ProfileViewController
            profileViewController.userId = sender as? String ?? ""
        }
        
        
    }
    
    
}
