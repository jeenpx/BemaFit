//
//  NewMessageViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/1/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

class NewMessageViewController: UIViewController, UITextViewDelegate, UIAlertViewDelegate {
    
    // hold choosen friend details
    var friend: FriendModel?
    
    @IBOutlet weak var textViewMessage: UITextView!
    @IBOutlet weak var labelPlaceholder: UILabel!
    
    // posted message
    var postedMessage = MessageItemModel()
    
    var placeHolderMessage = &&"message_post_placeholder_text"
    
    struct StoryBoard {
        struct Segues {
            static let CreateMessageToDetails = "kCreateMessageToDetails"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set placeholder
        labelPlaceholder.text = placeHolderMessage
        
        // configure the view
        configureView()
    }
    
    func configureView() {
        
        textViewMessage.becomeFirstResponder()
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        
        // text entered
        if text != "" {
            labelPlaceholder.hidden = true
        }
        else {
            // backspace
            
            // user presses backspace on single character
            if textView.text.characters.count == 1 {
                labelPlaceholder.hidden = false
            }
        }
        
        if text == "\n" {
            
            // pressed return key when no character
            if textView.text.characters.count == 0 {
                labelPlaceholder.hidden = false
            }
            
            textViewMessage.resignFirstResponder()
            return false
        }
        
        return true
    }
    
    func sendMessage(message: String, andFriendId friendId: String) {
        // send the message to the friend
        
        if textViewMessage.tag == 20 || message.trimmedString() == "" {
            
            // show alert
            showAlert(&&"new_message_alert_title", message: &&"new_message_alert_message")
        }
        else {
            MessageSendResponse.postMessage(message, andFriendId: friendId) { (sendMessage,meta) -> () in
                
                // response error
                if meta.responseCode != 200 {
                    self.showAlert(&&"notice", message: &&"failure_send")
                    return
                }
                
                // save posted message
                self.postedMessage = sendMessage
                NSNotificationCenter.defaultCenter().postNotificationName("RefreshMessageIdentifier", object: nil, userInfo: ["newMessage": self.postedMessage as AnyObject, "method": "Post"])
                
                //self.messageSendSuccessfulAlert(&&"notice", message: &&"message_send_success_alert")
                
                // navigate to message details
                self.performSegueWithIdentifier(StoryBoard.Segues.CreateMessageToDetails, sender: nil)
            }
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == StoryBoard.Segues.CreateMessageToDetails {
            let messageDetailsViewController = segue.destinationViewController as! MessageDetailsViewController
            messageDetailsViewController.selectedMessageThread = postedMessage
        }
    }
    
    @IBAction func buttonActionSend(sender: AnyObject) {
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        sendMessage(textViewMessage.text.trimmedString(), andFriendId: friend!.user_id!)
    }
    
    func showAlert(title: String, message: String) {
        if #available(iOS 8.0, *) {
            let alertView = UIAlertController(title: title,
                message: message, preferredStyle: .Alert)
            alertView.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
            presentViewController(alertView, animated: true, completion: nil)
        } else {
            // Fallback on earlier versions
            
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"ok").show()
        }
    }
}
