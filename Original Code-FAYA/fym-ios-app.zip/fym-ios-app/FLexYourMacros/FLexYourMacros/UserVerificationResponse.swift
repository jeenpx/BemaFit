//
//  UserFacebook.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 13/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _UserVerificationResponse = UserVerificationResponse()

class UserVerificationResponse: NSObject {
    
    var userVerificationModel: UserVerificationModel?
    var metaModel: MetaModel?

    class var sharedUserVerificationResponse: UserVerificationResponse {
        return _UserVerificationResponse
    }
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(UserVerificationResponse.metaModelKeyMapping)
        
        // give reference to accesstoken mapping
        responseMapping.addPropertyMapping(UserVerificationResponse.userVerificationModelKeyMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.verifyUserUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var userVerificationModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathVerifyUser, toKeyPath: "userVerificationModel", withMapping: UserVerificationModel.objectMapping)
    }
    
    class func verifyUser(userEmail: String, showHUD: Bool = true, userFacebookId: String, userName: String = "", completionHandler: (userVerificationModel: UserVerificationModel) -> (), failure: (failedWithError: String) -> ()) {
        
        if showHUD {
            SVProgressHUD.show()
        }

        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["email":userEmail as String, "facebook_id":userFacebookId as String, "username": userName]
        }
        
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(nil, method: .POST, path: Constants.ServiceConstants.verifyUserUrl, parameters: parameterDictionary, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
           
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            if showHUD {

            SVProgressHUD.dismiss()
            }

            // get the user response
            let userVerificationResponse = mappingResult.firstObject as! UserVerificationResponse
            
            // check for success
            if userVerificationResponse.metaModel?.responseCode != 200 {
                
                var errorMessage = userVerificationResponse.metaModel?.message ?? ""
                let errorMessages = userVerificationResponse.metaModel?.errormessages
                if errorMessages!.isEmpty {
                    
                } else {
                    
                    errorMessage = errorMessages?.first?.fieldMessage ?? ""
                }
                failure(failedWithError: errorMessage)
                return;
            }
            
            // set up the completion handler with response
            completionHandler(userVerificationModel: userVerificationResponse.userVerificationModel!)
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                if showHUD {

                    SVProgressHUD.dismiss() }

                failure(failedWithError: error.localizedDescription)
                //print("failed to load user verification with error \(error)")
        })

        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    
    }
    
}