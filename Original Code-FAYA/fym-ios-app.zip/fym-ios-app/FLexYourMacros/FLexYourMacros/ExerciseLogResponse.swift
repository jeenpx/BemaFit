//
//  ExerciseLogResponse.swift
//  FlexYourMacros
//
//  Created by mini on 26/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _ExerciseLogResponse = ExerciseLogResponse()

class ExerciseLogResponse: NSObject {
    
    var metaModel: MetaModel?
    var exerciseTypeResults: [ExerciseTypeModel]?
    
    class var sharedExerciseLogResponse: ExerciseLogResponse {
        return _ExerciseLogResponse
    }
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)

        // give referece to meta model
        responseMapping.addPropertyMapping(ExerciseLogResponse.metaModelKeyMapping)
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var exerciseTypeModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathExerciseTypeResult, toKeyPath: "exerciseTypeResults", withMapping: ExerciseTypeModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: responseMapping, method: .POST, pathPattern: Constants.ServiceConstants.ExerciseLogUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    class func logExercise(exerciseLogModel: ExerciseLogModel, completionHandler: (successful: Bool, message: String) -> ()) {
        
        RestKitManager.setToken(true)

        let request: NSMutableURLRequest = RestKitManager.sharedManager().requestWithObject(nil, method: .POST, path: Constants.ServiceConstants.ExerciseLogUrl, parameters: nil)
        
        request.HTTPBody = exerciseLogModel.toJson()
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        SVProgressHUD.show()

        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            SVProgressHUD.dismiss()

            let exerciseLogResponse = mappingResult.firstObject as! ExerciseLogResponse

            //print("respone status :\(exerciseLogResponse.metaModel?.responseStatus)")
            
            // check for success
            if exerciseLogResponse.metaModel?.responseCode != 200 {
                completionHandler(successful: false, message: exerciseLogResponse.metaModel!.message)
                return;
            }
            
            // set up the completion handler with response
            completionHandler(successful: true, message: exerciseLogResponse.metaModel!.message)
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                SVProgressHUD.dismiss()

                completionHandler(successful: false, message: "")

                //print("failed to log exercise with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)       
    }
    
}