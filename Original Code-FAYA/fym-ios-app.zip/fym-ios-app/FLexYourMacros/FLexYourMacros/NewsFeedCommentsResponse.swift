

//
//  NewsFeedCommentsResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 16/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class NewsFeedCommentsResponse: NSObject {
    
    var userId = ""
    var feedId = ""
    
    var metaModel = MetaModel()
    var pageMetaModel = PageMetaModel()
    var newsFeedComments = [NewsFeedComment]()
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
        responseMapping.addPropertyMapping(metaModelMapping)
        
        // newsfeedcomments mapping
        let newsFeedCommentsModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathNewsFeedComments, toKeyPath: "newsFeedComments", withMapping: NewsFeedComment.objectMapping)
        responseMapping.addPropertyMapping(newsFeedCommentsModelMapping)
        
        // page meta model mapping
        let pageMetaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathPageMeta, toKeyPath: "pageMetaModel", withMapping: PageMetaModel.objectMapping)
        responseMapping.addPropertyMapping(pageMetaModelMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let newFeedCommentsResponseDescriptor = RKResponseDescriptor(mapping: NewsFeedCommentsResponse.responseMapping, method: .Any, pathPattern: Constants.ServiceConstants.kNewsFeedCommentsUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return newFeedCommentsResponseDescriptor
    }
    
    class func fetchNewsFeedComments(feedId: String, params: [String: String], completionHandler: (newsFeedComments: [NewsFeedComment], pageMeta: PageMetaModel, error: NSError?) -> ()) {
        
        RestKitManager.setToken(true)
        
        let newsFeedCommentsResponse = NewsFeedCommentsResponse()
        newsFeedCommentsResponse.userId = AppConfiguration.sharedAppConfiguration.userDetails?.userId ?? ""
        newsFeedCommentsResponse.feedId = feedId
        
        RestKitManager.sharedManager().getObject(newsFeedCommentsResponse, path: nil, parameters: params, success: { (operation, mappingResult) in
            
            // map to correct datamodel
            let response = mappingResult.firstObject as! NewsFeedCommentsResponse
            
            if response.metaModel.responseCode != 200 {
                let error = NSError(domain: "FYM.NewsFeed", code: 1001, userInfo: ["title": "error", "message": "alert_feed_comments_list_message"])
                
                // fire completion handler
                completionHandler(newsFeedComments: [], pageMeta: PageMetaModel(), error: error)
                
            }
            else {
                // fire completion handler
                completionHandler(newsFeedComments: response.newsFeedComments, pageMeta: response.pageMetaModel, error: nil)
            }
            
            }) { (operation, error) -> Void in
                // error
                let networkError = NSError(domain: "FYM.NewsFeed", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
                
                // fire completion handler
                completionHandler(newsFeedComments: [], pageMeta: PageMetaModel(), error: networkError)
        }
    }
    
}