//
//  ProgressLastLog.swift
//  FlexYourMacros
//
//  Created by mini on 20/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
import CoreData
@objc(ProgressLastLog)

class ProgressLastLog: NSManagedObject {

    @NSManaged var body_fat: String
    @NSManaged var log_date: String
    @NSManaged var weight: String
    @NSManaged var calorie: String
    @NSManaged var amount: String

    @NSManaged var progressLastLogType: NSSet
    
    class var entityMapping : RKEntityMapping {
        
        var progressLastLogMapping: RKEntityMapping = RKEntityMapping(forEntityForName: Constants.Tables.ProgressLastLog, inManagedObjectStore: RestKitManager.sharedManager().managedObjectStore)
        progressLastLogMapping .addAttributeMappingsFromDictionary(mappingDictionary)
//        progressLastLogMapping.identificationAttributes = ["progressLastLogType"]

        return progressLastLogMapping
    }
    
    private class var mappingDictionary: [String : String] {
        
        return(["body_fat":"body_fat", "log_date":"log_date", "weight":"weight", "calorie": "calorie", "amount" : "amount"])
    }
    
    class func fetchProgressLastLogDetails(progressType: String, completionHandler:(lastLogDetails: [AnyObject])->()) {
        
        var error: NSError?
        let fetchRequest = NSFetchRequest()
        let entity = NSEntityDescription.entityForName(Constants.Tables.ProgressLastLog, inManagedObjectContext: RKObjectManager.sharedManager().managedObjectStore.persistentStoreManagedObjectContext)
        fetchRequest.returnsObjectsAsFaults = false
        fetchRequest.entity = entity
      

        let progressPredicate = NSPredicate(format: "SUBQUERY(progressLastLogType, $x, $x.type = %@).@count == progressLastLogType.@count",progressType)
        
        fetchRequest.predicate = progressPredicate
        
        var count = 1
        count = RKObjectManager.sharedManager().managedObjectStore.persistentStoreManagedObjectContext.countForFetchRequest(fetchRequest, error: &error)
        fetchRequest.fetchLimit = count
        
        let sortDescriptor = NSSortDescriptor(key: "log_date", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]

        let fetchedObjects: [AnyObject]?
        do {
            fetchedObjects = try RKObjectManager.sharedManager().managedObjectStore.persistentStoreManagedObjectContext .executeFetchRequest(fetchRequest)
        } catch var error1 as NSError {
            error = error1
            fetchedObjects = nil
        }
        completionHandler(lastLogDetails: fetchedObjects!)
    }

}
