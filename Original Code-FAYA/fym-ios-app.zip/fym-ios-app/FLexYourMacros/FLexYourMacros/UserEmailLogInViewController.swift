//
//  UserEmailLogInViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 11/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UserEmailLogInViewController: UITableViewController, UIAlertViewDelegate {
    
    @IBOutlet weak var textFieldEmail: UITextField!
    @IBOutlet weak var textFieldPassword: UITextField!
    
    var currentTextField = UITextField()
    
    override func viewWillAppear(animated: Bool) {
        // hides navigation bar
        navigationController?.navigationBarHidden = false
        let titleDictionary: NSDictionary = [NSForegroundColorAttributeName: UIColor.whiteColor()]
        self.navigationController?.navigationBar.titleTextAttributes = titleDictionary as? [String : AnyObject]
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if AppConfiguration.sharedAppConfiguration.isFacebookUser {
            textFieldEmail.text = UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserEmail
        } else {
            
            textFieldEmail.text = AppConfiguration.sharedAppConfiguration.userDetails?.userEmail
        }
        
        // hides navigation bar
        navigationController?.navigationBarHidden = false
        let titleDictionary: NSDictionary = [NSForegroundColorAttributeName: UIColor.whiteColor()]
        self.navigationController?.navigationBar.titleTextAttributes = titleDictionary as? [String : AnyObject]
        
        // Remove separator Inset of Table view
        
        if #available(iOS 8.0, *) {
            tableView.layoutMargins = UIEdgeInsetsZero
        } else {
            // Fallback on earlier versions
            tableView.separatorInset = UIEdgeInsetsZero
        };
        
    }
    
    @IBAction func unwindToUserEmailLoginViewController(segue: UIStoryboardSegue) {
        
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        
        currentTextField = textField
    }
    
    func textFieldShouldReturn(textField: UITextField!) -> Bool {
        // resign keyboard
        textField.resignFirstResponder()
        return false
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    @IBAction func buttonActionUserLogIn(sender: UIButton) {
        
        currentTextField.resignFirstResponder()
        // check whether email or password is empty
        if textFieldEmail.isEmpty {
            
            showAlert(&&"notice", message: &&"email_validity")//"Please enter a email")
            return
        } else if textFieldPassword.isEmpty {
            
            showAlert(&&"notice", message: &&"password_validity")//"Please enter a password")
            return
        }
        else if !textFieldEmail.isValidEmailAddress{
            showAlert("notice", message: &&"email_validity")//"Please enter a valid email")
            return
        }
        
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        UserLogInResponse.logInUser(self, username: textFieldEmail.text!, password: textFieldPassword.text!, completionHandler: { (accessCredential, userDiet, userDetails) -> () in
            
            AppConfiguration.sharedAppConfiguration.userDetails = userDetails
            
            AppConfiguration.sharedAppConfiguration.userDiet = userDiet
            
            AppConfiguration.sharedAppConfiguration.userCredential = accessCredential
            
            //print("accesstoken:\(AppConfiguration.sharedAppConfiguration.userCredential?.accessToken)")
            //print("userid:\(AppConfiguration.sharedAppConfiguration.userDetails?.userId)")
            
            self.appDelegate?.checkUserVerification({ (verifiedStatus) -> () in
                
                if !verifiedStatus {
                    
                    let userDefaults = NSUserDefaults.standardUserDefaults()
                    
                    AppConfiguration.sharedAppConfiguration.userEmail = userDefaults.objectForKey("user_email") as! String
                    
                    let alert =  UIAlertView(title: &&"notice", message: &&"To continue using the app, please verify the registered email", delegate: self, cancelButtonTitle: &&"ok", otherButtonTitles: &&"resend_email")
                    alert.tag = 2
                    alert.show()
                    
                } else {
                    
                    self.appDelegate?.loadDashboard()
                }
            })
            
            }) { (error) -> () in
                
                self.showAlert(&&"notice", message: error)
        }
        
    }
    
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if alertView.tag == 2 {
            
            if buttonIndex == 1 {
                
                
                // resend email api called
                ResendEmailResponse.resendEmail(AppConfiguration.sharedAppConfiguration.userEmail, completionHandler: { (resendEmailResponse) -> () in
                    
                    if resendEmailResponse == nil {
                        UIAlertView(title: &&"notice", message: &&"failed_resend_email", delegate: nil, cancelButtonTitle: &&"ok").show()
                        
                        return }
                    if resendEmailResponse!.status == "OK" {
                        
                        UIAlertView(title: &&"email_sent", message: &&"check_the_email_1" + "\(AppConfiguration.sharedAppConfiguration.userEmail). " + &&"check_the_email_2", delegate: nil, cancelButtonTitle: &&"ok").show()
                        
                    }
                })
                
                self.appDelegate?.loadLogin()
                
            } else {
                self.appDelegate?.loadLogin()
            }
        }
    }
    
    func showAlert(title: String, message: String) {
        
        if #available(iOS 8.0, *) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
            
            alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
            
            self.presentViewController(alert, animated: true, completion: nil)
        } else {
            // Fallback on earlier versions
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: "ok").show()
        }
    }
    
    override func  tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        cell.setSeparatorInsetZero()
        
    }
    
}
