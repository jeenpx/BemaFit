//
//  ProgressChartTableViewCell.swift
//  FlexYourMacros
//
//  Created by DBG on 17/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ProgressChartTableViewCell: UITableViewCell {
    
    weak var chartView: ScatterPlotView!
    weak var barPlotView: GroupedBarChartView!
    
    @IBOutlet weak var labelNoDataScatterPlot: UILabel!
    @IBOutlet weak var labelNoDataGroupedChart: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        labelNoDataScatterPlot.transform = CGAffineTransformMakeScale(1.0, -1.0)
        labelNoDataGroupedChart.transform = CGAffineTransformMakeScale(1.0, -1.0)
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    let arrayData: [Double] = [0.0, 2.0, 15.0, 12.9, 25.0, 6.5, 10.0, 3.8, 4.5, 11.0]
    
    var xAxisData:[String] = []
    
    var chartData:[[ProgressReport]] = [] {
        
        didSet {
            
            var averageArray = [Double]()
            
            if progressType == ProgressType.Weight {
                
                self.chartView.hidden = false
                self.barPlotView.hidden = true
                averageArray = chartData.map({ progressReports in
                    
                    let itemArray: [Double] = progressReports.map { return $0.weight.doubleValue }
                    let itemTotal: Double   = itemArray.reduce(0) { return $0 + $1 }
                    return itemArray.count != 0 ? Double(itemTotal) / Double(itemArray.count) : 0.0
                })
                
                chartView.xAxisLabels = xAxisData
                chartView.chartViewData = averageArray
                labelNoDataScatterPlot.hidden = averageArray.count == 0 ? false : true
                
            } else if progressType == ProgressType.Bodyfat {
                
                self.chartView.hidden = false
                self.barPlotView.hidden = true
                averageArray = chartData.map({ progressReports in
                    
                    let itemArray: [Double] = progressReports.map { return $0.bodyfat.doubleValue }
                    let itemTotal: Double   = itemArray.reduce(0) { return $0 + $1 }
                    return itemArray.count != 0 ? Double(itemTotal) / Double(itemArray.count) : 0.0
                })
                
                chartView.xAxisLabels = xAxisData
                chartView.chartViewData = averageArray
                labelNoDataScatterPlot.hidden = averageArray.count == 0 ? false : true

                
            }else if  progressType == ProgressType.Exercise && exerciseType == ExerciseCategory.Strength {
                
                self.chartView.hidden = false
                self.barPlotView.hidden = true
                averageArray = chartData.map({ progressReports in
                    
                    let itemArray: [Double] = progressReports.map { return $0.calorie.doubleValue }
                    let itemTotal: Double   = itemArray.reduce(0) { return $0 + $1 }
                    return itemArray.count != 0 ? Double(itemTotal) / Double(itemArray.count) : 0.0
                })
                
                chartView.xAxisLabels = xAxisData
                chartView.chartViewData = averageArray
                labelNoDataScatterPlot.hidden = averageArray .reduce(0) { return $0 + $1 } > 0 ? true : false

            } else if  progressType == ProgressType.Exercise && exerciseType == ExerciseCategory.CardioVascular {
                
                self.chartView.hidden = false
                self.barPlotView.hidden = true
                averageArray = chartData.map({ progressReports in
                    
                    let itemArray: [Double] = progressReports.map { return $0.amount.doubleValue }
                    let itemTotal: Double   = itemArray.reduce(0) { return $0 + $1 }
                    return itemArray.count != 0 ? Double(itemTotal) / Double(itemArray.count) : 0.0
                })
                
                chartView.xAxisLabels = xAxisData
                chartView.chartViewData = averageArray
                labelNoDataScatterPlot.hidden = averageArray .reduce(0) { return $0 + $1 } > 0 ? true : false
                
            } else if progressType == ProgressType.Macros {
               
                self.chartView.hidden = true
                self.barPlotView.hidden = false
                
                var macroPercentageArray = [[Double]]()
                
                let macroRequired = self.macroDailyRequirement.first

                macroPercentageArray = chartData.map({ progressReports in
                    
                    let calorieDayArray: [Double] = progressReports.map { return $0.calorie.doubleValue }
                    let calorieDayTotal: Double   = calorieDayArray.reduce(0) { return $0 + $1 }
                    
                    //protein calculation
                    let proteinDayArray: [Double] = progressReports.map { return $0.protein.doubleValue }
                    let proteinDayTotal: Double   = proteinDayArray.reduce(0) { return $0 + $1 }
                    
                    //fat calculation
                    let fatDayArray: [Double] = progressReports.map { return $0.fat.doubleValue }
                    let fatDayTotal: Double   = fatDayArray.reduce(0) { return $0 + $1 }
                    
                    //carb calculation
                    let carbDayArray: [Double] = progressReports.map { return $0.carb.doubleValue }
                    let carbDayTotal: Double   = carbDayArray.reduce(0) { return $0 + $1 }
                    
                    //fibre calculation
                    let fibreDayArray: [Double] = progressReports.map { return $0.fibre.doubleValue }
                    let fibreDayTotal: Double   = fibreDayArray.reduce(0) { return $0 + $1 }
                    
                    return [self.getThePercentageValue(calorieDayTotal, total: macroRequired!.calories_total), self.getThePercentageValue(proteinDayTotal, total: macroRequired!.protein_total), self.getThePercentageValue(fatDayTotal, total: macroRequired!.fat_total), self.getThePercentageValue(carbDayTotal, total: macroRequired!.carbs_total), self.getThePercentageValue(fibreDayTotal,total: macroRequired!.fiber_total)]
                })
                
                //print("macro sorted array-----\(macroPercentageArray)")
                self.barPlotView.xAxisLabels =  macroPercentageArray.count == 0 ? [] : xAxisData
                self.barPlotView.chartViewData = macroPercentageArray
                labelNoDataGroupedChart.hidden = macroPercentageArray.count == 0 ? false : true
            }
        }
    }
    
    var macroDailyRequirement = [DailyRequirement]()
    
    func getThePercentageValue(value: Double, total: String) -> Double {
        
        if total.doubleValue <= 0.0 {
            return 0.0
        }
        if value > total.doubleValue {
            return 100.0
        }
        return (value / total.doubleValue) * 100.0
    }
    
    var progressType: ProgressType = ProgressType.Weight
    var exerciseType: ExerciseCategory = ExerciseCategory.CardioVascular
}
