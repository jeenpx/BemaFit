//
//  InviteFriendResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 27/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FriendRequestResponseModel: NSObject {
    
    var userId: String?

    class var objectMapping: RKObjectMapping {
        let mapping = RKObjectMapping(forClass: self)
        mapping.addAttributeMappingsFromDictionary(mappingDictionary)
        // give reference to accesstoken mapping        return metaMapping
        return mapping
    }
    
    class var mappingDictionary: [String : String] {
        return(["userId":"userId"])
    }
}


class InviteFriendResponse: NSObject {
    
    var metaModel: MetaModel?
    var friendRequestResponseModel: FriendRequestResponseModel?
    var userId: String?

    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(InviteFriendResponse.metaModelKeyMapping)
        responseMapping.addPropertyMapping(InviteFriendResponse.friendRequestResponseModel)

        return responseMapping
    }
    
    // for invite via userId - FYM Friends
    class var userResponseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.sendFriendsRequestUrl1, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    // for the email invite - Contact Friends
    class var userResponseDescriptorForEmailInvite: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.inviteFriendsUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }

    
   // for invite via userId - FYM Friends
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    // for invite via userId - FYM Friends
    private class var friendRequestResponseModel : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathFriendRequest, toKeyPath: "friendRequestResponseModel", withMapping: FriendRequestResponseModel.objectMapping)
    }
    
    class func sendInvitationFriend(userId:String,completionHandler: (response:InviteFriendResponse) -> ()) {
        RestKitManager.setToken(true)
        
        let invitationResponse = InviteFriendResponse()
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["user_id":userId]
        }
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(nil, method: .POST, path:Constants.ServiceConstants.sendFriendsRequestUrl1, parameters: parameterDictionary, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })

        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let inviteFriendResponse = mappingResult.firstObject as! InviteFriendResponse
            //print("respone code :\(inviteFriendResponse.metaModel?.responseCode)")
            //print("respone status :\(inviteFriendResponse.metaModel?.responseStatus)")
            
            //print("fired completion handler for the user***")
            completionHandler(response: inviteFriendResponse)
            
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                //print("failed to load send invitation with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
    
    // for the email invite - Contact Friends
    class func sendInvitationFriendViaEmail(emailAddress:String,completionHandler: (response:InviteFriendResponse) -> ()) {
        RestKitManager.setToken(true)
        
        let invitationResponse = InviteFriendResponse()
        invitationResponse.userId = AppConfiguration.sharedAppConfiguration.userDetails!.userId
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["email": emailAddress]
        }
        
        //print("invitation parameters are \(parameterDictionary)")
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(invitationResponse, method: .POST, path:nil, parameters: parameterDictionary, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let inviteFriendResponse = mappingResult.firstObject as! InviteFriendResponse
            //print("respone code :\(inviteFriendResponse.metaModel?.responseCode)")
            //print("respone status :\(inviteFriendResponse.metaModel?.responseStatus)")
            
            completionHandler(response: inviteFriendResponse)
            
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                //print("failed to load send invitation with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }

    
}
