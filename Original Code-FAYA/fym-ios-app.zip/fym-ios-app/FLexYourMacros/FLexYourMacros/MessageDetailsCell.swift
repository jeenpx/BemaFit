//
//  MessageDetailsCell.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/7/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class MessageDetailsCell: UITableViewCell {
    
    @IBOutlet weak var labelMessage: UILabel!
    @IBOutlet weak var imageViewProfilePic: UIImageView!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelTime: UILabel!
    
    var userProfileDelegate: UserProfileDelegate?
    
    // set values for ui elements
    var messageThreadModel: MessageItemModel? {
        didSet {
            labelMessage.text = messageThreadModel?.message
            labelName.text = messageThreadModel?.senderUserName
            
            labelName.userInteractionEnabled = true
            let tapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
            tapGesture.delegate = self
            
            // add tap gesture to the username label
            labelName.addGestureRecognizer(tapGesture)
            
            if let date = messageThreadModel?.createdDate {
                let newDate = date.utcDateValue("yyyy-MM-dd HH:mm:ss")
                labelTime.text = newDate?.timeAgo()
            }
            
            imageViewProfilePic.setImageWithURL(NSURL(string: messageThreadModel!.senderPhoto!), placeholderImage: UIImage(named: "PlaceHolderProfilePic"))
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func didTaplabelUserNameWithGesture(tapGesture: UITapGestureRecognizer) {
        //print("didTaplabelUserNameWithGesture entered...")
        userProfileDelegate?.userProfile(MessageItemModel.getMessageFriend(messageThreadModel!).friendId)
    }
    
}
