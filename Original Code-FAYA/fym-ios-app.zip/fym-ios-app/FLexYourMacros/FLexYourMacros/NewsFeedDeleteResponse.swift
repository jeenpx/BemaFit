//
//  NewsFeedDeleteResponse.swift
//  FlexYourMacros
//
//  Created by dbgattila on 12/3/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class NewsFeedDeleteResponse: NSObject {

    // model instance variables
    var meta: MetaModel?
    
    // route instance variables
    var userId: String?
    var feedId: String?
    
    // message delete response mapping
    class var newsFeedDeleteResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(NewsFeedDeleteResponse.metaModelKeyMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: newsFeedDeleteResponseMapping, method: .DELETE, pathPattern: Constants.ServiceConstants.kNewsFeedDeleteUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    class func deleteNewsFeed(newsFeedId: String, completionHandler: (responseStatus: String) -> ()) {
        // delete the news feed comment
        
        // set access token
        RestKitManager.setToken(true)
        
        let newsFeedDeleteResponse = NewsFeedDeleteResponse()
        newsFeedDeleteResponse.userId = AppConfiguration.sharedAppConfiguration.userDetails?.userId
        newsFeedDeleteResponse.feedId = newsFeedId
        
        RestKitManager.sharedManager().deleteObject(newsFeedDeleteResponse, path: nil, parameters: nil, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
            
            //print("Success")
            let deleteResponseObject = mappingResult.firstObject as! NewsFeedDeleteResponse
            
            if let responseMeta = deleteResponseObject.meta {
                
                // completion handler
                completionHandler(responseStatus: responseMeta.responseStatus!)
            }
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                //print("error \(error)");
                
        })        
    }
}
