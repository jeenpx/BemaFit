//
//  ScatterPlotView.swift
//  ChartViews
//
//  Created by DBG-39 on 21/04/15.
//  Copyright (c) 2015 DBG-39. All rights reserved.
//

import Foundation

class ScatterPlotView: CPTGraphHostingView, CPTPlotAreaDelegate, CPTPlotSpaceDelegate, CPTPlotDataSource, CPTScatterPlotDelegate {
    
    var check: Bool = false
    
    var chartViewXIndex = [Int]()
    var  xAxisLabels    = [String]()
    let themeBlueColor = UIColor(red: 30.0/255.0, green: 144.0/255.0, blue: 255.0/255.0, alpha: 1.0)
    
    
    var chartViewData: [Double]? {
        didSet {
            
            chartViewXIndex = [Int]()
            
            for var i = 0; i < chartViewData?.count; i++ {
                
                chartViewXIndex.append(i)
            }
            // create graph hosting view if not exists
            //            if hostedGraph == nil {
            configureGraph()
            //            }
            
        }
        
        // reload graph
    }
    
    var xMaximum: Int? {
        
        return chartViewXIndex.isEmpty ? 1 : chartViewXIndex.reduce(Int.min, combine: { max($0, $1) })
    }
    
    var yMaximum: Double? {
        
        return (chartViewData?.isEmpty != nil) ? chartViewData?.reduce(DBL_MIN, combine: {max($0!, $1)}) : 1.0
    }
    
    var xDivision: Double? {
        
        return chartViewXIndex.isEmpty ? 1.0 : Double(xMaximum! / chartViewXIndex.count-1)
    }
    
    var yDivision: Double? {
        
        return (chartViewData?.isEmpty != nil) ? yMaximum! / 10 : 1.0
        
    }
    
    
    func configureGraph() {
        
        hostedGraph = CPTXYGraph(frame: self.bounds)
        // Plot area delegate
        hostedGraph.plotAreaFrame.plotArea.delegate = self;
        hostedGraph.plotAreaFrame.scrollPoint(CGPointMake(0, 0))
        hostedGraph.plotAreaFrame.paddingLeft =  25.0+CGFloat((yMaximum!.stringValue).characters.count )
        hostedGraph.plotAreaFrame.masksToBorder = false
        allowPinchScaling = false

        
        // Setup scatter plot space
        let plotSpace = hostedGraph.defaultPlotSpace as! CPTXYPlotSpace
        plotSpace.allowsUserInteraction = true;
        plotSpace.allowsMomentum        = false;
        plotSpace.delegate              = self;
        
        // Grid line styles
        let majorGridLineStyle = CPTMutableLineStyle()
        majorGridLineStyle.lineWidth = 0.75;
        majorGridLineStyle.lineColor = CPTColor.lightGrayColor()
        
        let minorGridLineStyle = CPTMutableLineStyle()
        minorGridLineStyle.lineWidth = 0.25
        minorGridLineStyle.lineColor = CPTColor.whiteColor().colorWithAlphaComponent(0.1)
        
        // Axes
        // Label x axis with a fixed interval policy
        let axisSet = hostedGraph.axisSet as! CPTXYAxisSet
        let x          = axisSet.xAxis as CPTXYAxis
        x.majorIntervalLengthNumber         = 2 * xDivision!
        x.orthogonalCoordinateDecimalNumber = 0.0
        x.preferredNumberOfMajorTicks = 8
        x.labelingPolicy = CPTAxisLabelingPolicy.None
        
        //  make the custom labels
        var labelLocation     = 0
        var customLabels   = NSMutableSet(capacity: xAxisLabels.count)
        
        for  tickLocation in chartViewXIndex  {
            let newLabel = CPTAxisLabel(text: xAxisLabels[labelLocation++], textStyle: x.labelTextStyle) as CPTAxisLabel
            newLabel.tickLocationNumber = tickLocation
            newLabel.offset = x.labelOffset
            customLabels .addObject(newLabel)
        }
        
        x.axisLabels = customLabels as Set<NSObject>;
        x.minorTicksPerInterval       = 0
        x.labelOffset                 = -5.0
        x.titleOffset   = 30.0
        x.titleLocationNumber = 1.2
        if chartViewData?.count == 0 {
            x.hidden = true
        
        }
        else {
            
            x.hidden = false
        }
        x.axisConstraints = CPTConstraints.constraintWithRelativeOffset(0.0)//(0.0)
        
        
        // Label y with an automatic label policy.
        let y = axisSet.yAxis as CPTXYAxis
        y.hidden = true
        y.orthogonalCoordinateDecimalNumber = 0.0
        y.majorIntervalLengthNumber = 2*yDivision!
        y.minorTicksPerInterval       = 0
        y.preferredNumberOfMajorTicks = 8
        y.majorGridLineStyle          = majorGridLineStyle
        y.minorGridLineStyle          = minorGridLineStyle
        y.labelOffset                 = -5
        y.titleOffset   = 30.0
        y.titleLocationNumber = 1.0
        y.axisConstraints = CPTConstraints.constraintWithLowerOffset(0.0)
        
        // Create a plot that uses the data source method
        let dataSourceLinePlot = CPTScatterPlot(frame: CGRectZero)
        dataSourceLinePlot.identifier = "Data Source Plot"
        
        let lineStyle = dataSourceLinePlot.dataLineStyle.mutableCopy() as! CPTMutableLineStyle
        lineStyle.lineWidth              = 1.5
        lineStyle.lineJoin               = CGLineJoin.Round
        lineStyle.lineGradient           = CPTGradient(beginningColor: CPTColor(componentRed: 65.0/255.0, green: 105.0/255.0, blue: 225.0/255.0, alpha: 1.0), endingColor: CPTColor.whiteColor())
        dataSourceLinePlot.dataLineStyle = lineStyle
        dataSourceLinePlot.dataSource    = self
        hostedGraph.addPlot(dataSourceLinePlot)
        
        // Put an area gradient under the plot above
        let areaColor       = CPTColor(componentRed: 30.0/255.0, green: 144.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        let areaGradient = CPTGradient(beginningColor: areaColor, endingColor: CPTColor.whiteColor())
        areaGradient.angle = -90.0
        let areaGradientFill = CPTFill(gradient: areaGradient) as CPTFill
        dataSourceLinePlot.areaFill      = areaGradientFill
        dataSourceLinePlot.areaBaseValueNumber = 0.0
        
        // Auto scale the plot space to fit the plot data
        // Extend the ranges by 30% for neatness
        plotSpace.scaleToFitPlots([dataSourceLinePlot])
        let xRange = plotSpace.xRange.mutableCopy() as! CPTMutablePlotRange
        let yRange = plotSpace.yRange.mutableCopy() as! CPTMutablePlotRange
        xRange.expandRangeByFactorNumber(1.0)
        yRange.expandRangeByFactorNumber(4.0)
        plotSpace.xRange = xRange
        plotSpace.yRange = yRange
        
        // Restrict y range to a global range
        let globalYRange = CPTPlotRange(locationNumber: 0.0, lengthNumber: yMaximum! +  yDivision! )
        plotSpace.globalYRange = globalYRange
        
        // Add plot symbols
        let symbolGradient = CPTGradient(beginningColor: areaColor, endingColor: areaColor) as CPTGradient
        symbolGradient.gradientType = CPTGradientType.Radial
        symbolGradient.startAnchor  = CGPointMake(0.25, 0.75)
        let plotSymbol = CPTPlotSymbol.ellipsePlotSymbol() as CPTPlotSymbol
        plotSymbol.fill               = CPTFill(gradient: symbolGradient)
        plotSymbol.lineStyle          = nil
        plotSymbol.size               = CGSizeMake(9.0, 9.0)
        dataSourceLinePlot.plotSymbol = plotSymbol
        
        // Set plot delegate, to know when symbols have been touched
        // We will display an annotation when a symbol is touched
        dataSourceLinePlot.delegate                        = self;
        dataSourceLinePlot.plotSymbolMarginForHitDetection = 5.0;
        
        hostedGraph.reloadData()
        
    }
    
    // plot datasource methods
    func numberOfRecordsForPlot(plot: CPTPlot!) -> UInt {
        return UInt(chartViewData!.count)
    }
    
    func numberForPlot(plot: CPTPlot!, field fieldEnum: UInt, recordIndex idx: UInt) -> AnyObject! {
        var indexValue: NSNumber = 0
        
        switch fieldEnum {
        case 0:
            indexValue = chartViewXIndex[Int(idx)]
        case 1:
            indexValue = chartViewData![Int(idx)]
        default:
            break
        }
        return indexValue
    }
    
    func plotSpace(space: CPTPlotSpace!, willChangePlotRangeTo newRange: CPTPlotRange!, forCoordinate coordinate: CPTCoordinate) -> CPTPlotRange! {
        
        var returnRange = CPTPlotRange()
        
        // Impose a limit on how far user can scroll in x
        let maxRange = CPTPlotRange(locationNumber: -1.0, lengthNumber:2*xMaximum!) as CPTPlotRange
        let changedRange = newRange.mutableCopy() as! CPTMutablePlotRange
        changedRange.shiftEndToFitInRange(maxRange)
        changedRange.shiftLocationToFitInRange(maxRange)
        returnRange = changedRange;
        return returnRange
    }
}