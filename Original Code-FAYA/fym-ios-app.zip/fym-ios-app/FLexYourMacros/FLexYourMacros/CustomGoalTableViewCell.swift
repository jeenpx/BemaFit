//
//  CustomGoalTableViewCell.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 18/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class CustomGoalTableViewCell: UITableViewCell {

    let FymUserModel = FymUser.sharedFymUser

    @IBOutlet weak var textFieldCustomGoal: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
        if FymUserModel.userCustomCalorie != 0.0 {
            textFieldCustomGoal.text =  String(stringInterpolationSegment: FymUserModel.userCustomCalorie)
        }
    }
}
