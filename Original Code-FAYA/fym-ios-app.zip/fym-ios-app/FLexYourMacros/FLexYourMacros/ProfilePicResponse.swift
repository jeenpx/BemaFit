//
//  ProfilePicResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 15/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ProfilePicResponse: NSObject {
 
    var metaModel: MetaModel?
    var user_id: String?
    var changeProfileModel: ProfilePicModel?
    
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        // give referece to meta model
        responseMapping.addPropertyMapping(ProfilePicResponse.metaModelKeyMapping)
        responseMapping.addPropertyMapping(ProfilePicResponse.profilePicModelMapping)
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    
    private class var profilePicModelMapping :RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathChangeProfilePic, toKeyPath: "changeProfileModel", withMapping: ProfilePicModel.objectMapping )
    }
    
    class var userResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: RKRequestMethod.POST, pathPattern: Constants.ServiceConstants.ChangeProfilePicUrl ,keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }

    
    
    class func changeUserPic(completionHandler: (profilePicResponse:ProfilePicResponse) -> ()) {
        
        RestKitManager.setToken(true)
        //print("headers are  \(RKObjectManager.sharedManager().defaultHeaders)");
        let changeProfilePicResponse = ProfilePicResponse()
        changeProfilePicResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
        var parameterDictionary: [String:String] = ["":""]        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(changeProfilePicResponse, method: RKRequestMethod.POST, path: nil, parameters: parameterDictionary, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
           if FymUser.sharedFymUser.userImage != nil {
                   //print("image found is done ")
                formData.appendPartWithFileData(UIImageJPEGRepresentation(FymUser.sharedFymUser.userImage!, 0.0), name :"photo", fileName :"photo.png", mimeType :"image/png") }
        }

)
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let response = mappingResult.firstObject as! ProfilePicResponse
            //print("respone code :\(response.metaModel?.responseCode)")
            //print("respone status :\(response.metaModel?.responseStatus)")
            
            // check for success
            if response.metaModel?.responseCode == 200 {
                completionHandler(profilePicResponse: response)
            }
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                //print("failed to load  with error \(error)")
        })
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
        
    }
    
    
}
