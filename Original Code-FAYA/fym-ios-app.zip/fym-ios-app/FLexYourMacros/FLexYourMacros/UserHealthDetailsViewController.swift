//
//  UserHealthDetailsViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 05/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

enum Gender: String {
    case Male   = "male"
    case Female = "female"
    
    static var genderTypes = [Male, Female]
    
    var description: String {
        switch self {
        case .Male : return "M"
        case .Female : return "F"
        }
    }
}

class UserHealthDetailsViewController: UITableViewController, UITextFieldDelegate, UIAlertViewDelegate {
    
    @IBOutlet weak var segmentGender: UISegmentedControl!
    @IBOutlet weak var textFieldDOB: UITextField!
    @IBOutlet weak var textFieldHeight: UITextField!
    //height in unit -- height in inches
    @IBOutlet weak var textFieldHeightUnits: UITextField!
    @IBOutlet weak var textFieldWeight: UITextField!
    @IBOutlet weak var textFieldBodyFat: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var toolBar: UIToolbar!
    var currentTextField = UITextField()
    internal var canDismissView = true
    var alert = UIAlertView()

    let FymUserModel = FymUser.sharedFymUser
    
    internal var canAbort = false
    
    struct StoryBoard {
        
        struct SegueIdentifiers {
            static let FormulaSelect = "kFormulaSelect"
        }
    }

    private var gender = Gender.Male {
        didSet {
            
            //print("gender description ------\(gender.description)")
           FymUserModel.userGender = gender.description
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldDOB.inputView = datePicker
        textFieldDOB.inputAccessoryView = toolBar
        
        setDatePickerMaximumDate()
        
        // initialize userGender with male
        if FymUserModel.userGender == "" {
            gender = Gender.Male
        }
    }
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        // view is active, should not abort
        canAbort = false
        canDismissView = true
        loadWithExistingCredentials()
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        // view is inactive, abort all checks
        canAbort = true
        alert.dismissWithClickedButtonIndex(0, animated: false)
    }
    
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(animated)
        alert.dismissWithClickedButtonIndex(0, animated: false)
    }

    func textFieldDidBeginEditing(textField: UITextField) {
        currentTextField = textField
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        // managing the textfield input: limit the characters to only of numeric type
        var result = true
        
        let prospectiveText = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        if string.characters.count > 0 {
            let disallowedCharacterSet = NSCharacterSet(charactersInString: allowString).invertedSet
            let replacementStringIsLegal = string.rangeOfCharacterFromSet(disallowedCharacterSet) == nil
            let resultingStringLengthIsLegal = prospectiveText.characters.count <= 6
            let scanner = NSScanner(string: prospectiveText)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
            result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
        }
        
        switch textField {
        case textFieldHeight, textFieldHeightUnits, textFieldBodyFat:
            return textField.text!.characters.count + string.characters.count - range.length <= 2
        case textFieldWeight:
            return textField.text!.characters.count + string.characters.count - range.length <= 3
        default:
            break
        }
        return result
    }
    
    var allowString: String {
        
        if currentTextField == textFieldHeight || currentTextField == textFieldHeightUnits {
            
            return "0123456789"
        }
        
        return "0123456789."
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        // resign keyboard
        textField.resignFirstResponder()
        return true
    }
    
    func didPresentAlertView(alertView: UIAlertView) {
        canDismissView = false
    }
    
    func alertViewCancel(alertView: UIAlertView) {
        canDismissView = true
    }
    
    func alertView(alertView: UIAlertView, didDismissWithButtonIndex buttonIndex: Int) {
        canDismissView = true
    }
    
    private func loadWithExistingCredentials() {
        
        // load with entered credentials
        textFieldDOB.text = getTheDateInDisplayFormat(FymUserModel.userDobString)
        textFieldWeight.text = FymUserModel.userWeight
        textFieldBodyFat.text = FymUserModel.userFatLoss
        
        // seperate height to feet and inches
        var heightComponentArray = FymUserModel.userHeight.componentsSeparatedByString(".")
        if heightComponentArray.count > 1 {
        textFieldHeight.text = heightComponentArray[0]
            textFieldHeightUnits.text = heightComponentArray[1] }
        
        // select the gender
        segmentGender.selectedSegmentIndex = FymUserModel.userGender == "M" ? 0 : 1
        
    }
   
    private func setDatePickerMaximumDate() {
    
        let calendar = NSCalendar.currentCalendar()
        let components = NSDateComponents()
        components.year = -10
        
        // min date
        let maximumDate = calendar.dateByAddingComponents(components, toDate: NSDate(), options: [])
        datePicker.maximumDate = maximumDate
        
        // min date
        components.year = -150
        let minimumDate = calendar.dateByAddingComponents(components, toDate: NSDate(), options: [])
        datePicker.minimumDate = minimumDate

    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        
        if (segue.identifier == StoryBoard.SegueIdentifiers.FormulaSelect) {
            FymUserModel.userWeight = textFieldWeight.text!
            
            let userHeightInFeet = textFieldHeight.text == "" ? "0" : textFieldHeight.text
            let userHeightInInch = textFieldHeightUnits.text == "" ? "0" : textFieldHeightUnits.text
            FymUserModel.userHeight = userHeightInFeet! + "." + userHeightInInch!
            
            //print("userheight in cm ----\(FymUserModel.userHeightinCm)")
//            if !textFieldBodyFat.text.isEmpty {
                FymUserModel.userFatLoss = textFieldBodyFat.text!
//        }
        }
        
    }
    
    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool {
        if (identifier == StoryBoard.SegueIdentifiers.FormulaSelect) {
            return checkAllFields()
        }
        
        alert.dismissWithClickedButtonIndex(0, animated: false)
        return true
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    func checkAllFields() -> Bool {
        
        currentTextField.resignFirstResponder()
        
        // abort if needed
//        if canAbort { return false}
        
        // check all fields are filled
        if textFieldDOB.text!.isEmpty {
            self.showAlert(&&"notice", message: &&"enter_date_of_birth")
            return false

            
        }else if ( textFieldHeight.text!.isEmpty && textFieldHeightUnits.text!.isEmpty || textFieldHeight.text!.doubleValue <= 0.0 ){
            
            self.showAlert(&&"notice", message: &&"enter_height")
            return false

            
        } else if  textFieldWeight.text!.isEmpty || textFieldWeight.text!.doubleValue <= 0.0 {
            
            self.showAlert(&&"notice", message: &&"enter_weight")
            return false

        } else if !textFieldBodyFat.text!.isEmpty {
            
            let fatValue = textFieldBodyFat.text!.doubleValue
            
            if fatValue <= 0.0 {
                self.showAlert(&&"notice", message: &&"enter_fat_less_alert_message")
                return false

            } else if fatValue > 100.0 {
                self.showAlert(&&"notice", message: &&"enter_fat_greater_alert_message")
                return false
            }
        }
        return true
    }

    
    func showAlert(title: String, message: String) {
        
        // show alert controller if possible else show alert view
//        if NSClassFromString(Class.UIAlertController) != nil {
//            
//            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//            
//            alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
//            
//            self.presentViewController(alert, animated: true, completion: nil)
//            return
//        }
//        else {
        
            alert = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"ok")
            alert.show()
            return
//        }
    }
    
    @IBAction func segmentActionSelectGender(sender: UISegmentedControl, forEvent event: UIEvent) {
        // get the selected index and the title for the section asssign to userGender
        
        gender = Gender.genderTypes[sender.selectedSegmentIndex]
     }
    
    @IBAction func buttonActionPickerDone(sender: UIBarButtonItem) {
        textFieldDOB.resignFirstResponder()
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        // get the pickerdate and assign it to the DOB field
        let strDate = dateFormatter.stringFromDate(datePicker.date)
        FymUserModel.userDob = datePicker.date
        FymUserModel.userDobString = strDate
        textFieldDOB.text = getTheDateInDisplayFormat(strDate)
    }
    
    private func getTheDateInDisplayFormat(dateString: String) -> (String){
        
        if dateString == "" {
            return ""
        }
        // get the date in return format eg Apr 01, 2013
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let formattedDate = dateFormatter.dateFromString(dateString)
        let returnDateFormatter = NSDateFormatter()
        returnDateFormatter.dateStyle =  .MediumStyle
        let formattedDateString = returnDateFormatter.stringFromDate(formattedDate!)
        return formattedDateString
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    @IBAction func unwindToUserHealthDetailsViewController(segue: UIStoryboardSegue) {
        self.navigationController?.navigationBarHidden = false
    }
    
    @IBAction func buttonActionBack(sender: UIBarButtonItem) {
        self.navigationController?.popViewControllerAnimated(false)

    }

}
