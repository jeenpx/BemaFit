//
//  CopyMealViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 27/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class CopyMealViewController: UITableViewController, UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate {
    
    @IBOutlet private weak var pickerViewMealType: UIPickerView!
    @IBOutlet private weak var toolbarMealType: UIToolbar!
    @IBOutlet private weak var datePicker: UIDatePicker!
    @IBOutlet private weak var toolbarDate: UIToolbar!
    @IBOutlet private weak var textFieldMealType: UITextField!
    @IBOutlet private weak var textFieldDate: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // configure view
        configureView()
    }
    
    var copiedFood: Food = Food()
    
    var totalMeals = [MealType]()
    
    func configureView() {
        
        // set textfield input views
        textFieldDate.inputView = datePicker
        textFieldDate.inputAccessoryView = toolbarDate
        
        textFieldMealType.inputView = pickerViewMealType
        textFieldMealType.inputAccessoryView = toolbarMealType
        textFieldMealType.text = copiedFood.mealType.name
        textFieldDate.text = copiedFood.logDate.dateValue("yyyy-MM-dd")?.stringValue("MM/dd/yyyy")
        
        datePicker.setDate(copiedFood.logDate.dateValue("yyyy-MM-dd")!, animated: false)
    }
    
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        cell.setSeparatorInsetZero()
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return totalMeals.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return totalMeals[row].name
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        let index = totalMeals.indexOf(copiedFood.mealType)
        pickerViewMealType.selectRow(index!, inComponent: 0, animated: false)
    }
    
    @IBAction func barButtonActionSelectMeal(sender: UIBarButtonItem) {
        
        // set meal type
        textFieldMealType.text = totalMeals[pickerViewMealType.selectedRowInComponent(0)].name
        copiedFood.mealType = totalMeals[pickerViewMealType.selectedRowInComponent(0)]
        // dismiss picker
        textFieldMealType.resignFirstResponder()
    }
    
    @IBAction func barButtonActionSelectDate(sender: UIBarButtonItem) {
        
        // set date
        textFieldDate.text = datePicker.date.stringValue("MM/dd/yyyy")
        copiedFood.logDate = datePicker.date.stringValue("yyyy-MM-dd")
        
        // dismiss picker
        textFieldDate.resignFirstResponder()
    }
    
    @IBAction func barButtonActionDone(sender: UIBarButtonItem) {
        
        copiedFood.copyFood(copiedFood.mealType.id, mealDate: copiedFood.logDate.dateValue("yyyy-MM-dd")!, userGuid: AppConfiguration.sharedAppConfiguration.userDetails!.userId!) { (error) -> () in
            //print("logged food")
            // add log and pop out
            self.navigationController?.popViewControllerAnimated(true)

        }
        
    }    
}
