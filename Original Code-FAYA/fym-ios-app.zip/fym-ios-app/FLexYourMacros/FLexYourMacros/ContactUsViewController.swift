//
//  ContactUsViewController.swift
//  FlexYourMacros
//
//  Created by Vineeth Edwin on 10/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ContactUsViewController: UIViewController, UITextViewDelegate {
    
    @IBOutlet weak var labelPlaceholder: UILabel!
    @IBOutlet private weak var textViewMessage: UITextView!
    @IBOutlet weak var buttonSend: UIBarButtonItem!
    @IBOutlet weak var labelUserMessage: UILabel!
    
    var placeHolderMessage = &&"suggestion_placeholder_text"
    
    func textViewShouldEndEditing(textView: UITextView) -> Bool {
        // hide keyboard
        textViewMessage.resignFirstResponder()
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set placeholder
        labelPlaceholder.text = placeHolderMessage
        
        //hide the static label this should be made visible after successfully posting the message
        labelUserMessage.hidden = true
        
        // setting the button color and text
        buttonSend.tintColor = UIColor(red: 40.0/255.0, green: 141.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        buttonSend.setTitleTextAttributes([NSFontAttributeName: UIFont(name: "Helvetica-Bold", size: 15)!], forState: UIControlState.Normal)
        
        textViewMessage.becomeFirstResponder()
    }
    
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        // hide the label
        labelUserMessage.hidden = true
        
        // text entered
        if text != "" {
            labelPlaceholder.hidden = true
        }
        else {
            // backspace
            
            // user presses backspace on single character
            if textView.text.characters.count == 1 {
                labelPlaceholder.hidden = false
            }
        }
        
        if text == "\n" {
            
            // pressed return key when no character
            if textView.text.characters.count == 0 {
                labelPlaceholder.hidden = false
            }
            
            textViewMessage.resignFirstResponder()
            return false
        }
        
        return true
        
    }
    
    func showAlert(title:String,message:String) {
        if #available(iOS 8.0, *) {
            let alertView = UIAlertController(title: title,
                                              message: message, preferredStyle: .Alert)
            alertView.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
            presentViewController(alertView, animated: true, completion: nil)
        } else {
            // Fallback on earlier versions
            
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"ok").show()
        }
    }
    
    @IBAction func buttonActionBack(sender: UIBarButtonItem) {
        self.navigationController?.popViewControllerAnimated(true)
        
    }
    @IBAction func buttonActionSend(sender: UIBarButtonItem) {
        if textViewMessage.tag == 20 || textViewMessage.text.characters.count == 0 || textViewMessage.text.isEmpty {
            showAlert(&&"new_message_alert_title", message: &&"new_message_alert_message")
        }
        else {
            // resign the keyboard
            textViewMessage.resignFirstResponder()
            
            // internet check
            let reachability = appDelegate!.internetReachable
            if !reachability {
                
                self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                return
            }
            
            
            // send message
            ContactUsResponse.sendMessageToFYM(textViewMessage.text, completionHandler: { (response) -> () in
                // check for success
                if response.metaModel?.responseCode == 200 {
                    // success password changed
                    self.showAlert("",message: &&"success_send")
                    //                    self.labelUserMessage.hidden = false
                    //                    self.labelUserMessage.text = &&"success_send"
                    //                    self.textViewMessage.text = ""
                    
                }  else {
                    self.showAlert("",message: &&"failure_send")
                    //                    self.labelUserMessage.hidden = false
                    //                    self.labelUserMessage.text = &&"failure_send"
                    //                    self.textViewMessage.text = ""
                    
                }
                
            })
        }
    }
}