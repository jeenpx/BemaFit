//
//  SettingsViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 18/02/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class SettingsViewController: UITableViewController, UITextFieldDelegate , UIPickerViewDelegate, UIPickerViewDataSource, UIAlertViewDelegate {
  
    @IBOutlet weak var switchProfileType: UISwitch!
    @IBOutlet var toolBarHeight: UIToolbar!
    @IBOutlet var pickerViewHeight: UIPickerView!
    @IBOutlet var buttonProfileImage: UIButton!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet var textFieldFirstName: UITextField!
    @IBOutlet weak var textFieldLastName: UITextField!
    @IBOutlet var textFieldEmailAddress: UITextField!
    @IBOutlet var textFieldUserName: UITextField!
    @IBOutlet var textFieldWebsite: UITextField!
    @IBOutlet var textFieldDOB: UITextField!
    @IBOutlet var datePicker: UIDatePicker!
    @IBOutlet var toolBar: UIToolbar!
    @IBOutlet weak var textFieldHeight: UITextField!
    @IBOutlet weak var buttonUpdate: UIBarButtonItem!
    @IBOutlet weak var labelFullName: UILabel!
    
    var isBackButtonClicked = false
    
    var isProfileEditable = false
    
    var alert1: UIAlertView?
    var alert2: UIAlertView?
    
    let FymUserModel = FymUser.sharedFymUser
    var gender: String! = "M"
    
    //  user height
    var height: String! = " "
    
    var profileChangedStatus: Bool = false
    var feet = [1,2,3,4,5,6,7]
    var inches = [0,1,2,3,4,5,6,7,8,9,10,11]
    
    // updateStatus variable for the profile save or edit button : updateStatus=0 for edit and 1 for save
    var updateStatus: Int = 0
    
    // profile type : public(default)/private
    var  profileType :String! = Profiletype.Public.rawValue
    
    enum Gender: String {
        case Male = "male"
        case Female = "female"
    }
    
    enum Profiletype: String {
        case Public = "Public"
        case Private = "Private"
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SVProgressHUD.show()
        
        // hide the edit bar button
        buttonUpdate.enabled = false
        buttonUpdate.tintColor = UIColor.clearColor()
        buttonUpdate.setTitleTextAttributes([NSFontAttributeName: UIFont(name: "Helvetica-Bold", size: 15)!], forState: UIControlState.Normal)

        // setting date picker and toolbar for textFieldDOB
        textFieldDOB.inputView = datePicker
        textFieldDOB.inputAccessoryView = toolBar
        setDatePickerMaximumDate()
        
        //setting the pickerview and toolbar for textFieldHeight
        textFieldHeight.inputView = pickerViewHeight
        textFieldHeight.inputAccessoryView = toolBarHeight
        
        // configure profile image
        configureProfileImage()
        
        // internet check
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            SVProgressHUD.dismiss()
            return
        }
        
        // refresh user details
        AppConfiguration.refreshUserDetails { (refreshedUserDetails) -> () in
            
            if refreshedUserDetails {
                SVProgressHUD.dismiss()
                
                // enable the edit bar button
                self.buttonUpdate.enabled = true
                self.buttonUpdate.tintColor = UIColor(red: 40.0/255.0, green: 141.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                self.initialiseUserData()
                
            }
        }
        
    }
    
    private func setDatePickerMaximumDate() {
        
        let calendar = NSCalendar.currentCalendar()
        let components = NSDateComponents()
        components.year = -10
        
        // max date
        let maximumDate = calendar.dateByAddingComponents(components, toDate: NSDate(), options: [])
        datePicker.maximumDate = maximumDate
        
        // min date
        components.year = -150
        let minimumDate = calendar.dateByAddingComponents(components, toDate: NSDate(), options: [])
        datePicker.minimumDate = minimumDate
        
    }
    
    func configureProfileImage() {
        buttonProfileImage.layer.cornerRadius = CGRectGetWidth(buttonProfileImage.bounds) / 2
        buttonProfileImage.layer.masksToBounds = true
    }
    
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
       if textField == textFieldUserName {
            
            if string == " "{
                return false
            }
        }
        if textField != textFieldHeight {
            return true
        }
        var result = true
        let prospectiveText = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        if string.characters.count > 0 {
            let disallowedCharacterSet = NSCharacterSet(charactersInString: "0123456789.").invertedSet
            let replacementStringIsLegal = string.rangeOfCharacterFromSet(disallowedCharacterSet) == nil
            let resultingStringLengthIsLegal = prospectiveText.characters.count <= 10
            let scanner = NSScanner(string: prospectiveText)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
            result = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric
        }
        return result
    }
    
    
    func initialiseUserData() {
        
        let userFirstName = AppConfiguration.sharedAppConfiguration.userDetails?.userFirstName!
        let userLastName = AppConfiguration.sharedAppConfiguration.userDetails?.userLastName!
        labelFullName.text = "\(userFirstName!) \(userLastName!)"
        labelFullName.hidden = false
        textFieldFirstName.text = userFirstName!
        textFieldLastName.text = userLastName!
        textFieldEmailAddress.text = AppConfiguration.sharedAppConfiguration.userDetails?.userEmail
        
        let dobString = AppConfiguration.sharedAppConfiguration.userDetails?.userDob
        textFieldDOB.text = dobString?.dateValue("yyyy-MM-dd", dateStyle: nil)?.stringValue("MM/dd/yy", dateStyle: nil, showToday: false)
        
        textFieldUserName.text = AppConfiguration.sharedAppConfiguration.userDetails?.userUserName
        textFieldWebsite.text = AppConfiguration.sharedAppConfiguration.userDetails?.userWebsite
        segmentControl.selectedSegmentIndex = AppConfiguration.sharedAppConfiguration.userDetails?.userGender == "M" ? 0 : 1
        
        textFieldHeight.text = conversionMetricUnits(AppConfiguration.sharedAppConfiguration.userDetails?.userHeight?.doubleValue ?? 0.0)
        height = AppConfiguration.sharedAppConfiguration.userDetails?.userHeight
        
        gender = AppConfiguration.sharedAppConfiguration.userDetails?.userGender
        profileType = AppConfiguration.sharedAppConfiguration.userDetails?.userType
        
        setTextViewEditable(false)
        
        if let  profilePhoto  =  AppConfiguration.sharedAppConfiguration.userDetails?.userProfilePhoto {
            //print(profilePhoto)
            
            loadImage(profilePhoto as? String ?? "")
            
        } else {
            //print("NO PROFILE PIC")
        }
        
        // isProfileEditable is true then make the button to save and change the updateStatus to 1
        // this senario is for the case of navigation from profile page edit.
        if isProfileEditable {
            setTextViewEditable(true)
            updateStatus = 1
            buttonUpdate.title = &&"save"//"Save"
            buttonUpdate.tintColor = UIColor(red: 40.0/255.0, green: 141.0/255.0, blue: 255.0/255.0, alpha: 1.0)
            buttonUpdate.setTitleTextAttributes([NSFontAttributeName: UIFont(name: "Helvetica-Bold", size: 15)!], forState: UIControlState.Normal)
            
        }
        
        
    }
    
    func loadImage(urlString:String) {
        let imgURL: NSURL = NSURL(string: urlString)!
       // let request: NSURLRequest = NSURLRequest(URL: imgURL)
        self.buttonProfileImage.sd_setImageWithURL(imgURL, forState: UIControlState.Normal)
        
    }
    
    
    func textFieldDidEndEditing(textField: UITextField) {
        
        if isBackButtonClicked {
            
        } else {
        
            // validates the email and check for any empty textfield
            switch (textField) {
            case let textField where (textField == textFieldEmailAddress) && !textField.isValidEmailAddress:
                showAlert(&&"email", message: &&"email_validity")
            case let textField where (textField == textFieldUserName) && textField.isEmpty:
                showAlert("Username", message: &&"user_validity")
            case let textField where (textField == textFieldFirstName) && textField.isEmpty:
                showAlert("First Name", message: &&"first_name_validity")
            case let textField where (textField == textFieldLastName) && textField.isEmpty:
                showAlert("Last Name", message: &&"last_name_validity")
            default: return
            }
            
            // show keyboard
            textField.becomeFirstResponder()
        }
        
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        // hide keyboard on return
        textField.resignFirstResponder()
        return true
    }
    
    // picker view for height
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 4
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if component == 0 {
            return feet.count
        } else if component == 1 {
            return 1
        }else if component == 2 {
            return inches.count
        }else {
            return 1
        }
        
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0 {
            return "\(feet[row])"
            
        } else if component == 2 {
            return "\(inches[row])"
        } else if component == 1{
            return "Feet"
        }else {
            return "Inches"
        }
        
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
    }
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    
    func updateUserInformation(isBackNavigationClicked: Bool){
        
        // internet check
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        
        if updateStatus == 0 {
            // edit
            setTextViewEditable(true)
            updateStatus = 1
            buttonUpdate.title = &&"save"//"Save"
            buttonUpdate.tintColor = UIColor(red: 40.0/255.0, green: 141.0/255.0, blue: 255.0/255.0, alpha: 1.0)
            buttonUpdate.setTitleTextAttributes([NSFontAttributeName: UIFont(name: "Helvetica-Bold", size: 15)!], forState: UIControlState.Normal)
            
        }else if updateStatus == 1 {
            
            if !checkAllFields() {
                
                return
            }
      
            // check for image update
            
            if profileChangedStatus {
                ProfilePicResponse.changeUserPic({ (profilePicResponse) -> () in
                    self.profileChangedStatus = false
                    
                    let resonse = profilePicResponse
                    // check for success
                    if resonse.metaModel?.responseCode != 200 {
                        
                        // profile image failed to upload
                        self.showAlert(&&"notice", message: &&"profile_image_failed")
                    }
                    //refresh user details
                    AppConfiguration.refreshUserDetails { (refreshedUserDetails) -> () in
                        if refreshedUserDetails {
                            //print("refreshed successfully222")
                        }
                    }
                    // update the profile page if the image is updated
                    let notification = NSNotification(name: Constants.updateUserProfile,
                        object: nil)
                    NSNotificationCenter.defaultCenter().postNotification(notification)
                    
                })
            }
            else {
                //print("profile is not updated")
            }
            
            //check for validity of website if the website field is not empty
            
            if !textFieldWebsite.isEmpty{
                let checkWebSiteValidity = textFieldWebsite.text!.websiteString()
                
                let validityCheck = checkWebSiteValidity.valid
                
                if !validityCheck {
                    
                    self.showAlert(&&"notice", message: &&"enter_valid_website_alert_message")
                    
                    return
                } else {
                    
                    textFieldWebsite.text = checkWebSiteValidity.urlString
                }
                
            }
            
            
            let dobString: String = textFieldDOB.text!.dateValue("MM/dd/yy", dateStyle: nil)!.stringValue("yyyy-MM-dd", dateStyle: nil, showToday: false)
            
            let parameterDictionary: [String:String] = ["first_name":textFieldFirstName.text!,"last_name":textFieldLastName.text!,"email":textFieldEmailAddress.text!,"website":textFieldWebsite.text!,"gender":gender,"dob": dobString,"height":height,"type":profileType,"username":textFieldUserName.text!]
            
            // update the user information
            UpdateUserResponse.updateUserInfo(parameterDictionary, completionHandler: { (updateResponse) -> () in
                
                let resonse = updateResponse
                //print("respone code :\(resonse.metaModel?.responseCode)")
                //print("respone status :\(resonse.metaModel?.responseStatus)")
                
                // if email already exist  El Email ya existe
                if resonse.metaModel?.responseCode == 422 {
                    self.showAlert(&&"notice", message: &&"email_already_exists")
                    return
                }
                
                // if username already exist
                if resonse.metaModel?.responseCode == 423 {
                    self.showAlert(&&"notice", message: &&"username_already_exists")
                    return
                }
                
                // check for success
                if resonse.metaModel?.responseCode == 200 {
                    // Successsfully completed
                    //print("respone code :\(resonse.metaModel?.responseCode)")
                    //print("respone status :\(resonse.metaModel?.responseStatus)")
                    
                    // if back button is clicked then pop up on success .
                    if !isBackNavigationClicked {
                        self.showAlert(&&"notice", message: &&"profile_succcessfully_updated")
                    } else {
                        self.navigationController?.popViewControllerAnimated(true)
                    }
                    
                    // set the update status to 0
                    self.updateStatus = 0
                    self.labelFullName.text = "\(self.textFieldFirstName.text!) \(self.textFieldLastName.text!)"
                    self.buttonUpdate.title = &&"edit"//"Edit"
                    self.buttonUpdate.tintColor = UIColor(red: 40.0/255.0, green: 141.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                    self.buttonUpdate.setTitleTextAttributes([NSFontAttributeName: UIFont(name: "Helvetica-Bold", size: 15)!], forState: UIControlState.Normal)
                    self.setTextViewEditable(false)
                    
                    //refresh user details
                    
                    //refresh user details
                    AppConfiguration.refreshUserDetails { (refreshedUserDetails) -> () in
                        if refreshedUserDetails {
                            //print("refreshed successfully")
                        }
                    }
                    
                    
                }
                
            })
            
            
        }
        
    }
    
    
    @available(iOS 8.0, *)
    func refreshUserDetails() {
        let qualityOfServiceClass = QOS_CLASS_BACKGROUND
        let backgroundQueue = dispatch_get_global_queue(qualityOfServiceClass, 0)
        dispatch_async(backgroundQueue, {
            //print("This is run on the background queue")
            
            AppConfiguration.refreshUserDetails { (refreshedUserDetails) -> () in
                if refreshedUserDetails {
                    //print("refreshed successfully")
                }
            }
        })
        
    }
    
    func conversionMetricUnits(ht:Double)->(String) {
        
        let heightInCentimeters = ht
        
        // calculate feet
        var feet = Double(heightInCentimeters)/30.48
        feet = floor(feet)
        
        // calculate total inches
        let inchesTotal = Double(heightInCentimeters)/2.54
        
        // remaining inches
        var inchesRemaing = inchesTotal - (feet*12)
        inchesRemaing = round(inchesRemaing)
        
        // converted string
        let converted = "\(Int(feet))'\(Int(inchesRemaing))''"
        return converted
        
    }
    
  
    
    private func getTheDateInDisplayFormat(dateString: String) -> (String){
        if dateString == "" {
            return ""
        }
        // get the date in return format eg Apr 01, 2013
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        //  dateFormatter.dateFormat = "MM/dd/yyyy"
        let formattedDate = dateFormatter.dateFromString(dateString)
        let returnDateFormatter = NSDateFormatter()
        returnDateFormatter.dateStyle =  .MediumStyle
        let formattedDateString = returnDateFormatter.stringFromDate(formattedDate!)
        return formattedDateString
    }
    
    
    func showAlert(title: String, message: String) {
        // configure alert
        // show alert controller if possible else show alert view
       
            if #available(iOS 8.0, *) {
                let alert = UIAlertController(title: title, message: message , preferredStyle: .Alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
                self.presentViewController(alert, animated: true, completion: nil)

            } else {
                // Fallback on earlier versions
                alert1 = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok")
                alert1?.show()
            }
        
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if alertView == alert2 {
            if buttonIndex == 0 {
                // cancel button
                self.navigationController?.popViewControllerAnimated(true)
                
            } else {
                updateUserInformation(true)
            }
        }
    }
    
    func showConfirmationAlert(title: String, message: String) {
        // show alert controller if possible else show alert view
      
            if #available(iOS 8.0, *) {
                let alert = UIAlertController(title:title, message: message, preferredStyle: .Alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .Default) { action -> Void in
                    self.updateUserInformation (true)
                    
                    })
                alert.addAction(UIAlertAction(title: &&"cancel", style: .Cancel,  handler: { action in
                    self.navigationController?.popViewControllerAnimated(true)
                    
                }))
                // show alert
                presentViewController(alert, animated: true, completion: nil)

            } else {
                // Fallback on earlier versions
                alert2 =  UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"cancel", otherButtonTitles: &&"ok")
                alert2?.show()
            }
            
    

    }
    
    
    func setTextViewEditable(value:Bool) {
        textFieldFirstName.enabled = value
        textFieldLastName.enabled = value
        textFieldEmailAddress.enabled = value
        textFieldDOB.enabled = value
        textFieldUserName.enabled = value
        textFieldWebsite.enabled = value
        segmentControl.enabled = value
        textFieldHeight.enabled = value
        labelFullName.hidden = value
        textFieldFirstName.hidden = !value
        textFieldLastName.hidden = !value
        buttonProfileImage.userInteractionEnabled = value
    }
    
    func checkAllFields() -> Bool {
        
        // check if firstname is empty 
        if (textFieldFirstName.text!.isEmpty) {
            showAlert("First Name", message: &&"first_name_validity")
            return false

        } else if (textFieldLastName.text!.isEmpty) {
            showAlert("Last Name", message: &&"last_name_validity")
            return false

            
        } else if (textFieldEmailAddress.text!.isEmpty) {
            showAlert(&&"email", message: &&"email_validity")
            return false

        } else if (!textFieldEmailAddress.text!.isValidEmail()) {
            showAlert(&&"email", message: &&"email_validity")
            return false

            
        } else if (textFieldUserName.text!.isEmpty){
           showAlert("Username", message: &&"user_validity")
            return false

        }  else if (textFieldHeight.text!.isEmpty) {
            showAlert("Height", message: "Enter height")
            return false
            
        } else if textFieldDOB.text!.isEmpty {
            showAlert("DOB", message: "Enter DOB")
            return false
        }
        
        
       /*
        // check all fields are filled
        if (textFieldDOB.text.isEmpty || textFieldHeight.text.isEmpty || textFieldFirstName.text.isEmpty || textFieldLastName.text.isEmpty || textFieldHeight.text.isEmpty || textFieldUserName.text.isEmpty) {
            showAlert(&&"notice", message: &&"enter_the_details_alert_message")
            return false
        }
        */
        return true
    }
    
    
    
    @IBAction func buttonActionUpdate(sender: UIBarButtonItem) {
        
        updateUserInformation(false)
    }
    
    @IBAction func backButtonDone(sender: UIBarButtonItem) {
       
        isBackButtonClicked = true
        
        if updateStatus == 0 {
            self.navigationController?.popViewControllerAnimated(true)
        } else {
            showConfirmationAlert(&&"notice", message: &&"save_the_changes_in_the_settings_message")
        }
    }
    
    @IBAction func buttonActonDoneHeight(sender: UIBarButtonItem) {
        
        textFieldHeight.resignFirstResponder()
        var feetValue = 0
        var inchValue = 0
        
        feetValue = self.pickerViewHeight.selectedRowInComponent(0)
        inchValue = self.pickerViewHeight.selectedRowInComponent(2)
        
        // 1foot =30.48 cm ,1inch =2.54 cm
        // metric to standard
        // cm = (feet*30.48)+(inch*2.54)
        let cms  = (Double(feet[feetValue])*30.48) + (Double(inches[inchValue])*2.54)
        //        cms = round(cms)
        // setting the height in feet inches
        textFieldHeight.text = "\(feet[feetValue]) '\(inches[inchValue])''"
        height = "\(Double(cms))"
        
    }
    
    
    
    @IBAction func buttonActionDOB(sender: UIBarButtonItem) {
        
        textFieldDOB.resignFirstResponder();
        textFieldDOB.text = datePicker.date.stringValue("MM/dd/yy", dateStyle: nil, showToday: false)// getTheDateInDisplayFormat(strDate)
        
    }
    
    @IBAction func segmentActionSelectGender(sender: UISegmentedControl) {
        gender = ["M", "F"][sender.selectedSegmentIndex]
    }
    
    @IBAction func buttonActionSelectProfileImage(sender: UIButton) {
        // profile pic
        ImagePickerManager.sharedManager.presentImagePicker(self) { (image, source) -> () in
            sender.setImage(image, forState: .Normal)
            self.FymUserModel.userImage = image
            self.profileChangedStatus = true
            
        }
    }
    
}
