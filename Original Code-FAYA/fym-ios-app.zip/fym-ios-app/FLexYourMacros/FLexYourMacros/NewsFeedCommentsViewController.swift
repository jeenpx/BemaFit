//
//  NewsFeedCommentsViewController.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 27/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class NewsFeedCommentsViewController: SLKTextViewController, NewsFeedCommentCellDelegate, EnlargeImageCommentDelegate, SWTableViewCellDelegate {
    
    // XXX fetch the hasttags here
    let hashTags = [String]()
    let users = [String]()
    
    // selected hashtag
    var hashTag = ""
    
    // newsFeed for which the comments are listed
    var newsFeed = NewsFeed()
    
    // list of news feeds
    private var newsFeedComments = [NewsFeedComment]()
    
    // search results which is optional
    private var searchResults: [String]?
    
    // refresh control
    let refreshControl = UIRefreshControl()
    
    var shouldReload = true
    
    var pageMeta = PageMetaModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // configure the chat view
        configureView()
        
        //print(NSUserDefaults.standardUserDefaults().objectForKey("accesstoken"))
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        title = &&"comments"
        
        // fetch news feed comments
        if shouldReload {
            
            // reset page meta data
            pageMeta = PageMetaModel()
            
            self.newsFeed.fetchComments(pageMeta: pageMeta) { (newsFeedComments, pageMeta) in
                self.pageMeta = pageMeta
                self.newsFeedComments = Array(newsFeedComments.reverse())
                self.tableView.reloadData()
                
                dispatch_async(dispatch_get_main_queue()) {
                    // scroll to bottom
                    self.scrollToBottom()
                }
            }
        }
    }
    
    func configureView() {
        
        // set basic properties for the view
        // XXX double check this
        bounces = true
        shakeToClearEnabled = true
        keyboardPanningEnabled = true
        shouldScrollToBottomAfterKeyboardShows = false
        inverted = false
        
        // setup tableview
        tableView.tableFooterView = UIView(frame: CGRectZero)
        tableView.registerNib(UINib(nibName: "NewsFeedCommentCell", bundle: nil), forCellReuseIdentifier: Storyboard.CellIdentifiers.NewsFeedCommentCellIdentifier)
        
        // set estimated row height
        // XXX setting the lowest height now, recheck
        tableView.estimatedRowHeight = 230.0
        tableView.rowHeight = UITableViewAutomaticDimension
        
        // setup refresh control
        refreshControl.addTarget(self, action: "pullToRefresh:", forControlEvents: UIControlEvents.ValueChanged)
        refreshControl.tintColor = UIColor.grayColor()
        
        // add refresh control to the tableview
        tableView.addSubview(refreshControl)
        
        // setup textview
        textView.placeholder = NSLocalizedString("post_placeholder_text", comment: "")
        textView.pastableMediaTypes = .None
        
        // setup buttons
        leftButton.setImage(UIImage(named: "CameraIcon"), forState: .Normal)
        rightButton.setTitle(&&"post_button_title", forState: .Normal)
        
        // setup textinputbar
        textInputbar.editorTitle.textColor = UIColor.darkGrayColor()
        
        textInputbar.editorLeftButton.tintColor = UIColor(red: 0, green: 122.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        textInputbar.editorRightButton.tintColor = UIColor(red: 0, green: 122.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        // textInputbar.editortLeftButton.tintColor = UIColor(red: 0, green: 122.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        // textInputbar.editortRightButton.tintColor = UIColor(red: 0, green: 122.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        
        textInputbar.autoHideRightButton = false
        textInputbar.counterStyle = SLKCounterStyle.None
        
        typingIndicatorView.canResignByTouch = true
        
        autoCompletionView.registerClass(NewsFeedCell.self, forCellReuseIdentifier:Storyboard.CellIdentifiers.AutoCompletionCellIdentifier)
        registerPrefixesForAutoCompletion(["#", "@"])
    }
    
    override func canPressRightButton() -> Bool {
        return super.canPressRightButton()
    }
    
    override func canShowAutoCompletion() -> Bool {
        
        // clear the search results array
        let autoCompletionList = foundPrefix == "#" ? hashTags : users
        searchResults = autoCompletionList as [String]
        
        // filter hashtags
        let predicate = NSPredicate(format: "SELF BEGINSWITH[C] %@", foundWord)
        if foundWord.characters.count > 0 {
            searchResults = autoCompletionList.filter {
                predicate.evaluateWithObject($0)
            }
        }
        
        // sort the search results
        if let _ = searchResults {
            (searchResults!).sortInPlace(<)
        }
        
        return searchResults?.count > 0
    }
    
    override func didPressLeftButton(sender: AnyObject!) {
        super.didPressLeftButton(sender)
        
        // hide keyboard to show actionsheet on top
        view.endEditing(true)
        
        // no need to reload data after picking image
        shouldReload = false
        
        // fetch image from image picker
        ImagePickerManager.sharedManager.presentImagePicker(self) { (image, source) in
            self.textView.insertImage(image)
            dispatch_async(dispatch_get_main_queue()) {
                self.textView.becomeFirstResponder()
                self.textView.selectedRange = NSMakeRange(self.textView.text.characters.count, 0)
            }
        }
    }
    
    override func didPressRightButton(sender: AnyObject!) {
        
        // validate any pending auto-correction or auto-spelling
        textView.refreshFirstResponder()
        
        // create a new newsfeed comment
        textView.getInsertedImage { image in
            // comment
            self.newsFeed.comment(self.textView.text, image: image) { (newsFeedComment, error) -> () in
                if error != nil {
                    // XXX handle error
                }
                
                // update in main thread
                dispatch_async(dispatch_get_main_queue()) {
                    
                    // update tableview
                    if let newsFeedComment = newsFeedComment {
                        self.tableView.beginUpdates()
                        self.newsFeedComments += [newsFeedComment]
                        self.tableView.insertRowsAtIndexPaths([NSIndexPath(forRow: self.newsFeedComments.count - 1, inSection: 0)], withRowAnimation: .Bottom)
                        self.tableView.endUpdates()
                        
                        // scroll table view to botton
                        self.scrollToBottom(true)
                    }
                }
            }
            
            // cleanup the textview (weird huh?)
            dispatch_async(dispatch_get_main_queue()) {
                self.textView.attributedText = nil
                self.textView.text = "   "
                self.textView.font = UIFont.systemFontOfSize(16)
                self.textView.slk_clearText(true)
                self.dismissKeyboard(true)
            }
        }
        
        // call the super method in the end with some
        // additional cleanup to handle image insertions
        // super method will do the cleanup
        super.didPressRightButton(sender)
    }
    
    override func didPasteMediaContent(userInfo: [NSObject : AnyObject]!) {
        super.didPasteMediaContent(userInfo)
        
        // XXX do something related to image upload here
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableView == autoCompletionView ? searchResults?.count ?? 0 : newsFeedComments.count
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return newsFeedComments[indexPath.row].expectedHeight
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell
        
        if tableView == self.tableView {
            cell = self.tableView(tableView, newsFeedCommentCellForRowAtIndexPath: indexPath)
        } else {
            cell = self.tableView(tableView, autoCompletionCellForRowAtIndexPath: indexPath)
        }
        
        // update the cell transform
        cell.transform = tableView.transform
        cell.layoutIfNeeded()
        return cell
    }
    
    func tableView(tableView: UITableView, newsFeedCommentCellForRowAtIndexPath indexPath: NSIndexPath) -> NewsFeedCommentCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifiers.NewsFeedCommentCellIdentifier) as! NewsFeedCommentCell
        
        cell.newsFeedComment = newsFeedComments[indexPath.row]
        cell.newsFeed = newsFeed
        cell.newsFeedCommentCellDelegate = self
        cell.enlargeImageCommentDelegate = self
        cell.delegate = self
        return cell
    }
    
    func tableView(tableView: UITableView, autoCompletionCellForRowAtIndexPath indexPath: NSIndexPath) -> NewsFeedCell {
        
        // get a reusable instance
        let cell = tableView.dequeueReusableCellWithIdentifier(Storyboard.CellIdentifiers.AutoCompletionCellIdentifier) as! NewsFeedCell
        
        // XXX configure cell here
        cell.textLabel?.text = searchResults![indexPath.row]
        
        return cell
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return tableView == autoCompletionView ? 0.5 : 0
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        cell.setSeparatorInsetZero()
        
        (cell as? NewsFeedCommentCell)?.newsFeedComment = newsFeedComments[indexPath.row]
        cell.layoutSubviews()
        cell.layoutIfNeeded()
    }
    
    override func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        tableView.reloadData()
    }
    
    override func didChangeKeyboardStatus(status: SLKKeyboardStatus) {
        // scroll to bottom
        scrollToBottom(true)
    }
    
    override func heightForAutoCompletionView() -> CGFloat {
        let cellHeight = CGFloat(44.0)
        let cellCount = CGFloat(searchResults?.count ?? 0)
        
        return cellHeight * cellCount
    }
    
    func pullToRefresh(sender: UIRefreshControl) {
        
        if !pageMeta.isValid {
            self.refreshControl.endRefreshing()
            return
        }
        
        // fetch news feed comments and reload table
        newsFeed.fetchComments(false, pageMeta: pageMeta) { (newsFeedComments, pageMeta) in
            self.pageMeta = pageMeta
            self.newsFeedComments = Array(newsFeedComments.reverse()) + self.newsFeedComments
            self.refreshControl.endRefreshing()
            self.tableView.reloadData()
        }
    }
    
    func scrollToBottom(animated: Bool = false) {
        // scroll table view to bottom
        if tableView.numberOfRowsInSection(0) > 0 {
            tableView.scrollToRowAtIndexPath(NSIndexPath(forRow: tableView.numberOfRowsInSection(0) - 1, inSection: 0), atScrollPosition: UITableViewScrollPosition.Bottom, animated: animated)
        }
    }
    
    func newsFeedCommentCell(newsFeedCommentCell: NewsFeedCommentCell, didSelectUser userId: String) {
        performSegueWithIdentifier(Storyboard.Segues.ProfileSegue, sender: userId)
    }
    
    func newsFeedCommentCell(newsFeedCommentCell: NewsFeedCommentCell, didSelectHashTag hashTag: String) {
        self.hashTag = hashTag
        performSegueWithIdentifier(Storyboard.Segues.HashTagSegue, sender: self)
    }
    
    struct Storyboard {
        struct Segues {
            static let ProfileSegue = "kProfileSegue"
            static let HashTagSegue = "kCommentHashTagSegue"
        }
        struct CellIdentifiers {
            static let NewsFeedCommentCellIdentifier = "kNewsFeedCommentCell"
            static let AutoCompletionCellIdentifier = "kAutoCompletionCell"
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == Storyboard.Segues.ProfileSegue {
            let profileViewController = segue.destinationViewController as! ProfileViewController
            profileViewController.userId = sender as? String ?? ""
        } else if segue.identifier == Storyboard.Segues.HashTagSegue {
            let hashTagViewController = segue.destinationViewController as! HashTagViewController
            hashTagViewController.hashTag = hashTag
        }
    }
    
    @IBAction func unwindToDashboardViewController(segue: UIStoryboardSegue) {
        // close the side menu if its open
    }
    
    func enlargeImageView(selectedCell: NewsFeedCommentCell, imageViewComment: UIImageView) {
        // enlarge the imageview
        
        let imageInfo = JTSImageInfo()
        imageInfo.image = imageViewComment.image
        
        // imageInfo.imageURL = NSURL(string: food.image)
        imageInfo.referenceRect = imageViewComment.frame
        imageInfo.referenceView = imageViewComment.superview
        let imageViewController = JTSImageViewController(imageInfo: imageInfo, mode: .Image, backgroundStyle: .Scaled)
        
        // present the view controller.
        imageViewController.showFromViewController(self, transition: .FromOriginalPosition)
        
    }
    
    func swipeableTableViewCell(cell: SWTableViewCell!, didTriggerRightUtilityButtonWithIndex index: Int) {
        // called when the right utility buttons are clicked
        
        let cellIndexPath = tableView.indexPathForCell(cell)
        let commentId = newsFeedComments[cellIndexPath!.row].id
        let feedId = newsFeed.id
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        // delete the newsfeed comment
        UIAlertView.showWithTitle(&&"delete_confirmation_title", message: &&"comment_delete_confirmation_message", cancelButtonTitle: &&"ok_button_title", otherButtonTitles: [&&"cancel_button_title"], tapBlock: { (alertview : UIAlertView, buttonIndex : Int) in
            
            
            if buttonIndex == alertview.cancelButtonIndex{
                
                NewsFeedCommentsDeleteResponse.deleteNewsFeedComment(feedId, newsFeedCommentId: commentId) { (responseStatus) -> () in
                    if responseStatus == "OK" {
                        
                        
                        if self.newsFeedComments.count-1 >= cellIndexPath!.row{
                            self.newsFeedComments.removeAtIndex(cellIndexPath!.row)
                            
                            self.tableView.deleteRowsAtIndexPaths([cellIndexPath!], withRowAnimation: .None)
                        }
                    }
                }
                
            }
        })
        
        
        
    }
    
    func swipeableTableViewCellShouldHideUtilityButtonsOnSwipe(cell: SWTableViewCell!) -> Bool {
        // prevent multiple cells from showing utilty buttons simultaneously
        
        return true
    }
    
}

