//
//  DragTableState_ot.h
//  LoadMore
//
//  Created by openthread on 2/13/13.
//  Copyright (c) 2013 CannonInc. All rights reserved.
//

#ifndef LoadMore_DragTableState_ot_h
#define LoadMore_DragTableState_ot_h

typedef enum{
	DragTableDragStatePulling_ot = 0,
	DragTableDragStateNormal_ot,
	DragTableDragStateLoading_ot,
} DragTableDragState_ot;

#endif
