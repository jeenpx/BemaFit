//
//  DailyMealPlanViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 11/17/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol DailyMealPlanCellDelegate {
    func showShareActionSheet(cell: DailyMealPlanCell)
    func showUserProfile(userId: String)
    func editMeal(cell:DailyMealPlanCell)
}

public class DailyMealPlanUtils{
    class func compareMealType(a : String, b : String) -> Bool{
        
        
        let string1Alpha:String = (a.componentsSeparatedByCharactersInSet(NSCharacterSet.decimalDigitCharacterSet()) as NSArray).componentsJoinedByString("")
        let string2Alpha:String = (b.componentsSeparatedByCharactersInSet(NSCharacterSet.decimalDigitCharacterSet()) as NSArray).componentsJoinedByString("")
        
        if string1Alpha != string2Alpha{ // compare two different meal names eg: coremeal1 n snack 2
            return a < b
        }
        
        let string1Numeric:String = (a.componentsSeparatedByCharactersInSet(NSCharacterSet.letterCharacterSet()) as NSArray).componentsJoinedByString("")
        let string2Numeric:String = (b.componentsSeparatedByCharactersInSet(NSCharacterSet.letterCharacterSet()) as NSArray).componentsJoinedByString("")
        
        return Int(string1Numeric) < Int(string2Numeric)
        
    }
    class func generatePdfAndEmail(noOfCoreSnacks : Int, noOfCoreMeals : Int, foodLog : [DailyMealFoodModel], fromViewController : UIViewController, pdfName : String, dailyMealPlanModel : DailyMealPlanResponseModel?){
        // calculating overall totals in the meal
        var actualProteins:Double = 0.000
        var actualCalories:Double = 0.000
        var actualCarbs:Double = 0.000
        var actualFats:Double = 0.000
        var actualFibres:Double = 0.000
        
        let pdfManager = PdfManager()
        
        
        pdfManager.addText("<B>Meal Planner Created by</B> : \(dailyMealPlanModel?.mealPlanAddedByUsername ?? "No Name")")
        pdfManager.addText("<br/><B>Meal Planner Name</B> : \(dailyMealPlanModel?.mealPlanName ?? "No Name")")
        pdfManager.addText("<br/><br/><B>Current Diet Profile</B> :  \(dailyMealPlanModel?.mealNutritionPlanName ?? "No Name")")
        
        
        let calories : String = String.localizedStringWithFormat("%.2f",Double(dailyMealPlanModel?.mealCalorie ?? "0") ?? 0)
        let proteins : String = String.localizedStringWithFormat("%.2f", Double(dailyMealPlanModel?.mealProtein ?? "0") ?? 0)
        let carbohydrates : String = String.localizedStringWithFormat("%.2f", Double(dailyMealPlanModel?.mealCarb ?? "0") ?? 0)
        let fats : String = String.localizedStringWithFormat("%.2f", Double(dailyMealPlanModel?.mealFat ?? "0") ?? 0)
        
        pdfManager.addText("<br/>Calories : \(calories)")
        pdfManager.addText("<br/>Proteins :  \(proteins)")
        pdfManager.addText("<br/>Carbohydrates :  \(carbohydrates)")
        pdfManager.addText("<br/>Fats :  \(fats)<br/><br/>")
        
        
        for(var j=1;j<=noOfCoreMeals;j++) {
            pdfManager.createHeaderTags(["Coremeal\(j)","#Servings","Unit","Calories","Protein(gm)","Carbs(gm)","Fats(gm)","Fibre(gm)"])
            
            // calculating totals in each coremeal
            var totalProteins:Double = 0.000
            var totalCalories:Double = 0.000
            var totalCarbs:Double = 0.000
            var totalFats:Double = 0.000
            var totalFibres:Double = 0.000
            
            var coreFood:[DailyMealFoodModel] = foodLog.filter{$0.dmpMealType == &&"coremeal\(j)" || $0.dmpMealType == "ComidaPrincipal\(j)"}
            
            for(var i=0;i<coreFood.count;i++) {
                //print("core meal count - - \(coreFood[i].foodName)")
                let servingSizeDouble = (coreFood[i].servingSizeFixed == "1") ? 1 : Double(coreFood[i].servingSize)
                totalProteins = totalProteins + (Double(coreFood[i].protien)! * servingSizeDouble!)
                totalCalories = totalCalories + (Double(coreFood[i].calorie)! * servingSizeDouble!)
                totalCarbs = totalCarbs + (Double(coreFood[i].carbs)! * servingSizeDouble!)
                totalFats = totalFats + (Double(coreFood[i].fat)! * servingSizeDouble!)
                totalFibres = totalFibres + (Double(coreFood[i].fiber)! * servingSizeDouble!)
                
                // for serving size with two decimal places use servingSize
                let servingSize = String.localizedStringWithFormat("%.2f ", servingSizeDouble!)
                //"\(coreFood[i].servingSize)"
                
                
                
                
                pdfManager.createSingleRowItem(["\(coreFood[i].foodName)","\(servingSize)","\(coreFood[i].unit)","\(coreFood[i].calorie)","\(coreFood[i].protien)","\(coreFood[i].carbs)","\(coreFood[i].fat)","\(coreFood[i].fiber)"])
            }
            pdfManager.drawLine()
            
            let proteinRounded = String.localizedStringWithFormat("%.2f ", totalProteins)
            let caloriesRounded = String.localizedStringWithFormat("%.2f ", totalCalories)
            let carbsRounded = String.localizedStringWithFormat("%.2f ", totalCarbs)
            let fatsRounded = String.localizedStringWithFormat("%.2f ", totalFats)
            let fibreRounded = String.localizedStringWithFormat("%.2f ", totalFibres)
            
            pdfManager.createSingleRowItemWithStyle([" "," ","Total","\(caloriesRounded)","\(proteinRounded)","\(carbsRounded)","\(fatsRounded)","\(fibreRounded)"],cssStyle : "font-weight:bold;")
            pdfManager.drawLine()
            // calculating totals
            actualProteins = actualProteins + totalProteins
            actualCalories = actualCalories + totalCalories
            actualCarbs = actualCarbs + totalCarbs
            actualFats = actualFats + totalFats
            actualFibres = actualFibres + totalFibres
            
        }
        for(var j=1;j<=noOfCoreSnacks;j++){
            var snack:[DailyMealFoodModel] = foodLog.filter{$0.dmpMealType == "snacks\(j)"}
            
            
            pdfManager.createHeaderTags(["Snack\(j)","#Servings","Unit","Calories","Protein(gm)","Carbs(gm)","Fats(gm)","Fibre(gm)"])
            var totalProteins:Double = 0.000
            var totalCalories:Double = 0.000
            var totalCarbs:Double = 0.000
            var totalFats:Double = 0.000
            var totalFibres:Double = 0.000
            
            
            for(var i=0;i<snack.count;i++) {
                //print("core meal count - - \(snack[i].foodName)")
                let servingSizeDouble = (snack[i].servingSizeFixed == "1") ? 1 : Double(snack[i].servingSize)
                totalProteins = totalProteins + (Double(snack[i].protien)! * servingSizeDouble!)
                totalCalories = totalCalories + (Double(snack[i].calorie)! * servingSizeDouble!)
                totalCarbs = totalCarbs + (Double(snack[i].carbs)! * servingSizeDouble!)
                totalFats = totalFats + (Double(snack[i].fat)! * servingSizeDouble!)
                totalFibres = totalFibres + (Double(snack[i].fiber)! * servingSizeDouble!)
                
                let servingSize = String.localizedStringWithFormat("%.2f ",servingSizeDouble!)
                //"\(coreFood[i].servingSize)"
                pdfManager.createSingleRowItem(["\(snack[i].foodName)","\(servingSize)","\(snack[i].unit)","\(snack[i].calorie)","\(snack[i].protien)","\(snack[i].carbs)","\(snack[i].fat)","\(snack[i].fiber)"])
            }
            
            pdfManager.drawLine()
            
            if snack.count <= 0{
                continue
            }
            
            
            
            let proteinRounded = String.localizedStringWithFormat("%.2f ", totalProteins)
            let caloriesRounded = String.localizedStringWithFormat("%.2f ", totalCalories)
            let carbsRounded = String.localizedStringWithFormat("%.2f ", totalCarbs)
            let fatsRounded = String.localizedStringWithFormat("%.2f ", totalFats)
            let fibreRounded = String.localizedStringWithFormat("%.2f ", totalFibres)
            
            pdfManager.createSingleRowItem([" "," ","Total","\(caloriesRounded)","\(proteinRounded)","\(carbsRounded)","\(fatsRounded)","\(fibreRounded)"])
            //  pdfManager.drawLine()
            actualProteins = actualProteins + totalProteins
            actualCalories = actualCalories + totalCalories
            actualCarbs = actualCarbs + totalCarbs
            actualFats = actualFats + totalFats
            actualFibres = actualFibres + totalFibres
            
        }
        
        pdfManager.drawLine()
        
        let proteinRounded = String.localizedStringWithFormat("%.2f ", actualProteins)
        let caloriesRounded = String.localizedStringWithFormat("%.2f ", actualCalories)
        let carbsRounded = String.localizedStringWithFormat("%.2f ", actualCarbs)
        let fatsRounded = String.localizedStringWithFormat("%.2f ", actualFats)
        let fibreRounded = String.localizedStringWithFormat("%.2f ", actualFibres)
        
        
        pdfManager.createSingleRowItem([" "," ","Actual Totals:","\(caloriesRounded)","\(proteinRounded)","\(carbsRounded)","\(fatsRounded)","\(fibreRounded)"])
        pdfManager.drawLine()
        //print("************** HTML CONTENT ************")
        //print (pdfManager.toHtml())
        //print("**************************")
        pdfManager.createPdfWithFileName("Meal.pdf", completion: { (manager,result) -> Void in
            //print("Pdf details :\(result)")
            
            
            
            
            
            let subject:String = "Your \(pdfName) is here!"
            let content:String = "Hi, i have sent you a meal plan."
            
            EmailManager.send1Mail(pdfName, fileName: "Meal.pdf", mailSubject: subject, mailContent: content, vController: fromViewController, withCompletionblock: { (controller, result, error) -> () in
                
                if error == nil {
                    //print("Email had been send")
                }
                else{
                    //print("Email send failed")
                }
                
                
            })
        })
        
        
    }
    
    
}

class DailyMealPlanCell: SWTableViewCell {
    
    @IBOutlet weak var imageViewProfilePic: UIImageView!
    @IBOutlet weak var labelUsername: UILabel!
    @IBOutlet weak var labelTimesAgo: UILabel!
    @IBOutlet weak var labelName: UILabel!
    
    var dailyMealPlanCellDelegate: DailyMealPlanCellDelegate?
    
    var dailyMeal = DailyMealPlanListModel() {
        didSet{
            
            labelUsername.text = dailyMeal.addedUsername
            let date = dailyMeal.updatedDate
            let newDate = date.utcDateValue("yyyy-MM-dd HH:mm:ss")
            labelTimesAgo.text = &&"alert_title_update"+" "+(newDate?.timeAgo())!
            labelName.text = dailyMeal.name
            let imageURL = NSURL(string: dailyMeal.profilePhoto)!
            
            imageViewProfilePic.setImageWithURL(imageURL, placeholderImage:  UIImage(named:"FacebookIcon")!)
            
            labelUsername.userInteractionEnabled = true
            imageViewProfilePic.userInteractionEnabled = true
            
            let tapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
            tapGesture.delegate = self
            
            let userImageTapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
            userImageTapGesture.delegate = self
            
            let timeAgoTapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
            timeAgoTapGesture.delegate = self
            
            imageViewProfilePic.addGestureRecognizer(userImageTapGesture)
            
            // add tap gesture to the username label
            //            labelUsername.addGestureRecognizer(tapGesture)
            
            labelTimesAgo.addGestureRecognizer(timeAgoTapGesture)
            
        }
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        // configure the cell
        configureCell()
    }
    
    
    func configureCell() {
        
        // Add right utility buttons
        rightUtilityButtons = configureRightUtilityButtons() as [AnyObject]
        
    }
    func didTaplabelUserNameWithGesture(tapGesture: UITapGestureRecognizer) {
        //dailyMealPlanCellDelegate?.showUserProfile(dailyMeal.addedUserId)
        dailyMealPlanCellDelegate?.editMeal(self)
    }
    
    
    func configureRightUtilityButtons() -> NSArray {
        // configure right utility button for swipe delete
        
        let rightUtilityButtons = NSMutableArray()
        rightUtilityButtons.addUtilityButtonWithBackgroundColor(UIColor(red: 79.0/255.0, green: 131.0/255.0, blue: 196.0/255.0, alpha: 1.0),
                                                                andTitleColor: UIColor.whiteColor(), andTitle: NSLocalizedString("message_swipe_delete_title", comment: ""))
        return rightUtilityButtons
    }
    
    
    @IBAction func buttonActionEdit(sender: AnyObject) {
        dailyMealPlanCellDelegate?.editMeal(self)
    }
    
    @IBAction func buttonActionShare(sender: AnyObject) {
        dailyMealPlanCellDelegate?.showShareActionSheet(self)
        //print(dailyMeal.guId)
    }
    
}

class DailyMealPlanViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIActionSheetDelegate, DailyMealPlanCellDelegate, UITableViewDragLoadDelegate, SWTableViewCellDelegate {
    
    struct StoryBoard {
        struct CellIdentifiers {
            static let DailyMealPlanCellIdentifier = "kDailyMealPlanCell"
        } //kSegueSendMealPlan
    }
    
    var mealPageMode = mealPlanDetailPageMode.newMealPlan
    
    
    // action sheet to share
    private let actionSheet = UIActionSheet(title: &&"daily_meal_plan_share", delegate: nil, cancelButtonTitle: &&"cancel", destructiveButtonTitle: nil, otherButtonTitles: &&"daily_meal_plan_email", "FYM")
    @IBOutlet weak var viewEmpty: UIView!
    @IBOutlet weak var tableViewDailyMealPlan: UITableView!
    var selectedDailyMealPlanId : String?
    var foodLog:[DailyMealFoodModel] = [DailyMealFoodModel]()
    var selectedDailyMealPlanName  : String?
    var dailyMealPlanModelSelected : DailyMealPlanResponseModel?
    //list contains the daily meal plan list
    var dailyMealPlanArray = [DailyMealPlanListModel]() {
        didSet {
            
            // show create meal plan if daily meal plan is empty
            viewEmpty.hidden = dailyMealPlanArray.count != 0
        }
    }
    
    // variable for pull to refresh
    var refreshControl: UIRefreshControl!
    
    var offset = 0
    
    var noOfCoreMeals = 4
    var noOfCoreSnacks = 2
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set the delegate for action sheet
        actionSheet.delegate = self
        configureTableViewDailyMealPlan()
        configureRefreshControl()
        offset = dailyMealPlanArray.count
        
        // get the daily mealplan list
        self.fetchDailyMealPlans(offset,limit: 15,doLoadMore: false)
        
        NSNotificationCenter.defaultCenter().addObserver(self,
                                                         selector: "updateDailyMealPlanList:",
                                                         name: Constants.updateDailyMealList,
                                                         object: nil)
    }
    
    
    func updateDailyMealPlanList(notification: NSNotification) {
        dailyMealPlanArray = []
        tableViewDailyMealPlan.reloadData()
        self.fetchDailyMealPlans(0,limit: 15,doLoadMore: false)
    }
    
    func configureTableViewDailyMealPlan() {
        
        // hide empty tableview cells
        tableViewDailyMealPlan.tableFooterView = UIView(frame: CGRectZero)
        
        // set delegate for pull to refresh and load more
        tableViewDailyMealPlan.setDragDelegate(self, refreshDatePermanentKey: "kDailyMealPlan")
        
        // hide pull to refresh
        tableViewDailyMealPlan.showRefreshView = false
        
        // show load more
        tableViewDailyMealPlan.showLoadMoreView = true
        
        // tableview footer release text
        tableViewDailyMealPlan.footerReleaseText = NSLocalizedString("release_to_load_more_status", comment: "")
        
        // tableview footer pull up text
        tableViewDailyMealPlan.footerPullUpText = NSLocalizedString("pull_down_to_load_more_status", comment: "")
        
        //tableview footer loading text
        tableViewDailyMealPlan.footerLoadingText = NSLocalizedString("loading_status", comment: "")
        
        
        
    }
    
    func configureRefreshControl() {
        refreshControl = UIRefreshControl()
        
        // add the target
        refreshControl.addTarget(self, action: "pullToRefresh:", forControlEvents: UIControlEvents.ValueChanged)
        refreshControl.tintColor = UIColor.grayColor()
        
        // add refresh control to the tableview
        tableViewDailyMealPlan.addSubview(refreshControl)
    }
    
    func pullToRefresh(sender: AnyObject) {
        // reset all the values
        //tableView.hidden = true
        dailyMealPlanArray = []
        viewEmpty.hidden = true
        tableViewDailyMealPlan.reloadData()
        self.fetchDailyMealPlans(0,limit: 15,doLoadMore: false)
    }
    
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let dailyMealPlanCell = tableView.dequeueReusableCellWithIdentifier(StoryBoard.CellIdentifiers.DailyMealPlanCellIdentifier) as! DailyMealPlanCell
        dailyMealPlanCell.dailyMeal = self.dailyMealPlanArray[indexPath.row]
        dailyMealPlanCell.dailyMealPlanCellDelegate = self
        dailyMealPlanCell.delegate = self
        return dailyMealPlanCell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dailyMealPlanArray.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 85.00
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let dailyMealPlanCell = tableView.cellForRowAtIndexPath(indexPath) as! DailyMealPlanCell
        mealPageMode = mealPlanDetailPageMode.logMealPlan
        self.performSegueWithIdentifier("kShowMealDetail", sender: dailyMealPlanCell.dailyMeal)
    }
    func actionSheet(actionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int) {
        
        // get the selected social media
        switch actionSheet.buttonTitleAtIndex(buttonIndex)! {
            
        case &&"daily_meal_plan_email":
            //print("count \(self.foodLog.count)")
            
            
            DailyMealPlanUtils.generatePdfAndEmail(self.noOfCoreSnacks, noOfCoreMeals: self.noOfCoreMeals, foodLog: self.foodLog , fromViewController: self,pdfName : self.selectedDailyMealPlanName ?? "", dailyMealPlanModel: self.dailyMealPlanModelSelected)
            
            /*    let pdfManager = PdfManager()
             pdfManager.createHeaderTags(["SI","Name","Type","Protein","Cal","Carb","Fats","Fibre","Cholesterol","Iron","VitaminA","VitaminC","Sugar","Potassium","Sodium","Trans","Saturated","Polyunsaturated","Monounsaturated"])
             for(var i=0;i<self.foodLog.count;i++){
             pdfManager.createSingleRowItem(["\(i)","\(self.foodLog[i].foodName)","\(self.foodLog[i].mealType)","\(self.foodLog[i].protien)","\(self.foodLog[i].calcium)","\(self.foodLog[i].carbs)","\(self.foodLog[i].fat)","\(self.foodLog[i].fiber)","\(self.foodLog[i].cholesterol)","\(self.foodLog[i].iron)","\(self.foodLog[i].vitaminA)","\(self.foodLog[i].vitaminC)","\(self.foodLog[i].sugar)","\(self.foodLog[i].potassium)","\(self.foodLog[i].sodium)","\(self.foodLog[i].trans)","\(self.foodLog[i].saturated)","\(self.foodLog[i].polyunsaturated)","\(self.foodLog[i].monounsaturated)"])
             }
             pdfManager.toHtml()
             self.PDFCreator = pdfManager.createAndAttachPdfAsEmail("Meal.pdf", completion: { (result) -> Void in
             //print("Pdf details :\(result)")
             self.sendEmail()
             })
             
             */
            // performSegueWithIdentifier("kSegueSendMealPlan", sender: nil)
            
        case "FYM":
            //        performSegueWithIdentifier("kSegueSendMealPlan", sender: nil)
            showSendMealToFriends(selectedDailyMealPlanId!)
            //print("FYM")
            
        default: return
        }
    }
    
    
    func showSendMealToFriends(dailyMealPlanId:String) -> (){
        
        SendDetailsViewController.shareDailyMealPlan(dailyMealPlanId, fromViewController: self)
    }
    
    func didSelectFriends(friendIds: [String]) {
        
    }
    
    func editMeal(cell: DailyMealPlanCell) {
        
        mealPageMode = mealPlanDetailPageMode.editingMealPlan
        self.performSegueWithIdentifier("kShowMealDetail", sender: cell.dailyMeal)
        
    }
    
    
    
    func showShareActionSheet(cell: DailyMealPlanCell) {
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        selectedDailyMealPlanId = cell.dailyMeal.guId
        DailyMealPlanItemDetailResponse.fetchMealPlanDetail(selectedDailyMealPlanId!,showHUD: true) { (dailyMealPlanResponseModel : DailyMealPlanResponseModel?, error) -> () in
            
            if dailyMealPlanResponseModel != nil {
                
                let foodLogs = dailyMealPlanResponseModel!.mealPlanFoods as [DailyMealFoodModel]
                self.dailyMealPlanModelSelected  = dailyMealPlanResponseModel
                self.selectedDailyMealPlanName = dailyMealPlanResponseModel?.mealPlanName
                self.foodLog = foodLogs
                self.noOfCoreSnacks = Int(dailyMealPlanResponseModel!.mealSnackNo)!
                self.noOfCoreMeals = Int(dailyMealPlanResponseModel!.mealCoreNo)!
                // show action sheet
                self.actionSheet.showInView(self.view)
                
            }
        }
    }
    
    func showUserProfile(userId: String) {
        let manageStoryboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        // instantiate the initial view controller
        let profileViewController = manageStoryboard.instantiateViewControllerWithIdentifier("kProgressVC") as! ProfileViewController
        profileViewController.userId = userId
        self.navigationController?.pushViewController(profileViewController, animated: true)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "kSegueSendMealPlan" {
        }
        else if segue.identifier == "kSegueSendMealPlan" {
            
        } else if segue.identifier == "kShowMealDetail" {
            
            let dailyMealPlanDetailViewController  = segue.destinationViewController as! DailyMealPlanDetailViewController
            dailyMealPlanDetailViewController.pageMode = mealPageMode
            let mealItem = sender as! DailyMealPlanListModel
            dailyMealPlanDetailViewController.mealPlanId = mealItem.guId
            dailyMealPlanDetailViewController.title = mealItem.name
            
        }
    }
    
    func swipeableTableViewCell(cell: SWTableViewCell!, didTriggerRightUtilityButtonWithIndex index: Int) {
        // called when the right utility buttons are clicked
        
        let cellIndexPath = tableViewDailyMealPlan.indexPathForCell(cell)
        let dailyMealPlanId = dailyMealPlanArray[cellIndexPath!.row].guId
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        //delete the daily meal plan
        DailyMealPlanDeleteResponse.deleteDailyMealPlan(dailyMealPlanId) { (responseStatus) -> () in
            if responseStatus == "OK" {
                let dailyMealPlan = self.dailyMealPlanArray.filter({$0.guId == dailyMealPlanId})
                
                if self.dailyMealPlanArray.count != 0 {
                    
                    // remove the daily meal plan
                    self.dailyMealPlanArray.remove(dailyMealPlan[0])
                    self.tableViewDailyMealPlan.reloadData()
                }
            }
        }
        
    }
    
    func swipeableTableViewCellShouldHideUtilityButtonsOnSwipe(cell: SWTableViewCell!) -> Bool {
        // prevent multiple cells from showing utilty buttons simultaneously
        
        return true
    }
    
    
    @IBAction func unwindToDailyMealPlanViewController(segue: UIStoryboardSegue) {
    }
    
    func dragTableDidTriggerLoadMore(tableView: UITableView!) {
        // called when the load more is selected
        
        self.offset = dailyMealPlanArray.count
        self.fetchDailyMealPlans(offset,limit: 15,doLoadMore: true)
        // finish the load more
        return
    }
    
    func dragTableLoadMoreCanceled(tableView: UITableView!) {
        // called when the load more is cancelled
        NSObject.cancelPreviousPerformRequestsWithTarget(self, selector: Selector("finishLoadMore"), object: nil)
    }
    
    func finishLoadMore() {
        // to stop the load more and populate the tableview with new items
        tableViewDailyMealPlan.finishLoadMore()
        //tableViewMessage.reloadData()
    }
    
    func fetchDailyMealPlans(offset:Int,limit:Int,doLoadMore:Bool){
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        // get the daily mealplan list
        DailyMealPlanListResponse.fetchDailyMealPlanList(offset, limit: limit,showHUD: true) { (dailyMealPlanList, error) -> () in
            
            if doLoadMore {
                // finish the load more
                if error == nil {
                    
                    self.dailyMealPlanArray += dailyMealPlanList
                    
                }else {
                    
                    //error alert
                }
                
                self.tableViewDailyMealPlan.finishLoadMore()
                
            }else {
                self.dailyMealPlanArray = dailyMealPlanList
            }
            
            if self.refreshControl != nil {
                
                // stop pull to refresh
                self.refreshControl?.endRefreshing()
            }
            
            self.tableViewDailyMealPlan.reloadData()
            
            
        }
    }
    
}
