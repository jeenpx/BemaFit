//
//  UserPersonelDetailsViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 05/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UserPersonelDetailsViewController: UITableViewController, UITextFieldDelegate, UIGestureRecognizerDelegate, UIAlertViewDelegate {
    
    @IBOutlet weak var barButtonNextIcon: UIBarButtonItem!
    @IBOutlet weak var barButtonPreviousIcon: UIBarButtonItem!
    @IBOutlet weak var textFieldFirstName: UITextField!
    @IBOutlet weak var textFieldLastName: UITextField!
    @IBOutlet weak var textFieldUserName: UITextField!
    @IBOutlet weak var textFieldEmail: UITextField!
    @IBOutlet weak var textFieldWebsite: UITextField!
    @IBOutlet weak var buttonImage: UIButton!
    @IBOutlet weak var textFieldPassword: UITextField!
    @IBOutlet weak var textFieldConfirmPassword: UITextField!
    var currentTextField = UITextField()
    internal var canDismissView = true
    var alert = UIAlertView()
    
    @IBOutlet weak var labelTermandConditions: UILabel!
    let FymUserModel = FymUser.sharedFymUser
    
    struct StoryBoard {
        
        struct SegueIdentifiers {
            static let PersonnelShow = "kShowPersonnel"
        }
    }
    
    func capitalizeTextFields() -> ()
    {
        self.textFieldFirstName.autocapitalizationType = UITextAutocapitalizationType.Words;
        self.textFieldLastName.autocapitalizationType = UITextAutocapitalizationType.Words;
//        self.textFieldUserName.autocapitalizationType = UITextAutocapitalizationType.Words;
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBarHidden = false
        self.capitalizeTextFields()
        let titleDictionary: NSDictionary = [NSForegroundColorAttributeName: UIColor.whiteColor()]
        self.navigationController?.navigationBar.titleTextAttributes = titleDictionary as? [String : AnyObject]
        
        // set border of button Image
        buttonImage.layer.borderWidth = 1.0
        buttonImage.layer.borderColor = UIColor.darkGrayColor().CGColor
        
        if (AppConfiguration.sharedAppConfiguration.isFacebookUser) {
            
            loadWithFacebookCredentials()
            
        } else {
            
            // load with already entered credentials
            loadWithExistingCredentials()
        }
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelTermandConditionsWithGesture:")
        tapGesture.delegate = self
        labelTermandConditions.addGestureRecognizer(tapGesture)
    }
    
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(true)
        canDismissView = true
        barButtonPreviousIcon.enabled = true
        barButtonNextIcon.enabled = true
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        alert.dismissWithClickedButtonIndex(0, animated: false)
        // view is inactive, abort all checks
    }
    
   override func viewDidDisappear(animated: Bool) {
    
        alert.dismissWithClickedButtonIndex(0, animated: false)

    }
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        cell.setSeparatorInsetZero()
    }
    
    private func loadWithFacebookCredentials() {
        
        textFieldFirstName.text = UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserFirstName
        textFieldLastName.text = UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserLastName
        textFieldUserName.text = UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserName
        textFieldEmail.text = UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserEmail
        
        let profilePicURL = "http://graph.facebook.com/" + UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserId! + "/picture?type=large"
        
        buttonImage.setImage(UIImage(data: NSData(contentsOfURL: NSURL(string: profilePicURL)!)!), forState: .Normal)
        
        self.FymUserModel.userImage = buttonImage.imageForState(.Normal)!
    }
    
    private func loadWithExistingCredentials() {
        
        textFieldFirstName.text = FymUserModel.userFirstName
        textFieldLastName.text = FymUserModel.userLastName
        textFieldUserName.text = FymUserModel.userUserName
        textFieldEmail.text = FymUserModel.userEmail
        textFieldWebsite.text = FymUserModel.userWebsite
        textFieldPassword.text = FymUserModel.userPassword
        textFieldConfirmPassword.text = FymUserModel.userPassword
        
        // check for the existing image
        if FymUserModel.userImage != nil {
            self.buttonImage .setImage(FymUserModel.userImage, forState: .Normal) }
    }
    
    private func storeDataLocally() {
        
       
        // store data locally
        FymUserModel.userFirstName = textFieldFirstName.text!
        FymUserModel.userLastName  = textFieldLastName.text!
        FymUserModel.userUserName  = textFieldUserName.text!
        FymUserModel.userEmail     = textFieldEmail.text!
        FymUserModel.userWebsite   = textFieldWebsite.text != "" ? textFieldWebsite.text! : ""
        FymUserModel.userPassword  = textFieldPassword.text!
    }
    
    func didTaplabelTermandConditionsWithGesture(tapGesture: UITapGestureRecognizer) {
        
        self.performSegueWithIdentifier("kTermsPage", sender: nil)
    }
    
    @IBAction func buttonActionSetImage(sender: UIButton) {
        
        currentTextField.resignFirstResponder()
        
        storeDataLocally()
        // bring image picker view
        
        ImagePickerManager.sharedManager.presentImagePicker(self, completionHandler: { (image, source) -> () in
            sender.setImage(image,forState: .Normal)
            self.FymUserModel.userImage = image
            
        })
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        
        currentTextField = textField
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        // resign keyboard
        textField.resignFirstResponder()
        return false
    }
    
    func didPresentAlertView(alertView: UIAlertView) {
        canDismissView = false
    }
    
    func alertViewCancel(alertView: UIAlertView) {
        canDismissView = true
    }
    
    func alertView(alertView: UIAlertView, didDismissWithButtonIndex buttonIndex: Int) {
        canDismissView = true
        barButtonPreviousIcon.enabled = true
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        // managing the textfield input: limit the characters to only of numeric type
        var result = true
        if textField == textFieldPassword || textField == textFieldConfirmPassword {
            let prospectiveText = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
            if string.characters.count > 0 {
                let resultingStringLengthIsLegal = prospectiveText.characters.count <= 10
                result =  resultingStringLengthIsLegal
            }
        } else if textField == textFieldUserName {
            
           if string == " "{
                result = false
            }
        }
        return result
    }

    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        storeDataLocally()
    }
    
    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool {
        if (identifier == StoryBoard.SegueIdentifiers.PersonnelShow) {
            
            barButtonPreviousIcon.enabled = false
        }
        barButtonNextIcon.enabled = false
        return true
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    @IBAction func buttonActionNext(sender: UIBarButtonItem) {
        
        currentTextField.resignFirstResponder()
        
        // check all fields are entered
        var validityCheck = checkAllFields()
        
        if !validityCheck {
            
           
            return
        }
        
        if validityCheck {
            // check the email entered is valid in style
            validityCheck = textFieldEmail.text!.isValidEmail()
            
            if !validityCheck {
                
                self.showAlert(&&"notice", message: &&"enter_valid_email_alert_message")
                return
            }

        }
        
        if textFieldWebsite.text != "" {
        
            //check for validity of website
            let checkWebSiteValidity = textFieldWebsite.text!.websiteString()
        
            validityCheck = checkWebSiteValidity.valid
            
            self.textFieldWebsite.text = checkWebSiteValidity.urlString
            if !validityCheck {
            
               self.showAlert(&&"notice", message: &&"enter_valid_website_alert_message")
                
                return
            } else {
                
                textFieldWebsite.text = checkWebSiteValidity.urlString
            }
        }
        
        if validityCheck {
            
            // check password is of 6 characters
            validityCheck = checkPasswordValidity()
            
            if !validityCheck {
                
                self.showAlert(&&"notice", message: &&"password_minimum_character_count_alert_message")
                return
            }
            
            if validityCheck {
                // check both password and confirm password fields are same
                validityCheck = confirmPassword()
            }
            
            if !validityCheck {
                
                self.showAlert(&&"notice", message: &&"password_mismatch_alert_message")
                return
            }
        }
        
        if validityCheck {

            checkForUserExisting()
        }
    }
    
    func checkForUserExisting() {
        
        
        UserVerificationResponse.verifyUser(textFieldEmail.text!, userFacebookId: "", userName: textFieldUserName.text!, completionHandler: { (userVerificationModel) -> () in
            
            AppConfiguration.sharedAppConfiguration.userVerification = userVerificationModel
            
            //print("user validity---\((AppConfiguration.sharedAppConfiguration.userVerification?.userExists as! Bool))")
            
            // check for the user is avlid for sign up
            if (AppConfiguration.sharedAppConfiguration.userVerification?.emailExists  as! Bool) == false && (AppConfiguration.sharedAppConfiguration.userVerification?.userNameExists  as! Bool) == false {
                
                // navigate to personal details view
                self.performSegueWithIdentifier(StoryBoard.SegueIdentifiers.PersonnelShow, sender: nil)
                
            } else {
                
                if (AppConfiguration.sharedAppConfiguration.userVerification?.emailExists  as! Bool) == true {
                    
                    self.showAlert(&&"notice", message: &&"user_already_exist_alert_message")

                } else if (AppConfiguration.sharedAppConfiguration.userVerification?.userNameExists  as! Bool) == true {
                    
                    self.showAlert(&&"notice", message: &&"user_name_already_exist_alert_message")

                }
            }
            
            }, failure: { (failedWithError) -> () in
                
                self.showAlert(&&"notice", message: failedWithError)
                
        })
    }
    
    func showAlert(title: String, message: String) {
        
        // show alert controller if possible else show alert view
//        if NSClassFromString(Class.UIAlertController) != nil {
//            
//            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
//            
//            alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
//            
//            self.presentViewController(alert, animated: true, completion: nil)
//            return
//        }
//        else {
        
            alert = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"ok")
            alert.show()
            return
//        }
    }
    
    func confirmPassword() -> Bool {
        // return true if password and confirmpassword are same
        return textFieldPassword.text == textFieldConfirmPassword.text ? true : false
    }
    
    func checkPasswordValidity() -> Bool {
        // return password contains 6 characters

        return  textFieldPassword.text!.utf16.count  >= 6 ? true : false
    }
    
    @IBAction func buttonActionBack(sender: UIBarButtonItem) {
       
        barButtonNextIcon.enabled = false
//        sleep(1)
        alert.dismissWithClickedButtonIndex(0, animated: false)
        self.navigationController?.popViewControllerAnimated(false)
    }
    
    func checkAllFields() -> Bool {
        // check all fields are non empty
       
        barButtonPreviousIcon.enabled = false

       if self.textFieldFirstName.isEmpty {
            
            showAlert(&&"first_name")
            return false;
        }
        if self.textFieldLastName.isEmpty {
            showAlert(&&"last_name")
            return false;
        }
        if self.textFieldUserName.isEmpty {
            showAlert(&&"username")
            return false;
        }
        if self.textFieldEmail.isEmpty {
            showAlert(&&"email")
            return false;
        }
//        if self.textFieldWebsite.isEmpty {
//            showAlert(&&"website")
//            return false;
//        }
        if self.textFieldPassword.isEmpty {
            showAlert(&&"password")
            return false;
        }
        if self.textFieldConfirmPassword.isEmpty {
            showAlert(&&"cpassword")
            return false;
        }
        
        
        /*
        
        "first_name"
        "last_name"
        "username"
        "email"
        "website"
        "password"
        "cpassword"
        "please_enter"*/
        barButtonPreviousIcon.enabled = true

        return true;
        
    }
    
   
    
    @IBAction func unwindToUserPersonelDetailsViewController(segue: UIStoryboardSegue) {
        
        self.navigationController?.navigationBarHidden = false

    }
    
    func showAlert(fieldName:String){
    
        alert = UIAlertView(title: &&"notice", message: &&"please_enter"+" "+fieldName, delegate: self, cancelButtonTitle: &&"Ok")
        alert.show()
    }
    
}
