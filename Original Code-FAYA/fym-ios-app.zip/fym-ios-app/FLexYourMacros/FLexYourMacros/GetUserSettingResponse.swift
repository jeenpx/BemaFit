//
//  GetUserSettingResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 28/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class GetUserSettingResponse: NSObject {
    
    var settings: [SettingsModel]?
    var metaModel: MetaModel?
    var user_id: String?
    
    class var UserSettingsResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        // give referece to meta model
        responseMapping.addPropertyMapping(GetUserSettingResponse.metaModelKeyMapping)
        // give reference to changePassword mapping
        responseMapping.addPropertyMapping(GetUserSettingResponse.userSettingModelMapping)
        
        return responseMapping
    }

    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    
    private class var userSettingModelMapping :RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathUserSettings, toKeyPath: "settings", withMapping: SettingsModel.objectMapping)
    }
    
    
    class var userResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: UserSettingsResponseMapping, method: .GET, pathPattern: Constants.ServiceConstants.userSettingsUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
  
    class func userSettingsRequest(completionHandler: (userSettingsResponse:GetUserSettingResponse) -> ()) {
        SVProgressHUD.show()
        RestKitManager.setToken(true)
        let settingResponse = GetUserSettingResponse()
        settingResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId!
        // get the objects from the path login
        RestKitManager.sharedManager().getObject(settingResponse, path:nil, parameters: ["locale" : "\(NSLocale.currentLocale().objectForKey(NSLocaleLanguageCode)!)"], success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) in
        let userSettingResponse = mappingResult.firstObject as! GetUserSettingResponse

        //check for success
       if userSettingResponse.metaModel?.responseCode != 200 {
       return;
        }
            // set up the completion handler with response
            completionHandler(userSettingsResponse: userSettingResponse)
            
           /* if let set = userSettingResponse.settings as [SettingsModel]? {
                for obj in set {
                    //println(obj.settingsId)
                    //println(obj.title)
                    //println(obj.status)
                    //println("******************")
                }
            }
            */
              SVProgressHUD.dismiss()
        
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
             SVProgressHUD.dismiss()
                //print("failed to load masterdata with error \(error)")
        })

    }
    
    
    

    
    
}
