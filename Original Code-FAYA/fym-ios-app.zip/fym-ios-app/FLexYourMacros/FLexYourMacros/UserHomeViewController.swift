//
//  UserHomeViewController.swift
//  FlexYourMacros
//
//  Created by DBG-39 on 05/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class UserHomeViewController: UITableViewController, UIAlertViewDelegate {
    
    @IBOutlet weak var buttonFacebookLogIn: UIButton!
    @IBOutlet weak var buttonSignUp: UIButton!
    @IBOutlet weak var imageScrollView: ImageScrollView!
    
    @IBOutlet weak var scrollView: UIScrollView!
    struct StoryBoard {
        
        struct SegueIdentifiers {
            static let PersonnelShow    = "kShowPersonalView"
            static let EmailShow        = "kEmailLogIn"
        }
        
        struct ViewControllerIdentifiers {
            static let LogInVC = "kEmailVC"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // setup scroll images
        imageScrollView.arrayImages = ["Logo", "Logo", "Logo"]
        
        // set border for buttonSignUp
        buttonSignUp.layer.borderColor = UIColor.lightGrayColor().CGColor
        buttonSignUp.layer.borderWidth = 1.0
        
        loadAllMAsterData()
        // call load master data
        //        AppConfiguration.loadAllMAsterData { (loadedmasterData) -> () in
        
        //        }
        self.navigationController?.navigationBarHidden = false
        
    }
    
    
    func loadAllMAsterData() {
        
        MasterDataResponse.fetchMasterData { (masterDataModelEnglish, masterDataModelSpanish) -> () in
            
            AppConfiguration.sharedAppConfiguration.masterDataModelEnglish = masterDataModelEnglish
            AppConfiguration.sharedAppConfiguration.masterDataModelSpanish = masterDataModelSpanish
        }
    }
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBarHidden = true
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    @IBAction func buttonActionFacebookLogIn(sender: UIButton) {
        
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        FymUser.resetSharedInstance()
        
        // connect to fb session and logIn with facebook
        //   let permissions:NSArray = NSArray(array:["public_profile","email","publish_actions","public_profile"])
        
        FacebookManager.logout();
        FacebookManager.openSessionWithReadPermissionsWithHandler { (result, error) -> Void in
            
            if error != nil {
                //print("Facebook login failed");
                FacebookManager.logout();
            }
            else
            {
                if result.isCancelled || result.declinedPermissions.count>0{
                    //print("permissions declined \(result.declinedPermissions)")
                }
                
                if !reachability {
                    
                    self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                    return
                }
                
                SVProgressHUD.show()
                
                FacebookManager.getUserDetail({ (userDetails) -> Void in
                    
                    SVProgressHUD.dismiss()
                    
                    //print("Access Token from Facebook is \(FBSDKAccessToken.currentAccessToken().tokenString)", terminator: "")
                    let userDictionary = userDetails as! Dictionary <String, AnyObject>
                    
                    UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserId = userDictionary["id"] as? String
                    UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserName = userDictionary["name"] as? String
                    UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserFirstName = userDictionary["first_name"] as? String
                    UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserLastName = userDictionary["last_name"] as? String
                    UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserEmail = userDictionary["email"] as? String
                    UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserGender = userDictionary["gender"] as? String
                    
                    UserFacebookCredentialModel.sharedUserFacebookCredentialModel.userFbAccessToken = FBSDKAccessToken.currentAccessToken().tokenString
                    
                    if !reachability {
                        
                        self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                        return
                    }
                    
                    UserVerificationResponse.verifyUser(UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserEmail!, userFacebookId: UserFacebookCredentialModel.sharedUserFacebookCredentialModel.fbUserId!, completionHandler: { (userVerificationModel) -> () in
                        
                        AppConfiguration.sharedAppConfiguration.userVerification = userVerificationModel
                        
                        // check for the user is avlid for sign up
                        if (AppConfiguration.sharedAppConfiguration.userVerification?.facebookIdExists as! Bool) == false {
                            
                            AppConfiguration.sharedAppConfiguration.isFacebookUser = true
                            
                            // navigate to personal details view
                            self .performSegueWithIdentifier(StoryBoard.SegueIdentifiers.PersonnelShow, sender: nil)
                        } else {
                            
                            AppConfiguration.sharedAppConfiguration.isFacebookUser = true
                            // log in with facebook
                            
                            if !reachability {
                                
                                self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                                return
                            }
                            
                            FacebookUserLogInResponse.logInFacebookUser(self, facebookAccessToken: UserFacebookCredentialModel.sharedUserFacebookCredentialModel.userFbAccessToken!, completionHandler: { (accessCredential, userDiet, userDetails) -> () in
                                
                                AppConfiguration.sharedAppConfiguration.userDetails = userDetails
                                
                                AppConfiguration.sharedAppConfiguration.userDiet = userDiet
                                
                                AppConfiguration.sharedAppConfiguration.userCredential = accessCredential
                                
                                //print("accesstoken:\(AppConfiguration.sharedAppConfiguration.userCredential?.accessToken)")
                                //print("userid:\(AppConfiguration.sharedAppConfiguration.userDetails?.userId)")
                                
                                self.appDelegate?.checkUserVerification({ (verifiedStatus) -> () in
                                    
                                    if !verifiedStatus {
                                        
                                        let userDefaults = NSUserDefaults.standardUserDefaults()
                                        
                                        AppConfiguration.sharedAppConfiguration.userEmail = userDefaults.objectForKey("user_email") as! String
                                        
                                        let alert =  UIAlertView(title: &&"notice", message: &&"To continue using the app, please verify the registered email", delegate: self, cancelButtonTitle: &&"ok", otherButtonTitles: &&"resend_email")
                                        alert.tag = 2
                                        alert.show()
                                        
                                    } else {
                                        
                                        self.appDelegate?.loadDashboard()
                                    }
                                })
                                
                                }, failedWithError: { (error) -> () in
                                    
                                    self.showAlert(&&"notice", message: error)
                                    
                            })
                            
                        }
                        }, failure: { (failedWithError) -> () in
                            
                            self.showAlert(&&"notice", message: failedWithError)
                            
                    })
                    
                })
                
                SVProgressHUD.dismiss()
            }};
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if alertView.tag == 2 {
            
            if buttonIndex == 1 {
                
                
                // resend email api called
                ResendEmailResponse.resendEmail(AppConfiguration.sharedAppConfiguration.userEmail, completionHandler: { (resendEmailResponse) -> () in
                    
                    if resendEmailResponse == nil {
                        UIAlertView(title: &&"notice", message: &&"failed_resend_email", delegate: nil, cancelButtonTitle: &&"ok").show()
                        
                        return }
                    if resendEmailResponse!.status == "OK" {
                        
                        UIAlertView(title: &&"email_sent", message: &&"check_the_email_1" + "\(AppConfiguration.sharedAppConfiguration.userEmail). " + &&"check_the_email_2", delegate: nil, cancelButtonTitle: &&"ok").show()
                        
                    }
                })
                
                self.appDelegate?.loadLogin()
                
            } else {
                self.appDelegate?.loadLogin()
            }
        }
    }
    
    
    func showAlert(title: String, message: String) {
        
        // show alert controller if possible else show alert view
        
        if #available(iOS 8.0, *) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
            alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            return
        } else {
            // Fallback on earlier versions
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"ok").show()
            return
        }
        
    }
    
    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool {
        
        if (identifier == StoryBoard.SegueIdentifiers.EmailShow) {
            
            let signInViewController = self.storyboard?.instantiateViewControllerWithIdentifier(StoryBoard.ViewControllerIdentifiers.LogInVC) as! UserEmailLogInViewController
        }
        return true
    }
    
    @IBAction func buttonActionSignUpWithEmail(sender: UIButton) {
        
        UserFacebookCredentialModel.resetSharedInstance()
        AppConfiguration.sharedAppConfiguration.isFacebookUser = false
        FymUser.resetSharedInstance()
        
        // navigate to personal details view
        self .performSegueWithIdentifier(StoryBoard.SegueIdentifiers.PersonnelShow, sender: nil)
        
    }
    @IBAction func unwindToUserHomeViewController(segue: UIStoryboardSegue) {
        self.navigationController?.navigationBarHidden = false
        
    }
    
    
}
