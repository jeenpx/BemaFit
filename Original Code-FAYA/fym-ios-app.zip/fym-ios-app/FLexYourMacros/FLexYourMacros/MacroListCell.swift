//
//  MacroListCell.swift
//  FlexYourMacros
//
//  Created by DBG on 17/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class MacroListCell: UITableViewCell {

    @IBOutlet weak var viewBullet: UIView!
    @IBOutlet weak var labelGoalPercentage: UILabel!
    @IBOutlet weak var labelGoalValue: UILabel!
    
    var itemDetails:[String:String] = [String:String]() {
        didSet {
            
            labelGoalPercentage.text = itemDetails["percentage"]! + "%"
            let itemType = itemDetails["type"]!
            labelGoalValue.text = itemDetails["total"]!+"g "+itemType

            switch itemType {
                case &&"calories":
                    viewBullet.backgroundColor = UIColor(red: 39.0/255.0, green: 141.0/255.0, blue: 253.0/255.0, alpha: 1.0)
                    labelGoalValue.text = labelGoalValue.text?.stringByReplacingOccurrencesOfString("g", withString: "")
                case &&"protein": viewBullet.backgroundColor = UIColor(red: 101.0/255.0, green: 173.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                case &&"carbs": viewBullet.backgroundColor = UIColor(red: 167.0/255.0, green: 206.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                case &&"fat": viewBullet.backgroundColor = UIColor(red: 204.0/255.0, green: 227.0/255.0, blue: 254.0/255.0, alpha: 1.0)
                case &&"fiber": viewBullet.backgroundColor = UIColor(red: 114.0/255.0, green: 112.0/255.0, blue: 114.0/255.0, alpha: 1.0)
                default: break
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
