//
//  NewsFeedShare.swift
//  FlexYourMacros
//
//  Created by Aromal Sasidharan on 7/13/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation
typealias FacebookShareContentCallback = () -> (FacebookShareModel)

class NewsFeedShare: NSObject, UIActionSheetDelegate {

    var currentViewContoller:UIViewController? = nil
    var facebookShareContentCallback : FacebookShareContentCallback?
    
    class var sharedManager: NewsFeedShare {
        struct Singleton {
            static let instance = NewsFeedShare()
        }
        return Singleton.instance
    }
    
    
    func showActionSheet(showFacebook: Bool, fromViewController controller: UIViewController, facebookShareContentCallback:FacebookShareContentCallback)
    {
        self.facebookShareContentCallback = facebookShareContentCallback
        currentViewContoller = controller
        var shareButtons:[String] = []
        if(showFacebook)
        {
            shareButtons.append("Facebook")
        }
        
         let actionSheet = UIActionSheet(title: nil, delegate: nil, cancelButtonTitle: &&"cancel", destructiveButtonTitle: nil, otherButtonTitles: "Facebook")
        
        actionSheet.delegate = self
        actionSheet.showInView(controller.view);
    }
    func actionSheet(actionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int) {
        
        switch actionSheet.buttonTitleAtIndex(buttonIndex)! {
            
        case "Facebook":
            
            FacebookManager.showShareDialogWithShareModel(currentViewContoller!, andModel: self.facebookShareContentCallback!(), andCallback: { (status, results, error) -> Void in
                if error != nil {
                    //print(error)
                }
                else {
                    //print("success")
                    
                }
            })
        default :
            break;
        }
    }
}