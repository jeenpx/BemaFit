//
//  GeolocationServiceUpdater.m
//  GeolocationServiceSample
//
//  Created by dbgmacmini2 dbg on 13/03/14.
//  Copyright (c) 2014 codebase. All rights reserved.
//

#import "GeolocationServiceUpdater.h"
#import <CoreLocation/CoreLocation.h>
@implementation GeolocationServiceUpdater
static BOOL isUpdatingLocation;

@synthesize clLocationManager,locationUpdate,desiredMeterDistance,oldLocationPoint,geocoder;
- (id)init
{
    self = [super init];
    if (self) {
        clLocationManager = [[CLLocationManager alloc]init];
        [clLocationManager setDelegate:self];
        self.geocoder = [[CLGeocoder alloc] init];
        clLocationManager.distanceFilter = kCLDistanceFilterNone;
        desiredMeterDistance = 0.0;
        clLocationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation;
        [self requestAlwaysAuthorization];
//        [clLocationManager requestWhenInUseAuthorization];
//        [clLocationManager requestAlwaysAuthorization];
     
//        [self performSelector:NSSelectorFromString(@"scanForCurrentLocation") withObject:nil afterDelay:1000];
//        [self scanForCurrentLocation];
        
    }
    return self;
}
- (void)requestAlwaysAuthorization
{
   
        if([self.clLocationManager respondsToSelector:@selector(requestAlwaysAuthorization)])
        [self.clLocationManager requestAlwaysAuthorization];
   
}


- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {

    
    if ([error domain] == kCLErrorDomain) {
        
        // We handle CoreLocation-related errors here
        switch ([error code]) {
                // "Don't Allow" on two successive app launches is the same as saying "never allow". The user
                // can reset this for all apps by going to Settings > General > Reset > Reset Location Warnings.
            case kCLErrorDenied:
                
            case kCLErrorLocationUnknown:
                
            default:
                break;
        }
    } else {
        // We handle all non-CoreLocation errors here
    }
}
//- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
//{
////    NSLog(@"Locations Found %@",locations);
////    [locations lastObject];
//    locationUpdate([locations lastObject]);
////    [clLocationManager stopUpdatingLocation];
//}
-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
//    NSLog(@"Location Found %@",newLocation);
    
    if (newLocation.horizontalAccuracy < 0) {
        return;
    }
    NSTimeInterval interval = [newLocation.timestamp timeIntervalSinceNow];
    if (abs(interval)>30)
        return;
    
    CLLocationDistance distance = [newLocation distanceFromLocation:oldLocationPoint];
    
    isUpdatingLocation = TRUE;
    if (oldLocationPoint==nil||distance>=desiredMeterDistance)
    
    {
//        NSLog(@"distance is %f desired distance %f",distance,desiredMeterDistance);
        self.oldLocationPoint = newLocation;
        [GeolocationServiceUpdater fireNotificationWithObject:newLocation];
        if(locationUpdate)
        {
            locationUpdate(newLocation,distance);
        }
    }
    
    
}

-(void)locationManagerDidPauseLocationUpdates:(CLLocationManager *)manager
{
     isUpdatingLocation = FALSE;
}
-(void)locationManagerDidResumeLocationUpdates:(CLLocationManager *)manager
{
     isUpdatingLocation = TRUE;
}
+(BOOL)isLocationServicesEnabled
{
    
    BOOL flag1 = [CLLocationManager locationServicesEnabled];
    
    BOOL flag2 = [CLLocationManager authorizationStatus]==kCLAuthorizationStatusDenied;
    
//    NSLog(@"is iphone location enabled %d",flag1);

//        NSLog(@"is location access denied %d",flag2);
    
    if(flag2)
    {
    }
//    else if(!flag1)
//    {
//        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Location Service Disabled"
//                                                        message:@"Please enable location service in settings"
//                                                       delegate:nil
//                                              cancelButtonTitle:@"OK"
//                                              otherButtonTitles:nil];
//        [alert show];
//    }
    
    
    return flag1&&!flag2;
    
}
+(BOOL)isGeoLocationEnabled
{
    __block BOOL isEnabled = TRUE;
    
    [GeolocationServiceUpdater isGeoLocationEnabled:^(BOOL result, GeolocationServiceUpdaterDisbledType type) {
        isEnabled = result;
    }];
    
    
    return isEnabled;
    
}
+(void)isGeoLocationEnabled:(void(^)(BOOL result,GeolocationServiceUpdaterDisbledType type))block
{
    
    BOOL flag1 = [CLLocationManager locationServicesEnabled];
    
    BOOL flag2 = [CLLocationManager authorizationStatus]==kCLAuthorizationStatusDenied;
    
    BOOL flag3 = isUpdatingLocation;
    
    
    if(flag1==false)
    {
        block(flag1,NOT_ENABLED_LOCATION_SERVICE);
    }
    else if (flag2==TRUE)
    {
        block(!flag2,NOT_ENABLED_IN_PHONE_SETTINGS);
    }
    else if (flag3 == false)
    {
        block(flag3,NOT_ENABLED_IN_APP_SETTINGS);
    }
    else
    {
        block(TRUE,ALL_SETTINGS_ENABLED);
    }
    
    

    
}

-(void)scanForCurrentLocation
{
    if([GeolocationServiceUpdater isLocationServicesEnabled])
    {
     
        if(!isUpdatingLocation)
        {
//            NSLog(@"not scanning so started scanning");
                [clLocationManager startUpdatingLocation];
           isUpdatingLocation = TRUE;
        }
        else{
//            NSLog(@"already scanning");
        }
    }
    else
    {
//        NSLog(@"Location Not Enabled");
    }
    
}
-(void)stopScanningLocations
{
    
    [clLocationManager stopUpdatingLocation];
       isUpdatingLocation = FALSE;
    
}
-(CLLocation*)getLastKnowLocation
{
    
    return clLocationManager.location;
    
}
-(void)getLastKnowLocationName:(UpdatedLocationName)updatedLocationNameBlock
{

     oldLocationPoint = (oldLocationPoint==nil)?clLocationManager.location:oldLocationPoint;
    
    [geocoder reverseGeocodeLocation:oldLocationPoint completionHandler:^(NSArray *placemarks, NSError *error) {
        
        if (error == nil && [placemarks count] > 0)
        {
             CLPlacemark *placemark = [placemarks lastObject];
            
            // strAdd -> take bydefault value nil
//            NSLog(@"Place mark is %@",placemark);
            NSString *strAdd = nil;
            
            if ([placemark.subThoroughfare length] != 0)
                strAdd = placemark.subThoroughfare;
            
            if ([placemark.thoroughfare length] != 0)
            {
                // strAdd -> store value of current location
                if ([strAdd length] != 0)
                    strAdd = [NSString stringWithFormat:@"%@ %@",strAdd,[placemark thoroughfare]];
                else
                {
                    // strAdd -> store only this value,which is not null
                    strAdd = placemark.thoroughfare;
                }
            }
            
            if ([placemark.postalCode length] != 0)
            {
                if ([strAdd length] != 0)
                    strAdd = [NSString stringWithFormat:@"%@ %@",strAdd,[placemark postalCode]];
                else
                    strAdd = placemark.postalCode;
            }
            
            if ([placemark.locality length] != 0)
            {
                if ([strAdd length] != 0)
                    strAdd = [NSString stringWithFormat:@"%@ %@",strAdd,[placemark locality]];
                else
                    strAdd = placemark.locality;
            }
            
            if ([placemark.administrativeArea length] != 0)
            {
                if ([strAdd length] != 0)
                    strAdd = [NSString stringWithFormat:@"%@ %@",strAdd,[placemark administrativeArea]];
                else
                    strAdd = placemark.administrativeArea;
            }
            
            if ([placemark.country length] != 0)
            {
                if ([strAdd length] != 0)
                    strAdd = [NSString stringWithFormat:@"%@ %@",strAdd,[placemark country]];
                else
                    strAdd = placemark.country;
            }
            
//            strAdd = [[strAdd componentsSeparatedByString:@" "] firstObject];
            strAdd = [strAdd stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            updatedLocationNameBlock(oldLocationPoint,strAdd,placemark,nil);
        }
        else
        {
             updatedLocationNameBlock(nil,nil,nil,error);
        }
    }];
}
+(void)getLastKnownLocationName:(UpdatedLocationName)updatedLocationNameBlock
{
     GeolocationServiceUpdater* updater = [GeolocationServiceUpdater getSharedGeoLocationUpdater];
    [updater getLastKnowLocationName:updatedLocationNameBlock];
    
}
+(CLLocation*)getLastKnowLocation
{
    GeolocationServiceUpdater* updater = [GeolocationServiceUpdater getSharedGeoLocationUpdater];
    return [updater getLastKnowLocation];
}
+(void)startScaningForLocationChange
{
    GeolocationServiceUpdater* updater = [GeolocationServiceUpdater getSharedGeoLocationUpdater];
    
    [updater scanForCurrentLocation];
    
    [GeolocationServiceUpdater fireNotificationStateChanged];
}
+(void)stopScanningForLocationChange
{
    GeolocationServiceUpdater* updater = [GeolocationServiceUpdater getSharedGeoLocationUpdater];
    [updater stopScanningLocations];
    [GeolocationServiceUpdater fireNotificationStateChanged];
}
-(void)getUpdatedLocation:(UpdatedLocation)locationUpdater
{
    self.locationUpdate = locationUpdater;
}
+(GeolocationServiceUpdater*)getSharedGeoLocationUpdater
{
    static GeolocationServiceUpdater *_geoLocationServiceUpdater = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _geoLocationServiceUpdater = [[GeolocationServiceUpdater alloc] init];
       
    });
    
    return _geoLocationServiceUpdater;

}
+(void)setDesiredMeterDistance:(float)meters
{
    GeolocationServiceUpdater* updater = [GeolocationServiceUpdater getSharedGeoLocationUpdater];
    updater.desiredMeterDistance = meters;
}
+(void)getUpdatedLocation:(UpdatedLocation)locationUpdater
{
    GeolocationServiceUpdater* updater = [GeolocationServiceUpdater getSharedGeoLocationUpdater];
    [updater getUpdatedLocation:locationUpdater];
}
+(void)registerForUpdatesWith:(id)object andSelector:(SEL)selector
{
    [[NSNotificationCenter defaultCenter] addObserver:object selector:selector name:NOTIFICATION_UPDATE_LOCATION object:nil];
}
+(void)fireNotificationWithObject:(CLLocation*)object
{
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_UPDATE_LOCATION object:object];
}

+(void)fireNotificationStateChanged
{
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_STATE_CHANGED object:nil];
}
+(void)registerForStateChangeWith:(id)object andSelector:(SEL)selector
{
    [[NSNotificationCenter defaultCenter] addObserver:object selector:selector name:NOTIFICATION_STATE_CHANGED object:nil];
}
@end
