//
//  ChangeProfileSettingsViewController.swift
//  FlexYourMacros
//
//  Created by DBG on 23/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ChangeProfileSettingsViewController: UITableViewController , UITextFieldDelegate , UIAlertViewDelegate{
    @IBOutlet weak var tableViewCellPushnotification: UITableViewCell!
    @IBOutlet weak var tableViewCellDescription: UITableViewCell!
    
    @IBOutlet weak var tableViewCellPrivateCell: UITableViewCell!
    var descrption = ""
    var height :String! = "160"
    var profileType :String! = ""
    
    // variable used to check if the user changed an field or data in the form
    var isValueUpdated = false
    
    var alert: UIAlertView?
    
    @IBOutlet weak var textFieldDescription: UITextField!
    @IBOutlet weak var switchProfileType: UISwitch!
    @IBOutlet weak var switchPushNotification: UISwitch!
    @IBOutlet weak var labelPrivate: UILabel!
    
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableViewCellPushnotification.hidden = true
        self.tableViewCellDescription.hidden = true
        self.tableViewCellPrivateCell.hidden = true
        self.switchProfileType.hidden = true
        self.switchPushNotification.hidden = true
        
        
        self.textFieldDescription.autocapitalizationType = UITextAutocapitalizationType.Words
        // refresh user details
        AppConfiguration.refreshUserDetails { (refreshedUserDetails) -> () in
            
            if refreshedUserDetails {
                SVProgressHUD.dismiss()
                self.initialiseUserData()
                
            }
        }
        
    }
    
    func initialiseUserData() {
        
        height = AppConfiguration.sharedAppConfiguration.userDetails?.userHeight
        profileType = AppConfiguration.sharedAppConfiguration.userDetails?.userType
        
        // push notification
        switchPushNotification.setOn(AppConfiguration.sharedAppConfiguration.userDetails?.userPushNotificationStatus == "Yes" ? true : false, animated: false)
        
        descrption = AppConfiguration.sharedAppConfiguration.userDetails?.userDescription as? String ?? ""
        
        // populate the details
        textFieldDescription.text = descrption
        
        // set the profile type
        if profileType == "Public" {
            self.switchProfileType.setOn(false, animated: false)
            self.labelPrivate.text = &&"private_profile_disabled"
            
        }else {
            self.switchProfileType.setOn(true, animated: false)
            self.labelPrivate.text = &&"private_profile_enabled"
        }
        
        self.tableViewCellPushnotification.hidden = false
        self.tableViewCellDescription.hidden = false
        self.tableViewCellPrivateCell.hidden = false
        self.switchProfileType.hidden = false
        self.switchPushNotification.hidden = false
        
    }
    
    // MARK: - Button Actions
    
    @IBAction func switchProfileType(sender: UISwitch) {
        // if user updated the status
        isValueUpdated = true
        
        if switchProfileType.on {
            //print("Switch is on /private")
            profileType = "Private"
            self.labelPrivate.text = &&"private_profile_enabled"
            
        } else {
            //print("Switch is off /public ")
            profileType = "Public"
            self.labelPrivate.text = &&"private_profile_disabled"
            
        }
        
    }
    
    @IBAction func buttonActionPushNotificationSwitch(sender: UISwitch) {
        // if user updated the status
        isValueUpdated = true
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        // hide keyboard on return
        textField.resignFirstResponder()
        return true
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        // if user updated the status
        isValueUpdated = true
        
        let newLength = textField.text!.utf16.count + string.utf16.count - range.length
        return newLength <= 500 // Bool
    }
    
    @IBAction func buttonActionBackNavigate(sender: UIBarButtonItem) {
        self.textFieldDescription.resignFirstResponder()
        // check if any value is changed by user
        if (isValueUpdated) {
                self.showAlert(&&"notice", message: &&"save_the_changes_in_the_settings_message")
            
        } else {
            self.navigationController?.popViewControllerAnimated(true)
        }
        
    }
    
    func showAlert(title: String, message: String) {
        //         show alert controller if possible else show alert view
            if #available(iOS 8.0, *) {
                let alert = UIAlertController(title:title, message: message, preferredStyle: .Alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .Default) { action -> Void in
                    
                    let parameterDictionary: [String:String] = ["type":self.profileType,"height":self.height,"description":self.textFieldDescription.text!, "push_notification" : self.switchPushNotification.on ? "Yes" : "No"]
                    // update the user information
                    UpdateUserResponse.updateUserInfo(parameterDictionary, completionHandler: { (updateResponse) -> () in
                        
                        let resonse = updateResponse
                        //print("respone code :\(resonse.metaModel?.responseCode)")
                        //print("respone status :\(resonse.metaModel?.responseStatus)")
                        
                        // check for success
                        if resonse.metaModel?.responseCode == 200 {
                            // Successsfully completed
                            //print("respone code :\(resonse.metaModel?.responseCode)")
                            //print("respone status :\(resonse.metaModel?.responseStatus)")
                            
                            // update the profile page if the image is updated
                            let notification = NSNotification(name: Constants.updateUserProfile,
                                object: nil)
                            NSNotificationCenter.defaultCenter().postNotification(notification)
                            
                            
                            self.navigationController?.popViewControllerAnimated(true)
                            
                        }else{
                            //print("respone code :\(resonse.metaModel?.responseCode)")
                            
                        }
                        
                        
                    })
                    
                    
                    })
                alert.addAction(UIAlertAction(title: &&"cancel", style: .Cancel,  handler: { action in
                    
                    self.navigationController?.popViewControllerAnimated(true)
                    
                }))
                // show alert
                presentViewController(alert, animated: true, completion: nil)
            } else {
                // Fallback on earlier versions
                alert = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: &&"cancel", otherButtonTitles: &&"ok")
                alert?.show()
            }
            
       
            
        
    }
    
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if alertView == alert {
            if buttonIndex == 0 {
                // cancel button
                self.navigationController?.popViewControllerAnimated(true)
                
            } else {
                
                // ok button
                let parameterDictionary: [String:String] = ["type":self.profileType,"height":self.height,"description":self.textFieldDescription.text!, "push_notification" : self.switchPushNotification.on ? "Yes" : "No"]
                
                // update the user information
                UpdateUserResponse.updateUserInfo(parameterDictionary) { (updateResponse) -> () in
                    
                    let resonse = updateResponse
                    
                    // check for success
                    if resonse.metaModel?.responseCode == 200 {
                        // Successsfully completed
                        // update the profile page if the image is updated
                        let notification = NSNotification(name: Constants.updateUserProfile,
                            object: nil)
                        NSNotificationCenter.defaultCenter().postNotification(notification)
                        
                        self.navigationController?.popViewControllerAnimated(true)
                        
                    } else {
                        //print("respone code :\(resonse.metaModel?.responseCode)")
                        
                    }
                }
            }
        }
    }
}
