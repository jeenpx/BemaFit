//
//  ProgressLogWeightAndFatResponse.swift
//  FlexYourMacros
//
//  Created by mini on 18/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _ProgressLogWeightAndFatResponse = ProgressLogWeightAndFatResponse()

class ProgressLogWeightAndFatResponse: NSObject {
    
    var meta: MetaModel?

    class var sharedProgressLogWeightAndFatResponse: ProgressLogWeightAndFatResponse {
        return _ProgressLogWeightAndFatResponse
    }
    
    
    class var userResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(ProgressLogWeightAndFatResponse.metaModelKeyMapping)
        
        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.postWeightAndFatUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "meta", withMapping: MetaModel.objectMapping)
    }
 
    class func postWeightandBodyFat(date: String, weight: String, bodyFat: String, completionHandler: (successful: Bool) -> ()) {
        
        SVProgressHUD.show()
        RestKitManager.setToken(true)

        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(nil, method: .POST, path: Constants.ServiceConstants.postWeightAndFatUrl, parameters: ["log_date" : date, "log_weight": weight, "log_bodyfat": bodyFat], constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            SVProgressHUD.dismiss()
            let logWeightAndFatResponse = mappingResult.firstObject as! ProgressLogWeightAndFatResponse
            // check for success
            if logWeightAndFatResponse.meta?.responseCode != 200 {
                return;
            }
            completionHandler(successful: true)
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                //print("failed to load signup with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
}