//
//  ContactUsResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 02/07/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ContactUsResponse: NSObject {
   
    var metaModel: MetaModel?

    class var contactUsResponseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        // give referece to meta model
        responseMapping.addPropertyMapping(ContactUsResponse.metaModelKeyMapping)        
        
        return responseMapping
    }
    
    class var userResponseDescriptor: RKResponseDescriptor {
        
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: contactUsResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.contactUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    class func sendMessageToFYM(message:String,completionHandler: (response:ContactUsResponse) -> ()) {
         SVProgressHUD.show()
        RestKitManager.setToken(true)
        
        var parameterDictionary: [String:String] {
            // create the parameter dictionary
            return ["message":message]
        }
        
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(nil, method: .POST, path: Constants.ServiceConstants.contactUrl, parameters: parameterDictionary, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let response = mappingResult.firstObject as! ContactUsResponse
            
            completionHandler(response: response)
             SVProgressHUD.dismiss()
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                //print("failed to load contact us with error \(error)")
                SVProgressHUD.dismiss()

        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
    

    
}
