//
//  TermsViewController.swift
//  FlexYourMacros
//
//  Created by DBG on 13/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class TermsViewController: UIViewController, UIWebViewDelegate , UIAlertViewDelegate {
    
    
    @IBOutlet weak var webViewTermsAndPolicies: UIWebView!

    var alert1: UIAlertView?
    var urlString:String = "http://flexyourmacros.com/terms.php"
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //      self.title = "Hello"
        
        let reachability = appDelegate!.internetReachable
        
        if !reachability {
            
            self.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        let request = NSURLRequest(URL: NSURL(string: urlString)!)
        
        // loading the url on webView
        webViewTermsAndPolicies.loadRequest(request)
    }
    
    func webViewDidStartLoad(webView: UIWebView) {
        
        SVProgressHUD.show()
    }
    
    func webViewDidFinishLoad(webView: UIWebView) {
        
        SVProgressHUD.dismiss()
    }
    
    func webView(webView: UIWebView, didFailLoadWithError error: NSError?) {
        
        SVProgressHUD.dismiss()
    }
    
    @IBAction func buttonActionBack(sender: UIBarButtonItem) {
        
        // checks if the settings needed to be updated
        self.navigationController?.popViewControllerAnimated(true)
        
    }
    
    class func openAdsInEmbedBrowser(fromViewcontroller:UINavigationController?, withUrl urlString:String) -> () {
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let adViewController = storyBoard.instantiateViewControllerWithIdentifier("embededBrowser") as! TermsViewController
        adViewController.title = &&"advertisment"
        adViewController.urlString = urlString
        fromViewcontroller!.pushViewController(adViewController, animated: true)
        
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if alertView == alert1 {
           
        }
    }
    
    func showAlert(title: String, message: String) {
        // show alert controller if possible else show alert view
            if #available(iOS 8.0, *) {
                let alert = UIAlertController(title:title, message: message, preferredStyle: .Alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .Default) { action -> Void in
                    
                    })
                
                // show alert
                presentViewController(alert, animated: true, completion: nil)
            } else {
                // Fallback on earlier versions
                alert1 =  UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: nil, otherButtonTitles: &&"ok")
                alert1?.show()

            }
        
    }
    
    
}
