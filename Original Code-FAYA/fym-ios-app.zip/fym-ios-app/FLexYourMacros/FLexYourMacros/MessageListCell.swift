//
//  MessageListCell.swift
//  FlexYourMacros
//
//  Created by dbgattila on 3/24/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class MessageListCell: SWTableViewCell {
    
    @IBOutlet weak var imageViewProfilePic: UIImageView!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelTimeStamp: UILabel!
    @IBOutlet weak var labelDescription: UILabel!
    @IBOutlet weak var imageViewReadStatus: UIImageView!
    
    var userProfileDelegate: UserProfileDelegate?
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        // configure the cell
        configureCell()
    }
    
    var messageItemModel: MessageItemModel? {
        didSet {
            // set values for ui elements
            
            labelName.text = MessageItemModel.getMessageFriend(messageItemModel!).friendUserName
            labelName.userInteractionEnabled = true
            let tapGesture = UITapGestureRecognizer(target: self, action: "didTaplabelUserNameWithGesture:")
            tapGesture.delegate = self
            
            // add tap gesture to the username label
            labelName.addGestureRecognizer(tapGesture)
            
            labelDescription.text = messageItemModel?.message
            imageViewProfilePic.setImageWithURL(NSURL(string:  MessageItemModel.getMessageFriend(messageItemModel!).friendPhoto), placeholderImage: UIImage(named: "PlaceHolderProfilePic"))
            
            //print(messageItemModel!.createdDate!)
            
            if let date = messageItemModel?.createdDate {
                let newDate = date.utcDateValue("yyyy-MM-dd HH:mm:ss")
                labelTimeStamp.text = newDate?.timeAgo()
            }
            
            if let readStatus = messageItemModel?.readStatus {
                if readStatus == "Read" {
                    imageViewReadStatus.image = UIImage(named: "GreyRoundIcon")
                }
            }
        }
    }
    
    func configureCell() {
        
        // Add right utility buttons
        rightUtilityButtons = configureRightUtilityButtons() as [AnyObject]
    }
    
    func configureRightUtilityButtons() -> NSArray {
        // configure right utility button for swipe delete
        
        let rightUtilityButtons = NSMutableArray()
        rightUtilityButtons.addUtilityButtonWithBackgroundColor(UIColor(red: 224.0/255.0, green: 224.0/255.0, blue: 224.0/255.0, alpha: 1.0),
            andTitleColor: UIColor.redColor(), andTitle: NSLocalizedString("message_swipe_delete_title", comment: ""))
        return rightUtilityButtons
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func didTaplabelUserNameWithGesture(tapGesture: UITapGestureRecognizer) {
        //print("didTaplabelUserNameWithGesture entered...")
        userProfileDelegate?.userProfile(MessageItemModel.getMessageFriend(messageItemModel!).friendId)
    }
    
}
