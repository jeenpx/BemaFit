//
//  FollowUserResponse.swift
//  FlexYourMacros
//
//  Created by DBG on 11/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class FollowUserResponse: NSObject {
   
    var metaModel: MetaModel?
    var user_id: String?
    var friend_id:String?
    
    class var userResponseMapping: RKObjectMapping {
        let responseMapping = RKObjectMapping(forClass: self)
        responseMapping.addPropertyMapping(FollowUserResponse.metaModelKeyMapping)
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    
    class var userResponseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        let responseDescriptor = RKResponseDescriptor(mapping: userResponseMapping, method: .POST, pathPattern: Constants.ServiceConstants.kFollowUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }
    
   
    //api for following user
    class func followUser(friendId:String,completionHandler: (response:FollowUserResponse) -> ()) {
        RestKitManager.setToken(true)
        
        let response = FollowUserResponse()
        response.user_id = AppConfiguration.sharedAppConfiguration.userDetails!.userId
        response.friend_id = friendId
      
        let request: NSMutableURLRequest = RestKitManager.sharedManager().multipartFormRequestWithObject(response, method: .POST, path:nil, parameters: nil, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
        })
        
        let operation: RKObjectRequestOperation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation: RKObjectRequestOperation!, mappingResult: RKMappingResult!) -> Void in
            
            let followUserResponse = mappingResult.firstObject as! FollowUserResponse
           // //println("respone code :\(followUserResponse.metaModel?.responseCode)")
           // //println("respone status :\(followUserResponse.metaModel?.responseStatus)")
            completionHandler(response: followUserResponse)
            
            }, failure: { (operation: RKObjectRequestOperation!, error: NSError!) -> Void in
                
                //print("failed to load follow with error \(error)")
        })
        
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }

}
