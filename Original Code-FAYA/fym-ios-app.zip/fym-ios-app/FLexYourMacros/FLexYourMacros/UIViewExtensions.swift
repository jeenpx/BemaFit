//
//  UIViewExtensions.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 10/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

let kMainScreenWidth = Double(UIScreen.mainScreen().bounds.width)

extension UIView {
    
    func disableAutoresizingMask() {
        translatesAutoresizingMaskIntoConstraints = false
    }
    
    func centerHorizontallyInSuperview() {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let constraints = NSLayoutConstraint(item: self, attribute: NSLayoutAttribute.CenterX, relatedBy: NSLayoutRelation.Equal, toItem: superview, attribute: NSLayoutAttribute.CenterX, multiplier: 1, constant: 0)
        superview!.addConstraint(constraints)
    }
    
    func centerVerticallyInSuperview() {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let constraints = NSLayoutConstraint(item: self, attribute: NSLayoutAttribute.CenterY, relatedBy: NSLayoutRelation.Equal, toItem: superview, attribute: NSLayoutAttribute.CenterY, multiplier: 1, constant: 0)
        superview!.addConstraint(constraints)
    }
    
    func fillSuperView(margin: Int = 0) {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let views = ["view": self]
        let metrics = ["margin": margin]
        superview!.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("H:|-margin-[view]-margin-|", options: NSLayoutFormatOptions.AlignAllCenterX, metrics: metrics, views: views))
        superview!.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("V:|-margin-[view]-margin-|", options: NSLayoutFormatOptions.AlignAllCenterY, metrics: metrics, views: views))
    }
    
    func setLeftMargin(margin: Int = 15) {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let views = ["view": self]
        let metrics = ["margin": margin]
        
        superview!.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("H:|-margin-[view]", options: NSLayoutFormatOptions(), metrics: metrics, views: views))
    }
    
    func setRightMargin(margin: Int = 15) {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let views = ["view": self]
        let metrics = ["margin": margin]
        
        superview!.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("H:[view]-margin-|", options: NSLayoutFormatOptions(), metrics: metrics, views: views))
    }
    
    func setTopMargin(margin: Int = 15) {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let views = ["view": self]
        let metrics = ["margin": margin]
        
        superview!.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("V:|-margin-[view]", options: NSLayoutFormatOptions(), metrics: metrics, views: views))
    }
    
    func setBottomMargin(margin: Int = 15) {
        
        // can't set constraints if we dont have a superview
        if superview == nil {
            return
        }
        
        disableAutoresizingMask()
        let views = ["view": self]
        let metrics = ["margin": margin]
        
        superview!.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("V:[view]-margin-|", options: NSLayoutFormatOptions(), metrics: metrics, views: views))
    }    
}