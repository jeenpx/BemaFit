//
//  CompanyTimingsCell.swift
//  FlexYourMacros
//
//  Created by DBG on 12/07/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class CompanyTimingsCell: UITableViewCell {
    
    @IBOutlet weak var labelDay: UILabel!
    @IBOutlet weak var labelTimings: UILabel!
    
    var directoryCellMode = DirectoryCellMode.Monday
    
    var  directory = DirectoryModel() {
        didSet {
            
            if let workingHours = directory.workingHours {
                if workingHours.count > 0 {
                    switch directoryCellMode {
                    case .Monday:
                        
                        labelDay.text = directoryCellMode.rawValue
                        
                        // set monday working hours
                        if let monday = directory.getWorkingHours("Monday") {
                            labelTimings.text = monday.getNormalTimeFromRailway(true) + " - " + monday.getNormalTimeFromRailway(false)
                        }
                        
                        // set background color
                        backgroundColor = UIColor.grayColorDirectory()
                        
                    case .Tuesday:
                        labelDay.text = directoryCellMode.rawValue
                        
                        // set tuesday working hours
                        if let tuesday = directory.getWorkingHours("Tuesday") {
                            labelTimings.text = tuesday.getNormalTimeFromRailway(true) + " - " + tuesday.getNormalTimeFromRailway(false)
                        }
                        
                        // set background color
                        backgroundColor = UIColor.whiteColor()
                        
                    case .Wednesday:
                        labelDay.text = directoryCellMode.rawValue
                        
                        // set wednesday working hours
                        if let wednesday = directory.getWorkingHours("Wednesday") {
                            labelTimings.text = wednesday.getNormalTimeFromRailway(true) + " - " + wednesday.getNormalTimeFromRailway(false)
                        }
                        
                        // set background color
                        backgroundColor = UIColor.grayColorDirectory()
                        
                    case .Thursday:
                        labelDay.text = directoryCellMode.rawValue
                        
                        // set thursday working hours
                        if let thursday = directory.getWorkingHours("Thursday") {
                            labelTimings.text = thursday.getNormalTimeFromRailway(true) + " - " + thursday.getNormalTimeFromRailway(false)
                        }
                        
                        // set background color
                        backgroundColor = UIColor.whiteColor()
                        
                    case .Friday:
                        labelDay.text = directoryCellMode.rawValue
                        
                        // set friday working hours
                        if let friday = directory.getWorkingHours("Friday") {
                            labelTimings.text = friday.getNormalTimeFromRailway(true) + " - " + friday.getNormalTimeFromRailway(false)
                        }
                        
                        // set background color
                        backgroundColor = UIColor.grayColorDirectory()
                        
                    case .Saturday:
                        labelDay.text = directoryCellMode.rawValue
                        
                        // set saturday working hours
                        if let saturday = directory.getWorkingHours("Saturday") {
                            labelTimings.text = saturday.getNormalTimeFromRailway(true) + " - " + saturday.getNormalTimeFromRailway(false)
                        }
                        
                        // set background color
                        backgroundColor = UIColor.whiteColor()
                        
                    case .Sunday:
                        labelDay.text = directoryCellMode.rawValue
                        
                        // set sunday working hours
                        if let sunday = directory.getWorkingHours("Sunday") {
                            labelTimings.text = sunday.getNormalTimeFromRailway(true) + " - " + sunday.getNormalTimeFromRailway(false)
                        }
                        
                        // set background color
                        backgroundColor = UIColor.grayColorDirectory()                        
                    }
                }
                else {
                    // no working hours
                    labelDay.hidden = true
                    labelTimings.hidden = true
                    showEmptyTableViewCellMessage(&&"no_working_hours")
                    // set background color
                    backgroundColor = UIColor.whiteColor()
                }
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
