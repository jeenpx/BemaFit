//
//  NSMutableArray.swift
//  FlexYourMacros
//
//  Created by dbgattila on 3/30/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

extension NSMutableArray {
    
    func addUtilityButtonWithBackgroundColor(backGroundColor: UIColor, andTitleColor titleColor: UIColor, andTitle title: String) {
        // add  an utility button with background and title color
        
        let button = UIButton.buttonWithType(.Custom) as! UIButton
        button.backgroundColor = backGroundColor
        button.setTitle(title, forState: .Normal)
        button.setTitleColor(titleColor, forState: .Normal)
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        addObject(button)
    }
}

