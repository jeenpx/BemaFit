//
//  DailyMealPlanItemDetailResponse.swift
//  FlexYourMacros
//
//  Created by Minimol BI on 14/12/15.
//  Copyright © 2015 Digital Brand Group. All rights reserved.
//

import Foundation

private let _DailyMealPlanItemDetailResponse = DailyMealPlanItemDetailResponse()

class DailyMealPlanItemDetailResponse: NSObject {
    
    var metaModel = MetaModel()
    var dailyMealPlanResponseModel = DailyMealPlanResponseModel()
    var dailyMealPlanId: String?
    
    class var sharedDailyMealPlanItemDetailResponse: DailyMealPlanItemDetailResponse {
        return _DailyMealPlanItemDetailResponse
    }
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // give referece to meta model
        responseMapping.addPropertyMapping(DailyMealPlanItemDetailResponse.metaModelKeyMapping)
        
        // give reference to FoodListMapping
        responseMapping.addPropertyMapping(DailyMealPlanItemDetailResponse.dailyMealPlanResponseModelKeyMapping)
        
        return responseMapping
    }
    
    private class var metaModelKeyMapping : RKRelationshipMapping {
        
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
    }
    
    private class var dailyMealPlanResponseModelKeyMapping : RKRelationshipMapping {
        
        //food log model is used since both auto suggested food and logged food are of same model
        return RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathSuggestedFoodResult, toKeyPath: "dailyMealPlanResponseModel", withMapping: DailyMealPlanResponseModel.objectMapping)
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        // create the response descriptor
        
        let responseDescriptor = RKResponseDescriptor(mapping: responseMapping, method: .GET, pathPattern: Constants.ServiceConstants.kDailyMealPlanDetailUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return responseDescriptor
    }

    class func fetchMealPlanDetail(dailyMealPlanId: String, showHUD: Bool = false,completionHandler:(dailyMealPlanResponseModel: DailyMealPlanResponseModel?, error: NSError?)->()) {
        
        RestKitManager.setToken(true)
        let dailyMealPlanItemDetailResponse = DailyMealPlanItemDetailResponse()
        dailyMealPlanItemDetailResponse.dailyMealPlanId = dailyMealPlanId
        
        if showHUD {
            SVProgressHUD.show()
        }
        // get the objects from the path login
        RestKitManager.sharedManager().getObject(dailyMealPlanItemDetailResponse, path: nil, parameters: nil, success: { (operation, mappingResult) in
            
            // map to correct datamodel
            let response = mappingResult.firstObject as! DailyMealPlanItemDetailResponse
            if showHUD {
                SVProgressHUD.dismiss()
            }

            if response.metaModel.responseCode != 200 {
                let error = NSError(domain: "FYM.DailyMealPlan", code: 1001, userInfo: ["title": "error", "message": "alert_daily_meal_detail_message"])
                // fire completion handler
                completionHandler(dailyMealPlanResponseModel: nil, error: error)
                
            }
            else {
                // fire completion handler
                completionHandler(dailyMealPlanResponseModel: response.dailyMealPlanResponseModel, error: nil)
            }
            
            }) { (operation, error) -> Void in
                // error
                let networkError = NSError(domain: "FYM.AutoSuggestFood", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
                
                // fire completion handler
                completionHandler(dailyMealPlanResponseModel: nil, error: networkError)
        }
    }
}
