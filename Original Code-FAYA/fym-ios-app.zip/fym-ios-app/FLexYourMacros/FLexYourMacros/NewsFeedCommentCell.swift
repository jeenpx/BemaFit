//
//  NewsFeedCommentsCell.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 13/04/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

protocol NewsFeedCommentCellDelegate {
    func newsFeedCommentCell(newsFeedCommentCell: NewsFeedCommentCell, didSelectUser userId: String)
    func newsFeedCommentCell(newsFeedCommentCell: NewsFeedCommentCell, didSelectHashTag hashTag: String)

}

protocol EnlargeImageCommentDelegate {
    func enlargeImageView(selectedCell: NewsFeedCommentCell, imageViewComment: UIImageView)
}

class NewsFeedCommentCell: SWTableViewCell, HashTagTextViewDelegate {

    var enlargeImageCommentDelegate: EnlargeImageCommentDelegate?

    // UI elements
    @IBOutlet private weak var imageViewProfilePic: UIImageView!
    @IBOutlet private weak var textViewComment: HashTagTextView!
    @IBOutlet private weak var imageViewComment: UIImageView!
    @IBOutlet private weak var labelTimeStamp: UILabel!
    
    // constraints
    @IBOutlet private weak var constraintImageViewHeight: NSLayoutConstraint!
    @IBOutlet private weak var constraintPadding: NSLayoutConstraint!
    
    var constraintTextViewHeight: [NSLayoutConstraint]?
    
    // NewsFeedCommentCellDelegate
    var newsFeedCommentCellDelegate: NewsFeedCommentCellDelegate?
    
    var isNetworkReachable: Bool {
        let reachability = (UIApplication.sharedApplication().delegate as! AppDelegate).internetReachable
        
        if !reachability {
            
            // no internet
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
        }
        
        return reachability
    }
    
    var newsFeed = NewsFeed() {
        didSet {
            
            // check whether the currrent user posted the feed
            if newsFeed.userId == AppConfiguration.sharedAppConfiguration.userDetails?.userId {
                
                // Add right utility buttons to all the comments
                rightUtilityButtons = configureRightUtilityButtons() as [AnyObject]
            }
            else {
                // feeds posted by friends
                
                if newsFeedComment.userId == AppConfiguration.sharedAppConfiguration.userDetails?.userId {
                    
                    // Add right utility buttons to the comments from user
                    rightUtilityButtons = configureRightUtilityButtons() as [AnyObject]
                }
            }
        }
    }
    
    // news feed data
    var newsFeedComment = NewsFeedComment() {
        didSet {
            
            // we dont need cell selection
            selectionStyle = .None
            
            // round edges for profile pic
            imageViewProfilePic.layer.cornerRadius = imageViewProfilePic.bounds.width / 2
            imageViewProfilePic.clipsToBounds = true
            
            textViewComment.text = newsFeedComment.comment
            textViewComment.configureForHashTagDetection(true)
            textViewComment.prependSender(newsFeedComment.userName, senderId: newsFeedComment.userId)
            textViewComment.hashTagTextViewDelegate = self
            
            if let profileImageURL = NSURL(string: newsFeedComment.userImage) {
                imageViewProfilePic.setImageWithURL(profileImageURL, placeholderImage: UIImage(named: "PlaceHolderProfilePic"))
            }
            
           
            
            labelTimeStamp.text = newsFeedComment.date.timeAgo()
            
            textViewComment.sizeToFit()
            textViewComment.layoutIfNeeded()
            
            hasImage = false
            if !newsFeedComment.image.isEmpty {
                imageViewComment.setImageWithURL(NSURL(string: newsFeedComment.image))
                hasImage = true
                let tapGesture = UITapGestureRecognizer(target: self, action: "didTapImageViewCommentWithGesture:")
                tapGesture.delegate = self
                
                // add tap gesture to the food imageview
                imageViewComment.addGestureRecognizer(tapGesture)
                imageViewComment.userInteractionEnabled = true
            }
            imageViewProfilePic.gestureRecognizers = [UITapGestureRecognizer(target: self, action: "imageViewProfilePicTapped:")]
        }
    }
    
    func didTapImageViewCommentWithGesture(tapGesture: UITapGestureRecognizer) {
        enlargeImageCommentDelegate?.enlargeImageView(self, imageViewComment: imageViewComment)
    }
    // default comment doesn't include image
    var hasImage: Bool = false {
        didSet {
            
            // update constraints based on image content
            constraintImageViewHeight.constant = hasImage ? 200 : 0
            constraintPadding.constant = hasImage ? 8 : 0
            
            updateConstraintsIfNeeded()
        }
    }
    
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//        
//        configureCell()
//    }
//    
//    func configureCell() {
//        
//        // Add right utility buttons
//        rightUtilityButtons = configureRightUtilityButtons() as [AnyObject]
//    }
    
    func configureRightUtilityButtons() -> NSArray {
        // configure right utility button for swipe delete
        
        let rightUtilityButtons = NSMutableArray()
        rightUtilityButtons.addUtilityButtonWithBackgroundColor(UIColor(red: 224.0/255.0, green: 224.0/255.0, blue: 224.0/255.0, alpha: 1.0),
            andTitleColor: UIColor.redColor(), andTitle: NSLocalizedString("message_swipe_delete_title", comment: ""))
        return rightUtilityButtons
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        
        imageViewComment.image = nil
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func hashTagTextView(hashTagTextView: HashTagTextView, didSelectUser user: String) {
        newsFeedCommentCellDelegate?.newsFeedCommentCell(self, didSelectUser: user)
    }
    
    func imageViewProfilePicTapped(sender: UITapGestureRecognizer) {
        newsFeedCommentCellDelegate?.newsFeedCommentCell(self, didSelectUser: newsFeedComment.userId)
    }
    
    func hashTagTextView(hashTagTextView: HashTagTextView, didSelectHashTag hashTag: String) {
        // hashtag
        // abort if no network
        if !isNetworkReachable { return }
        
        newsFeedCommentCellDelegate?.newsFeedCommentCell(self, didSelectHashTag: hashTag)
    }
    
    func hashTagTextView(hashTagTextView: HashTagTextView, didSelectBusinessDirectory businessDirectory: String) {
        // business directory
    }
}
