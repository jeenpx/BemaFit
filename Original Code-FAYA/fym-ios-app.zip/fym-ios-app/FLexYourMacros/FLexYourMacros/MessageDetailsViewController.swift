//
//  MessageDetailsViewController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 4/7/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class MessageDetailsViewController: SLKTextViewController, UITableViewDragLoadDelegate, UserProfileDelegate {
    
    // set the offset value
    var offset: Int = 0
    
    // set the limit value
    var limit: Int = 10
    
    // array holds the inbox messages
    var inboxMessages: [MessageItemModel]?
    
    // variable for pull to refresh
    var refreshControl: UIRefreshControl!
    
    // temporary array
    var arrayTemporary: [MessageItemModel]?
    
    // array to hold final messages
    var finalMessages: [MessageItemModel]?
    
    // instance variable holds selected message
    var selectedMessageThread: MessageItemModel?
    
    var messageListReplacedObject: MessageItemModel?
    
    var offscreenCells = [String: MessageDetailsCell]()
    
    struct MessageDetails {
        
        // cell identifier
        static let cellIdentifierMessageDetails = "kMessageDetailsCell"
        
        // cell name
        static let cellNameMessageDetails = "MessageDetailsCell"
        
        struct Segue {
            static let messageDetailProfileSegue = "kMessageDetailProfileSegue"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // configure pull to refresh
        configureRefreshControl()
        
        messageListReplacedObject = selectedMessageThread
        
        // to configure view
        configureView()
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        // list the thread messages
        listThreadMessages(offset, andLimit: limit, andFriendId: MessageItemModel.getMessageFriend(selectedMessageThread!).friendId, andPullToRefreshCalled: false, andShowProgressHUD: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func configureRefreshControl() {
        refreshControl = UIRefreshControl()
        
        // add the target
        refreshControl.addTarget(self, action: "pullToRefresh:", forControlEvents: UIControlEvents.ValueChanged)
        refreshControl.tintColor = UIColor.grayColor()
        
        // add refresh control to the tableview
        self.tableView.addSubview(refreshControl)
    }
    
    func configureView() {
        
        // set title for navigation bar
        self.navigationItem.title = MessageItemModel.getMessageFriend(selectedMessageThread!).friendUserName
        
        // set basic properties for the view
        // XXX double check this
        bounces = true
        shakeToClearEnabled = true
        keyboardPanningEnabled = true
        shouldScrollToBottomAfterKeyboardShows = false
        inverted = false // check
        
        // setup tableview
        tableView.separatorStyle = UITableViewCellSeparatorStyle.SingleLine
        tableView.registerNib(UINib(nibName: MessageDetails.cellNameMessageDetails, bundle: nil), forCellReuseIdentifier: MessageDetails.cellIdentifierMessageDetails)
        
        tableView.estimatedRowHeight = UITableViewAutomaticDimension
        
        // hide empty tableview cells
        tableView.tableFooterView = UIView(frame: CGRectZero)
        
        textView.pastableMediaTypes = .None
        
        rightButton.setTitle(&&"post_button_title", forState: .Normal)
        
        // setup textview
        textView.placeholder = NSLocalizedString("message_post_placeholder_text", comment: "")
        
        textInputbar.autoHideRightButton = false
        
        rightButton.setTitle(&&"post_button_title", forState: .Normal)
        
    }
    
    override func canPressRightButton() -> Bool {
        return super.canPressRightButton()
    }
    
    override func didPressRightButton(sender: AnyObject!) {
        // called when the right button is clicked
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        // cleanup the textview (weird huh?)
        dispatch_async(dispatch_get_main_queue()) {
            
            self.textView.slk_clearText(true)
            self.dismissKeyboard(true)
        }
        
        textView.refreshFirstResponder()
        
        sendMessage(textView.text.trimmedString(), andFriendId: MessageItemModel.getMessageFriend(selectedMessageThread!).friendId)
        
        //        // update tableview
        //        tableView.beginUpdates()
        //        messages.append(textView.text)
        //        tableView.insertRowsAtIndexPaths([NSIndexPath(forRow: 0, inSection: 0)], withRowAnimation: .Bottom)
        //        tableView.endUpdates()
        
        //        tableView.slk_scrollToBottomAnimated(true)
        
        
        
        // call the super method in the end
        // super method will do the cleanup
        super.didPressRightButton(sender)
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let count = self.inboxMessages?.count {
            return count
        }
        return 0
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let messageDetailsCell = tableView.dequeueReusableCellWithIdentifier(MessageDetails.cellIdentifierMessageDetails) as! MessageDetailsCell
        
        // save the message
        messageDetailsCell.messageThreadModel = inboxMessages?[indexPath.row]
        messageDetailsCell.userProfileDelegate = self
        
        messageDetailsCell.setNeedsUpdateConstraints()
        messageDetailsCell.updateConstraintsIfNeeded()
        
        return messageDetailsCell
    }
    
    //    override func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
    //        return 75
    //    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        var cell = offscreenCells[MessageDetails.cellIdentifierMessageDetails]
        if cell == nil {
            cell = tableView.dequeueReusableCellWithIdentifier(MessageDetails.cellIdentifierMessageDetails) as? MessageDetailsCell
            offscreenCells[MessageDetails.cellIdentifierMessageDetails] = cell
        }
        
        cell?.messageThreadModel = inboxMessages?[indexPath.row]
        
        cell?.setNeedsUpdateConstraints()
        cell?.updateConstraintsIfNeeded()
        cell?.bounds = CGRectMake(0.0, 0.0, CGRectGetWidth(tableView.bounds), CGRectGetHeight(cell!.bounds))
        
        cell?.setNeedsLayout()
        cell?.layoutIfNeeded()
        
        cell?.labelMessage.preferredMaxLayoutWidth = CGRectGetWidth(cell!.labelMessage.bounds)
        cell?.labelMessage.setNeedsUpdateConstraints()
        
        // Get the actual height required for the cell's contentView
        var height = cell?.contentView.systemLayoutSizeFittingSize(UILayoutFittingCompressedSize).height
        
        // Add an extra point to the height to account for the cell separator, which is added between the bottom
        // of the cell's contentView and the bottom of the table view cell.
        height = height! + 1
        
        return height!
        
    }
    
    override func didChangeKeyboardStatus(status: SLKKeyboardStatus) {
        
        if tableView.numberOfRowsInSection(0) > 0 {
            tableView.scrollToRowAtIndexPath(NSIndexPath(forRow: tableView.numberOfRowsInSection(0)-1, inSection: 0), atScrollPosition: UITableViewScrollPosition.Middle, animated: false)
        }
    }
    
    func listThreadMessages(offset: Int, andLimit limit: Int, andFriendId friendId: String, andPullToRefreshCalled doRefresh: Bool, andShowProgressHUD showLoader: Bool) {
        
        // get message thread
        MessageThreadResponse.getThreadMessages(offset, andLimit: limit, andFriendId: friendId, andShowProgressHUD: showLoader) { (totalMessages, messages) -> () in
            
            if doRefresh {
                // dragged pull to refresh
                
                // save to temporary array
                self.arrayTemporary = self.inboxMessages
                
                // make array empty
                self.inboxMessages = []
                
                // store messages to inboxmessages
                self.inboxMessages = messages
                
                // reverse inbox messages
                self.inboxMessages = self.inboxMessages?.reverse()
                
                // append temporary array to inbox messages
                if let messageThread:[MessageItemModel] = self.arrayTemporary {
                    for message in messageThread {
                        self.inboxMessages?.append(message)
                    }
                }
                self.arrayTemporary = []
            }
            else {
                
                if self.inboxMessages?.isEmpty == false {
                    // append new messages to existing messages
                    
                    if let messageThread:[MessageItemModel] = messages {
                        for message in messageThread {
                            //print(" messages in the thread:\(message.message)")
                            self.inboxMessages?.append(message)
                        }
                    }
                }
                else {
                    // emty array
                    
                    self.inboxMessages = messages
                }
                //reverse the array
                self.inboxMessages = self.inboxMessages?.reverse()
            }
            
            if self.refreshControl != nil {
                
                // stop pull to refresh
                self.refreshControl?.endRefreshing()
            }
            
            //fire notification to refresh message list thread
            
            NSNotificationCenter.defaultCenter().postNotificationName("RefreshMessageIdentifier", object: nil, userInfo: ["newMessage": self.inboxMessages?.last as! AnyObject, "method": "Read"])
            
            // reload tableview
            self.tableView.reloadData()
            
            if !doRefresh {
                
                if self.tableView.numberOfRowsInSection(0) > 0 {
                    self.tableView.scrollToRowAtIndexPath(NSIndexPath(forRow: self.tableView.numberOfRowsInSection(0)-1, inSection: 0), atScrollPosition: UITableViewScrollPosition.Middle, animated: false)
                }
            }
        }
    }
    
    func sendMessage(message: String, andFriendId friendId: String) {
        // send message to the friend
        
        MessageSendResponse.postMessage(message, andFriendId: friendId) { (sendMessage,meta) -> () in
            
            // response error
            if meta.responseCode == 406 {
                self.showAlert(&&"notice", message: &&"message_non_friends")
                return
            }
            //print(sendMessage.message)
            self.inboxMessages?.append(sendMessage)
            self.tableView.reloadData()
            
            if self.tableView.numberOfRowsInSection(0) > 0 {
                self.tableView.scrollToRowAtIndexPath(NSIndexPath(forRow: self.tableView.numberOfRowsInSection(0)-1, inSection: 0), atScrollPosition: UITableViewScrollPosition.Middle, animated: false)
            }
            
            NSNotificationCenter.defaultCenter().postNotificationName("RefreshMessageIdentifier", object: nil, userInfo: ["newMessage": self.inboxMessages?.last as! AnyObject, "method": "Post"])
            
        }
    }
    
    
    func pullToRefresh(sender: AnyObject) {
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            refreshControl.endRefreshing()
            return
        }
        
        if let count = self.inboxMessages?.count {
            // save messages count to offset
            
            offset = count
        }
        else {
            // set offset value to zero
            
            offset = 0
        }
        
        // list messages thread
        listThreadMessages(offset, andLimit: limit, andFriendId: MessageItemModel.getMessageFriend(selectedMessageThread!).friendId, andPullToRefreshCalled: true, andShowProgressHUD: false)
    }
    
    func showAlert(title: String, message: String) {
        
        if #available(iOS 8.0, *) {
            let alertView = UIAlertController(title: title,
                message: message, preferredStyle: .Alert)
            alertView.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
            presentViewController(alertView, animated: true, completion: nil)
        } else {
            // Fallback on earlier versions
            UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: &&"ok").show()
        }
    }
    
    func userProfile(userId: String) {
        performSegueWithIdentifier(MessageDetails.Segue.messageDetailProfileSegue, sender: userId)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == MessageDetails.Segue.messageDetailProfileSegue {
            let profileViewController = segue.destinationViewController as! ProfileViewController
            profileViewController.userId = sender as? String ?? ""
        }
    }
    
}