//
//  CreateNewsFeedResponse.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 04/06/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class CreateNewsFeedResponse: NSObject {
    
    var user_id = ""

    var metaModel = MetaModel()
    
    var newsFeed: NewsFeed?
    
    var newsFeedComment: NewsFeedComment?
    
    class var responseMapping: RKObjectMapping {
        
        let responseMapping = RKObjectMapping(forClass: self)
        
        // meta model mapping
        let metaModelMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathMeta, toKeyPath: "metaModel", withMapping: MetaModel.objectMapping)
        responseMapping.addPropertyMapping(metaModelMapping)

        // newsfeed mapping
        let newsFeedMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathNewsFeed, toKeyPath: "newsFeed", withMapping: NewsFeed.objectMapping)
        responseMapping.addPropertyMapping(newsFeedMapping)
        
        // newsfeedcomment mapping
        let newsFeedCommentMapping = RKRelationshipMapping(fromKeyPath: Constants.ServiceConstants.keyPathNewsFeedComment, toKeyPath: "newsFeedComment", withMapping: NewsFeedComment.objectMapping)
        responseMapping.addPropertyMapping(newsFeedCommentMapping)

        return responseMapping
    }
    
    class var responseDescriptor: RKResponseDescriptor {
        let createNewsFeedResponseDescriptor = RKResponseDescriptor(mapping: CreateNewsFeedResponse.responseMapping, method: .POST, pathPattern: Constants.ServiceConstants.kNewsFeedUrl, keyPath: nil, statusCodes: RKStatusCodeIndexSetForClass(RKStatusCodeClass.Successful))
        return createNewsFeedResponseDescriptor
    }
    
    class func create(params: [String: String], data: NSData?, completionHandler: (newsFeed: NewsFeed?, newsFeedComment: NewsFeedComment?, error: NSError?) -> ()) {
        
        RestKitManager.setToken(true)
        
        // route user id
        let createNewsFeedResponse = CreateNewsFeedResponse()
        createNewsFeedResponse.user_id = AppConfiguration.sharedAppConfiguration.userDetails?.userId ?? ""
        
        // create a multipart request 
        let request = RestKitManager.sharedManager().multipartFormRequestWithObject(createNewsFeedResponse, method: RKRequestMethod.POST, path: nil, parameters: params) { (formData) in
            
            // append data if we have data
            if let data = data {
                formData.appendPartWithFileData(data, name: "photo", fileName: "photo.jpg", mimeType: "image/jpg")
            }
        }
        
        // perform 
        let operation = RestKitManager.sharedManager().objectRequestOperationWithRequest(request, success: { (operation, mappingResult) in
            
            // get the response
            let response = mappingResult.firstObject as! CreateNewsFeedResponse
            
            // check for success
            var error: NSError?
            if response.metaModel.responseCode != 200 {
                error = NSError(domain: "FYM.NewsFeed", code: 1001, userInfo: ["title": "error", "message": params["feed_type"] == "feed" ? "alert_feed_post_message" : "alert_feed_comments_post_message"])
            }
                        
            // fire completionhandler
            completionHandler(newsFeed: response.newsFeed, newsFeedComment: response.newsFeedComment, error: error)

        }) { (operation, error) in

            // error
            let networkError = NSError(domain: "FYM.NewsFeed", code: 1000, userInfo: ["title": "alert_failed_parsing_title", "message": "alert_failed_parsing_message"])
            
            // fire completion handler
            completionHandler(newsFeed: nil, newsFeedComment: nil, error: networkError)
        }

        // enqueue operation
        RestKitManager.sharedManager().enqueueObjectRequestOperation(operation)
    }
}

    