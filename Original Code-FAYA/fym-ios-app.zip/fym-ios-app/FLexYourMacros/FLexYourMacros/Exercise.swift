//
//  Exercise.swift
//  FlexYourMacros
//
//  Created by mini on 25/05/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

// MARK:

enum ExerciseType: String {
    case Strength = "strength"
    case CardioVascular = "cardiovascular"
    case None = ""
}

enum ExerciseTypeId: String {
    case CardioVascular = "1"
    case Strength = "2"
    case None = ""
}

class Exercise: HeightCalculating {
    var name = ""
    var date = NSDate()
    var caloriesBurned = 0.0
    var exerciseId = ""
    var exerciseLogId = ""
    var exerciseMetValue = ""
    // in seconds
    var exerciseAmount = 0.0
    var exerciseMethod = ""
    var caloriesPerMinute = ""
    var caloriesPerHour = ""


    var expectedHeight: CGFloat {
        return 191.0
    }
    
    var exerciseTypeId: ExerciseTypeId = .None

    private(set) var exerciseType: ExerciseType = .None
    
    init(name: String) {
        self.name = name
    }
    
    func copy() -> Exercise {
        
        var copiedExercise: Exercise
        
        // create the correct exercise object
        if exerciseType == ExerciseType.Strength {
            copiedExercise = StrengthExercise(name: name)
            
        }
        else if exerciseType == ExerciseType.CardioVascular {
            copiedExercise = CardioVascularExercise(name: name)
        }
        else {
            copiedExercise = Exercise(name: name)
        }
        
        // copy the exercise values
        copiedExercise.exerciseId = exerciseId
        copiedExercise.date = date
        copiedExercise.caloriesBurned = caloriesBurned
        copiedExercise.exerciseType = exerciseType
        copiedExercise.exerciseTypeId = exerciseTypeId
        copiedExercise.exerciseMetValue = exerciseMetValue
        copiedExercise.caloriesPerMinute = caloriesPerMinute
        copiedExercise.caloriesPerHour = caloriesPerHour


        return copiedExercise
    }
    
    class func fetchExercisesLogs(offSet: String, showHUD: Bool = false, date: NSDate, completionHandler:(exerciseList: [Exercise])->()) {
        if showHUD {
            SVProgressHUD.show()
        }

        ExerciseResponse.fetchExerciseList(offSet, date: date) { (exerciseList, error) -> () in
            if showHUD {
                SVProgressHUD.dismiss()
            }
            if error == nil {
                completionHandler(exerciseList: exerciseList) }
        }
    }
    
    class func fetchExercises(offset: String,name: String, type: String, completionHandler:(exercises: [Exercise])->()) {
        
        ExerciseTypeResponse.fetchExerciseTypes(offset, name: name, type:type, completionHandler: { (exercises) -> () in
            completionHandler(exercises: exercises)
        })
       
    }
    
    class func fetchCardioExercises(offset: String, name: String, type: String, completionHandler:(cardioExercises: [CardioVascularExercise])->()) {
            Exercise.fetchExercises (offset,name:name, type:type, completionHandler: { (exercises) -> () in
//                let cardioExercises = exercises.filter { $0.exerciseType == .CardioVascular }
                completionHandler(cardioExercises: exercises as! [CardioVascularExercise])
            })
    }
    
    class func fetchStrengthExercises(offset: String, name: String, type: String, completionHandler:(strengthExercises: [StrengthExercise])->()) {
        Exercise.fetchExercises (offset, name:name, type:type, completionHandler: { (exercises) -> () in
//            let strengthExercises = exercises.filter { $0.exerciseType == .Strength }
            completionHandler(strengthExercises: exercises as! [StrengthExercise])
        })
    }
    
    class func createExercise(strengthExercise: StrengthExercise,cardioExercise: CardioVascularExercise, completionHandler:(createdExerciseId: String, successful: Bool, message: String)->()) {
        
        // create an exercise
        var paramDictionary = [String: String]()

        if strengthExercise.name != "" {
            
            paramDictionary["name"] = strengthExercise.name
            paramDictionary["amount"] = strengthExercise.exerciseAmount.stringValue
            paramDictionary["calorie_burned"] = strengthExercise.caloriesBurned.stringValue
            paramDictionary["type"] = "2"//ExerciseCategory.Strength.rawValue
            paramDictionary["number_of_sets"] = strengthExercise.sets.stringValue
            paramDictionary["rep_sets"] = strengthExercise.reps.stringValue
            paramDictionary["rep_set_weight"] = strengthExercise.weight.stringValue
            
        } else if cardioExercise.name != "" {
            
            paramDictionary["name"] = cardioExercise.name
            paramDictionary["amount"] = cardioExercise.exerciseAmount.stringValue
            paramDictionary["calorie_burned"] = cardioExercise.caloriesBurned.stringValue
            paramDictionary["type"] = "1"//ExerciseCategory.CardioVascular.rawValue
            paramDictionary["distance"] = cardioExercise.distance.stringValue
        }
        
        paramDictionary["locale"] = "\(NSLocale.currentLocale().objectForKey(NSLocaleLanguageCode)!)"

        ExerciseCreateResponse.createExercise(paramDictionary, completionHandler: { (createdExerciseId, successful, message) -> () in
            completionHandler(createdExerciseId: createdExerciseId, successful: successful, message: message)

        })
        
    }
    
    //delete an exercise
    class func deleteExercise(exerciseId: String, completionHandler:(deletedStatus: Bool)->()) {
        ExerciseDeleteResponse.deleteExercise(exerciseId, completionHandler: { (deletedStatus) -> () in
            completionHandler(deletedStatus: deletedStatus)
        })
    }
    
    class func updateExercise(exercise: Exercise, completionHandler:(updatedStatus: Bool)->()) {
        //update exercise date
        ExerciseUpdateResponse.updateExercise(exercise.date, exerciseId: exercise.exerciseLogId) { (updatedStatus) -> () in
        completionHandler(updatedStatus: updatedStatus)
        }
    }
}

class StrengthExercise: Exercise {
    var sets = 0.0
    var reps = 0.0
    var weight = 0.0
    
    override var expectedHeight: CGFloat {
        return 191.0
    }
    
    override init(name: String) {
        super.init(name: name)
        exerciseType = .Strength
    }
    
    override func copy() -> StrengthExercise {
        let copiedExercise = super.copy() as! StrengthExercise
        copiedExercise.sets = sets
        copiedExercise.reps = reps
        copiedExercise.weight = weight
        return copiedExercise
    }
}

class CardioVascularExercise: Exercise {
    
    // XXX think of units here
    var distance = 0.0
    
    override var expectedHeight: CGFloat {
        return 130.0
    }
    
    override init(name: String) {
        super.init(name: name)
        exerciseType = .CardioVascular
    }
    
    override func copy() -> CardioVascularExercise {
        let copiedExercise = super.copy() as! CardioVascularExercise
        copiedExercise.distance = distance
        return copiedExercise
    }
}
