//
//  ManageGoalsCompletionController.swift
//  FlexYourMacros
//
//  Created by dbgattila on 6/9/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import UIKit

class ManageGoalsCompletionController: UITableViewController , UITextFieldDelegate, SignUpCompleteTableViewCellDelegate, UIAlertViewDelegate {
    
    var didEdit: Bool = true
    let FYMUserModel = FymUser.sharedFymUser
    var manageGoalsCell = UITableViewCell()
    var currentTextField = UITextField()
    var customCarbPercentage: Double = 0.0
    var customFatPercentage: Double = 0.0
    var customProteinPercentage: Double = 0.0
    var isUpdateButtonPresent = false
    var buttonUpdateMacro = UIButton()
    
    var previousCustomCarbPercentage: Double = 0.0
    var previousCustomFatPercentage: Double = 0.0
    var previousCustomProteinPercentage: Double = 0.0
    var previousUserNutritionType = " "
    var previousUserCustomFiberValue = " "
    
    // set tableview editable or not
    var isEditable = false {
        didSet {
            
            // XXX - need to localise
            navigationItem.rightBarButtonItem?.title = "Save"
        }
    }
    
    struct Class {
        static let UIAlertController = "UIAlertController"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        customCarbPercentage = FYMUserModel.userCustomCarbsPercentage
        customFatPercentage = FYMUserModel.userCustomFatPercentage
        customProteinPercentage = FYMUserModel.userCustomProteinPercentage
        tableView.tableFooterView = UIView(frame: CGRectZero)
        
        // store the initial values of macros, nutrition type and fiber
        previousUserCustomFiberValue = FYMUserModel.userCustomFiberValue
        previousUserNutritionType = FymUser.sharedFymUser.userNutritionType
        previousCustomCarbPercentage = FYMUserModel.userCustomCarbsPercentage
        previousCustomFatPercentage = FYMUserModel.userCustomFatPercentage
        previousCustomProteinPercentage = FYMUserModel.userCustomProteinPercentage
        
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 4
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        
        // set seperator inset
        cell.setSeparatorInsetZero()
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        if section == 3 {
            return 1
        } else if section == 2 {
            return 3
        }
        return 1
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 3 {
            return 0
        }
        return 40.0
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.section == 3 {
            return 120.0
        }
        return 60.0
    }
    
    override func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        // section four of the table contains the update button
        if section == 3 {
            
            return UIView(frame: CGRectZero)
        }
        let headerView = tableView.dequeueReusableCellWithIdentifier("kHeaderCell") as! SignUpCompleteTableViewCell
        headerView.labelHeaderTitle.text = setSectionHeaderTitles(section)
        return headerView
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            // section zero holds the calorie prototype cell
            let cell = tableView.dequeueReusableCellWithIdentifier("kCalorieCell", forIndexPath: indexPath) as! SignUpCompleteTableViewCell
            cell.configureCell()
            manageGoalsCell = cell
            
        } else if indexPath.section == 1 {
            // section one holds the fibre prototype cell
            let cell = tableView.dequeueReusableCellWithIdentifier("kFibreCell", forIndexPath: indexPath) as! SignUpCompleteTableViewCell
            cell.textFieldFiber.delegate = self
            cell.textFieldFiber.tag = 120
            
            //cell.textFieldFiber.userInteractionEnabled = FYMUserModel.userNutritionType == "5" ? true : false
            
            cell.textFieldFiber.userInteractionEnabled = isEditable
            
            cell.configureCell()
            manageGoalsCell = cell
            
        } else if indexPath.section == 2 {
            // section two holds the macro prototype cell
            let cell = tableView.dequeueReusableCellWithIdentifier("kMacroCell", forIndexPath: indexPath) as! SignUpCompleteTableViewCell
            cell.textFieldMacroValue.delegate = self
            cell.textFieldMacroValue.tag = indexPath.row
            
            //  based on the selected nutrition type user interaction for the macro breakdown cells are managed
            //cell.textFieldMacroValue.userInteractionEnabled = FYMUserModel.userNutritionType == "5" ? true : false
            
            cell.textFieldMacroValue.userInteractionEnabled = isEditable
            
            cell.tag = indexPath.row
            cell.configureCell()
            manageGoalsCell = cell
        } else if indexPath.section == 3 {
            
            let cell = tableView.dequeueReusableCellWithIdentifier("kUpdateCell") as! SignUpCompleteTableViewCell
            
            buttonUpdateMacro = cell.buttonUpdate
            // if in editing mode update button is visible
            //            if didEdit {
            //cell.buttonUpdate.hidden = FYMUserModel.userNutritionType == "5" ? false : true
            
            cell.buttonUpdate.hidden = !isEditable
            
            cell.signUpCompleteTableViewCellDelegate = self
            
            manageGoalsCell = cell
        }
        
        return manageGoalsCell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if tableView.cellForRowAtIndexPath(indexPath)?.reuseIdentifier == "kMacroCell"  {
            
            let cell = tableView.cellForRowAtIndexPath(indexPath) as! SignUpCompleteTableViewCell
            
            cell.textFieldMacroValue.becomeFirstResponder()
        }
    }
    
    func setSectionHeaderTitles(sectionIndex: Int) -> String {
        
        // manage the header titles for the sections in the table view
        var headerTitle: String
        
        switch sectionIndex {
        case 0:
            headerTitle = &&"calculate_calories"
        case 1:
            headerTitle = &&"fiber_goal"
        case 2:
            headerTitle = &&"calculate_macros"
        case 3:
            headerTitle = &&"no_of_meals"
        default :
            headerTitle = ""
        }
        
        return headerTitle
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        //print("string ---\(string)")
        
        // managing the textfield input: limit the characters to only of numeric type
        FymUser.sharedFymUser.userNutritionType = "5"

        if string == " " {
            return false
        }
        
        if string.isEmpty {
            return true
        }
        
        var isValid = true
        let text = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        
        // check for unwanted characters
        let replacementStringIsLegal = string.rangeOfCharacterFromSet(NSCharacterSet(charactersInString: "0123456789.").invertedSet) == nil
        
        
        if textField.tag == 120 {
            // textfield fiber
            
            // check for string count
            let resultingStringLengthIsLegal = text.characters.count <= 7
            
            
            // check if the number is valid
            let scanner = NSScanner(string: text)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
            
            let isLowNumber = text.doubleValue < 100000
            
            // seperate strings after and before decimal point
            let arrayString = text.componentsSeparatedByString(".")
            
            // number of characters after decimal status
            var limitAfterDecimalNotExceeded = true
            
            if arrayString.count > 1 {
                var trailingDigits: NSString = arrayString[1]
                
                // save character count after decimal point
                limitAfterDecimalNotExceeded = trailingDigits.length <= 2
                
            }
            
            isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber && limitAfterDecimalNotExceeded
        }
        else {
            
            // check for string count
            let resultingStringLengthIsLegal = text.characters.count <= 5
            
            // check if the number is valid
            let scanner = NSScanner(string: text)
            let resultingTextIsNumeric = scanner.scanDecimal(nil) && scanner.atEnd
            
            let isLowNumber = text.doubleValue <= 100
            
            // seperate strings after and before decimal point
            let arrayString = text.componentsSeparatedByString(".")
            
            // number of characters after decimal status
            var limitAfterDecimalNotExceeded = true
            
            if arrayString.count > 1 {
                let trailingDigits: NSString = arrayString[1]
                
                // save character count after decimal point
                limitAfterDecimalNotExceeded = trailingDigits.length <= 2
                
            }
            
            isValid = replacementStringIsLegal && resultingStringLengthIsLegal && resultingTextIsNumeric && isLowNumber && limitAfterDecimalNotExceeded
        }
        
        return isValid
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        
        

        currentTextField = textField
        
        // not fiber
        if textField.tag != 120 {
            buttonUpdateMacro.alpha = 1.0
            buttonUpdateMacro.userInteractionEnabled = true
        }
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        // on return of text field editing update the user model with macro values
        if textField.tag == 0 {
            customFatPercentage  = textField.text!.doubleValue
        } else if textField.tag == 1 {
            customCarbPercentage  = textField.text!.doubleValue
        } else if textField.tag == 2 {
            customProteinPercentage  = textField.text!.doubleValue
        } else if textField.tag == 120 {
            //fiber value entered
            if textField.text != FYMUserModel.userCustomFiberValue {
                ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
            }
            FYMUserModel.userCustomFiberValue = textField.text!
            currentTextField.resignFirstResponder()
        }
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        
        // on ending of text field editing update the user model with macro values
        //print("//print tag----\(textField.tag)")
        if textField.tag == 0 {
            customFatPercentage  = textField.text!.doubleValue
            
        } else if textField.tag == 1 {
            customCarbPercentage  = textField.text!.doubleValue
            
        } else if textField.tag == 2 {
            customProteinPercentage  = textField.text!.doubleValue
            
        } else if textField.tag == 120 {
            //fiber value entered
            
            if textField.text != FYMUserModel.userCustomFiberValue {
                ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
            }
            FYMUserModel.userCustomFiberValue = textField.text!
            currentTextField.resignFirstResponder()
        }
        
    }
    
    func checkCustomFiber() -> Bool {
        
        if FYMUserModel.userCustomFiberValue.doubleValue <= 0.0 {
            
            
            if #available(iOS 8.0, *) {
                let alert = UIAlertController(title: &&"notice", message: &&"custom_fiber_greater_zero", preferredStyle: .Alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
                
                self.presentViewController(alert, animated: true, completion: nil)
            } else {
                // Fallback on earlier versions
                UIAlertView(title: &&"notice", message: &&"custom_fiber_greater_zero", delegate: nil, cancelButtonTitle: &&"ok").show()
                
            }
            
            
            return false
        }
        
        return true
    }
    
    func checkTheMacroTotal() -> Bool {
        
        currentTextField.resignFirstResponder()
        
        // check macro total : show alert when it is not equal to 100%
        var checkMacro = true
        let totalMacroPercentage = customFatPercentage + customCarbPercentage + customProteinPercentage
        
        //print("roundPlaces(decimalPlaces: 3)---\(totalMacroPercentage.roundPlaces(3))");
        
        if totalMacroPercentage.roundPlaces(3) > 99.994 && totalMacroPercentage.roundPlaces(3) <= 100.0 {
            
            didEdit = true
            
            if customFatPercentage != FYMUserModel.userCustomFatPercentage || customCarbPercentage != FYMUserModel.userCustomCarbsPercentage || customProteinPercentage != FYMUserModel.userCustomProteinPercentage{
                ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
            }
            // update the value to user model
            FYMUserModel.userCustomFatPercentage = customFatPercentage
            FYMUserModel.userCustomCarbsPercentage = customCarbPercentage
            FYMUserModel.userCustomProteinPercentage = customProteinPercentage
            
        } else {
            
            checkMacro = false
            didEdit = true
            //          show alert controller if possible else show alert view
            
            if #available(iOS 8.0, *) {
                let alert = UIAlertController(title: &&"notice", message: &&"macro_percentage_add_upto_100", preferredStyle: .Alert)
                alert.addAction(UIAlertAction(title: &&"ok", style: .Cancel, handler: nil))
                self.presentViewController(alert, animated: true, completion: nil)
            } else {
                // Fallback on earlier versions
                UIAlertView(title: &&"notice", message: &&"macro_percentage_add_upto_100", delegate: nil, cancelButtonTitle: &&"ok").show()
                
            }
            
        }
        return checkMacro
    }
    
    func buttonActionUpdate(signUpCompleteTableViewCell: SignUpCompleteTableViewCell){
        
        didEdit = true
        
        if !checkTheMacroTotal() {
            return
        }
        // update the value to user model
        FYMUserModel.userCustomFatPercentage = customFatPercentage
        FYMUserModel.userCustomCarbsPercentage = customCarbPercentage
        FYMUserModel.userCustomProteinPercentage = customProteinPercentage
        
        self.tableView .reloadData()
        
    }
    
    @IBAction func buttonActionBack(sender: UIButton) {
        
        currentTextField.resignFirstResponder()
        
        if isEditable {
            
            if !checkCustomFiber() {
                return
            }
            
            if !checkTheMacroTotal() {
                return
            }
        }
        
       // self.navigationController?.popViewControllerAnimated(true)
        
        if ManageGoalsAlert.sharedManageGoalsAlert.showAlert {
            if #available(iOS 8.0, *) {
                
                let alertView = UIAlertController(title: &&"notice",
                    message: &&"manage_save_changes", preferredStyle: .Alert)
                alertView.addAction(UIAlertAction(title: &&"cancel", style: .Cancel){ action -> Void in
                    
                    // reset to the previous value
                    self.resetToPreviousValue()
                    
                    // pop view controller
                    self.navigationController?.popViewControllerAnimated(true)
                    })
                alertView.addAction(UIAlertAction(title: &&"ok", style: .Default){ action -> Void in
                    
                    let reachability = self.appDelegate!.internetReachable
                    if !reachability {
                        // no internet
                        
                        // alert
                        AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                        return
                    }
                    
                    self.SaveData()
                    
                    })
                presentViewController(alertView, animated: true, completion: nil)
                
                
            } else {
                // Fallback on earlier versions
                
                let alert = UIAlertView(title: &&"notice", message:  &&"manage_save_changes", delegate: self, cancelButtonTitle:  &&"cancel", otherButtonTitles: &&"ok")
                alert.show()
            }
        }
        else {
            self.navigationController?.popViewControllerAnimated(true)
        }
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
            
            if alertView.buttonTitleAtIndex(buttonIndex) == &&"ok" {
                
                let reachability = appDelegate!.internetReachable
                if !reachability {
                    // no internet
                    
                    // alert
                    AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
                    return
                }
                
                SaveData()
            }
            else {
                
                // reset to the previous value
                resetToPreviousValue()
                
                // pop view controller
                self.navigationController?.popViewControllerAnimated(true)
            }
    }

    
    @IBAction func barButtonActionEditOrSave(sender: AnyObject) {
        
        if navigationItem.rightBarButtonItem?.title == "Edit" {
            
            // show the alert
            ManageGoalsAlert.sharedManageGoalsAlert.showAlert = true
            
            // set table view editable
            isEditable = true
            
            tableView.reloadData()
            return
        }
        
        // save the data
        SaveData()
    }
    
    func SaveData() {
        
        currentTextField.resignFirstResponder()
        if isEditable {
            
            if !checkCustomFiber() {
                return
            }
            
            if !checkTheMacroTotal() {
                return
            }
        }
        
        let reachability = appDelegate!.internetReachable
        if !reachability {
            // no internet
            
            // alert
            AlertManager.showAlert(&&"alert_network_title", message: &&"alert_network_message")
            return
        }
        
        ManageGoalsUpdateUserResponse.manageGoalsUpdateUser { (completed) -> () in
            
            if completed {
                
                // set save or not confirmation alert in manage goals to false
                ManageGoalsAlert.sharedManageGoalsAlert.showAlert = false
                
                //pop viewcontroller
                self.navigationController?.popViewControllerAnimated(true)
                
            } else {
                // XXX - show alert
                //print("failed")
            }
        }
    }
    
    func resetToPreviousValue() {
        // reset to the previous value
        
        FymUser.sharedFymUser.userNutritionType = previousUserNutritionType
        FYMUserModel.userCustomCarbsPercentage = previousCustomCarbPercentage
        FYMUserModel.userCustomFatPercentage = previousCustomFatPercentage
        FYMUserModel.userCustomProteinPercentage = previousCustomProteinPercentage
        FYMUserModel.userCustomFiberValue = previousUserCustomFiberValue
    }
}
