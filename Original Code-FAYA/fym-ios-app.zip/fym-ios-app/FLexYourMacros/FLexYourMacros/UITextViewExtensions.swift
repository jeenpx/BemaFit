//
//  UITextView.swift
//  FlexYourMacros
//
//  Created by Thahir Maheen on 20/03/15.
//  Copyright (c) 2015 Digital Brand Group. All rights reserved.
//

import Foundation

extension UITextView {
    
    // XXX default font will be small in the presence of an image
    func insertImage(image: UIImage) {
                
        // create attributed text respecting the textview font
        let attributedText = NSMutableAttributedString(string: "", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(0)])
        
        // get the scale factor
        let scaleFactor = image.size.width / (CGRectGetWidth(bounds) - 18)
        
        // create a text attachment for the image
        let textAttachment = NSTextAttachment()
        textAttachment.image = UIImage(CGImage: image.CGImage!, scale: scaleFactor, orientation: .Up)
        
        // insert image into the attributed text
        let attributedTextWithImage = NSAttributedString(attachment: textAttachment)
        attributedText.insertAttributedString(attributedTextWithImage, atIndex: 0)
        attributedText.appendAttributedString(NSAttributedString(string: text.isEmpty ? "\n\n" : text))
                
        // set attributed text to the textstorage
        textStorage.setAttributedString(attributedText)
    }
    
    func getInsertedImage(completionHandler: (UIImage? -> ())) {
        
        // return if there is no attributed text
        if attributedText == nil {
            completionHandler(nil)
            return
        }
        
        // filter out image attachments if any
        var image: UIImage?
        for i in 0..<attributedText.length {
            if let attachment = attributedText.attribute(NSAttachmentAttributeName, atIndex: i, effectiveRange: nil) as? NSTextAttachment {
                image = attachment.image
            }
        }
        
        // fire completion handler
        completionHandler(image)
    }
}