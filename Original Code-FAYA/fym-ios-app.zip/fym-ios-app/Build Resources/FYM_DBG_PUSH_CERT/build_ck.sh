openssl x509 -in apns_development.cer -inform der -out apns_development.pem
openssl pkcs12 -nocerts -out apns_development_key.pem -in apns_development.p12
cat apns_development.pem apns_development_key.pem > ck_development.pem


echo "Testing certificate working"
openssl s_client -connect gateway.sandbox.push.apple.com:2195 -cert apns_development.pem -key apns_development_key.pem


# Enter pass phrase 1234