<?php
return array(
    'router' => array(
        'routes' => array(
            'meal' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/meal',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'index',
                    ),
                )
            ),
            'postmeal' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/postmeal',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'postMeal',
                    ),
                )
            ),
            'getMealById' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/getMealById',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'getMealById',
                    ),
                )
            ),
            'getMealNutritionId' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/getMealNutritionId',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'getMealNutritionId',
                    ),
                )
            ),
            'mealImageSubmit' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/mealImageSubmit',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'mealImageSubmit',
                    ),
                )
            ),
            'removeMeal' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/removeMeal',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'removeMeal',
                    ),
                )
            ),
            'addMealCategories' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/addMealCategories',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'addMealCategories',
                    ),
                )
            ),
            'getMealCategory' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/getMealCategory',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'getMealCategory',
                    ),
                )
            ),
            'editMealCategories' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/editMealCategories',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'editMealCategories',
                    ),
                )
            ),
            'removeMealCat' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/removeMealCat',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'removeMealCat',
                    ),
                )
            ),
            'unitSelect' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/unitSelect',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'unitSelect',
                    ),
                )
            ),
            'getMealsData' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/getMealsData',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'getMealsData',
                    ),
                )
            ),
            'updateMealsNutriData' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/updateMealsNutriData',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'updateMealsNutriData',
                    ),
                )
            ),
            'fetchMeal' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/fetchMeal',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'fetchMeal',
                    ),
                )
            ),
            'updateMealsServingUnit' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/updateMealsServingUnit',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'updateMealsServingUnit',
                    ),
                )
            ),
            'getMealSearchSettings' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/getMealSearchSettings',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'getMealSearchSettings',
                    ),
                )
            ),
            'updateMealSearchSettings' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/updateMealSearchSettings',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'updateMealSearchSettings',
                    ),
                )
            ),
            'mealImport' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/mealImport',
                    'defaults' => array(
                        'controller' => 'meal',
                        'action'     => 'mealImport',
                    ),
                )
            )
        )
    ),
    'controllers' => array(
        'invokables' => array(
            'meal' => 'Meal\Controller\MealController',
        ),
    ),
    'controller_plugins' => array(
        'invokables' => array(
            'fym' => 'Application\Controller\Plugin\Fym',
        )
    ),
    'view_manager' => array(
        'template_map' => array(
            'meal/meal/index' => __DIR__ . '/../view/meal/meal/index.phtml',
            'addmeal' => __DIR__ . '/../view/meal/meal/addmeal.phtml',
            'mealcategory' => __DIR__ . '/../view/meal/meal/categories.phtml',
            'managefoodsearch' => __DIR__ . '/../view/meal/meal/managefoodsearch.phtml',
        ),
        'strategies' => array(
            'ViewJsonStrategy',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
