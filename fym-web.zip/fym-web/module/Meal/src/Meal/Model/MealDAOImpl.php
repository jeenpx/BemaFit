<?php
namespace Meal\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Predicate\Expression;

class MealDAOImpl
{
    protected $tableGateway;
    protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
        $this->select = new Select();

    }
    public function getMeals()
    {
        /*$select = $this->tableGateway->getSql()->select();
        $select->columns(array('id','guid','name','language_id','brand_name','serving_size','serving_size_unit','serving_per_container','description',   'vendor_verified','status_id'));
        //$select->join('meal_type_master', 'meal_type_master.id = meal.meal_type_id', array('mealtypename'=>'name'));
        $select->join('language', 'language.id = meal.language_id', array('languagename'=>'name'));
        $select->join('meal_unit_master', 'meal_unit_master.id = meal.serving_size_unit', array('unitname'=>'name'), "LEFT");
        $select->join('meal_unit', 'meal_unit.meal_id = meal.id', array('mealunitid'=>'id'), "LEFT");
        $select->join('meal_unit_nutrition_fact', new Expression('meal_unit_nutrition_fact.meal_unit_id = meal_unit.id AND meal_unit_nutrition_fact.nutrition_fact_id = 1'), array('value'=>'value'), "LEFT");
        $select->join("meal_category", "meal_category.meal_id = meal.id", array("catid"=>new Expression("Group_Concat(DISTINCT meal_category.meal_category_master_id)")), "LEFT");
        $select->group('meal.id');
        $select->join("meal_category_master", "meal_category_master.id = meal_category.meal_category_master_id", array("catname"=>new Expression("Group_Concat(DISTINCT meal_category_master.name SEPARATOR ', ')")), "LEFT");
        $select->group('meal.id');
        $select->join("meal_type", "meal_type.meal_id = meal.id", array("mealTypeid"=>new Expression("Group_Concat(DISTINCT meal_type.meal_type_master_id)")), "LEFT");
        $select->group('meal.id');
        $select->join("meal_type_master", "meal_type_master.id = meal_type.meal_type_master_id", array("mealtypename"=>new Expression("Group_Concat(DISTINCT meal_type_master.name SEPARATOR ', ')")), "LEFT");
        $select->group('meal.id');
        $select->where('meal.status_id != 4');
        $select->where('meal_category_master.status_id != 4');
        $select->order('id DESC');
        $sql = $this->tableGateway->getSql();
        //echo $sql->getSqlstringForSqlObject($select);
        //exit;
        $resultSet = $this->tableGateway->selectWith($select);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();*/
        $sql = "SELECT meal.id,language_id,brand_name,serving_size,serving_size_unit,serving_per_container,vendor_verified,meal.status_id,
                        language.name as languagename,meal_unit_master.name as unitname,
                        meal.calorie as value,Group_Concat(DISTINCT meal_category.meal_category_master_id) as catid , 
                        Group_Concat(DISTINCT meal_category_master.name SEPARATOR ', ') as catname,
                        Group_Concat(DISTINCT meal_type.meal_type_master_id) as mealTypeid,
                        Group_Concat(DISTINCT meal_type_master.name SEPARATOR ', ') as mealtypename,
                        IF( LENGTH( meal.name ) >0, meal.name,  meal.name_es ) AS name
                FROM meal  
                join language on language.id = meal.language_id 
                left join meal_unit_master on meal_unit_master.id = meal.serving_size_unit 
                left join meal_category on meal_category.meal_id = meal.id
                left join meal_category_master on meal_category_master.id = meal_category.meal_category_master_id
                left join meal_type on meal_type.meal_id = meal.id
                left join meal_type_master on meal_type_master.id = meal_type.meal_type_master_id
                WHERE meal.status_id != 4   
                GROUP BY meal.id order by  meal.id desc " ;
        $result = $this->tableGateway->getAdapter()->driver->getConnection()->execute($sql);
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function getUpateMealsDet($id)
    {
        $sql = "SELECT meal.id,guid,language_id,brand_name,serving_size,serving_size_unit,serving_per_container,vendor_verified,meal.status_id,
                        language.name as languagename,meal_unit_master.name as unitname,meal_unit.id as mealunitid,
                        meal_unit_nutrition_fact.value,Group_Concat(DISTINCT meal_category.meal_category_master_id) as catid , 
                        Group_Concat(DISTINCT meal_category_master.name SEPARATOR ', ') as catname,
                        Group_Concat(DISTINCT meal_type.meal_type_master_id) as mealTypeid,
                        Group_Concat(DISTINCT meal_type_master.name SEPARATOR ', ') as mealtypename,
                        IF( LENGTH( meal.name ) >0, meal.name,  CONVERT( CAST( CONVERT( meal.name_es  USING utf8 ) AS   BINARY )  USING latin1 ) ) AS name
                FROM meal  
                join language on language.id = meal.language_id 
                left join meal_unit_master on meal_unit_master.id = meal.serving_size_unit 
                LEFT JOIN meal_unit ON meal_unit.meal_id = meal.id AND meal_unit.unit_id=meal.serving_size_unit
                left join meal_unit_nutrition_fact on meal_unit_nutrition_fact.meal_unit_id = meal_unit.id AND meal_unit_nutrition_fact.nutrition_fact_id = 1
                left join meal_category on meal_category.meal_id = meal.id
                left join meal_category_master on meal_category_master.id = meal_category.meal_category_master_id
                left join meal_type on meal_type.meal_id = meal.id
                left join meal_type_master on meal_type_master.id = meal_type.meal_type_master_id
                WHERE meal.id =".$id ;
        $result = $this->tableGateway->getAdapter()->driver->getConnection()->execute($sql);
        return $result->current();
    }
    public function insert($data)
    {
        try {
            $this->tableGateway->insert($data);
            $id = $this->tableGateway->lastInsertValue;
            return $id;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function update($data)
    {
        try {
            $this->tableGateway->update($data, array('id' => $data['id']));
            return 1;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function insertMealCategory($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $mealCategory = new TableGateway('meal_category', $adapter);
         $mealCategory->insert($data);
    }
    public function deleteMealCategory($id)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $businessCategory = new TableGateway('meal_category', $adapter);
             return $businessCategory->delete(array('meal_id' => $id));
        } catch (\Exception $e) {
             return 0;
        }
    }
    public function getMealById($id)
    {
        $select = $this->tableGateway->getSql()->select();
        $select->columns(array(new Expression("CONVERT(CAST(CONVERT(meal.name_es USING utf8 ) AS BINARY) USING latin1) as name_es"),new Expression("CONVERT(CAST(CONVERT(meal.description_es USING utf8 ) AS BINARY) USING latin1) as description_es"),new Expression("CONVERT(CAST(CONVERT(brand_name_es USING utf8 ) AS BINARY) USING latin1) as brand_name_es"),'id','guid','name','language_id','brand_name','serving_size','serving_size_unit','serving_per_container','description','vendor_verified','status_id'));
        $select->join('meal_image', 'meal_image.meal_id = meal.id', array('file'=>'file','file_resize'=>'file_resize'), "LEFT");
        $select->join('meal_unit_master', 'meal_unit_master.id = meal.serving_size_unit', array('mealUnitName'=>'name'), "LEFT");
        //$select->join('meal_type_master', 'meal_type_master.id = meal.meal_type_id', array('mealtypename'=>'name'));
        $select->join('language', 'language.id = meal.language_id', array('languagename'=>'name'));
        $select->join("meal_category", "meal_category.meal_id = meal.id", array("catid"=>new Expression("Group_Concat(DISTINCT meal_category.meal_category_master_id)")), "LEFT");
        $select->group('meal.id');
        $select->join("meal_category_master", "meal_category_master.id = meal_category.meal_category_master_id", array("catname"=>new Expression("Group_Concat(DISTINCT meal_category_master.name)")), "LEFT");
        $select->group('meal.id');
        $select->join("meal_type", "meal_type.meal_id = meal.id", array("mealTypeid"=>new Expression("Group_Concat(DISTINCT meal_type.meal_type_master_id)")), "LEFT");
        $select->group('meal.id');
        $select->join("meal_type_master", "meal_type_master.id = meal_type.meal_type_master_id", array("mealtypename"=>new Expression("Group_Concat(DISTINCT meal_type_master.name)")), "LEFT");
        $select->group('meal.id');
        $select->where(array('meal.id' => $id));
        $resultSet = $this->tableGateway->selectWith($select);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getMealNutritionFact()
    {
        $adapter = $this->tableGateway->getAdapter();
        $nutritionFactMaster = new TableGateway('nutrition_fact', $adapter);
        $select = $nutritionFactMaster->getSql()->select();
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function insertMealNutritionFact($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $mealNutrition = new TableGateway('meal_unit_nutrition_fact', $adapter);
         $mealNutrition->insert($data);
    }
    public function getMealNutritionById($id, $servingUnit)
    {
        $adapter = $this->tableGateway->getAdapter();
        $nutritionFactMaster = new TableGateway('meal_unit', $adapter);
        $select = $nutritionFactMaster->getSql()->select();
        $select->join('meal_unit_nutrition_fact', 'meal_unit.id = meal_unit_nutrition_fact.meal_unit_id', array('nutrition_fact_id'=>'nutrition_fact_id','value'=>'value'), "LEFT");
        $select->where(array('meal_unit.meal_id' => $id));
        $select->where(array('meal_unit.unit_id' => $servingUnit));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function deleteMealNutritionFact($id)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $businessCategory = new TableGateway('meal_nutrition_fact', $adapter);
             return $businessCategory->delete(array('meal_id' => $id));
        } catch (\Exception $e) {
             return 0;
        }
    }
    public function deleteMealImage($id)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $mealImage = new TableGateway('meal_image', $adapter);
             return $mealImage->delete(array('meal_id' => $id));
        } catch (\Exception $e) {
             return 0;
        }
    }
    public function insertMealImage($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $adImage = new TableGateway('meal_image', $adapter);
         $adImage->insert($data);
    }
    public function updateMealImage($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $adImage = new TableGateway('meal_image', $adapter);
         $adImage->update($data, array('meal_id' => $data['meal_id']));
    }
    public function deleteMeal($data)
    {
        try {
            $this->tableGateway->update($data, array('id' => $data['id']));
            return 1;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function getMealCategory()
    {
        $adapter = $this->tableGateway->getAdapter();
        $businessCategoryMaster = new TableGateway('meal_category_master', $adapter);
        $select = $businessCategoryMaster->getSql()->select();
        $select->where('meal_category_master.status_id != 4');
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function insertMealCategoryMaster($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $businessCategoryMaster = new TableGateway('meal_category_master', $adapter);
         $businessCategoryMaster->insert($data);
         $id = $businessCategoryMaster->lastInsertValue;
         return $id;
    }
    public function updateMealCategoryMaster($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $businessCategoryMaster = new TableGateway('meal_category_master', $adapter);
         $businessCategoryMaster->update($data, array('id' => $data['id']));
    }
    public function deleteMealCategoryMaster($catId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $businessCategory = new TableGateway('meal_category_master', $adapter);
        try {
            $data['status_id']=4;
            $businessCategory->update($data, array('id' => $catId));
            return 1;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function insertMealType($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $mealCategory = new TableGateway('meal_type', $adapter);
         $mealCategory->insert($data);
    }
    public function deleteMealType($id)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $mealType = new TableGateway('meal_type', $adapter);
             return $mealType->delete(array('meal_id' => $id));
        } catch (\Exception $e) {
             return 0;
        }
    }
    public function getAllUnit($searchValue)
    {
        $adapter = $this->tableGateway->getAdapter();
        $state = new TableGateway('meal_unit_master', $adapter);
        $select = $state->getSql()->select();
        $select->where->like('name', $searchValue.'%');
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function getMealUnitById($unitId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $state = new TableGateway('meal_unit_master', $adapter);
        $select = $state->getSql()->select();
        $select->where(array('id' => $unitId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function insertMealUnitMaster($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $mealUnitMaster = new TableGateway('meal_unit_master', $adapter);
         $mealUnitMaster->insert($data);
         $id = $mealUnitMaster->lastInsertValue;
         return $id;
    }
    public function insertMealUnit($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $mealUnit = new TableGateway('meal_unit', $adapter);
         $mealUnit->insert($data);
         $id = $mealUnit->lastInsertValue;
         return $id;
    }
    public function getMealUnitIdByMealId($mealId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $state = new TableGateway('meal_unit', $adapter);
        $select = $state->getSql()->select();
        $select->where(array('meal_id' => $mealId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function deleteMealUnitNutritionFact($mealUnitid)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $mealType = new TableGateway('meal_unit_nutrition_fact', $adapter);
             return $mealType->delete(array('meal_unit_id' => $mealUnitid));
        } catch (\Exception $e) {
             return 0;
        }
    }
    public function deleteMealUnit($mealId)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $mealType = new TableGateway('meal_unit', $adapter);
             return $mealType->delete(array('meal_id' => $mealId));
        } catch (\Exception $e) {
             return 0;
        }
    }
    public function countMealCategory($catId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $mealCategory = new TableGateway('meal_category', $adapter);
        $select = $mealCategory->getSql()->select();
        $select->columns(array(new Expression("COUNT(meal_category.id) as catCount")));
        $select->join('meal', 'meal.id = meal_category.meal_id');
        $select->where(array('meal_category_master_id' => $catId));
        $select->where('meal.status_id != 4');
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getCatName($catId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $mealCategory = new TableGateway('meal_category_master', $adapter);
        $select = $mealCategory->getSql()->select();
        $select->columns(array('name'));
        $select->where(array('id' => $catId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getAllMeals()
    {
        $select = $this->tableGateway->getSql()->select();
        $resultSet = $this->tableGateway->selectWith($select);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function getMealsCalorieValue($mealId, $unitId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $mealCategory = new TableGateway('meal_unit', $adapter);
        $select = $mealCategory->getSql()->select();
        $select->columns(array('id'));
        $select->join('meal_unit_nutrition_fact', new Expression('meal_unit_nutrition_fact.meal_unit_id = meal_unit.id AND meal_unit_nutrition_fact.nutrition_fact_id = 1'), array('value'=>'value'), "LEFT");
        $select->where(array('meal_id' => $mealId));
        $select->where(array('unit_id' => $unitId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getMealServingUnit()
    {
        $sql = "SELECT meal.id, meal.name, meal_unit.unit_id FROM meal
                JOIN meal_unit ON meal_unit.meal_id= meal.id
                GROUP BY meal.id" ;
        $result = $this->tableGateway->getAdapter()->driver->getConnection()->execute($sql);
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function getAllMealsCal()
    {
        $sql = "SELECT meal.id,serving_size_unit
                FROM meal" ;
        $result = $this->tableGateway->getAdapter()->driver->getConnection()->execute($sql);
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function getMealSearchSettings()
    {
        $adapter = $this->tableGateway->getAdapter();
        $state = new TableGateway('system_settings', $adapter);
        $select = $state->getSql()->select();
        $select->where(array('status' => 1));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function updateMealSearchSetting($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $systemSetting= new TableGateway('system_settings', $adapter);
         $systemSetting->update($data, array('id' => 1));
    }
    public function getMealData()
    {
        $adapter = $this->tableGateway->getAdapter();
        $state = new TableGateway('dmp_meal', $adapter);
        $select = $state->getSql()->select();
        $select->order('id DESC');
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }

    public function getMealUnit($unitname)
    {
        $adapter = $this->tableGateway->getAdapter();
        $state = new TableGateway('meal_unit_master', $adapter);
        $select = $state->getSql()->select();
        $select->where(array('name' => $unitname));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }

    public function getMealTypeId($mealTypeName)
    {
        $adapter = $this->tableGateway->getAdapter();
        $state = new TableGateway('meal_type_master', $adapter);
        $select = $state->getSql()->select();
        $select->where(array('name' => $mealTypeName));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $result->current();
    }
}
