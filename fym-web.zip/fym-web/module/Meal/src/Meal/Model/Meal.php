<?php
namespace Meal\Model;

class Meal
{
    public $id;
    public $name;
    public $meal_type_id;
    public $language_id;
    public $brand_name;
    public $serving_size;
    public $serving_size_unit;
    public $saving_per_container;
    public $description;
    public $vendor_verified;

   

    public function exchangeArray($data)
    {
        $this->id    = (isset($data['id'])) ? $data['id'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
        $this->meal_type_id = (isset($data['meal_type_id'])) ? $data['meal_type_id'] : null;
        $this->language_id = (isset($data['language_id'])) ? $data['language_id'] : null;
        $this->brand_name = (isset($data['brand_name'])) ? $data['brand_name'] : null;
        $this->serving_size = (isset($data['serving_size'])) ? $data['serving_size'] : null;
        $this->serving_size_unit = (isset($data['serving_size_unit'])) ? $data['serving_size_unit'] : null;
        $this->description = (isset($data['description'])) ? $data['description'] : null;
        $this->vendor_verified = (isset($data['vendor_verified'])) ? $data['vendor_verified'] : null;
    }
}
