<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Meal\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\ServiceManager\ServiceLocatorAwareInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\Db\Adapter\AdapterInterface;
use Zend\Db\Sql\Sql;
use Zend\View\Model\JsonModel;

class MealController extends AbstractActionController
{
    const ROUTE_LOGIN        = 'zfcuser/login';
    public function getMealTable()
    {
        if (!isset($this->mealTable) || !$this->mealTable) {
            $sm = $this->getServiceLocator();
            $this->mealTable = $sm->get('Meal\Model\MealDAOImpl');
        }
        return $this->mealTable;
    }
    public function indexAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $this->getViewHelper('HeadScript')->prependFile('/js/meal.admin.js');
        $this->getViewHelper('HeadScript')->prependFile('/js/ko.meal.admin.js');
        $mealsCategoryData = $this->getMealTable()->getMealCategory();
        //$mealsData =array();
        $mealsData = $this->getMealTable()->getMeals();
        $mealNutritionFactData = $this->getMealTable()->getMealNutritionFact();
        return new ViewModel(array('mealData' =>json_encode($mealsData),'mealNutritionFact' =>$mealNutritionFactData,'mealsCategory' =>$mealsCategoryData));
        //return new ViewModel(array('mealData' =>json_encode($mealsData),'mealNutritionFact' =>$mealNutritionFactData,'mealsCategory' =>$mealsCategoryData));
    }
    public function postMealAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $data['id']=$this->getRequest()->getPost('mealId');
        $data['name']=$this->getRequest()->getPost('meal_name');
        $data['name_es']=utf8_decode($this->getRequest()->getPost('meal_name_spa'));
        //$data['description_es']=utf8_decode($this->getRequest()->getPost('description_spa'));
        //$data['exercise_language_id']=$this->getRequest()->getPost('exercise_language');
        $data['brand_name']=$this->getRequest()->getPost('brand_name');
        $data['brand_name_es']=utf8_decode($this->getRequest()->getPost('brand_name_spa'));
        $data['serving_size']=$this->getRequest()->getPost('serving-size');
        $data['serving_size_unit']=$this->getRequest()->getPost('serving-size-unit');
        $data['serving_per_container']=$this->getRequest()->getPost('serving-per-container');
        //$data['description']=$this->getRequest()->getPost('description');

        $mealType=$this->getRequest()->getPost('mealType');
        $data['vendor_verified']=($this->getRequest()->getPost('vendor-verified')!="")?$this->getRequest()->getPost('vendor-verified'):"No";
        $mealImage=$this->getRequest()->getPost('mealImageLocation');
        $mealImageResize=$this->getRequest()->getPost('mealImageResizeLocation');
        $dataMealImage['file']=$mealImage;
        $dataMealImage['file_resize']=$mealImageResize;
        $mealCategory=$this->getRequest()->getPost('category');
        $mealNutritions=$this->getRequest()->getPost('nutrition');
        $data['calorie']=$mealNutritions['1'];
        $mealUnitId= $this->getRequest()->getPost('mealUnitId');
        $autocomplete_meal_unit=$this->getRequest()->getPost('autocomplete_meal_unit');
        $mealUnitName=$this->getMealTable()->getMealUnitById($mealUnitId);
        $language=$this->getRequest()->getPost('language');
        if (count($language)==1 && $language[0]==2) {
            $language_id=2;
        } else if (count($language)==2) {
            $language_id=3;
        } else {
            $language_id=1;
        }
        $data['language_id']=$language_id;
        if (trim($mealUnitName['name'])==trim($autocomplete_meal_unit)) {
            $data['serving_size_unit']=$mealUnitId;
        } else {
            $mealUnitMaster['name']=$autocomplete_meal_unit;
            $mealUnitMasterId=$this->getMealTable()->insertMealUnitMaster($mealUnitMaster);
            $data['serving_size_unit']=$mealUnitMasterId;
        }
        if ($data['id']=="") {
            $data['guid']=md5(uniqid(rand(), true));
            $mealId=$this->getMealTable()->insert($data);
            $dataMealImage['meal_id']=$mealId;
            $this->getMealTable()->insertMealImage($dataMealImage);
            $dataMealUnit['meal_id']=$mealId;
            $dataMealUnit['unit_id']=$data['serving_size_unit'];
            $mealUnitTableId=$this->getMealTable()->insertMealUnit($dataMealUnit);
            foreach ($mealCategory as $mealCategoryId) {
                $dataMeal['meal_id']=$mealId;
                $dataMeal['meal_category_master_id']=$mealCategoryId;
                $this->getMealTable()->insertMealCategory($dataMeal);
            }
            foreach ($mealType as $mealTypeId) {
                $dataMealType['meal_id']=$mealId;
                $dataMealType['meal_type_master_id']=$mealTypeId;
                $this->getMealTable()->insertMealType($dataMealType);
            }
            foreach ($mealNutritions as $key => $mealNutrition) {
                $dataNutritions['meal_unit_id']=$mealUnitTableId;
                $dataNutritions['nutrition_fact_id']=$key;
                $dataNutritions['value']=$mealNutrition;
                $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            }
            $this->flashMessenger()->addMessage('New Meal has been added');
        } else {
            $this->getMealTable()->update($data);
            $mealId=$data['id'];
            $dataMealImage['meal_id']=$this->getRequest()->getPost('mealId');
            $mealUnit=$this->getMealTable()->getMealUnitIdByMealId($data['id']);
            $this->getMealTable()->deleteMealImage($data['id']);
            $this->getMealTable()->deleteMealCategory($data['id']);
            $this->getMealTable()->deleteMealUnitNutritionFact($mealUnit['id']);
            //$this->getMealTable()->deleteMealUnit($data['id']);
            $this->getMealTable()->deleteMealType($data['id']);
            //$this->getMealTable()->deleteMealNutritionFact($data['id']);
            $this->getMealTable()->insertMealImage($dataMealImage);
            $dataMealUnit['meal_id']=$data['id'];
            $dataMealUnit['unit_id']=$data['serving_size_unit'];
            $mealUnitTableId=$this->getMealTable()->insertMealUnit($dataMealUnit);

            foreach ($mealCategory as $mealCategoryId) {
                $dataMeal['meal_id']=$data['id'];
                $dataMeal['meal_category_master_id']=$mealCategoryId;
                $this->getMealTable()->insertMealCategory($dataMeal);
            }
            foreach ($mealType as $mealTypeId) {
                $dataMealType['meal_id']=$data['id'];
                $dataMealType['meal_type_master_id']=$mealTypeId;
                $this->getMealTable()->insertMealType($dataMealType);
            }
            foreach ($mealNutritions as $key => $mealNutrition) {
                $dataNutritions['meal_unit_id']=$mealUnitTableId;
                $dataNutritions['nutrition_fact_id']=$key;
                $dataNutritions['value']=$mealNutrition;
                $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            }
            $this->flashMessenger()->addMessage('Meal has been updated');
        }
        //return $this->redirect()->toRoute('meal');
        $mealData = $this->getMealTable()->getUpateMealsDet($mealId);
        $json = new JsonModel($mealData);
        return $json;
        //$variables = array( 'Message' => 'Exercise has been added' );

    }
    public function getMealByIdAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $mealId= $this->getRequest()->getPost('mealId');
        $mealDetails=$this->getMealTable()->getMealById($mealId);
        $json = new JsonModel($mealDetails);
        return $json;
    }
    public function getMealNutritionIdAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $mealId= $this->getRequest()->getPost('mealId');
        $servingUnit= $this->getRequest()->getPost('servingUnit');
        $mealNutritionDetails=$this->getMealTable()->getMealNutritionById($mealId, $servingUnit);
        $json = new JsonModel($mealNutritionDetails);
        return $json;
    }
    public function mealImageSubmitAction()
    {
        $fymCommon = $this->fym();
        $File    = $this->params()->fromFiles('image');
        $config = $this->getServiceLocator()->get('Config');
        $settings=$config['meal_photo_Settings'];
        $uploadDet=$fymCommon->uploadImage("mealImage", $File, $settings, $config['amazon_s3']);
        $json = new JsonModel($uploadDet);
        return $json;

    }
    public function removeMealAction()
    {
        $mealId= $this->getRequest()->getPost('mealId');
        $data['id']=$mealId;
        $data['status_id']=4;
        $deleteRet=$this->getMealTable()->deleteMeal($data);
        $deletMsg=array();
        if ($deleteRet==1) {
            $deletMsg['msg']="Sucess";
        } else {
            $deletMsg['msg']="False";
        }
        $json = new JsonModel($deletMsg);
        return $json;
    }
    public function getMealCategoryAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $mealCategoryData = $this->getMealTable()->getMealCategory();
        $json = new JsonModel($mealCategoryData);
        return $json;
    }
    public function addMealCategoriesAction()
    {
        $data['name']=$this->getRequest()->getPost('category_name');
        $data['name_es']=$this->getRequest()->getPost('category_name_es');
        $data['status_id']=1;
        //$data['created_by']=1;
        $data['created_date']=date("Y-m-d");
        $catId=$this->getMealTable()->insertMealCategoryMaster($data);
        $catData['id']=$catId;
        $catData['categories'] = $this->getMealTable()->getMealCategory();
        $json = new JsonModel($catData);
        return $json;
        //return $this->redirect()->toRoute('meal');


    }
    protected function editMealCategoriesAction()
    {
        $categoryEditList=$this->getRequest()->getPost('businesscat');
        $categorySpaEditList=$this->getRequest()->getPost('businesscates');
        foreach ($categoryEditList as $key => $value) {
            $data=array();
            $data['id']=$key;
            if (trim($value)!="") {
                $data['name']=trim($value);
            }
            if (trim($categorySpaEditList[$key])!="") {
                $data['name_es']=trim($categorySpaEditList[$key]);
            }
            $this->getMealTable()->updateMealCategoryMaster($data);
        }
        $catData['categories'] = $this->getMealTable()->getMealCategory();
        //$mealData = $this->getMealTable()->getMeals();
        //$catData['meallist'] =$mealData;
        $json = new JsonModel($catData);
        return $json;
    }
    public function removeMealCatAction()
    {

        $catVal=$this->getRequest()->getPost('catVal');
        $catVal=rtrim($catVal, ",");
        $catVals=explode(",", $catVal);
        $catUndeleted=[];
        $catdeleted=[];
        foreach ($catVals as $catVal) {
            $countMeal=$this->getMealTable()->countMealCategory($catVal);
            if ($countMeal['catCount']==0) {
                $this->getMealTable()->deleteMealCategoryMaster($catVal);
                $catdeleted[]=$catVal;
            } else {
                $catName=$this->getMealTable()->getCatName($catVal);
                if (!in_array($catName['name'], $catUndeleted)) {
                    $catUndeleted[]=$catName['name'];
                }

            }

        }
        if (!empty($catUndeleted)) {
            $deleteCat=implode(",", $catUndeleted);
            $message="Meals are associated with these categories. Please remove the meals  first and then proceed";
        } else {
            $message="Deleted Successfully";
        }
        $catData['message'] = $message;
        $catData['catValsDel'] = $catdeleted;
        $catData['categories'] = $this->getMealTable()->getMealCategory();
        //$mealData = $this->getMealTable()->getMeals();
        //$catData['meallist'] =$mealData;
        $json = new JsonModel($catData);
        return $json;
    
    }
    public function unitSelectAction()
    {
        $searchValue= $this->getRequest()->getPost('searchValue');
        $unitList=$this->getMealTable()->getAllUnit($searchValue);
        $json = new JsonModel($unitList);
        return $json;
    
    }
    public function getMealsDataAction()
    {
        $mealData = $this->getMealTable()->getMeals();
        $mealsData['meallist'] =$mealData;
        $json = new JsonModel($mealsData);
        return $json;
    
    }
    public function updateMealsNutriDataAction()
    {
        set_time_limit(0);
        error_reporting(E_ALL);
        ob_implicit_flush(true);
        ob_end_flush();
        $mealData = $this->getMealTable()->getAllMealsCal();
        foreach ($mealData as $meals) {
            $calVal= $this->getMealTable()->getMealsCalorieValue($meals['id'], $meals['serving_size_unit']);
            $data['calorie']=$calVal['value'];
            $data['id']=$meals['id'];
            $this->getMealTable()->update($data);
        }
        echo "updated sucessfully";
        exit();
    
    }
    public function fetchMealAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }

        $mealsData = $this->getMealTable()->getMeals();

        $json = new JsonModel($mealsData);
        return $json;
    }
    public function updateMealsServingUnitAction()
    {
        set_time_limit(0);
        error_reporting(E_ALL);
        ob_implicit_flush(true);
        ob_end_flush();
        $mealData = $this->getMealTable()->getMealServingUnit();
        foreach ($mealData as $meals) {
            $data['serving_size_unit']=$meals['unit_id'];
            $data['id']=$meals['id'];
            $this->getMealTable()->update($data);
        }
        echo "updated sucessfully";
        exit();
    }
    public function getMealSearchSettingsAction()
    {
        $mealsSearchSettings = $this->getMealTable()->getMealSearchSettings();

        $json = new JsonModel($mealsSearchSettings);
        return $json;
    }

    public function updateMealSearchSettingsAction()
    {
        $mealPlan=$this->getRequest()->getPost('meal_paln');
        if (count($mealPlan)>=2) {
            $data['value']='both';
        } else {
            $data['value']=$mealPlan[0];
        }
        $this->getMealTable()->updateMealSearchSetting($data);
        $json = new JsonModel($mealsSearchSettings);
        return $json;
    }

    public function mealImportAction()
    {
        set_time_limit(0);
        error_reporting(E_ALL);
        $mealData = $this->getMealTable()->getMealData();
        foreach ($mealData as $mealDet) {
            $unitCheck=$this->getMealTable()->getMealUnit($mealDet['unit']);
            $mealtypes=explode('/', $mealDet['type']);
            if (isset($unitCheck['id'])) {
                $data['serving_size_unit']=$unitCheck['id'];
            } else {
                $mealUnitMaster['name']=$mealDet['unit'];
                $mealUnitMasterId=$this->getMealTable()->insertMealUnitMaster($mealUnitMaster);
                $data['serving_size_unit']=$mealUnitMasterId;
            }

            $data['name']=$mealDet['name'];
            $data['guid']=$mealDet['guid'];
            $data['language_id']=1;
            $data['serving_size']=$mealDet['serving_size'];
            $data['calorie']=$mealDet['calorie'];
            $data['brand_name']=$mealDet['brand'];
            $data['added_date']=$mealDet['created_date'];
            $data['vendor_verified']='No';
            $data['dmp_meal']=1;
            $mealId=$this->getMealTable()->insert($data);
            foreach ($mealtypes as $mealtype) {
                $mealTypeDet=$this->getMealTable()->getMealTypeId($mealtype);
                $dataMealType['meal_id']=$mealId;
                $dataMealType['meal_type_master_id']=$mealTypeDet['id'];
                $this->getMealTable()->insertMealType($dataMealType);
            }
            $dataMealUnit['meal_id']=$mealId;
            $dataMealUnit['unit_id']=$data['serving_size_unit'];
            $mealUnitTableId=$this->getMealTable()->insertMealUnit($dataMealUnit);
            $dataNutritions['meal_unit_id']=$mealUnitTableId;
            $dataNutritions['nutrition_fact_id']=1;
            $dataNutritions['value']=$mealDet['calorie'];
            $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            $dataNutritions['meal_unit_id']=$mealUnitTableId;
            $dataNutritions['nutrition_fact_id']=2;
            $dataNutritions['value']=$mealDet['fat'];
            $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            $dataNutritions['meal_unit_id']=$mealUnitTableId;
            $dataNutritions['nutrition_fact_id']=3;
            $dataNutritions['value']=$mealDet['saturated'];
            $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            $dataNutritions['meal_unit_id']=$mealUnitTableId;
            $dataNutritions['nutrition_fact_id']=4;
            $dataNutritions['value']=$mealDet['polyunsaturated'];
            $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            $dataNutritions['meal_unit_id']=$mealUnitTableId;
            $dataNutritions['nutrition_fact_id']=5;
            $dataNutritions['value']=$mealDet['monounsaturated'];
            $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            $dataNutritions['meal_unit_id']=$mealUnitTableId;
            $dataNutritions['nutrition_fact_id']=6;
            $dataNutritions['value']=$mealDet['trans'];
            $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            $dataNutritions['meal_unit_id']=$mealUnitTableId;
            $dataNutritions['nutrition_fact_id']=7;
            $dataNutritions['value']=$mealDet['cholesterol'];
            $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            $dataNutritions['meal_unit_id']=$mealUnitTableId;
            $dataNutritions['nutrition_fact_id']=8;
            $dataNutritions['value']=$mealDet['sodium'];
            $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            $dataNutritions['meal_unit_id']=$mealUnitTableId;
            $dataNutritions['nutrition_fact_id']=9;
            $dataNutritions['value']=$mealDet['potassium'];
            $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            $dataNutritions['meal_unit_id']=$mealUnitTableId;
            $dataNutritions['nutrition_fact_id']=10;
            $dataNutritions['value']=$mealDet['carbs'];
            $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            $dataNutritions['meal_unit_id']=$mealUnitTableId;
            $dataNutritions['nutrition_fact_id']=11;
            $dataNutritions['value']=$mealDet['fiber'];
            $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            $dataNutritions['meal_unit_id']=$mealUnitTableId;
            $dataNutritions['nutrition_fact_id']=12;
            $dataNutritions['value']=$mealDet['protien'];
            $this->getMealTable()->insertMealNutritionFact($dataNutritions);
            

        }
        echo "updated Suceesfully";
        exit;
    }
    protected function getViewHelper($helperName)
    {
        return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
    }
}
