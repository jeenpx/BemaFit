<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace User\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\ServiceManager\ServiceLocatorAwareInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\Db\Adapter\AdapterInterface;
use Zend\Db\Sql\Sql;
use Zend\View\Model\JsonModel;
use Zend\Mail\Message;
use Zend\Mail\Transport\Sendmail as SendmailTransport;

class UserController extends AbstractActionController
{
    const ROUTE_LOGIN        = 'zfcuser/login';
    public function getUserTable()
    {
        if (!isset($this->userTable) || !$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('User\Model\UserDAOImpl');
        }
        return $this->userTable;
    }
    public function indexAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $this->getViewHelper('inlineScript')->prependFile('/js/ko.user.admin.js');
        $this->getViewHelper('HeadScript')->prependFile('/js/user.admin.js');
        $usersData = $this->getUserTable()->getUsers();
/*        echo "<pre>";
        print_r($usersData);
        exit;*/
        return new ViewModel(array('userData' =>json_encode($usersData)));
    }
    public function userStatusChangeAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $data['id']=$this->getRequest()->getPost('userId');
        $data['status_id']=$this->getRequest()->getPost('action');
        $data['verified']="Yes";
        $this->getUserTable()->updateUserStatus($data);
        $userDetails=$this->getUserTable()->getUsersEmail($data['id']);
        if ($data['status_id'] == 2) {
            $this->getUserTable()->updateUserAccessToken($data['id']);
            $this->renderer = $this->getServiceLocator()->get('ViewRenderer');
            $content = $this->renderer->render('user/user/deactivationMail', null);
            $fymCommon = $this->fym();
            try {
                $fymCommon->sendMail($content, 'mail', 'FYM Deactivation Mail', 'info@flexyourmacros.com', $userDetails['email']);
            } catch (\Exception $e) {
            }
        }
        $updateMsg['msg']="Sucess";
        $json = new JsonModel($updateMsg);
        return $json;
    }
    protected function getViewHelper($helperName)
    {
        return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
    }
    public function recoverpasswordAction()
    {
        $data['email']=$this->getRequest()->getPost('email');
        $userDetails=$this->getUserTable()->getUsersPassword($data);
        if (isset($userDetails['id'])) {
            // $message = new Message();
            // $message->addFrom("preejith.jp@gmail.com", "FYM")
            //         ->addTo($userDetails['email'])
            //         ->setSubject("FYM Admin Password");
            // $message->setBody("Your Password - ".$userDetails['password']);
            // $transport = new SendmailTransport();
            // $transport->send($mail);
            $this->renderer = $this->getServiceLocator()->get('ViewRenderer');
            $user=array();
            $user['password']=$userDetails['password'];
            $content = $this->renderer->render('user/user/forgotpassword', $user);
            $fymCommon = $this->fym();
            try {
                $fymCommon->sendMail($content, 'mail', 'FYM Recover Password Mail', 'info@flexyourmacros.com', $userDetails['email']);
            } catch (\Exception $e) {
            }
/*            $to = $userDetails['email'];
            $subject = "Your Password - ".$userDetails['password'];
            $txt = "Your Password - ".$userDetails['password'];
            $headers = "From: preejith.jp@gmail.com";
            mail($to, $subject, $txt, $headers);*/
            $variables = array( 'Message' => 'Password has been sent to your email id' );
        } else {
            $variables = array( 'Message' => 'Email  not found' );
        }
        //$variables = array( 'Message' => 'Password has been sent' );
        $json = new JsonModel($variables);
        return $json;
    }
    public function pendingUserCronAction()
    {
        $pendingUserList=$this->getUserTable()->getPendingUser();
        foreach ($pendingUserList as $pendingUser) {
            $data['id']=$pendingUser['id'];
            $data['status_id']=2;
            $this->getUserTable()->updateUserStatus($data);
        }
        echo "Updated Sucessfully";
        exit;
    }
}
