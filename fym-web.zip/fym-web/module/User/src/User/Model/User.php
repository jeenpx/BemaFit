<?php
namespace User\Model;

class User
{
    public $id;
    public $guid;
    public $username;
    public $email;
    public $first_name;
    public $last_name;
    public $role;
    public $password;
    public $status_id;
    public $type;

   

    public function exchangeArray($data)
    {
        $this->id    = (isset($data['id'])) ? $data['id'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
        $this->meal_type_id = (isset($data['meal_type_id'])) ? $data['meal_type_id'] : null;
        $this->language_id = (isset($data['language_id'])) ? $data['language_id'] : null;
        $this->brand_name = (isset($data['brand_name'])) ? $data['brand_name'] : null;
        $this->serving_size = (isset($data['serving_size'])) ? $data['serving_size'] : null;
        $this->serving_size_unit = (isset($data['serving_size_unit'])) ? $data['serving_size_unit'] : null;
        $this->description = (isset($data['description'])) ? $data['description'] : null;
        $this->vendor_verified = (isset($data['vendor_verified'])) ? $data['vendor_verified'] : null;
    }
}
