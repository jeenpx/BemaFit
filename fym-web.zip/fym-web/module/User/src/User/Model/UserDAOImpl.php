<?php
namespace User\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Predicate\Expression;

class UserDAOImpl
{
    protected $tableGateway;
    protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
        $this->select = new Select();

    }
    public function getUsers()
    {
        $select = $this->tableGateway->getSql()->select();
        $select->columns(array('*',new Expression("CONCAT(first_name,' ',last_name) as name"), new Expression("DATE_FORMAT(date_added , '%m/%d/%y') as signup"), new Expression("UNIX_TIMESTAMP(date_added) as signup_sort"),
                 new Expression("IF((verified = 'No' AND status_id =1), 'Pending', IF( status_id =1, 'Active', 'InActive' ) ) AS status "),
                 new Expression("IF((verified = 'No' AND status_id =1), 'pending', IF( status_id =1, 'active', 'inactive' ) ) AS slug "),
                  ));
        $select->join('status', 'status.id = user.status_id', array('statusid'=>'id','description'=>'description'));
        $select->where(array('role' => 'User'));
        $select->where('user.status_id != 4');
        $select->order(array('id DESC', 'first_name ASC'));
        $resultSet = $this->tableGateway->selectWith($select);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function getUsersEmail($id)
    {
        $select = $this->tableGateway->getSql()->select();
        $select->where(array('id' => $id));
        $resultSet = $this->tableGateway->selectWith($select);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getUsersPassword($data)
    {
        $select = $this->tableGateway->getSql()->select();
        $select->where(array('role' => 'Admin'));
        $select->where(array('email' => $data['email']));
        $resultSet = $this->tableGateway->selectWith($select);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function updateUserStatus($data)
    {
        try {
            $this->tableGateway->update($data, array('id' => $data['id']));
            return 1;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function updateUserAccessToken($userId)
    {
         $adapter = $this->tableGateway->getAdapter();
         $oauthAccessTokens = new TableGateway('oauth_access_tokens', $adapter);
        try {
            $oauthAccessTokens->delete(array('user_id' => $userId));
        } catch (\Exception $e) {
        }
    }
    public function getPendingUser()
    {
        $sql = "SELECT id
                FROM user
                WHERE status_id =1 AND verified='No' 
                AND DATEDIFF( CURDATE( ) , date_added ) >=15 " ;
        $result = $this->tableGateway->getAdapter()->driver->getConnection()->execute($sql);
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
}
