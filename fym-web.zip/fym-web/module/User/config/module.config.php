<?php
return array(
    'router' => array(
        'routes' => array(
            'user' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/user',
                    'defaults' => array(
                        'controller' => 'user',
                        'action'     => 'index',
                    ),
                )
            ),
            'recover-password' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/recoverpassword',
                    'defaults' => array(
                        'controller' => 'user',
                        'action'     => 'recoverpassword',
                    ),
                )
            ),
            'userStatusChange' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/userStatusChange',
                    'defaults' => array(
                        'controller' => 'user',
                        'action'     => 'userStatusChange',
                    ),
                )
            ),
            'pendingUserCron' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/pendingUserCron',
                    'defaults' => array(
                        'controller' => 'user',
                        'action'     => 'pendingUserCron',
                    ),
                )
            )


        ),
    ),
    'controllers' => array(
        'invokables' => array(
            'user' => 'User\Controller\UserController',
        ),
    ),
    'controller_plugins' => array(
        'invokables' => array(
            'fym' => 'Application\Controller\Plugin\Fym',
        )
    ),
    'view_manager' => array(
        'template_map' => array(
            'user/user/index' => __DIR__ . '/../view/user/user/index.phtml',
            'user/user/activation' => __DIR__ . '/../view/user/user/deactivationMail.phtml',
            'user/user/forgotpassword' => __DIR__ . '/../view/user/user/forgotpassword.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
