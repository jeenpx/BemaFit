<?php
namespace Business\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Predicate\Expression;

class BusinessDAOImpl
{
    protected $tableGateway;
    protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
        $this->select = new Select();

    }
    public function getAllBusiness()
    {
        $select = $this->tableGateway->getSql()->select()->columns(array(
        '*', new Expression("CONCAT(address1,', ',address2,', ',state_code,' ',zipcode) as address"), new Expression("CONCAT(address1,', ',state_code,' ',zipcode) as address_half")
        ));
        $select->join('states', 'states.id = business.state', array('state_code'=>'state_code'));
        $select->join("business_category", "business_category.business_id = business.id", array("catid"=>new Expression("Group_Concat(DISTINCT business_category.business_category_master_id)")), "LEFT");
        $select->group('business.id');
        $select->join("business_category_master", "business_category_master.id = business_category.business_category_master_id", array("catname"=>new Expression("Group_Concat(DISTINCT business_category_master.name SEPARATOR ', ')")), "LEFT");
        $select->group('business.id');
        $select->join("business_radius", "business_radius.business_id = business.id", array("radius"=>new Expression("Group_Concat(DISTINCT business_radius.radius_value)")), "LEFT");
        $select->group('business_radius.business_id');
        $select->where('business.status_id != 4');
        $select->where('business_category_master.status_id != 4');
        $select->order('id DESC');
        $resultSet = $this->tableGateway->selectWith($select);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function insert($data)
    {
        try {
            $this->tableGateway->insert($data);
            $id = $this->tableGateway->lastInsertValue;
            return $id;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function update($data)
    {
        try {
            $this->tableGateway->update($data, array('id' => $data['id']));
            return 1;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function deleteBusiness($data)
    {
        try {
            $this->tableGateway->update($data, array('id' => $data['id']));
            return 1;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function getBusinessCategory()
    {
        $adapter = $this->tableGateway->getAdapter();
        $businessCategoryMaster = new TableGateway('business_category_master', $adapter);
        $select = $businessCategoryMaster->getSql()->select();
        $select->where('business_category_master.status_id != 4');
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function getBusinessForCopy($businessId)
    {
        $select = $this->tableGateway->getSql()->select();
        $select->where(array('business.id' => $businessId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getBusinessCategoryForCopy($businessId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $adImage = new TableGateway('business_category', $adapter);
        $select = $adImage->getSql()->select();
        $select->where(array('business_category.business_id' => $businessId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function getBusinessById($id)
    {
        $select = $this->tableGateway->getSql()->select()->columns(array(
        '*', new Expression("CONCAT(address1,', ',address2,', ',state_code,' ',zipcode) as address"), new Expression("CONCAT(address1,', ',state_code,' ',zipcode) as address_half")
        ));
        $select->join('business_image', 'business_image.business_id = business.id', array('file'=>'file','file_resize'=>'file_resize'), "LEFT");
        $select->join('states', 'states.id = business.state', array('state_code'=>'state_code'));
        $select->join("business_category", "business_category.business_id = business.id", array("catid"=>new Expression("Group_Concat(DISTINCT business_category.business_category_master_id)")), "LEFT");
        $select->group('business.id');
        $select->join("business_category_master", "business_category_master.id = business_category.business_category_master_id", array("catname"=>new Expression("Group_Concat(DISTINCT business_category_master.name)")), "LEFT");
        $select->group('business.id');
        $select->join("business_radius", "business_radius.business_id = business.id", array("radius"=>new Expression("Group_Concat(DISTINCT business_radius.radius_value)")), "LEFT");
        $select->group('business.id');
        $select->where('business.status_id != 4');
        $select->where(array('business.id' => $id));
        $resultSet = $this->tableGateway->selectWith($select);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getStates()
    {
        $adapter = $this->tableGateway->getAdapter();
        $states= new TableGateway('states', $adapter);
        $select = $states->getSql()->select();
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function insertBusinessCategory($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $businessCategory = new TableGateway('business_category', $adapter);
         $businessCategory->insert($data);
    }
    public function insertBusinessCategoryMaster($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $businessCategoryMaster = new TableGateway('business_category_master', $adapter);
         $businessCategoryMaster->insert($data);
         $id = $businessCategoryMaster->lastInsertValue;
         return $id;
    }
    public function updateBusinessCategoryMaster($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $businessCategoryMaster = new TableGateway('business_category_master', $adapter);
         $businessCategoryMaster->update($data, array('id' => $data['id']));
    }
    public function deleteBusinessCategory($id)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $businessCategory = new TableGateway('business_category', $adapter);
             return $businessCategory->delete(array('business_id' => $id));
        } catch (\Exception $e) {
             return 0;
        }
    }
    public function deleteBusinessCategoryMaster($catId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $businessCategory = new TableGateway('business_category_master', $adapter);
        try {
            $data['status_id']=4;
            $businessCategory->update($data, array('id' => $catId));
            //$businessCategory->delete('id = '.$catId);
            return 1;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function insertBusinessImage($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $businessImage = new TableGateway('business_image', $adapter);
         $businessImage->insert($data);
    }
    public function updateBusinessImage($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $adImage = new TableGateway('business_image', $adapter);
         $adImage->update($data, array('business_id' => $data['business_id']));
    }
    public function insertRadius($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $adRadius = new TableGateway('business_radius', $adapter);
         $adRadius->insert($data);
    }
    public function getBusinessRadiusForCopy($businessId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $adImage = new TableGateway('business_radius', $adapter);
        $select = $adImage->getSql()->select();
        $select->where(array('business_radius.business_id' => $businessId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function getBusinessImageForCopy($businessId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $adImage = new TableGateway('business_image', $adapter);
        $select = $adImage->getSql()->select();
        $select->where(array('business_image.business_id' => $businessId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function insertBusinessRadius($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $businessCategory = new TableGateway('business_radius', $adapter);
         $businessCategory->insert($data);
    }
    public function getRadius($businessId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $radius= new TableGateway('business_radius', $adapter);
        $select = $radius->getSql()->select();
        $select->where(array('business_radius.business_id' => $businessId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function insertBusinessHour($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $businessHour = new TableGateway('business_working_hours', $adapter);
         $businessHour->insert($data);
    }
    public function getBusinessHours($businessId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $radius= new TableGateway('business_working_hours', $adapter);
        $select = $radius->getSql()->select();
        $select->where(array('business_working_hours.business_id' => $businessId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function deleteBusinessHours($id)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $businessHours = new TableGateway('business_working_hours', $adapter);
             return $businessHours->delete(array('business_id' => $id));
        } catch (\Exception $e) {
             return 0;
        }
    }
    public function deleteRadius($id)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $businessCategory = new TableGateway('business_radius', $adapter);
             return $businessCategory->delete(array('business_id' => $id));
        } catch (\Exception $e) {
             return 0;
        }
    }
    public function getPostalId($code)
    {
        $adapter = $this->tableGateway->getAdapter();
        $radius= new TableGateway('postal_code', $adapter);
        $select = $radius->getSql()->select()->columns(array('id'));
        $select->where('postal_code.code ='.$code);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getStateId($code)
    {
        $adapter = $this->tableGateway->getAdapter();
        $radius= new TableGateway('states', $adapter);
        $select = $radius->getSql()->select()->columns(array('id'));
        $select->where('states.state_name = "'.$code.'"');
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getZipcode($id)
    {
        $adapter = $this->tableGateway->getAdapter();
        $radius= new TableGateway('postal_code', $adapter);
        $select = $radius->getSql()->select()->columns(array('code'));
        $select->where('postal_code.id ='.$id);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getStateName($id)
    {
        $adapter = $this->tableGateway->getAdapter();
        $radius= new TableGateway('states', $adapter);
        $select = $radius->getSql()->select()->columns(array('state_name'));
        $select->where('states.id ='.$id);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function countBusinessCategory($catId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $businessCategory = new TableGateway('business_category', $adapter);
        $select = $businessCategory->getSql()->select();
        $select->columns(array(new Expression("COUNT(business_category.id) as catCount")));
        $select->join('business', 'business.id = business_category.business_id');
        $select->where(array('business_category_master_id' => $catId));
        $select->where('business.status_id != 4');
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getCatName($catId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $businessCategory = new TableGateway('business_category_master', $adapter);
        $select = $businessCategory->getSql()->select();
        $select->columns(array('name'));
        $select->where(array('id' => $catId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function deleteBusinessImage($id)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $businessImage = new TableGateway('business_image', $adapter);
             return $businessImage->delete(array('business_id' => $id));
        } catch (\Exception $e) {
             return 0;
        }
    }
}
