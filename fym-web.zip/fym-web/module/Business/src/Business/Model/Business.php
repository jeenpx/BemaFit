<?php
namespace Business\Model;

class Business
{
    public $id;
    public $guid;
    public $name;
    public $address1;
    public $address2;
    public $state;
    public $city;
    public $url;
    public $language_id;
    public $description;
    public $status_id;
    public $created_by;
    public $created_date;
    public $updated_by;
    public $updated_date;

   

    public function exchangeArray($data)
    {
        $this->id    = (isset($data['id'])) ? $data['id'] : null;
        $this->guid = (isset($data['guid'])) ? $data['guid'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
        $this->address1 = (isset($data['address1'])) ? $data['address1'] : null;
        $this->address2 = (isset($data['address2'])) ? $data['address2'] : null;
        $this->state = (isset($data['state'])) ? $data['state'] : null;
        $this->city = (isset($data['city'])) ? $data['city'] : null;
        $this->url = (isset($data['url'])) ? $data['url'] : null;
        $this->language_id = (isset($data['language_id'])) ? $data['language_id'] : null;
        $this->description = (isset($data['description'])) ? $data['description'] : null;
        $this->status_id = (isset($data['status_id'])) ? $data['status_id'] : null;
        $this->created_by = (isset($data['created_by'])) ? $data['created_by'] : null;
        $this->created_date = (isset($data['created_date'])) ? $data['created_date'] : null;
        $this->updated_by = (isset($data['updated_by'])) ? $data['updated_by'] : null;
        $this->updated_date = (isset($data['updated_date'])) ? $data['updated_date'] : null;
    }
}
