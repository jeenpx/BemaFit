<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Business\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\ServiceManager\ServiceLocatorAwareInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\Db\Adapter\AdapterInterface;
use Zend\Db\Sql\Sql;
use Zend\View\Model\JsonModel;

class BusinessController extends AbstractActionController
{
    const ROUTE_LOGIN        = 'zfcuser/login';
    public $daysData=array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
    public $timeData=array('12:00 AM','12:30 AM','1:00 AM','1:30 AM','2:00 AM','2:30 AM','3:00 AM','3:30 AM','4:00 AM','4:30 AM','5:00 AM','5:30 AM','6:00 AM','6:30 AM','7:00 AM','7:30 AM','8:00 AM','8:30 AM','9:00 AM','9:30 AM','10:00 AM','10:30 AM','11:00 AM'
                            ,'11:30 AM','12:00 PM','12:30 PM','1:00 PM','1:30 PM','2:00 PM','2:30 PM','3:00 PM','3:30 PM','4:00 PM','4:30 PM','5:00 PM','5:30 PM','6:00 PM','6:30 PM','7:00 PM','7:30 PM','8:00 PM','8:30 PM','9:00 PM','9:30 PM','10:00 PM','10:30 PM','11:00 PM','11:30 PM');
    public function getBusinessTable()
    {
        if (!isset($this->businessTable) || !$this->businessTable) {
            $sm = $this->getServiceLocator();
            $this->businessTable = $sm->get('Business\Model\BusinessDAOImpl');
        }
        return $this->businessTable;
    }
    public function indexAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $businessData = $this->getBusinessTable()->getAllBusiness();
        $newBusinessData=array();
        foreach ($businessData as $business) {
            $newBusiness=array();
            $newBusiness=$business;
            $radiusVal=$this->getBusinessTable()->getRadius($business['id']);
            //print_r($radiusVal);
            //echo $business['id']." - ".$business['radius']."  ";
            $radiusVales="";
            foreach ($radiusVal as $radius) {
                //echo "1234".$radius['radius_type'];
                if ($radius['radius_type']=="Zipcode") {
                    $zipcodeVal=$this->getBusinessTable()->getZipcode($radius['radius_value']);
                    $radiusVales.= $zipcodeVal['code'].", ";
                } else {
                    $stateVal=$this->getBusinessTable()->getStateName($radius['radius_value']);
                    $radiusVales.= $stateVal['state_name'].", ";
                }

            }
            $radiusVales=rtrim($radiusVales, ', ');
            $newBusiness['radius']=$radiusVales;
            array_push($newBusinessData, $newBusiness);
        }
        $bussinessCategoryData = $this->getBusinessTable()->getBusinessCategory();
        
        
        $statesData = $this->getBusinessTable()->getStates();
        $this->getViewHelper('HeadScript')->prependFile('/js/business.admin.js');
        $this->getViewHelper('inlineScript')->prependFile('/js/ko.business.admin.js');
        return new ViewModel(array('businessData' =>json_encode($newBusinessData),'bussinessCategoryData'=>$bussinessCategoryData,'states'=>$statesData,'days'=>$this->daysData,'times'=>$this->timeData));
    }
    public function removeBusinessAction()
    {
        $businessId= $this->getRequest()->getPost('businessId');
        $data['id']=$businessId;
        $data['status_id']=4;
        $deleteRet=$this->getBusinessTable()->deleteBusiness($data);
        $deletMsg=array();
        if ($deleteRet==1) {
            $deletMsg['msg']="Sucess";
        } else {
            $deletMsg['msg']="False";
        }
        $json = new JsonModel($deletMsg);
        return $json;
    }
    public function copyBusinessAction()
    {
        $businessId= $this->getRequest()->getPost('businessId');
        $businessDetails=$this->getBusinessTable()->getBusinessForCopy($businessId);
        unset($businessDetails['id']);
        $businessId_new=$this->getBusinessTable()->insert($businessDetails);
        $businessImageDetails=$this->getBusinessTable()->getBusinessImageForCopy($businessId);
        unset($businessImageDetails['id']);
        $businessImageDetails['business_id']=$businessId_new;
        $this->getBusinessTable()->insertBusinessImage($businessImageDetails);
        $businessCategoryDetails=$this->getBusinessTable()->getBusinessCategoryForCopy($businessId);
        foreach ($businessCategoryDetails as $newBusinessCategoryDetails) {
            unset($newBusinessCategoryDetails['id']);
            $newBusinessCategoryDetails['business_id']=$businessId_new;
            $businessCategoryId_new=$this->getBusinessTable()->insertBusinessCategory($newBusinessCategoryDetails);
        }
        $businessCategoryDetails=$this->getBusinessTable()->getBusinessRadiusForCopy($businessId);
        foreach ($businessCategoryDetails as $newBusinessCategoryDetails) {
            unset($newBusinessCategoryDetails['id']);
            $newBusinessCategoryDetails['business_id']=$businessId_new;
            $businessCategoryId_new=$this->getBusinessTable()->insertBusinessRadius($newBusinessCategoryDetails);
        }
        $businessCopyDet=$this->getBusinessTable()->getBusinessById($businessId_new);
        $newBusinessCopy=array();
        $newBusinessCopy=$businessCopyDet;
        $radiusVal=$this->getBusinessTable()->getRadius($businessCopyDet['id']);
        //print_r($radiusVal);
        //echo $business['id']." - ".$business['radius']."  ";
        $radiusVales="";
        foreach ($radiusVal as $radius) {
            //echo "1234".$radius['radius_type'];
            if ($radius['radius_type']=="Zipcode") {
                $zipcodeVal=$this->getBusinessTable()->getZipcode($radius['radius_value']);
                $radiusVales.= $zipcodeVal['code'].", ";
            } else {
                $stateVal=$this->getBusinessTable()->getStateName($radius['radius_value']);
                $radiusVales.= $stateVal['state_name'].", ";
            }

        }
        $radiusVales=rtrim($radiusVales, ', ');
        $newBusinessCopy['radius']=$radiusVales;
        $json = new JsonModel($newBusinessCopy);
        return $json;
    }
    protected function postBusinessAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $radiusValues=$this->getRequest()->getPost('radiusValues');
        $radiusArray=explode(",", $radiusValues);
        $businessCategory=$this->getRequest()->getPost('businessCategory');
        $data['id']=$this->getRequest()->getPost('businessId');
        $data['name']=$this->getRequest()->getPost('business_name');
        $data['address1']=$this->getRequest()->getPost('address1');
        $data['address2']=$this->getRequest()->getPost('address2');
        $data['state']=$this->getRequest()->getPost('state');
        $data['zipcode']=$this->getRequest()->getPost('zipcode');
        $data['phone']=$this->getRequest()->getPost('phone');
        $data['url']=$this->getRequest()->getPost('url');
        $data['description']=$this->getRequest()->getPost('business-description');
        $data['status_id']=1;
        $data['business_hour_check']=$this->getRequest()->getPost('business_hours_available');
        $open=$this->getRequest()->getPost('open');
        $close=$this->getRequest()->getPost('close');

        $data['premium_listing']=($this->getRequest()->getPost('premium-list')!="")?$this->getRequest()->getPost('premium-list'):0;
        $data['all_radius']=($this->getRequest()->getPost('all_radius')!="")?$this->getRequest()->getPost('all_radius'):0;
        $businessImage=$this->getRequest()->getPost('businessImageLocation');
        $businessImageResize=$this->getRequest()->getPost('businessImageResizeLocation');
        $dataBusinessImage['file']=$businessImage;
        $dataBusinessImage['file_resize']=$businessImageResize;
        $address1=str_replace(' ', '', $data['address1']);
        $address2=str_replace(' ', '', $data['address2']);
        $stateName=$this->getBusinessTable()->getStateName($data['state']);
        $state=$stateName['state_name'];
        $state=str_replace(' ', '', $state);
        if ($address2 !="") {
            $address = $address1."+".$address2."+".$state."+".$data['zipcode'];
        } else {
            $address = $address1."+".$state."+".$data['zipcode'];
        }
        
        $address = trim($address);
        $dataBusinessImage['description']="";
        $dataBusinessImage['status_id']=1;
        //$address = $data['address1']."+".$data['address2']."+".$data['state']."+".$data['zipcode'];
        $url = "http://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&region=USA";
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            $response = curl_exec($ch);
            curl_close($ch);
            $response_a = json_decode($response);
            $data['latitude'] = ($response_a->results[0]->geometry->location->lat!="")?$response_a->results[0]->geometry->location->lat:"";
            $data['longitude'] = ($response_a->results[0]->geometry->location->lng!="")?$response_a->results[0]->geometry->location->lng:"";
        } catch (\Exception $e) {
            $data['latitude'] = "";
            $data['longitude'] = "";
        }
        if ($data['id']=="") {
            $data['guid']=md5(uniqid(rand(), true));
            $businessId=$this->getBusinessTable()->insert($data);
            $dataBusinessImage['business_id']=$businessId;
            $this->getBusinessTable()->insertBusinessImage($dataBusinessImage);
            foreach ($businessCategory as $businessCategoryId) {
                $dataBusiness['business_id']=$businessId;
                $dataBusiness['business_category_master_id']=$businessCategoryId;
                $this->getBusinessTable()->insertBusinessCategory($dataBusiness);
            }
            foreach ($radiusArray as $radiusValues) {
                if ($radiusValues!="") {
                    if (is_numeric($radiusValues)) {
                         $postalValues=$this->getBusinessTable()->getPostalId($radiusValues);
                         $radiusValues=$postalValues['id'];
                         $radiusType="Zipcode";
                    } else {
                         $stateValues=$this->getBusinessTable()->getStateId($radiusValues);
                         $radiusValues=$stateValues['id'];
                         $radiusType="State";
                    }
                    $radius['business_id'] = $businessId;
                    $radius['radius_value'] = $radiusValues;
                    $radius['radius_type'] = $radiusType;
                    $this->getBusinessTable()->insertRadius($radius);
                }
            }
            if ($data['business_hour_check']==1) {
                foreach ($this->daysData as $days) {
                    $businessHour['business_id']=$businessId;
                    $businessHour['day']=$days;
                    $businessHour['open']=$open[$days];
                    $businessHour['close']=$close[$days];
                    $this->getBusinessTable()->insertBusinessHour($businessHour);
                }
            }
        } else {
            $this->getBusinessTable()->update($data);
            $dataBusinessImage['business_id']=$this->getRequest()->getPost('businessId');
            $this->getBusinessTable()->deleteBusinessImage($data['id']);
            $this->getBusinessTable()->deleteBusinessCategory($data['id']);
            $this->getBusinessTable()->deleteBusinessHours($data['id']);
            $this->getBusinessTable()->deleteRadius($data['id']);
            $this->getBusinessTable()->insertBusinessImage($dataBusinessImage);
            foreach ($businessCategory as $businessCategoryId) {
                $dataBusiness['business_id']=$data['id'];
                $dataBusiness['business_category_master_id']=$businessCategoryId;
                $this->getBusinessTable()->insertBusinessCategory($dataBusiness);
            }
            if ($data['business_hour_check']==1) {
                foreach ($this->daysData as $days) {
                    $businessHour['business_id']=$data['id'];
                    $businessHour['day']=$days;
                    $businessHour['open']=$open[$days];
                    $businessHour['close']=$close[$days];
                    $this->getBusinessTable()->insertBusinessHour($businessHour);
                }
            }
            foreach ($radiusArray as $radiusValues) {
                if ($radiusValues!="") {
                    if (is_numeric($radiusValues)) {
                         $postalValues=$this->getBusinessTable()->getPostalId($radiusValues);
                         $radiusValues=$postalValues['id'];
                         $radiusType="Zipcode";
                    } else {
                         $stateValues=$this->getBusinessTable()->getStateId(ltrim($radiusValues));
                         $radiusValues=$stateValues['id'];
                         $radiusType="State";
                    }
                    $radius['business_id'] = $data['id'];
                    $radius['radius_value'] = $radiusValues;
                    $radius['radius_type'] = $radiusType;
                    $this->getBusinessTable()->insertRadius($radius);
                }
            }
            //$dataAdImage['ad_id']=$this->getRequest()->getPost('adId');
            //$this->getAdTable()->updateAdImage($dataAdImage);
        }
        $businessData = $this->getBusinessTable()->getAllBusiness();
        $newBusinessData=array();
        foreach ($businessData as $business) {
            $newBusiness=array();
            $newBusiness=$business;
            $radiusVal=$this->getBusinessTable()->getRadius($business['id']);
            //print_r($radiusVal);
            //echo $business['id']." - ".$business['radius']."  ";
            $radiusVales="";
            foreach ($radiusVal as $radius) {
                //echo "1234".$radius['radius_type'];
                if ($radius['radius_type']=="Zipcode") {
                    $zipcodeVal=$this->getBusinessTable()->getZipcode($radius['radius_value']);
                    $radiusVales.= $zipcodeVal['code'].",";
                } else {
                    $stateVal=$this->getBusinessTable()->getStateName($radius['radius_value']);
                    $radiusVales.= $stateVal['state_name'].",";
                }

            }
            $radiusVales=rtrim($radiusVales, ',');
            $newBusiness['radius']=$radiusVales;
            array_push($newBusinessData, $newBusiness);
        }
        $json = new JsonModel($newBusinessData);
        return $json;
    }
    public function getBusinessByIdAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $businessId= $this->getRequest()->getPost('businessId');
        $businessDetails=$this->getBusinessTable()->getBusinessById($businessId);
        $json = new JsonModel($businessDetails);
        return $json;
    }
    public function getBusinessCategoryAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $bussinessCategoryData = $this->getBusinessTable()->getBusinessCategory();
        $json = new JsonModel($bussinessCategoryData);
        return $json;
    }
    public function businessImageSubmitAction()
    {
        $fymCommon = $this->fym();
        $File    = $this->params()->fromFiles('image');
        $config = $this->getServiceLocator()->get('Config');
        $settings=$config['business_photo_Settings'];
        $uploadDet=$fymCommon->uploadImage("businessImage", $File, $settings, $config['amazon_s3']);
        $json = new JsonModel($uploadDet);
        return $json;

    }
    public function addBusinessCategoriesAction()
    {
        $data['name']=$this->getRequest()->getPost('category_name');
        $data['name_es']=$this->getRequest()->getPost('category_name_es');
        $data['status_id']=1;
        $data['created_by']=1;
        $data['created_date']=date("Y-m-d");
        $catId=$this->getBusinessTable()->insertBusinessCategoryMaster($data);
        $catData['id']=$catId;
        $catData['categories'] = $this->getBusinessTable()->getBusinessCategory();
        $json = new JsonModel($catData);
        return $json;

    }
    protected function editBusinessCategoriesAction()
    {
        $categoryEditList=$this->getRequest()->getPost('businesscat');
        $categorySpaEditList=$this->getRequest()->getPost('businesscates');
        foreach ($categoryEditList as $key => $value) {
            $data=array();
            $data['id']=$key;
            if (trim($value)!="") {
                $data['name']=trim($value);
            }
            if (trim($categorySpaEditList[$key])!="") {
                $data['name_es']=trim($categorySpaEditList[$key]);
            }
            $this->getBusinessTable()->updateBusinessCategoryMaster($data);
        }
        $catData['categories'] = $this->getBusinessTable()->getBusinessCategory();
        $businessData = $this->getBusinessTable()->getAllBusiness();
        $newBusinessData=array();
        foreach ($businessData as $business) {
            $newBusiness=array();
            $newBusiness=$business;
            $radiusVal=$this->getBusinessTable()->getRadius($business['id']);
            //print_r($radiusVal);
            //echo $business['id']." - ".$business['radius']."  ";
            $radiusVales="";
            foreach ($radiusVal as $radius) {
                //echo "1234".$radius['radius_type'];
                if ($radius['radius_type']=="Zipcode") {
                    $zipcodeVal=$this->getBusinessTable()->getZipcode($radius['radius_value']);
                    $radiusVales.= $zipcodeVal['code'].", ";
                } else {
                    $stateVal=$this->getBusinessTable()->getStateName($radius['radius_value']);
                    $radiusVales.= $stateVal['state_name'].", ";
                }

            }
            $radiusVales=rtrim($radiusVales, ', ');
            $newBusiness['radius']=$radiusVales;
            array_push($newBusinessData, $newBusiness);
        }
        $catData['businesslist'] =$newBusinessData;
        $json = new JsonModel($catData);
        return $json;
    }
    public function removeBusinessCatAction()
    {

        $catVal=$this->getRequest()->getPost('catVal');
        $catVal=rtrim($catVal, ",");
        $catVals=explode(",", $catVal);
        $catUndeleted=[];
        $catdeleted=[];
        foreach ($catVals as $catVal) {
            $countBusiness=$this->getBusinessTable()->countBusinessCategory($catVal);
            if ($countBusiness['catCount']==0) {
                 $this->getBusinessTable()->deleteBusinessCategoryMaster($catVal);
                 $catdeleted[]=$catVal;
            } else {
                $catName=$this->getBusinessTable()->getCatName($catVal);
                if (!in_array($catName['name'], $catUndeleted)) {
                    $catUndeleted[]=$catName['name'];
                }

            }

        }
        if (!empty($catUndeleted)) {
            $deleteCat=implode(",", $catUndeleted);
            $message="Business are associated with these categories. Please remove the business  first and then proceed";
        } else {
            $message="Deleted Successfully";
        }
        $catData['message'] = $message;
        $catData['catValsDel'] = $catdeleted;
        $catData['categories'] = $this->getBusinessTable()->getBusinessCategory();
        $businessData = $this->getBusinessTable()->getAllBusiness();
        $newBusinessData=array();
        foreach ($businessData as $business) {
            $newBusiness=array();
            $newBusiness=$business;
            $radiusVal=$this->getBusinessTable()->getRadius($business['id']);
            //print_r($radiusVal);
            //echo $business['id']." - ".$business['radius']."  ";
            $radiusVales="";
            foreach ($radiusVal as $radius) {
                //echo "1234".$radius['radius_type'];
                if ($radius['radius_type']=="Zipcode") {
                    $zipcodeVal=$this->getBusinessTable()->getZipcode($radius['radius_value']);
                    $radiusVales.= $zipcodeVal['code'].", ";
                } else {
                    $stateVal=$this->getBusinessTable()->getStateName($radius['radius_value']);
                    $radiusVales.= $stateVal['state_name'].", ";
                }

            }
            $radiusVales=rtrim($radiusVales, ', ');
            $newBusiness['radius']=$radiusVales;
            array_push($newBusinessData, $newBusiness);
        }
        $catData['businesslist'] =$newBusinessData;
        $json = new JsonModel($catData);
        return $json;
    
    }
    public function getRadiusByIdAction()
    {

        $businessId= $this->getRequest()->getPost('businessId');
        $bussinessRadiusData = $this->getBusinessTable()->getRadius($businessId);
        $newBusinessRadiusData=array();
        foreach ($bussinessRadiusData as $business) {
            $newBusiness=array();
            $newBusiness=$business;
            $radiusVales="";
            //echo $business['radius_type'];
            //echo "1234".$radius['radius_type'];
            if ($business['radius_type']=="Zipcode") {
                $zipcodeVal=$this->getBusinessTable()->getZipcode($business['radius_value']);
                $radiusVales.= $zipcodeVal['code'].",";
            } else {
                $stateVal=$this->getBusinessTable()->getStateName($business['radius_value']);
                $radiusVales.= $stateVal['state_name'].",";
            }

            $radiusVales=rtrim($radiusVales, ',');
            $newBusiness['radius_value']=$radiusVales;
            array_push($newBusinessRadiusData, $newBusiness);
        }
        $json = new JsonModel($newBusinessRadiusData);
        return $json;
    
    }
    public function getBusinessHoursbyIdAction()
    {

        $businessId= $this->getRequest()->getPost('businessId');
        $bussinessHoursData = $this->getBusinessTable()->getBusinessHours($businessId);
        $json = new JsonModel($bussinessHoursData);
        return $json;
    
    }
    protected function verifyEmailAction()
    {
        echo "abcd";
        exit;
    }
    /**
    * To Convert String time in to mysql formated time format
    */
    protected function covertMysqlTime($time)
    {
        $formattedDateStr = date("H:i:s", strtotime("10:47PM"));
        $formattedDateStr = date("h:ia", strtotime("22:47:00"));
        echo $formattedDateStr;
        exit;
    }

    protected function getViewHelper($helperName)
    {

        return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
    }
}
