<?php
return array(
    'router' => array(
        'routes' => array(
            'business' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/business',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'index',
                    ),
                )
            ),
            'removeBusiness' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/removeBusiness',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'removeBusiness',
                    ),
                )
            ),
            'copyBusiness' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/copyBusiness',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'copyBusiness',
                    ),
                )
            ),
           'verifyEmail' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/verifyEmail/[:slug]',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'verifyEmail',
                    ),
                )
            ),
           'postBusiness' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/postBusiness',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'postBusiness',
                    ),
                )
            ),
            'getBusinessById' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/getBusinessById',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'getBusinessById',
                    ),
                )
            ),
            'businessImageSubmit' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/businessImageSubmit',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'businessImageSubmit',
                    ),
                )
            ),
            'addBusinessCategories' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/addBusinessCategories',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'addBusinessCategories',
                    ),
                )
            ),
            'getBusinessCategory' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/getBusinessCategory',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'getBusinessCategory',
                    ),
                )
            ),
            'editBusinessCategories' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/editBusinessCategories',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'editBusinessCategories',
                    ),
                )
            ),
            'removeBusinessCat' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/removeBusinessCat',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'removeBusinessCat',
                    ),
                )
            ),
            'getRadiusById' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/getRadiusById',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'getRadiusById',
                    ),
                )
            ),
            'getBusinessHoursbyId' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/getBusinessHoursbyId',
                    'defaults' => array(
                        'controller' => 'business',
                        'action'     => 'getBusinessHoursbyId',
                    ),
                )
            )


            
        ),
    ),
    'controllers' => array(
        'invokables' => array(
            'business' => 'Business\Controller\BusinessController',
        ),
    ),
    'controller_plugins' => array(
        'invokables' => array(
            'fym' => 'Application\Controller\Plugin\Fym',
        )
    ),
    'view_manager' => array(
        'template_map' => array(
            'business/business/index' => __DIR__ . '/../view/business/business/index.phtml',
            'addbusiness' => __DIR__ . '/../view/business/business/addbusiness.phtml',
            'businesscategory' => __DIR__ . '/../view/business/business/categories.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
