<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Exercise\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\ServiceManager\ServiceLocatorAwareInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\Db\Adapter\AdapterInterface;
use Zend\Db\Sql\Sql;
use Zend\View\Model\JsonModel;

class ExerciseController extends AbstractActionController
{
    const ROUTE_LOGIN        = 'zfcuser/login';
    public function getExerciseTable()
    {
        if (!isset($this->exerciseTable) || !$this->exerciseTable) {
            $sm = $this->getServiceLocator();
            $this->exerciseTable = $sm->get('Exercise\Model\ExerciseDAOImpl');
        }
        return $this->exerciseTable;
    }
    public function getExerciseTypeTable()
    {
        if (!isset($this->exerciseTypeTable) || !$this->exerciseTypeTable) {
            $sm = $this->getServiceLocator();
            $this->exerciseTypeTable = $sm->get('Exercise\Model\ExerciseTypeDAOImpl');
        }
        return $this->exerciseTypeTable;
    }
    public function indexAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $exerciseTypeData = $this->getExerciseTypeTable()->getExerciseType();
        $exerciseData = $this->getExerciseTable()->getAllExercise();
        $this->getViewHelper('HeadScript')->prependFile('/js/exercise.admin.js');
        $this->getViewHelper('inlineScript')->prependFile('/js/ko.exercise.admin.js');
        return new ViewModel(array('exerciseTypes' =>$exerciseTypeData,'flashMessages' => $this->flashMessenger()->getMessages(),'exerciseData' =>json_encode($exerciseData)));
    }
    public function postAddExerciseAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $data['id']=$this->getRequest()->getPost('exerciseId');
        $data['name']=$this->getRequest()->getPost('exercise_name');
        $data['name_es']=utf8_decode($this->getRequest()->getPost('exercise_name_spa'));
        $exercise_lan=$this->getRequest()->getPost('exercise_language');
        if (count($exercise_lan)==1 && $exercise_lan[0]==2) {
            $language_id=2;
        } else if (count($exercise_lan)==2) {
            $language_id=3;
        } else {
            $language_id=1;
        }
        //$data['exercise_language_id']=$this->getRequest()->getPost('exercise_language');
        $data['exercise_type_id']=$this->getRequest()->getPost('exercise_type');
        $data['language_id']=$language_id;
        $option=array();
        if ($this->getRequest()->getPost('amount_hour')!="") {
            $option['Exercise Amount']=$this->getRequest()->getPost('amount_hour');
        }
        //$option['Calories Burned']=$this->getRequest()->getPost('calories_burned');
        $option['Distance']=$this->getRequest()->getPost('distance');
        $option['Number of Sets']=$this->getRequest()->getPost('number_of_sets');
        $option['Reps/ Weight per Set']=$this->getRequest()->getPost('weight_per_set');
        $option['Reps/Set']=$this->getRequest()->getPost('reps_set');
        //$data['amount_hour']=$this->getRequest()->getPost('amount_hour');
        //$data['amount_min']=$this->getRequest()->getPost('amount_min');
        //$data['amount_sec']=$this->getRequest()->getPost('amount_sec');
        //$data['calories_burned']=$this->getRequest()->getPost('calories_burned');
        $data['distance']=$this->getRequest()->getPost('distance');
        $data['set_no']=$this->getRequest()->getPost('number_of_sets');
        $data['set_weight']=$this->getRequest()->getPost('weight_per_set');
        $data['met_value']=$this->getRequest()->getPost('met_value');
        //$data['description']="";
        $data['status_id']=1;
        $data['created_by']=1;
        if ($data['id']=="") {
            $data['guid']=md5(uniqid(rand(), true));
            $exerciseId=$this->getExerciseTable()->insert($data);
            $this->flashMessenger()->addMessage('New Exercise has been added');
        } else {
            $exerciseId=$this->getRequest()->getPost('exerciseId');
            $this->getExerciseTable()->update($data);
            $this->getExerciseTable()->deleteExerciseDet($exerciseId);
            $this->flashMessenger()->addMessage('Exercise has been updated');
        }
        foreach ($option as $key => $value) {
            $exerciseDetailsData['exercise_id']=$exerciseId;
            $exerciseOption=$this->getExerciseTable()->getOptionId($key, $data['exercise_type_id']);
            $exerciseDetailsData['exercise_type_option_id']=$exerciseOption['id'];
            $exerciseDetailsData['value']=$value;
            if ($exerciseOption['id']!="") {
                $this->getExerciseTable()->insertexerciseDetails($exerciseDetailsData);
            }
        }
        $exerciseData = $this->getExerciseTable()->getAllExercise();
        $json = new JsonModel($exerciseData);
        return $json;
        //return $this->redirect()->toRoute('exercise');
        //$variables = array( 'Message' => 'Exercise has been added' );
        //$json = new JsonModel($variables);
        //return $json;
    }
    public function removeExerciseAction()
    {
        $exerciseId= $this->getRequest()->getPost('exerciseId');
        $data['id']=$exerciseId;
        $data['status_id']=4;
        $deleteRet=$this->getExerciseTable()->deleteExercise($data);
        $deletMsg=array();
        if ($deleteRet==1) {
            $deletMsg['msg']="Sucess";
        } else {
            $deletMsg['msg']="False";
        }
        $json = new JsonModel($deletMsg);
        return $json;
    }
    public function getExerciseByIdAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $exerciseId= $this->getRequest()->getPost('exerciseId');
        $exercise['master']=$this->getExerciseTable()->getExerciseById($exerciseId);
        $exercise['details']=$this->getExerciseTable()->getExerciseDetailsById($exerciseId);
        $json = new JsonModel($exercise);
        return $json;
    }
    public function updateStatusFromExcelAction()
    {
        //error_reporting(E_ALL);
        //ini_set('display_errors', 1);
        include 'public/excel_reader/excel_reader.php';
        $excel = new \PhpExcelReader;
        $excel->read('public/excel_reader/exercise_fym.xls');
        $nr_sheets = count($excel->sheets);
        $x = 2;
        while ($x <= $excel->sheets[0]['numRows']) {
            $guid= $excel->sheets[0]['cells'][$x][2];
            $id= $excel->sheets[0]['cells'][$x][1];
            if ($id!="") {
                $count=$this->getExerciseTable()->exerciseCheckUsingGuid($guid, $id);
                if ($count['count']!=0) {
                    /*if ($excel->sheets[0]['cells'][$x][5]=="REMOVE") {
                        $datadelete['id']=$id;
                        $datadelete['status_id']=4;
                        $this->getExerciseTable()->deleteExercise($datadelete);
                    } else if ($excel->sheets[0]['cells'][$x][5]=="1,2" || $excel->sheets[0]['cells'][$x][5]=="1") {
                        $data['id']=$id;
                        $data['exercise_type_id']=1;
                        $this->getExerciseTable()->update($data);
                    } else if ($excel->sheets[0]['cells'][$x][5]=="2") {
                        $data['id']=$id;
                        $data['exercise_type_id']=2;
                        $this->getExerciseTable()->update($data);
                    }*/
                    if ($excel->sheets[0]['cells'][$x][5]=="1,2") {
                        $exerciseCopy=$this->getExerciseTable()->getExerciseCopyById($id);
                        unset($exerciseCopy['id']);
                        $exerciseCopy['guid']=md5(uniqid(rand(), true));
                        $exerciseCopy['exercise_type_id']=2;
                        $exerciseId_new=$this->getExerciseTable()->insert($exerciseCopy);
                        for ($i=4; $i<=8; $i++) {
                            $exerciseDet['exercise_id']=$exerciseId_new;
                            $exerciseDet['exercise_type_option_id']=$i;
                            //$this->getExerciseTable()->insertexerciseDetails($exerciseDet);
                        }
                    }
                }
            }
              
            $x++;
        }
        echo "updated" ;
        exit;

    }
    protected function getViewHelper($helperName)
    {
        return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
    }
}
