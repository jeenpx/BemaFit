<?php
namespace Exercise\Model;

class ExerciseType
{
    public $id;
    public $name;
    public $status_id;


   

    public function exchangeArray($data)
    {
        $this->id    = (isset($data['id'])) ? $data['id'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
        $this->status_id = (isset($data['status_id'])) ? $data['status_id'] : null;
    }
}
