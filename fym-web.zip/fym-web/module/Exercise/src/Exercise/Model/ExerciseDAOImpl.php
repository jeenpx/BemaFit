<?php
namespace Exercise\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Predicate\Expression;

class ExerciseDAOImpl
{
    protected $tableGateway;
    protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
        $this->select = new Select();

    }
    public function getAllExercise()
    {
/*        $select = $this->tableGateway->getSql()->select();
        $select->columns(array(new Expression("CONVERT(CAST(CONVERT(name_es USING utf8 ) AS BINARY) USING latin1) as name_es"), 'name','id','description','status_id'));
        $select->join('exercise_type', 'exercise_type.id = exercise.exercise_type_id', array('exercisetypename'=>'name'));
        $select->join('language', 'language.id = exercise.language_id', array('languagename'=>'.name'));
        $select->where('exercise.status_id != 4');
        $select->order('id DESC');
        $resultSet = $this->tableGateway->selectWith($select);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();*/
        $sql = "SELECT exercise.name,exercise.id,exercise.description,exercise.status_id,exercise_type.name as exercisetypename ,language.name as languagename,
                         IF( LENGTH( exercise.name ) >0, exercise.name,  CONVERT( CAST( CONVERT( exercise.name_es  USING utf8 ) AS   BINARY )  USING latin1 ) ) AS name
                FROM exercise  
                inner join exercise_type on exercise_type.id = exercise.exercise_type_id
                inner join language on language.id = exercise.language_id 
                WHERE exercise.status_id != 4 order by  exercise.id desc " ;
        $result = $this->tableGateway->getAdapter()->driver->getConnection()->execute($sql);
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function insert($data)
    {
        try {
            $this->tableGateway->insert($data);
            $id = $this->tableGateway->lastInsertValue;
            return $id;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function update($data)
    {
        try {
            $this->tableGateway->update($data, array('id' => $data['id']));
            return 1;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function deleteExercise($data)
    {
        try {
            $this->tableGateway->update($data, array('id' => $data['id']));
            return 1;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function getExerciseById($id)
    {
        $select = $this->tableGateway->getSql()->select();
        $select->columns(array(new Expression("CONVERT(CAST(CONVERT(exercise.name_es USING utf8 ) AS BINARY) USING latin1) as name_es"), 'name','id','description','status_id','amount_hour','amount_min','amount_sec','calories_burned','distance','set_no','set_weight','met_value','language_id','exercise_type_id'));
        $select->where(array('exercise.id' => $id));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getOptionId($key, $exerciseType)
    {
        $adapter = $this->tableGateway->getAdapter();
        $exerciseTypeOption = new TableGateway('exercise_type_option', $adapter);
        $select = $exerciseTypeOption->getSql()->select();
        $select->where(array('exercise_type_option.option' => $key));
        $select->where(array('exercise_type_option.exercise_type_id' => $exerciseType));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function insertexerciseDetails($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $exerciseDet = new TableGateway('exercise_details', $adapter);
         $exerciseDet->insert($data);
    }
    public function deleteExerciseDet($id)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
              $exerciseDet = new TableGateway('exercise_details', $adapter);
             return $exerciseDet->delete(array('exercise_id' => $id));
        } catch (\Exception $e) {
             return 0;
        }
    }
    public function getExerciseDetailsById($exerciseId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $exerciseDet = new TableGateway('exercise_details', $adapter);
        $select = $exerciseDet->getSql()->select();
        $select->join('exercise_type_option', 'exercise_type_option.id = exercise_details.exercise_type_option_id', array('option'=>'option'), "LEFT");
        $select->where(array('exercise_id' => $exerciseId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function exerciseCheckUsingGuid($guid, $id)
    {
        $sql = "SELECT count( id ) as count
                FROM `exercise`
                WHERE `guid` = '$guid' AND id=$id" ;
        $result = $this->tableGateway->getAdapter()->driver->getConnection()->execute($sql);
        return $result->current();
    }
    public function getExerciseCopyById($id)
    {
        $select = $this->tableGateway->getSql()->select();
        $select->where(array('exercise.id' => $id));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
}
