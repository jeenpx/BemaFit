<?php
namespace Exercise;

use Exercise\Model\Exercise;
use Exercise\Model\ExerciseDAOImpl;
use Exercise\Model\ExerciseType;
use Exercise\Model\ExerciseTypeDAOImpl;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;

class Module
{
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'Exercise\Model\ExerciseDAOImpl' =>  function ($sm) {
                    $tableGateway = $sm->get('ExerciseDAOImplGateway');
                    $table = new ExerciseDAOImpl($tableGateway);
                    return $table;
                },
                'ExerciseDAOImplGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Exercise());
                    return new TableGateway('exercise', $dbAdapter, null, $resultSetPrototype);
                },
                'Exercise\Model\ExerciseTypeDAOImpl' =>  function ($sm) {
                    $tableGateway = $sm->get('ExerciseTypeDAOImplGateway');
                    $table = new ExerciseTypeDAOImpl($tableGateway);
                    return $table;
                },
                'ExerciseTypeDAOImplGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new ExerciseType());
                    return new TableGateway('exercise_type', $dbAdapter, null, $resultSetPrototype);
                },
            ),
        );
    }
}
