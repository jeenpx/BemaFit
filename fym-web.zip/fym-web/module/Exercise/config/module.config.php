<?php
return array(
    'router' => array(
        'routes' => array(
            'exercise' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/exercise',
                    'defaults' => array(
                        'controller' => 'exercise',
                        'action'     => 'index',
                    ),
                )
            ),
            'postexercise' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/postexercise',
                    'defaults' => array(
                        'controller' => 'exercise',
                        'action'     => 'postAddExercise',
                    ),
                )
            ),
            'removeExercise' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/removeExercise',
                    'defaults' => array(
                        'controller' => 'exercise',
                        'action'     => 'removeExercise',
                    ),
                )
            ),
            'getExerciseById' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/getExerciseById',
                    'defaults' => array(
                        'controller' => 'exercise',
                        'action'     => 'getExerciseById',
                    ),
                )
            ),
            'updateStatusFromExcel' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/updateStatusFromExcel',
                    'defaults' => array(
                        'controller' => 'exercise',
                        'action'     => 'updateStatusFromExcel',
                    ),
                )
            )

        ),
    ),
    'controllers' => array(
        'invokables' => array(
            'exercise' => 'Exercise\Controller\ExerciseController',
        ),
    ),
    'view_manager' => array(
        'template_map' => array(
            'exercise/exercise/index' => __DIR__ . '/../view/exercise/exercise/index.phtml',
            'addexercise' => __DIR__ . '/../view/exercise/exercise/addexercise.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
