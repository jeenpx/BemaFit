<?php

namespace ZfcUser\Exception;

class AuthenticationEventException extends DomainException
{
}
