<?php

namespace ZfcUser\Mapper\Exception;

use ZfcBase\Mapper\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{
}
