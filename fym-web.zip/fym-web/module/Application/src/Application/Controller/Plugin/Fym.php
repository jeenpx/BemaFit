<?php
namespace Application\Controller\Plugin;

use Zend\Mvc\Controller\Plugin\AbstractPlugin;
use Zend\Http\PhpEnvironment\Request;
use ZendMail;
use Zend\Mail;
use Zend\Mime\Part as MimePart;
use Zend\Mime\Message as MimeMessage;
use Zend\Validator\File\Size;
use Zend\Validator\File\Extension;
use Aws\S3\S3Client;
use Aws\Ses\SesClient;

class Fym extends AbstractPlugin
{
    public function uploadImage($type, $File, $settings, $aws_settings, $adUploadType = 1)
    {
        $uploadFolder=$this->uniqueID();
/*        if ($type=="mealImage") {
            $baseImageUploadFolder="MealImages";
        } else if ($type=="businessImage") {
            $baseImageUploadFolder="BusinessImages";
        } else {
            $baseImageUploadFolder="AdImages";
        }*/
        //mkdir(getcwd().'/public/'.$baseImageUploadFolder.'/'.$uploadFolder, 0777, true);
        //chmod(getcwd().'/public/'.$baseImageUploadFolder.'/'.$uploadFolder, 0777);
        $adapter = new \Zend\File\Transfer\Adapter\Http();
        $size = new Size(array('max'=>1000000));
        $extension = new Extension(array('jpg', 'jpeg','png','JPG', 'JPEG','PNG','gif','GIF'), true);
        if ($type=="mealImage") {
            $imageWidthHeight = new \Zend\Validator\File\ImageSize(array(
                'minWidth' => 100, 'minHeight' => 100,
                //'maxWidth' => 700, 'maxHeight' => 700,
            ));
            $adapter->setValidators(array($size,$extension,$imageWidthHeight), $File['name']);

        } else {
            $adapter->setValidators(array($size,$extension), $File['name']);
        }
        $fileType=explode('/', $File['type']);
        $uploadDet=array();
        if (!$adapter->isValid()) {
            $dataError = $adapter->getMessages();
            if ($File['name']!="") {
                foreach ($dataError as $key => $row) {
                        $uploadDet['message']=$row;
                }
            } else {
                $uploadDet['message']="";
            }
            $uploadDet['sucess']=false;
        } else {
            $adapter->addFilter(
                new \Zend\Filter\File\Rename(
                    array(
                    'target' =>  $uploadFolder.".".$fileType[1],
                    'overwrite' => false)
                )
            );
            $adapter->setDestination(getcwd().'/'.$settings['server_upload_path']);
            $adapter->receive($File['name']);
            $data= new \stdClass();
            $data->image_name=$uploadFolder.".".$fileType[1];
            if (!empty($data->image_name)) {
                //$config = $this->getServiceLocator()->get('Config');
                $file_upload_settings = $settings;

                $s3_upload_status = true;
                $s3_client = S3Client::factory($aws_settings);
                try {
                    $result = $s3_client->putObject(array(
                        'Bucket'     => $file_upload_settings['bucket'],
                        'Key'        => $data->image_name,
                        'SourceFile' => $file_upload_settings['server_upload_path'].$data->image_name
                    ));

                    //Successfully uploaded to amason s3. Then resize image and upload these thumbs to s3
                    if (isset($result['ObjectURL'])) {
                        //$utilityObj = new \Application\Service\Utility();

                        foreach ($file_upload_settings['thumbs'] as $thumb) {
                            $key = key($thumb);
                            $resize_status = $this->smart_resize_image(
                                $file_upload_settings['server_upload_path'].$data->image_name,
                                $file_upload_settings['server_upload_path'].$data->image_name,
                                $thumb[$key]['width'],
                                $thumb[$key]['height'],
                                true,
                                $file_upload_settings['thumb_server_upload_path'].$data->image_name,
                                false,
                                false,
                                $quality = 100
                            );

                            //Resize successfull. Upload to amazon
                            if ($resize_status) {
                                try {
                                    $result = $s3_client->putObject(array(
                                        'Bucket'     => $thumb[$key]['bucket'],
                                        'Key'        => $data->image_name,
                                        'SourceFile' => $file_upload_settings['thumb_server_upload_path'].$data->image_name
                                    ));
                                } catch (\Exception $ex) {
                                    $s3_upload_status = false;
                                    //var_dump($ex->getMessage());
                                }
                            }
                        }

                        if (file_exists($file_upload_settings['server_upload_path'].$data->image_name)) {
                            if (is_file($file_upload_settings['server_upload_path'].$data->image_name)) {
                                unlink($file_upload_settings['server_upload_path'].$data->image_name);
                            }
                        }

                        if (file_exists($file_upload_settings['thumb_server_upload_path'].$data->image_name)) {
                            if (is_file($file_upload_settings['thumb_server_upload_path'].$data->image_name)) {
                                unlink($file_upload_settings['thumb_server_upload_path'].$data->image_name);
                            }
                        }
                        
                        if ($s3_upload_status) {
                             //var_dump($this->sizeInfo);exit;

                        }
                    }
                } catch (\Exception $ex) {
                    $s3_upload_status = false;
                }

        
            }
            $uploadDet['fileName']=$data->image_name;
            $uploadDet['fileName_resize']= "https://s3.amazonaws.com/".$settings['thumbs'][0]['resize']['bucket']."/".$data->image_name;
            $uploadDet['sucess']=true;
            
        }
        return $uploadDet;
        
    }
    public function uniqueID($limit = 10)
    {
        return  str_replace(
            '-',
            '',
            sprintf(
                '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                // 32 bits for "time_low"
                mt_rand(
                    0,
                    0xffff
                ),
                mt_rand(
                    0,
                    0xffff
                ),
                // 16 bits for "time_mid"
                mt_rand(0, 0xffff),
                // 16 bits for "time_hi_and_version",
                // four most significant bits holds version number 4
                mt_rand(0, 0x0fff) | 0x4000,
                // 16 bits, 8 bits for "clk_seq_hi_res",
                // 8 bits for "clk_seq_low",
                // two most significant bits holds zero and one for variant DCE1.1
                mt_rand(0, 0x3fff) | 0x8000,
                // 48 bits for "node"
                mt_rand(
                    0,
                    0xffff
                ),
                mt_rand(
                    0,
                    0xffff
                ),
                mt_rand(0, 0xffff)
            )
        );
    }
    // send email
    public function sendMail($htmlBody, $textBody, $subject, $from, $to)
    {
        define('AWS_SES', serialize(array(
        'key' => 'AKIAJXZA5BCZGVQOSRHA',
        'secret' => '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',
        'region' => 'us-west-2',
        )));

        $ses_client = SesClient::factory(unserialize(AWS_SES));
        //$user_message="testing AWS";
        //define('MAILER_FROM', $from);
        //$email="preejith.jp@gmail.com";
        try {
                    $result = $ses_client->sendEmail(array(
                    'Source' => $from,
                    'Destination' => array(
                        'ToAddresses' => array($to),
                    ),
                    'Message' => array(
                        'Subject' => array(
                            'Data' => $subject,
                            'Charset' => 'UTF-8',
                        ),
                        'Body' => array(

                            'Html' => array(
                                'Data' => $htmlBody,
                                'Charset' => 'UTF-8',
                            ),
                        ),
                    ),
                    'ReplyToAddresses' => array($from)
                    ));
                    //echo json_encode(array('status'=>true));
        } catch (\Exception $ex) {
                    //echo json_encode(array('status'=>false, 'code'=>'email', 'message'=>$ex->getMessage()));
                    //exit;
        }
        /*$htmlPart = new MimePart($htmlBody);
        $htmlPart->type = "text/html";
     
        $textPart = new MimePart($textBody);
        $textPart->type = "text/plain";
     
        $body = new MimeMessage();
        $body->setParts(array($textPart, $htmlPart));
     
        $message = new Mail\Message();
        $message->setFrom($from);
        $message->addTo($to);
        $message->setSubject($subject);
     
        $message->setEncoding("UTF-8");
        $message->setBody($body);
        $message->getHeaders()->get('content-type')->setType('multipart/alternative');
     
        $transport = new Mail\Transport\Sendmail();
        $transport->send($message);*/
    }
    public function resizeImage($imagePath, $width, $height, $filterType, $blur, $bestFit, $cropZoom)
    {
        //The blur factor where &gt; 1 is blurry, &lt; 1 is sharp.
        echo realpath($imagePath);
        exit;
        $imagick = new \Imagick(realpath($imagePath));
            //$thumb = new \Imagick();
            //exit;
        $imagick->resizeImage($width, $height, $filterType, $blur, $bestFit);

        $cropWidth = $imagick->getImageWidth();
        $cropHeight = $imagick->getImageHeight();

        if ($cropZoom) {
            $newWidth = $cropWidth / 2;
            $newHeight = $cropHeight / 2;

            $imagick->cropimage(
                $newWidth,
                $newHeight,
                ($cropWidth - $newWidth) / 2,
                ($cropHeight - $newHeight) / 2
            );

            $imagick->scaleimage(
                $imagick->getImageWidth() * 4,
                $imagick->getImageHeight() * 4
            );
        }


        header("Content-Type: image/jpg");
        echo $imagick->getImageBlob();
    }
    public function photoUpload($params = array())
    {

        $target_dir = $params['upload_dir'];
        $target_file = $target_dir . $params['image_name'];
        $uploadOk = 1;
        $imageFileType = pathinfo($_FILES["photo"]["name"], PATHINFO_EXTENSION);
        $status = false;
        $message = '';
        // Check if image file is a actual image or fake image
        if (isset($_POST["submit"])) {
            $check = getimagesize($_FILES["photo"]["tmp_name"]);
            if ($check !== false) {
                $message  =  "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                $message  =  "File is not an image.";
                $uploadOk = 0;
            }
        }
        // Check if file already exists
        if (file_exists($target_file)) {
            $message  =  "Sorry, file already exists.";
            $uploadOk = 0;
        }
        // Check file size
        if ($_FILES["photo"]["size"] > 5242880) {
            $message  =  "Sorry, your file is too large.";
            $uploadOk = 0;
        }
        $imageFileType = strtolower($imageFileType);
        // Allow certain file formats
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            $message  =  "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            //$message  =  "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file.'.'.$imageFileType)) {
                return array('status'=>true, 'file_name'=>$params['image_name'].'.'.$imageFileType);
            } else {
                $message  =  "Sorry, there was an error uploading your file.";
            }
        }
        return array('status'=>$status, 'message'=>$message);
    }
    /**
     * easy image resize function
     * @param  $file - file name to resize
     * @param  $string - The image data, as a string
     * @param  $width - new image width
     * @param  $height - new image height
     * @param  $proportional - keep image proportional, default is no
     * @param  $output - name of the new file (include path if needed)
     * @param  $delete_original - if true the original image will be deleted
     * @param  $use_linux_commands - if set to true will use "rm" to delete the image, if false will use PHP unlink
     * @param  $quality - enter 1-100 (100 is best quality) default is 100
     * @return boolean|resource
     */
    public function smart_resize_image($file,
                                      $string             = null,
                                      $width              = 0,
                                      $height             = 0,
                                      $proportional       = false,
                                      $output             = 'file',
                                      $delete_original    = true,
                                       $use_linux_commands = false,
                                      $quality = 100
                 ) {
              
                if ( $height <= 0 && $width <= 0 ) return false;
                if ( $file === null && $string === null ) return false;

                # Setting defaults and meta
                $info                         = $file !== null ? getimagesize($file) : getimagesizefromstring($string);
                $image                        = '';
                $final_width                  = 0;
                $final_height                 = 0;
                list($width_old, $height_old) = $info;
                $cropHeight = $cropWidth = 0;

                # Calculating proportionality
                if ($proportional) {
                  if      ($width  == 0)  $factor = $height/$height_old;
                  elseif  ($height == 0)  $factor = $width/$width_old;
                  else                    $factor = min( $width / $width_old, $height / $height_old );

                  $final_width  = round( $width_old * $factor );
                  $final_height = round( $height_old * $factor );
                }
                else {
                  $final_width = ( $width <= 0 ) ? $width_old : $width;
                  $final_height = ( $height <= 0 ) ? $height_old : $height;
                  $widthX = $width_old / $width;
                  $heightX = $height_old / $height;
                  
                  $x = min($widthX, $heightX);
                  $cropWidth = ($width_old - $width * $x) / 2;
                  $cropHeight = ($height_old - $height * $x) / 2;
                }

                # Loading image to memory according to type
                switch ( $info[2] ) {
                  case IMAGETYPE_JPEG:  $file !== null ? $image = imagecreatefromjpeg($file) : $image = imagecreatefromstring($string);  break;
                  case IMAGETYPE_GIF:   $file !== null ? $image = imagecreatefromgif($file)  : $image = imagecreatefromstring($string);  break;
                  case IMAGETYPE_PNG:   $file !== null ? $image = imagecreatefrompng($file)  : $image = imagecreatefromstring($string);  break;
                  default: return false;
                }
                
                
                # This is the resizing/resampling/transparency-preserving magic
                $image_resized = imagecreatetruecolor( $final_width, $final_height );
                if ( ($info[2] == IMAGETYPE_GIF) || ($info[2] == IMAGETYPE_PNG) ) {
                  $transparency = imagecolortransparent($image);
                  $palletsize = imagecolorstotal($image);

                  if ($transparency >= 0 && $transparency < $palletsize) {
                    $transparent_color  = imagecolorsforindex($image, $transparency);
                    $transparency       = imagecolorallocate($image_resized, $transparent_color['red'], $transparent_color['green'], $transparent_color['blue']);
                    imagefill($image_resized, 0, 0, $transparency);
                    imagecolortransparent($image_resized, $transparency);
                  }
                  elseif ($info[2] == IMAGETYPE_PNG) {
                    imagealphablending($image_resized, false);
                    $color = imagecolorallocatealpha($image_resized, 0, 0, 0, 127);
                    imagefill($image_resized, 0, 0, $color);
                    imagesavealpha($image_resized, true);
                  }
                }
                imagecopyresampled($image_resized, $image, 0, 0, $cropWidth, $cropHeight, $final_width, $final_height, $width_old - 2 * $cropWidth, $height_old - 2 * $cropHeight);
                
                
                # Taking care of original, if needed
                if ( $delete_original ) {
                  if ( $use_linux_commands ) exec('rm '.$file);
                  else @unlink($file);
                }

                # Preparing a method of providing result
                switch ( strtolower($output) ) {
                  case 'browser':
                    $mime = image_type_to_mime_type($info[2]);
                    header("Content-type: $mime");
                    $output = NULL;
                  break;
                  case 'file':
                    $output = $file;
                  break;
                  case 'return':
                    return $image_resized;
                  break;
                  default:
                  break;
                }
                
                # Writing image according to type to the output destination and image quality
                switch ( $info[2] ) {
                  case IMAGETYPE_GIF:   imagegif($image_resized, $output);    break;
                  case IMAGETYPE_JPEG:  imagejpeg($image_resized, $output, $quality);   break;
                  case IMAGETYPE_PNG:
                    $quality = 9 - (int)((0.9*$quality)/10.0);
                    imagepng($image_resized, $output, $quality);
                    break;
                  default: return false;
                }

                return true;
        }
}
