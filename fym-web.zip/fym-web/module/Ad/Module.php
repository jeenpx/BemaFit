<?php
namespace Ad;

use Ad\Model\AdLocationMaster;
use Ad\Model\AdLocationMasterDAOImpl;
use Ad\Model\Ad;
use Ad\Model\AdDAOImpl;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;

class Module
{
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'Ad\Model\AdLocationMasterDAOImpl' =>  function ($sm) {
                    $tableGateway = $sm->get('AdLocationMasterDAOImplGateway');
                    $table = new AdLocationMasterDAOImpl($tableGateway);
                    return $table;
                },
                'AdLocationMasterDAOImplGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new AdLocationMaster());
                    return new TableGateway('ad_location_master', $dbAdapter, null, $resultSetPrototype);
                },
                'Ad\Model\AdDAOImpl' =>  function ($sm) {
                    $tableGateway = $sm->get('AdDAOImplGateway');
                    $table = new AdDAOImpl($tableGateway);
                    return $table;
                },
                'AdDAOImplGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Ad());
                    return new TableGateway('ad', $dbAdapter, null, $resultSetPrototype);
                }
            ),
        );
    }
}
