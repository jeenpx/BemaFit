<?php
return array(
    'router' => array(
        'routes' => array(
            'ad' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/ad',
                    'defaults' => array(
                        'controller' => 'ad',
                        'action'     => 'index',
                    ),
                )
            ),
            'postad' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/postad',
                    'defaults' => array(
                        'controller' => 'ad',
                        'action'     => 'postAd',
                    ),
                )
            ),
            'getAdById' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/getAdById',
                    'defaults' => array(
                        'controller' => 'ad',
                        'action'     => 'getAdById',
                    ),
                )
            ),
            'adImageSubmit' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/adImageSubmit',
                    'defaults' => array(
                        'controller' => 'ad',
                        'action'     => 'adImageSubmit',
                    ),
                )
            ),
            'removeAd' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/removeAd',
                    'defaults' => array(
                        'controller' => 'ad',
                        'action'     => 'removeAd',
                    ),
                )
            ),
            'copyAd' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/copyAd',
                    'defaults' => array(
                        'controller' => 'ad',
                        'action'     => 'copyAd',
                    ),
                )
            ),
            'radiusSelect' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/radiusSelect',
                    'defaults' => array(
                        'controller' => 'ad',
                        'action'     => 'radiusSelect',
                    ),
                )
            ),
            'getAdRadiusById' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/getAdRadiusById',
                    'defaults' => array(
                        'controller' => 'ad',
                        'action'     => 'getAdRadiusById',
                    ),
                )
            ),
            'testImageUpload' => array(
                'type' => 'Segment',
                'options' => array(
                    'route'    => '/testImageUpload',
                    'defaults' => array(
                        'controller' => 'ad',
                        'action'     => 'testImageUpload',
                    ),
                )
            )



        ),
    ),
    'controllers' => array(
        'invokables' => array(
            'ad' => 'Ad\Controller\AdController',
        ),
    ),
    'controller_plugins' => array(
        'invokables' => array(
            'fym' => 'Application\Controller\Plugin\Fym',
        )
    ),
    'view_manager' => array(
        'template_map' => array(
            'ad/ad/index' => __DIR__ . '/../view/ad/ad/index.phtml',
            'addad' => __DIR__ . '/../view/ad/ad/addad.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
