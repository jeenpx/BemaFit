<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Ad\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;
use Aws\S3\S3Client;
use Aws\DynamoDb\DynamoDbClient;

class AdController extends AbstractActionController
{

    const ROUTE_LOGIN        = 'zfcuser/login';
    public function getAdLocationMasterTable()
    {
        if (!isset($this->adLocationMasterTable) || !$this->adLocationMasterTable) {
            $sm = $this->getServiceLocator();
            $this->adLocationMasterTable = $sm->get('Ad\Model\AdLocationMasterDAOImpl');
        }
        return $this->adLocationMasterTable;
    }
    public function getAdTable()
    {
        if (!isset($this->adTable) || !$this->adTable) {
            $sm = $this->getServiceLocator();
            $this->adTable = $sm->get('Ad\Model\AdDAOImpl');
        }
        return $this->adTable;
    }
    public function indexAction()
    {
        $adLocationMasterData =$this->getAdLocationMasterTable()->getAdLocationMaster();
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $this->getViewHelper('HeadScript')->prependFile('/js/fymAds.admin.js');
        $this->getViewHelper('inlineScript')->prependFile('/js/ko.ad.admin.js');
        $adData = $this->getAdTable()->getAds();
        return new ViewModel(array('adLocationMasters' =>$adLocationMasterData,'adData' =>json_encode($adData),'flashMessages' => $this->flashMessenger()->getMessages()));
    }
    public function postAdAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $radiusValues=$this->getRequest()->getPost('radiusValues');
        $radiusArray=explode(",", $radiusValues);
        $data['id']=$this->getRequest()->getPost('adId');
        $data['ad_type_id']=$this->getRequest()->getPost('location');
        if ($data['ad_type_id']==3) {
            $data['content']=$this->getRequest()->getPost('content');
        } else {
            $data['content']=$this->getRequest()->getPost('url');
        }
        //$data['url']=$this->getRequest()->getPost('url');
        $data['business_name']=$this->getRequest()->getPost('business_name');
        if ($this->getRequest()->getPost('ad_dt_from') != "") {
            $time_from = \DateTime::createFromFormat('m-d-Y', $this->getRequest()->getPost('ad_dt_from'));
            $data['time_from']= $time_from->format('Y-m-d');
        } else {
            $data['time_from']="";
        }
        if ($this->getRequest()->getPost('ad_dt_to') != "") {
            $time_to=\DateTime::createFromFormat('m-d-Y', $this->getRequest()->getPost('ad_dt_to'));
            $data['time_to']=$time_to->format('Y-m-d');
        } else {
            $data['time_to']="";
        }
        $adImage=$this->getRequest()->getPost('adImageLocation');
        $adImageResizeLocation=$this->getRequest()->getPost('adImageResizeLocation');
        $data['all_radius']=($this->getRequest()->getPost('all_radius')!="")?$this->getRequest()->getPost('all_radius'):0;
        $dataAdImage['file']=$adImage;
        $dataAdImage['file_resize']=$adImageResizeLocation;
        $dataAdImage['status_id']=1;
        if ($data['id']=="") {
            $data['guid']=md5(uniqid(rand(), true));
            $adId=$this->getAdTable()->insert($data);
            if ($data['ad_type_id']==3) {
/*                $dataFeed['user_id']=1;
                $dataFeed['guid']=md5(uniqid(rand(), true));
                $dataFeed['status_id']=1;
                $dataFeed['created_date']=gmdate('Y-m-d H:i:s');
                $dataFeed['updated_date']=gmdate('Y-m-d H:i:s');
                $feedId=$this->getAdTable()->insertFeed($dataFeed);
                $feedData['user_id']=1;
                $feedData['feed_id']=$feedId;
                $feedData['object_id']=$adId;
                $feedData['status_id']=1;
                $feedData['feed_type_id']=6;
                $feedData['parent_id']=0;
                $feedData['created_date']=gmdate('Y-m-d H:i:s');
                $feedData['updated_date']=gmdate('Y-m-d H:i:s');
                $feedId=$this->getAdTable()->insertFeedData($feedData);*/
                $amazon_dynamo= array(
                'key' => 'AKIAIUM2TKXQ5KLQORTA',
                'secret' => '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',
                'region' => 'us-west-2',
                'endpoint' => 'https://dynamodb.us-west-2.amazonaws.com');
                $dynamodbClient = DynamoDbClient::factory($amazon_dynamo);

                try {
                    $item = array(
                        'date' => array('S' => gmdate('Y-m-d') ),
                        'created_date'=>array('N' => time(gmdate('Y-m-d H:i:s'))),
                        'feed_guid'      => array('S' =>md5(uniqid(rand(), true))),
                        'user_id'    => array('S' => "1"),
                        'feed_type_id'=>array('N' => 6),
                        'status_id'=>array('N' => 1),
                        'like_count'=>array('N' => 0),
                        'inspire_count'=>array('N' => 0),
                        'comment_count'=>array('N' => 0),
                            
                    );
                    
                    $item['object_id'] = array('N' => ($adId));
                   
                    $result = $dynamodbClient->putItem(array(
                        'TableName' => 'feed',
                        'Item' => $item
                    ));
                } catch (\Exception $ex) {
                    //echo 'first insert -> '.$ex->getMessage();
                }

            }
            $dataAdImage['ad_id']=$adId;
            $this->getAdTable()->insertAdImage($dataAdImage);
            $dataAdLocation['ad_id']=$adId;
            $dataAdLocation['ad_location_master_id']=$this->getRequest()->getPost('location');
            $this->getAdTable()->insertAdLocation($dataAdLocation);
            foreach ($radiusArray as $radiusValues) {
                if ($radiusValues!="") {
                    if (is_numeric($radiusValues)) {
                         $postalValues=$this->getAdTable()->getPostalId($radiusValues);
                         $radiusValues=$postalValues['id'];
                         $radiusType="Zipcode";
                    } else {
                         $stateValues=$this->getAdTable()->getStateId($radiusValues);
                         $radiusValues=$stateValues['id'];
                         $radiusType="State";
                    }
                    $radius['ad_id'] = $adId;
                    $radius['radius_value'] = $radiusValues;
                    $radius['radius_type'] = $radiusType;
                    $this->getAdTable()->insertAdRadius($radius);
                }
            }
        } else {
            $this->getAdTable()->update($data);
            $dataAdImage['ad_id']=$this->getRequest()->getPost('adId');
            $this->getAdTable()->deleteAdImage($data['id']);
            $this->getAdTable()->deleteRadius($data['id']);
            $this->getAdTable()->deleteAdLocation($data['id']);
            $this->getAdTable()->insertAdImage($dataAdImage);
            $dataAdLocation['ad_id']=$this->getRequest()->getPost('adId');
            $dataAdLocation['ad_location_master_id']=$this->getRequest()->getPost('location');
            $this->getAdTable()->insertAdLocation($dataAdLocation);
            foreach ($radiusArray as $radiusValues) {
                if ($radiusValues!="") {
                    if (is_numeric($radiusValues)) {
                         $postalValues=$this->getAdTable()->getPostalId($radiusValues);
                         $radiusValues=$postalValues['id'];
                         $radiusType="Zipcode";
                    } else {
                         $stateValues=$this->getAdTable()->getStateId(ltrim($radiusValues));
                         $radiusValues=$stateValues['id'];
                         $radiusType="State";
                    }
                    $radius['ad_id'] = $data['id'];
                    $radius['radius_value'] = $radiusValues;
                    $radius['radius_type'] = $radiusType;
                    $this->getAdTable()->insertAdRadius($radius);
                }
            }
        }
        $this->flashMessenger()->addMessage('New Ad has been added');
        $adData = $this->getAdTable()->getAds();
        $json = new JsonModel($adData);
        return $json;
    }
    public function getAdByIdAction()
    {
        if (!$this->zfcUserAuthentication()->hasIdentity()) {
            return $this->redirect()->toRoute(static::ROUTE_LOGIN);
        }
        $adId= $this->getRequest()->getPost('adId');
        $adDetails=$this->getAdTable()->getAdById($adId);
        $json = new JsonModel($adDetails);
        return $json;
    }
    public function adImageSubmitAction()
    {
        $fymCommon = $this->fym();
        $File    = $this->params()->fromFiles('photo');
        $adUploadType=$this->getRequest()->getPost('adUploadType');
        $config = $this->getServiceLocator()->get('Config');
        if ($adUploadType==1) {
            $settings=$config['ad_photo_Settings_sidebar'];
        } elseif ($adUploadType==2) {
            $settings=$config['ad_photo_Settings_newsfeed'];
        } elseif ($adUploadType==3) {
            $settings=$config['ad_photo_Settings_guestpost'];
        } else {
            $settings=$config['ad_photo_Settings_sidebar'];
        }
        $uploadDet=$fymCommon->uploadImage("adImage", $File, $settings, $config['amazon_s3'], $adUploadType);
        $json = new JsonModel($uploadDet);
        return $json;

    }
    public function removeAdAction()
    {
        $adId= $this->getRequest()->getPost('adId');
        $data['id']=$adId;
        $data['status_id']=4;
        $deleteRet=$this->getAdTable()->deleteAd($data);
        $deletMsg=array();
        if ($deleteRet==1) {
            $deletMsg['msg']="Sucess";
        } else {
            $deletMsg['msg']="False";
        }
        $json = new JsonModel($deletMsg);
        return $json;
    }
    public function copyAdAction()
    {
        $adId= $this->getRequest()->getPost('adId');
        $adDetails=$this->getAdTable()->getAdForCopy($adId);
        unset($adDetails[id]);
        $adId_new=$this->getAdTable()->insert($adDetails);
        $adImageDetails=$this->getAdTable()->getAdImageForCopy($adId);
        unset($adImageDetails[id]);
        $adImageDetails['ad_id']=$adId_new;
        $adImageId_new=$this->getAdTable()->insertAdImage($adImageDetails);
        $dataAdLocation['ad_id']=$adId_new;
        $dataAdLocation['ad_location_master_id']=$adDetails['ad_type_id'];
        $this->getAdTable()->insertAdLocation($dataAdLocation);
        $businessCategoryDetails=$this->getAdTable()->getAdRadiusForCopy($adId);
        foreach ($businessCategoryDetails as $newBusinessCategoryDetails) {
            unset($newBusinessCategoryDetails[id]);
            $newBusinessCategoryDetails['ad_id']=$adId_new;
            $businessCategoryId_new=$this->getAdTable()->insertAdRadius($newBusinessCategoryDetails);
        }
        $adCopyDet=$this->getAdTable()->getAdCopyById($adId_new);
        $json = new JsonModel($adCopyDet);
        return $json;
    }
    public function radiusSelectAction()
    {
        $searchValue= $this->getRequest()->getPost('searchValue');
        $num_length = strlen((string)$searchValue);

        $state=array();
        if (is_numeric($searchValue) && ($num_length >= 4)) {
            $state=$this->getAdTable()->getAllPostalCode($searchValue);

        } else {
            $state=$this->getAdTable()->getAllStates($searchValue);
        }

        $json = new JsonModel($state);
        return $json;
    }
    public function getAdRadiusByIdAction()
    {

        $adId= $this->getRequest()->getPost('adId');
        $adRadiusData = $this->getAdTable()->getRadius($adId);
        $json = new JsonModel($adRadiusData);
        return $json;

    }
    public function testImageUploadAction()
    {
        $user_photo_Settings = array('bucket'=>'fymmeal',
                                  'server_upload_path' =>'public/uploads/meal/',
                                  'thumb_server_upload_path' =>'public/uploads/mealthumbs/',
                                   'thumbs'=> array(
                                           array('meal700' => array('bucket'=>'fymmealthumbs/meal700',
                                                                    'width'=>700)
                                           ),
                                           /*array('profile300' => array('bucket'=>'fymprofilethumbs/profile300',
                                                                    'width'=>300)
                                           )*/
                                       )
                                   );

        $image_name = md5(uniqid(rand(), true));
        // $file_upload_status = $utilityObj->photoUpload(array('upload_dir'=>$user_photo_Settings['server_upload_path'], 'image_name'=>$image_name));
        $config = $this->getServiceLocator()->get('Config');
        $s3_client = S3Client::factory($config['amazon_s3']);
        try {
               $result = $s3_client->putObject(array(
                   'Bucket'     => $user_photo_Settings['bucket'],
                   'Key'        => $image_name,
                   'SourceFile' => '/home/preejith/Downloads/image1.jpg'
               ));
               var_dump($result);
        } catch (\Exception $ex) {
            var_dump($ex->getMessage());
        }

        echo "testImage";
        exit;

    }
    protected function getViewHelper($helperName)
    {
        return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
    }
}
