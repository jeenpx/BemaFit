<?php
namespace Ad\Model;

class Ad
{
    public $id;
    public $guid;
    public $ad_type_id;
    public $content;
    public $time_from;
    public $time_to;
    public $business_name;
    public function exchangeArray($data)
    {
        $this->id    = (isset($data['id'])) ? $data['id'] : null;
        $this->guid = (isset($data['guid'])) ? $data['guid'] : null;
        $this->ad_type_id = (isset($data['ad_type_id'])) ? $data['ad_type_id'] : null;
        $this->content = (isset($data['content'])) ? $data['content'] : null;
        $this->time_from = (isset($data['time_from'])) ? $data['time_from'] : null;
        $this->time_to = (isset($data['time_to'])) ? $data['time_to'] : null;
        $this->business_name = (isset($data['business_name'])) ? $data['business_name'] : null;
    }
}
