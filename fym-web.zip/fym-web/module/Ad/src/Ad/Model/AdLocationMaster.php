<?php
namespace Ad\Model;

class AdLocationMaster
{
    public $id;
    public $type;
    public $name;
    public $description;
    public $exercise_type_id;
    public $status_id;
    public $created_by;
    public $created_date;
    public $updated_by;
    public $updated_date;

   

    public function exchangeArray($data)
    {
        $this->id    = (isset($data['id'])) ? $data['id'] : null;
        $this->type = (isset($data['type'])) ? $data['type'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
        $this->description = (isset($data['description'])) ? $data['description'] : null;
        $this->exercise_type_id = (isset($data['exercise_type_id'])) ? $data['exercise_type_id'] : null;
        $this->status_id = (isset($data['status_id'])) ? $data['status_id'] : null;
        $this->created_by = (isset($data['created_by'])) ? $data['created_by'] : null;
        $this->created_date = (isset($data['created_date'])) ? $data['created_date'] : null;
        $this->updated_by = (isset($data['updated_by'])) ? $data['updated_by'] : null;
    }
}
