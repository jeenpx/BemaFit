<?php
namespace Ad\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Predicate\Expression;

class AdDAOImpl
{
    protected $tableGateway;
    protected $select;
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
        $this->select = new Select();

    }
    public function insert($data)
    {
        try {
            $this->tableGateway->insert($data);
            $id = $this->tableGateway->lastInsertValue;
            return $id;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function insertFeed($data)
    {
        try {
            $adapter = $this->tableGateway->getAdapter();
            $feed = new TableGateway('feed', $adapter);
            $feed->insert($data);
            $id = $feed->lastInsertValue;
            return $id;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function insertFeedData($data)
    {
        try {
            $adapter = $this->tableGateway->getAdapter();
            $feedData = new TableGateway('feed_data', $adapter);
            $feedData->insert($data);
            $id = $feedData->lastInsertValue;
            return $id;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function insertAdImage($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $adImage = new TableGateway('ad_image', $adapter);
         $adImage->insert($data);
    }
    public function insertAdLocation($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $adImage = new TableGateway('ad_location', $adapter);
         $adImage->insert($data);
    }
    public function insertRadius($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $adRadius = new TableGateway('ad_radius', $adapter);
         $adRadius->insert($data);
    }
    public function updateAdImage($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $adImage = new TableGateway('ad_image', $adapter);
         $adImage->update($data, array('ad_id' => $data['ad_id']));
    }
    public function update($data)
    {
        try {
            $this->tableGateway->update($data, array('id' => $data['id']));
            return 1;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function getAdById($id)
    {
        // $select = $this->tableGateway->getSql()->select();
        // $select->join('ad_image', 'ad_image.ad_id = ad.id', array('file'=>'file'));
        // $select->join("ad_radius", "ad_radius.ad_id = ad.id", array("radius"=>new Expression("Group_Concat(ad_radius.radius_value)")), "LEFT");
        // $select->group('ad.id');
        // $select->where(array('ad.id' => $id));
        // $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        // $result = $statement->execute();
        $sql = "SELECT ad.id,ad.ad_type_id,ad.content,DATE_FORMAT(ad.time_from , '%m-%d-%Y') as time_from,DATE_FORMAT(ad.time_to , '%m-%d-%Y') as time_to ,ad.business_name,ad.all_radius,GROUP_CONCAT( concat_ws( ',', states.state_name, postal_code.code ) SEPARATOR ', ' ) AS radius,CONCAT(ad_location_master.type,':',ad_location_master.name) as name,ad_image.file,ad_image.file_resize
                FROM ad  
                left join ad_radius on ad.id=ad_radius.ad_id 
                left join ad_location_master on ad_location_master.id = ad.ad_type_id 
                left join ad_image on ad_image.ad_id = ad.id
                left join states on  ad_radius.radius_value = states.id and ad_radius.radius_type='State' 
                left join postal_code on  ad_radius.radius_value = postal_code.id and ad_radius.radius_type='Zipcode' WHERE ad.id = ".$id." GROUP BY ad.id " ;
        $result = $this->tableGateway->getAdapter()->driver->getConnection()->execute($sql);
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function getAds()
    {
/*        $select = $this->tableGateway->getSql()->select()->columns((array(
        '*', new Expression("DATE_FORMAT(time_from , '%m/%d/%Y') as timefrom") , new Expression("DATE_FORMAT(time_to , '%m/%d/%Y') as timeto")
        )));
        $select->join('ad_location_master', 'ad_location_master.id = ad.ad_type_id', array('name'=>new Expression("CONCAT(type,':',name)")));
        $select->join("ad_radius", "ad_radius.ad_id = ad.id", array("radius"=>new Expression("Group_Concat(ad_radius.radius_value)")), "LEFT");
        $select->group('ad.id');
        $select->where('ad.status_id != 4');
        $select->order('ad.id DESC');
        $resultSet = $this->tableGateway->selectWith($select);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();*/
        $sql = "SELECT ad.id,ad.ad_type_id,ad.content,DATE_FORMAT(ad.time_from , '%m/%d/%Y') as timefrom,DATE_FORMAT(ad.time_to , '%m/%d/%Y') as timeto,ad.business_name,ad.all_radius,GROUP_CONCAT( concat_ws( ',', states.state_name, postal_code.code ) SEPARATOR ', ' ) AS radius,CONCAT(ad_location_master.type,':',ad_location_master.name) as name
                FROM ad  
                left join ad_radius on ad.id=ad_radius.ad_id 
                left join ad_location_master on ad_location_master.id = ad.ad_type_id 
                left join states on  ad_radius.radius_value = states.id and ad_radius.radius_type='State' 
                left join postal_code on  ad_radius.radius_value = postal_code.id and ad_radius.radius_type='Zipcode'WHERE ad.status_id != 4 GROUP BY ad.id order by  ad.id desc ";
        $statement = $this->tableGateway->getAdapter()->driver->getConnection()->execute($sql);
        $resultSet = new ResultSet();
        $resultSet->initialize($statement);
        return $resultSet->toArray();
    }
    public function getAdCopyById($id)
    {
/*        $select = $this->tableGateway->getSql()->select()->columns((array(
        '*', new Expression("DATE_FORMAT(time_from , '%m/%d/%Y') as timefrom") , new Expression("DATE_FORMAT(time_to , '%m/%d/%Y') as timeto")
        )));
        $select->join('ad_location_master', 'ad_location_master.id = ad.ad_type_id', array('name'=>new Expression("CONCAT(type,':',name)")));
        $select->join("ad_radius", "ad_radius.ad_id = ad.id", array("radius"=>new Expression("Group_Concat(ad_radius.radius_value)")), "LEFT");
        $select->group('ad.id');
        $select->where(array('ad.id' => $id));
        $resultSet = $this->tableGateway->selectWith($select);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();*/
        $sql = "SELECT ad.id,ad.ad_type_id,ad.content,DATE_FORMAT(ad.time_from , '%m/%d/%Y') as timefrom,DATE_FORMAT(ad.time_to , '%m/%d/%Y') as timeto,ad.business_name,ad.all_radius,GROUP_CONCAT( concat_ws( ',', states.state_name, postal_code.code ) ) AS radius,CONCAT(ad_location_master.type,':',ad_location_master.name) as name
                FROM ad  
                left join ad_radius on ad.id=ad_radius.ad_id 
                left join ad_location_master on ad_location_master.id = ad.ad_type_id 
                left join states on  ad_radius.radius_value = states.id and ad_radius.radius_type='State' 
                left join postal_code on  ad_radius.radius_value = postal_code.id and ad_radius.radius_type='Zipcode' WHERE ad.id = ".$id." GROUP BY ad.id ";
        $result = $this->tableGateway->getAdapter()->driver->getConnection()->execute($sql);
        return $result->current();
    }
    public function deleteAd($data)
    {
        try {
            $this->tableGateway->update($data, array('id' => $data['id']));
            return 1;
        } catch (\Exception $e) {
            return 0;
        }
    }
    public function getAdForCopy($adId)
    {
        $select = $this->tableGateway->getSql()->select();
        $select->where(array('ad.id' => $adId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getAdImageForCopy($adId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $adImage = new TableGateway('ad_image', $adapter);
        $select = $adImage->getSql()->select();
        $select->where(array('ad_image.ad_id' => $adId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getAllStates($searchValue)
    {
        $adapter = $this->tableGateway->getAdapter();
        $state = new TableGateway('states', $adapter);
        $select = $state->getSql()->select();
        $select->where->like('state_name', $searchValue.'%');
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function getAllPostalCode($searchValue)
    {
        $adapter = $this->tableGateway->getAdapter();
        $state = new TableGateway('postal_code', $adapter);
        $select = $state->getSql()->select();
        $select->columns(array('*',new Expression("code as state_name")));
        $select->where->like('code', $searchValue.'%');
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function getAdRadiusForCopy($adId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $adImage = new TableGateway('ad_radius', $adapter);
        $select = $adImage->getSql()->select();
        $select->where(array('ad_radius.ad_id' => $adId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function insertAdRadius($data)
    {
         $adapter = $this->tableGateway->getAdapter();
         $businessCategory = new TableGateway('ad_radius', $adapter);
         //$businessCategory = new TableGateway('ad_radius_new', $adapter);
         $businessCategory->insert($data);
    }
    public function getRadius($adId)
    {
        $adapter = $this->tableGateway->getAdapter();
        $radius= new TableGateway('ad_radius', $adapter);
/*      $select = $radius->getSql()->select();
        $select->where(array('ad_radius.ad_id' => $adId));
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();*/
        $sql = "SELECT ad_radius.id, ad_radius.radius_value, ad_radius.radius_type, states.state_name, postal_code.code
                FROM `ad_radius`
                LEFT JOIN states ON ad_radius.radius_value = states.id
                AND ad_radius.radius_type = 'State'
                LEFT JOIN postal_code ON ad_radius.radius_value = postal_code.id
                AND ad_radius.radius_type = 'Zipcode'
                WHERE ad_radius.ad_id =".$adId;
        $result = $radius->getAdapter()->driver->getConnection()->execute($sql);
        $resultSet = new ResultSet();
        $resultSet->initialize($result);
        return $resultSet->toArray();
    }
    public function deleteRadius($id)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $businessCategory = new TableGateway('ad_radius', $adapter);
             return $businessCategory->delete(array('ad_id' => $id));
        } catch (\Exception $e) {
             return 0;
        }
    }
    public function deleteAdImage($id)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $mealImage = new TableGateway('ad_image', $adapter);
             return $mealImage->delete(array('ad_id' => $id));
        } catch (\Exception $e) {
             return 0;
        }
    }
    public function getPostalId($code)
    {
        $adapter = $this->tableGateway->getAdapter();
        $radius= new TableGateway('postal_code', $adapter);
        $select = $radius->getSql()->select()->columns(array('id'));
        $select->where('postal_code.code ='.$code);
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function getStateId($code)
    {
        $adapter = $this->tableGateway->getAdapter();
        $radius= new TableGateway('states', $adapter);
        $select = $radius->getSql()->select()->columns(array('id'));
        $select->where('states.state_name = "'.$code.'"');
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        return $result->current();
    }
    public function deleteAdLocation($id)
    {
        try {
             $adapter = $this->tableGateway->getAdapter();
             $adLocation = new TableGateway('ad_location', $adapter);
             return $adLocation->delete(array('ad_id' => $id));
        } catch (\Exception $e) {
             return 0;
        }
    }
}
