RENAME TABLE `fym_admin`.`meal_type` TO `fym_admin`.`meal_type_master` ;
[11:57:07 AM] Preejith JP (DBG): CREATE TABLE IF NOT EXISTS `meal_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meal_id` int(10) unsigned DEFAULT NULL,
  `meal_type_master_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

INSERT INTO `fym_admin`.`status` (
`id` ,
`status` ,
`slug` ,
`description`
)
VALUES (
'4', 'Delete', 'delete', 'Delete'
);

CREATE TABLE `states` (
   `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
   `state_code` char(3) NOT NULL,
   `state_name` varchar(32) NOT NULL,
   `country_iso` char(2) NOT NULL,
   `country_id` int(10) unsigned DEFAULT NULL,
   `congressional_districts` tinyint(3) unsigned NOT NULL DEFAULT '0',
   PRIMARY KEY (`id`),
   KEY `state_name` (`state_name`),
   KEY `state_code` (`state_code`),
   KEY `id` (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8

CREATE TABLE `postal_code` (
   `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
   `code` varchar(10) NOT NULL,
   `city` varchar(255) DEFAULT NULL,
   `state_id` int(10) unsigned DEFAULT NULL,
   `county` varchar(50) DEFAULT NULL,
   `timezone` varchar(10) DEFAULT NULL,
   `latitude` varchar(10) NOT NULL,
   `longitude` varchar(10) NOT NULL,
   PRIMARY KEY (`id`),
   KEY `latitude` (`latitude`,`longitude`),
   KEY `state_id` (`state_id`),
   KEY `code` (`code`),
   KEY `code_2` (`code`),
   KEY `state_id_2` (`state_id`),
   KEY `code_3` (`code`),
   KEY `city` (`city`)
 )

ALTER TABLE `business` ADD `premium_listing` BOOLEAN NOT NULL DEFAULT TRUE ;
 INSERT INTO `status` (`id`, `status`, `slug`, `description`) VALUES
(2, 'Inactive', 'inactive', 'In-Active'),
(3, 'Pending', 'pending', 'Pending');

ALTER TABLE `exercise` ADD `language_id` INT( 10 ) UNSIGNED NOT NULL AFTER `exercise_type_id` ;

ALTER TABLE `exercise` ADD `amount_hour` INT( 3 ) NOT NULL AFTER `description` ,
ADD `amount_min` INT( 2 ) NOT NULL AFTER `amount_hour` ,
ADD `amount_sec` INT( 2 ) NOT NULL AFTER `amount_min` ,
ADD `calories_burned` VARCHAR( 10 ) NOT NULL AFTER `amount_sec` ,
ADD `distance` VARCHAR( 10 ) NOT NULL AFTER `calories_burned` ,
ADD `set_no` INT( 5 ) NOT NULL AFTER `distance` ,
ADD `set_weight` VARCHAR( 10 ) NOT NULL AFTER `set_no` ;




ALTER TABLE `exercise` ADD `amount_hour` INT( 3 ) NOT NULL AFTER `description` ,
ADD `amount_min` INT( 2 ) NOT NULL AFTER `amount_hour` ,
ADD `amount_sec` INT( 2 ) NOT NULL AFTER `amount_min` ,
ADD `calories_burned` VARCHAR( 10 ) NOT NULL AFTER `amount_sec` ,
ADD `distance` VARCHAR( 10 ) NOT NULL AFTER `calories_burned` ,
ADD `set_no` INT( 5 ) NOT NULL AFTER `distance` ,
ADD `set_weight` VARCHAR( 10 ) NOT NULL AFTER `set_no` ;


ALTER TABLE `friends`     CHANGE `guid` `guid` VARCHAR(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL ;

ALTER TABLE `user_details`     ADD COLUMN `email_verification_code` VARCHAR(256) NULL AFTER `neutirition_plan_id`;
 INSERT INTO `status` (`id`, `status`, `slug`, `description`) VALUES
(5, 'Accepted', 'accepted', 'Friend Request Accepted'),
(6, 'Rejected', 'rejected', 'Friend Request Rejected'),
(7, 'Read', 'read', 'Read'),
(8, 'UnRead', 'unread', 'Unread');

CREATE TABLE IF NOT EXISTS `ad_radius` (
  `id` int(11) NOT NULL,
  `ad_id` int(10) NOT NULL,
  `radius_value` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `ad_radius`     ADD COLUMN `radius_type` ENUM('Zipcode','State') NULL AFTER `radius_value`,    CHANGE `radius_value` `radius_value` INT(10) NOT NULL;

CREATE TABLE IF NOT EXISTS `business_radius` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business_id` int(10) NOT NULL,
  `radius_value` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
CREATE TABLE IF NOT EXISTS `business_radius_new` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business_id` int(10) NOT NULL,
  `radius_value` INT(10) NOT NULL,
  `radius_type` ENUM('Zipcode','State')	
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
