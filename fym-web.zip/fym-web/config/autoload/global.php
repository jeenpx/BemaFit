<?php
return array(
    'db' => array(
        'driver'    => 'PdoMysql',
        'hostname'  => 'localhost',
        'database'  => 'fym',
        'username'  => 'root',
        'password'  => 'dbg123',
        'driver_options' => array(
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES UTF8"
        )
    ),
    'service_manager' => array(
        'factories' => array(
            'Zend\Db\Adapter\Adapter' => 'Zend\Db\Adapter\AdapterServiceFactory',
        ),
    ),
    'amazon_s3' => array(
       'key' => 'AKIAJXZA5BCZGVQOSRHA',
       'secret' => '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',
       'region' => 'us-east-1',
    ),
    'aws_s3_path'=>'https://s3.amazonaws.com',
    'ad_photo_Settings_sidebar' => array(  'bucket'=>'fymad',
                                   'server_upload_path' =>'public/uploads/ad/',
                                   'thumb_server_upload_path' =>'public/uploads/adthumbs/',
                                   'thumbs'=> array(
                                            array('resize' => array(
                                                                     'bucket'=>'fymadthumb/ad100',
                                                                     'width'=>0,
                                                                     'height'=>100
                                                                )
                                            ),
                                            array('ad1400' => array(
                                                                     'bucket'=>'fymadthumb/ad1400',
                                                                     'width'=>1401,
                                                                     'height'=>888
                                                                )
                                            ),
                                            array('ad600' => array('bucket'=>'fymadthumb/ad600',
                                                                     'width'=>600)
                                            )
                                   )
    ),
    'ad_photo_Settings_newsfeed' => array(  'bucket'=>'fymad',
                                       'server_upload_path' =>'public/uploads/ad/',
                                       'thumb_server_upload_path' =>'public/uploads/adthumbs/',
                                       'thumbs'=> array(
                                                array('resize' => array(
                                                                         'bucket'=>'fymadthumb/ad100',
                                                                         'width'=>0,
                                                                         'height'=>100
                                                                    )
                                                ),
                                                array('ad1400' => array(
                                                                         'bucket'=>'fymadthumb/ad1400',
                                                                         'width'=>1833,
                                                                         'height'=>307
                                                                    )
                                                ),
                                                array('ad600' => array('bucket'=>'fymadthumb/ad600',
                                                                         'width'=>600)
                                                )
                                       )
     ),
    'ad_photo_Settings_guestpost' => array(  'bucket'=>'fymad',
                                       'server_upload_path' =>'public/uploads/ad/',
                                       'thumb_server_upload_path' =>'public/uploads/adthumbs/',
                                       'thumbs'=> array(
                                                array('resize' => array(
                                                                         'bucket'=>'fymadthumb/ad100',
                                                                         'width'=>0,
                                                                         'height'=>100
                                                                    )
                                                ),
                                                array('ad1400' => array(
                                                                         'bucket'=>'fymadthumb/ad1400',
                                                                         'width'=>576,
                                                                         'height'=>576
                                                                    )
                                                ),
                                                array('ad600' => array('bucket'=>'fymadthumb/ad600',
                                                                         'width'=>600)
                                                )
                                       )
     ),
    'business_photo_Settings' => array(  'bucket'=>'fymbusiness',
                                       'server_upload_path' =>'public/uploads/business/',
                                       'thumb_server_upload_path' =>'public/uploads/businessthumbs/',
                                       'thumbs'=> array(
                                                array('resize' => array(
                                                                         'bucket'=>'fymbusinessthumb/business100',
                                                                         'width'=>0,
                                                                         'height'=>100
                                                                    )
                                                ),
                                                array('business1900' => array(
                                                                         'bucket'=>'fymbusinessthumb/business1900',
                                                                         'width'=>1920,
                                                                         'height'=>1056
                                                                    )
                                                ),
                                                /*array('feed300' => array('bucket'=>'fymfeedthumb/feed300',
                                                                         'width'=>300)
                                                )*/
                                       )
     ),
    'meal_photo_Settings' => array(  'bucket'=>'fymmeal',
                                       'server_upload_path' =>'public/uploads/meal/',
                                       'thumb_server_upload_path' =>'public/uploads/mealthumbs/',
                                       'thumbs'=> array(
                                                array('resize' => array(
                                                                         'bucket'=>'fymmealthumbs/meal100',
                                                                         'width'=>0,
                                                                         'height'=>100
                                                                    )
                                                ),
                                                array('meal225' => array(
                                                                         'bucket'=>'fymmealthumbs/meal225',
                                                                         'width'=>225,
                                                                         'height'=>225
                                                                    )
                                                ),
                                                array('meal600' => array('bucket'=>'fymmealthumbs/meal600',
                                                                         'width'=>600)
                                                )
                                       )
     )
);
