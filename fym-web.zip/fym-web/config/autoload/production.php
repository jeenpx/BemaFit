<?php
return array(
	'db' => array(
        'driver'    => 'PdoMysql',
        'hostname'  => 'fymdbstage.c59jgus5q6nm.us-west-2.rds.amazonaws.com',
        'database'  => 'fym_core_stage',
        'username'  => 'admin',
        'password'  => 'stagingfymp4ssword!',
        'driver_options' => array(
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES UTF8"
        )
    ),
);
