
<!DOCTYPE html>
<html class="no-js" lang="en-us">
    <head>
    	<meta charset="utf-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title>Flex Your Macros</title>
    	<meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge">

    	<link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/pure-min.css">
      <!--[if lte IE 8]>
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/grids-responsive-old-ie-min.css">
      <![endif]-->
      <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/grids-responsive-min.css">
      <!--<![endif]-->
    	<link rel="stylesheet" href="css/common-base.css" media="screen, projection" />
    	<link rel="stylesheet" href="css/base.css" media="screen, projection" />
		  <link rel="stylesheet" href="css/print.css" media="print" />
      <link rel="stylesheet" href="css/_forms.css" media="screen, projection" />
      <link rel="stylesheet" href="css/colorbox/colorbox.css" media="screen, projection" />
      <link rel="stylesheet" href="css/jQueryUI/jquery-ui.css" media="screen, projection">
      <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
      <!--[if lt IE 9]>
        <script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
      <![endif]-->

      <link rel="stylesheet" href="css/msdropdown/dd.css" media="screen, projection" />
      <link rel="stylesheet" href="css/iCheck/all.css" media="screen, projection" />

		  <link rel="Shortcut Icon" href="images/favicon.png" type="image/x-icon" />
    </head>

    <body>

      <div class="wrapper">

        <header class="header">
          <div class="header__resize">
            <div class="header__user-account">
              <a href="" title="">Logout</a>
            </div>
            <div class="header__user-activity">
              <div class="header__logo">
                <h1><a href="#">FYM</a></h1>
              </div>
              <div class="header__module-management">
                <select class="module-management">
                  <option value="" selected="selected">User Management</option>
                  <option value="">Meal Management</option>
                </select>
              </div>
              <div class="clear"></div>
            </div>
          </div>
        </header>

        <section class="content">

          <div class="content__resize">
            <div class="content__breadcrumb">

            </div>
            <div class="content__table">
              <div class="content__table-top pure-g">
                <div class="pure-u-1-2">
                  <div class="content__table-top__select">
                    <select class="user-status">
                      <option value="" selected="selected">Inactive Users (200)</option>
                      <option value="">Active Users (200)</option>
                    </select>
                  </div>
                </div>
                <div class="pure-u-1-2">
                  <div class="content__table-top__search">
                    <input type="text" class="form__group-control" id="" placeholder="Search...">
                  </div>
                </div>
              </div>
              <table class="common-table">
                <tr>
                  <th width="22%"><span class="sortable">NAME</span><span class="table-sort"></span></th>
                  <th width="12%">USERNAME</th>
                  <th width="28%">EMAIL</th>
                  <th width="13%"><span class="sortable">SIGN UP</span><span class="table-sort"></th>
                  <th width="11%">PASSWORD</th>
                  <th width="14%">MANAGE</th>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td class="bold">Pending...</td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td class="has-button"><input class="button--green" type="button" value="Activate"></td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td class="has-button"><input class="button--grey" type="button" value="Deactivate"></td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td class="bold">Pending...</td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td class="bold">Pending...</td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td class="has-button"><input class="button--green" type="button" value="Activate"></td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td class="has-button"><input class="button--green" type="button" value="Activate"></td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td class="has-button"><input class="button--green" type="button" value="Activate"></td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td class="has-button"><input class="button--grey" type="button" value="Deactivate"></td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td class="has-button"><input class="button--grey" type="button" value="Deactivate"></td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td class="bold">Pending...</td>
                </tr>
              </table>
            </div>
            <div class="content__pagination">
              <ul class="content__pagination-list">
                <li class="active"><a href="">1</a></li>
                <li><a href="">2</a></li>
                <li><a href="">3</a></li>
                <li><a href="">4</a></li>
                <li class="content__pagination-list__pagination--dots"><a href="">...</a></li>
                <li><a href="">10</a></li>
                <li><a href="">11</a></li>
                <li><a href="" title="Next">Next</a></li>
              </ul>
            </div>
          </div>
          <div class="clear"></div>
        </section>

      </div>



      <!-- JavaScript -->
      <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
      <script src="js/colorbox/jquery.colorbox.js"></script>
      <script src="js/jQueryUI/jquery-ui.js"></script>
      <script src="js/common.js" ></script>

      <script src="js/iCheck/icheck.js"></script>
      <script src="js/msdropdown/jquery.dd.min.js"></script>


      <script>
        $(document).ready(function(){


          $(".inline").colorbox({inline:true, width:"50%"});


          $( "#dialog" ).dialog({
            autoOpen: false,
            width: 340,
            modal: true,
            buttons: [
              {
                text: "No, Cancel Request",
                click: function() {
                  $( this ).dialog( "close" );
                }
              },
              {
                text: "Yes, Deactivate User",
                click: function() {
                  $( this ).dialog( "close" );
                }
              }
            ]
          });
          $( "#dialog-link" ).click(function( event ) {
            $( "#dialog" ).dialog( "open" );
            event.preventDefault();
          });


          var callbacks_list = $('.icheck-callbacks ul');
          $('.icheck-list input').on('ifCreated ifClicked ifChanged ifChecked ifUnchecked ifDisabled ifEnabled ifDestroyed', function(event){
            callbacks_list.prepend('<li><span>#' + this.id + '</span> is ' + event.type.replace('if', '').toLowerCase() + '</li>');
          }).iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%'
          });


          $(".user-status, .module-management").msDropdown().data("dd");//{animStyle:'none'} /{animStyle:'slideDown'} {animStyle:'show'}


        });
      </script>

    </body>
</html>
