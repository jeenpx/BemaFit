
<!DOCTYPE html>
<html class="no-js" lang="en-us">
    <head>
    	<meta charset="utf-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title>Flex Your Macros</title>
    	<meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge">

    	<link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/pure-min.css">
      <!--[if lte IE 8]>
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/grids-responsive-old-ie-min.css">
      <![endif]-->
      <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/grids-responsive-min.css">
      <!--<![endif]-->

    	<link rel="stylesheet" href="css/common-base.css" media="screen, projection" />
    	<link rel="stylesheet" href="css/base.css" media="screen, projection" />
		  <link rel="stylesheet" href="css/print.css" media="print" />
      <link rel="stylesheet" href="css/_forms.css" media="screen, projection" />
      <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
      <!--[if lt IE 9]>
        <script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
      <![endif]-->

		  <link rel="Shortcut Icon" href="images/favicon.png" type="image/x-icon" />
    </head>

    <body>

      <div class="wrapper">

        <header class="header">
          <div class="header__resize">
            <div class="header__user-account">
            </div>
            <div class="header__user-activity">
              <div class="header__logo">
                <h1><a href="#">FYM</a></h1>
              </div>
              <div class="header__module-management">

              </div>
              <div class="clear"></div>
            </div>
          </div>
        </header>

        <section class="content">
          <div class="content__login-box">
              <div id="login-email">
                <label class="form__label" for="user-name">Email</label>
                <input type="email" class="form__group-control">
                <label class="error hide">error</label>
              </div>
              <div class="clear padding-top-05"></div>
              <div id="login-password">
                <label class="form__label" for="email">Password</label>
                <input type="password" class="form__group-control">
                <label class="error hide">error</label>
              </div>
              <div class="clear padding-top-10"></div>
              <div class="block text-center">
                <button type="submit" class="button--blue-medium margin-auto" id="login-btn" title="Login">Login</button>
                <button type="submit" class="button--blue-medium--lengthy margin-auto" id="recover-password-btn" title="Recover Password">Recover Password</button>
              </div>
          </div>
          <div class="forgot-password-link"><a href="" title="Forgot Password?" id="forgot-password-btn">Forgot Password?</a></div>
        </section>


      </div>

      <!-- JavaScript -->
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

      <script>
        $(document).ready(function(){

          $('#recover-password-btn').hide();
          $('#forgot-password-btn').on('click', function(){
            $('#login-password, #login-btn, #forgot-password-btn').hide();
            $('#login-email').addClass('padding-top-25');
            $('#recover-password-btn').fadeIn();
            return false;
          });

        });
      </script>

    </body>
</html>
