
<!DOCTYPE html>
<html class="no-js" lang="en-us">
    <head>
    	<meta charset="utf-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title>Flex Your Macros</title>
    	<meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge">

    	<link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/pure-min.css">
      <!--[if lte IE 8]>
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/grids-responsive-old-ie-min.css">
      <![endif]-->
      <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/grids-responsive-min.css">
      <!--<![endif]-->
    	<link rel="stylesheet" href="css/common-base.css" media="screen, projection" />
    	<link rel="stylesheet" href="css/base.css" media="screen, projection" />
		  <link rel="stylesheet" href="css/print.css" media="print" />
      <link rel="stylesheet" href="css/_forms.css" media="screen, projection" />
      <link rel="stylesheet" href="css/colorbox/colorbox.css" media="screen, projection" />
      <link rel="stylesheet" href="css/jQueryUI/jquery-ui.css" media="screen, projection">
      <link rel="stylesheet" href="css/tooltipster/tooltipster.css" media="screen, projection">
      <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
      <!--[if lt IE 9]>
        <script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
      <![endif]-->

      <link rel="stylesheet" href="css/msdropdown/dd.css" media="screen, projection" />
      <link rel="stylesheet" href="css/iCheck/all.css" media="screen, projection" />
      <link rel="stylesheet" href="css/jScroll/jquery.jscrollpane.css" media="screen, projection" />

		  <link rel="Shortcut Icon" href="images/favicon.png" type="image/x-icon" />
    </head>

    <body>

      <div class="wrapper">

        <header class="header">
          <div class="header__resize">
            <div class="header__user-account">
              <a href="" title="">Logout</a>
            </div>
            <div class="header__user-activity">
              <div class="header__logo">
                <h1><a href="#">FYM</a></h1>
              </div>
              <div class="header__module-management">
                <select class="module-management">
                  <option value="" selected="selected">User Management</option>
                  <option value="">Meal Management</option>
                </select>
              </div>
              <div class="clear"></div>
            </div>
          </div>
        </header>

        <section class="content">

          <div class="content__resize">
            <div class="content__breadcrumb">

            </div>
            <div class="content__table">
              <div class="content__table-top">

              </div>
              <table class="common-table">
                <tr>
                  <th width="16%">NAME</th>
                  <th width="11%">USERNAME</th>
                  <th width="19%">EMAIL</th>
                  <th width="12%">SIGN UP</th>
                  <th width="10%">PASSWORD</th>
                  <th width="12%">MANAGE</th>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td>Pending...</td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td>Pending...</td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td>Pending...</td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td>Pending...</td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td>Pending...</td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td>Pending...</td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td>Pending...</td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">Michael Bilderbach</a></td>
                  <td>buffdude</td>
                  <td>mbilderbach@gmail.com</td>
                  <td>01/13/14</td>
                  <td>imsobuff</td>
                  <td>Pending...</td>
                </tr>
              </table>
            </div>
            <div class="content__pagination">
              <ul class="content__pagination-list">
                <li class="active"><a href="">1</a></li>
                <li><a href="">2</a></li>
                <li><a href="">3</a></li>
                <li><a href="">4</a></li>
                <li class="content__pagination-list__pagination--dots"><a href="">...</a></li>
                <li><a href="">10</a></li>
                <li><a href="">11</a></li>
                <li><a href="" title="Next">Next</a></li>
              </ul>

            </div>

            <p><a class='inline' href="#inline-content">Popup Style</a></p>
            <p class=""><a href="#" id="dialog-link">Open Dialog</a></p>
            <p class="tooltip float-left">Tooltip - Hover me</p>

          </div>

          <div class="clear"></div>

        </section>

        <div class="content__resize">
          <div class="icheck-list">
          <h3>CheckBox, Radio Buttons</h3>
          <ul>
            <li>
              <input tabindex="1" type="checkbox" id="input-1">
              <label for="input-1">Low Carb</label>
            </li>
            <li>
              <input tabindex="2" type="checkbox" id="input-2" checked>
              <label for="input-2">Low Carb</label>
            </li>
          </ul>
          <ul>
            <li>
              <input tabindex="3" type="radio" id="input-3" name="demo-radio">
              <label for="input-3">Low Carb</label>
            </li>
            <li>
              <input tabindex="4" type="radio" id="input-4" name="demo-radio" checked>
              <label for="input-4">Low Carb</label>
            </li>
          </ul>
          </div>
        </div>
        <div class="clear"></div>
        <div class="content__resize">
          <h3>Normal Buttons</h3>
            <input class="button--red" type="button" value="Remove">
            <input class="button--green" type="button" value="Success">
            <input class="button--blue" type="button" value="Save">
            <input class="button--grey" type="button" value="Deactivate">
            <input class="button--darkgrey" type="button" value="Copy">
          <h3>Small Buttons</h3>
            <input class="button--red-small" type="button" value="+Add Meal">
            <input class="button--green-small" type="button" value="Success">
            <input class="button--blue-small" type="button" value="Save">
            <input class="button--grey-small" type="button" value="Deactivate">
            <input class="button--darkgrey-small" type="button" value="Copy">
          <h3>Medium Buttons</h3>
            <input class="button--red-medium" type="button" value="Copy">
            <input class="button--green-medium" type="button" value="Success">
            <input class="button--blue-medium" type="button" value="Save">
            <input class="button--grey-medium" type="button" value="Deactivate">
            <input class="button--darkgrey-medium" type="button" value="Copy">
          <h3>Large Buttons</h3>
            <input class="button--red-large" type="button" value="+Add Meal">
            <input class="button--green-large" type="button" value="Success">
            <input class="button--blue-large" type="button" value="Save">
            <input class="button--grey-large" type="button" value="Deactivate">
            <input class="button--darkgrey-large" type="button" value="Copy">
          <h3>Lengthy Buttons</h3>
            <input class="button--blue-medium--lengthy" type="button" value="Save">
          <h3>Drop Down</h3>
            <select style="width:100%"  name="pages" class="pages">
              <option value="" selected="selected">Drop Down</option>
              <option value="">Normal</option>
            </select>
          <h3>Drop Down Theme Unit Only</h3>
            <select style="width:100%"  name="theme" class="theme-unit">
              <option value="" selected="selected">Drop Down</option>
              <option value="">Normal</option>
            </select>
            <h3>Drop Down Theme Segmented Button</h3>
            <div class="pure-u-1">
              <div class="pure-u-4-5 float-left"><input type="email" class="form__group-control--segment" id="input-email1" placeholder="Enter email"></div>
              <div class="pure-u-1-5">
                <select style="width:62px"  name="theme" class="theme-segment">
                  <option value="" selected="selected">oz</option>
                  <option value="">ml</option>
                </select>
              </div>
            </div>
        </div>

        <div class="content__resize">
          <h3>File Upload</h3>
          <div class="file__input-wrapper">
          <button class="btn-file-input">SELECT FILES</button>
          <input type="file" name="image" id="image" value="" />
        </div>
        </div>

        <div class="content__resize">
          <h3>Custom Scroll</h3>
          <div class="scroll__container">
            <div class="scroll-pane">
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec in ligula id sem tristique ultrices
                eget id neque. Duis enim turpis, tempus at accumsan vitae, lobortis id sapien. Pellentesque nec orci
                mi, in pharetra ligula. Nulla facilisi. Nulla facilisi. Mauris convallis venenatis massa, quis
                consectetur felis ornare quis. Sed aliquet nunc ac ante molestie ultricies. Nam pulvinar ultricies
                bibendum. Vivamus diam leo, faucibus et vehicula eu, molestie sit amet dui. Proin nec orci et elit
                semper ultrices. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus
                mus. Sed quis urna mi, ac dignissim mauris. Quisque mollis ornare mauris, sed laoreet diam malesuada
                quis. Proin vel elementum ante. Donec hendrerit arcu ac odio tincidunt posuere. Vestibulum nec risus
                eu lacus semper viverra.
              </p>
              <p>
                Vestibulum dictum consectetur magna eu egestas. Praesent molestie dapibus erat, sit amet sodales
                lectus congue ut. Nam adipiscing, tortor ac blandit egestas, lorem ligula posuere ipsum, nec
                faucibus nisl enim eu purus. Quisque bibendum diam quis nunc eleifend at molestie libero tincidunt.
                Quisque tincidunt sapien a sapien pellentesque consequat. Mauris adipiscing venenatis augue ut
                tempor. Donec auctor mattis quam quis aliquam. Nullam ultrices erat in dolor pharetra bibendum.
                Suspendisse eget odio ut libero imperdiet rhoncus. Curabitur aliquet, ipsum sit amet aliquet varius,
                est urna ullamcorper magna, sed eleifend libero nunc non erat. Vivamus semper turpis ac turpis
                volutpat non cursus velit aliquam. Fusce id tortor id sapien porta egestas. Nulla venenatis luctus
                libero et suscipit. Sed sed purus risus. Donec auctor, leo nec eleifend vehicula, lacus felis
                sollicitudin est, vitae lacinia lectus urna nec libero. Aliquam pellentesque, arcu condimentum
                pharetra vestibulum, lectus felis malesuada felis, vel fringilla dolor dui tempus nisi. In hac
                habitasse platea dictumst. Ut imperdiet mauris vitae eros varius eget accumsan lectus adipiscing.
              </p>
            </div>
          </div>
        </div>

        <div class="content__resize">
          <h3>Text Box</h3>
            <form role="form" action="form">
              <div class="form__group">
                <label for="input-email" class="form__label">Email address</label>
                <input type="email" placeholder="Enter email" id="input-email1" class="form__group-control">
                <label class="error">error</label>
              </div>
              <div class="form__group">
                <label for="input-password" class="form__label">Password</label>
                <input type="password" placeholder="Password" id="input-password1" class="form__group-control">
              </div>
            </form>
        </div>

        <div class="content__resize">
          <h3>Comp 4b</h3>
          <div style="width:855px; border:1px solid #e6e6e6; padding:15px;">
          <form class="pure-form-stacked">
            <fieldset>
                <h2 class="form__label--medium" for="">Rebate #1101</h2>
                <div class="pure-g form__block-floated total--option--head">
                  <div class="pure-u-1-24 form__group">
                    <div class="form__element-block--first">&nbsp;
                    </div>
                  </div>
                  <div class="pure-u-1-4 form__group">
                    <div class="form__element-block--first">
                      <label class="form__label--medium" for="rebate">REBATE</label>
                    </div>
                  </div>
                  <div class="pure-u-1-12 form__group">
                    <div class="form__element-block--second">
                      <label class="form__label--medium" for="date">DATE</label>
                    </div>
                  </div>
                  <div class="pure-u-1-12 form__group">
                    <div class="form__element-block--third">
                      <label class="form__label--medium" for="status">STATUS</label>
                    </div>
                  </div>
                  <div class="pure-u-1-5 form__group">
                    <div class="form__element-block--third">
                      <label class="form__label--medium" for="status">CASHED OUT METHOD</label>
                    </div>
                  </div>
                  <div class="pure-u-1-5 form__group">
                    <div class="form__element-block--third">
                      <label class="form__label--medium" for="status">DOWNLOAD DETAILS</label>
                    </div>
                  </div>
                  <div class="pure-u-1-8 form__group">
                    <div class="form__element-block--last">
                      <label class="form__label--medium" for="status">AMOUNT</label>
                    </div>
                  </div>
              </div>
              <div class="pure-g form__block-floated">
                <div class="pure-u-1 form__group">
                  <?php
                  for($i=0; $i<5;$i++)
                 {
                  ?>
                  <div class="total--option">
                    <div class="pure-u-1-24">
                      <div class="icheck-list">
                        <ul>
                          <li>
                            <input tabindex="1" type="checkbox" id="input-1">
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div class="pure-u-1-4">
                       <span><strong>Blue Diamond Almond Breeze</strong></span>
                    </div>
                    <div class="pure-u-1-12">
                       <span>4/23/14</span>
                    </div>
                    <div class="pure-u-1-12">
                       <span>Approved</span>
                    </div>
                    <div class="pure-u-1-5">
                       <span>Store Credit</span>
                    </div>
                    <div class="pure-u-1-5">
                       <span>1101.pdf</span>
                    </div>
                    <div class="pure-u-1-12">
                       <span>$45.00</span>
                    </div>
                  </div>
                  <?php
                  }
                  ?>
                </div>
              </div>
              <div class="pure-g form__block-floated">
                <div class="pure-u-1-2 form__group">
                  <div class="form__element-block--first">
                    <div class="pure-u-1-3"><label for="user-name" class="form__label">Approve/ Deny</label></div>
                    <div class="pure-u-1-2">
                      <select style="width:100%" name="pages" class="pages">
                        <option value="" selected="selected">Approved</option>
                        <option value="">Approved</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="pure-u-1-2 form__group">
                  <div class="form__element-block--first">
                    <div class="pure-u-3-8"><label for="user-name" class="form__label">&nbsp;</label></div>
                    <div class="pure-u-1-2 text-right">
                      <span class="form__label--p"><strong>Total</strong></span>
                      <span class="form__label--p"><strong> $45.00</strong></span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="pure-g form__block-floated">
                <div class="pure-u-3-4 form__group">
                  <div class="form__element-block--first">
                    <label class="form__label" for="password">Notes</label>
                    <input type="password" class="form__group-control textarea--large" id="password" placeholder="">
                    <label class="error">error</label>
                  </div>
                </div>
                <div class="pure-u-3-24 form__group float-right">
                  <div class="form__element-block--last margin-top-75">
                    <button title="Save Changes" class="button--blue-medium float-right" type="submit">Save Changes</button>
                  </div>
                </div>
              </div>
            </fieldset>
          </form>
          </div>

        <div class="clear" style="margin-bottom:50px;"></div>


        <div class="content__resize">
        <h3>Comp 5</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                    <h2 class="form__label--medium" for="">Account Credentials</h2>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="user-name">User Name</label>
                            <input type="email" class="form__group-control" id="user-name" placeholder="Enter User Name">
                            <label class="error">error</label>
                          </div>
                        </div>
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--last">
                            <label class="form__label" for="email">Email</label>
                            <input type="email" class="form__group-control" id="email" placeholder="Enter email">
                            <label class="error">error</label>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="first-name">First Name</label>
                            <input type="email" class="form__group-control" id="first-name" placeholder="Enter First Name">
                            <label class="error">error</label>
                          </div>
                        </div>
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--last">
                            <label class="form__label" for="last-name">Last Name</label>
                            <input type="email" class="form__group-control" id="last-name" placeholder="Enter Last Name">
                            <label class="error">error</label>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="password">Password</label>
                            <input type="password" class="form__group-control" id="password" placeholder="Enter Password">
                            <label class="error">error</label>
                          </div>
                        </div>
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--last">
                            <label class="form__label" for="confirm-password">Confirm Password</label>
                            <input type="password" class="form__group-control" id="confirm-password" placeholder="Confirm Password">
                            <label class="error">error</label>
                          </div>
                        </div>
                      </div>
                      <h2 class="form__label--medium" for="">PayPal Account</h2>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-12 form__group">
                          <div class="form__element-block--first">
                            <a href="#" title="close" class="close-button"></a>
                          </div>
                        </div>
                        <div class="pure-u-1-5 form__group">
                          <span class="paypal-image"></span>
                        </div>
                        <div class="pure-u-1-5 form__group">
                          <span class="custom__text--blue">mbilderbach@gmail.com</span>
                        </div>
                      </div>
                    <button type="submit" class="button--blue-medium float-right" title="Save Changes">Save Changes</button>
                </fieldset>
              </form>
            </div>
          </div>
        </div>


        <div class="content__resize">
        <h3>Comp 5b</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                    <h2 class="form__label--medium" for="">Account Credentials</h2>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="user-name">User Name</label>
                            <input type="email" class="form__group-control" id="user-name" placeholder="Enter User Name">
                            <label class="error">error</label>
                          </div>
                        </div>
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--last">
                            <label class="form__label" for="email">Email</label>
                            <input type="email" class="form__group-control" id="email" placeholder="Enter email">
                            <label class="error">error</label>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="first-name">First Name</label>
                            <input type="email" class="form__group-control" id="first-name" placeholder="Enter First Name">
                            <label class="error">error</label>
                          </div>
                        </div>
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--last">
                            <label class="form__label" for="last-name">Last Name</label>
                            <input type="email" class="form__group-control" id="last-name" placeholder="Enter Last Name">
                            <label class="error">error</label>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="password">Password</label>
                            <input type="password" class="form__group-control" id="password" placeholder="Enter Password">
                            <label class="error">error</label>
                          </div>
                        </div>
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--last">
                            <label class="form__label" for="confirm-password">Confirm Password</label>
                            <input type="password" class="form__group-control" id="confirm-password" placeholder="Confirm Password">
                            <label class="error">error</label>
                          </div>
                        </div>
                      </div>
                      <h2 class="form__label--medium" for="">PayPal Account</h2>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-5 form__group">
                          <span class="paypal-image"></span>
                        </div>
                        <div class="pure-u-3-8 form__group">
                          <div class="form__element-block--second">
                            <input type="email" class="form__group-control" id="email" placeholder="Enter email">
                          </div>
                        </div>
                        <div class="pure-u-1-5 form__group">
                          <div class="form__element-block--third">
                            <button type="submit" class="text__button--blue" title="add">add</button>
                          </div>
                        </div>
                      </div>
                    <button type="submit" class="button--blue-medium float-right" title="Save Changes">Save Changes</button>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>

        <div class="content__resize">
        <h3>Comp 27</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="brand-name">Image Upload</label>
                          <div class="file__input-wrapper">
                            <button class="btn-file-input">SELECT FILES</button>
                            <input type="file" value="" id="image" name="image">
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="brand-name">Brand Name</label>
                          <input type="email" class="form__group-control" id="brand-name" placeholder="Enter Brand Name">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="url">Product</label>
                          <input type="email" class="form__group-control" id="product" placeholder="Enter Product">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="rebate-amount">Rebate Amount</label>
                          <input type="text" class="form__group-control" id="rebate-amount" placeholder="Enter Rebate Amount">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="data-range">Rebate Date</label>
                          <select style="width:45%" name="pages" class="pages">
                            <option value="" selected="selected">1/12/2015</option>
                            <option value="">1-30</option>
                          </select>
                          <select style="width:45%" name="pages" class="pages">
                            <option value="" selected="selected">1/12/2015</option>
                            <option value="">1-30</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="upc-code">UPC Code</label>
                          <input type="email" class="form__group-control" id="upc-code" placeholder="Enter UPC Code">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="categories">Categories</label>
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="1" type="checkbox" id="input-1">
                                <label for="input-1">Gym</label>
                              </li>
                              <li>
                                <input tabindex="2" type="checkbox" id="input-2" checked>
                                <label for="input-2">Retail</label>
                              </li>
                              <li>
                                <input tabindex="2" type="checkbox" id="input-2" checked>
                                <label for="input-2">Retail</label>
                              </li>
                              <li>
                                <input tabindex="2" type="checkbox" id="input-2" checked>
                                <label for="input-2">Retail</label>
                              </li>
                              <li>
                                <input tabindex="2" type="checkbox" id="input-2" checked>
                                <label for="input-2">Retail</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="radius">Radius</label>
                          <input type="email" class="form__group-control" id="radius" placeholder="Enter Radius">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <input type="text" style="height:80px;" class="form__group-control" id="note" placeholder="">
                        <label class="error">error</label>
                      </div>
                    </div>
                  <button type="submit" class="button--blue-medium float-right" title="Save">Save</button>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>

        <div class="content__resize">
        <h3>Comp 27b</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="brand-name">Image Upload</label>
                          <div class="file__input-wrapper">
                            <button class="btn-file-input">SELECT FILES</button>
                            <input type="file" value="" id="image" name="image">
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="brand-name">Brand Name</label>
                          <input type="email" class="form__group-control" id="brand-name" placeholder="Enter Brand Name">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="url">Product</label>
                          <input type="email" class="form__group-control" id="product" placeholder="Enter Product">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="rebate-amount">Rebate Amount</label>
                          <input type="text" class="form__group-control" id="rebate-amount" placeholder="Enter Rebate Amount">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="data-range">Rebate Date</label>
                          <select style="width:45%" name="pages" class="pages">
                            <option value="" selected="selected">1/12/2015</option>
                            <option value="">1-30</option>
                          </select>
                          <select style="width:45%" name="pages" class="pages">
                            <option value="" selected="selected">1/12/2015</option>
                            <option value="">1-30</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="categories">Categories</label>
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="1" type="checkbox" id="input-1">
                                <label for="input-1">Gym</label>
                              </li>
                              <li>
                                <input tabindex="2" type="checkbox" id="input-2" checked>
                                <label for="input-2">Retail</label>
                              </li>
                              <li>
                                <input tabindex="2" type="checkbox" id="input-2" checked>
                                <label for="input-2">Retail</label>
                              </li>
                              <li>
                                <input tabindex="2" type="checkbox" id="input-2" checked>
                                <label for="input-2">Retail</label>
                              </li>
                              <li>
                                <input tabindex="2" type="checkbox" id="input-2" checked>
                                <label for="input-2">Retail</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="radius">Radius</label>
                          <input type="email" class="form__group-control" id="radius" placeholder="Enter Radius">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <input type="text" style="height:80px;" class="form__group-control" id="note" placeholder="">
                        <label class="error">error</label>
                      </div>
                    </div>
                  <button type="submit" class="button--blue-medium float-right" title="Save">Save</button>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>


        <div class="content__resize">
        <h3>Comp 15</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="type">Type</label>
                          <select style="width:100%" name="pages" class="pages">
                            <option value="" selected="selected">Type</option>
                            <option value="">Type 2</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="url">URL</label>
                          <input type="email" placeholder="Enter URL" id="radius" class="form__group-control">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="location">Location</label>
                          <select style="width:100%" name="pages" class="pages">
                            <option value="" selected="selected">Location 1</option>
                            <option value="">Location 2</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="url">Time Period</label>
                          <select style="width:45%" name="pages" class="pages">
                            <option value="" selected="selected">1-30</option>
                            <option value="">1-30</option>
                          </select>
                          <select style="width:45%"  name="pages" class="pages float-right">
                            <option value="" selected="selected">1-30</option>
                            <option value="">1-30</option>
                          </select>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="business-name">Business Name</label>
                          <input type="email" placeholder="Enter Business Name" id="business-name" class="form__group-control">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>

                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="radius">Radius</label>
                          <input type="email" class="form__group-control" id="radius" placeholder="Enter Radius">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="radius">&nbsp;</label>
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="1" type="checkbox" id="input-1">
                                <label for="input-1">All</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <input type="text" style="height:80px;" class="form__group-control" id="note" placeholder="">
                        <label class="error">error</label>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="brand-name">Image Upload</label>
                          <div class="file__input-wrapper">
                            <button class="btn-file-input">SELECT FILES</button>
                            <input type="file" value="" id="image" name="image">
                          </div>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                        <label class="form__label" for="radius">&nbsp;</label>
                          <button type="submit" class="button--blue-medium float-right margin-top-75 " title="Save">Save</button>
                        </div>
                      </div>
                    </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>



        <div class="content__resize">
        <h3>Comp 15b</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="type">Type</label>
                          <select style="width:100%" name="pages" class="pages">
                            <option value="" selected="selected">Type</option>
                            <option value="">Type 2</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="comments">Comments</label>
                          <input type="text" placeholder="" id="note" class="form__group-control" style="height:80px;">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="url">Time Period</label>
                          <select style="width:45%" name="pages" class="pages">
                            <option value="" selected="selected">1-30</option>
                            <option value="">1-30</option>
                          </select>
                          <select style="width:45%"  name="pages" class="pages float-right">
                            <option value="" selected="selected">1-30</option>
                            <option value="">1-30</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="radius">Radius</label>
                          <input type="email" class="form__group-control" id="radius" placeholder="Enter Radius">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="radius">&nbsp;</label>
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="1" type="checkbox" id="input-1">
                                <label for="input-1">All</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <input type="text" style="height:80px;" class="form__group-control" id="note" placeholder="">
                        <label class="error">error</label>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="add-image">Add Image</label>
                          <div class="file__input-wrapper">
                            <button class="btn-file-input">SELECT FILES</button>
                            <input type="file" value="" id="image" name="image">
                          </div>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                        <label class="form__label" for="radius">&nbsp;</label>
                          <button type="submit" class="button--blue-medium float-right margin-top-75 " title="Save">Save</button>
                        </div>
                      </div>
                    </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>

        <div class="content__resize">
        <h3>Comp 29 To do Tag 2</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="video-name">Video Name</label>
                            <input type="email" class="form__group-control" id="video-name" placeholder="Enter Video Name">
                            <label class="error">error</label>
                          </div>
                        </div>
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--last">
                            <label class="form__label" for="url">URL</label>
                            <input type="email" class="form__group-control" id="url" placeholder="Enter URL">
                            <label class="error">error</label>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="categories">Categories</label>
                            <div class="icheck-list">
                              <ul>
                                <li>
                                  <input tabindex="1" type="checkbox" id="input-1">
                                  <label for="input-1">Gym</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">Retail</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">Retail</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">Retail</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">Retail</label>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="radius">Radius</label>
                            <input type="text" class="form__group-control" id="radius" placeholder="Enter Radius">
                            <label class="error">error</label>
                          </div>
                        </div>
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--last">
                            <label class="form__label" for="data-range">Data Range</label>
                            <select style="width:45%" name="pages" class="pages">
                              <option value="" selected="selected">1-30</option>
                              <option value="">1-30</option>
                            </select>
                            <select style="width:45%"  name="pages" class="pages float-right">
                              <option value="" selected="selected">1-30</option>
                              <option value="">1-30</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1 form__group">
                          <input type="text" style="height:100px;" class="form__group-control" id="note" placeholder="">
                          <label class="error">error</label>
                        </div>
                      </div>
                    <button type="submit" class="button--blue-medium float-right" title="Save Changes">Save Changes</button>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>


        <div class="content__resize">
        <h3>Comp 32b 2</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                      <h2 for="" class="form__label--medium">Exercise</h2>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="categories">Languague</label>
                            <div class="icheck-list">
                              <ul>
                                <li>
                                  <input tabindex="3" type="radio" id="input-3" name="demo-radio">
                                  <label for="input-3">English</label>
                                </li>
                                <li>
                                  <input tabindex="4" type="radio" id="input-4" name="demo-radio" checked>
                                  <label for="input-4">Spanish</label>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="name">Name</label>
                            <input type="email" class="form__group-control" id="name" placeholder="Enter Name">
                            <label class="error">error</label>
                          </div>
                        </div>
                        <div class="pure-u-1-2 form__group">
                          <div class="form__element-block--last">
                            <label class="form__label" for="data-range">Type</label>
                            <select style="width:100%" name="pages" class="pages">
                              <option value="" selected="selected">Drop Down</option>
                              <option value="">Normal</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    <button type="submit" class="button--blue-medium float-right" title="Save Changes">Save Changes</button>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>

        <div class="content__resize">
        <h3>Comp 17</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                  <div class="pure-g form__block-floated">
                    <div class="pure-u-1 form__group">
                      <div class="form__element-block--first">
                        <label class="form__label" for="category-name">Category Name</label>
                        <input type="email" class="form__group-control" id="category-name" placeholder="Enter Category Name">
                        <label class="error">error</label>
                      </div>
                    </div>
                    <div class="pure-u-1 form__group">
                      <div class="form__element-block--first">
                        <label class="form__label" for="description">Description</label>
                        <input type="text" placeholder="" id="input-email1" class="form__group-control" style="height:100px;">
                        <label class="error">error</label>
                      </div>
                    </div>
                  </div>
                  <button type="submit" class="button--blue-medium float-right" title="Save">Save</button>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>

        <div class="content__resize">
        <h3>Comp 6</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <h2 for="" class="form__label--medium">Order #1101</h2>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <h2 for="" class="form__label--medium">Order Placed: 9/10/14</h2>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="tracking">Tracking #</label>
                          <input type="email" class="form__group-control" id="name" placeholder="135689">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="data-range">Fullfillment</label>
                          <select style="width:100%" name="pages" class="pages">
                            <option value="" selected="selected">Drop Down</option>
                            <option value="">Normal</option>
                          </select>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="data-range">Payment</label>
                          <select style="width:100%" name="pages" class="pages">
                            <option value="" selected="selected">Drop Down</option>
                            <option value="">Normal</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <h2 for="" class="form__label--medium">SHIPPING</h2>
                          <p>
                            1601 Dove St. <br> Newport Beach, <br/>CA 92660
                          </p>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <h2 for="" class="form__label--medium">BILLING</h2>
                          <p>
                            1601 Dove St. <br> Newport Beach, <br/>CA 92660
                          </p>
                        </div>
                      </div>
                    </div>
                     <hr class="hr--line">
                     <div class="pure-g form__block-floated">
                      <div class="pure-u-1-6 form__group">
                        <div class="form__element-block--first">
                          <div class="preview-box"></div>
                        </div>
                      </div>
                      <div class="pure-u-2-3 form__group">
                        <div class="form__element-block--second">
                          <h2 for="" class="form__label"> x1 Optimum Nutrition Protein Powder </h2>
                        </div>
                      </div>
                      <div class="pure-u-1-6 form__group">
                        <div class="form__element-block--third">
                          <h2 for="" class="form__label">$20.00</h2>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-6 form__group">
                        <div class="form__element-block--first">
                          <div class="preview-box"></div>
                        </div>
                      </div>
                      <div class="pure-u-2-3 form__group">
                        <div class="form__element-block--second">
                          <h2 for="" class="form__label"> x1 Optimum Nutrition Protein Powder </h2>
                        </div>
                      </div>
                      <div class="pure-u-1-6 form__group">
                        <div class="form__element-block--third">
                          <h2 for="" class="form__label">$20.00</h2>
                        </div>
                      </div>
                    </div>
                    <hr class="hr--line">
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <div class="form__element-block--last text-right">
                          <p>
                            Items: <strong>$40.00</strong><br/>
                            Shipping & Handling: <strong>$5.00</strong><br/><br/>

                            Total Before Tax: <strong>$45.00</strong><br/>
                            Estimated Tax to be Collected: <strong>$0.00</strong><br/>
                            Total Paid: <strong>$45.00</strong>
                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <p class="total text-right">
                          Total Paid: <strong>$45.00</strong><br/>
                        </p>
                      </div>
                    </div>
                    <div class="pure-g">
                      <div class="pure-u-1">
                        <div class="pure-u-2-3">
                          <button type="submit" class="button--darkgrey-medium float-left" title="Download">Download</button>
                          <button type="submit" class="button--darkgrey-medium float-left margin-lft-10" title="Resend Invoice">Resend Invoice</button>
                        </div>
                        <div class="pure-u-7-24"><button type="submit" class="button--blue-medium float-right" title="Save">Save</button></div>
                      </div>
                    </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>

        <div class="content__resize">
        <h3>Comp 20</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <h2 for="" class="form__label--medium">Order #1101</h2>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <h2 for="" class="form__label--medium">Order Placed: 9/10/14</h2>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="tracking">Tracking #</label>
                          <input type="email" class="form__group-control" id="name" placeholder="135689">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="data-range">Fullfillment</label>
                          <select style="width:100%" name="pages" class="pages">
                            <option value="" selected="selected">Drop Down</option>
                            <option value="">Normal</option>
                          </select>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="data-range">Payment</label>
                          <select style="width:100%" name="pages" class="pages">
                            <option value="" selected="selected">Drop Down</option>
                            <option value="">Normal</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <h2 for="" class="form__label--medium">SHIPPING</h2>
                          <p>
                            1601 Dove St. <br> Newport Beach, <br/>CA 92660
                          </p>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <h2 for="" class="form__label--medium">BILLING</h2>
                          <p>
                            1601 Dove St. <br> Newport Beach, <br/>CA 92660
                          </p>
                        </div>
                      </div>
                    </div>
                     <hr class="hr--line">
                     <div class="pure-g form__block-floated">
                      <div class="pure-u-1-6 form__group">
                        <div class="form__element-block--first">
                          <div class="preview-box"></div>
                        </div>
                      </div>
                      <div class="pure-u-2-3 form__group">
                        <div class="form__element-block--second">
                          <h2 for="" class="form__label"> x1 Optimum Nutrition Protein Powder </h2>
                        </div>
                      </div>
                      <div class="pure-u-1-6 form__group">
                        <div class="form__element-block--third">
                          <h2 for="" class="form__label">$20.00</h2>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-6 form__group">
                        <div class="form__element-block--first">
                          <div class="preview-box"></div>
                        </div>
                      </div>
                      <div class="pure-u-2-3 form__group">
                        <div class="form__element-block--second">
                          <h2 for="" class="form__label"> x1 Optimum Nutrition Protein Powder </h2>
                        </div>
                      </div>
                      <div class="pure-u-1-6 form__group">
                        <div class="form__element-block--third">
                          <h2 for="" class="form__label">$20.00</h2>
                        </div>
                      </div>
                    </div>
                    <hr class="hr--line">
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <div class="form__element-block--last text-right">
                          <p>
                            Items: <strong>$40.00</strong><br/>
                            Shipping & Handling: <strong>$5.00</strong><br/><br/>

                            Total Before Tax: <strong>$45.00</strong><br/>
                            Estimated Tax to be Collected: <strong>$0.00</strong><br/>
                            Total Paid: <strong>$45.00</strong>
                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <p class="total text-right">
                          Total Paid: <strong>$45.00</strong><br/>
                        </p>
                      </div>
                    </div>
                    <div class="pure-g">
                      <div class="pure-u-1">
                        <button type="submit" class="button--blue-medium float-right margin-lft-10" title="Resend Invoice">Resend Invoice</button>
                        <button type="submit" class="button--blue-medium float-right" title="Download">Download</button>
                      </div>
                    </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="content__resize">
        <h3>Comp 25</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <label class="form__label" for="brand-name">Image Upload</label>
                        <div class="file__input-wrapper">
                          <button class="btn-file-input">SELECT FILES</button>
                          <input type="file" value="" id="image" name="image">
                        </div>
                        <div class="file__input-wrapper">
                          <button class="btn-file-input">SELECT FILES</button>
                          <input type="file" value="" id="image" name="image">
                        </div>
                        <div class="file__input-wrapper">
                          <button class="btn-file-input">SELECT FILES</button>
                          <input type="file" value="" id="image" name="image">
                        </div>
                        <div class="file__input-wrapper">
                          <button class="btn-file-input">SELECT FILES</button>
                          <input type="file" value="" id="image" name="image">
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="sku">SKU</label>
                          <input type="email" class="form__group-control" id="sku" placeholder="Enter SKU">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="product-name">Product Name</label>
                          <input type="email" class="form__group-control" id="product" placeholder="Enter Product Name">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="brand">Brand</label>
                          <input type="text" class="form__group-control" id="brand" placeholder="Enter Brand">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="data-range">Category</label>
                          <select style="width:100%" name="pages" class="pages">
                            <option value="" selected="selected">Category 1</option>
                            <option value="">Category 2</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="price">Price</label>
                          <input type="email" class="form__group-control" id="price" placeholder="Enter Price">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="quantity">Quantity</label>
                          <input type="email" class="form__group-control" id="quantity" placeholder="Enter Quantity">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="price">Weight</label>
                          <div class="pure-u-1 segment__dd">
                            <div class="pure-u-4-5 float-left">
                              <input type="email" class="form__group-control--segment" id="weight" placeholder="Enter Weight">
                            </div>
                            <div class="pure-u-1-5 segment__unit">
                              <select style="width:62px"  name="theme" class="theme-segment">
                                <option value="" selected="selected">oz</option>
                                <option value="">ml</option>
                              </select>
                            </div>
                          </div>
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="radius">Description</label>
                          <input type="email" class="form__group-control textarea--large" id="description" placeholder="Enter Description">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="brand">Option Name</label>
                          <input type="text" class="form__group-control" id="option-name" placeholder="Ex. Size">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="data-range"># of options</label>
                          <select style="width:50%" name="pages" class="pages">
                            <option value="" selected="selected">1</option>
                            <option value="">2</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <hr class="hr--line">
                        <div class="pure-u-1">
                          <?php
                          for($i=0; $i<10;$i++)
                          {
                          ?>
                          <div class="option__table">
                            <div class="pure-u-1-4">Options</div>
                            <div class="pure-u-7-24">$ Additional Price</div>
                            <div class="pure-u-7-24">Additional Price</div>
                            <div class="pure-u-1-8">
                              <select style="width:100%"  name="theme" class="theme-unit">
                                <option value="" selected="selected">.oz</option>
                                <option value="">g</option>
                              </select>
                            </div>
                          </div>
                          <?php
                          }
                          ?>
                        </div>
                      <hr class="hr--line">
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <button title="Add Product Option" class="text__button--blue" type="submit">+ Add Product Option</button>
                      </div>
                    </div>
                    <div class="pure-g">
                      <div class="pure-u-1">
                        <div class="pure-u-2-3">
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="1" type="checkbox" id="input-1">
                                <label for="input-1">Free Shipping</label>
                              </li>
                              <li>
                                <input tabindex="2" type="checkbox" id="input-2" checked>
                                <label for="input-2">Tax Free</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div class="pure-u-7-24"><button title="Save" class="button--blue-medium float-right" type="submit">Save</button></div>
                      </div>
                    </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>

        <div class="content__resize">
        <h3>Comp 10</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <label for="product-name" class="form__label">Language</label>
                        <div class="icheck-list">
                          <ul>
                            <li>
                              <input tabindex="3" type="radio" id="input-3" name="demo-radio">
                              <label for="input-3">English</label>
                            </li>
                            <li>
                              <input tabindex="4" type="radio" id="input-4" name="demo-radio" checked>
                              <label for="input-4">Spanish</label>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="name">Name</label>
                          <input type="text" class="form__group-control" id="name" placeholder="Enter Name">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="brand-name">Brand Name</label>
                          <select style="width:100%" name="pages" class="pages">
                            <option value="" selected="selected">Brand 1</option>
                            <option value="">Brand 2</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="price">Serving Size</label>
                          <div class="pure-u-1 segment__dd">
                            <div class="pure-u-17-24 float-left">
                              <input type="email" class="form__group-control--segment" id="weight" placeholder="Enter Weight">
                            </div>
                            <div class="pure-u-1-5 segment__unit">
                              <select style="width:62px"  name="theme" class="theme-segment">
                                <option value="" selected="selected">oz</option>
                                <option value="">ml</option>
                              </select>
                            </div>
                          </div>
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="name">Servings per container </label>
                          <input type="text" class="form__group-control" id="name" placeholder="">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <div class="form__element-block--first">
                          <input type="email" class="form__group-control textarea--large" id="description" placeholder="Enter Description">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                        <div class="pure-u-1 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="categories">Categories</label>
                            <div class="icheck-list">
                              <ul>
                                <li>
                                  <input tabindex="1" type="checkbox" id="input-1">
                                  <label for="input-1">Low Carb</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">Low Fat</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">High Protein</label>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="categories">Meal Type</label>
                            <div class="icheck-list">
                              <ul>
                                <li>
                                  <input tabindex="1" type="checkbox" id="input-1">
                                  <label for="input-1">Breakfast</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">Lunch</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">Dinner</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">Snacks</label>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1">
                        <div class="scroll-pane">
                          <?php
                          for($i=0; $i<100;$i++)
                          {
                          ?>
                          <div class="option__unit">
                            <div class="pure-u-7-8">Options</div>
                            <div class="pure-u-1-12 text-right">g</div>
                          </div>
                          <?php
                          }
                          ?>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1">
                        <div class="pure-u-2-3">
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="1" type="checkbox" id="input-1">
                                <label for="input-1">Vendor Verified</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div class="pure-u-7-24"><button title="Save" class="button--blue-medium float-right" type="submit">Save</button></div>
                      </div>
                    </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>

        <div class="content__resize">
        <h3>Comp 10b</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <label for="product-name" class="form__label">Language</label>
                        <div class="icheck-list">
                          <ul>
                            <li>
                              <input tabindex="3" type="radio" id="input-3" name="demo-radio">
                              <label for="input-3">English</label>
                            </li>
                            <li>
                              <input tabindex="4" type="radio" id="input-4" name="demo-radio" checked>
                              <label for="input-4">Spanish</label>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="name">Name</label>
                          <input type="text" class="form__group-control" id="name" placeholder="Enter Name">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="brand-name">Brand Name</label>
                          <select style="width:100%" name="pages" class="pages">
                            <option value="" selected="selected">Brand 1</option>
                            <option value="">Brand 2</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="price">Serving Size</label>
                          <div class="pure-u-1 segment__dd">
                            <div class="pure-u-17-24 float-left">
                              <input type="email" class="form__group-control--segment" id="weight" placeholder="Enter Weight">
                            </div>
                            <div class="pure-u-1-5 segment__unit">
                              <select style="width:62px"  name="theme" class="theme-segment">
                                <option value="" selected="selected">oz</option>
                                <option value="">ml</option>
                              </select>
                            </div>
                          </div>
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="name">Servings per container </label>
                          <input type="text" class="form__group-control" id="name" placeholder="">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <div class="form__element-block--first">
                          <input type="email" class="form__group-control textarea--large" id="description" placeholder="Enter Description">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                        <div class="pure-u-1 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="categories">Categories</label>
                            <div class="icheck-list">
                              <ul>
                                <li>
                                  <input tabindex="1" type="checkbox" id="input-1">
                                  <label for="input-1">Low Carb</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">Low Fat</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">High Protein</label>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="categories">Meal Type</label>
                            <div class="icheck-list">
                              <ul>
                                <li>
                                  <input tabindex="1" type="checkbox" id="input-1">
                                  <label for="input-1">Breakfast</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">Lunch</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">Dinner</label>
                                </li>
                                <li>
                                  <input tabindex="2" type="checkbox" id="input-2" checked>
                                  <label for="input-2">Snacks</label>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1">
                        <div class="scroll-pane">
                          <?php
                          for($i=0; $i<100;$i++)
                          {
                          ?>
                          <div class="option__unit">
                            <div class="pure-u-7-8">Options</div>
                            <div class="pure-u-1-12 text-right">g</div>
                          </div>
                          <?php
                          }
                          ?>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1">
                        <div class="pure-u-2-3">
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="1" type="checkbox" id="input-1">
                                <label for="input-1">Vendor Verified</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="pure-u-1 form__group">
                          <label class="form__label" for="brand-name">Image Upload</label>
                          <div class="file__input-wrapper">
                            <button class="btn-file-input">SELECT FILES</button>
                            <input type="file" value="" id="image" name="image">
                          </div>
                      </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <button title="Save" class="button--blue-medium float-right margin-top-75" type="submit">Save</button>
                        </div>
                      </div>
                    </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>


      <div class="clear" style="margin-bottom:50px;"></div>

       <div class="clear" style="margin-bottom:50px;"></div>
        <div class="content__resize">
        <h3>Comp 22</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                  <div class="pure-g form__block-floated">
                    <div class="pure-u-1-2 form__group">
                      <div class="form__element-block--first">
                        <select style="width:100%" name="pages" class="pages">
                          <option value="" selected="selected">Taxes</option>
                          <option value="">Taxes</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <hr class="hr--line">
                  <div class="pure-g form__block-floated">
                    <div class="pure-u-1-2 form__group">
                      <div class="form__element-block--first">
                        <label class="form__label" for="name">Destination</label>
                      </div>
                    </div>
                    <div class="pure-u-1-2 form__group">
                      <div class="form__element-block--last">
                        <label class="form__label" for="data-range">Tax Rate</label>
                      </div>
                    </div>
                  </div>
                  <div class="pure-g form__block-floated">
                    <div class="pure-u-1 form__group">
                      <?php
                      for($i=0; $i<20;$i++)
                     {
                      ?>
                      <div class="total--option">
                        <div class="pure-u-1-2">
                          <a class="close-button" title="close" href="#"></a>
                          <span>California</span>
                        </div>
                        <div class="pure-u-11-24">
                           <span>5%</span>
                        </div>
                      </div>
                      <?php
                      }
                      ?>
                    </div>
                    <hr class="hr--line">
                  </div>
                  <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="zip-code-range">Zip Code Range</label>
                          <input type="text" class="form__group-control" id="name" placeholder="Enter Zip Code Range">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="brand-name">&nbsp;</label>
                          <input type="text" class="form__group-control" id="name" placeholder="Enter Zip Code Range">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="tax-rate">Tax Rate</label>
                          <input type="text" class="form__group-control" id="name" placeholder="Enter Tax Rate">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="">&nbsp;</label>
                          <button title="Add Tax Rate" class="button--blue-medium float-right" type="submit">Add Tax Rate</button>
                        </div>
                      </div>
                    </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>


        <div class="clear" style="margin-bottom:50px;"></div>
        <div class="content__resize">
        <h3>Comp 23</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                  <div class="pure-g form__block-floated">
                    <div class="pure-u-1-2 form__group">
                      <div class="form__element-block--first">
                        <select style="width:100%" name="pages" class="pages">
                          <option value="" selected="selected">Discount</option>
                          <option value="">Discount 1</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <hr class="hr--line">
                  <div class="pure-g form__block-floated">
                    <div class="pure-u-1-2 form__group">
                      <div class="form__element-block--first">
                        <label class="form__label" for="discount-name">Discount Name</label>
                      </div>
                    </div>
                    <div class="pure-u-1-2 form__group">
                      <div class="form__element-block--last">
                        <label class="form__label" for="code">Code</label>
                      </div>
                    </div>
                  </div>
                  <div class="pure-g form__block-floated">
                    <div class="pure-u-1 form__group">
                      <?php
                      for($i=0; $i<20;$i++)
                     {
                      ?>
                      <div class="total--option">
                        <div class="pure-u-1-2">
                          <a class="close-button" title="close" href="#"></a>
                          <span>20% Off Order</span>
                        </div>
                        <div class="pure-u-11-24">
                           <span>20OOFF</span>
                        </div>
                      </div>
                      <?php
                      }
                      ?>
                    </div>
                    <hr class="hr--line">
                  </div>
                  <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="discount-name">Discount Name</label>
                          <input type="text" class="form__group-control" id="name" placeholder="Enter Discount Name">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <div class="pure-u-11-24">
                            <label class="form__label" for="code">Code</label>
                            <input type="text" class="form__group-control" id="name" placeholder="Enter Code">
                            <label class="error">error</label>
                          </div>
                          <div class="pure-u-11-24 float-right">
                            <label class="form__label" for="code">Enter Discount</label>
                            <input type="text" class="form__group-control" id="name" placeholder="%">
                            <label class="error">error</label>
                          </div>
                        </div>
                      </div>
                    </div>
                    <button title="Add Discount" class="button--blue-medium float-right" type="submit">Add Discount</button>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>
        <div class="content__resize">
        <h3>Comp 24</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                  <div class="pure-g form__block-floated">
                    <div class="pure-u-1-2 form__group">
                      <div class="form__element-block--first">
                        <select style="width:100%" name="pages" class="pages">
                          <option value="" selected="selected">Shipping</option>
                          <option value="">Shipping 1</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <hr class="hr--line">
                  <div class="pure-g form__block-floated">
                    <div class="pure-u-11-24 form__group">
                      <div class="form__element-block--first">
                        <label class="form__label" for="discount-name">Discount Name</label>
                      </div>
                    </div>
                    <div class="pure-u-1-5 form__group">
                      <div class="form__element-block--second">
                        <label class="form__label" for="weight">Weight</label>
                      </div>
                    </div>
                    <div class="pure-u-1-6 form__group">
                      <div class="form__element-block--third">
                        <label class="form__label" for="location">Location</label>
                      </div>
                    </div>
                    <div class="pure-u-1-6 form__group">
                      <div class="form__element-block--last">
                        <label class="form__label" for="rate">Rate</label>
                      </div>
                    </div>
                  </div>
                  <div class="pure-g form__block-floated">
                    <div class="pure-u-1 form__group">
                      <?php
                      for($i=0; $i<20;$i++)
                     {
                      ?>
                      <div class="total--option">
                        <div class="pure-u-11-24">
                          <a class="close-button" title="close" href="#"></a>
                          <span>Standard Rate</span>
                        </div>
                        <div class="pure-u-1-5">
                           <span>0.0 lb-5.0lb</span>
                        </div>
                        <div class="pure-u-1-6">
                           <span>USA</span>
                        </div>
                        <div class="pure-u-1-8">
                           <span>$10.00</span>
                        </div>
                      </div>
                      <?php
                      }
                      ?>
                    </div>
                    <hr class="hr--line">
                  </div>
                  <div class="pure-g form__block-floated">
                    <div class="pure-u-1-2 form__group">
                      <div class="form__element-block--first">
                        <label class="form__label" for="shipping-name">Shipping Name</label>
                        <input type="text" class="form__group-control" id="shipping-name" placeholder="Enter Shipping Name">
                        <label class="error">error</label>
                      </div>
                    </div>
                    <div class="pure-u-1-2 form__group">
                      <div class="form__element-block--second">
                        <label class="form__label" for="price">Weight</label>
                        <div class="pure-u-1 segment__dd">
                          <div class="pure-u-17-24 float-left">
                            <input type="email" class="form__group-control--segment" id="weight" placeholder="Enter Weight">
                          </div>
                          <div class="pure-u-1-5 segment__unit">
                            <select style="width:62px"  name="theme" class="theme-segment">
                              <option value="" selected="selected">oz</option>
                              <option value="">ml</option>
                            </select>
                          </div>
                        </div>
                        <label class="error">error</label>
                      </div>
                    </div>
                  </div>
                  <div class="pure-g form__block-floated">
                    <div class="pure-u-1-2 form__group">
                      <div class="form__element-block--first">
                        <label class="form__label" for="brand-name">Location</label>
                          <select style="width:100%" name="pages" class="pages">
                            <option value="" selected="selected">Location 1</option>
                            <option value="">Location 2</option>
                          </select>
                      </div>
                    </div>
                    <div class="pure-u-1-2 form__group">
                      <div class="form__element-block--second">
                        <label class="form__label" for="shipping-name">Price</label>
                        <input type="text" class="form__group-control" id="price" placeholder="Enter Price">
                        <label class="error">error</label>
                      </div>
                    </div>
                  </div>
                  <button title="Add Rate" class="button--blue-medium float-right" type="submit">Add Rate</button>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

        <div class="clear" style="margin-bottom:50px;"></div>

        <div class="content__resize">
        <h3>Comp 13</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked">
                <fieldset>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="business-name">Business Name</label>
                          <input type="email" class="form__group-control" id="name" placeholder="Enter Business Name">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="categories">Categories</label>
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="1" type="checkbox" id="input-1">
                                <label for="input-1">Low Carb</label>
                              </li>
                              <li>
                                <input tabindex="2" type="checkbox" id="input-2" checked>
                                <label for="input-2">Low Fat</label>
                              </li>
                              <li>
                                <input tabindex="3" type="checkbox" id="input-3" checked>
                                <label for="input-3">High Protein</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="data-range">Address</label>
                          <input type="email" class="form__group-control" id="address" placeholder="Enter Address">
                          <label class="error">error</label>
                          <div class="pure-g">
                            <div class="pure-u-1 form__group">
                              <input type="email" class="form__group-control" id="address" placeholder="Enter Address">
                              <label class="error">error</label>
                            </div>
                          </div>
                          <div class="pure-g">
                            <div class="pure-u-1 form__group">
                              <div class="pure-u-1-2 float-left">
                                <select style="width:100%" name="pages" class="pages">
                                  <option value="" selected="selected">Location 1</option>
                                  <option value="">Location 2</option>
                                </select>
                              </div>
                              <div class="pure-u-5-12 float-right">
                                <input type="email" class="form__group-control" id="address" placeholder="Enter Address">
                                <label class="error">error</label>
                              </div>
                          </div>
                          </div>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="data-range">Phone</label>
                          <input type="email" class="form__group-control" id="phone" placeholder="Enter Phone">
                          <label class="error">error</label>
                          <label class="form__label" for="data-range">URL</label>
                          <input type="email" class="form__group-control" id="url" placeholder="Enter URL">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="data-range">Radius</label>
                          <input type="email" class="form__group-control" id="radius" placeholder="Enter Radius">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="data-range">&nbsp;</label>
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="1" type="checkbox" id="input-1">
                                <label for="input-1">All</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <label class="form__label" for="brand-name">Image Upload</label>
                        <div class="file__input-wrapper">
                          <button class="btn-file-input">SELECT FILES</button>
                          <input type="file" value="" id="image" name="image">
                        </div>
                        <div class="file__input-wrapper">
                          <button class="btn-file-input">SELECT FILES</button>
                          <input type="file" value="" id="image" name="image">
                        </div>
                        <div class="file__input-wrapper">
                          <button class="btn-file-input">SELECT FILES</button>
                          <input type="file" value="" id="image" name="image">
                        </div>
                        <div class="file__input-wrapper">
                          <button class="btn-file-input">SELECT FILES</button>
                          <input type="file" value="" id="image" name="image">
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <label class="form__label" for="brand-name">Business Hours</label>
                        <div class="pure-u-4-5 form__group">
                          <div class="pure-u-7-24">&nbsp;</div>
                          <div class="pure-u-7-24">
                            <label class="form__label" for="open">Open</label>
                          </div>
                          <div class="pure-u-1-4">
                            <label class="form__label" for="close">Close</label>
                          </div>
                        </div>
                        <?php
                        for($i=0; $i<8;$i++)
                        {
                        ?>
                        <div class="pure-u-4-5 form__group">
                          <div class="pure-u-7-24"><label class="form__label" for="Monday">Monday</label></div>
                          <div class="pure-u-7-24">
                            <select style="width:100%" name="pages" class="pages">
                              <option value="" selected="selected">Open</option>
                              <option value="">Open</option>
                            </select>
                          </div>
                          <div class="pure-u-7-24">
                            <select style="width:100%" name="pages" class="pages">
                              <option value="" selected="selected">Open</option>
                              <option value="">Open</option>
                            </select>
                          </div>
                        </div>
                        <?php
                        }
                        ?>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-2 form__group">
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="1" type="checkbox" id="input-1">
                                <label for="input-1">Premium Listing</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label" for="radius">Business Description</label>
                            <input type="email" class="form__group-control textarea--large" id="business-description" placeholder="">
                            <label class="error">error</label>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g">
                      <div class="pure-u-1">
                        <button type="submit" class="button--blue-medium float-right" title="Save">Save</button>
                      </div>
                    </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>

      </div>


      <!-- This contains the hidden content for inline calls -->
      <div style='display:none'>
        <div id='inline-content' class='popup__inner'>
          <div class="padding-lft-20 padding-rgt-20">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>
        </div>
      </div>

      <!-- ui-dialog -->
      <div id="dialog" title="Please Confirm">
        <p class="font16px">Are you sure you want to <br>deactivate this user?</p>
      </div>



      <!-- JavaScript -->
      <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
      <script src="js/colorbox/jquery.colorbox.js"></script>
      <script src="js/jQueryUI/jquery-ui.js"></script>
      <script src="js/tooltipster/jquery.tooltipster.min.js"></script>
      <script src="js/common.js" ></script>

      <script src="js/iCheck/icheck.js"></script>
      <script src="js/msdropdown/jquery.dd.js"></script>
      <script src="js/jScroll/jquery.jscrollpane.js"></script>
      <script src="js/jScroll/jquery.mousewheel.js"></script>

      <!--[if gt IE 9]><!-->
        <script src="//cdnjs.cloudflare.com/ajax/libs/html-inspector/0.8.1/html-inspector.js"></script>
        <script>
          HTMLInspector.inspect({
            excludeElements: ["svg", "iframe", "html"]
          })
        </script>
      <!--<![endif]-->

      <script>
        $(document).ready(function(){


          $(".inline").colorbox({inline:true, width:"50%"});


          $( "#dialog" ).dialog({
            autoOpen: false,
            width: 340,
            modal: true,
            buttons: [
              {
                text: "No, Cancel Request",
                click: function() {
                  $( this ).dialog( "close" );
                }
              },
              {
                text: "Yes, Deactivate User",
                click: function() {
                  $( this ).dialog( "close" );
                }
              }
            ]
          });
          $( "#dialog-link" ).click(function( event ) {
            $( "#dialog" ).dialog( "open" );
            event.preventDefault();
          });


          var callbacks_list = $('.icheck-callbacks ul');
          $('.icheck-list input').on('ifCreated ifClicked ifChanged ifChecked ifUnchecked ifDisabled ifEnabled ifDestroyed', function(event){
            callbacks_list.prepend('<li><span>#' + this.id + '</span> is ' + event.type.replace('if', '').toLowerCase() + '</li>');
          }).iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%'
          });


          $(".pages, .module-management").msDropdown().data("dd");//{animStyle:'none'} /{animStyle:'slideDown'} {animStyle:'show'}
          $(".theme-unit").msDropdown({mainCSS:'dd2'});
          $(".theme-three").msDropdown({mainCSS:'dd2'});
          $(".theme-segment").msDropdown({mainCSS:'dd3'});

          $('.tooltip').tooltipster({
            autoClose: false,
            minWidth: 230,
              content: $('<div class="pure-g"><span class="bold pure-u-1">Add new category</span><div class="clear"></div><div class="pure-u-3-4"><div class="form__element-block--first"><input type="text" class="form__group-control" placeholder="Category Name"></div></div><div class="pure-u-1-4"><input class="button--green-small" type="button" value="Add"></div></div>')
          });

          $('.scroll-pane').jScrollPane();
        });
      </script>

    </body>
</html>
