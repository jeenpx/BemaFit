
<!DOCTYPE html>
<html class="no-js" lang="en-us">
    <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title>Flex Your Macros</title>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge">

      <link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/pure-min.css">
      <!--[if lte IE 8]>
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/grids-responsive-old-ie-min.css">
      <![endif]-->
      <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/grids-responsive-min.css">
      <!--<![endif]-->
      <link rel="stylesheet" href="css/common-base.css" media="screen, projection" />
      <link rel="stylesheet" href="css/base.css" media="screen, projection" />
      <link rel="stylesheet" href="css/print.css" media="print" />
      <link rel="stylesheet" href="css/_forms.css" media="screen, projection" />
      <link rel="stylesheet" href="css/colorbox/colorbox.css" media="screen, projection" />
      <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
      <!--[if lt IE 9]>
        <script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
      <![endif]-->

      <link rel="stylesheet" href="css/msdropdown/dd.css" media="screen, projection" />
      <link rel="stylesheet" href="css/iCheck/all.css" media="screen, projection" />

      <link rel="Shortcut Icon" href="images/favicon.png" type="image/x-icon" />
    </head>

    <body>

      <div class="wrapper">

        <header class="header">
          <div class="header__resize">
            <div class="header__user-account">
              <a href="" title="">Logout</a>
            </div>
            <div class="header__user-activity">
              <div class="header__logo">
                <h1><a href="#">FYM</a></h1>
              </div>
              <div class="header__module-management">
                <select class="module-management">
                  <option value="" selected="selected">User Management</option>
                  <option value="">Meal Management</option>
                </select>
              </div>
              <div class="clear"></div>
            </div>
          </div>
        </header>

        <section class="content">

          <div class="content__resize">
            <div class="content__breadcrumb">

            </div>
            <div class="content__table">
              <div class="content__table-top pure-g">
                <div class="pure-u-1-2">
                  <div class="content__table-top__select">
                    <input class="button--green-large" type="button" value="+Add Ad">
                  </div>
                </div>
                <div class="pure-u-1-2">
                  <div class="content__table-top__search">
                    <input type="text" class="form__group-control" id="" placeholder="Search...">
                  </div>
                  <div class="content__table-top__filter">
                    <a href="" class="show-filter">+ Show Filters</a>
                    <a href="" class="hide-filter">- Hide Filters</a>
                  </div>
                </div>
              </div>

              <div class="content__table-top__filter-content pure-g">
                <div class="pure-u-1-3 padding-btm-25">
                  <div class="pure-u-2-5 float-left icheck-list">
                    <label class="form__label" for="user-name">Categories</label>
                    <div class="clear"></div>
                    <input tabindex="1" type="checkbox" id="">
                    <label for="">Web: Sidebar</label>
                    <div class="clear"></div>
                    <input tabindex="1" type="checkbox" id="">
                    <label for="">Web: Newsfeed</label>
                    <div class="clear"></div>
                    <input tabindex="1" type="checkbox" id="">
                    <label for="">Web: Guest Post</label>
                    <div class="clear"></div>
                  </div>
                  <div class="pure-u-2-5 float-left icheck-list">
                    <label class="form__label" for="user-name">&nbsp;</label>
                    <div class="clear"></div>
                    <input tabindex="1" type="checkbox" id="">
                    <label for="">Web: Sidebar</label>
                    <div class="clear"></div>
                    <input tabindex="1" type="checkbox" id="">
                    <label for="">Web: Newsfeed</label>
                    <div class="clear"></div>
                    <input tabindex="1" type="checkbox" id="">
                    <label for="">Web: Guest Post</label>
                    <div class="clear"></div>
                  </div>
                </div>
                <div class="pure-u-1-2">
                  <div class="pure-u-1-2 float-left icheck-list">
                    <label class="form__label" for="user-name">Radius</label>
                    <div class="clear"></div>
                    <input type="text" class="form__group-control float-left" id="" placeholder="State, Zip">
                    <div class="clear"></div>
                    <ul class="tags">
                      <li><a href="">California</a></li>
                    </ul>
                  </div>
                  <div class="pure-u-1-2 float-left icheck-list padding-top-23 padding-lft-05">
                    <input tabindex="1" type="checkbox" id="">
                    <label for="">All</label>
                  </div>
                </div>
              </div>

              <table class="common-table">
                <tr>
                  <th width="14%"><span class="sortable">NAME</span><span class="table-sort"></span></th>
                  <th width="14%">LOCATION</th>
                  <th width="14%">URL</th>
                  <th width="12%"><span class="sortable">START DATE</span><span class="table-sort"></span></th>
                  <th width="11%"><span class="sortable">END DATE</span><span class="table-sort"></span></th>
                  <th width="10%">TARGET</th>
                  <th width="24%">MANAGE</th>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">24 Hour Fitness</a></td>
                  <td>Website: Sidebar</td>
                  <td>www.24hour...</td>
                  <td>10/01/14</td>
                  <td>10/01/14</td>
                  <td>92629, CA</td>
                  <td class="has-button"><input class="button--darkgrey margin-rgt-10" type="button" value="Copy"><input class="button--red" type="button" value="Remove"></td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">24 Hour Fitness</a></td>
                  <td>Website: Sidebar</td>
                  <td>www.24hour...</td>
                  <td>10/01/14</td>
                  <td>10/01/14</td>
                  <td>92629, CA</td>
                  <td class="has-button"><input class="button--darkgrey margin-rgt-10" type="button" value="Copy"><input class="button--red" type="button" value="Remove"></td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">24 Hour Fitness</a></td>
                  <td>Website: Sidebar</td>
                  <td>www.24hour...</td>
                  <td>10/01/14</td>
                  <td>10/01/14</td>
                  <td>92629, CA</td>
                  <td class="has-button"><input class="button--darkgrey margin-rgt-10" type="button" value="Copy"><input class="button--red" type="button" value="Remove"></td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">24 Hour Fitness</a></td>
                  <td>Website: Sidebar</td>
                  <td>www.24hour...</td>
                  <td>10/01/14</td>
                  <td>10/01/14</td>
                  <td>92629, CA</td>
                  <td class="has-button"><input class="button--darkgrey margin-rgt-10" type="button" value="Copy"><input class="button--red" type="button" value="Remove"></td>
                </tr>
                <tr>
                  <td class="bold"><a href="" class="user__name">24 Hour Fitness</a></td>
                  <td>Website: Sidebar</td>
                  <td>www.24hour...</td>
                  <td>10/01/14</td>
                  <td>10/01/14</td>
                  <td>92629, CA</td>
                  <td class="has-button"><input class="button--darkgrey margin-rgt-10" type="button" value="Copy"><input class="button--red" type="button" value="Remove"></td>
                </tr>

              </table>
            </div>
            <div class="content__pagination">
              <ul class="content__pagination-list">
                <li class="active"><a href="">1</a></li>
                <li><a href="">2</a></li>
                <li><a href="">3</a></li>
                <li><a href="">4</a></li>
                <li class="content__pagination-list__pagination--dots"><a href="">...</a></li>
                <li><a href="">10</a></li>
                <li><a href="">11</a></li>
                <li><a href="" title="Next">Next</a></li>
              </ul>
            </div>
          </div>
          <div class="clear"></div>
        </section>

      </div>



      <!-- JavaScript -->
      <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
      <script src="js/colorbox/jquery.colorbox.js"></script>
      <script src="js/common.js" ></script>

      <script src="js/iCheck/icheck.js"></script>
      <script src="js/msdropdown/jquery.dd.min.js"></script>


      <script>
        $(document).ready(function(){


          $(".inline").colorbox({inline:true, width:"50%"});

          var callbacks_list = $('.icheck-callbacks ul');
          $('.icheck-list input').on('ifCreated ifClicked ifChanged ifChecked ifUnchecked ifDisabled ifEnabled ifDestroyed', function(event){
            callbacks_list.prepend('<li><span>#' + this.id + '</span> is ' + event.type.replace('if', '').toLowerCase() + '</li>');
          }).iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%'
          });


          $(".user-status, .module-management, .brand-management, .rebate-management").msDropdown().data("dd");//{animStyle:'none'} /{animStyle:'slideDown'} {animStyle:'show'}


          $('.hide-filter, .content__table-top__filter-content').hide();
          $('.show-filter').on('click', function(){
            $('.show-filter').hide();
            $('.hide-filter').fadeIn();
            $('.content__table-top__filter-content').fadeIn();
            return false;
          });
          $('.hide-filter').on('click', function(){
            $('.hide-filter').hide();
            $('.show-filter').fadeIn();
            $('.content__table-top__filter-content').hide();
            return false;
          });


        });
      </script>

    </body>
</html>
