
<!DOCTYPE html>
<html class="no-js" lang="en-us">
    <head>
    	<meta charset="utf-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title>Flex Your Macros</title>
    	<meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge">

    	<link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/pure-min.css">
      <!--[if lte IE 8]>
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/grids-responsive-old-ie-min.css">
      <![endif]-->
      <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/grids-responsive-min.css">
      <!--<![endif]-->
    	<link rel="stylesheet" href="css/common-base.css" media="screen, projection" />
    	<link rel="stylesheet" href="css/base.css" media="screen, projection" />
		  <link rel="stylesheet" href="css/print.css" media="print" />
      <link rel="stylesheet" href="css/_forms.css" media="screen, projection" />
      <link rel="stylesheet" href="css/colorbox/colorbox.css" media="screen, projection" />
      <link rel="stylesheet" href="css/jQueryUI/jquery-ui.css" media="screen, projection">
      <link rel="stylesheet" href="css/tooltipster/tooltipster.css" media="screen, projection">
      <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
      <!--[if lt IE 9]>
        <script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
      <![endif]-->

      <link rel="stylesheet" href="css/msdropdown/dd.css" media="screen, projection" />
      <link rel="stylesheet" href="css/iCheck/all.css" media="screen, projection" />
      <link rel="stylesheet" href="css/jScroll/jquery.jscrollpane.css" media="screen, projection" />

		  <link rel="Shortcut Icon" href="images/favicon.png" type="image/x-icon" />
    </head>

    <body>

      <div class="wrapper">

        <header class="header">
          <div class="header__resize">
            <div class="header__user-account">
              <a href="" title="">Logout</a>
            </div>
            <div class="header__user-activity">
              <div class="header__logo">
                <h1><a href="#">FYM</a></h1>
              </div>
              <div class="header__module-management">

              </div>
              <div class="clear"></div>
            </div>
          </div>
        </header>


         <div class="clear" style="margin-bottom:50px;"></div>

        <div class="content__resize">
        <h3>Add Meal (10b)</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked" action="#">
                <fieldset>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <label class="form__label">Language</label>
                        <div class="icheck-list">
                          <ul>
                            <li>
                              <input tabindex="11" type="radio" id="english" name="demo-radio">
                              <label for="english">English</label>
                            </li>
                            <li>
                              <input tabindex="12" type="radio" id="spanish" name="demo-radio" checked>
                              <label for="spanish">Spanish</label>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="name">Name</label>
                          <input type="text" class="form__group-control" id="name" placeholder="">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="brand-name">Brand Name</label>
                          <input type="text" id="brand-name" class="form__group-control" placeholder="">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="price">Serving Size</label>
                          <div class="pure-u-1 segment__dd">
                            <div class="pure-u-2-3 float-left">
                              <input type="email" id="price" class="form__group-control--segment no-top-margin" placeholder="">
                            </div>
                            <div class="pure-u-1-5 segment__unit no-top-margin">
                              <select style="width:62px"  name="theme" class="theme-segment">
                                <option selected="selected">oz</option>
                                <option>ml</option>
                              </select>
                            </div>
                          </div>
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="name">Servings per container </label>
                          <input type="text" id="servings-per-container" class="form__group-control" placeholder="">
                          <label class="error">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <textarea rows="1" cols="1" class="form__group-control textarea--large" placeholder=""></textarea>
                        <label class="error">error</label>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                        <div class="pure-u-1 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label">Categories</label>
                            <div class="icheck-list">
                              <ul>
                                <li>
                                  <input tabindex="13" type="checkbox" id="low-carb">
                                  <label for="low-carb">Low Carb</label>
                                </li>
                                <li>
                                  <input tabindex="14" type="checkbox" id="low-fat">
                                  <label for="low-fat">Low Fat</label>
                                </li>
                                <li>
                                  <input tabindex="15" type="checkbox" id="high-protein">
                                  <label for="high-protein">High Protein</label>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1 form__group">
                          <div class="form__element-block--first">
                            <label class="form__label">Meal Type</label>
                            <div class="icheck-list">
                              <ul>
                                <li>
                                  <input tabindex="16" type="checkbox" id="breakfast">
                                  <label for="breakfast">Breakfast</label>
                                </li>
                                <li>
                                  <input tabindex="17" type="checkbox" id="lunch" checked>
                                  <label for="lunch">Lunch</label>
                                </li>
                                <li>
                                  <input tabindex="18" type="checkbox" id="dinner" checked>
                                  <label for="dinner">Dinner</label>
                                </li>
                                <li>
                                  <input tabindex="19" type="checkbox" id="snacks" checked>
                                  <label for="snacks">Snacks</label>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1">
                        <div class="scroll-pane">
                          <?php
                          for($i=0; $i<100;$i++)
                          {
                          ?>
                          <div class="option__unit">
                            <div class="pure-u-7-8">Options</div>
                            <div class="pure-u-1-12 text-right">g</div>
                          </div>
                          <?php
                          }
                          ?>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1">
                        <div class="pure-u-2-3">
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="20" type="checkbox" id="input-20">
                                <label for="input-20">Vendor Verified</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated no-btm-margin ">
                      <div class="pure-u-3-5 form__group no-btm-margin ">
                        <div class="form__element-block--first no-btm-margin ">
                          <label class="form__label" for="brand-name">Image Upload</label>
                          <div class="file__input-wrapper">
                            <button class="btn-file-input">SELECT FILES</button>
                            <input type="file" id="image" name="image">
                          </div>
                        </div>
                        <div class="pure-u-1-2 limit-size"><p>Maximun Size <br>700px x 700px</p></div>
                      </div>
                      <div class="pure-u-2-5 form__group no-btm-margin ">
                        <div class="form__element-block--last">
                        <label class="form__label" for="radius">&nbsp;</label>
                          <button type="submit" class="button--blue-medium float-right margin-top-78 " title="Save">Save</button>
                        </div>
                      </div>
                    </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>


        <div class="clear" style="margin-bottom:50px;"></div>

      </div>


      <!-- This contains the hidden content for inline calls -->
      <div style='display:none'>
        <div id='inline-content' class='popup__inner'>
          <div class="padding-lft-20 padding-rgt-20">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>
        </div>
      </div>

      <!-- ui-dialog -->
      <div id="dialog" title="Please Confirm">
        <p class="font16px">Are you sure you want to <br>deactivate this user?</p>
      </div>



      <!-- JavaScript -->
      <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
      <script src="js/colorbox/jquery.colorbox.js"></script>
      <script src="js/jQueryUI/jquery-ui.js"></script>
      <script src="js/tooltipster/jquery.tooltipster.min.js"></script>
      <script src="js/common.js" ></script>

      <script src="js/iCheck/icheck.js"></script>
      <script src="js/msdropdown/jquery.dd.js"></script>
      <script src="js/jScroll/jquery.jscrollpane.js"></script>
      <script src="js/jScroll/jquery.mousewheel.js"></script>

      <!--[if gt IE 9]><!-->
        <script src="//cdnjs.cloudflare.com/ajax/libs/html-inspector/0.8.1/html-inspector.js"></script>
        <script>
          HTMLInspector.inspect({
            excludeElements: ["svg", "iframe", "html"]
          })
        </script>
      <!--<![endif]-->

      <script>
        $(document).ready(function(){


          $(".inline").colorbox({inline:true, width:"50%"});


          $( "#dialog" ).dialog({
            autoOpen: false,
            width: 340,
            modal: true,
            buttons: [
              {
                text: "No, Cancel Request",
                click: function() {
                  $( this ).dialog( "close" );
                }
              },
              {
                text: "Yes, Deactivate User",
                click: function() {
                  $( this ).dialog( "close" );
                }
              }
            ]
          });
          $( "#dialog-link" ).click(function( event ) {
            $( "#dialog" ).dialog( "open" );
            event.preventDefault();
          });


          var callbacks_list = $('.icheck-callbacks ul');
          $('.icheck-list input').on('ifCreated ifClicked ifChanged ifChecked ifUnchecked ifDisabled ifEnabled ifDestroyed', function(event){
            callbacks_list.prepend('<li><span>#' + this.id + '</span> is ' + event.type.replace('if', '').toLowerCase() + '</li>');
          }).iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%'
          });


          $(".pages").msDropdown().data("dd");//{animStyle:'none'} /{animStyle:'slideDown'} {animStyle:'show'}
          $(".theme-unit").msDropdown({mainCSS:'dd2'});
          //$(".theme-three").msDropdown({mainCSS:'dd2'});
          $(".theme-segment").msDropdown({mainCSS:'dd3'});

          $('.tooltip').tooltipster({
            autoClose: false,
            minWidth: 230,
              content: $('<div class="pure-g"><span class="bold pure-u-1">Add new category</span><div class="clear"></div><div class="pure-u-3-4"><div class="form__element-block--first"><input type="text" class="form__group-control" placeholder="Category Name"></div></div><div class="pure-u-1-4"><input class="button--green-small" type="button" value="Add"></div></div>')
          });

          $('.scroll-pane').jScrollPane();
        });
      </script>

    </body>
</html>
