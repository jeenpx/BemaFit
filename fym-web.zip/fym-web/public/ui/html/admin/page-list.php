
<!DOCTYPE html>
<html class="no-js" lang="en-us">
    <head>
    	<meta charset="utf-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title>Flex Your Macros</title>
    	<meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge">

    	<link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/pure-min.css">
      <!--[if lte IE 8]>
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/grids-responsive-old-ie-min.css">
      <![endif]-->
      <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/grids-responsive-min.css">
      <!--<![endif]-->
    	<link rel="stylesheet" href="css/common-base.css" media="screen, projection" />
    	<link rel="stylesheet" href="css/base.css" media="screen, projection" />
		  <link rel="stylesheet" href="css/print.css" media="print" />
      <link rel="stylesheet" href="css/_forms.css" media="screen, projection" />
      <link rel="stylesheet" href="css/colorbox/colorbox.css" media="screen, projection" />
      <link rel="stylesheet" href="css/jQueryUI/jquery-ui.css" media="screen, projection">
      <link rel="stylesheet" href="css/tooltipster/tooltipster.css" media="screen, projection">
      <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
      <!--[if lt IE 9]>
        <script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
      <![endif]-->

      <link rel="stylesheet" href="css/msdropdown/dd.css" media="screen, projection" />
      <link rel="stylesheet" href="css/iCheck/all.css" media="screen, projection" />
      <link rel="stylesheet" href="css/jScroll/jquery.jscrollpane.css" media="screen, projection" />

		  <link rel="Shortcut Icon" href="images/favicon.png" type="image/x-icon" />
      <style type="text/css">
body {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 12px;
  background:url(page-bg.jpg) repeat;
  margin: auto;
}
#container {
  height: auto!important;
  min-height: 650px;
  text-align: center;
}
</style>
    </head>

    <body>

      <div class="wrapper">

        <header class="header">
          <div class="header__resize">
            <div class="header__user-account">
              <a href="" title="">Logout</a>
            </div>
            <div class="header__user-activity">
              <div class="header__logo">
                <h1><a href="#">FYM</a></h1>
              </div>
              <div class="header__module-management">

              </div>
              <div class="clear"></div>
            </div>
          </div>
        </header>
        <div id="container"><br />
  <table width="419" border="0" align="center" cellpadding="0" cellspacing="2" style="border:1px solid #666; background:#fff;" >
    <tr>
      <td height="67" align="center" background="header.png"><h1 style="color:#000"></h1></td>
    </tr>
    <tr>
      <td height="40" align="center" valign="middle" bgcolor="" style="color:#FFF;font-size:16px;font-weight:bold; background-color:#333;"></td>
    </tr>

    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#dadada" style="color:#333;font-size:16px;font-weight:bold;">POP UP</td>
    </tr>
      <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="add-meal-popup.php" target="_blank" style="color:#000;">Add Meal</a></td>
    </tr>
     <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="add-meal-2-popup.php" target="_blank" style="color:#000;">Add Meal (10b)</a></td>
    </tr>
     <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="add-business-popup.php" target="_blank" style="color:#000;">Add Business (13)</a></td>
    </tr>
     <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="add-ad-popup.php" target="_blank" style="color:#000;">Add Ad (15)</a></td>
    </tr>
       <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="add-ad-2-popup.php" target="_blank" style="color:#000;">Add Ad (15b)</a></td>
    </tr>
    </tr>
       <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="exercise-popup.php" target="_blank" style="color:#000;">Exercise (32b)</a></td>
    </tr>
    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="manage-category-popup.php" target="_blank" style="color:#000;">Manage Category</a></td>
    </tr>
    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#dadada" style="color:#333;font-size:16px;font-weight:bold;">LOGIN/FORGOT PASS</td>
    </tr>
    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="login.php" target="_blank" style="color:#000;">Login/Forgot Pass</a></td>
    </tr>
    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#dadada" style="color:#333;font-size:16px;font-weight:bold;">USER MANAGEMENT</td>
    </tr>
    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="user-management.php" target="_blank" style="color:#000;">User Management</a></td>
    </tr>
    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#dadada" style="color:#333;font-size:16px;font-weight:bold;">MEAL MANAGEMENT</td>
    </tr>
    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="meal-management.php" target="_blank" style="color:#000;">Meal Management</a></td>
    </tr>
    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#dadada" style="color:#333;font-size:16px;font-weight:bold;">BUSINESS DIRECTORY</td>
    </tr>
    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="business-directory.php" target="_blank" style="color:#000;">Business Directory</a></td>
    </tr>
     <tr>
      <td height="30" align="center" valign="middle" bgcolor="#dadada" style="color:#333;font-size:16px;font-weight:bold;">AD MANAGEMENT</td>
    </tr>
    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="ad-management.php" target="_blank" style="color:#000;">Ad Management</a></td>
    </tr>
    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#dadada" style="color:#333;font-size:16px;font-weight:bold;">EXERCISE MANAGEMENT</td>
    </tr>
    <tr>
      <td height="30" align="center" valign="middle" bgcolor="#FFFFFF"><a href="exercise-management.php" target="_blank" style="color:#000;">Exercise Management</a></td>
    </tr>
    </table>

      </div>



      <!-- JavaScript -->
      <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
      <script src="js/colorbox/jquery.colorbox.js"></script>
      <script src="js/jQueryUI/jquery-ui.js"></script>
      <script src="js/tooltipster/jquery.tooltipster.min.js"></script>
      <script src="js/common.js" ></script>

      <script src="js/iCheck/icheck.js"></script>
      <script src="js/msdropdown/jquery.dd.js"></script>
      <script src="js/jScroll/jquery.jscrollpane.js"></script>
      <script src="js/jScroll/jquery.mousewheel.js"></script>

      <!--[if gt IE 9]><!-->
        <script src="//cdnjs.cloudflare.com/ajax/libs/html-inspector/0.8.1/html-inspector.js"></script>
        <script>
          HTMLInspector.inspect({
            excludeElements: ["svg", "iframe", "html"]
          })
        </script>
      <!--<![endif]-->

      <script>
        $(document).ready(function(){


          $(".inline").colorbox({inline:true, width:"50%"});


          $( "#dialog" ).dialog({
            autoOpen: false,
            width: 340,
            modal: true,
            buttons: [
              {
                text: "No, Cancel Request",
                click: function() {
                  $( this ).dialog( "close" );
                }
              },
              {
                text: "Yes, Deactivate User",
                click: function() {
                  $( this ).dialog( "close" );
                }
              }
            ]
          });
          $( "#dialog-link" ).click(function( event ) {
            $( "#dialog" ).dialog( "open" );
            event.preventDefault();
          });


          var callbacks_list = $('.icheck-callbacks ul');
          $('.icheck-list input').on('ifCreated ifClicked ifChanged ifChecked ifUnchecked ifDisabled ifEnabled ifDestroyed', function(event){
            callbacks_list.prepend('<li><span>#' + this.id + '</span> is ' + event.type.replace('if', '').toLowerCase() + '</li>');
          }).iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%'
          });


          $(".pages").msDropdown().data("dd");//{animStyle:'none'} /{animStyle:'slideDown'} {animStyle:'show'}
          $(".theme-unit").msDropdown({mainCSS:'dd2'});
          $(".theme-three").msDropdown({mainCSS:'dd2'});
          $(".theme-segment").msDropdown({mainCSS:'dd3'});

          $('.tooltip').tooltipster({
            autoClose: false,
            minWidth: 230,
              content: $('<div class="pure-g"><span class="bold pure-u-1">Add new category</span><div class="clear"></div><div class="pure-u-3-4"><div class="form__element-block--first"><input type="text" class="form__group-control" placeholder="Category Name"></div></div><div class="pure-u-1-4"><input class="button--green-small" type="button" value="Add"></div></div>')
          });

          $('.scroll-pane').jScrollPane();
        });
      </script>

    </body>
</html>
