
<!DOCTYPE html>
<html class="no-js" lang="en-us">
    <head>
    	<meta charset="utf-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title>Flex Your Macros</title>
    	<meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge">

    	<link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/pure-min.css">
      <!--[if lte IE 8]>
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/grids-responsive-old-ie-min.css">
      <![endif]-->
      <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="//yui.yahooapis.com/pure/0.5.0/grids-responsive-min.css">
      <!--<![endif]-->
    	<link rel="stylesheet" href="css/common-base.css" media="screen, projection" />
    	<link rel="stylesheet" href="css/base.css" media="screen, projection" />
		  <link rel="stylesheet" href="css/print.css" media="print" />
      <link rel="stylesheet" href="css/_forms.css" media="screen, projection" />
      <link rel="stylesheet" href="css/colorbox/colorbox.css" media="screen, projection" />
      <link rel="stylesheet" href="css/jQueryUI/jquery-ui.css" media="screen, projection">
      <link rel="stylesheet" href="css/tooltipster/tooltipster.css" media="screen, projection">
      <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
      <!--[if lt IE 9]>
        <script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
      <![endif]-->

      <link rel="stylesheet" href="css/msdropdown/dd.css" media="screen, projection" />
      <link rel="stylesheet" href="css/iCheck/all.css" media="screen, projection" />
      <link rel="stylesheet" href="css/jScroll/jquery.jscrollpane.css" media="screen, projection" />

		  <link rel="Shortcut Icon" href="images/favicon.png" type="image/x-icon" />
    </head>

    <body>

      <div class="wrapper">

        <header class="header">
          <div class="header__resize">
            <div class="header__user-account">
              <a href="" title="">Logout</a>
            </div>
            <div class="header__user-activity">
              <div class="header__logo">
                <h1><a href="#">FYM</a></h1>
              </div>
              <div class="header__module-management">

              </div>
              <div class="clear"></div>
            </div>
          </div>
        </header>

        <div class="content__resize">
        <h1>BUSINESS DIRECTORY</h1>
        <h3>Add Business (13)</h3>
          <div style="width:460px; border:1px solid #e6e6e6; padding:15px; background:#fff;">
            <div class="pure-u-1">
              <form class="pure-form-stacked" action="#">
                <fieldset>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="business-name">Business Name</label>
                          <input type="email" id="name" class="form__group-control" placeholder="">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label">Categories</label>
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="21" type="checkbox" id="input-21">
                                <label for="input-21">Low Carb</label>
                              </li>
                              <li>
                                <input tabindex="22" type="checkbox" id="input-22" checked>
                                <label for="input-22">Low Fat</label>
                              </li>
                              <li>
                                <input tabindex="23" type="checkbox" id="input-23" checked>
                                <label for="input-23">High Protein</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label">Address</label>
                          <input type="email" class="form__group-control margin-btm-05" id="address" placeholder="">
                          <label class="error" style="display:none;">error</label>
                          <div class="pure-g">
                            <div class="pure-u-1 form__group">
                              <input type="email" class="form__group-control" id="address-2" placeholder="">
                              <label class="error" style="display:none;">error</label>
                            </div>
                          </div>
                          <div class="pure-g">
                            <div class="pure-u-1 form__group">
                              <div class="pure-u-1-2 float-left">
                                <select style="width:100%" name="pages" class="pages">
                                  <option selected="selected">&nbsp;</option>
                                  <option>&nbsp;</option>
                                </select>
                              </div>
                              <div class="pure-u-5-12 float-right">
                                <input type="email" class="form__group-control no-top-margin" id="address-3" placeholder="">
                                <label class="error" style="display:none;">error</label>
                              </div>
                          </div>
                          </div>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="data-range">Phone</label>
                          <input type="email" id="phone" class="form__group-control" placeholder="">
                          <label class="error" style="display:none;">error</label>
                          <label class="form__label margin-top-26" for="data-range">URL</label>
                          <input type="email" id="url" class="form__group-control" placeholder="">
                          <label class="error" style="display:none;">error</label>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated no-btm-margin">
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--first">
                          <label class="form__label" for="data-range">Radius</label>
                          <input type="email" class="form__group-control" id="radius" placeholder="State, Zip">
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-u-1-2 form__group">
                        <div class="form__element-block--last">
                          <label class="form__label" for="data-range">&nbsp;</label>
                          <div class="icheck-list">
                            <ul>
                              <li class="margin-top-05">
                                <input tabindex="24" type="checkbox" id="input-24">
                                <label for="input-24">All</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                        <div class="pure-u-1 form__group">
                          <textarea rows="1" cols="1" class="form__group-control textarea--large"></textarea>
                          <label class="error">error</label>
                        </div>
                      </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <label class="form__label" for="add-image">Add Image</label>
                        <div class="file__input-wrapper">
                          <button class="btn-file-input">SELECT FILES</button>
                          <input type="file" id="add-image" name="image">
                        </div>
                        <div class="file__input-wrapper">
                          <button class="btn-file-input">SELECT FILES</button>
                          <input type="file" id="add-image-2" name="image">
                        </div>
                        <div class="file__input-wrapper">
                          <button class="btn-file-input">SELECT FILES</button>
                          <input type="file" id="add-image-3" name="image">
                        </div>
                        <div class="file__input-wrapper">
                          <button class="btn-file-input">SELECT FILES</button>
                          <input type="file" id="add-image-4" name="image">
                        </div>
                      </div>
                    </div>
                    <div class="pure-g form__block-floated">
                      <div class="pure-u-1 form__group">
                        <label class="form__label">Business Hours</label>
                        <div class="pure-u-4-5 form__group">
                          <div class="pure-u-7-24">&nbsp;</div>
                          <div class="pure-u-7-24">
                            <label class="form__label">Open</label>
                          </div>
                          <div class="pure-u-1-4">
                            <label class="form__label">Close</label>
                          </div>
                        </div>
                        <?php
                        for($i=0; $i<8;$i++)
                        {
                        ?>
                        <div class="pure-u-4-5 form__group">
                          <div class="pure-u-7-24"><label class="form__label day--section">Monday</label></div>
                          <div class="pure-u-7-24">
                            <select style="width:100%" name="pages" class="pages">
                              <option value="" selected="selected">Open</option>
                              <option value="">Open</option>
                            </select>
                          </div>
                          <div class="pure-u-7-24">
                            <select style="width:100%" name="pages" class="pages">
                              <option value="" selected="selected">Open</option>
                              <option value="">Open</option>
                            </select>
                          </div>
                        </div>
                        <?php
                        }
                        ?>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1-2 form__group">
                          <div class="icheck-list">
                            <ul>
                              <li>
                                <input tabindex="25" type="checkbox" id="input-25">
                                <label for="input-25">Premium Listing</label>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="pure-g form__block-floated">
                        <div class="pure-u-1 form__group">
                          <label class="form__label" for="radius">Business Description</label>
                          <textarea rows="1" cols="1" class="form__group-control textarea--large" id="business-description"></textarea>
                          <label class="error">error</label>
                        </div>
                      </div>
                      <div class="pure-g">
                        <div class="pure-u-1">
                          <button type="submit" class="button--blue-medium float-right" title="Save">Save</button>
                        </div>
                      </div>
                    </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>


           <div class="clear" style="margin-bottom:50px;"></div>


      </div>


      <!-- This contains the hidden content for inline calls -->
      <div style='display:none'>
        <div id='inline-content' class='popup__inner'>
          <div class="padding-lft-20 padding-rgt-20">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>
        </div>
      </div>

      <!-- ui-dialog -->
      <div id="dialog" title="Please Confirm">
        <p class="font16px">Are you sure you want to <br>deactivate this user?</p>
      </div>



      <!-- JavaScript -->
      <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
      <script src="js/colorbox/jquery.colorbox.js"></script>
      <script src="js/jQueryUI/jquery-ui.js"></script>
      <script src="js/tooltipster/jquery.tooltipster.min.js"></script>
      <script src="js/common.js" ></script>

      <script src="js/iCheck/icheck.js"></script>
      <script src="js/msdropdown/jquery.dd.js"></script>
      <script src="js/jScroll/jquery.jscrollpane.js"></script>
      <script src="js/jScroll/jquery.mousewheel.js"></script>

      <!--[if gt IE 9]><!-->
        <script src="//cdnjs.cloudflare.com/ajax/libs/html-inspector/0.8.1/html-inspector.js"></script>
        <script>
          HTMLInspector.inspect({
            excludeElements: ["svg", "iframe", "html"]
          })
        </script>
      <!--<![endif]-->

      <script>
        $(document).ready(function(){


          $(".inline").colorbox({inline:true, width:"50%"});


          $( "#dialog" ).dialog({
            autoOpen: false,
            width: 340,
            modal: true,
            buttons: [
              {
                text: "No, Cancel Request",
                click: function() {
                  $( this ).dialog( "close" );
                }
              },
              {
                text: "Yes, Deactivate User",
                click: function() {
                  $( this ).dialog( "close" );
                }
              }
            ]
          });
          $( "#dialog-link" ).click(function( event ) {
            $( "#dialog" ).dialog( "open" );
            event.preventDefault();
          });


          var callbacks_list = $('.icheck-callbacks ul');
          $('.icheck-list input').on('ifCreated ifClicked ifChanged ifChecked ifUnchecked ifDisabled ifEnabled ifDestroyed', function(event){
            callbacks_list.prepend('<li><span>#' + this.id + '</span> is ' + event.type.replace('if', '').toLowerCase() + '</li>');
          }).iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%'
          });


          $(".pages").msDropdown().data("dd");//{animStyle:'none'} /{animStyle:'slideDown'} {animStyle:'show'}
          $(".theme-unit").msDropdown({mainCSS:'dd2'});
          //$(".theme-three").msDropdown({mainCSS:'dd2'});
          $(".theme-segment").msDropdown({mainCSS:'dd3'});

          $('.tooltip').tooltipster({
            autoClose: false,
            minWidth: 230,
              content: $('<div class="pure-g"><span class="bold pure-u-1">Add new category</span><div class="clear"></div><div class="pure-u-3-4"><div class="form__element-block--first"><input type="text" class="form__group-control" placeholder="Category Name"></div></div><div class="pure-u-1-4"><input class="button--green-small" type="button" value="Add"></div></div>')
          });

          $('.scroll-pane').jScrollPane();
        });
      </script>

    </body>
</html>
