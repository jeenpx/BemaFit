<?php
session_start();
$language = isset($_POST['language'])?$_POST['language']:'English';
if($language != 'Spanish' && $language != 'English'){
    $language = 'English';
}
$_SESSION['language'] = $language;
echo json_encode(array('status'=>true));
exit;
?>

