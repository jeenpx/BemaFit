
	Created by : shiraz samad
	created date : 16-01-2013 (dd-mm-yy)

------------------------------------------------------------------------------------
	Things to consider before using the DBG HTML Frame work
------------------------------------------------------------------------------------

	1) Please Dont make any changes in common.css once it is used in a project. 
	2) Please keep the directory structure as it is.

------------------------------------------------------------------------------------
	About the -js- folder in DBG HTML Frame work
------------------------------------------------------------------------------------

	1) Please make sure all the javascript files are up-to-date.
	2) Please use latest jquery from jquery CDN if possible.(currentyly using Ver - 1.7.2)
	3) PLease use libraries like PIE, SELECTIVIZR, CUFON, PNGFIX, MODERNIZER only when needed.

------------------------------------------------------------------------------------
	About the -css- folder in DBG HTML Frame work
------------------------------------------------------------------------------------
	
	1) Please create the css files and name it based on module names.

------------------------------------------------------------------------------------
	About the -images- folder in DBG HTML Frame work
------------------------------------------------------------------------------------
	
	1) Please organize images by creating folders based on modules.

------------------------------------------------------------------------------------
	About the -fonts- folder in DBG HTML Frame work
------------------------------------------------------------------------------------

	1) If more than one custom font is using please make seperate folders with the font name as the folder name. 

------------------------------------------------------------------------------------
	Things to consider after using the DBG HTML Frame work
------------------------------------------------------------------------------------
	
	1) After ui development please minify the css and javascript files.
	2) Please change the title of the html document
	3) Add all meta tag contents



