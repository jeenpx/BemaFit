<?php
    error_reporting(E_ALL);
            ini_set('display_errors', 1); 
session_start();
if(!isset($_SESSION['language'])) {
    $_SESSION['language'] = 'English';
}
setcookie('FymLang', $_SESSION['language'], time() + (86400 * 30), "/");
$lngFileContents = file_get_contents('language/'.$_SESSION['language'].'.php');
$lngTexts = json_decode($lngFileContents,true);
function getLangText($msgId, $lngTexts){
    echo isset($lngTexts[$msgId])?$lngTexts[$msgId]:'';
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
    	<meta charset="utf-8">
    	<title>Flex Your Macros</title>
    	<meta name="description" content="">
    	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    	<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/pure-min.css">
        <!--[if lte IE 8]>
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/grids-responsive-min.css">
        <!--<![endif]-->
        
    	<link rel="stylesheet" href="css/common-base-min.css" media="screen, projection" />
    	<link rel="stylesheet" href="css/base.css" media="screen, projection" />
		<link rel="stylesheet" href="css/print.css" media="print" />

        <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
        <link rel="icon" href="./images/favicon.ico" type="image/x-icon">


        
        <link rel="stylesheet" href="css/slider/slick.css" media="screen, projection" />

        <link href='http://fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

    </head>
    <body>  
        <div id="wrapper">
            <header>               
                <div class="header">
                    <div class="top-login">
                        <div class="mid-container pure-g">
                            <div class="pure-u-1">
                                <ul class="lang-link">
                                    <li>
                                        <a href="javascript:;" class="default-lang"><?php echo $_SESSION['language'];?></a>
                                        <ul class="lang-sub-link hide">
                                            <?php if($_SESSION['language']!='English'):?>
                                                <li><a href="javascript:;" data-lang="English" class="links lngLink">English</a></li>
                                            <?php endif;?>
                                            <?php if($_SESSION['language']!='Spanish'):?>
                                                <li><a href="javascript:;" data-lang="Spanish" class="links lngLink">Spanish</a></li>
                                            <?php endif;?>
                                        </ul>
                                    </li>
                                </ul>
                                <a href="#" class="login-link hide">Login</a>
                            </div>
                        </div>
                    </div>
                    <div class="main-nav">
                        <div class="mid-container pure-g">
                            <div class="pure-u-1 pure-u-md-1-4 pure-u-lg-1-4 pure-u-sm-1-2">
                                <h1 class="fym-logo float-left"><a href="index.php" title="FYM">FYM</a></h1>
                            </div>
                            <div class="pure-u-1 pure-u-md-3-4 pure-u-lg-3-4 pure-u-sm-1-2 hide">
                                <div class="main-nav-bar">
                                    <a href="#" class="nav-item" title="Home">Home</a>   
                                    <a href="#" class="nav-item" title="Community Forum">Community Forum</a>   
                                    <a href="#" class="nav-item" title="Store">Store</a>    
                                    <a href="#" class="nav-item" title="Contact">Contact</a>
                                    <a href="#" class="nav-item download-app" title="Download App Now!">Download App Now!</a>
                                </div>
                                <a href="#" id="humburger-btn" title="humburger menu" class="humburger-icon hamburger-icon hide">humburger menu</a> 
                            </div>
                        </div>
                    </div>    
                </div>
            </header>
            <div class="clear"></div>
            

            

            <div class="mid-container">
                <div class="terms-wrap">
                    <h2 class="tersm-head">Supplementary End User License Agreement and Disclaimer</h2>
                    <p class="terms-detail">Message and data rates may apply for downloading and accessing mobile application features and content.  By downloading this mobile application you represent that you are at least 18 years of age or older, and that you are the account holder for the device or have the account holder's permission to download this application.  You will be responsible for obtaining and maintaining all telephone, computer hardware and other equipment needed for access to and use of the Services and all charges related thereto.</p>
                    <p class="terms-detail">This Supplementary End User License Agreement and Disclaimer (“Supplementary License”) is a binding legal agreement between you (“you” or “User”) and Flex Your Macros, LLC. (“FYM”) regarding your use of the FLEX YOUR MACROS software application (the “ the App” or the “Software”). This Supplementary License is intended to supplement the terms of the “Licensed Application End User License Agreement” to which User agreed when downloading the FLEX YOUR MACROS application from [the Apple Inc. App Store or the Android marketplace or  FYM’s website] (the “Download License”). Accordingly, User acknowledges and agrees that (1) the FLEX YOUR MACROS application is the “Licensed Application” as defined in the Download License, (2) User continues to be bound by all the terms of the Download License as well as the supplementary terms in this Supplementary License, and (3) in the event of a conflict between the terms of the Download License and this Supplementary License, the terms of the Download License will control.</p>
                    <p class="terms-detail">Subject to the terms of the Download License as supplemented by this Supplementary License, User is granted a non-transferable, non-exclusive and free license for the use of the FLEX YOUR MACROS application on the appropriate equipment owned or controlled by User owns or controls as permitted by the Download License as supplemented by this Supplementary License including, but not limited to, the Usage Rules set forth in the App Store Terms of Services referenced in the Download License. The FLEX YOUR MACROS application has been developed by FYM and is protected by copyright and may not be reproduced or used without the expressed written permission of FYM. Making additional copies of the software, or enabling others to use your registration code(s) or serial number(s), if any, is strictly prohibited. It is also prohibited to duplicate the software by any other means including electronic transmission. The software also contains trade secrets and you may not decompile, reverse engineer, disassemble or otherwise reduce the software to human-perceivable form or disable any functionality which limits the use of the software. You may not modify, adapt, translate, rent or sublicense (including offering the software to third parties on an application service provider or time-sharing basis), assign, loan, resell for profit, or distribute the software, disks or related materials or create derivative works based upon the software or any part thereof, without the expressed written permission of FYM.</p>
                    <p class="terms-detail">FLEX YOUR MACROS® is a Registered Trademark owned by FYM. You acknowledge that FYM is an intended third-party beneficiary of the Download License as supplemented by this Supplementary License.</p>
                    <p class="terms-detail">Visit www.___________________.com/privacy to view the FLEX YOUR MACROS Application Privacy Statement.</p>
                    <p class="terms-detail">User acknowledges that FYM or its licensors, in their sole discretion, have taken necessary measures to ensure the privacy, integrity and security of the data entered by the user when transmitting that data between the user’s device(s) such as iPhone, iPad, Android, or a web browser and the servers that will host/store the data. Despite these security and privacy measures, it is possible that there can be a breach in the data security resulting from non-malicious actions of FYM or its licensors and/or malicious actions of external parties. Neither FYM nor its licensors will be responsible for such effects, and neither FYM nor its licensors will have any obligation to furnish any maintenance and support services with respect to the FLEX YOUR MACROS application.</p>
                    <h3 class="terms-sub-head">Without limiting the generality of the Download License:</h3>
                    <p class="terms-detail">The FLEX YOUR MACROS application is designed to help User maintain a healthy lifestyle through better management and tracking of nutrition, and exercise activity. However, FYM has no control over, and makes no representations or warranties, expressed or implied, regarding the use by User of the FLEX YOUR MACROS application or the use or interpretation of any information stored on, generated by or received through the FLEX YOUR MACROS application. User is solely responsible for communicating nutrition and exercise related information to (and receiving feedback from) User’s healthcare provider(s). The FLEX YOUR MACROS application does not provide FYM or its licensors access to data that can identify the User.</p>
                    <p class="terms-detail">User is solely responsible for reviewing and evaluating the accuracy and relevance of any information stored on, generated by or received through the FLEX YOUR MACROS application. FYM cannot and does not guarantee said accuracy. THE FLEX YOUR MACROS APPLICATION AND ANY INFORMATION STORED ON, GENERATED BY OR RECEIVED THROUGH THE FLEX YOUR MACROS APPLICATION ARE NOT INTENDED TO BE A SUBSTITUTE FOR PROFESSIONAL MEDICAL ADVICE, DIAGNOSIS, OR TREATMENT. ALWAYS SEEK THE ADVICE OF A PHYSICIAN OR OTHER QUALIFIED HEALTHCARE PROVIDER WITH ANY QUESTIONS REGARDING A MEDICAL CONDITION. NEVER DISREGARD PROFESSIONAL MEDICAL ADVICE OR DELAY IN SEEKING IT BECAUSE OF SOMETHING READ OR LEARNED THROUGH THE USE OF THE FLEX YOUR MACROS APPLICATION OR ANY INFORMATION STORED ON, GENERATED BY OR RECEIVED THROUGH THE FLEX YOUR MACROS APPLICATION.</p>
                    <p class="terms-detail">User acknowledges that they are in good health and that, prior to starting any exercise program, they should check with their medical provider.</p>
                    <p class="terms-detail">User acknowledges that FYM or its licensors, in their sole discretion, may from time to time make modifications to the FLEX YOUR MACROS application. Such modifications may require corresponding changes to be made in the User’s systems. Changes or failure to make timely changes by User may sever or affect User’s access to the FLEX YOUR MACROS application. Neither FYM nor its licensors will be responsible for such effects, and neither FYM nor its licensors will have any obligation to furnish any maintenance and support services with respect to the FLEX YOUR MACROS application.</p>
                    <h3 class="terms-sub-head">Health Disclaimer:</h3>
                    <p class="terms-detail">The nutrition and fitness information contained herein is provided for general education purposes only. Persons using the data within the FLEX YOUR MACROS application for medical purposes, should not rely on the accuracy of the data herein. While the data may be updated periodically, users should independently check other sources for the latest and most accurate information.</p>
                    <h3 class="terms-sub-head">Warranty Disclaimer:</h3>
                    <p class="terms-detail">You expressly agree that use of this mobile application is at your sole risk.   Neither FYM  nor any of their respective employees, agents, third party content providers or licensors warrant that the use of the application will be uninterrupted or error free; nor do they make any warranty as to the results that may be obtained from use of FLEX YOUR MACROS, or from the information contained therein, or as to the accuracy or reliability of any information or service provided through FLEX YOUR MACROS.</p>
                    <p class="terms-detail">Any and all liability arising directly or indirectly from the use of the FLEX YOUR MACROS application is hereby disclaimed. The FLEX YOUR MACROS application is provided "as is" and without any warranty expressed or implied, including but not limited to, warranties of title or implied warranties of merchantability or fitness for a particular purpose. </p>
                    <p class="terms-detail">This disclaimer of liability applies to any damages or injury caused by any failure or performance, error, omission, inaccuracy, interruption, deletion, defect, delay in operation or transmission, computer virus, communication line failure, theft or destruction or unauthorized access to, alteration of, or use of the Service, whether for breach of contract, tortious behavior (including, without limitation, strict liability), negligence, or under any other cause of action, to the fullest extent permissible by law. You specifically acknowledge that FYM is not liable for the defamatory, offensive or illegal conduct of other users or third-parties over which it has no control or for any disclosure of any type of information transmitted through the use of FLEX YOUR MACROS.  All direct, indirect, special, incidental, consequential or punitive damages arising from any use of the FLEX YOUR MACROS application or data contained herein are disclaimed and excluded.</p>

                </div>
            </div>

            <div class="grey-bg pre-footer hide">
                <div class="mid-container pure-g">
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4"><a href="#" class="corporate-member almond-breeze"><img src="./images/home/almond-breeze.png" alt=""></a></div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4"><a href="#" class="corporate-member"><img src="./images/home/subway.png"  alt=""></a></div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4"><a href="#" class="corporate-member"><img src="./images/home/jennieO.png" alt=""></a></div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4"><a href="#" class="corporate-member"><img src="./images/home/massage-envy.png" alt=""></a></div>
                </div>
            </div>
            <footer id="footer">
                <div class="mid-container pure-g">
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">&nbsp;
                        <div class="footer-menu">
                            <a href="terms.php" class="menu-item" title="Privacy">Terms</a>   
                            <!-- <a href="#" class="menu-item" title="Privacy">Privacy</a>   
                            <a href="#" class="menu-item" title="FAQ">FAQ</a>   
                            <a href="#" class="menu-item" title="Contact">Contact</a> -->
                        </div>
                    </div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="social-icons">
                            <a href="//www.facebook.com/flexyourmacros" title="Facebook" class="icon facebook" target="_blank">Facebook</a>
                            <!-- <a href="#" title="Twitter" class="icon twitter">Twitter</a>
                            <a href="#" title="Pinterest" class="icon pinterest">Pinterest</a> -->
                            <a href="//instagram.com/flexyourmacros" title="Instagram" class="icon instagram" target="_blank">Instagram</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
        <script src="js/modernizr/modernizr-2.8.1.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="js/slider/slick.js" ></script>
        <script src="js/common.js" ></script>
    </body>
</html>
