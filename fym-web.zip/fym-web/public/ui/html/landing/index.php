<?php
    error_reporting(E_ALL);
            ini_set('display_errors', 1); 
session_start();
if(!isset($_SESSION['language'])) {
    $_SESSION['language'] = 'English';
}
setcookie('FymLang', $_SESSION['language'], time() + (86400 * 30), "/");
$lngFileContents = file_get_contents('language/'.$_SESSION['language'].'.php');
$lngTexts = json_decode($lngFileContents,true);
function getLangText($msgId, $lngTexts){
    echo isset($lngTexts[$msgId])?$lngTexts[$msgId]:'';
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
    	<meta charset="utf-8">
    	<title>Flex Your Macros</title>
    	<meta name="description" content="">
    	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    	<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/pure-min.css">
        <!--[if lte IE 8]>
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/grids-responsive-min.css">
        <!--<![endif]-->
        
    	<link rel="stylesheet" href="css/common-base-min.css" media="screen, projection" />
    	<link rel="stylesheet" href="css/base.css" media="screen, projection" />
		<link rel="stylesheet" href="css/print.css" media="print" />

        <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
        <link rel="icon" href="./images/favicon.ico" type="image/x-icon">


        
        <link rel="stylesheet" href="css/slider/slick.css" media="screen, projection" />

        <link href='http://fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

    </head>
    <body>  
        <div id="wrapper">
            <header>               
                <div class="header">
                    <div class="top-login">
                        <div class="mid-container pure-g">
                            <div class="pure-u-1">
                                <ul class="lang-link">
                                    <li>
                                        <a href="javascript:;" class="default-lang"><?php echo $_SESSION['language'];?></a>
                                        <ul class="lang-sub-link hide">
                                            <?php if($_SESSION['language']!='English'):?>
                                                <li><a href="javascript:;" data-lang="English" class="links lngLink">English</a></li>
                                            <?php endif;?>
                                            <?php if($_SESSION['language']!='Spanish'):?>
                                                <li><a href="javascript:;" data-lang="Spanish" class="links lngLink">Spanish</a></li>
                                            <?php endif;?>
                                        </ul>
                                    </li>
                                </ul>
                                <a href="#" class="login-link hide">Login</a>
                            </div>
                        </div>
                    </div>
                    <div class="main-nav">
                        <div class="mid-container pure-g">
                            <div class="pure-u-1 pure-u-md-1-4 pure-u-lg-1-4 pure-u-sm-1-2">
                                <h1 class="fym-logo float-left"><a href="index.php" title="FYM">FYM</a></h1>
                            </div>
                            <div class="pure-u-1 pure-u-md-3-4 pure-u-lg-3-4 pure-u-sm-1-2 hide">
                                <div class="main-nav-bar">
                                    <a href="#" class="nav-item" title="Home">Home</a>   
                                    <a href="#" class="nav-item" title="Community Forum">Community Forum</a>   
                                    <a href="#" class="nav-item" title="Store">Store</a>    
                                    <a href="#" class="nav-item" title="Contact">Contact</a>
                                    <a href="#" class="nav-item download-app" title="Download App Now!">Download App Now!</a>
                                </div>
                                <a href="#" id="humburger-btn" title="humburger menu" class="humburger-icon hamburger-icon hide">humburger menu</a> 
                            </div>
                        </div>
                    </div>    
                </div>
            </header>
            <div class="clear"></div>
            <div class="banner-container">
                <div class="mid-container banner-container-inner pure-g">
                   <div class="pure-u-1">
                        <div class="home-banner">
                            <ul class="hamburger-menu clearfix hide" id="hamburger-menu">
                                <li><a href="#" class="menu-item">Home</a></li>
                                <li><a href="#" class="menu-item">Community Forum</a></li>
                                <li><a href="#" class="menu-item">Store</a></li>
                                <li><a href="#" class="menu-item">Contact</a></li>
                                <li><a href="#" class="menu-item download-app">Download App Now!</a></li>
                            </ul>
                            <h2 class="banner-txt"><?php getLangText('lng_Title_Normal',$lngTexts);?><br><span class="oswald-bold"><?php getLangText('lng_Title_Bold',$lngTexts);?></span></h2>
                            <div class="home-vdo"><iframe height="320" src="//www.youtube.com/embed/qV5jLvf1N1w?wmode=opaque;rel=0;autohide=1;showinfo=0;wmode=transparent" allowfullscreen></iframe></div>


                            <div class="coming-soon hide"><?php getLangText('lng_coming_soon',$lngTexts);?></div>
                            <div class="button-wrap">
                                <!-- <a href="#coming-soon" id="scroll-to-signup" class="sign-up-update" title="<?php getLangText('lang_sign_up_for_updates',$lngTexts);?>"><?php getLangText('lang_sign_up_for_updates',$lngTexts);?></a> -->    
                                <a href="#" class="download-app" title="<?php getLangText('lang_download_mob_app',$lngTexts);?>"><?php getLangText('lang_download_mob_app',$lngTexts);?></a> 
                                <a href="#" class="sign-up-facebook" title="<?php getLangText('lang_signup_facebook',$lngTexts);?>"><?php getLangText('lang_signup_facebook',$lngTexts);?></a> 
                                <a href="#" class="sign-up-email" title="<?php getLangText('lang_signup_email',$lngTexts);?>"><?php getLangText('lang_signup_email',$lngTexts);?></a> 
                            </div>              
                        </div>
                   </div>
                </div>
            </div>

            <div class=""> <!--add class 'grey-bg' for grey background-->
                <div class="mid-container video-container hide-flow">
                     <div class="variable-width" >                    
                        <div class="vdo-container">
                            <div class="video-single"><iframe height="165" src="//www.youtube.com/embed/qV5jLvf1N1w?wmode=opaque;rel=0;autohide=1;showinfo=0;wmode=transparent"  allowfullscreen></iframe></div>
                        </div>
                        <div class="vdo-container">
                            <div class="video-single"><iframe height="165" src="//www.youtube.com/embed/qV5jLvf1N1w?wmode=opaque;rel=0;autohide=1;showinfo=0;wmode=transparent"  allowfullscreen></iframe></div>
                        </div>
                        <div class="vdo-container">
                            <div class="video-single last"><iframe height="165" src="//www.youtube.com/embed/qV5jLvf1N1w?wmode=opaque;rel=0;autohide=1;showinfo=0;wmode=transparent"  allowfullscreen></iframe></div>
                        </div>                   
                    </div>
                </div>
            </div>

            <div class="mid-container">
                <div class="content-tag pure-g">
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="tag-image macro-graph"><img src="./images/home/macros-formula.png" alt=""></div>
                    </div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="content-tag-txt macro-graph-txt">
                            <h3 class="content-tag-head"><?php getLangText('lng_we_use_proven',$lngTexts);?></h3>
                            <p class="content-tag-detail"><?php getLangText('lang_in_the_fym_application',$lngTexts);?></p>
                        </div>
                    </div>  
                    <div class="grey-line pure-u-1">&nbsp;</div>  
                </div>
                
                <div class="content-tag pure-g">
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="content-tag-txt smart-food-txt">
                            <h3 class="content-tag-head"><?php getLangText('lang_smart_food',$lngTexts);?></h3>
                            <p class="content-tag-detail"><?php getLangText('lang_Based_off_your_macronutrient',$lngTexts);?></p>
                        </div>
                    </div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="tag-image smart-food"><img src="./images/home/smart-food.jpg" alt=""></div>
                    </div>
                    <div class="grey-line pure-u-1">&nbsp;</div>
                </div>
               
                <div class="content-tag pure-g">
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="tag-image your-progress"><img src="./images/home/progress-map.png" alt=""></div>
                    </div>

                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="content-tag-txt your-progress-txt">
                            <h3 class="content-tag-head"><?php getLangText('lang_your_progress_logged',$lngTexts);?></h3>
                            <p class="content-tag-detail your-progress-txt"><?php getLangText('lang_as_you_continue',$lngTexts);?></p>
                        </div>
                    </div>
                    
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="tag-image your-progress your-progress-mob"><img src="./images/home/progress-map.png" alt=""></div>
                    </div>   
                    <div class="grey-line pure-u-1">&nbsp;</div> 
                </div>
                <div class="content-tag pure-g">
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="content-tag-txt fitness-txt">
                            <h3 class="content-tag-head"><?php getLangText('lang_achieve_your_fitness',$lngTexts);?></h3>
                            <p class="content-tag-detail"><?php getLangText('lang_whether_you_choose',$lngTexts);?></p>
                        </div>
                    </div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="tag-image fitness"><img src="./images/home/achieve-fitness.png" alt=""></div>
                    </div>
                    <div class="grey-line pure-u-1">&nbsp;</div>
                </div>

                <!-- <div class="content-tag pure-g">
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="tag-image fym-community"><img src="./images/home/fym-community.jpg" alt=""></div>
                    </div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="content-tag-txt fym-community-txt">
                            <h3 class="content-tag-head"><?php getLangText('lang_fym_is_more_than',$lngTexts);?></h3>
                            <p class="content-tag-detail"><?php getLangText('lang_join_friends',$lngTexts);?></p>
                        </div>
                    </div> 
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="tag-image fym-community fym-community-mob"><img src="./images/home/fym-community.jpg" alt=""></div>
                    </div>   
                    <div class="grey-line pure-u-1">&nbsp;</div>
                </div>

                <div class="content-tag pure-g fym-app-section">
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="tag-image fym-app"><img src="./images/home/fym-app.jpg" alt=""></div>
                    </div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="content-tag-txt fym-app-txt">
                            <h3 class="content-tag-head"><?php getLangText('lang_find_great_rebates',$lngTexts);?></h3>
                            <p class="content-tag-detail"><?php getLangText('lang_using_fym_mobile',$lngTexts);?></p>
                        </div>
                    </div>  
                    <div class="grey-line pure-u-1">&nbsp;</div>  
                </div> 

                <div class="content-tag pure-g">
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="content-tag-txt fym-inspire-txt">
                            <h3 class="content-tag-head"><?php getLangText('lang_fym_gives_back',$lngTexts);?></h3>
                            <p class="content-tag-detail"><?php getLangText('lang_fym_appreciates',$lngTexts);?></p>
                        </div>
                    </div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="tag-image fym-inspire"><img src="./images/home/fym-inspire.jpg" alt=""></div>
                    </div>
                    <div class="grey-line pure-u-1">&nbsp;</div>
                </div>
                -->
                <div class="content-tag no-border pure-g">
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="tag-image fym-mob-app"><img src="./images/home/fym-mob-app.png" alt=""></div>
                    </div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-2" id="coming-soon">
                        <div class="content-tag-txt fym-mob-app-txt">
                            <h3 class="content-tag-head"><?php getLangText('lang_where_you_go_head',$lngTexts);?></h3>
                            <p class="content-tag-detail"><?php getLangText('lang_where_you_go',$lngTexts);?></p>
                            <div class="sign-up">
                                <form id="frmSignUp" action="#" class="margin-top-15 hide">
                                    <input type="text" name="email" id="email" class="sign-up-text">
                                    <input type="submit" value="<?php getLangText('lang_signup',$lngTexts);?>" class="sign-up-submit" title="<?php getLangText('lang_signup',$lngTexts);?>">
                                    <label id="lblError" class="error-message"></label>
                                    <div id="messageBox">
                                        <label id="lblSuccess" class="success-message"></label>
                                    </div>
                                </form>
                                <div class="download-app"> <!-- add class 'low-opacity' in landing-prelaunch -->
                                    <a href="#" class="app app-store" title="App Store">App Store</a>
                                    <!-- <a href="#" class="app google-play" title="Google Play">Google Play</a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="grey-bg pre-footer hide">
                <div class="mid-container pure-g">
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4"><a href="#" class="corporate-member almond-breeze"><img src="./images/home/almond-breeze.png" alt=""></a></div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4"><a href="#" class="corporate-member"><img src="./images/home/subway.png"  alt=""></a></div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4"><a href="#" class="corporate-member"><img src="./images/home/jennieO.png" alt=""></a></div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4"><a href="#" class="corporate-member"><img src="./images/home/massage-envy.png" alt=""></a></div>
                </div>
            </div>
            <footer id="footer">
                <div class="mid-container pure-g">
                    <div class="pure-u-1-2 pure-u-md-1-2 pure-u-lg-1-2">&nbsp;
                        <div class="footer-menu">
                            <a href="terms.php" class="menu-item" title="Terms and Conditions">Terms and Conditions</a>   
                            <!-- <a href="#" class="menu-item" title="Privacy">Privacy</a>   
                            <a href="#" class="menu-item" title="FAQ">FAQ</a>   
                            <a href="#" class="menu-item" title="Contact">Contact</a> -->
                        </div>
                    </div>
                    <div class="pure-u-1-2 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="social-icons">
                            <a href="//www.facebook.com/flexyourmacros" title="Facebook" class="icon facebook" target="_blank">Facebook</a>
                            <!-- <a href="#" title="Twitter" class="icon twitter">Twitter</a>
                            <a href="#" title="Pinterest" class="icon pinterest">Pinterest</a> -->
                            <a href="//instagram.com/flexyourmacros" title="Instagram" class="icon instagram" target="_blank">Instagram</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
        <script src="js/modernizr/modernizr-2.8.1.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="js/slider/slick.js" ></script>
        <script src="js/common.js" ></script>
    </body>
</html>
