<?php

if(isset($_SERVER['WORK_ENVIRONMENT']) && $_SERVER['WORK_ENVIRONMENT']=='development') {
    define('HOSTNAME',"localhost");
    define('DB',"fym");
    define('DB_USERNAME',"root");
    define('DB_PASSWORD',"");
} else {
    define('HOSTNAME',"localhost");
    define('DB',"fym");
    define('DB_USERNAME',"fym");
    define('DB_PASSWORD',"fym123");
}

define('TO_SIGNUP_EMAIL',"arunssjoshi@gmail.com");