<?php

include("assets/OBJ_mysql.php");
$db = new OBJ_mysql();
$email = isset($_POST['email'])?$_POST['email']:'';
$newUser = array( 
    'email'  => $email,
    'created_date' => date('Y-m-d h:i:s'),
    'ip' => $_SERVER['REMOTE_ADDR']
 );

$new_user_id = $db->insert('users', $newUser);


if($new_user_id){

    $to      = TO_SIGNUP_EMAIL;
    $subject = 'New Sign up request';
    
    $message = '<table cellspacing="0" cellpadding="0" bgcolor="#eaeaea" width="100%">
  <tbody><tr>
    <td align="center">
            <table cellspacing="0" cellpadding="0" background="">
                <tbody><tr>
                    <td background="" align="center" width="100%">
                        <table cellspacing="0" cellpadding="0" width="610">
                            <tbody><tr bgcolor="#ffffff">
                                <td align="left" style="border-top:2px solid #caa50e;border-left:1px solid #cdcdcd;border-right:1px solid #cdcdcd;"><img src="http://mailer.dbgstage.com/images/fym/fym-logo.png"></td>
                            </tr>
                            <tr bgcolor="#ffffff">
                                <td align="left" style="padding: 22px 20px 22px 20px;border:1px solid #cdcdcd; color:#7f7f7f; border-top:none;font-family:Arial, Helvetica, sans-serif;font-size:13px;"><table cellspacing="0" cellpadding="0" border="0" width="100%">
                                  <tbody><tr>
                                    <td align="center" style="padding:0px 0px 10px; font-family:Arial, Helvetica, sans-serif;font-size:18px; font-weight: bold; " colspan="2">Your have recieved a sign up request from</td>
                                  </tr>
                                  <tr>
                                    <td align="center" style="padding:0px 0px 10px; font-family:Arial, Helvetica, sans-serif;font-size:22px; " colspan="2"><table cellspacing="0" cellpadding="0" border="0" width="50%">
                                      <tbody><tr>
                                        <td>
                                            <div style="background:#ebebeb; border:2px solid #cdcdcd;color:#666;font-family:Arial, Helvetica, sans-serif;font-size:24px; padding:10px 8px;text-align: center;">'.$email.'</div>
                                        </td>
                                      </tr>
                                    </tbody></table></td>
                                  </tr>
                                </tbody></table></td>
                            </tr>
                            <tr bgcolor="#ffffff">
                                <td style="padding: 8px 0 8px 20px;border:1px solid #cdcdcd;color:#7f7f7f;border-top:none;border-bottom:none;font-family:Arial, Helvetica, sans-serif;font-size:11px;text-align:left;">
                                    <p>&copy; 2015 FYM. All Rights Reserved.</p>
                                </td>
                            </tr>
                            <tr>
                                <td height="36" style="margin:0;padding:0">
                                    <img style="border:none" src="http://mailer.dbgstage.com/images/fym/footerImg.jpg">
                                </td>
                            </tr>
                        </tbody></table>
                    </td>
                </tr>
            </tbody></table>
        </td>
  </tr>
</tbody></table>';

    $headers =  'Content-type: text/html; charset=iso-8859-1' . "\r\n" .
    'From: FYM <webmaster@fym.com>' . "\r\n" .
        'Reply-To: FYM <webmaster@fym.com>' . "\r\n
        ";
    if (mail($to, $subject, $message, $headers)){

        /*BEGIN SENT MAIL TO USER*/
        $user_message = '<table cellspacing="0" cellpadding="0" bgcolor="#eaeaea" width="100%">
                          <tbody><tr>
                            <td align="center">
                                    <table cellspacing="0" cellpadding="0" background="">
                                        <tbody><tr>
                                            <td background="" align="center" width="100%">
                                                <table cellspacing="0" cellpadding="0" width="610">
                                                    <tbody><tr bgcolor="#ffffff">
                                                        <td align="left" style="border-top:2px solid #caa50e;border-left:1px solid #cdcdcd;border-right:1px solid #cdcdcd;"><img src="http://mailer.dbgstage.com/images/fym/fym-logo.png"></td>
                                                    </tr>
                                                    <tr bgcolor="#ffffff">
                                                        <td align="left" style="padding: 22px 20px 22px 20px;border:1px solid #cdcdcd; color:#7f7f7f; border-top:none;font-family:Arial, Helvetica, sans-serif;font-size:13px;"><table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                          <tbody><tr>
                                                            <td align="center" style="padding:0px 0px 10px; font-family:Arial, Helvetica, sans-serif;font-size:18px;" colspan="2">Thank you for your interest in FYM. We will contact you once the app is released.</td>
                                                          </tr>
                                                          
                                                        </tbody></table></td>
                                                    </tr>
                                                    <tr bgcolor="#ffffff">
                                                        <td style="padding: 8px 0 8px 20px;border:1px solid #cdcdcd;color:#7f7f7f;border-top:none;border-bottom:none;font-family:Arial, Helvetica, sans-serif;font-size:11px;text-align:left;">
                                                            <p>&copy; 2015 FYM. All Rights Reserved.</p>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td height="36" style="margin:0;padding:0">
                                                            <img style="border:none" src="http://mailer.dbgstage.com/images/fym/footerImg.jpg">
                                                        </td>
                                                    </tr>
                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                          </tr>
                        </tbody></table>';
        $headers =  'Content-type: text/html; charset=iso-8859-1' . "\r\n" .
        'From: FYM <webmaster@fym.com>' . "\r\n" .
            'Reply-To: FYM <webmaster@fym.com>' . "\r\n
            ";
        if (mail($email, 'You are successfully signed up with FYM', $user_message, $headers)){
            echo json_encode(array('status'=>true));
            exit;
        } else{
            echo json_encode(array('status'=>false));
            exit;
        }

        /*END SENT MAIL TO USER*/


        
    } else {
        echo json_encode(array('status'=>false));
        exit;
    }

} else {
    echo json_encode(array('status'=>false));
    exit;
}






?>

