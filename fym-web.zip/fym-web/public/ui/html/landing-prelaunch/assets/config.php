<?php

if(isset($_SERVER['WORK_ENVIRONMENT']) && $_SERVER['WORK_ENVIRONMENT']=='development') {
    define('HOSTNAME',"localhost");
    define('DB',"fym");
    define('DB_USERNAME',"root");
    define('DB_PASSWORD',"");
    define('AWS_SES' , serialize( array(
        'key' => 'AKIAJXZA5BCZGVQOSRHA',
        'secret' => '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',
        'region' => 'us-west-2',
    )));
} else {
    define('HOSTNAME',"fymdb.c59jgus5q6nm.us-west-2.rds.amazonaws.com");
    define('DB',"fym_core");
    define('DB_USERNAME',"fymDBUser");
    define('DB_PASSWORD',"EMjmEVYVL6vn");
    define('AWS_SES' , serialize( array(
        'key' => 'AKIAJXZA5BCZGVQOSRHA',
        'secret' => '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',
        'region' => 'us-west-2',
    )));

}

define('TO_SIGNUP_EMAIL',"info@flexyourmacros.com");
define('BCC_SIGNUP_EMAIL',"ryu@digitalbrandgroup.com");
define('MAILER_FROM',"FYM <noreply@flexyourmacros.com>");
