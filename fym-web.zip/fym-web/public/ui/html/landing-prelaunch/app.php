<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title></title>
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
  <style>
    ::-moz-selection {
      background: #000;
      color: #fff;
      text-shadow: none;
    }
    ::selection {
      background: #000;
      color: #fff;
      text-shadow: none;
    }
    .terms-wrap {
      font-size: .875em;
      color: #2c2c2c;
      font-family: 'Open Sans', sans-serif;
      padding: 1.5em;
      line-height: 2;
    }
    .terms-wrap .tersm-head {
      font-size: 2em;
      font-weight: 700;
      font-family: 'Open Sans', sans-serif;
      margin: 0 0 .2em 0;
      line-height: 1.4;
    }
    .terms-wrap .terms-detail {
      margin: 0 0 1em 0;
      font-family: 'Open Sans', sans-serif;
    }
    .terms-wrap .terms-sub-head {
      margin: 2em 0 .2em 0;
      font-family: 'Open Sans', sans-serif;
      line-height: 1.4;
    }
</style>
</head>
<body>
<div id="wrapper" class="page-terms">
  <div class="terms-wrap">
    <?php
      $locale = (isset($_GET['locale']) && $_GET['locale']=='es')?"Spanish":"English";
      if (isset($_GET['type'])) {
          //Update logic when new content types available
          $type = "terms_text";
      } else {
          $type = "terms_text";
      }

      $lngFileContents = file_get_contents('language/'.$locale.'.php');
      $lngTexts = json_decode($lngFileContents,true);

      function getLangText($msgId, $lngTexts){
          return isset($lngTexts[$msgId])?$lngTexts[$msgId]:'';
      }
      echo getLangText($type, $lngTexts);
    ?>
  </div>
</div>
</body>
</html>
