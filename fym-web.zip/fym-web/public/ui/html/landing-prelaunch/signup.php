<?php
require_once('vendor/autoload.php');
require_once('assets/config.php');
use Aws\Ses\SesClient;

error_reporting(E_ALL);
ini_set('display_errors', 1);
include("assets/OBJ_mysql.php");
$db = new OBJ_mysql();
$email = isset($_POST['email'])?$_POST['email']:'';


$newUser = array(
    'email'  => $email,
    'created_date' => date('Y-m-d h:i:s'),
    'ip' => $_SERVER['REMOTE_ADDR']
 );
$query = "SELECT * FROM users WHERE email = '".addslashes($email)."'";
$result = $db->query($query);

if (!empty($result->num_rows)) {
    echo json_encode(array('status'=>false, 'code'=>'exists', 'message'=>'You are already registered.'));
    exit;
}

$new_user_id = $db->insert('users', $newUser);


if($new_user_id){

    try {
        $ses_client = SesClient::factory(unserialize(AWS_SES));

    } catch(Exception $ex) {
        echo $ex->getMessage();
    }


    $to      = TO_SIGNUP_EMAIL;
    $bcc     = BCC_SIGNUP_EMAIL;
    $subject = 'New Sign up request';

    $message = '<table cellspacing="0" cellpadding="0" bgcolor="#eaeaea" width="100%">
                  <tbody><tr>
                    <td align="center">
                            <table cellspacing="0" cellpadding="0" background="">
                                <tbody><tr>
                                    <td background="" align="center" width="100%">
                                        <table cellspacing="0" cellpadding="0" width="610">
                                            <tbody><tr bgcolor="#ffffff">
                                                <td align="left" style="border-top:2px solid #caa50e;border-left:1px solid #cdcdcd;border-right:1px solid #cdcdcd;"><img src="http://mailer.dbgstage.com/images/fym/fym-logo.png"></td>
                                            </tr>
                                            <tr bgcolor="#ffffff">
                                                <td align="left" style="padding: 22px 20px 22px 20px;border:1px solid #cdcdcd; color:#7f7f7f; border-top:none;font-family:Arial, Helvetica, sans-serif;font-size:13px;"><table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                  <tbody><tr>
                                                    <td align="center" style="padding:0px 0px 10px; font-family:Arial, Helvetica, sans-serif;font-size:18px; font-weight: bold; " colspan="2">Your have recieved a sign up request from</td>
                                                  </tr>
                                                  <tr>
                                                    <td align="center" style="padding:0px 0px 10px; font-family:Arial, Helvetica, sans-serif;font-size:22px; " colspan="2"><table cellspacing="0" cellpadding="0" border="0" width="50%">
                                                      <tbody><tr>
                                                        <td>
                                                            <div style="background:#ebebeb; border:2px solid #cdcdcd;color:#666;font-family:Arial, Helvetica, sans-serif;font-size:24px; padding:10px 8px;text-align: center;">'.$email.'</div>
                                                        </td>
                                                      </tr>
                                                    </tbody></table></td>
                                                  </tr>
                                                </tbody></table></td>
                                            </tr>
                                            <tr bgcolor="#ffffff">
                                                <td style="padding: 8px 0 8px 20px;border:1px solid #cdcdcd;color:#7f7f7f;border-top:none;border-bottom:none;font-family:Arial, Helvetica, sans-serif;font-size:11px;text-align:left;">
                                                    <p>&copy; 2015 FYM. All Rights Reserved.</p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td height="36" style="margin:0;padding:0">
                                                    <img style="border:none" src="http://mailer.dbgstage.com/images/fym/footerImg.jpg">
                                                </td>
                                            </tr>
                                        </tbody></table>
                                    </td>
                                </tr>
                            </tbody></table>
                        </td>
                  </tr>
                </tbody></table>';



    try {
        $result = $ses_client->sendEmail(array(
        'Source' => MAILER_FROM,
        'Destination' => array(
            'ToAddresses' => array($to),
            'BccAddresses' => array($bcc)
        ),
        'Message' => array(
            'Subject' => array(
                'Data' => $subject,
                'Charset' => 'UTF-8',
            ),
            'Body' => array(

                'Html' => array(
                    'Data' => $message,
                    'Charset' => 'UTF-8',
                ),
            ),
        ),
        'ReplyToAddresses' => array(MAILER_FROM)
        ));

        if ($result) {
            if (!empty($result['MessageId'])) {
                /*BEGIN SENT MAIL TO USER*/
                $user_message = '<table cellspacing="0" cellpadding="0" bgcolor="#eaeaea" width="100%">
                                  <tbody><tr>
                                    <td align="center">
                                            <table cellspacing="0" cellpadding="0" background="">
                                                <tbody><tr>
                                                    <td background="" align="center" width="100%">
                                                        <table cellspacing="0" cellpadding="0" width="610">
                                                            <tbody><tr bgcolor="#ffffff">
                                                                <td align="left" style="border-top:2px solid #caa50e;border-left:1px solid #cdcdcd;border-right:1px solid #cdcdcd;"><img src="http://mailer.dbgstage.com/images/fym/fym-logo.png"></td>
                                                            </tr>
                                                            <tr bgcolor="#ffffff">
                                                                <td align="left" style="padding: 22px 20px 22px 20px;border:1px solid #cdcdcd; color:#7f7f7f; border-top:none;font-family:Arial, Helvetica, sans-serif;font-size:13px;"><table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                                  <tbody><tr>
                                                                    <td align="center" style="padding:0px 0px 10px; font-family:Arial, Helvetica, sans-serif;font-size:18px;" colspan="2"><p style="text-align:left;font-size:13px;line-height:1.6;">Thank you for registering to receive an email notification which will include a link that will allow you to be one of the first to download the Flex Your Macros (FYM) nutrition and fitness mobile app for FREE upon its launch!  Soon you will be able to easily and conveniently create customized meal plans, tailored to your specific needs.  Achieving your health and fitness goals will be fun and exciting.  By registering to receive the FYM mobile app launch notification email, you have also been automatically entered to have a chance to win several prizes such as exclusive FYM merchandise, nutritional supplements, Titin Tech gear, DUH apparel, Beats wireless headphones and more.  For more chances to win, follow us on Facebook, Twitter, and Instagram, as winners will be randomly selected from each platform.   If you have a business within the nutrition, fitness, or wellness industry and if you are interested in promoting your business on the FYM mobile app, feel free to email us at <a href="mailto:partnerwithus@flexyourmacros.com">PartnerWithUs@FlexYourMacros.com</a>.   Once again, thank you for registering. <br/><br/>Best wishes, <br/>Team Flex Your Macros</p></td>
                                                                  </tr>

                                                                </tbody></table></td>
                                                            </tr>
                                                            <tr bgcolor="#ffffff">
                                                                <td style="padding: 8px 0 8px 20px;border:1px solid #cdcdcd;color:#7f7f7f;border-top:none;border-bottom:none;font-family:Arial, Helvetica, sans-serif;font-size:11px;text-align:left;">
                                                                    <p>&copy; 2015 FYM. All Rights Reserved.</p>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="36" style="margin:0;padding:0">
                                                                    <img style="border:none" src="http://mailer.dbgstage.com/images/fym/footerImg.jpg">
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        </td>
                                  </tr>
                                </tbody></table>';

                try {
                    $result = $ses_client->sendEmail(array(
                    'Source' => MAILER_FROM,
                    'Destination' => array(
                        'ToAddresses' => array($email),
                    ),
                    'Message' => array(
                        'Subject' => array(
                            'Data' => 'You are successfully signed up with FYM',
                            'Charset' => 'UTF-8',
                        ),
                        'Body' => array(

                            'Html' => array(
                                'Data' => $user_message,
                                'Charset' => 'UTF-8',
                            ),
                        ),
                    ),
                    'ReplyToAddresses' => array(MAILER_FROM)
                    ));
                    echo json_encode(array('status'=>true));
                }catch (\Exception $ex) {
                    echo json_encode(array('status'=>false, 'code'=>'email', 'message'=>$ex->getMessage()));
                    exit;
                }
                /*END SENT MAIL TO USER*/
            } else {
                echo json_encode(array('status'=>false));
                exit;
            }
        }

    } catch (\Exception $ex) {
        echo json_encode(array('status'=>false, 'code'=>'email', 'message'=>$ex->getMessage()));
        exit;
    }

} else {
    echo json_encode(array('status'=>false, 'code'=>'error', 'message'=>'Please try later'));
    exit;
}






?>

