<?php
    error_reporting(E_ALL);
            ini_set('display_errors', 1);
session_start();
if(!isset($_SESSION['language'])) {
    $_SESSION['language'] = 'English';
}
setcookie('FymLang', $_SESSION['language'], time() + (86400 * 30), "/");
$lngFileContents = file_get_contents('language/'.$_SESSION['language'].'.php');
$lngTexts = json_decode($lngFileContents,true);
function getLangText($msgId, $lngTexts){
    echo isset($lngTexts[$msgId])?$lngTexts[$msgId]:'';
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
    	<meta charset="utf-8">
    	<title>Flex Your Macros</title>
    	<meta name="description" content="">
    	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    	<link rel="stylesheet" href="css/pure/pure-min.css">
      <!--[if lte IE 8]>
        <link rel="stylesheet" href="css/pure/grids-responsive-old-ie-min.css">
      <![endif]-->
      <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="css/pure/grids-responsive-min.css">
      <!--<![endif]-->

    	<link rel="stylesheet" href="css/common-base-min.css" media="screen, projection" />
    	<link rel="stylesheet" href="css/base.css" media="screen, projection" />
		  <link rel="stylesheet" href="css/print.css" media="print" />

      <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
      <link rel="icon" href="./images/favicon.ico" type="image/x-icon">

      <link rel="stylesheet" href="css/slider/slick.css" media="screen, projection" />
      <link href='http://fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
      <!-- The google analytics code -->
      <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

        ga('create', 'UA-59658922-1', 'auto');
        ga('send', 'pageview');
      </script>

    </head>
    <body>
        <div id="wrapper" class="page-terms">
            <header>
                <div class="header">
                    <div class="top-login">
                        <div class="mid-container pure-g">
                            <div class="pure-u-1">
                                <ul class="lang-link">
                                    <li>
                                        <a href="javascript:;" class="default-lang"><?php echo $_SESSION['language'];?></a>
                                        <ul class="lang-sub-link hide">
                                            <?php if($_SESSION['language']!='English'):?>
                                                <li><a href="javascript:;" data-lang="English" class="links lngLink">English</a></li>
                                            <?php endif;?>
                                            <?php if($_SESSION['language']!='Spanish'):?>
                                                <li><a href="javascript:;" data-lang="Spanish" class="links lngLink">Spanish</a></li>
                                            <?php endif;?>
                                        </ul>
                                    </li>
                                </ul>
                                <a href="#" class="login-link hide">Login</a>
                            </div>
                        </div>
                    </div>
                    <div class="main-nav">
                        <div class="mid-container pure-g">
                            <div class="pure-u-1 pure-u-md-1-4 pure-u-lg-1-4 pure-u-sm-1-2">
                                <h1 class="fym-logo float-left"><a href="index.php" title="FYM">FYM</a></h1>
                            </div>
                            <div class="pure-u-1 pure-u-md-3-4 pure-u-lg-3-4 pure-u-sm-1-2 hide">
                                <div class="main-nav-bar">
                                    <a href="#" class="nav-item" title="Home">Home</a>
                                    <a href="#" class="nav-item" title="Community Forum">Community Forum</a>
                                    <a href="#" class="nav-item" title="Store">Store</a>
                                    <a href="#" class="nav-item" title="Contact">Contact</a>
                                    <a href="#" class="nav-item download-app" title="Download App Now!">Download App Now!</a>
                                </div>
                                <a href="#" id="humburger-btn" title="humburger menu" class="humburger-icon hamburger-icon hide">humburger menu</a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <div class="clear"></div>




            <div class="mid-container">
                <div class="terms-wrap">
                    <?php getLangText('terms_text',$lngTexts);?>
                </div>
            </div>

            <div class="grey-bg pre-footer hide">
                <div class="mid-container pure-g">
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4"><a href="#" class="corporate-member almond-breeze"><img src="./images/home/almond-breeze.png" alt=""></a></div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4"><a href="#" class="corporate-member"><img src="./images/home/subway.png"  alt=""></a></div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4"><a href="#" class="corporate-member"><img src="./images/home/jennieO.png" alt=""></a></div>
                    <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4"><a href="#" class="corporate-member"><img src="./images/home/massage-envy.png" alt=""></a></div>
                </div>
            </div>
            <footer id="footer">
                <div class="mid-container">
                  <div class="footer-wrap pure-g">
                    <div class="pure-u-1-2 pure-u-md-1-2 pure-u-lg-1-2 footer-nav-item">
                        <div class="footer-menu">
                            <a href="terms.php" class="menu-item" title="Terms and Conditions"><?php getLangText('terms_link',$lngTexts);?></a>
                            <!-- <a href="#" class="menu-item" title="Privacy">Privacy</a>
                            <a href="#" class="menu-item" title="FAQ">FAQ</a>
                            <a href="#" class="menu-item" title="Contact">Contact</a> -->
                        </div>
                    </div>
                    <div class="pure-u-1-2 pure-u-md-1-2 pure-u-lg-1-2">
                        <div class="social-icons">
                            <a href="//www.facebook.com/flexyourmacros" title="Facebook" class="icon facebook" target="_blank">Facebook</a>
                            <!-- <a href="#" title="Twitter" class="icon twitter">Twitter</a>
                            <a href="#" title="Pinterest" class="icon pinterest">Pinterest</a> -->
                            <a href="//instagram.com/flexyourmacros" title="Instagram" class="icon instagram" target="_blank">Instagram</a>
                        </div>
                    </div>
                  </div>
                </div>
            </footer>
        </div>
        <script src="js/modernizr/modernizr-2.8.1.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="js/slider/slick.js" ></script>
        <script src="js/common.js" ></script>
    </body>
</html>
