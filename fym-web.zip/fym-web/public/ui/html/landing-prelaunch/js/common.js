$(document).ready(function(){

   //  if ($.browser.msie  && parseInt($.browser.version, 10) < 7) {
   //      $('body').append('<p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>');
   //  }

/* =============================================================================
   Function to Clear Inputs on Click
=============================================================================*/

    $.fn.search = function() {
        return this.focus(function() {
            if( this.value == this.defaultValue ) {
                this.value = "";
            }
        }).blur(function() {
            if( !this.value.length ) {
                this.value = this.defaultValue;
            }
        });
    };

});
$("#humburger-btn").click(function(){
  $("#hamburger-menu").toggle();
});
$('.variable-width').slick({
  infinite: true,
  speed: 300,
  slidesToShow: 3,
  swipeToSlide: true,
  responsive: [{
    breakpoint: 960,
    settings: {
      slidesToShow: 1,
      variableWidth: true,
      centerMode: true
    }
  }]
});
$('#footer-scroll').slick({
  autoplay: true,
  autoplaySpeed: 2000,
  slidesToShow: 4,
  speed: 300,
  swipeToSlide: true,
  responsive: [{
    breakpoint: 768,
    settings: {
      slidesToShow: 1,
      variableWidth: true,
      centerMode: true
    }
  }]
});

var signUp = function () {

    return {

        init: function () {
            this.addEvents();
            this.initExternalScripts();
        },
        initExternalScripts: function () {

        },
        showError:function(selector, messageId){
          var language = getCookie('FymLang');
          var text = '';
          if(language == 'Spanish') {
              if(messageId == 'invalidEmail')
                text =  'no válida de correo electrónico';
              else if(messageId == 'tryLater')
                text =  'Vuelva a intentarlo más tarde.';
              else if(messageId == 'signedUpSuccess')
                text =  'Registrado con éxito .';
              else if(messageId == 'emailRequired')
                text =  'Firmado con éxito.';


          } else {
              if(messageId == 'invalidEmail')
                text =  'Invalid Email';
              else if(messageId == 'tryLater')
                text =  'Please retry later.';
              else if(messageId == 'signedUpSuccess')
                text =  'Signed Up Successfully.';
              else if(messageId == 'emailRequired')
                text =  'Email Id Required';
          }
          $(selector).html(text);
        },
        addEvents: function () {
                $('#frmSignUp').submit(function(e){
              e.preventDefault();
              $('#lblError').html('');
              var email = $('#email').val();
              var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
              if($.trim(email)==''){
                signUp.showError('#lblError','emailRequired');
                return;
              }

              if(regex.test(email)) {
                  var postUrl = 'signup.php';
                  $.post(postUrl,
                      {email : email},
                      function(response) {
                         if(response.status) {
                            $('#lblError').html('');
                            signUp.showError('#lblSuccess','signedUpSuccess');
                            var tId;
                            $("#messageBox").hide().slideDown();
                            clearTimeout(tId);
                            tId=setTimeout(function(){
                                $("#messageBox").slideUp(function(){
                                  $('#email').val('');
                                });
                            }, 2000);

                         } else {
                            $('#lblError').html(response.message);
                         }
                      },
                      'json'
                  );
              } else {
                  $('#lblError').text('invalidEmail');
              }
          });

          $('.default-lang').click(function(){
              $('.lang-sub-link').toggleClass('hide');
          })

          $('.lngLink').click(function(){
                var lang    = $(this).attr('data-lang');
                var postUrl = 'language.php';
                $.post(postUrl,
                    {language : lang},
                    function(response) {
                       if(response.status) {
                          location.reload();
                       } else {

                       }
                    },
                    'json'
                );
          });

          $(document).mouseup(function (e)
          {
              var container = $(".lang-link");
              if (!container.is(e.target)   && container.has(e.target).length === 0)  {
                  $('.lang-sub-link').addClass('hide');
              }
          });

        }
    };
}();
$(function() {
    signUp.init();
    $('#scroll-to-signup').click(function(e){
      e.preventDefault();
      scrollToElement( $(this).attr('href'), 1000 );
    });
    $('.corporate-member').click(function(e) {
      e.preventDefault();
    });
});


function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
    return "";
}


var scrollToElement = function(el, ms){
    var speed = (ms) ? ms : 600;
    $('html,body').animate({
        scrollTop: $(el).offset().top
    }, speed);
}
