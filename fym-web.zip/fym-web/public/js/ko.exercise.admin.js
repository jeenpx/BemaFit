var ViewModel = function(data) {
          var self = this;

          self.items = ko.observableArray(data);

          //Table headers
          self.headers = [
            {title:'NAME',sortPropertyName:'name', propertyClass:'sortable',width:'41%', asc: false},
            {title:'EXERCISE TYPE',sortPropertyName:'exercisetypename', propertyClass:'sortable',width:'23%', asc: true},
            {title:'ENGLISH/SPANISH',sortPropertyName:'languagename', propertyClass:'sortable',width:'23%', asc: true},
            {title:'MANAGE',sortPropertyName:'', propertyClass:'',width:'13%',asc: true}];

          self.activeSort = self.headers[0]; //set the default sort
          self.activeSortNameArrow  = ko.observable('<span class="table-sort"></span>');
          self.activeSortTypeArrow  = ko.observable('<span class="table-sort"></span>');
          self.activeSortLngArrow   = ko.observable('<span class="table-sort"></span>');
          self.sort = function(header,event){
            //if this header was just clicked a second time
            if(self.activeSort === header) {
                header.asc = !header.asc; //toggle the direction of the sort
            } else {
                self.activeSort = header; //first click, remember it
            }

            var prop = self.activeSort.sortPropertyName;
            //implementation of sort
            var ascSort = function(a,b){ 
              if(prop == 'name')
              {
                self.activeSortNameArrow('<span class="table-sort-up"></span>');
                self.activeSortTypeArrow('<span class="table-sort"></span>');
                self.activeSortLngArrow('<span class="table-sort"></span>');
  
              }
              if(prop == 'exercisetypename')
              {
                self.activeSortNameArrow('<span class="table-sort"></span>');
                self.activeSortTypeArrow('<span class="table-sort-up"></span>');
                self.activeSortLngArrow('<span class="table-sort"></span>');
  
              }
              if(prop == 'languagename')
              {
                self.activeSortNameArrow('<span class="table-sort"></span>');
                self.activeSortTypeArrow('<span class="table-sort"></span>');
                self.activeSortLngArrow('<span class="table-sort-up"></span>');
  
              }
              return a[prop].toLowerCase() < b[prop].toLowerCase() ? -1 : a[prop].toLowerCase() > b[prop].toLowerCase() ? 1 : a[prop].toLowerCase() == b[prop].toLowerCase() ? 0 : 0; 
            };
            var descSort = function(a,b){ 
              if(prop == 'name')
              {
                self.activeSortNameArrow('<span class="table-sort"></span>');
                self.activeSortTypeArrow('<span class="table-sort"></span>');
                self.activeSortLngArrow('<span class="table-sort"></span>');
  
              }
              if(prop == 'exercisetypename')
              {
                self.activeSortNameArrow('<span class="table-sort"></span>');
                self.activeSortTypeArrow('<span class="table-sort"></span>');
                self.activeSortLngArrow('<span class="table-sort"></span>');
  
              }
              if(prop == 'languagename')
              {
                self.activeSortNameArrow('<span class="table-sort"></span>');
                self.activeSortTypeArrow('<span class="table-sort"></span>');
                self.activeSortLngArrow('<span class="table-sort"></span>');
  
              }
              return a[prop].toLowerCase() > b[prop].toLowerCase() ? -1 : a[prop].toLowerCase() < b[prop].toLowerCase() ? 1 : a[prop].toLowerCase() == b[prop].toLowerCase() ? 0 : 0; 
            };
            var sortFunc = self.activeSort.asc ? ascSort : descSort;
            self.items.sort(sortFunc);
            //self.currentPage(1);
          };

          // Pagination stuff
          // pager related stuff
    // ---------------------------------------------
        this.currentPage = ko.observable(1);
        this.searchQuery = ko.observable('');
        this.perPage = 15;
        self.filteredItems      = ko.observableArray([]);
        self.usedFilters        = ko.observableArray([]);
        self.userStatusFilter   = ko.observable(''); 
        self.exercisFilter      = "";
        //self.main_data = this.items();
        this.pagedItems = ko.computed(function(){

          self.filteredItems(self.items());
          if(self.searchQuery() != "")
          {
            var searchFiltered = _.filter(self.filteredItems(), function (i) {

                return (i.name.toLowerCase().indexOf(this.keys ) )  > -1;


              }, {
                  "keys": [self.searchQuery().toLowerCase()]  // values to look for
              });
             self.filteredItems(searchFiltered) ;
          }
          if((this.userStatusFilter() != "undefined") && (this.userStatusFilter() != "all") )
          {
            var userFiltered = _.filter(self.filteredItems(), function (i) {
                return this.keys.indexOf(i.exercisetypename.toLowerCase()) > -1;
              }, {
                  "keys": [this.userStatusFilter()]  // values to look for
              });
             self.filteredItems(userFiltered) ;
          }
          var pg = this.currentPage(),
              start = this.perPage * (pg-1),
              end = start + this.perPage;
              return  self.filteredItems.slice(start,end);

        }, this);


        self.searchData = function(value) {
          var newData = [];         
          var oldData = [];      
            _.each(self.items(), function(eachData,key) {
              oldData.push(eachData);
            if (eachData.name.toLowerCase().indexOf(value.toLowerCase()) >= 0) {
              newData.push(eachData);
            }

          });
          if (value == '') {
            self.items(oldData);
            self.currentPage(1);

          }
          else{
            self.filteredItems(newData); 
            self.currentPage(1);

          }
          //console.log(self.items())
        };
        self.activeUserCount = ko.computed(function() {
          

              if(self.searchQuery() != "")
              {
                var searchFilteredLsa = _.filter(self.items(), function (i) {

                    return (i.name.toLowerCase().indexOf(this.keys ) )  > -1;


                  }, {
                      "keys": [self.searchQuery().toLowerCase()]  // values to look for
                  });
              }
              else
              {
                 var searchFilteredLsa = self.items();
              }
              var activeUsers = _.filter(searchFilteredLsa, function (i) {

                return this.keys.indexOf(i.exercisetypename.toLowerCase()) > -1;
              }, {
                  "keys": ["cardiovascular"]  // values to look for
              });
             return activeUsers.length;
        });
        self.inActiveUserCount = ko.computed(function() {


              if(self.searchQuery() != "")
              {
                var searchFilteredLs = _.filter(self.items(), function (i) {

                    return (i.name.toLowerCase().indexOf(this.keys ) )  > -1;

                  }, {
                      "keys": [self.searchQuery().toLowerCase()]  // values to look for
                  });
                  
              }
              else
              {
                   var searchFilteredLs = self.items();
              }

              var inActiveUsers = _.filter(searchFilteredLs, function (i) {
                return this.keys.indexOf(i.exercisetypename.toLowerCase()) > -1;
              }, {
                  "keys": ["strength"]  // values to look for
              });
              
          return inActiveUsers.length;
        });
       

        self.totalItemCount =  ko.computed(function() {
          if(self.searchQuery() != "")
              {
                var searchFilteredLs = _.filter(self.items(), function (i) {

                    return (i.name.toLowerCase().indexOf(this.keys ) )  > -1;


                  }, {
                      "keys": [self.searchQuery().toLowerCase()]  // values to look for
                  });
                  return searchFilteredLs.length;
              }

          return self.items().length;
        });



        self.userStatusOptions = ko.computed(function() {
            var returnArray = [{"statusvalue":"All Exercise ("+self.totalItemCount()+")","exercisetypename":"all"},{"statusvalue":"Cardiovascular ("+self.activeUserCount()+")","exercisetypename":"cardiovascular"},{"statusvalue":"Strength ("+self.inActiveUserCount()+")","exercisetypename":"strength"}];
            //console.log(returnArray);
            return returnArray;
        }); 


        self.updateUI = function(){
          if(self.exercisFilter == "")
          {
            self.exercisFilter = $("#exercise-filter").msDropDown().data('dd');  
          }
          else
          {
            self.exercisFilter.destroy();  
            self.exercisFilter = $("#exercise-filter").msDropDown().data('dd');  

          }
          
          
        }

        self.totalItemCount.subscribe(self.updateUI);
        self.inActiveUserCount.subscribe(self.updateUI);
        self.activeUserCount.subscribe(self.updateUI);

        self.userStatusFilter.subscribe(function(newValue) {
            self.updateUI();
            self.currentPage(1);
        });

        this.searchQuery.subscribe(this.searchData);
        this.totalItems = ko.computed(function(){
            return this.filteredItems().length;
        }, this);


        this.totalPageList = ko.observableArray([]);
        this.totalPageListArray = ko.observableArray([]);
        this.totalPages = ko.computed(function() {
            var div = Math.floor(this.totalItems() / this.perPage);
            div     += this.totalItems() % this.perPage > 0 ? 1 : 0;
            this.totalPageList.removeAll();
            this.totalPageListArray.removeAll();
            //Adding first 2 pages
            var lastItem = 1;
            for (var i = 1; i <= 2; i++) {
                if(i < div)
                {
                  if(this.currentPage() == i)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = ""; 
                  }
                  var newPageLink = {linkNumber:i, linkClass:pageLinkClass}; 
                  this.totalPageListArray.push(newPageLink);                   
                  this.totalPageList.push(i); 
                  lastItem = i; 
                }
            }
            // Adding 2 previous pages
            for (var i = 2; i > 0; i--) {
                var nextItem = this.currentPage()  - i;
                if(nextItem > 0 && (jQuery.inArray(nextItem, this.totalPageList())===-1))
                {
                  if((nextItem - lastItem ) > 1)
                  {
                    var newPageLink = {linkNumber:'..', linkClass:'disabled'}; 
                    this.totalPageListArray.push(newPageLink);
                    this.totalPageList.push('..');  
                  }
                  if(this.currentPage() == nextItem)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = ""; 
                  }
                  var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass}; 
                          
                  this.totalPageListArray.push(newPageLink);   
                  this.totalPageList.push(nextItem );
                  lastItem = nextItem;   
                }  
            }
            //Adding current page
            var nextItem = this.currentPage();
            if((jQuery.inArray(nextItem, this.totalPageList()) ===-1))
            {
              if((nextItem - lastItem ) > 1)
              {
                  var newPageLink = {linkNumber:'..', linkClass:'disabled'}; 
                  this.totalPageListArray.push(newPageLink);
                  this.totalPageList.push('..');  
              }
              
              if(this.currentPage() == nextItem)
              {
                var pageLinkClass = "active";
              }
              else
              {
                var pageLinkClass = ""; 
              }
              var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass}; 
              this.totalPageListArray.push(newPageLink); 
              this.totalPageList.push(nextItem);  
              lastItem = nextItem;    
            }
            //Adding Next pages
            for (var i = 1; i <= 2; i++) {
                var nextItem = this.currentPage()  + i;
                if((nextItem - lastItem ) > 1)
                {
                   var newPageLink = {linkNumber:'..', linkClass:'disabled'}; 
                          
                    this.totalPageListArray.push(newPageLink);
                    this.totalPageList.push('..');  
                }
                if(nextItem  <= div && (jQuery.inArray(nextItem, this.totalPageList()) ===-1))
                {
                  if(this.currentPage() == nextItem)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = ""; 
                  }
                  var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass}; 
                  this.totalPageListArray.push(newPageLink); 
                  this.totalPageList.push(nextItem);  
                }  
                lastItem = nextItem;
            }
            //Adding last 2 pages
            for (var i = 1; i >= 0; i--) {
                var nextItem = div  - i;
                if((nextItem - lastItem ) > 1)
                {
                    var newPageLink = {linkNumber:'..', linkClass:'disabled'}; 
                    this.totalPageListArray.push(newPageLink);
                    this.totalPageList.push('..');  
                }
                if(nextItem  > 0 && (jQuery.inArray(nextItem, this.totalPageList())===-1))
                {
                  if(this.currentPage() == nextItem)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = ""; 
                  }
                  var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass}; 
                  this.totalPageListArray.push(newPageLink); 
                  this.totalPageList.push(nextItem);   
                }  
                lastItem = nextItem;
            }
            
            return div;

        }, this);

          self.pageController = function(targetPage) {
          if(targetPage.linkNumber != '..')
          {
            return self.currentPage(targetPage.linkNumber);  
          }
          else
          {
            return false;
          }
          
        }

         this.nextPage = function(){
        if(this.nextPageEnabled())
          this.currentPage(this.currentPage()+1);
        };

        this.nextPageEnabled = ko.computed(function(){
          return this.filteredItems().length > this.perPage * this.currentPage();
        },this);

        this.previousPage = function(){
        if(this.previousPageEnabled())
            this.currentPage(this.currentPage()-1);
        };
        this.previousPageEnabled = ko.computed(function(){
            return this.currentPage() > 1;
        },this);
        //Edit Items
        self.editExercise = function(item) {
          Fym.exercise.exerciseEdit(item.id);
        };
        //Removing Items
        self.removeItem = function(item) {
              $( "#dialog" ).dialog({
                  autoOpen: true,
                  width: 360,
                  modal: true,
                  open: function( event, ui ) {
                    $(this).removeClass('hide');
                  },
                  close: function( event, ui ) {
                    $(this).addClass('hide');
                  },
                  buttons: [
                    {
                      text: "No, Cancel Request",
                      click: function() {
                        $( this ).dialog( "close" );
                      }
                    },
                    {
                      text: "Yes, Remove this item",
                      click: function() {

                        dataRem= {exerciseId: item.id}
                        Fym.eW.Services.post("removeExercise", dataRem, function (response) {
                          if(response.msg=="Sucess") {
                            self.items.remove(item);
                            if(self.currentPage()!=1) {
                              self.totalItems() % self.perPage == 0 ? self.currentPage(self.currentPage()-1) : self.currentPage();
                            }
                            self.updateUI();

                          }
                        });
                        $( this ).dialog( "close" );
                      }
                    }
                  ]
              });

              
        };    
   
};
var ViewModelObj = new ViewModel(dataSource);
ko.applyBindings(ViewModelObj);

