/* FYM BASE CONFIGURATIONS */
// Code to instantiate the base class/create if not create
var Fym = window.Fym || {};
// Create the core functions of the base namespace eW=>entertainmentWorkflow denotes its root
Fym.eW = Fym.eW || {};
Fym.exercise = Fym.exercise || {};
Fym.ad = Fym.ad || {};
Fym.user = Fym.user || {};
Fym.business = Fym.business || {};
Fym.meal = Fym.meal || {};
// Code to create the common service namespace 
// associate with the base class which extents in the eW class
Fym.eW.Services = Fym.eW.Services || {};
//Other utility function declaration
Fym.eW.Utils = Fym.eW.Utils || {};