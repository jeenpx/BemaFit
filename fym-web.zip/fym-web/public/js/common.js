$(document).ready(function(){

   //  if ($.browser.msie  && parseInt($.browser.version, 10) < 7) {
   //      $('body').append('<p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>');
   //  }

/* =============================================================================
   Function to Clear Inputs on Click
=============================================================================*/

    $.fn.search = function() {
        return this.focus(function() {
            if( this.value == this.defaultValue ) {
                this.value = "";
            }
        }).blur(function() {
            if( !this.value.length ) {
                this.value = this.defaultValue;
            }
        });
    };

});

