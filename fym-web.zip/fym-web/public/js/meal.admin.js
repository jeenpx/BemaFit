var old_spa_name="";
var old_spa_description="";
var old_spa_brand="";
var old_eng_name="";
var old_eng_description="";
var old_eng_brand="";

Fym.meal = {
    init: function() {
        $('#upload-form').validate();

        $('#vendor-verified').click(function() {
            if ($('#vendor-verified' ).is(":checked")) {
                $('#meal-image-section' ).show();
                $('#select-files-section' ).show();
                $('#uploaded-image-section' ).hide();
                $('html, body').animate({ scrollTop: $('#meal-image-section').offset().top }, 'slow');
                $.colorbox.resize();
            } else {
                $('#meal-image-section' ).hide();
                $.colorbox.resize();
            }
        });
        $('.meal_language').on('ifChecked', function(event){
            if($(this).val()==2) {
                $( "#spanish-div" ).show();
                $( "#description-spanish-div" ).show();
                $( "#spanish-brand-div" ).show();
                $('#lan_en').icheck('enabled');
                $('#spanish-div > .form__element-block--first').addClass('margin-top-10');
                $('#spanish-brand-div > .form__element-block--last').addClass('margin-top-10');
                $('#meal_name_spa').val(old_spa_name);
                $('#description_spa').val(old_spa_description);
                $('#brand-name-spa').val(old_spa_brand);
            }
            if($(this).val()==1) {
                $( "#english-div" ).show();
                $( "#description-english-div" ).show();
                $( "#english-brand-div" ).show();
                if($('#lan_spa').prop('checked') == true){
                    $('#spanish-div > .form__element-block--first').addClass('margin-top-10');
                    $('#spanish-brand-div > .form__element-block--last').addClass('margin-top-10');
                }
                $('#meal-name').val(old_eng_name);
                $('#description').val(old_eng_description);
                $('#brand-name').val(old_eng_brand);

            }
            $.colorbox.resize();
        });
        $('.meal_language').on('ifUnchecked', function(event){
            if($(this).val()==2) {
                $( "#spanish-div" ).hide();
                $( "#description-spanish-div" ).hide();
                $( "#spanish-brand-div" ).hide();
                $('#lan_en').icheck('checked');
                $('#lan_en').icheck('disabled');
                old_spa_name=$('#meal_name_spa').val();
                old_spa_description=$('#description_spa').val();
                old_spa_brand=$('#brand-name-spa').val();
                $('#meal_name_spa').val("");
                $('#description_spa').val("");
                $('#brand-name-spa').val("");
                // if($('#lan_en').prop('checked') == false){
                //     $( "#english-div" ).show();
                // }
            }
            if($(this).val()==1) {
               if($('#lan_spa').prop('checked') == true){
                $( "#english-div" ).hide();
                $( "#description-english-div" ).hide();
                $( "#english-brand-div" ).hide();
                $('#spanish-div > .form__element-block--first').removeClass('margin-top-10');
                $('#spanish-brand-div > .form__element-block--last').removeClass('margin-top-10');
               }
               old_eng_name=$('#meal-name').val();
               old_eng_description=$('#description').val();
               old_eng_brand=$('#brand-name').val();
               $('#meal-name').val("");
               $('#description').val("");
               $('#brand-name').val("");
                
            }
            $.colorbox.resize();

        });
        $('.meal_nutrition').focus(function() {
            $( ".nutritionLabel" ).removeClass( "txt-black" );
            $( ".meal_nutrition" ).removeClass("txt-black");
            $(this).addClass( "txt-black" );
            $( "#nutritionLabel"+$(this).attr("data") ).addClass( "txt-black" );
        });
        $('#addCategory').click(function() {
            $("#addCategoriesForm").submit();
        });
        $(document).on('click', '#categorySave', function(){
              $('#editCategoriesForm').ajaxSubmit({
                   url: 'editMealCategories',
                   type: 'post',
                   success: function (response) {
                        var catagoryFilteroptionList=[];
                        var catagoryFilterList="";
                        $('#meal-category-form-list').empty();
                        $.each(response.categories, function(key,category) {
                            catagoryFilteroptionList.push( new filter(category.name,"category","checkbox"));
                            $("#meal-category-form-list").append('<li><input tabindex="3" type="checkbox" class="category-meal" value='+category.id+' name="category[]" id="input-3"><label for="input-3">'+category.name+'</label></li>');
                        });

                        newavailFilterArray   = [
                                                    {title:'Language',name:'language', optiontype:'radio' , optionList:[
                                                      new filter("English","language",'radio'),
                                                      new filter("Spanish","language",'radio'),
                                                      new filter("Both","language",'radio'),
                                                      new filter("All","language",'radio')    ]},
                                                    {title:'Meal Type',name:'mealtype', optiontype:'checkbox', optionList:[
                                                      new filter("Breakfast","mealtype",'checkbox'),
                                                      new filter("Lunch","mealtype",'checkbox'),
                                                      new filter("Dinner","mealtype",'checkbox'),
                                                      new filter("Snacks","mealtype",'checkbox')   ]},
                                                    {title:'Vendor Verified',name:'vendorstatus', optiontype:'radio', optionList:[
                                                      new filter("Verified","vendorstatus",'radio'),
                                                      new filter("Unverified","vendorstatus",'radio'),
                                                      new filter("Both","vendorstatus",'radio') ]},
                                                    {title:'Categories',name:'category', optiontype:'checkbox', optionList:catagoryFilteroptionList}

                        ];

                        mealKoObject.availableFilters3  = ko.mapping.fromJS(newavailFilterArray);
                        mealKoObject.availableFilters( mealKoObject.availableFilters3());
                        if (mealKoObject.isFiltered()){
                            mealKoObject.isFiltered(false);
                        } else{
                            mealKoObject.isFiltered(true);
                        }
                        //newDataSource=response.meallist;
                        //mealKoObject.newDataSource1  = ko.observableArray(newDataSource);
                        //mealKoObject.items(mealKoObject.newDataSource1());
                        $('#filter-meals input').icheck({
                            checkboxClass: 'icheckbox_square-blue',
                            radioClass: 'iradio_square-blue',
                            increaseArea: '20%'
                        });
                        $(".category-meal").icheck({
                            checkboxClass: 'icheckbox_square-blue',
                            radioClass: 'iradio_square-blue',
                            increaseArea: '20%'
                        });
                        $('#categoryMessageSections').html("");
                        $('#categoryMessageSections').html("Updated Successfully");
                        $.colorbox.resize({
                            innerHeight:$('#category-content').outerHeight()+5
                        });

                        // Fym.eW.Services.post("getMealsData",function (response) {

                        // });
                        $.ajax({
                            url: "getMealsData",
                            type: "get",
                            dataType: 'json',
                            success : function (response) {
                                newDataSource=response.meallist;
                                mealKoObject.newDataSource1  = ko.observableArray(newDataSource);
                                mealKoObject.items(mealKoObject.newDataSource1());
                            }
                        });

                   }

              });
        });
        $.extend($.ui.autocomplete.prototype.options, {
            open: function(event, ui) {
                $(this).autocomplete("widget").css({
                    "width": ($(this).outerWidth() + "px")
                });
            }
        });
        $('#autocomplete-meal-unit').autocomplete({
            source: function (request, response)
            {
                $.ajax({
                    url: "unitSelect",
                    dataType: "json",
                    method: "POST",
                    data:
                    {
                        searchValue: request.term,
                    },
                    success: function (data)
                    {
                        response($.map(data, function(v,i){
                                return {
                                    label: v.name,
                                    id: v.id
                                };
                        }));
                    }
                });
            },
            select: function( event, ui ) {
                $("#mealUnitId").val(ui.item.id);

            },
            minLength: 1
        });
        $('#submitMeal').click(function() {
            //alert("abcdd");
            //$("#upload-form").hide();
            //alert($('#addadForm').valid());
            // if($('#brand-name').val()=="") {
            //     $('#brand-name').html("Meal Name is required");
            // }

            //alert($('#meal-name').val());

            // if($.trim($('#meal-name').val())=="") {
            //     $('#error_name').html("Meal Name is required");
            //     //return false;
            // }
            // if($.trim($('#brand-name').val())=="") {
            //     $('#error_brand').html("Brand Name is required");
            //     //return false;
            // }
            // if($.trim($('#meal-name').val())=="" || $.trim($('#brand-name').val())=="") {
            //     return false;

            // }
            // $.colorbox.resize();
            //$("#upload-form").show();

        });
        $("#add-meal").colorbox({
            inline:true,
            width:"600px",
            onComplete:function(){
                $("label.error").html("").hide();
                $(".form__group-control").not(".new").val("");
                $( ".form__group-control" ).removeClass( "error" );
                $( ".option__unit--entry" ).removeClass( "error" );
                $( ".nutritionLabel" ).removeClass( "txt-black" );
                $(".option__unit--entry").val("");
                $("#mealId").val("");
                $("#mealIndex").val("");
                $("#mealImageLocation").val("");
                $("#mealImageResizeLocation").val("");
                $("#serving-size-unit").msDropdown({mainCSS:'dd3'});
                $('#meal-image-section' ).hide();
                $('#submitMeal').removeAttr('disabled').removeClass('button--loader');
                //$('#vendor-verified').icheck('uncheck');
                $('#addMealForm input').icheck('unchecked');
                $(".meal_language[value='1']").icheck('checked');
                $( "#spanish-div" ).hide();
                $( "#spanish-brand-div" ).hide();
                $( "#description-spanish-div" ).hide();
                $('#lan_en').icheck('disabled');
                //Custom scroll pane
                $('.scroll-pane').jScrollPane();
                //var state = $("#state").msDropdown().data("dd");
                //var days = $(".days").msDropdown().data("dd");
                //var amountMin = $("#amount-min").msDropdown().data("dd");
                //var amountSec = $("#amount-sec").msDropdown().data("dd");

                // Set the visible rows of the select box.
                //state.showRows(5);
                //days.showRows(5);
                //amountMin.showRows(5);
                //amountSec.showRows(5);
            }
        });
        jQuery.validator.addMethod("selectimage", function(value, element){
            if($('#vendor-verified').is(':checked')) {
                if ($("#mealImageLocation").val()=="") {
                    return false;
                } else {
                    return true;
                };
            } else {
                return true;
            }

        }, "Meal Image is required");
        $.validator.addMethod("nutrition_message", $.validator.methods.number,
        "Nutrition should be number");
        $.validator.addMethod("nutrition_required_message", $.validator.methods.required,
        "Nutrition is required");
        jQuery.validator.addClassRules('meal_nutrition_validate[]', {
                nutrition_message: true,
                nutrition_required_message:true
                 /*,
                other rules */
        });
        $('#addMealForm').validate({ // initialize the plugin
            onfocusout: false,
            ignore: [],
            rules: {
                meal_name: {
                    required: function(element) {
                        if($("#meal_name_spa").val()!="") {
                            return false;
                        } else {
                            return true;
                        }
                        //return $("#exercise_name_spa").is(':empty');
                    }
                },
                meal_name_spa: {
                    required: function(element) {
                        if($("#meal-name").val()!="") {
                            return false;
                        } else {
                            return true;
                        }
                    }
                },
                /*description: {
                    required: function(element) {
                        if($("#description_spa").val()!="") {
                            return false;
                        } else {
                            return true;
                        }
                        //return $("#exercise_name_spa").is(':empty');
                    }
                },
                description_spa: {
                    required: function(element) {
                        if($("#description").val()!="") {
                            return false;
                        } else {
                            return true;
                        }
                        //return $("#exercise_name_spa").is(':empty');
                    }
                },*/
                brand_name: {
                    required: function(element) {
                        if($("#brand-name-spa").val()!="") {
                            return false;
                        } else {
                            return true;
                        }
                        //return $("#exercise_name_spa").is(':empty');
                    }
                },
                brand_name_spa: {
                    required: function(element) {
                        if($("#brand-name").val()!="") {
                            return false;
                        } else {
                            return true;
                        }
                        //return $("#exercise_name_spa").is(':empty');
                    }
                },
                'category[]': {
                    required: true
                },
                'mealType[]': {
                    required: function(element) {
                        if($('#vendor-verified').is(':checked')) {
                            return true;
                        } else {
                            return false;
                        }
                        //return $("#exercise_name_spa").is(':empty');
                    }
                },
                'mealImageLocation': {
                    selectimage: true
                },
                'serving-size': {
                    required: true,
                    number: true
                },
                'serving-per-container': {
                    required: true,
                    number: true
                },
                'autocomplete_meal_unit': {
                    required: true
                }



            },
            messages: {
                meal_name: "Meal Name is required",
                meal_name_spa: {
                            required: "Name (Spanish) is required"
                }, 
                /*description: {
                            required: "Description is required"
                }, 
                description_spa: {
                            required: "Description in Spanish is required"
                }, */
                brand_name: {
                            required: "Brand Name is required"
                }, 
                brand_name_spa: {
                            required: "Brand Name (Spanish) is required"
                },
                'category[]': {
                           required: "Category is required"
                },
                'mealType[]': {
                           required: "Meal Type is required"
                },
                'serving-size': {
                            required: "Serving Size is required",
                            number: "Serving Size should be number"
                },
                'serving-per-container': {
                            required: 'Servings per container is required',
                            number: "Servings per container should be number"
                },
                'autocomplete_meal_unit': {
                            required: "Meal Unit is required"
                }
            },
            showErrors: function(errorMap, errorList) {
                this.defaultShowErrors();
                $('.scroll-pane').jScrollPane();
                $.colorbox.resize();
            },
            submitHandler: function(form) {
                $('#addMealForm').ajaxSubmit({
                       url: 'postmeal',
                       type: 'post',
                       beforeSubmit: function() {
                             $('#submitMeal').attr('disabled','disabled').addClass('button--loader');
                       },
                       success: function (data) {
                            newDataSource=data;
                            //mealKoObject.newDataSource1  = ko.observableArray(newDataSource);
                           // mealKoObject.items(mealKoObject.newDataSource1());

                            //mealKoObject.items.push(newDataSource[0]);
                            var mealIndex=$("#mealIndex").val();
                            if($("#mealId").val()==""){
                               mealKoObject.items.unshift(newDataSource);
                            } else {
                               mealKoObject.items.replace(mealKoObject.items()[mealIndex],newDataSource);   
                            }
                            
                            $.colorbox.close();
                       }

                });
            }
        });
        $('#meal-add-image').change(function() {
            $('#upload-form').ajaxSubmit({
                   url: 'mealImageSubmit',
                   type: 'post',
                   beforeSubmit: function() {
                         $("#uploaded-image").attr("src","images/common/blank.png");
                         $("#select-files-section").hide();
                         $("#uploaded-image-section" ).removeClass("hide").show().addClass('loading');
                   },
                   success: function (data) {
                        $("#uploaded-image-section" ).removeClass('loading');
                        if(data.sucess) {
                            $("#mealImageLocation-error").html("");
                            $("#image-validation-error").html("");
                            $("#image-validation-error").hide();
                            $("#select-files-section").hide();
                            $("#uploaded-image").attr("src",data.fileName_resize);
                            $("#mealImageLocation").val(data.fileName);
                            $("#mealImageResizeLocation").val(data.fileName_resize);
                            $.colorbox.resize();
                        } else {
                            $("#image-validation-error").html(data.message);
                            $("#image-validation-error").show();
                            $("#select-files-section").show();
                            $("#uploaded-image").attr("src","");
                            $("#uploaded-image-section" ).addClass( "hide" ).hide();
                            $("#mealImageLocation").val("");
                            $("#mealImageResizeLocation").val("");
                            $.colorbox.resize();
                        }
                        $('html, body').animate({ scrollTop: $('#meal-image-section').offset().top }, 'slow');
                   }

            });
            return false;

        });
        $('#meal-close').click(function() {
            $("#select-files-section").show();
            $("#uploaded-image-section").hide();
            $("#mealImageLocation").val("");
            $("#mealImageResizeLocation").val("");


        });
        $("#meal_category_management").colorbox({
            inline:true,
            width:"400",
            onOpen:function(){
               $("#categorySave").hide();
            },
            onComplete:function(){
              $(".error").html("");
              $('#categoryMessageSections').html("");
              var catVals=[];
              $("#category_name").val("");
              $("#category_name_es").val("");
              $( ".form__group-control" ).removeClass( "error" );
              $('#addCategoriesForm').validate({
                    rules: {
                        category_name: {
                            required: true
                        },
                        category_name_es: {
                            required: true
                        }
                    },
                    messages: {
                        category_name: "Category English is required",
                        category_name_es: "Category Spanish is required",
                    },
                    submitHandler: function(form) {
                     // do other things for a valid form
                     var CatName=$( "#category_name" ).val();
                     var CatNameEs=$( "#category_name_es" ).val();
                     $('#categoryMessageSections').html("");
                     var data= {category_name: CatName,category_name_es: CatNameEs};
                     Fym.eW.Services.post("addMealCategories",data, function (response) {
                        $( "#category_name" ).val("");
                        $( "#category_name_es" ).val("");
                        $('#categoryMessageSections').html("category has been added");
                        $("#categoryList").append('<li class="meal-categorie-list"><label for="input-27">'+CatName+'</label></li><li class="meal-categorie-list"><label for="input-27">'+CatNameEs+'</label></li>');
                        $("#categoryEditList").append('<li id="editCat'+response.id+'"><div class="cbox-container"><div class="icheck-list float-left"><input tabindex="27" value="'+response.id+'" type="checkbox" class="categoryEditCheck" id="cbox-cat'+response.id+'" /> </div><input type="text" maxlength="15" class="form__group-control" name="businesscat['+response.id+']"  value="'+CatName+'"  /><input type="text" maxlength="15" class="form__group-control" name="businesscates['+response.id+']"  value="'+CatNameEs+'"  /></div></li>');
                        var catagoryFilteroptionList=[];
                        var catagoryFilterList="";
                        $('#meal-category-form-list').empty();
                        $.each(response.categories, function(key,category) {
                            catagoryFilteroptionList.push( new filter(category.name,"category","checkbox"));
                            $("#meal-category-form-list").append('<li><input tabindex="3" type="checkbox" class="category-meal" value='+category.id+' name="category[]" id="input-3"><label for="input-3">'+category.name+'</label></li>');
                        });

                        newavailFilterArray   = [
                            {title:'Language',name:'language', optiontype:'radio' , optionList:[
                              new filter("English","language",'radio'),
                              new filter("Spanish","language",'radio'),
                              new filter("Both","language",'radio'),
                              new filter("All","language",'radio')   ]},
                            {title:'Meal Type',name:'mealtype', optiontype:'checkbox', optionList:[
                              new filter("Breakfast","mealtype",'checkbox'),
                              new filter("Lunch","mealtype",'checkbox'),
                              new filter("Dinner","mealtype",'checkbox'),
                              new filter("Snacks","mealtype",'checkbox')   ]},
                            {title:'Vendor Verified',name:'vendorstatus', optiontype:'radio', optionList:[
                              new filter("Verified","vendorstatus",'radio'),
                              new filter("Unverified","vendorstatus",'radio'),
                              new filter("Both","vendorstatus",'radio') ]},
                            {title:'Categories',name:'category', optiontype:'checkbox', optionList:catagoryFilteroptionList}

                        ];
                             //console.log(newavailFilterArray);
                        mealKoObject.availableFilters3  = ko.mapping.fromJS(newavailFilterArray);
                        mealKoObject.availableFilters( mealKoObject.availableFilters3());
                        if (mealKoObject.isFiltered()){
                          mealKoObject.isFiltered(false);
                        }else{
                          mealKoObject.isFiltered(true);
                        }
                        $(".category-meal").icheck({
                            checkboxClass: 'icheckbox_square-blue',
                            radioClass: 'iradio_square-blue',
                            increaseArea: '20%'
                        });
                        $("#cbox-cat"+response.id).icheck({
                            checkboxClass: 'icheckbox_square-blue',
                            radioClass: 'iradio_square-blue',
                            increaseArea: '20%'
                        });
                        $('#filter-meals input').icheck({
                            checkboxClass: 'icheckbox_square-blue',
                            radioClass: 'iradio_square-blue',
                            increaseArea: '20%'
                        });
                        $('.categoryEditCheck').on('ifChecked', function(event){
                            catVals.push($(this).val());
                        });
                        $('.categoryEditCheck').on('ifUnchecked', function(event){
                            catVals.pop($(this).val());
                        });
                        $.colorbox.resize({
                            innerHeight:$('#category-content').outerHeight()+5
                        });
                        
                    });



                                 //form.submit();
                    } ,
                    showErrors: function(errorMap, errorList) {
                        this.defaultShowErrors();
                        $.colorbox.resize();
                    }
              });
              var data= "";
              Fym.eW.Services.post("getMealCategory",data, function (response) {
                $("#categoryList").html("");
                $("#categoryEditList").html("");
                $.each(response, function(key,category) {
                  $("#categoryList").append('<li class="meal-categorie-list"><label for="input-27">'+category.name+'</label></li><li class="meal-categorie-list"><label for="input-27">'+category.name_es+'</label></li>');
                  $("#categoryEditList").append('<li id="editCat'+category.id+'"><div class="cbox-container"><div class="icheck-list float-left"><input tabindex="27" value="'+category.id+'" type="checkbox" class="categoryEditCheck" /> </div><input type="text" maxlength="15" class="form__group-control" name="businesscat['+category.id+']"  value="'+category.name+'"  /><input type="text" maxlength="15" class="form__group-control" name="businesscates['+category.id+']"  value="'+category.name_es+'"  /></div></li>');
                });
                $("#categoryListDiv").show();
                $("#categoryEditDiv").hide();
                $("#removeSelectedSection").hide();
                $("#categorySave").hide();
                $("#categoryEdit").show();
                $('#categoryEditList input').icheck({
                  checkboxClass: 'icheckbox_square-blue',
                  radioClass: 'iradio_square-blue',
                  increaseArea: '20%'
                });
                $('#categoryEdit').click(function() {
                    $("#categoryListDiv").hide();
                    $("#categoryEditDiv").show();
                    $("#categorySave").show();
                    $("#categoryEdit").hide();
                    $("#removeSelectedSection").show();

                    $('.categoryEditCheck').on('ifChecked', function(event){
                        catVals.push($(this).val());
                    });
                    $('.categoryEditCheck').on('ifUnchecked', function(event){
                        catVals.pop($(this).val());
                    });

                    $.colorbox.resize({
                        innerHeight:$('#category-content').outerHeight()+5
                    });
                });
                //$(document).on('ifChecked', '.categoryEditCheck', function(event){
                $('.categoryEditCheck').on('ifChecked', function(event){
                    catVals.push($(this).val());
                })
                $('.categoryEditCheck').on('ifUnchecked', function(event){
                    //alert($(this).val()); // alert value
                    catVals.pop($(this).val());
                })


                $('#removeCategory').click(function() {
                    var newCatVals="";
                    $('input[class=categoryEditCheck]:checked').each(function () {
                        //alert($(this).val());
                        newCatVals += $(this).val() + ','
                        //sList += "(" + $(this).val() + "-" + (this.checked ? "checked" : "not checked") + ")";
                    });
                    $.each(catVals, function(key,category) {
                        newCatVals += category + ','
                    });
                    catVals=[];
                    var data= {catVal: newCatVals};
                    Fym.eW.Services.post("removeMealCat", data, function (response) {
                        var catagoryFilteroptionList=[];
                        var catagoryFilterList="";
                        $('#meal-category-form-list').empty();
                         $.each(response.categories, function(key,category) {
                            catagoryFilteroptionList.push( new filter(category.name,"category","checkbox"));
                            $("#meal-category-form-list").append('<li><input tabindex="3" type="checkbox" class="category-meal" value='+category.id+' name="category[]" id="input-3"><label for="input-3">'+category.name+'</label></li>');
                         });

                        newavailFilterArray   = [
                                                    {title:'Language',name:'language', optiontype:'radio' , optionList:[
                                                      new filter("English","language",'radio'),
                                                      new filter("Spanish","language",'radio'),
                                                      new filter("Both","language",'radio'),
                                                      new filter("All","language",'radio')    ]},
                                                    {title:'Meal Type',name:'mealtype', optiontype:'checkbox', optionList:[
                                                      new filter("Breakfast","mealtype",'checkbox'),
                                                      new filter("Lunch","mealtype",'checkbox'),
                                                      new filter("Dinner","mealtype",'checkbox'),
                                                      new filter("Snacks","mealtype",'checkbox')   ]},
                                                    {title:'Vendor Verified',name:'vendorstatus', optiontype:'radio', optionList:[
                                                      new filter("Verified","vendorstatus",'radio'),
                                                      new filter("Unverified","vendorstatus",'radio'),
                                                      new filter("Both","vendorstatus",'radio') ]},
                                                    {title:'Categories',name:'category', optiontype:'checkbox', optionList:catagoryFilteroptionList}

                        ];
                             //console.log(newavailFilterArray);
                        mealKoObject.availableFilters3  = ko.mapping.fromJS(newavailFilterArray);
                        mealKoObject.availableFilters( mealKoObject.availableFilters3());
                        if (mealKoObject.isFiltered()){
                            mealKoObject.isFiltered(false);
                        } else{
                            mealKoObject.isFiltered(true);
                        }
                        $.each(response.catValsDel, function(key,category) {
                            $("#editCat"+category).remove();
                        });
                        //newDataSource=response.meallist;
                        //mealKoObject.newDataSource1  = ko.observableArray(newDataSource);
                        //mealKoObject.items(mealKoObject.newDataSource1());
                        $(".category-meal").icheck({
                            checkboxClass: 'icheckbox_square-blue',
                            radioClass: 'iradio_square-blue',
                            increaseArea: '20%'
                        });
                        $("#categoryEditList input").icheck('unchecked');
                        $('#filter-meals input').icheck({
                            checkboxClass: 'icheckbox_square-blue',
                            radioClass: 'iradio_square-blue',
                            increaseArea: '20%'
                        });
                        //alert(response.message);
                        $('#categoryMessageSections').html(response.message);
                        //$('#categoryMessageSection').html("Deleted Successfully");

                        $.colorbox.resize({
                            innerHeight:$('#category-content').outerHeight()+5
                        });
                    });

                });
                $.colorbox.resize({
                    innerHeight:$('#category-content').outerHeight()+5
                });
              });
              $.colorbox.resize({
                    innerHeight:$('#category-content').outerHeight()+5
              });
            },
            onClosed:function(){
                $("#categoryEditDiv").hide();
                $("#removeSelectedSection").hide();
                $("#categorySave").hide();
                $("#categoryListDiv").show();
            }
        });

        $("#manage_food_search").colorbox({
            inline:true,
            width:"500",
            onLoad:function(){
               $('#verified_meal').icheck('unchecked');
               $('#non_verified_meal').icheck('unchecked');
               $(".error").html("");
            },
            onOpen:function(){
               Fym.eW.Services.post("getMealSearchSettings",'', function (response) {
                if(response.value=="verified" || response.value=="both") {
                   $('#verified_meal').icheck('checked'); 
                }
                if(response.value=="non-verified" || response.value=="both") {
                   $('#non_verified_meal').icheck('checked'); 
                }
               });

            },
            onComplete:function(){

              
            },
            onClosed:function(){
                
            }
        });
        $('#mealPlanForm').validate({ // initialize the plugin
            onfocusout: false,
            rules: {
                'meal_paln[]': {
                    required: true
                }
            },
            messages: {
                'meal_paln[]': {
                           required: "Food search result is required"
                }
            },
            showErrors: function(errorMap, errorList) {
                this.defaultShowErrors();
                $.colorbox.resize();
            },
            submitHandler: function(form) {
                $('#mealPlanForm').ajaxSubmit({
                       url: 'updateMealSearchSettings',
                       type: 'post',
                       beforeSubmit: function() {
                             //$('#submitMeal').attr('disabled','disabled').addClass('button--loader');
                       },
                       success: function (data) {
                            
                            $.colorbox.close();
                       }

                });
            }
        });


    } ,
    mealEditId: function(id,indexValue) {
        $(".editmeallink").colorbox({
            inline:true,
            href:"#inline-content",
            width:"600px",
            onOpen:function(){
                $("label.error").html("").hide();
                $(".form__group-control").not(".new").val("");
                $( ".form__group-control" ).removeClass( "error" );
                $( ".option__unit--entry" ).removeClass( "error" );
                $( ".option__unit--entry" ).removeClass( "txt-black" );
                $( ".nutritionLabel" ).removeClass( "txt-black" );
                $(".option__unit--entry").val("");
                $("#mealIndex").val(indexValue);
                $('#submitMeal').removeAttr('disabled').removeClass('button--loader');
                //Custom scroll pane
                $('.scroll-pane').jScrollPane();
                old_spa_name="";
                old_spa_description="";
                old_spa_brand="";
                old_eng_name="";
                old_eng_description="";
                old_eng_brand="";
                var data= {mealId: id};
                Fym.eW.Services.post("getMealById", data, function (response) {
                    //$("input[name=vendor-verified]").prop("checked",false);
                    //$(".meal_language[value='"+response.language_id+"']").icheck('checked');
                    $("#lan_en").icheck('unchecked');
                    $("#lan_spa").icheck('unchecked');
                    if(response.language_id == 3) {
                        $("#lan_en").icheck('checked');
                        $("#lan_spa").icheck('checked');
                    } else if(response.language_id == 2) {
                        $("#lan_spa").icheck('checked');
                        $("#lan_en").icheck('unchecked');
                        $( "#spanish-div" ).show();
                        $( "#description-spanish-div" ).show();
                        $( "#spanish-brand-div" ).show();
                        $( "#english-div" ).hide();
                        $( "#description-english-div" ).hide();
                        $( "#english-brand-div" ).hide();
                    } else {
                        $("#lan_en").icheck('checked');
                        $("#lan_spa").icheck('unchecked');
                        $( "#spanish-div" ).hide();
                        $( "#description-spanish-div" ).hide();
                        $( "#spanish-brand-div" ).hide();
                        $( "#english-div" ).show();
                        $( "#description-english-div" ).show();
                        $( "#english-brand-div" ).show();
                    }
                    $('#vendor-verified').icheck('unchecked');
                    //$("input[name=vendor-verified][value='"+response.vendor_verified+"']").prop("checked",true);
                    $("#vendor-verified[value='"+response.vendor_verified+"']").icheck('checked');
                    $( "#meal-name" ).val(response.name);
                    $( "#meal_name_spa" ).val(response.name_es);
                    $( "#description_spa" ).val(response.description_es);
                    $( "#brand-name" ).val(response.brand_name);
                    $( "#brand-name-spa" ).val(response.brand_name_es);
                    $( "#serving-size" ).val(response.serving_size);
                    $( "#serving-per-container" ).val(response.serving_per_container);
                    $( "#description").val(response.description);
                    $( "#phone").val(response.phone);
                    $( "#url").val(response.url);
                    $( "#business-description").val(response.description);
                    $( "#autocomplete-meal-unit").val(response.mealUnitName);
                    $('.category-meal').icheck('unchecked');
                    if(response.catid !=null) {
                        var categories = response.catid.split(",");
                        //$("input[class=category-meal]").prop("checked",false);

                        $.each( categories, function( key, value ) {
                            $(".category-meal[value='"+value+"']").icheck('checked');
                        });
                    }
                    $('.meal-type').icheck('unchecked');
                    if(response.mealTypeid !=null) {
                        var mealType = response.mealTypeid.split(",");
                        //$("input[class=meal-type]").prop("checked",false);

                        $.each( mealType, function( key, value ) {
                            $(".meal-type[value='"+value+"']").icheck('checked');
                        });
                    }
                    if(response.file!="" && response.file!=null){
                        $("#select-files-section").hide();
                        $("#uploaded-image").attr("src",response.file_resize);
                        $( "#uploaded-image-section" ).removeClass( "hide" );
                        $("#uploaded-image-section").show();
                        $("#mealImageLocation").val(response.file);
                        $("#mealImageResizeLocation").val(response.file_resize);
                    }
                    $( "#mealId" ).val(response.id);
                    if ($('#vendor-verified' ).is(":checked") ) {
                        $('#meal-image-section' ).show();
                        if(response.file==""  || response.file==null) {
                            $("#select-files-section").show();
                            $("#uploaded-image-section").hide();
                            $("#mealImageLocation").val("");
                            $("#mealImageResizeLocation").val("");
                        }
                    } else {
                        $('#meal-image-section' ).hide();
                        $("#mealImageLocation").val("");
                        $("#mealImageResizeLocation").val("");
                    }
                    var dataNut= {mealId: id,servingUnit:response.serving_size_unit};
                    Fym.eW.Services.post("getMealNutritionId", dataNut, function (response) {
                        $.each( response, function( key, nutrition ) {
                            $("#nutrition"+nutrition.nutrition_fact_id).val(nutrition.value);
                        });
                    });
                    $.colorbox.resize();

                });
            },
            onComplete: function(){
                $('.scroll-pane').jScrollPane();
                $.colorbox.resize();
            }
        });
    }
};
