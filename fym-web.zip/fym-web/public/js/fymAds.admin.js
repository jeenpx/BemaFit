Fym.ad = {

    init: function() {

        var selectedRadiusToken=[];
        var selectedRadiusListToken=[];
        $('#upload-form').validate();
        var old_dt_from="";
        var old_dt_to="";
        $('#addadForm').validate({ // initialize the plugin
            rules: {
                url: {
                    required: true,
                    url: true
                },
                business_name: {
                    required: true
                },
                content: {
                    required: true
                },
                ad_dt_from: {
                    required: true
                },
                ad_dt_to: {
                    required: true
                },
                // radiusValues: {
                //     required: true
                // }

            },
            messages: {
                url:{
                    required: "URL Required",
                    url: "Please enter URL with http://www"
                },
                business_name:"Business Name is required",
                content:"Content is required",
                ad_dt_from:"Date from is required",
                ad_dt_to:"Date to is required",
                // radiusValues:"Radius  is required",
            },
            showErrors: function(errorMap, errorList) {
                $("#upload-form").show();
                this.defaultShowErrors();
                $.colorbox.resize();
            },
            submitHandler: function(form) {
                $('#addadForm').ajaxSubmit({
                       url: 'postad',
                       type: 'post',
                       beforeSubmit: function() {
                             $('#submitAddad').attr('disabled','disabled').addClass('button--loader');
                       },
                       success: function (data) {
                            newDataSource=data;
                            ViewModelObj.newDataSource1  = ko.observableArray(newDataSource);
                            ViewModelObj.items(ViewModelObj.newDataSource1());
                            $.colorbox.close();
                       }

                });


            }
        });
        $.extend($.ui.autocomplete.prototype.options, {
            open: function(event, ui) {
                $(this).autocomplete("widget").css({
                    "width": ($(this).outerWidth() + "px")
                });
            }
        });
        $('#all_radius').on('ifChecked', function(event){
            $("#radiusValues").val("");
            $("#ad-radius>li").remove();
            selectedRadiusToken=[];
            $("#autocomplete-radius").prop('disabled', true);
            $("#autocomplete-radius").addClass('disabled');
        });
        $('#all_radius').on('ifUnchecked', function(event){
            $("#autocomplete-radius").prop('disabled', false);
            $("#autocomplete-radius").removeClass('disabled');
        });
        $('#allRadiusList').on('ifChecked', function(event){
            $("#ad-filter-radius>li").remove();
            selectedRadiusListToken=[];
            $("#radiusComplete").prop('disabled', true);
            $("#radiusComplete").addClass('disabled');
        });
        $('#allRadiusList').on('ifUnchecked', function(event){
            $("#radiusComplete").prop('disabled', false);
            $("#radiusComplete").removeClass('disabled');
        });
        $('#autocomplete-radius').autocomplete({
            source: function (request, response)
            {
                $.ajax({
                    url: "radiusSelect",
                    dataType: "json",
                    method: "POST",
                    data:
                    {
                        searchValue: request.term,
                    },
                    success: function (data)
                    {
                        response($.map(data, function(v,i){
                            var tokenId = selectedRadiusToken.indexOf(v.id); 
                            if(tokenId == -1) {
                                return {
                                    label: v.state_name,
                                    id: v.id
                                };
                            }
                        }));
                    }
                });
            },
            select: function( event, ui ) {
                selectedRadiusToken.push(ui.item.id);
                $( "#ad-radius" )
                .append('<li id="ad-radius'+ui.item.id+'" class="radius-selected"><span data="'+ui.item.id+'" title="'+ui.item.label+'" class="remove-selection">Remove</span><span class="selected-item">'+ui.item.label+'</span></li>');
                var oldRadiusVal = $('#radiusValues').val();
                if(oldRadiusVal=="") {
                   $('#radiusValues').val(ui.item.label);
                } else {
                   $('#radiusValues').val(oldRadiusVal+','+ui.item.label);
                }
                $('.scroll-pane').jScrollPane();
                $(this).val("");
                return false;
            },
            minLength: 1
        });
        $('#radiusComplete').autocomplete({
            source: function (request, response)
            {
                $.ajax({
                    url: "radiusSelect",
                    dataType: "json",
                    method: "POST",
                    data:
                    {
                        searchValue: request.term,
                    },
                    success: function (data)
                    {
                        response($.map(data, function(v,i){
                            var tokenId = selectedRadiusListToken.indexOf(v.id); 
                            if(tokenId == -1) {
                                return {
                                    label: v.state_name,
                                    id: v.id
                                };
                            }
                        }));
                    }
                });
            },
            select: function( event, ui ) {
                selectedRadiusListToken.push(ui.item.id);
                ViewModelObj.autocompleteAdd(ui.item.label);
                $( "#ad-filter-radius" )
                .append('<li id="ad-radius'+ui.item.id+'" class="radius-selected"><span data="'+ui.item.id+'" title="'+ui.item.label+'" class="remove-selection remove-filter">Remove</span><span class="selected-item">'+ui.item.label+'</span></li>');
                $('.scroll-pane').jScrollPane();
                $(this).val("");
                return false;
            },
            minLength: 1
        });
        $(".addad").colorbox({
            inline:true,
            width:"450px",
            trapFocus: false,
            onOpen:function(){
                //Custom scroll pane
                var dpickDateTo = rome(dt_to,{ time: false,"inputFormat": "MM-DD-YYYY",dateValidator: rome.val.afterEq(dt_from)}, {
                    "autoHideOnBlur": false
                }).setValue($.datepicker.formatDate('mm/dd/yy', new Date()));
                
                var dpickDateFrom = rome(dt_from,{ time: false,"inputFormat": "MM-DD-YYYY",dateValidator: rome.val.beforeEq(dt_to) }, {
                    "autoHideOnBlur": false
                }).setValue($.datepicker.formatDate('mm/dd/yy', new Date()));


            },
            onComplete:function(){

                $("#ad-radius").empty();
                $("label.error").html("").hide();
                $(".form__group-control").not(".new").val("");
                $( ".form__group-control" ).removeClass( "error" );
                $('#submitAddad').removeAttr('disabled').removeClass('button--loader');
                $("#radiusValues").val("");
                $("#adId").val("");
                $("#adImageLocation").val("");
                $("#adImageResizeLocation").val("");
                $("#select-files-section").show();
                $("#uploaded-image-section").hide();
                $( "#ad-img-size" ).html("1401px x 888px");
                var location = $("#location_select").msDropdown().data("dd");
                location.showRows(5);
                location.set('value', '1');
                $.colorbox.resize();
                selectedRadiusToken=[];
                $( "#url-section" ).removeClass( "hide" );
                $( "#time-business-section" ).removeClass( "hide" );
                $( "#businessNameSection" ).removeClass( "business-name-label" );
                $( "#content-section" ).addClass( "hide" );
                $('#all_radius').icheck('unchecked');

            },
            onClosed:function(){
                $(".form__group-control").not(".new").val("");
                $("#ad-radius>li").remove();
                $("#uploaded-image").attr("src","");
            }
        });
        $(document).on('click', '.remove-selection', function(){
             var radiusId= $(this).attr('data');
             selectedRadiusToken = jQuery.grep(selectedRadiusToken, function( n, i ) {
                return (n!==radiusId);
             });
             var radiusValue=$(this).attr('title');
             //$("#ad-radius"+radiusId).hide();
             $("#ad-radius"+radiusId).remove();
             var currentRadiusVal=$('#radiusValues').val();
             var currentRadiusValArray = currentRadiusVal.split(",");
             currentRadiusValArray.splice( $.inArray(radiusValue,currentRadiusValArray), 1 );
             currentRadiusValArray.toString();
             $('#radiusValues').val(currentRadiusValArray);

        });
        $(document).on('click', '.remove-filter', function(){
             var radiusId= $(this).attr('data');
             selectedRadiusListToken = jQuery.grep(selectedRadiusListToken, function( n, i ) {
                return (n!==radiusId);
             });
             var radiusValue=$(this).attr('title');
             ViewModelObj.autocompleteRemove(radiusValue);
             //$("#ad-radius"+radiusId).hide();
             $("#ad-radius"+radiusId).remove();
        });


        //$("#location_select").msDropdown().data("dd");
        $("#timestart").msDropdown().data("dd");
        $("#timeend").msDropdown().data("dd");


    } ,
    changeLocation : function() {
        var selectedLocation=$('select#location_select option:selected').val();
        $('#adUploadType').val(selectedLocation);
        if(selectedLocation==3) {
    		$( "#url-section" ).addClass( "hide" );
    		$( "#time-business-section" ).addClass( "hide" );
            $( "#businessNameSection" ).addClass( "business-name-label" );
    		$( "#content-section" ).removeClass( "hide" );
            old_dt_from=$( "#dt_from" ).val();
            old_dt_to=$( "#dt_from" ).val();
            $( "#content" ).val("");
            $( "#dt_from" ).val( "" );
            $( "#dt_to" ).val( "" );
            $( "#ad-img-size" ).html("576px x 576px");

    	} else {
    		$( "#url-section" ).removeClass( "hide" );
    		$( "#time-business-section" ).removeClass( "hide" );
            $( "#businessNameSection" ).removeClass( "business-name-label" );
    		$( "#content-section" ).addClass( "hide" );
            if (typeof(old_dt_from) != 'undefined') {
                $( "#dt_from" ).val(old_dt_from);
            }
            if (typeof(old_dt_to) != 'undefined') {
                $( "#dt_to" ).val(old_dt_to);
            }
            if(selectedLocation==1){
                $( "#ad-img-size" ).html("1401px x 888px");
            } else {
                $( "#ad-img-size" ).html("1833px x 307px");
            }
            


    	}
        $.colorbox.resize();
    } ,
	editAd : function() {
        $('.editadlink').click(function() {
            var data= {adId: "22"};
            Fym.eW.Services.post("getAdById", data, function (response) {
                $( "#url" ).val(response[0].content);
                $( "#content" ).val(response[0].content);
                var oHandler = $('#location_select').msDropDown().data("dd");
                oHandler.set('value', response[0].ad_type_id);
                $( "#adId" ).val(response[0].id);
                $( "#business-name" ).val(response[0].business_name);
                $( "#dt_from" ).val(response[0].time_from);
                $( "#dt_to" ).val(response[0].time_to);

                $("#select-files-section").hide();
                $("#uploaded-image").attr("src",response[0].file);
                $( "#uploaded-image-section" ).removeClass( "hide" );
                $("#uploaded-image-section").show();
                $("#adImageLocation").val(response[0].file);
                $("#adImageResizeLocation").val(response[0].file_resize);

                //rome(dt_from, { initialValue: '2014-12-08 08:36' });
                if(response[0].ad_type_id==3) {
                    $( "#url" ).val('');
                    $( "#url-section" ).addClass( "hide" );
                    $( "#time-business-section" ).addClass( "hide" );
                    $( "#content-section" ).removeClass( "hide" );
                }

                //alert(response[0].ad_type_id);
                //$('#location').val(response[0].ad_type_id).attr("selected", "selected");
                //$('#location').msDropDown().data('dd').set('selectedValue',response[0].ad_type_id);

            });


        });
    },

    userEditId: function(id) {

        $('.editadlink').colorbox({inline:true,href:"#addad-content", width:"450px",trapFocus: false,
            onOpen:function(){
                var data= {adId: id};
                $("label.error").html("").hide();
                $( ".form__group-control" ).removeClass("error");
                selectedRadiusToken=[];
                $('#submitAddad').removeAttr('disabled').removeClass('button--loader');
                Fym.eW.Services.post("getAdById", data, function (response) {
                    $( "#url" ).val(response[0].content);
                    $( "#content" ).val(response[0].content);
                    var oHandler = $('#location_select').msDropDown().data("dd");
                    oHandler.set('value', response[0].ad_type_id);
                    $( "#adId" ).val(response[0].id);
                    $( "#business-name" ).val(response[0].business_name);
                    rome(dt_to,{ time: false,"inputFormat": "MM-DD-YYYY"}, {
                        "autoHideOnBlur": false
                    }).setValue(response[0].time_to);
                    rome(dt_from,{ time: false,"inputFormat": "MM-DD-YYYY" }, {
                        "autoHideOnBlur": false
                    }).setValue(response[0].time_from);
                    $( "#dt_from" ).val(response[0].time_from);
                    $( "#dt_to" ).val(response[0].time_to);
                    $("#select-files-section").show();
                    $("#uploaded-image-section").hide();
                    if(response[0].file!=""){
                        $("#select-files-section").hide();
                        $("#uploaded-image").attr("src",response[0].file_resize);
                        $( "#uploaded-image-section" ).removeClass( "hide" );
                        $("#uploaded-image-section").show();
                        $("#adImageLocation").val(response[0].file);
                        $("#adImageResizeLocation").val(response[0].file_resize);
                    }
                    $("#radiusValues").val(response[0].radius);
                    $('#all_radius').icheck('unchecked');
                    $("#all_radius[value='"+response[0].all_radius+"']").icheck('checked');
                    if(response[0].ad_type_id==3) {
                        $( "#url" ).val('');
                        $( "#url-section" ).addClass( "hide" );
                        $( "#time-business-section" ).addClass( "hide" );
                        $( "#businessNameSection" ).addClass( "business-name-label" );
                        $( "#content-section" ).removeClass( "hide" );
                        $( "#ad-img-size" ).html("576px x 576px");
                    }else {
                        $( "#url-section" ).removeClass( "hide" );
                        $( "#time-business-section" ).removeClass( "hide" );
                        $( "#businessNameSection" ).removeClass( "business-name-label" );
                        $( "#content-section" ).addClass( "hide" );
                        if(response[0].ad_type_id==1){
                            $( "#ad-img-size" ).html("1401px x 888px");
                        } else {
                            $( "#ad-img-size" ).html("1833px x 307px");
                        }
                    }
                    $.colorbox.resize();   


                });
                Fym.eW.Services.post("getAdRadiusById", data, function (response) {
                    $( "#ad-radius" ).html("");
                    var radiusValue="";
                    $.each( response, function( key, radius ) {
                        if(radius.radius_value!=0){
                            if(radius.radius_type=="State"){
                                radiusValue=radius.state_name;
                            } else {
                                radiusValue=radius.code;
                            }
                            $( "#ad-radius" )
                            .append('<li id="ad-radius'+radius.id+'" class="radius-selected"><span data="'+radius.id+'" title="'+radiusValue+'" class="remove-selection">Remove</span><span class="selected-item">'+radiusValue+'</span></li>');
                        }
                    });
                });
            

            },
            onComplete:function(){
                $.colorbox.resize();      
            },
            onClosed:function(){
                $(".form__group-control").not(".new").val("");
                $("#ad-radius>li").remove();
                $("#uploaded-image").attr("src","images/common/dark-loader-large.gif");
            }

        });



    },
    adImage: function() {
        $('#ad-add-image').change(function() {
            $('#upload-form').ajaxSubmit({
                   url: 'adImageSubmit',
                   type: 'post',
                   beforeSubmit: function() {
                         $("#uploaded-image").attr("src","images/common/blank.png");
                         $("#select-files-section").hide();
                         $("#uploaded-image-section" ).removeClass("hide").show().addClass('loading');
                   },
                   success: function (data) {
                        $("#uploaded-image-section" ).removeClass('loading');
                        if(data.sucess) {
                            $("#image-validation-error").html("");
                            $("#image-validation-error").hide();
                            $("#uploaded-image").attr("src",data.fileName_resize);
                            $("#adImageLocation").val(data.fileName);
                            $("#adImageResizeLocation").val(data.fileName_resize);
                            $.colorbox.resize();
                        } else {

                            $("#image-validation-error").html(data.message);
                            $("#image-validation-error").show();
                            $("#select-files-section").show();
                            $("#uploaded-image").attr("src","");
                            $("#uploaded-image-section" ).addClass( "hide" ).hide();
                            $("#adImageLocation").val("");
                            $("#adImageResizeLocation").val("");
                            $.colorbox.resize();
                        }
                   }

            });
            return false;

        });
    },
    adImageClose: function() {
        $('#ad-close').click(function() {
            $("#select-files-section").show();
            $("#uploaded-image-section").hide();
            $("#adImageLocation").val("");
            $("#adImageResizeLocation").val("");
            $.colorbox.resize();
        });
    },
    adAddSubmit: function() {
        $('#submitAddad').click(function() {
            $("#addadForm").submit();
            $("#upload-form").show();

        });
    }


};
