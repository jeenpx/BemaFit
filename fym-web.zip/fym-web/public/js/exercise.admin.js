var old_spa_name="";
var old_eng_name="";
Fym.exercise = {

    init: function() {
        // Initialise the colorbox once the add exercise button clicked.
        $('#saveExercise').click(function() {
            $("#addExerciseForm").submit();
        });
        $('.exercise_language').on('ifChecked', function(event){
            if($(this).val()==2) {
                $( "#spanish-div" ).show();
                $('#lan_en').icheck('enabled');
                $('#spanish-div > .form__element-block--first').addClass('margin-top-10');
                $('#exercise_name_spa').val(old_spa_name);
            }
            if($(this).val()==1) {
                $( "#english-div" ).show();
                if($('#lan_spa').prop('checked') == true){
                    $('#spanish-div > .form__element-block--first').addClass('margin-top-10');
                }
                $('#exercise-name').val(old_eng_name);

            }
            $.colorbox.resize();
        });
        $('.exercise_language').on('ifUnchecked', function(event){
            if($(this).val()==2) {
                $( "#spanish-div" ).hide();
                $('#lan_en').icheck('checked');
                $('#lan_en').icheck('disabled');
                old_spa_name=$('#exercise_name_spa').val();
                $('#exercise_name_spa').val("");
                // if($('#lan_en').prop('checked') == false){
                //     $( "#english-div" ).show();
                // }
            }
            if($(this).val()==1) {
               if($('#lan_spa').prop('checked') == true){
                $( "#english-div" ).hide();
                $('#spanish-div > .form__element-block--first').removeClass('margin-top-10');
                $( "#exercise-type" ).attr("tabindex",33);
               }
               old_eng_name=$('#exercise-name').val();
               $('#exercise-name').val("");

                
            }
            $.colorbox.resize();

        });

        $("#add-exercise").colorbox({
            inline:true,
            width:505,
            onComplete:function(){

                $("label.error").html("").hide();
                $(".form__group-control").not(".new").val("");
                $( ".form__group-control" ).removeClass( "error" );
                $( ".form__group-control" ).removeClass( "hide" );
                $('#saveExercise').removeAttr('disabled').removeClass('button--loader');
                var exerciseType = $("#exercise-type").msDropdown().data("dd");
/*                var amtHour = $("#amount-hour").msDropdown().data("dd");
                var amountMin = $("#amount-min").msDropdown().data("dd");
                var amountSec = $("#amount-sec").msDropdown().data("dd");*/
                // Set the visible rows of the select box.
                exerciseType.showRows(5);
/*                amtHour.showRows(4);
                amountMin.showRows(4);
                amountSec.showRows(4);*/
                exerciseType.set('value', 1);
/*                amtHour.set('value', "");
                amountMin.set('value', "");
                amountSec.set('value', "");*/
                Fym.exercise.exerciseTypeChange(1);
                $('.exercise_language').icheck('unchecked');
                $(".exercise_language[value='1']").icheck('checked');
                $( "#spanish-div" ).hide();
                $('#lan_en').icheck('disabled');

            },
            onClosed:function(){
              $(".form__group-control").not(".new").val("");
              $(".exercise_language").icheck('checked');
            }
        });
    } ,
    changeType : function() {
        var selectedType=$('select#exercise-type option:selected').val();  
        this.exerciseTypeChange(selectedType);
        $.colorbox.resize();
    } ,
    exerciseValidate: function() {
        $('#addExerciseForm').validate({ // initialize the plugin
            rules: {
                exercise_name: {
                    required: function(element) {
                        if($("#exercise_name_spa").val()!="") {
                            return false;
                        } else {
                            return true;
                        }
                        //return $("#exercise_name_spa").is(':empty');
                    }
                },
                exercise_name_spa: {
                    required: function(element) {
                        if($("#exercise-name").val()!="") {
                            return false;
                        } else {
                            return true;
                        }
                    }
                },
/*                calories_burned: {
                    required: true,
                    number: true
                },*/
                distance: {
                    number: true
                },
                reps_set: {
                    number: true
                },
                number_of_sets: {
                    required: true,
                    number: true
                },
                weight_per_set: {
                    required: true,
                    number: true
                },
                met_value: {
                    required: true,
                    number: true
                }
            },
            messages: {
                exercise_name: {
                            required: "Name is required"
                }, 
                exercise_name_spa: {
                            required: "Name (Spanish) is required"
                }, 
/*                calories_burned: {
                            required: "Calories Burned is required",
                            number: "Calories Burned should be number"
                },*/ 
                distance: {
                           number: "Distance should be number"
                }, 
                reps_set: {
                           number: "Reps/Set should be number"
                }, 
                number_of_sets: {
                            required: "Number of sets is required",
                            number: "Number of sets should be number"
                },
                weight_per_set: {
                            required: "Weight per set is required",
                            number: "Weight per set should be number"
                },
                met_value: {
                            required: "Met Value is required",
                            number: "Met Value should be number"
                },
            },
            showErrors: function(errorMap, errorList) {
                this.defaultShowErrors();
                $.colorbox.resize();
            },
            submitHandler: function(form) {
                $('#addExerciseForm').ajaxSubmit({
                       url: 'postexercise',
                       type: 'post',
                       beforeSubmit: function() {
                             $('#saveExercise').attr('disabled','disabled').addClass('button--loader');
                       },
                       success: function (datals) {
                            newDataSource=datals;
                            ViewModelObj.newDataSource1  = ko.observableArray(newDataSource);
                            ViewModelObj.items(ViewModelObj.newDataSource1());
                            ViewModelObj.updateUI();
                            $.colorbox.close();
                       }

                });

            },
        });
    } ,
    exerciseEdit: function(id) {
        $('.editexerciselink').colorbox({inline:true,href:"#inline-content",width:505,
            onComplete:function(){
                $("#cboxLoadingOverlay").show();
                old_spa_name="";
                old_eng_name="";
                $("label.error").html("").hide();
                $( ".form__group-control" ).removeClass( "error" );
                // Set the visible rows of the select box.
                $('#saveExercise').removeAttr('disabled').removeClass('button--loader');
                var data= {exerciseId: id};
                Fym.eW.Services.post("getExerciseById", data, function (response) {
                    //$("input[name=exercise_language][value='"+response.language_id+"']").prop("checked",true);
                    var exerciseType = $("#exercise-type").msDropdown().data("dd");
                    /*var amtHour = $("#amount-hour").msDropdown().data("dd");
                    var amountMin = $("#amount-min").msDropdown().data("dd");
                    var amountSec = $("#amount-sec").msDropdown().data("dd");*/
                    exerciseType.showRows(5);
/*                    amtHour.showRows(4);
                    amountMin.showRows(4);
                    amountSec.showRows(4);*/
                    $("#lan_en").icheck('unchecked');
                    $("#lan_spa").icheck('unchecked');
                    if(response.master.language_id == 3) {
                        $("#lan_en").icheck('checked');
                        $("#lan_spa").icheck('checked');
                    } else if(response.master.language_id == 2) {
                        $("#lan_spa").icheck('checked');
                        $("#lan_en").icheck('unchecked');
                        $( "#spanish-div" ).show();
                        $( "#english-div" ).hide();
                    } else {
                        $("#lan_en").icheck('checked');
                        $("#lan_spa").icheck('unchecked');
                        $( "#spanish-div" ).hide();
                        $( "#english-div" ).show();
                    }
                    //$(".exercise_language[value='"+response.language_id+"']").icheck('checked');
                    $( "#exercise-name" ).val(response.master.name);
                    $( "#exercise_name_spa" ).val(response.master.name_es);
                    exerciseType.set('value', response.master.exercise_type_id);
/*                    if(response.master.amount_hour==0 && response.master.amount_min==0 && response.master.amount_sec==0 ) {
                        amtHour.set('value', "");
                        amountMin.set('value', "");
                        amountSec.set('value', "");
                    } else {
                        amtHour.set('value', response.master.amount_hour);
                        amountMin.set('value', response.master.amount_min);
                        amountSec.set('value', response.master.amount_sec);
                    }*/
                    $.each( response.details, function( key, value ) {
                        switch(value.option) {
/*                            case "Calories Burned":
                                $( "#calories-burned" ).val(value.value);
                                break;*/
                            case "Distance":
                                $( "#distance" ).val(value.value);
                                break;
                            case "Number of Sets":
                                $( "#number_of_sets" ).val(value.value);
                                break;
                            case "Reps/ Weight per Set":
                                $( "#weight_per_set" ).val(value.value);
                                break;
                            case "Reps/Set":
                                $( "#reps_set" ).val(value.value);
                                break;

/*                            default:
                                default code block*/
                        }
                    });
                    //$( "#calories-burned" ).val(response.master.calories_burned);
                    //$( "#distance" ).val(response.master.distance);
                    ///$( "#number_of_sets" ).val(response.master.set_no);
                    //$( "#weight_per_set" ).val(response.master.set_weight);
                    $( "#met_value" ).val(response.master.met_value);
                    $( "#exerciseId" ).val(response.master.id);
                    Fym.exercise.exerciseTypeChange(response.master.exercise_type_id);
                    $.colorbox.resize();
                    $("#cboxLoadingOverlay").hide();
                }); 
            },
            onClosed:function(){
              $(".form__group-control").not(".new").val("");
              $(".exercise_language").icheck('checked');
            }

        });
        

    },
    exerciseTypeChange: function(selectedType) {
        if(selectedType==1) {
               $( "#number-of-items-section" ).addClass( "hide" );
               $( "#weight-per-set-section" ).addClass( "hide" );
               $( "#distance-div" ).removeClass( "hide" );
               $( "#reps-div" ).addClass( "hide" );
               $( "#number_of_sets" ).val('');
               $( "#weight_per_set" ).val('');
        } else {
               $( "#distance-div" ).addClass( "hide" );
               $( "#number-of-items-section" ).removeClass( "hide" );
               $( "#weight-per-set-section" ).removeClass( "hide" );
               $( "#reps-div" ).removeClass( "hide" );
        }
    }

	
	 
	
};