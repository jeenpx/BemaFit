// Disable caching of AJAX responses
$.ajaxSetup({
    cache: false
});