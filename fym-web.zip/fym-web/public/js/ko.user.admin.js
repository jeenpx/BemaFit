var ViewModel = function(data) {

          var self = this;
          self.items    = ko.mapping.fromJS(data);

          //Table headers
          self.headers = [
            {title:'NAME',sortPropertyName:'name', propertyClass:'sortable',width:'19.6%', asc: true},
            {title:'USERNAME',sortPropertyName:'', propertyClass:'',width:'15%', asc: true},
            {title:'EMAIL',sortPropertyName:'email', propertyClass:'',width:'25%',asc: true},
            {title:'SIGN UP',sortPropertyName:'date_added', propertyClass:'sortable',width:'14.3%',asc: true},
            {title:'PASSWORD',sortPropertyName:'', propertyClass:'',width:'13.3%',asc: true},
            {title:'MANAGE',sortPropertyName:'', propertyClass:'',width:'',asc: true}];

          self.activeSort = self.headers[0]; //set the default sort

          self.activeSortNameArrow    = ko.observable('<span class="table-sort"></span>');
          self.activeSortSignupArrow  = ko.observable('<span class="table-sort"></span>');

        self.sort = function(header,event){
          if(header.title =="NAME" || header.title =="SIGN UP") {
            //if this header was just clicked a second time
            if(self.activeSort === header) {
                header.asc = !header.asc; //toggle the direction of the sort
               
            } else {
                self.activeSort = header; //first click, remember it
            }

            var prop = self.activeSort.sortPropertyName;
            //implementation of sort
            var ascSort = function(a,b){ 


                if(prop == 'name')
                {
                  //self.activeSortNameArrow('<span class="table-sort-up"></span>');
                  //self.activeSortSignupArrow('<span class="table-sort"></span>');
                  self.activeSortNameArrow('<span class="table-sort"></span>');
                  self.activeSortSignupArrow('<span class="table-sort"></span>');
                  //alert(a.name());data-bind="foreach: items().sort(function (l, r) {  })"
                  //return String(a.name()) < String(b.name()) ? -1 : String(a.name()) > String(b.name()) ? 1 : String(a.name()) == String(b.name()) ? 0 : 0; 
                  //return (l.lastName() == r.lastName()) ? (l.firstName() > r.firstName() ? 1 : -1) : (l.lastName() > r.lastName() ? 1 : -1)
                  if(a.name().toLowerCase() > b.name().toLowerCase() )
                  {
                    return -1;

                  }
                  else if(a.name().toLowerCase() < b.name().toLowerCase() )
                  {
                    return 1;

                  }
                  else 
                  {
                    return 0;

                  }


                }
                if(prop == 'date_added')
                {
                  //
                  //self.activeSortNameArrow('<span class="table-sort"></span>');
                  //self.activeSortSignupArrow('<span class="table-sort"></span>');
                  self.activeSortNameArrow('<span class="table-sort"></span>');
                  self.activeSortSignupArrow('<span class="table-sort-up"></span>');
                  return a.signup_sort() < b.signup_sort() ? -1 : a.signup_sort() > b.signup_sort() ? 1 : a.signup_sort() == b.signup_sort() ? 1 : 1; 
                }

                return 1;
                //return a.prop() < b[prop] ? -1 : a[prop] > b[prop] ? 1 : a[prop] == b[prop] ? 0 : 0; 

            };
            var descSort = function(a,b){ 

                  
              if(prop == 'name')
                {
                  //self.activeSortNameArrow('<span class="table-sort"></span>');
                  //self.activeSortSignupArrow('<span class="table-sort"></span>');
                  self.activeSortNameArrow('<span class="table-sort-up"></span>');
                  self.activeSortSignupArrow('<span class="table-sort"></span>');
                  //alert(a.name());data-bind="foreach: items().sort(function (l, r) {  })"
                  //return String(a.name()) < String(b.name()) ? -1 : String(a.name()) > String(b.name()) ? 1 : String(a.name()) == String(b.name()) ? 0 : 0; 
                  //return (l.lastName() == r.lastName()) ? (l.firstName() > r.firstName() ? 1 : -1) : (l.lastName() > r.lastName() ? 1 : -1)
                  if(a.name().toLowerCase() < b.name().toLowerCase() )
                  {
                    return -1;

                  }
                  else if(a.name().toLowerCase() > b.name().toLowerCase() )
                  {
                    return 1;

                  }
                  else 
                  {
                    return 0;

                  }


                }
                if(prop == 'date_added')
                {
                  //alert(a.name());
                  //self.activeSortNameArrow('<span class="table-sort"></span>');
                  //self.activeSortSignupArrow('<span class="table-sort-up"></span>');
                  self.activeSortNameArrow('<span class="table-sort"></span>');
                  self.activeSortSignupArrow('<span class="table-sort"></span>');
                  return a.signup_sort() < b.signup_sort() ? 1 : a.signup_sort() > b.signup_sort() ? -1 : a.signup_sort() == b.signup_sort() ? 1 : 1; 


                }

              //return a[prop] > b[prop] ? -1 : a[prop] < b[prop] ? 1 : a[prop] == b[prop] ? 0 : 0; 

            };
            var sortFunc = self.activeSort.asc ? ascSort : descSort;
            self.items.sort(sortFunc);
            self.currentPage(1);
          }
        };

        // Pagination stuff
        this.currentPage = ko.observable(1);
        this.searchQuery = ko.observable('');
        this.perPage = 15;
        self.filteredItems      = ko.observableArray([]);
        self.usedFilters        = ko.observableArray([]);
        self.userStatusFilter   = ko.observable('');
        self.selectmsobj        = "" ;

        //self.main_data = this.items();
        this.pagedItems = ko.computed(function(){
          self.filteredItems(self.items());

          if((this.userStatusFilter() != "undefined") && (this.userStatusFilter() != "all") )
          {
            var userFiltered = _.filter(self.filteredItems(), function (i) {
                return this.keys.indexOf(i.status().toLowerCase()) > -1;
              }, {
                  "keys": [this.userStatusFilter()]  // values to look for
              });
             self.filteredItems(userFiltered) ;
          }

          if(self.searchQuery() != "")
          {
            var searchFiltered = _.filter(self.filteredItems(), function (i) {

                if(i.email().toLowerCase().indexOf(this.keys )> -1)
                {
                  return true;
                }
                if(i.username().toLowerCase().indexOf(this.keys )> -1)
                {
                  return true;
                }
                if(i.last_name().toLowerCase().indexOf(this.keys )> -1)
                {
                  return true;
                }
                if(i.first_name().toLowerCase().indexOf(this.keys )> -1)
                {
                  return true;
                }
                return false;
                //return (  &&  &&  &&  )  > -1;


              }, {
                  "keys": [self.searchQuery().toLowerCase()]  // values to look for
              });
             self.filteredItems(searchFiltered) ;
          }
          var pg = this.currentPage(),
              start = this.perPage * (pg-1),
              end = start + this.perPage;
              return  self.filteredItems.slice(start,end);

        }, this);

  
       self.searchTypeFn  = function() {
           self.currentPage(1);
           self.changeDropdown();
        };


        self.searchQuery.subscribe(self.searchTypeFn);

        var activeUserCountValuefunction  = function() {
          var activeUsers = _.filter(self.items(), function (i) {
                return this.keys.indexOf(i.status().toLowerCase()) > -1;
              }, {
                  "keys": ["active"]  // values to look for
              });
          return activeUsers.length;
        };


        var activeUserCountValue = activeUserCountValuefunction();
        self.activeUserCount = ko.observable(activeUserCountValue);


       var inActiveUserCountValuefunction  =  function() {
          var inActiveUsers = _.filter(self.items(), function (i) {
                return this.keys.indexOf(i.status().toLowerCase()) > -1;
              }, {
                  "keys": ["inactive"]  // values to look for
              });
          return inActiveUsers.length;
        };

        var inActiveUserCountValue  = inActiveUserCountValuefunction();
        self.inActiveUserCount = ko.observable(inActiveUserCountValue);

        var pendingUserCountValuefunction = function() {
          var pendingUsers = _.filter(self.items(), function (i) {
                return this.keys.indexOf(i.status().toLowerCase()) > -1;
              }, {
                  "keys": ["pending"]  // values to look for
              });
          return pendingUsers.length;
        };

        var pendingUserCountValue = pendingUserCountValuefunction();
        self.pendingUserCount     = ko.observable(pendingUserCountValue);
        self.allUserCount         = ko.observable(self.items().length);

        self.userStatusOptions = ko.computed(function() {
            var returnArray = [{"statusvalue":"All Users ("+self.allUserCount()+")","status":"all"},{"statusvalue":"Active Users ("+self.activeUserCount()+")","status":"active"},{"statusvalue":"Inactive Users ("+self.inActiveUserCount()+")","status":"inactive"},{"statusvalue":"Pending Users ("+self.pendingUserCount()+")","status":"pending"}];
            //console.log(returnArray);
            return returnArray;
        }); 


        self.updateUI = function(){
            if(self.selectmsobj != ''){
              self.selectmsobj.destroy();
              self.selectmsobj = $("#UserFilter").msDropDown().data('dd');
            }else{
              self.selectmsobj = $("#UserFilter").msDropDown().data('dd');
            }
        }

        self.userStatusFilter.subscribe(function(newValue) {
            self.updateUI();
            self.currentPage(1);
        });
       
        self.changeDropdown = function() {
          if(self.searchQuery() != "")
          {
              var searchFilteredLs = _.filter(self.items(), function (i) {
                

                if(i.email().toLowerCase().indexOf(this.keys )> -1)
                {
                  return true;
                }
                if(i.username().toLowerCase().indexOf(this.keys )> -1)
                {
                  return true;
                }
                if(i.last_name().toLowerCase().indexOf(this.keys )> -1)
                {
                  return true;
                }
                if(i.first_name().toLowerCase().indexOf(this.keys )> -1)
                {
                  return true;
                }
                return false;
              }, {
                  "keys": [self.searchQuery().toLowerCase()]  // values to look for
              });

              var totalUserSearchCount =  searchFilteredLs.length;
              self.allUserCount(totalUserSearchCount);



              var pendingUsersls = _.filter(searchFilteredLs, function (i) {
                return this.keys.indexOf(i.status().toLowerCase()) > -1;
              }, {
                  "keys": ["pending"]  // values to look for
              });
              var pendingUserSearchCount =  pendingUsersls.length;
              self.pendingUserCount(pendingUserSearchCount);

              var inActiveUsersls = _.filter(searchFilteredLs, function (i) {
                return this.keys.indexOf(i.status().toLowerCase()) > -1;
              }, {
                  "keys": ["inactive"]  // values to look for
              });
              var inactiveUserSearchCount =  inActiveUsersls.length;
              self.inActiveUserCount(inactiveUserSearchCount); 
              
              var activeUsersls = _.filter(searchFilteredLs, function (i) {
                return this.keys.indexOf(i.status().toLowerCase()) > -1;
              }, {
                  "keys": ["active"]  // values to look for
              });
              var activeUserSearchCount =  activeUsersls.length;
              self.activeUserCount(activeUserSearchCount);
          }
          else
          {

            var searchFilteredLs = self.items();
              
              var totalUserSearchCount =  searchFilteredLs.length;
              self.allUserCount(totalUserSearchCount);

              var pendingUsersls = _.filter(self.items(), function (i) {
                return this.keys.indexOf(i.status().toLowerCase()) > -1;
              }, {
                  "keys": ["pending"]  // values to look for
              });
              var pendingUserSearchCount =  pendingUsersls.length;
              self.pendingUserCount(pendingUserSearchCount);

              var inActiveUsersls = _.filter(self.items(), function (i) {
                return this.keys.indexOf(i.status().toLowerCase()) > -1;
              }, {
                  "keys": ["inactive"]  // values to look for
              });
              var inactiveUserSearchCount =  inActiveUsersls.length;
              self.inActiveUserCount(inactiveUserSearchCount); 
              
              var activeUsersls = _.filter(self.items(), function (i) {
                return this.keys.indexOf(i.status().toLowerCase()) > -1;
              }, {
                  "keys": ["active"]  // values to look for
              });
              var activeUserSearchCount =  activeUsersls.length;
              self.activeUserCount(activeUserSearchCount);
          }
          self.updateUI();
        }
    

        this.totalItems = ko.computed(function(){
            //console.log("FilteredItems"+self.filteredItems().length);
            //console.log("Items"+self.items().length);
             return self.filteredItems().length;
        });


        this.totalPageList = ko.observableArray([]);
        this.totalPageListArray = ko.observableArray([]);
        this.totalPages = ko.computed(function() {
          //console.log(this.totalItems()+"><>");
            var div = Math.floor(this.totalItems() / this.perPage);
            div     += this.totalItems() % this.perPage > 0 ? 1 : 0;
            this.totalPageList.removeAll();
            this.totalPageListArray.removeAll();
            //Adding first 2 pages
            var lastItem = 1;
            for (var i = 1; i <= 2; i++) {
                if(i < div)
                {
                  if(this.currentPage() == i)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = ""; 
                  }
                  var newPageLink = {linkNumber:i, linkClass:pageLinkClass}; 
                  this.totalPageListArray.push(newPageLink);                   
                  this.totalPageList.push(i); 
                  lastItem = i; 
                }
            }
            // Adding 2 previous pages
            for (var i = 2; i > 0; i--) {
                var nextItem = this.currentPage()  - i;
                if(nextItem > 0 && (jQuery.inArray(nextItem, this.totalPageList())===-1))
                {
                  if((nextItem - lastItem ) > 1)
                  {
                    var newPageLink = {linkNumber:'..', linkClass:'disabled'}; 
                    this.totalPageListArray.push(newPageLink);
                    this.totalPageList.push('..');  
                  }
                  if(this.currentPage() == nextItem)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = ""; 
                  }
                  var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass}; 
                          
                  this.totalPageListArray.push(newPageLink);   
                  this.totalPageList.push(nextItem );
                  lastItem = nextItem;   
                }  
            }
            //Adding current page
            var nextItem = this.currentPage();
            if((jQuery.inArray(nextItem, this.totalPageList()) ===-1))
            {
              if((nextItem - lastItem ) > 1)
              {
                  var newPageLink = {linkNumber:'..', linkClass:'disabled'}; 
                  this.totalPageListArray.push(newPageLink);
                  this.totalPageList.push('..');  
              }
              
              if(this.currentPage() == nextItem)
              {
                var pageLinkClass = "active";
              }
              else
              {
                var pageLinkClass = ""; 
              }
              var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass}; 
              this.totalPageListArray.push(newPageLink); 
              this.totalPageList.push(nextItem);  
              lastItem = nextItem;    
            }
            //Adding Next pages
            for (var i = 1; i <= 2; i++) {
                var nextItem = this.currentPage()  + i;
                if((nextItem - lastItem ) > 1)
                {
                   var newPageLink = {linkNumber:'..', linkClass:'disabled'}; 
                          
                    this.totalPageListArray.push(newPageLink);
                    this.totalPageList.push('..');  
                }
                if(nextItem  <= div && (jQuery.inArray(nextItem, this.totalPageList()) ===-1))
                {
                  if(this.currentPage() == nextItem)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = ""; 
                  }
                  var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass}; 
                  this.totalPageListArray.push(newPageLink); 
                  this.totalPageList.push(nextItem);  
                }  
                lastItem = nextItem;
            }
            //Adding last 2 pages
            for (var i = 1; i >= 0; i--) {
                var nextItem = div  - i;
                if((nextItem - lastItem ) > 1)
                {
                    var newPageLink = {linkNumber:'..', linkClass:'disabled'}; 
                    this.totalPageListArray.push(newPageLink);
                    this.totalPageList.push('..');  
                }
                if(nextItem  > 0 && (jQuery.inArray(nextItem, this.totalPageList())===-1))
                {
                  if(this.currentPage() == nextItem)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = ""; 
                  }
                  var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass}; 
                  this.totalPageListArray.push(newPageLink); 
                  this.totalPageList.push(nextItem);   
                }  
                lastItem = nextItem;
            }
            

            //console.log(div);
            return div;

        }, this);

        self.pageController = function(targetPage) {
          if(targetPage.linkNumber != '..')
          {
            return self.currentPage(targetPage.linkNumber);  
          }
          else
          {
            return false;
          }
          
        }

        this.nextPage = function(){
        if(this.nextPageEnabled())
          this.currentPage(this.currentPage()+1);
        };

        this.nextPageEnabled = ko.computed(function(){
          return this.filteredItems().length > this.perPage * this.currentPage();
        },this);

        this.previousPage = function(){
        if(this.previousPageEnabled())
            this.currentPage(this.currentPage()-1);
        };
        this.previousPageEnabled = ko.computed(function(){
            return this.currentPage() > 1;
        },this);
        //Activate user
        self.activateItem = function(item) {
              //Fym.user.acivateUser(item.id);

              //alert(item.slug)
              $( "#dialog" ).dialog({
                  autoOpen: true,
                  width: 360,
                  modal: true,
                  open: function( event, ui ) {
                    $(this).removeClass('hide');
                  },
                  close: function( event, ui ) {
                    $(this).addClass('hide');
                  },
                  buttons: [
                    {
                      text: "No, Cancel Request",
                      click: function() {
                        $( this ).dialog( "close" );
                      }
                    },
                    {
                      text: "Yes, Activate User",
                      class: "activate-txt",
                      click: function() {

                        item.id();

                        item.slug("active");
                        item.status("Active");
                        item.statusid(1);
                        item.description("Active");




                       // inActiveUserCount activeUserCount
                        var activeUserCnt = parseInt(self.activeUserCount());
                        var inactiveUserCnt = parseInt(self.inActiveUserCount());
                        self.activeUserCount(activeUserCnt+1);
                        self.inActiveUserCount(inactiveUserCnt-1);


                         //self.selectmsobj.refresh();
                         self.updateUI();
                         //$("select").refresh();


                        Fym.user.acivateUser(item.id());
                        $( this ).dialog( "close" );
                      }
                    }
                  ]
              });
        };
        //Deactivate user
        self.deactivateItem = function(item) {
              //Fym.user.acivateUser(item.id);

              //alert(item.slug)
              $( "#dialog-inactive" ).dialog({
                  autoOpen: true,
                  width: 360,
                  modal: true,
                  open: function( event, ui ) {
                    $(this).removeClass('hide');
                  },
                  close: function( event, ui ) {
                    $(this).addClass('hide');
                  },
                  buttons: [
                    {
                      text: "No, Cancel Request",
                      click: function() {
                        $( this ).dialog( "close" );
                      }
                    },
                    {
                      text: "Yes, Deactivate User",
                      click: function() {

                        item.slug("inactive");
                        item.status("Inactive");
                        item.statusid(2);
                        item.description("In-Active");
                      
                         var activeUserCnt = parseInt(self.activeUserCount());
                        var inactiveUserCnt = parseInt(self.inActiveUserCount());
                        self.activeUserCount(activeUserCnt-1);
                        self.inActiveUserCount(inactiveUserCnt+1);
                           self.updateUI();

                        Fym.user.deacivateUser(item.id());
                        $( this ).dialog( "close" );
                      }
                    }
                  ]
              });
              //item.slug="active";
              //self.items.remove(item);
              //self.items.push(Newitem);
              //self.items.replace(item,Newitem);
              //self.items.replace(item,Newitem);
              //self.items(data);
              //console.log(data);
              //ko.observableArray(data);
              //self.items.remove(item);
              //self.currentPage(2);

              //console.log(item);
              // data= {exercis,eId: item.id}
              // Fym.eW.Services.post("removeExercise", data, function (response) {
              //   if(response.msg=="Sucess") ,              //     self.items.remove(item);
              //   }
              // });
              
        };


};

ko.applyBindings(new ViewModel(dataSource));
