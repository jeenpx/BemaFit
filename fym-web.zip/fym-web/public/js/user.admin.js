Fym.user = {
    init: function() {
        $('body').on('click','.ui-widget-overlay',function() {
          var activate =  $( "#dialog" ).dialog( "instance" );
          var inactivate =  $( "#dialog-inactive" ).dialog( "instance" );
          if(activate!=null) {
            $( "#dialog" ).dialog( "close" );
          } 
          if(inactivate!=null) {
            $( "#dialog-inactive" ).dialog( "close" );
          }
        });
    } ,
    acivateUser: function(id) {
        //$( "#dialog" ).dialog( "open" );
        var data= {userId: id,action:1};
        Fym.eW.Services.post("userStatusChange", data, function (response) {
            
        });
    },
    deacivateUser: function(id) {
        //$( "#dialog" ).dialog( "open" );
        var data= {userId: id,action:2};
        Fym.eW.Services.post("userStatusChange", data, function (response) {
            
        });
    } 
}