Fym.eW = {

    /*clickMe: function() {

        $('.as').click(function() {
            alert("DSFf");
        });
    }*/
	/*
	  Fym.eW.Services.post("/Schedules/Notifications", data, function (response) {
      };
	 */
};

Fym.eW.Services = {
    post: function(url, data, success, errorCallback) {
        return this.request("POST", url, data, success, errorCallback);
    },

    put: function (url, data, success, errorCallback) {
        return this.request("PUT", url, data, success, errorCallback);
    },

    del: function (url, data, success, errorCallback) {
        return this.request("DELETE", url, data, success, errorCallback);
    },

    request: function(type, url, data, success, errorCallback) {
        return $.ajax({
            type: type,
            cache: false,
            //contentType: "application/json; charset=utf-8",
            url: url,
            //data: JSON.stringify(data),
            data: data,
            dataType: "json",
            timeout: 15000,
            success: success
        })
        .fail(function (xhr, status, error) {
            if (errorCallback != null) {
                errorCallback(xhr, status, error);
                return;
            }

            if (status == "timeout") {
                alert("Failed to communicate with FYM.");
            } else {
                // Need to output error messages
                window.location = "login";
                //alert("Save failed: " + xhr.Status);
            }
        });
    },
};

Fym.eW.Utils = {
	getJson: function(data) {
	    if (data == '' || data == 'undefined') return null;
	    return (JSON && JSON.parse(data) || $.parseJSON(data));
    }
};