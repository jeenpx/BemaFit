ko.bindingHandlers.jScrollPane = {
    init: function(element, valueAccessor) {
        var o = valueAccessor() || {};
        //initialize
        $(element).jScrollPane(o.options);
        var reinit = function() {
            var scroll = $(element).data("jsp");
            if (scroll) {
               scroll.reinitialise();
            }
        };

        // handle window resize (not really necessary if your box has a set pixel width)
        $(window).resize(reinit);

        if(o.subscribe) {
            o.subscribe.subscribe(function() {
                // use setTimeout so the DOM finishes updating before reinitialising
                setTimeout(reinit, 0);
            });
        }
    }
};
var filter  = function(value,type,optiontype) {
  this.filterValue    =  ko.observable(value);
  this.filterType     =  ko.observable(type);
  this.filterChecked  =  ko.observable(false);
  this.optionType     =  ko.observable(optiontype);
}
var ViewModel = function(data,availFilterArray) {
          var self = this;

          self.items = ko.observableArray(data,availFilterArray);
          //Filter

          // var availFilterArray   = [
          //     {title:'Categories',name:'category', optiontype:'checkbox', optionList:[
          //     new filter("Gym","category",'checkbox'),
          //     new filter("Retail","category",'checkbox'),
          //     new filter("Nutrition","category",'checkbox') ]}
          // ];

          this.availableFilters = ko.mapping.fromJS(availFilterArray);
          self.addCategory= function(options) {
             //return true;
             options.optionList.push(new filter("New Category","category",'checkbox'));
          };

          self.usedFilters = ko.observableArray([]);

          self.filterChanged = function(options) {

            self.usedFilters()
            if(options.optionType() == "radio" ) {
                ko.utils.arrayForEach(self.usedFilters(),function(v) {
                  if(v.filterType() == options.filterType()){
                    ko.utils.arrayRemoveItem(self.usedFilters(), v);
                  }
                });
                self.usedFilters.push(options);
            }
            else
            {
              ko.utils.arrayForEach(self.usedFilters(), function(v) {
                if(v)
                {
                  if(v.filterValue() == options.filterValue())  {
                    ko.utils.arrayRemoveItem(self.usedFilters(), v);
                  }
                }
              });
              if(options.filterChecked() == true)
              {
                self.usedFilters.push(options);
              }
            }
             self.currentPage(1);
            return true;
          };


          //Table headers
          self.headers = [
            {title:'NAME',sortPropertyName:'name', propertyClass:'sortable',width:'14.1%', asc: false},
            {title:'CATEGORY',sortPropertyName:'catname', propertyClass:'',width:'11.5%', asc: true},
            {title:'ADDRESS',sortPropertyName:'address', propertyClass:'',width:'15.3%', asc: true},
            {title:'PHONE',sortPropertyName:'phone', propertyClass:'',width:'11.9%',asc: true},
            {title:'RADIUS',sortPropertyName:'radius', propertyClass:'',width:'10%',asc: true},
            {title:'PREMIUM LISTING',sortPropertyName:'premium_listing', propertyClass:'sortable',width:'13.7%',asc: true},
            {title:'MANAGE',sortPropertyName:'', propertyClass:'manage',width:'23.5%',asc: true}];

          self.activeSort = self.headers[0]; //set the default sort


          self.activeSortNameArrow      = ko.observable('<span class="table-sort"></span>');
          self.activeSortListingArrow  = ko.observable('<span class="table-sort"></span>');

          self.sort = function(header,event){
            if(header.title =="NAME" || header.title =="PREMIUM LISTING") {
              //if this header was just clicked a second time
              if(self.activeSort === header) {
                  header.asc = !header.asc; //toggle the direction of the sort
              } else {
                  self.activeSort = header; //first click, remember it
              }

              var prop = self.activeSort.sortPropertyName;
              //implementation of sort
              var ascSort = function(a,b){
                 if(prop == 'name')
                  {
                    self.activeSortNameArrow('<span class="table-sort-up"></span>');
                    self.activeSortListingArrow('<span class="table-sort"></span>');

                  }
                  if(prop == 'premium_listing')
                  {
                     self.activeSortNameArrow('<span class="table-sort"></span>');
                    self.activeSortListingArrow('<span class="table-sort-up"></span>');

                  }
                return a[prop].toLowerCase() < b[prop].toLowerCase() ? -1 : a[prop].toLowerCase() > b[prop].toLowerCase() ? 1 : a[prop].toLowerCase() == b[prop].toLowerCase() ? 0 : 0;
              };
              var descSort = function(a,b){
                  self.activeSortNameArrow('<span class="table-sort"></span>');
                  self.activeSortListingArrow('<span class="table-sort"></span>');
                return a[prop].toLowerCase() > b[prop].toLowerCase() ? -1 : a[prop].toLowerCase() < b[prop].toLowerCase() ? 1 : a[prop].toLowerCase() == b[prop].toLowerCase() ? 0 : 0;
              };
              var sortFunc = self.activeSort.asc ? ascSort : descSort;
              self.items.sort(sortFunc);
              //self.currentPage(1);
            }
          };

          // Pagination stuff
          // pager related stuff
    // ---------------------------------------------
        this.currentPage = ko.observable(1);
        this.searchQuery = ko.observable('');
        this.perPage = 15;
        self.filteredItems      = ko.observableArray([]);
        self.usedFilters        = ko.observableArray([]);
        self.userStatusFilter   = ko.observable('');
        self.radiusFilters      = ko.observableArray([]);
        self.allRadiusFilter    = ko.observable(false);

        //self.main_data = this.items();
        this.pagedItems = ko.computed(function(){
          var mealtypeFilter = new Array();
          var categoryFilter = new Array();
          self.filteredItems(self.items());

          if(self.searchQuery() != "")
          {
            
            var searchFiltered = [];
            _.each(self.filteredItems(), function(eachData,key) {
              if (eachData.name.toLowerCase().indexOf(self.searchQuery().toLowerCase()) >= 0) {
                searchFiltered.push(eachData);
              }
              else if (eachData.phone.toLowerCase().indexOf(self.searchQuery().toLowerCase()) >= 0) {
                searchFiltered.push(eachData);
              }
              else if (eachData.address.toLowerCase().indexOf(self.searchQuery().toLowerCase()) >= 0) {
                searchFiltered.push(eachData);
              }

            });
            self.filteredItems(searchFiltered) ;
          }
          ko.utils.arrayForEach(self.usedFilters(), function(eachFilterUsed) {
                var eachfiltereditems  = [];
                var filterused = eachFilterUsed.filterValue().toLowerCase();
                if (!filterused) {
                    eachfiltereditems = self.filteredItems();
                }
                else if(eachFilterUsed.filterType() == 'mealtype')
                {
                      if(eachFilterUsed.filterChecked())
                      {
                        mealtypeFilter.push(filterused.toLowerCase());
                      }
                      eachfiltereditems = self.filteredItems();
                }
                else if(eachFilterUsed.filterType() == 'category')
                {
                      if(eachFilterUsed.filterChecked())
                      {
                        categoryFilter.push(filterused.toLowerCase());
                      }
                       eachfiltereditems = self.filteredItems();
                }
                else
                {
                  eachfiltereditems =  ko.utils.arrayFilter(self.filteredItems(), function(item) {

                  if(eachFilterUsed.filterType() == 'language')
                  {
                    if((filterused == item.languagename.toLowerCase()) || filterused == 'both')
                    {
                      return true;
                    }
                    else
                    {
                      return false;
                    }
                  }
                  else if(eachFilterUsed.filterType() == 'vendorstatus')
                  {

                    if(filterused == 'both')
                    {
                      return true;
                    }
                    else if(((filterused == "verified") && (item.vendor_verified.toLowerCase() == "yes") )||  ((filterused == "unverified") && (item.vendor_verified.toLowerCase() == "no") ))
                    {
                       return true;
                    }
                    else
                    {
                      return false;
                    }

                  }
                  else
                  {
                    return item.name.toLowerCase().indexOf(filterused) !== -1;
                  }
                });
              }
              self.filteredItems(eachfiltereditems) ;
          });
          if(mealtypeFilter.length > 0)
          {
            var mealFiltered = _.filter(self.filteredItems(), function (i) {
                return this.keys.indexOf(i.mealtypename.toLowerCase()) > -1;
              }, {
                  "keys": mealtypeFilter  // values to look for
              });
             self.filteredItems(mealFiltered) ;
          }
          if(self.allRadiusFilter())
          {

              var allRadiusFiltered = _.filter(self.filteredItems(), function (i) {
                if(i.all_radius == "1")
                {
                  self.radiusFilters.removeAll();
                  return true;


                }
                else

                {
                  return false;
                }

              });
             self.filteredItems(allRadiusFiltered);
          }
          else
          {
              if(self.radiusFilters().length > 0)
              {
                var radiusFiltered = _.filter(self.filteredItems(), function (i) {
                    var returnVal = false;
                    _.each(this.keys, function(eachKey) {
                          console.log(i);
                          if(i.radius.toLowerCase().indexOf(eachKey) > -1)
                          {
                            returnVal =  true;
                          }
                          else if(i.all_radius == "1")
                          {
                            returnVal =  true;

                          }
                    });
                    return returnVal;
                  }, {
                      "keys": self.radiusFilters()  // values to look for
                  });
                 self.filteredItems(radiusFiltered) ;
              }
          }


          if(categoryFilter.length > 0)
          {
            var mealFiltered = _.filter(self.filteredItems(), function (i) {
                  if(i.catname)
                  {
                     var returnVal = false; 
                    _.each(this.keys, function(eachKey) {
                          if(i.catname.toLowerCase().indexOf(eachKey) > -1)
                          {
                            returnVal =  true;
                          }
                    });
                    return returnVal;
                  }
                  else
                  {
                    return false;
                  }

              }, {
                  "keys": categoryFilter
              });
             self.filteredItems(mealFiltered) ;
          }
          var pg = this.currentPage(),
              start = this.perPage * (pg-1),
              end = start + this.perPage;
              return  self.filteredItems.slice(start,end);

        }, this);


        self.searchData = function(value) {
          /*var newData = [];
            _.each(data, function(eachData,key) {
            if (eachData.name.toLowerCase().indexOf(value.toLowerCase()) >= 0) {
              newData.push(eachData);
            }
            else if (eachData.phone.toLowerCase().indexOf(value.toLowerCase()) >= 0) {
              newData.push(eachData);
            }
            else if (eachData.address.toLowerCase().indexOf(value.toLowerCase()) >= 0) {
              newData.push(eachData);
            }

          });
          if (value == '') {
             self.items(data);
          }
          else{
            self.items(newData);
            self.currentPage(1);

          }*/
          if (value == '') {
          }
          else{
            self.currentPage(1);

          }
        };

        this.searchQuery.subscribe(this.searchData);
        this.totalItems = ko.computed(function(){
            return this.filteredItems().length;
        }, this);


        this.totalPageList = ko.observableArray([]);
        this.totalPageListArray = ko.observableArray([]);
        this.totalPages = ko.computed(function() {
            var div = Math.floor(this.totalItems() / this.perPage);
            div     += this.totalItems() % this.perPage > 0 ? 1 : 0;
            this.totalPageList.removeAll();
            this.totalPageListArray.removeAll();
            //Adding first 2 pages
            var lastItem = 1;
            for (var i = 1; i <= 2; i++) {
                if(i < div)
                {
                  if(this.currentPage() == i)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = "";
                  }
                  var newPageLink = {linkNumber:i, linkClass:pageLinkClass};
                  this.totalPageListArray.push(newPageLink);
                  this.totalPageList.push(i);
                  lastItem = i;
                }
            }
            // Adding 2 previous pages
            for (var i = 2; i > 0; i--) {
                var nextItem = this.currentPage()  - i;
                if(nextItem > 0 && (jQuery.inArray(nextItem, this.totalPageList())===-1))
                {
                  if((nextItem - lastItem ) > 1)
                  {
                    var newPageLink = {linkNumber:'..', linkClass:'disabled'};
                    this.totalPageListArray.push(newPageLink);
                    this.totalPageList.push('..');
                  }
                  if(this.currentPage() == nextItem)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = "";
                  }
                  var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass};

                  this.totalPageListArray.push(newPageLink);
                  this.totalPageList.push(nextItem );
                  lastItem = nextItem;
                }
            }
            //Adding current page
            var nextItem = this.currentPage();
            if((jQuery.inArray(nextItem, this.totalPageList()) ===-1))
            {
              if((nextItem - lastItem ) > 1)
              {
                  var newPageLink = {linkNumber:'..', linkClass:'disabled'};
                  this.totalPageListArray.push(newPageLink);
                  this.totalPageList.push('..');
              }

              if(this.currentPage() == nextItem)
              {
                var pageLinkClass = "active";
              }
              else
              {
                var pageLinkClass = "";
              }
              var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass};
              this.totalPageListArray.push(newPageLink);
              this.totalPageList.push(nextItem);
              lastItem = nextItem;
            }
            //Adding Next pages
            for (var i = 1; i <= 2; i++) {
                var nextItem = this.currentPage()  + i;
                if((nextItem - lastItem ) > 1)
                {
                   var newPageLink = {linkNumber:'..', linkClass:'disabled'};

                    this.totalPageListArray.push(newPageLink);
                    this.totalPageList.push('..');
                }
                if(nextItem  <= div && (jQuery.inArray(nextItem, this.totalPageList()) ===-1))
                {
                  if(this.currentPage() == nextItem)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = "";
                  }
                  var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass};
                  this.totalPageListArray.push(newPageLink);
                  this.totalPageList.push(nextItem);
                }
                lastItem = nextItem;
            }
            //Adding last 2 pages
            for (var i = 1; i >= 0; i--) {
                var nextItem = div  - i;
                if((nextItem - lastItem ) > 1)
                {
                    var newPageLink = {linkNumber:'..', linkClass:'disabled'};
                    this.totalPageListArray.push(newPageLink);
                    this.totalPageList.push('..');
                }
                if(nextItem  > 0 && (jQuery.inArray(nextItem, this.totalPageList())===-1))
                {
                  if(this.currentPage() == nextItem)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = "";
                  }
                  var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass};
                  this.totalPageListArray.push(newPageLink);
                  this.totalPageList.push(nextItem);
                }
                lastItem = nextItem;
            }

            return div;

        }, this);

          self.pageController = function(targetPage) {
          if(targetPage.linkNumber != '..')
          {
            return self.currentPage(targetPage.linkNumber);
          }
          else
          {
            return false;
          }

        }

         this.nextPage = function(){
        if(this.nextPageEnabled())
          this.currentPage(this.currentPage()+1);
        };

        this.nextPageEnabled = ko.computed(function(){
          return this.filteredItems().length > this.perPage * this.currentPage();
        },this);

        this.previousPage = function(){
        if(this.previousPageEnabled())
            this.currentPage(this.currentPage()-1);
        };
        this.previousPageEnabled = ko.computed(function(){
            return this.currentPage() > 1;
        },this);
        //Edit Items
        self.editBusiness = function(item) {
          Fym.business.businessEditId(item.id);
        };
        //Removing Items
        self.removeItem = function(item) {
              $( "#dialog" ).dialog({
                  autoOpen: true,
                  width: 360,
                  modal: true,
                  open: function( event, ui ) {
                    $(this).removeClass('hide');
                  },
                  close: function( event, ui ) {
                    $(this).addClass('hide');
                  },
                  buttons: [
                    {
                      text: "No, Cancel Request",
                      click: function() {
                        $( this ).dialog( "close" );
                      }
                    },
                    {
                      text: "Yes, Remove this item",
                      click: function() {

                        dataRem = {businessId: item.id}
                        Fym.eW.Services.post("removeBusiness", dataRem, function (response) {
                          if(response.msg=="Sucess") {
                            self.items.remove(item);
                            //console.log(self.totalItems());
                            if(self.currentPage()!=1) {
                              self.totalItems() % self.perPage == 0 ? self.currentPage(self.currentPage()-1) : self.currentPage();
                            }
                            
                            //self.currentPage(self.currentPage()-1);
                          }
                        });
                        $( this ).dialog( "close" );
                      }
                    }
                  ]
              });


        };
        //Copy Items
        self.copyItem = function(item) {
              dataCpy = {businessId: item.id}
              Fym.eW.Services.post("copyBusiness", dataCpy, function (response) {
                //self.items.push(response);
                  var indexItem = self.items.indexOf(item);   
              self.items.splice(indexItem, 0, response);
              //self.items.join();
              // var prop = 'id';
              //implementation of sort
              //var ascSort = function(a,b){ return a[prop] < b[prop] ? -1 : a[prop] > b[prop] ? 1 : a[prop] == b[prop] ? 0 : 0; };
              //var descSort = function(a,b){ return a[prop] > b[prop] ? -1 : a[prop] < b[prop] ? 1 : a[prop] == b[prop] ? 0 : 0; };
              //var sortFunc = descSort;
              //self.items.sort(sortFunc);
              //self.currentPage(1);
              });

        };
        self.autocompleteAdd    = function(radiusItem) {
            self.radiusFilters.push(radiusItem.toLowerCase());
            self.currentPage(1);
        }
        self.autocompleteRemove = function(radiusItem) {
            self.radiusFilters.remove(radiusItem.toLowerCase());
            self.currentPage(1);
            
        };

        self.isFiltered = ko.observable(true);
        self.showFilters = function(){
            if (self.isFiltered()){
              self.isFiltered(false);
            }else{
              self.isFiltered(true);
            }
        };

};
var ViewModelObj = new ViewModel(dataSource,availFilterArray);
ko.applyBindings(ViewModelObj);
//ko.applyBindings(new ViewModel(dataSource,availFilterArray));
