Fym.business = {
    init: function() {
        var selectedRadiusToken=[];
        var selectedRadiusListToken=[];
        $("#phone").mask("(999) 999-9999");
        $('#upload-form').validate();
        $('#addCategory').click(function() {
            $("#addCategoriesForm").submit();
        });

        $.extend($.ui.autocomplete.prototype.options, {
            open: function(event, ui) {
                $(this).autocomplete("widget").css({
                    "width": ($(this).outerWidth() + "px")
                });
            }
        });
        $('#business_hours_unavailable').on('ifChecked', function(event){
            $("#business_hour_section").hide();
            $.colorbox.resize();

        });
        $('#business_hours_available').on('ifChecked', function(event){
            $("#business_hour_section").show();
            $.colorbox.resize();

        });
        $('#all_radius').on('ifChecked', function(event){
            $("#radiusValues").val("");
            $("#ad-radius>li").remove();
            selectedRadiusToken=[];
            $("#autocomplete-radius").prop('disabled', true);
            $("#autocomplete-radius").addClass('disabled');
        });
        $('#all_radius').on('ifUnchecked', function(event){
            $("#autocomplete-radius").prop('disabled', false);
            $("#autocomplete-radius").removeClass('disabled');
        });
        $('#allRadiusList').on('ifChecked', function(event){
            $("#ad-filter-radius>li").remove();
            selectedRadiusListToken=[];
            $("#radiusComplete").prop('disabled', true);
            $("#radiusComplete").addClass('disabled');
        });
        $('#allRadiusList').on('ifUnchecked', function(event){
            $("#radiusComplete").prop('disabled', false);
            $("#radiusComplete").removeClass('disabled');
        });
        jQuery.validator.addMethod("selectimage", function(value, element){
            if ($("#businessImageLocation").val()=="") {
                return false;
            } else {
                return true;
            };
        }, "Business Image is required");
        $('#addbusinessForm').validate({ // initialize the plugin
            onfocusout: false,
            ignore: [],
            rules: {
                business_name: {
                    required: true
                },
                url: {
                    url: true
                },
                address1: {
                    required: true
                },
                zipcode: {
                    required: true
                },
                'businessImageLocation': {
                    selectimage: true
                },
                'businessCategory[]': {
                    required: true
                }
            } ,
            messages: {
                business_name: {
                    required: "Business Name is required"
                },
                url:{
                    url: "Please enter URL with http://www"
                },
                address1: {
                    required: "Address1 is required"
                },
                zipcode: {
                    required: "Zipcode is required"
                },
                'businessCategory[]': {
                    required: "Category is required"
                }
            },
            showErrors: function(errorMap, errorList) {
                this.defaultShowErrors();
                $.colorbox.resize();
            },
            submitHandler: function(form) {
                $('#addbusinessForm').ajaxSubmit({
                       url: 'postBusiness',
                       type: 'post',
                       beforeSubmit: function() {
                             $('#submitBusiness').attr('disabled','disabled').addClass('button--loader');
                       },
                       success: function (data) {
                            newDataSource=data;
                            ViewModelObj.newDataSource1  = ko.observableArray(newDataSource);
                            ViewModelObj.items(ViewModelObj.newDataSource1());
                            $.colorbox.close();
                       }

                });
            }
        });
        $('#autocomplete-radius').autocomplete({
            source: function (request, response)
            {
                $.ajax({
                    url: "radiusSelect",
                    dataType: "json",
                    method: "POST",
                    data:
                    {
                        searchValue: request.term,
                    },
                    success: function (data)
                    {
                        response($.map(data, function(v,i){
                            var tokenId = selectedRadiusToken.indexOf(v.id);
                            if(tokenId == -1) {
                                return {
                                    label: v.state_name,
                                    id: v.id
                                };
                            }
                        }));
                    }
                });
            },
            select: function( event, ui ) {
                selectedRadiusToken.push(ui.item.id);
                $( "#ad-radius" )
                .append('<li id="ad-radius'+ui.item.id+'" class="radius-selected"><span data="'+ui.item.id+'" title="'+ui.item.label+'" class="remove-selection">Remove</span><span class="selected-item">'+ui.item.label+'</span></li>');
                var oldRadiusVal = $('#radiusValues').val();
                if(oldRadiusVal=="") {
                   $('#radiusValues').val(ui.item.label);
                } else {
                   $('#radiusValues').val(oldRadiusVal+','+ui.item.label);
                }
                $('.scroll-pane').jScrollPane();
                $(this).val("");
                return false;

            },
            minLength: 1
        });
        $('#radiusComplete').autocomplete({
            source: function (request, response)
            {
                $.ajax({
                    url: "radiusSelect",
                    dataType: "json",
                    method: "POST",
                    data:
                    {
                        searchValue: request.term,
                    },
                    success: function (data)
                    {
                        response($.map(data, function(v,i){
                            var tokenId = selectedRadiusListToken.indexOf(v.id);
                            if(tokenId == -1) {
                                return {
                                    label: v.state_name,
                                    id: v.id
                                };
                            }
                        }));
                    }
                });
            },
            select: function( event, ui ) {
                selectedRadiusListToken.push(ui.item.id);
                ViewModelObj.autocompleteAdd(ui.item.label);
                $( "#ad-filter-radius" )
                .append('<li id="ad-radius'+ui.item.id+'" class="radius-selected"><span data="'+ui.item.id+'" title="'+ui.item.label+'" class="remove-selection remove-filter">Remove</span><span class="selected-item">'+ui.item.label+'</span></li>');
                $('.scroll-pane').jScrollPane();
                $(this).val("");
                return false;
            },
            minLength: 1
        });
        $(document).on('click', '.remove-selection', function(){
             var radiusId= $(this).attr('data');
             selectedRadiusToken = jQuery.grep(selectedRadiusToken, function( n, i ) {
                return (n!==radiusId);
             });
             var radiusValue=$(this).attr('title');
             //$("#ad-radius"+radiusId).hide();
             $("#ad-radius"+radiusId).remove();
             var currentRadiusVal=$('#radiusValues').val();
             var currentRadiusValArray = currentRadiusVal.split(",");
             currentRadiusValArray.splice( $.inArray(radiusValue,currentRadiusValArray), 1 );
             currentRadiusValArray.toString();
             $('#radiusValues').val(currentRadiusValArray);

        });
        $(document).on('click', '.remove-filter', function(){
             var radiusId= $(this).attr('data');
             selectedRadiusListToken = jQuery.grep(selectedRadiusListToken, function( n, i ) {
                return (n!==radiusId);
             });
             var radiusValue=$(this).attr('title');
             ViewModelObj.autocompleteRemove(radiusValue);
             //$("#ad-radius"+radiusId).hide();
             $("#ad-radius"+radiusId).remove();
        });
        $(document).on('click', '#categorySave', function(){
                $('#editCategoriesForm').ajaxSubmit({
                   url: 'editBusinessCategories',
                   type: 'post',
                   success: function (response) {
                        var catagoryFilteroptionList=[];
                        var catagoryFilterList="";
                        $('#business-category-form-list').empty();
                        $.each(response.categories, function(key,category) {
                            catagoryFilteroptionList.push( new filter(category.name,"category","checkbox"));
                            $("#business-category-form-list").append('<li class="business-category-list" id="business-category-form-list"><input tabindex="21" class="businessCategory" id="cbox-cat-list'+category.id+'"  type="checkbox" name="businessCategory[]" value="'+category.id+'" id="input-'+category.id+'"><label for="input-'+category.id+'">'+category.name+'</label></li>');
                        });

                         newavailFilterArray   = [
                            {title:'Categories',name:'category', optiontype:'checkbox', optionList:catagoryFilteroptionList}

                         ];
                             //console.log(newavailFilterArray);
                        ViewModelObj.availableFilters3  = ko.mapping.fromJS(newavailFilterArray);
                        ViewModelObj.availableFilters( ViewModelObj.availableFilters3());
                        if (ViewModelObj.isFiltered()){
                            ViewModelObj.isFiltered(false);
                        } else{
                            ViewModelObj.isFiltered(true);
                        }
                        newDataSource=response.businesslist;
                        ViewModelObj.newDataSource1  = ko.observableArray(newDataSource);
                        ViewModelObj.items(ViewModelObj.newDataSource1());
                        $('#filter-business input').icheck({
                            checkboxClass: 'icheckbox_square-blue',
                            radioClass: 'iradio_square-blue',
                            increaseArea: '20%'
                        });
                        $(".businessCategory").icheck({
                            checkboxClass: 'icheckbox_square-blue',
                            radioClass: 'iradio_square-blue',
                            increaseArea: '20%'
                        });
                        $('#categoryMessageSection').html("Updated Successfully");
                        $.colorbox.resize();
                   }

              });

        });
        $("#add-business").colorbox({
            inline:true,
            width:"575",
            onComplete:function(){
                $(".error").html("");
                $(".business_hours_check[value='1']").icheck('checked');
                $(".form__group-control").not(".new").val("");
                $( ".form__group-control" ).removeClass( "error" );
                $("#businessId").val("");
                $("#businessImageLocation").val("");
                $("#businessImageResizeLocation").val("");
                $("#radiusValues").val("");
                var state = $("#state").msDropdown().data("dd");
                var days = $(".days").msDropdown().data("dd");
                $("#ad-radius").empty();
                $("#select-files-section").show();
                $("#uploaded-image-section").hide();
                $('.businessCategory').icheck('unchecked');
                $('#submitBusiness').removeAttr('disabled').removeClass('button--loader');
                $('#all_radius').icheck('unchecked');
                $('.premium-list').icheck('unchecked');
                //var amountMin = $("#amount-min").msDropdown().data("dd");
                //var amountSec = $("#amount-sec").msDropdown().data("dd");

                // Set the visible rows of the select box.
                state.showRows(5);
                days.showRows(5);
                var BusinessDays = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
                $.each( BusinessDays, function( key, value ) {
                    $("#open_"+value).msDropdown().data("dd").set('selectedIndex',0);
                    $("#close_"+value).msDropdown().data("dd").set('selectedIndex',0);
                });
                $("#open_Monday").msDropdown().data("dd").set('selectedIndex',0);
                $("#close_Monday").msDropdown().data("dd").set('selectedIndex',0);
                selectedRadiusToken=[];
                state.set('value', 1);
                //days.set('selectedIndex',2);
                //amountMin.showRows(5);
                //amountSec.showRows(5);
                $.colorbox.resize();

            }
        });
        $("#business_category_management").colorbox({
            inline:true,
            width:"400",
            onOpen:function(){
               $("#categorySave").hide();
            },
            onComplete:function(){
              $("label.error").html("").hide();
              $("#categoryMessageSection").html("");
              categoryMessageSection
              var catVals=[];
              $("#category_name").val("");
              $("#category_name_es").val("");
              $( ".form__group-control" ).removeClass( "error" );
              $('#addCategoriesForm').validate({
                    rules: {
                        category_name: {
                            required: true
                        },
                        category_name_es: {
                            required: true
                        }
                    },
                    messages: {
                        category_name: "Category is required",
                        category_name_es: "Category Spanish is required",
                    },
                    submitHandler: function(form) {
                         var CatName=$( "#category_name" ).val();
                         var CatNameEs=$( "#category_name_es" ).val();
                         var data= {category_name: CatName,category_name_es: CatNameEs};
                         Fym.eW.Services.post("addBusinessCategories",data, function (response) {
                            $('#categoryMessageSection').html("category has been added");
                            $( "#category_name" ).val("");
                            $( "#category_name_es" ).val("");
                            $("#categoryList").append('<li class="meal-categorie-list"><label for="input-27">'+CatName+'</label></li><li class="meal-categorie-list"><label for="input-27">'+CatNameEs+'</label></li>');
                            $("#categoryEditList").append('<li id="editCat'+response.id+'"><div class="cbox-container"><div class="icheck-list float-left"><input tabindex="27" value="'+response.id+'" type="checkbox" class="categoryEditCheck" id="cbox-cat'+response.id+'" /> </div><input type="text" maxlength="15" class="form__group-control" name="businesscat['+response.id+']"  value="'+CatName+'"  /><input type="text" maxlength="15" class="form__group-control" name="businesscates['+response.id+']"  value="'+CatNameEs+'"  /></div></li>');

                            var catagoryFilteroptionList=[];
                            var catagoryFilterList="";
                            $('#business-category-form-list').empty();
                            $.each(response.categories, function(key,category) {
                                catagoryFilteroptionList.push( new filter(category.name,"category","checkbox"));
                                $("#business-category-form-list").append('<li class="business-category-list" id="business-category-form-list"><input tabindex="21" class="businessCategory" id="cbox-cat-list'+category.id+'"  type="checkbox" name="businessCategory[]" value="'+category.id+'" id="input-'+category.id+'"><label for="input-'+category.id+'">'+category.name+'</label></li>');
                            });

                            newavailFilterArray   = [
                                {title:'Categories',name:'category', optiontype:'checkbox', optionList:catagoryFilteroptionList}

                            ];
                                 //console.log(newavailFilterArray);
                            ViewModelObj.availableFilters3  = ko.mapping.fromJS(newavailFilterArray);
                            ViewModelObj.availableFilters( ViewModelObj.availableFilters3());
                            if (ViewModelObj.isFiltered()){
                                ViewModelObj.isFiltered(false);
                            } else{
                                ViewModelObj.isFiltered(true);
                            }
                            $(".businessCategory").icheck({
                                checkboxClass: 'icheckbox_square-blue',
                                radioClass: 'iradio_square-blue',
                                increaseArea: '20%'
                            });
                            $("#cbox-cat"+response.id).icheck({
                                checkboxClass: 'icheckbox_square-blue',
                                radioClass: 'iradio_square-blue',
                                increaseArea: '20%'
                            });
                            $('#filter-business input').icheck({
                                checkboxClass: 'icheckbox_square-blue',
                                radioClass: 'iradio_square-blue',
                                increaseArea: '20%'
                            });
                            $('.categoryEditCheck').on('ifChecked', function(event){
                                catVals.push($(this).val());
                            });
                            $('.categoryEditCheck').on('ifUnchecked', function(event){
                                catVals.pop($(this).val());
                            });
                            $.colorbox.resize();
                        });
                    } ,
                    showErrors: function(errorMap, errorList) {
                        this.defaultShowErrors();
                        $.colorbox.resize();
                    }
              });

              var data= "";
              Fym.eW.Services.post("getBusinessCategory",data, function (response) {
                $("#categoryList").html("");
                $("#categoryEditList").html("");
                $.each(response, function(key,category) {
                  $("#categoryList").append('<li class="business-categorie-list"><label for="input-27">'+category.name+'</label></li><li class="business-categorie-list"><label for="input-27">'+category.name_es+'</label></li>');
                  $("#categoryEditList").append('<li id="editCat'+category.id+'"><div class="cbox-container"><div class="icheck-list float-left"><input tabindex="27" value="'+category.id+'" type="checkbox" class="categoryEditCheck" /> </div><input type="text" class="form__group-control" maxlength="15" name="businesscat['+category.id+']"  value="'+category.name+'"  /><input type="text" maxlength="15" class="form__group-control" name="businesscates['+category.id+']"  value="'+category.name_es+'"  /></div></li>');
                });
                $("#categoryListDiv").show();
                $("#categoryEditDiv").hide();
                $("#removeSelectedSection").hide();
                //$("#categorySave").hide();
                $("#categoryEdit").show();
                $('#categoryEditList input').icheck({
                  checkboxClass: 'icheckbox_square-blue',
                  radioClass: 'iradio_square-blue',
                  increaseArea: '20%'
                });
                $('#categoryEdit').click(function() {
                    $("#categoryListDiv").hide();
                    $("#categoryEditDiv").show();
                    $("#categorySave").show();
                    $("#categoryEdit").hide();
                    $("#removeSelectedSection").show();
                    $('.categoryEditCheck').on('ifChecked', function(event){
                        //alert($(this).val()); // alert value
                        catVals.push($(this).val());
                    })
                    $('.categoryEditCheck').on('ifUnchecked', function(event){
                        //alert($(this).val()); // alert value
                        catVals.pop($(this).val());
                    })
                    $.colorbox.resize();
                });


                $('#removeCategory').click(function() {
                    var newCatVals="";
                    $('input[class=categoryEditCheck]:checked').each(function () {
                        //alert($(this).val());
                        newCatVals += $(this).val() + ','
                        //sList += "(" + $(this).val() + "-" + (this.checked ? "checked" : "not checked") + ")";
                    });
                    $.each(catVals, function(key,category) {
                        newCatVals += category + ','
                    });
                    catVals=[];
                    var data= {catVal: newCatVals};
                    Fym.eW.Services.post("removeBusinessCat", data, function (response) {
                        var catagoryFilteroptionList=[];
                        var catagoryFilterList="";
                        $('#business-category-form-list').empty();
                         $.each(response.categories, function(key,category) {
                            catagoryFilteroptionList.push( new filter(category.name,"category","checkbox"));
                            $("#business-category-form-list").append('<li class="business-category-list" id="business-category-form-list"><input tabindex="21" class="businessCategory" id="cbox-cat-list'+category.id+'"  type="checkbox" name="businessCategory[]" value="'+category.id+'" id="input-'+category.id+'"><label for="input-'+category.id+'">'+category.name+'</label></li>');
                         });

                         newavailFilterArray   = [
                            {title:'Categories',name:'category', optiontype:'checkbox', optionList:catagoryFilteroptionList}

                         ];
                             //console.log(newavailFilterArray);
                        ViewModelObj.availableFilters3  = ko.mapping.fromJS(newavailFilterArray);
                        ViewModelObj.availableFilters( ViewModelObj.availableFilters3());
                        if (ViewModelObj.isFiltered()){
                            ViewModelObj.isFiltered(false);
                        } else{
                            ViewModelObj.isFiltered(true);
                        }
                        $.each(response.catValsDel, function(key,category) {
                            $("#editCat"+category).remove();
                        });
                        newDataSource=response.businesslist;
                        ViewModelObj.newDataSource1  = ko.observableArray(newDataSource);
                        ViewModelObj.items(ViewModelObj.newDataSource1());
                        $('#filter-business input').icheck({
                            checkboxClass: 'icheckbox_square-blue',
                            radioClass: 'iradio_square-blue',
                            increaseArea: '20%'
                        });
                        $("#categoryEditList input").icheck('unchecked');
                        $(".businessCategory").icheck({
                            checkboxClass: 'icheckbox_square-blue',
                            radioClass: 'iradio_square-blue',
                            increaseArea: '20%'
                        });
                        $('#categoryMessageSection').html(response.message);
                        $.colorbox.resize();

                    });

                });
                $.colorbox.resize({
                    innerHeight:$('#category-content').outerHeight()+5
                });
              });
            },
            onClosed:function(){
                $("#categoryEditDiv").hide();
                $("#removeSelectedSection").hide();
                $("#categorySave").hide();
                $("#categoryListDiv").show();
            }

        });

        //$("#location").msDropdown().data("dd");
        //$("#timestart").msDropdown().data("dd");
        //$("#timeend").msDropdown().data("dd");

    } ,
    businessEditId: function(id) {
        $(".editbusinesslink").colorbox({
            inline:true,
            href:"#inline-content",
            width:"575",
            onComplete:function(){
                $("label.error").html("").hide();
                var state = $("#state").msDropdown().data("dd");
                var days = $(".days").msDropdown().data("dd");
                $(".form__group-control").not(".new").val("");
                $( ".form__group-control" ).removeClass( "error" );

                $('#submitBusiness').removeAttr('disabled').removeClass('button--loader');

                //var amountMin = $("#amount-min").msDropdown().data("dd");
                //var amountSec = $("#amount-sec").msDropdown().data("dd");

                // Set the visible rows of the select box.
                state.showRows(5);
                days.showRows(5);
                //amountMin.showRows(5);
                //amountSec.showRows(5);
                var data= {businessId: id};
                Fym.eW.Services.post("getBusinessById", data, function (response) {
                    $('.premium-list').icheck('unchecked');
                    $('.business_hours_check').icheck('unchecked');
                    $(".premium-list[value='"+response.premium_listing+"']").icheck('checked');
                    $(".business_hours_check[value='"+response.business_hour_check+"']").icheck('checked');
                    $( "#business-name" ).val(response.name);
                    $( "#address1" ).val(response.address1);
                    $( "#address2" ).val(response.address2);
                    $( "#zipcode").val(response.zipcode);
                    $( "#phone").val(response.phone);
                    $( "#url").val(response.url);
                    $( "#business-description").val(response.description);
                    $('#all_radius').icheck('unchecked');
                    $("#all_radius[value='"+response.all_radius+"']").icheck('checked');
                    state.set('value', response.state);
                    var categories = response.catid.split(",");
                    // $("input[class=businessCategory]").prop("checked",false);
                    // $.each( categories, function( key, value ) {
                    //     $("input[class=businessCategory][value='"+value+"']").prop("checked",true);
                    // });
                    $('.businessCategory').icheck('unchecked');
                    $.each( categories, function( key, value ) {
                        $(".businessCategory[value='"+value+"']").icheck('checked');
                    });
                    $("#select-files-section").show();
                    $("#uploaded-image-section").hide();
                    if(response.file!=""){
                        $("#select-files-section").hide();
                        $("#uploaded-image").attr("src",response.file_resize);
                        $( "#uploaded-image-section" ).removeClass( "hide" );
                        $("#uploaded-image-section").show();
                        $("#businessImageLocation").val(response.file);
                        $("#businessImageResizeLocation").val(response.file_resize);
                    }
                    $( "#businessId" ).val(response.id);
                    $.colorbox.resize();
                    selectedRadiusToken=[];
                });
                Fym.eW.Services.post("getRadiusById", data, function (response) {
                    $( "#ad-radius" ).html("");
                    $("#radiusValues").val("");
                    $.each( response, function( key, radius ) {
                        if(radius.radius_value!=""){
                            $( "#ad-radius" )
                            .append('<li id="ad-radius'+radius.id+'" class="radius-selected"><span data="'+radius.id+'" title="'+radius.radius_value+'" class="remove-selection">Remove</span><span class="selected-item">'+radius.radius_value+'</span></li>');
                        }
                        var oldRadiusVal = $('#radiusValues').val();
                        if(oldRadiusVal=="") {
                           $('#radiusValues').val(radius.radius_value);
                        } else {
                           $('#radiusValues').val(oldRadiusVal+','+radius.radius_value);
                        }
                    });
                });
                Fym.eW.Services.post("getBusinessHoursbyId", data, function (response) {
                    $.each( response, function( key, hours ) {
                       var businessHourOpen = $("#open_"+hours.day).msDropdown().data("dd");
                       businessHourOpen.set('value', hours.open);
                       var businessHourClose = $("#close_"+hours.day).msDropdown().data("dd");
                       businessHourClose.set('value', hours.close);
                    });
                });
            },
            onClosed:function(){
               $(".form__group-control").not(".new").val("");
               $("#ad-radius>li").remove();
               $("#uploaded-image").attr("src","");
               $(".business_hours_check[value='1']").icheck('checked');
               var BusinessDays = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
               $.each( BusinessDays, function( key, value ) {
                    $("#open_"+value).msDropdown().data("dd").set('selectedIndex',0);
                    $("#close_"+value).msDropdown().data("dd").set('selectedIndex',0);
               });
            }
        });

    },
    businessImage: function() {
        $('#business-add-image').change(function() {

            $('#upload-form').ajaxSubmit({
                   url: 'businessImageSubmit',
                   type: 'post',
                   beforeSubmit: function() {
                         $("#uploaded-image").attr("src","images/common/blank.png");
                         $("#select-files-section").hide();
                         $("#uploaded-image-section" ).removeClass("hide").show().addClass('loading');
                   },
                   success: function (data) {
                        $("#uploaded-image-section" ).removeClass('loading');
                        if(data.sucess) {
                            $("#image-validation-error").html("");
                            $("#businessImageLocation-error").html("");
                            $("#image-validation-error").hide();
                            $("#select-files-section").hide();
                            $("#uploaded-image").attr("src",data.fileName_resize);
                            $("#businessImageLocation").val(data.fileName);
                            $("#businessImageResizeLocation").val(data.fileName_resize);
                            $.colorbox.resize();
                        } else {
                            $("#image-validation-error").html(data.message);
                            $("#image-validation-error").show();
                            $("#select-files-section").show();
                            $("#uploaded-image").attr("src","");
                            $("#uploaded-image-section" ).addClass( "hide" ).hide();
                            $("#businessImageLocation").val("");
                            $("#businessImageResizeLocation").val("");
                            $.colorbox.resize();
                        }
                        $('html, body').animate({ scrollTop: $('#business-upload-section').offset().top }, 'slow');
                   }

            });

            return false;

        });
    },
    businessImageClose: function() {
        $('#business-close').click(function() {
            $("#select-files-section").show();
            $("#uploaded-image-section").hide();
            $("#businessImageLocation").val("");
            $("#businessImageResizeLocation").val("");

        });
    },
    businessAddSubmit: function() {
        $('#submitBusiness').click(function() {
            // if($.trim($('#business-name').val())=="") {
            //     $('#error_business_name').html("Business Name is required");
            //     //return false;
            // }
            // if($.trim($('#address1').val())=="") {
            //     $('#error_address1').html("Address1 is required");
            //     //return false;
            // }
            // if($.trim($('#address2').val())=="") {
            //     $('#error_address2').html("Address2 is required");
            //     //return false;
            // }
            // if($.trim($('#business-name').val())=="" || $.trim($('#address1').val())=="" || $.trim($('#address2').val())=="") {
            //     $.colorbox.resize();
            //     return false;


            // }

            //$("#addbusinessForm").submit();

        });
    }


};
