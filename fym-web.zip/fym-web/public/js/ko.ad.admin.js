var filter  = function(value,type,optiontype) {
  this.filterValue    =  ko.observable(value);
  this.filterType     =  ko.observable(type);
  this.filterChecked  =  ko.observable(false);
  this.optionType     =  ko.observable(optiontype);
}
var ViewModel = function(data) {
          var self = this;

          self.items = ko.observableArray(data)


          //Filter 
         
          var availFilterArray   = [
              {title:'Location',name:'name', optiontype:'checkbox', optionList:[
              new filter("App:Sidebar","name",'checkbox'),
              new filter("App:Newsfeed","name",'checkbox'),
              new filter("App:GuestPost","name",'checkbox') ]}
          ];

          this.availableFilters = ko.mapping.fromJS(availFilterArray);
          self.addCategory= function(options) {
             //return true;
             options.optionList.push(new filter("New Category","name",'checkbox'));
          };
          
          self.usedFilters = ko.observableArray([]);

          self.radiusFilters = ko.observableArray([]);
          

          self.filterChanged = function(options) {

            self.usedFilters()
            if(options.optionType() == "radio" ) {
                ko.utils.arrayForEach(self.usedFilters(),function(v) {
                  if(v.filterType() == options.filterType()){
                    ko.utils.arrayRemoveItem(self.usedFilters(), v);
                  }
                });
                self.usedFilters.push(options);
            }
            else
            {
              ko.utils.arrayForEach(self.usedFilters(), function(v) {
                if(v)
                {
                  if(v.filterValue() == options.filterValue())  {
                    ko.utils.arrayRemoveItem(self.usedFilters(), v);
                  }
                }
              }); 
              if(options.filterChecked() == true)
              {
                self.usedFilters.push(options);
              }
            }
             self.currentPage(1);
            return true;
          };

          //Table headers
          self.headers = [
            {title:'NAME',sortPropertyName:'business_name', propertyClass:'sortable',width:'15.2%', asc: false},
            {title:'LOCATION',sortPropertyName:'name', propertyClass:'',width:'12.1%', asc: true},
            {title:'URL',sortPropertyName:'content', propertyClass:'',width:'12.2%', asc: true},
            {title:'START DATE',sortPropertyName:'timefrom', propertyClass:'sortable',width:'13%',asc: true},
            {title:'END DATE',sortPropertyName:'timeto', propertyClass:'sortable',width:'11%',asc: true},
            {title:'TARGET',sortPropertyName:'radius', propertyClass:'',width:'12.5%',asc: true},
            {title:'MANAGE',sortPropertyName:'', propertyClass:'',width:'24%',asc: true}];

          self.activeSort = self.headers[0]; //set the default sort


          self.activeSortNameArrow      = ko.observable('<span class="table-sort"></span>');
          self.activeSortTimeFromArrow  = ko.observable('<span class="table-sort"></span>');
          self.activeSortTimeToArrow    = ko.observable('<span class="table-sort"></span>');

          self.sort = function(header,event){
            //if this header was just clicked a second time
            //console.log(header);
            if(header.title =="NAME" || header.title =="START DATE" || header.title =="END DATE" ) {
              if(self.activeSort === header) {
                  header.asc = !header.asc; //toggle the direction of the sort
              } else {
                  self.activeSort = header; //first click, remember it
              }

              var prop = self.activeSort.sortPropertyName;
              //implementation of sort
              var ascSort = function(a,b){
                if(prop == 'business_name')
                {
                  self.activeSortNameArrow('<span class="table-sort-up"></span>');
                  self.activeSortTimeFromArrow('<span class="table-sort"></span>');
                  self.activeSortTimeToArrow('<span class="table-sort"></span>');
    
                }
                if(prop == 'timefrom')
                {
                   self.activeSortNameArrow('<span class="table-sort"></span>');
                  self.activeSortTimeFromArrow('<span class="table-sort-up"></span>');
                  self.activeSortTimeToArrow('<span class="table-sort"></span>');
    
                }
                if(prop == 'timeto')
                {
                  self.activeSortNameArrow('<span class="table-sort"></span>');
                  self.activeSortTimeFromArrow('<span class="table-sort"></span>');
                  self.activeSortTimeToArrow('<span class="table-sort-up"></span>');
    
                }
                return a[prop].toLowerCase() < b[prop].toLowerCase() ? -1 : a[prop].toLowerCase() > b[prop].toLowerCase() ? 1 : a[prop].toLowerCase() == b[prop].toLowerCase() ? 0 : 0; 
              };
              var descSort = function(a,b){ 
                 if(prop == 'business_name')
                {
                  self.activeSortNameArrow('<span class="table-sort"></span>');
                  self.activeSortTimeFromArrow('<span class="table-sort"></span>');
                  self.activeSortTimeToArrow('<span class="table-sort"></span>');
    
                }
                if(prop == 'timefrom')
                {
                   self.activeSortNameArrow('<span class="table-sort"></span>');
                  self.activeSortTimeFromArrow('<span class="table-sort"></span>');
                  self.activeSortTimeToArrow('<span class="table-sort"></span>');
    
                }
                if(prop == 'timeto')
                {
                  self.activeSortNameArrow('<span class="table-sort"></span>');
                  self.activeSortTimeFromArrow('<span class="table-sort"></span>');
                  self.activeSortTimeToArrow('<span class="table-sort"></span>');
    
                }
                return a[prop].toLowerCase() > b[prop].toLowerCase() ? -1 : a[prop].toLowerCase() < b[prop].toLowerCase() ? 1 : a[prop].toLowerCase() == b[prop].toLowerCase() ? 0 : 0; 
              };
              var sortFunc = self.activeSort.asc ? ascSort : descSort;
              self.items.sort(sortFunc);
              //self.currentPage(1);
            }
          };

          // Pagination stuff
          // pager related stuff
    // ---------------------------------------------
        this.currentPage = ko.observable(1);
        this.searchQuery = ko.observable('');
        this.perPage = 15;
        self.filteredItems      = ko.observableArray([]);
        self.usedFilters        = ko.observableArray([]);
        self.userStatusFilter   = ko.observable(''); 
        self.allRadiusFilter    = ko.observable(false); 
        //self.main_data = this.items();
        this.pagedItems = ko.computed(function(){
          var categoryFilter = new Array();
          self.filteredItems(self.items());
          if(self.searchQuery() != "")
          {
            self.currentPage(1);
            var searchFiltered = _.filter(self.filteredItems(), function (i) {

                return (i.business_name.toLowerCase().indexOf(this.keys ) )  > -1;


              }, {
                  "keys": [self.searchQuery().toLowerCase()]  // values to look for
              });
             self.filteredItems(searchFiltered) ;
          }
          ko.utils.arrayForEach(self.usedFilters(), function(eachFilterUsed) {
                var eachfiltereditems  = [];
                var filterused = eachFilterUsed.filterValue().toLowerCase();
                if (!filterused) {
                    eachfiltereditems = self.filteredItems();
                }
                else if(eachFilterUsed.filterType() == 'name')
                { 
                      if(eachFilterUsed.filterChecked())
                      {
                        categoryFilter.push(filterused.toLowerCase());
                      }
                       eachfiltereditems = self.filteredItems();
                }
                else
                {
                  eachfiltereditems =  ko.utils.arrayFilter(self.filteredItems(), function(item) {
                    return true;
                  });
              }
              self.filteredItems(eachfiltereditems) ;
          }); 
          

          if(self.allRadiusFilter())
          {
                var allRadiusFiltered = _.filter(self.filteredItems(), function (i) {
                  if(i.all_radius == "1")
                  {
                    return true;

                  }
                  else

                  {
                    return false;
                  }
                  
                });
               self.filteredItems(allRadiusFiltered);
          }
          else
          {
              if(self.radiusFilters().length > 0)
              {
                var radiusFiltered = _.filter(self.filteredItems(), function (i) {
                    var returnVal = false; 
                    _.each(this.keys, function(eachKey) {
                          console.log(i);
                          if(i.radius.toLowerCase().indexOf(eachKey) > -1)
                          {
                            returnVal =  true;
                          }
                          else if(i.all_radius == "1")
                          {
                            returnVal =  true;

                          }
                    });
                    return returnVal;
                  }, {
                      "keys": self.radiusFilters()  // values to look for
                  });
                 self.filteredItems(radiusFiltered) ;
              }
          }
          if(categoryFilter.length > 0)
          {
            var mealFiltered = _.filter(self.filteredItems(), function (i) {
                  if(i.name)
                  {
                    var returnVal = false; 
                    _.each(this.keys, function(eachKey) {
                          if(i.name.toLowerCase().indexOf(eachKey) > -1)
                          {
                            returnVal =  true;
                          }
                    });
                    return returnVal;
                  }
                  else
                  {
                    return false;
                  }
                  
              }, {
                  "keys": categoryFilter  
              });
             self.filteredItems(mealFiltered) ;
          }
          var pg = this.currentPage(),
              start = this.perPage * (pg-1),
              end = start + this.perPage;
              return  self.filteredItems.slice(start,end);

        }, this);
        

        self.searchData = function(value) {
          var newData = [];         
          var oldData = [];      
            _.each(self.items(), function(eachData,key) {
              oldData.push(eachData);
            if (eachData.business_name.toLowerCase().indexOf(value.toLowerCase()) >= 0) {
              newData.push(eachData);
            }

          });
          if (value == '') {
            self.items(oldData);
            self.currentPage(1);

          }
          else{

            self.filteredItems(newData); 
            self.currentPage(1);

          }
          //console.log(self.items())
        };

        //this.searchQuery.subscribe(this.searchData);
        this.totalItems = ko.computed(function(){
            return this.filteredItems().length;
        }, this);


        this.totalPageList = ko.observableArray([]);
        this.totalPageListArray = ko.observableArray([]);
        this.totalPages = ko.computed(function() {
            var div = Math.floor(this.totalItems() / this.perPage);
            div     += this.totalItems() % this.perPage > 0 ? 1 : 0;
            this.totalPageList.removeAll();
            this.totalPageListArray.removeAll();
            //Adding first 2 pages
            var lastItem = 1;
            for (var i = 1; i <= 2; i++) {
                if(i < div)
                {
                  if(this.currentPage() == i)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = ""; 
                  }
                  var newPageLink = {linkNumber:i, linkClass:pageLinkClass}; 
                  this.totalPageListArray.push(newPageLink);                   
                  this.totalPageList.push(i); 
                  lastItem = i; 
                }
            }
            // Adding 2 previous pages
            for (var i = 2; i > 0; i--) {
                var nextItem = this.currentPage()  - i;
                if(nextItem > 0 && (jQuery.inArray(nextItem, this.totalPageList())===-1))
                {
                  if((nextItem - lastItem ) > 1)
                  {
                    var newPageLink = {linkNumber:'..', linkClass:'disabled'}; 
                    this.totalPageListArray.push(newPageLink);
                    this.totalPageList.push('..');  
                  }
                  if(this.currentPage() == nextItem)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = ""; 
                  }
                  var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass}; 

                  this.totalPageListArray.push(newPageLink);   
                  this.totalPageList.push(nextItem );
                  lastItem = nextItem;   
                }  
            }
            //Adding current page
            var nextItem = this.currentPage();
            if((jQuery.inArray(nextItem, this.totalPageList()) ===-1))
            {
              if((nextItem - lastItem ) > 1)
              {
                  var newPageLink = {linkNumber:'..', linkClass:'disabled'}; 
                  this.totalPageListArray.push(newPageLink);
                  this.totalPageList.push('..');  
              }
              
              if(this.currentPage() == nextItem)
              {
                var pageLinkClass = "active";
              }
              else
              {
                var pageLinkClass = ""; 
              }
              var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass}; 
              this.totalPageListArray.push(newPageLink); 
              this.totalPageList.push(nextItem);  
              lastItem = nextItem;    
            }
            //Adding Next pages
            for (var i = 1; i <= 2; i++) {
                var nextItem = this.currentPage()  + i;
                if((nextItem - lastItem ) > 1)
                {
                   var newPageLink = {linkNumber:'..', linkClass:'disabled'}; 
                    this.totalPageListArray.push(newPageLink);
                    this.totalPageList.push('..');  
                }
                if(nextItem  <= div && (jQuery.inArray(nextItem, this.totalPageList()) ===-1))
                {
                  if(this.currentPage() == nextItem)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = ""; 
                  }
                  var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass}; 
                  this.totalPageListArray.push(newPageLink); 
                  this.totalPageList.push(nextItem);  
                }  
                lastItem = nextItem;
            }
            //Adding last 2 pages
            for (var i = 1; i >= 0; i--) {
                var nextItem = div  - i;
                if((nextItem - lastItem ) > 1)
                {
                    var newPageLink = {linkNumber:'..', linkClass:'disabled'}; 
                    this.totalPageListArray.push(newPageLink);
                    this.totalPageList.push('..');  
                }
                if(nextItem  > 0 && (jQuery.inArray(nextItem, this.totalPageList())===-1))
                {
                  if(this.currentPage() == nextItem)
                  {
                    var pageLinkClass = "active";
                  }
                  else
                  {
                    var pageLinkClass = ""; 
                  }
                  var newPageLink = {linkNumber:nextItem, linkClass:pageLinkClass}; 
                  this.totalPageListArray.push(newPageLink); 
                  this.totalPageList.push(nextItem);   
                }  
                lastItem = nextItem;
            }
            
            return div;

        }, this);

          self.pageController = function(targetPage) {
          if(targetPage.linkNumber != '..')
          {
            return self.currentPage(targetPage.linkNumber);  
          }
          else
          {
            return false;
          }
          
        }

         this.nextPage = function(){
        if(this.nextPageEnabled())
          this.currentPage(this.currentPage()+1);
        };

        this.nextPageEnabled = ko.computed(function(){
          return this.filteredItems().length > this.perPage * this.currentPage();
        },this);

        this.previousPage = function(){
        if(this.previousPageEnabled())
            this.currentPage(this.currentPage()-1);
        };
        this.previousPageEnabled = ko.computed(function(){
            return this.currentPage() > 1;
        },this);
        //Edit Items
        self.editAd = function(item) {
          Fym.ad.userEditId(item.id);
        };
        //Removing Items
        self.removeItem = function(item) {
              $( "#dialog" ).dialog({
                  autoOpen: true,
                  width: 360,
                  modal: true,
                  open: function( event, ui ) {
                    $(this).removeClass('hide');
                  },
                  close: function( event, ui ) {
                    $(this).addClass('hide');
                  },
                  buttons: [
                    {
                      text: "No, Cancel Request",
                      click: function() {
                        $( this ).dialog( "close" );
                      }
                    },
                    {
                      text: "Yes, Remove this item",
                      click: function() {

                        dataRem = {adId: item.id}
                        Fym.eW.Services.post("removeAd", dataRem, function (response) {
                          if(response.msg=="Sucess") {
                            self.items.remove(item);
                            /*var index = data.indexOf(item);
                            data=data.filter(function(el){return el.id !== item.id});*/
                            if(self.currentPage()!=1) {
                              self.totalItems() % self.perPage == 0 ? self.currentPage(self.currentPage()-1) : self.currentPage();
                            }
                          }
                        });
                        $( this ).dialog( "close" );
                      }
                    }
                  ]
              });

              
        };    
        //Copy Items
        self.copyItem = function(item) {
              datad= {adId: item.id}
              Fym.eW.Services.post("copyAd", datad, function (response) {

              var indexItem = self.items.indexOf(item);   
              self.items.splice(indexItem, 0, response);
              //self.items.join();
              //self.items.push(response);
              // var prop = 'id';
              //implementation of sort
              //var ascSort = function(a,b){ return a[prop] < b[prop] ? -1 : a[prop] > b[prop] ? 1 : a[prop] == b[prop] ? 0 : 0; };
              //var descSort = function(a,b){ return a[prop] > b[prop] ? -1 : a[prop] < b[prop] ? 1 : a[prop] == b[prop] ? 0 : 0; };
              //var sortFunc = descSort;
              //self.items.sort(sortFunc);
              //self.currentPage(1);
              });
              
        };  
        self.autocompleteAdd    = function(radiusItem) {
            self.radiusFilters.push(radiusItem.toLowerCase());
            self.currentPage(1);
        }  
        self.autocompleteRemove = function(radiusItem) {
            self.radiusFilters.remove(radiusItem.toLowerCase());
            self.currentPage(1);
        }  
         self.allRadiusFilterchanged = function(radiusItem) {
                 self.radiusFilters.removeAll();
                 self.currentPage(1);
                 return true;
        }  
};
var ViewModelObj = new ViewModel(dataSource);
ko.applyBindings(ViewModelObj);
